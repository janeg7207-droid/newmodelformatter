"""Build a small, verified copy/literal patch for the experimental formatter.

This reads EXE archives as data. It does not execute either EXE or load bytecode.
Python 3.9+ is sufficient for building; users need only Windows PowerShell.
"""

import argparse
import base64
import gzip
import hashlib
import json
from pathlib import Path
import struct
import zipfile


MAGIC = b'MEI\014\013\012\013\016'
COOKIE = struct.Struct('!8sIIII64s')
ENTRY = struct.Struct('!IIIIBc')
FORMAT = 'gmf-copy-literal-v1'


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def archive_segments(data):
    """Return the PE prefix and absolute raw payload locations, without imports."""
    cookie_at = data.rfind(MAGIC)
    if cookie_at < 0 or cookie_at + COOKIE.size != len(data):
        raise ValueError('Expected an unsigned PyInstaller EXE ending at EOF')
    magic, length, toc_offset, toc_size, version, library = COOKIE.unpack_from(data, cookie_at)
    start = len(data) - length
    if start < 0 or toc_offset + toc_size != length - COOKIE.size:
        raise ValueError('Invalid CArchive extent')
    entries = []
    names = set()
    cursor, end = start + toc_offset, start + toc_offset + toc_size
    expected_payload_offset = 0
    while cursor < end:
        if cursor + ENTRY.size > end:
            raise ValueError('Truncated CArchive table')
        size, offset, stored_size, plain_size, compressed, kind = ENTRY.unpack_from(data, cursor)
        if size < ENTRY.size + 1 or cursor + size > end or offset + stored_size > toc_offset:
            raise ValueError('Invalid CArchive entry')
        name = data[cursor + ENTRY.size:cursor + size].rstrip(b'\0').decode('utf-8')
        if name in names:
            raise ValueError('Duplicate CArchive entry: ' + name)
        # The inspected builder writes contiguous payloads in table order. Refuse
        # alternate layouts so no padding or gaps are accidentally discarded.
        if offset != expected_payload_offset:
            raise ValueError('Expected contiguous CArchive payloads')
        expected_payload_offset += stored_size
        names.add(name)
        entries.append({'name': name, 'kind': kind, 'offset': start + offset,
                        'length': stored_size, 'compressed': compressed,
                        'plain_size': plain_size})
        cursor += size
    if cursor != end or expected_payload_offset != toc_offset:
        raise ValueError('CArchive payload/table extent mismatch')
    return start, entries, start + toc_offset


def append_copy(ops, offset, length):
    if not length:
        return
    if ops and 'offset' in ops[-1] and ops[-1]['offset'] + ops[-1]['length'] == offset:
        ops[-1]['length'] += length
    else:
        ops.append({'offset': offset, 'length': length})


def append_literal(ops, data):
    if data:
        ops.append({'literal': base64.b64encode(data).decode('ascii')})


def pyz_delta(ops, source, target, old, new):
    """Reuse original compressed module bytes inside the uncompressed PYZ."""
    if old['compressed'] or new['compressed']:
        return False
    a = source[old['offset']:old['offset'] + old['length']]
    b = target[new['offset']:new['offset'] + new['length']]
    if len(a) < 12 or len(b) < 12 or a[:4] != b'PYZ\0' or a[:8] != b[:8]:
        return False
    old_toc = struct.unpack_from('!i', a, 8)[0]
    new_toc = struct.unpack_from('!i', b, 8)[0]
    if not (12 <= old_toc <= len(a) and old_toc <= new_toc <= len(b)):
        return False
    if a[12:old_toc] != b[12:old_toc]:
        return False
    append_copy(ops, old['offset'], 8)
    append_literal(ops, b[8:12])
    append_copy(ops, old['offset'] + 12, old_toc - 12)
    append_literal(ops, b[old_toc:])
    return True


def make_patch(source, target):
    source_prefix, original_entries, source_table = archive_segments(source)
    target_prefix, target_entries, target_table = archive_segments(target)
    if source[:source_prefix] != target[:target_prefix]:
        raise ValueError('Expected the exact unchanged original PE prefix')
    old_by_name = {entry['name']: entry for entry in original_entries}
    ops = []
    append_copy(ops, 0, source_prefix)
    reused_entries = 0
    reused_pyz_prefix = False
    for new in target_entries:
        raw = target[new['offset']:new['offset'] + new['length']]
        old = old_by_name.get(new['name'])
        if old is not None and old['kind'] == new['kind']:
            original_raw = source[old['offset']:old['offset'] + old['length']]
            if original_raw == raw:
                append_copy(ops, old['offset'], old['length'])
                reused_entries += 1
                continue
            if new['name'] == 'PYZ.pyz' and pyz_delta(ops, source, target, old, new):
                reused_pyz_prefix = True
                continue
        append_literal(ops, raw)
    append_literal(ops, target[target_table:])
    patch = {'format': FORMAT, 'original_sha256': sha256(source),
             'original_bytes': len(source), 'target_sha256': sha256(target),
             'target_bytes': len(target), 'operations': ops}
    result = apply_patch_bytes(source, patch)
    if result != target:
        raise ValueError('Generated patch failed exact reconstruction')
    validation = {'original_sha256': patch['original_sha256'],
                  'target_sha256': patch['target_sha256'],
                  'original_bytes': len(source), 'target_bytes': len(target),
                  'operation_count': len(ops), 'raw_carchive_payloads_reused': reused_entries,
                  'original_pyz_module_prefix_reused': reused_pyz_prefix,
                  'python_reconstruction_verified': True,
                  'windows_powershell_installer_tested': False}
    return patch, validation


def apply_patch_bytes(source, patch):
    if patch.get('format') != FORMAT or len(source) != patch['original_bytes']:
        raise ValueError('Patch format/source size mismatch')
    if sha256(source) != patch['original_sha256']:
        raise ValueError('Original SHA-256 mismatch')
    result = bytearray()
    for op in patch['operations']:
        if set(op) == {'offset', 'length'}:
            offset, length = op['offset'], op['length']
            if type(offset) is not int or type(length) is not int or offset < 0 or length < 0:
                raise ValueError('Invalid copy operation')
            if offset > len(source) or length > len(source) - offset:
                raise ValueError('Copy exceeds original EXE')
            chunk = source[offset:offset + length]
        elif set(op) == {'literal'}:
            chunk = base64.b64decode(op['literal'], validate=True)
        else:
            raise ValueError('Invalid patch operation')
        if len(chunk) > patch['target_bytes'] - len(result):
            raise ValueError('Operation exceeds target size')
        result.extend(chunk)
    if len(result) != patch['target_bytes'] or sha256(result) != patch['target_sha256']:
        raise ValueError('Target size/SHA-256 mismatch')
    return bytes(result)


def build(original_path, target_path, zip_path):
    original_path, target_path, zip_path = map(Path, (original_path, target_path, zip_path))
    if zip_path.exists():
        raise ValueError('Choose a new ZIP filename; existing files are never overwritten')
    patch, validation = make_patch(original_path.read_bytes(), target_path.read_bytes())
    packed = gzip.compress(json.dumps(patch, separators=(',', ':')).encode('utf-8'), mtime=0)
    validation['compressed_patch_bytes'] = len(packed)
    folder = Path(__file__).parent
    archive_names = ['Install.cmd', 'Apply-FormatterPatch.ps1', 'README.txt']
    with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        output.writestr('formatter.patch.json.gz', packed)
        output.writestr('patch-validation.json', json.dumps(validation, indent=2) + '\n')
        for name in archive_names:
            output.writestr(name, (folder / name).read_bytes())
    with zipfile.ZipFile(zip_path) as check:
        bad = check.testzip()
        if bad is not None:
            raise ValueError('ZIP CRC validation failed: ' + bad)
        checked_patch = json.loads(gzip.decompress(check.read('formatter.patch.json.gz')))
        if apply_patch_bytes(original_path.read_bytes(), checked_patch) != target_path.read_bytes():
            raise ValueError('Packaged patch reconstruction failed')
    validation['zip_crc_verified'] = True
    validation['zip_bytes'] = zip_path.stat().st_size
    return validation


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original_exe')
    parser.add_argument('target_exe')
    parser.add_argument('output_zip')
    args = parser.parse_args()
    print(json.dumps(build(args.original_exe, args.target_exe, args.output_zip), indent=2))
