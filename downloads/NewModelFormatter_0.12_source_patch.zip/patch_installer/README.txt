NewModelFormatter 0.12 experimental

INSTALL

1. Right-click this ZIP and choose Extract All into a NEW empty folder.
2. Open that folder and double-click Install.cmd.
3. Choose your ORIGINAL Gorilla Model Formatter 1.0 EXE.
4. Wait for "Created successfully", then open NewModelFormatter.exe.

Do not run Install.cmd inside the ZIP. Keep its extracted files together.
Choose the original Gorilla EXE, not an older experimental NewModelFormatter.
No Python or Blender installation is required. The original EXE is unchanged.
Existing output EXEs are never overwritten; use a fresh installer folder.

CONVERT

Keep each wrestler's BaseModel, attire, Materials and Textures folders together.
Use your usual source folder, CakeView workflow and a new empty output folder.
To audit an already-ported 2K26 model, choose Keep the mod's own folder name.
After conversion click Open conversion report. The log shows its saved path.
Final reports save at the output root and inside the converted mod, with a
Temp fallback when the selected output cannot be written. Conversion failures
also produce reports; forced termination cannot guarantee a completed report.

WHAT 0.12 ADDS

Recognized compact male legacy rigs keep Gorilla's full target bone builder,
custom bones and mapped skin weights. The shorter source rig can pass only
after all written bones, parents, bind matrices and every skin influence are
verified. Missing animation joints or malformed rigs remain unsupported.
Inspect partial_legacy_rig. No extra surface reweighting is forced by this route.

Every recorded output gets eye/teeth geometry, anchor, actual material-binding
and available texture checks. Inspect face_output_audit and face_output_check.
Custom eye colors and tooth atlases are preserved. Unavailable external game
assets stay unverified. These checks do not prove in-game brightness/rendering.

Existing repairs include named local DDS bindings, preserved valid authored
teeth irradiance, strict matching Rey/Bryan mask recovery, BC1 alpha detection,
material case matching and supported existing-data recovery for native2K26.
Original model/texture inputs, Gorilla UI logic, CakeView gate and Gorilla's
YCL translator are retained. Vynx/PWM surface math and comparison formatter
material handling are used where supported; the full Blender pipeline is not
active. Attribution is retained in the app and source package.

REMAINING LIMITS

Unreadable or unavailable hide-mask data is not replaced with an invented mask.
Flip's intact original mask is still needed. General clipping, beard, belt,
blood, eye and tooth appearance need entrance/gameplay checks. No universal
visual repair is claimed. Billie YCL translates, but WDF/YWA companion
conversion remains unsupported; moving hair/cloth still needs a game check.
Unsupported older material layouts remain explicit problems. Bryan's reported
loading crash has not been reproduced or established fixed.

VALIDATION

242 regression tests pass. The exact final payloads passed Wine/native DLL
checks for the supplied models, Rey gear/masks, Billie YCL, face checks, reports
and UI. Binary patch reconstruction and ZIP CRCs passed. The Windows PowerShell
installer and in-game appearance have not been executed/tested here.

Accepted original Gorilla EXE SHA-256:
ece4729f2ac3fc707c69550d4a79df7866c11a61463d8eb529ae927e04f377f2

Optional Windows PowerShell command:
.\Apply-FormatterPatch.ps1 -OriginalExe "C:\path\Gorilla Model Formatter.exe"
The optional -OutputExe selects another NEW output filename.
