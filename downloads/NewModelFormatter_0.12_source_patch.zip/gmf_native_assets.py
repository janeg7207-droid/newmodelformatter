"""Recover local native dependencies by exact names/hashes, never templates."""
import hashlib
import os
from pathlib import Path
import struct
import tempfile
from gmf_2k26_repair import _safe_name, path_hash, read_native_library, _STUB
from gmf_jmtl_audit import inspect_material


def virtual_file(path):
    parts=Path(path).parts
    for i,part in enumerate(parts):
        if part.casefold()=='characters':return '/'.join(('Characters',*parts[i+1:]))
    return None


def atomic_bytes(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    handle,name=tempfile.mkstemp(prefix='.native-repair-',suffix=path.suffix,dir=path.parent)
    stage=Path(name)
    try:
        with os.fdopen(handle,'wb') as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        if stage.read_bytes()!=data:raise ValueError('staged dependency differs from source')
        os.replace(stage,path)
    finally:
        if stage.exists():stage.unlink()


class AssetIndex:
    def __init__(self,source,output):
        self.source=Path(source).resolve();self.output=Path(output).resolve()
        self.by_hash={'material':{},'texture':{}};self.repairs=[]
        self.by_path={}
        for path in sorted(self.source.rglob('*')):
            if not path.is_file() or path.suffix.lower() not in ('.jmtl','.dds','.tex'):continue
            if not path.resolve().is_relative_to(self.source):continue
            target=self.output/path.relative_to(self.source);virtual=virtual_file(target)
            if virtual is None:continue
            kind='material' if path.suffix.lower()=='.jmtl' else 'texture'
            key=path_hash(str(Path(virtual).with_suffix('.tex')) if kind=='texture' else virtual)
            self.by_hash[kind].setdefault(key,[]).append(path)
            self.by_path.setdefault(str(path.parent).casefold(),{}).setdefault(path.name.casefold(),[]).append(path)

    def local_material(self,model,name):
        folder=str(Path(model).parent/'Materials').casefold()
        return self.by_path.get(folder,{}).get((name+'.jmtl').casefold(),[])

    def target(self,path):
        target=self.output/Path(path).relative_to(self.source)
        return self.safe_target(target)

    def safe_target(self,path):
        path=Path(path)
        resolved=path.resolve()
        if not resolved.is_relative_to(self.output) or resolved.is_relative_to(self.source):
            raise ValueError('native dependency output leaves the separate output folder')
        return path

    def copy(self,source,target=None):
        source=Path(source)
        if not source.resolve().is_relative_to(self.source):raise ValueError('native dependency source is outside selected folder')
        target=self.target(source) if target is None else self.safe_target(target)
        data=source.read_bytes()
        if not data:raise ValueError('native dependency is empty: '+source.name)
        if target.is_file() and target.read_bytes()==data:return None
        before=hashlib.sha256(data).hexdigest();atomic_bytes(target,data)
        if source.read_bytes()!=data:raise ValueError('native dependency source changed during recovery')
        repair={'kind':'restore_available_native_asset','source':str(source),'output':str(target),
                'sha256':before,'bytes':len(data),'byte_identical':True}
        self.repairs.append(repair)
        return repair


def write_library(entries):
    """Serialize the exact supported v6 stub format, preserving entry order."""
    names=[_safe_name(e['name']) for e in entries]
    if len({n.casefold() for n in names})!=len(names):raise ValueError('material definitions collide by case')
    strings=bytearray();offsets=[]
    for name in names:
        if len(strings)>65535:raise ValueError('material name table exceeds native u16 offsets')
        offsets.append(len(strings));strings.extend(name.encode('utf-8')+b'\0')
    result=bytearray(b'MTLs'+struct.pack('<II',6,len(strings))+strings)
    result.extend(bytes((-len(result))%4));result.extend(struct.pack('<I',len(entries)))
    for entry in entries:result.extend(struct.pack('<Q',entry['path_hash']))
    for offset in offsets:result.extend(struct.pack('<H',offset))
    result.extend(bytes((-len(result))%4));result.extend(_STUB*len(entries))
    data=bytes(result);read_native_library(data)
    return data


def recover_materials(source,target,used,index):
    source,target=Path(source),Path(target);library=target.with_suffix('.mtls')
    original=source.with_suffix('.mtls')
    result={'format':'native_v6_stub','findings':[],'repairs':[],'materials':[],'complete':True}
    if original.is_file() and not library.is_file():
        copied=index.copy(original,library)
        if copied:result['repairs'].append(copied)
    data=library.read_bytes() if library.is_file() else None
    try:entries=[] if data is None else read_native_library(data)
    except (ValueError,struct.error) as error:
        result.update(format='unsupported_or_inline_layout',complete=False)
        result['findings'].append({'category':'material_table','state':'layout_unverified',
            'file':str(original),'reason':str(error),'action':'preserved; unsupported layout was not rewritten'})
        return result
    planned=[{'name':e['name'],'path_hash':e['path_hash']} for e in entries]
    buckets={}
    for i,entry in enumerate(planned):buckets.setdefault(entry['name'].casefold(),[]).append(i)
    requested=sorted({_safe_name(n) for n in used if n!='lambert1'})
    if any(len(v)>1 for v in buckets.values()) or len({n.casefold() for n in requested})!=len(requested):
        result['complete']=False
        result['findings'].append({'category':'material_table','state':'ambiguous_definitions','action':'preserved; case collision not guessed'})
        return result
    unresolved=False
    for name in requested:
        positions=buckets.get(name.casefold(),[]);entry=planned[positions[0]] if positions else None
        candidates=index.local_material(source,name)
        if not candidates and entry is not None:candidates=index.by_hash['material'].get(entry['path_hash'],[])
        expected=target.parent/'Materials'/(name+'.jmtl')
        if len(candidates)!=1:
            state='ambiguous_jmtl' if candidates else ('unresolved_external_or_missing_jmtl' if entry is not None else 'missing_material_definition')
            result['findings'].append({'category':'material','state':state,'binding':name,
                'expected_file':str(expected),'path_hash':None if entry is None else entry['path_hash'],
                'action':'provide the referenced JMTL or verify its game-asset reference; no shader generated'})
            unresolved=True;continue
        material=candidates[0]
        try:metadata=inspect_material(material.read_bytes())
        except ValueError as error:
            result['findings'].append({'category':'material','state':'invalid_jmtl','binding':name,'file':str(material),'reason':str(error)})
            unresolved=True;continue
        filename=_safe_name(material.name);jmtl=index.safe_target(target.parent/'Materials'/filename)
        copied=index.copy(material,jmtl)
        if copied:result['repairs'].append(copied)
        new_hash=path_hash(virtual_file(jmtl))
        if entry is None:
            buckets[name.casefold()]=[len(planned)];planned.append({'name':name,'path_hash':new_hash})
        else:
            if entry['name']!=name and (not entry['name'].isascii() or not name.isascii()):
                result['findings'].append({'category':'material','state':'unsupported_unicode_alias','binding':name});unresolved=True;continue
            entry.update(name=name,path_hash=new_hash)
        result['materials'].append({'binding':name,'source':str(material),'output':str(jmtl),**metadata})
    # Preserve/audit unused table references too: the runtime still loads this
    # table, and an unused entry must not disappear during reconstruction.
    required={n.casefold() for n in requested}
    for entry in planned:
        if entry['name'].casefold() in required:continue
        name=entry['name'];candidates=index.local_material(source,name)
        if not candidates:candidates=index.by_hash['material'].get(entry['path_hash'],[])
        if len(candidates)!=1:
            result['findings'].append({'category':'material','state':'unused_material_reference_unverified',
                'binding':name,'path_hash':entry['path_hash'],'used_by_mesh':False})
            unresolved=True;continue
        material=candidates[0]
        try:metadata=inspect_material(material.read_bytes())
        except ValueError as error:
            result['findings'].append({'category':'material','state':'invalid_jmtl','binding':name,'file':str(material),'reason':str(error)})
            unresolved=True;continue
        jmtl=index.safe_target(target.parent/'Materials'/_safe_name(material.name))
        copied=index.copy(material,jmtl)
        if copied:result['repairs'].append(copied)
        entry['path_hash']=path_hash(virtual_file(jmtl))
        result['materials'].append({'binding':name,'source':str(material),'output':str(jmtl),'used_by_mesh':False,**metadata})
    if data is None and unresolved:
        result['findings'].append({'category':'material_table','state':'missing_mtls','expected_file':str(library),
            'action':'cannot reconstruct a complete table without its required material definitions'})
    elif planned or data is not None:
        changed=write_library(planned)
        if changed!=data:
            index.safe_target(library);atomic_bytes(library,changed)
            result['repairs'].append({'kind':'rebuild_missing_native_mtls' if data is None else 'repair_native_material_table',
                'output':str(library),'material_count':len(planned),'sha256':hashlib.sha256(changed).hexdigest(),
                'shader_payloads':'preserved; existing validated JMTLs only'})
    result['complete']=not unresolved
    return result


def recover_textures(materials,index):
    results=[]
    for material in materials:
        for reference in material['texture_references']:
            value=reference['hash'];matches=index.by_hash['texture'].get(value,[])
            item={'material':material['binding'],'jmtl':material['output'],**reference}
            if not matches:
                item.update(state='unresolved_external_or_missing_texture',
                            action='verify this hash in game assets or provide its original texture; texture not synthesized')
            elif len(matches)>1:
                # DDS and baked TEX may both be present for the same key. Keep
                # both exact assets; duplicate same-extension paths are ambiguous.
                suffixes=[p.suffix.lower() for p in matches]
                if len(set(suffixes))!=len(suffixes):
                    item.update(state='ambiguous_texture_hash');results.append(item);continue
                item.update(state='present_or_recovered',files=[])
                for path in matches:
                    data=path.read_bytes()
                    if not data or (path.suffix.lower()=='.dds' and (len(data)<128 or data[:4]!=b'DDS ')):
                        item.update(state='invalid_texture');continue
                    repair=index.copy(path)
                    item['files'].append({'source':str(path),'output':str(index.target(path)),'recovered':repair is not None})
            else:
                path=matches[0];data=path.read_bytes()
                if not data or (path.suffix.lower()=='.dds' and (len(data)<128 or data[:4]!=b'DDS ')):
                    item.update(state='invalid_texture',file=str(path))
                else:
                    repair=index.copy(path)
                    item.update(state='present_or_recovered',files=[{'source':str(path),'output':str(index.target(path)),'recovered':repair is not None}])
            results.append(item)
    return results
