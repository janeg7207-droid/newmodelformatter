import hashlib
import json
import marshal
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest
from unittest import mock

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import gmf_ycl_repair as repair


def original_ycl():
    package=types.ModuleType('_original_ycl_fixture');package.__path__=[]
    own=types.ModuleType(package.__name__+'.ycl_own');own.__package__=package.__name__
    ycl=types.ModuleType(package.__name__+'.ycl');ycl.__package__=package.__name__
    root=Path(__file__).parent/'fixtures'
    exec(marshal.loads((root/'gmf.ycl_own.marshal').read_bytes()),own.__dict__)
    package.ycl_own=own
    with mock.patch.dict(sys.modules,{package.__name__:package,own.__name__:own}):
        exec(marshal.loads((root/'gmf.ycl.marshal').read_bytes()),ycl.__dict__)
    return ycl


def sample_ycl():
    # Real kind-3 structural growth through the inspected original converter.
    node=struct.pack('<III',3,96,96)+bytes(84)
    return struct.pack('<4I2H3I',0,32,32+len(node),1,1,25,0xffffffff,0,0)+node


class YclRepairTests(unittest.TestCase):
    def test_checked_translation_uses_original_converter_and_parses_target_tree(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'in.ycl';dst=root/'out.ycl';data=sample_ycl();src.write_bytes(data)
            module=types.SimpleNamespace(ycl=original_ycl())
            result=repair.checked_translation(module,src,dst)
            self.assertEqual(src.read_bytes(),data)
            self.assertEqual(len(dst.read_bytes()),len(data)+16)
            self.assertEqual(struct.unpack_from('<HH',dst.read_bytes(),16),(1,26))
            self.assertTrue(result['target_tree_parsed']);self.assertIsNone(result['stable_2k26_roundtrip']);self.assertTrue(result['original_gorilla_translator'])

    def test_unreadable_source_retains_existing_output_and_removes_staging_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'in.ycl';dst=root/'out.ycl';src.write_bytes(b'bad');dst.write_bytes(b'original output')
            with self.assertRaisesRegex(ValueError,'readable'):repair.checked_translation(types.SimpleNamespace(ycl=original_ycl()),src,dst)
            self.assertEqual(dst.read_bytes(),b'original output');self.assertEqual(src.read_bytes(),b'bad')
            self.assertFalse(list(root.glob('.ycl-convert-*')))

    def test_output_must_not_alias_input(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'file.ycl';p.write_bytes(sample_ycl())
            with self.assertRaisesRegex(ValueError,'replace its input'):repair.checked_translation(types.SimpleNamespace(ycl=original_ycl()),p,p)

    def folder(self,source,destination,carry=None,mapped=None):
        ycl=original_ycl()
        if carry is not None:ycl.carry=carry
        def convert_folder(src,dst,log=print,copy_other=True,slot=None):
            rel='873_Attire.ycl'
            warning=rel+': hair/cloth physics not converted (this attire also has cloth data (.wdf) that is not converted yet) - they will not swing'
            return {'source':src,'output':dst,'problems':[warning],'warnings':[warning],
                    'physics_converted':[],'left_out':[rel+' (2K25 physics file: this attire also has cloth data (.wdf) that is not converted yet)','873_Attire.wdf (2K25 physics data)']}
        return types.SimpleNamespace(convert_folder=convert_folder,ycl=ycl,
            _mapped=mapped or (lambda rel,plan:rel),_slot_plan=lambda src,slot:({}, {}, []))

    def test_folder_converts_ycl_despite_companion_and_keeps_companion_omission(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'input';dst=root/'output';src.mkdir();dst.mkdir()
            (src/'873_Attire.ycl').write_bytes(sample_ycl());(src/'873_Attire.wdf').write_bytes(b'unsupported physics'*30)
            mod=self.folder(src,dst);repair.install(mod)
            result=mod.convert_folder(str(src),str(dst),log=lambda _:None,copy_other=False)
            self.assertTrue((dst/'873_Attire.ycl').is_file());self.assertFalse((dst/'873_Attire.wdf').exists())
            self.assertEqual(result['warnings'],[]);self.assertEqual(result['left_out'],['873_Attire.wdf (2K25 physics data)'])
            self.assertEqual(len(result['physics_converted']),1);self.assertEqual(result['conversion_completeness'],'incomplete')
            self.assertIn('companion conversion is incomplete',result['problems'][0])
            saved=json.loads((dst/'input - conversion report.json').read_text());self.assertEqual(saved,result)

    def test_failed_translation_does_not_remove_original_skip_or_copy_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'input';dst=root/'output';src.mkdir();dst.mkdir()
            (src/'873_Attire.ycl').write_bytes(sample_ycl());(src/'873_Attire.wdf').write_bytes(b'unsupported')
            mod=self.folder(src,dst,carry=lambda *args:(None,'rejected source layout'));repair.install(mod)
            result=mod.convert_folder(str(src),str(dst),log=lambda _:None)
            self.assertTrue(result['warnings']);self.assertFalse((dst/'873_Attire.ycl').exists())
            self.assertEqual(result['physics_converted'],[]);self.assertIn('rejected source layout',result['problems'][-1])

    def test_mapped_away_attire_stays_omitted(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'input';dst=root/'output';src.mkdir();dst.mkdir()
            (src/'873_Attire.ycl').write_bytes(sample_ycl());(src/'873_Attire.wdf').write_bytes(b'unsupported')
            mod=self.folder(src,dst,mapped=lambda *args:None);repair.install(mod)
            result=mod.convert_folder(str(src),str(dst),log=lambda _:None,slot='999_Test')
            self.assertEqual(result['physics_converted'],[]);self.assertFalse((dst/'873_Attire.ycl').exists())

    def test_source_output_overlap_is_rejected_before_original_loop(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);mod=self.folder(root,root)
            mod.convert_folder=mock.Mock(side_effect=AssertionError('must not run original'))
            # An explicit signature models the actual original entrypoint.
            original=mod.convert_folder
            def convert_folder(src,dst,log=print,copy_other=True,slot=None):return original(src,dst)
            mod.convert_folder=convert_folder;repair.install(mod)
            with self.assertRaisesRegex(ValueError,'separate'):mod.convert_folder(str(root),str(root/'out'))
            original.assert_not_called()
