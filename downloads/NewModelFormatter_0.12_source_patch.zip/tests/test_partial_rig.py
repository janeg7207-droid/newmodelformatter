import copy
from pathlib import Path
import sys
import tempfile
import threading
import types
import unittest

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import gmf_partial_rig as patch


def fixture():
    names=['J_Root',*sorted(patch.CORE_NAMES-{'J_Root'})]
    names += ['H_Test_'+str(i) for i in range(175-len(names))]
    bones=[types.SimpleNamespace(name=n,parent=None if n=='J_Root' else 'J_Root',world=np.eye(4,dtype=np.float32)) for n in names]
    ref=types.SimpleNamespace(set26=set(names),new26=set(),variants={'male':types.SimpleNamespace(names=names,
        bones=[(b.name,b.parent,b.world.copy(),b.world.copy()) for b in bones])})
    source=types.SimpleNamespace(version=41,bones=copy.deepcopy(bones[:130]),meshes=[types.SimpleNamespace(
        name='M_Body',num_verts=2,weights={'J_Root':np.array([.8,.2]),'J_Hips':np.array([.2,.8])})])
    source.bone_names=lambda:[b.name for b in source.bones]
    skeleton=types.SimpleNamespace(pick_variant=lambda bones,ref:('male',0.),
        convert_bones=lambda bones,ref,variant:(copy.deepcopy(fixture_bones),{},{}))
    fixture_bones=bones
    return source,ref,skeleton,bones


class PartialRigSourceTests(unittest.TestCase):
    def test_recognized_core_fills_missing_helpers_with_original_builder(self):
        source,ref,skeleton,bones=fixture();plan=patch.source_plan(source,ref,skeleton)
        self.assertEqual(len(plan['expected_bones']),175)
        self.assertEqual(len(plan['missing_source_standard_bones']),45)
        self.assertEqual(plan['core_pose_maximum_error'],0.)
    def test_missing_animation_joint_is_rejected(self):
        source,ref,skeleton,bones=fixture();source.bones=[b for b in source.bones if b.name!='J_Knee_L']
        with self.assertRaisesRegex(ValueError,'core is incomplete'):patch.source_plan(source,ref,skeleton)
    def test_changed_core_pose_and_hierarchy_are_rejected(self):
        source,ref,skeleton,bones=fixture();source.bones[1].world[0,3]=1.
        with self.assertRaisesRegex(ValueError,'bind pose differs'):patch.source_plan(source,ref,skeleton)
        source,ref,skeleton,bones=fixture();next(b for b in source.bones if b.name=='J_Knee_L').parent='J_Head'
        with self.assertRaisesRegex(ValueError,'animation parent differs'):patch.source_plan(source,ref,skeleton)
    def test_nontrivial_rotation_or_scale_is_not_treated_as_translation_tolerance(self):
        source,ref,skeleton,bones=fixture();source.bones[1].world[0,0]=1.01
        with self.assertRaisesRegex(ValueError,'rotation or scale differs'):patch.source_plan(source,ref,skeleton)
    def test_malformed_bone_matrix_and_parent_cycle_are_rejected(self):
        source,ref,skeleton,bones=fixture();source.bones[1].world[0,0]=np.nan
        with self.assertRaisesRegex(ValueError,'invalid bind matrix'):patch.source_plan(source,ref,skeleton)
        source,ref,skeleton,bones=fixture();source.bones[0].parent=source.bones[1].name
        with self.assertRaisesRegex(ValueError,'parent cycle'):patch.source_plan(source,ref,skeleton)
    def test_unknown_unweighted_and_nonfinite_weights_are_rejected(self):
        for weights,reason in [({'unknown':[1.,1.]},'absent'),({'J_Root':[0.,1.]},'unweighted'),({'J_Root':[np.nan,1.]},'invalid')]:
            source,ref,skeleton,bones=fixture();source.meshes[0].weights=weights
            with self.assertRaisesRegex(ValueError,reason):patch.source_plan(source,ref,skeleton)
    def test_native26_and_conflicting_variant_cannot_be_admitted(self):
        source,ref,skeleton,bones=fixture();source.version=47
        with self.assertRaisesRegex(ValueError,'legacy'):patch.source_plan(source,ref,skeleton)
        source.version=41
        with self.assertRaisesRegex(ValueError,'variants differ'):patch.source_plan(source,ref,skeleton,'female')
    def test_untested_female_and_large_variants_are_rejected(self):
        for variant in ('female','large'):
            source,ref,skeleton,bones=fixture();skeleton.pick_variant=lambda bones,ref:(variant,0.)
            with self.assertRaisesRegex(ValueError,'male reference only'):patch.source_plan(source,ref,skeleton)
    def test_weighted_detached_custom_root_is_rejected(self):
        source,ref,skeleton,bones=fixture()
        source.bones.append(types.SimpleNamespace(name='J_CustomDetached',parent=None,world=np.eye(4)))
        source.meshes[0].weights={'J_CustomDetached':np.array([1.,1.])}
        with self.assertRaisesRegex(ValueError,'no animation-core ancestor'):patch.source_plan(source,ref,skeleton)


class PartialRigTargetTests(unittest.TestCase):
    def test_all_custom_bones_and_their_poses_are_verified(self):
        source,ref,skeleton,bones=fixture();plan=patch.source_plan(source,ref,skeleton)
        extra=types.SimpleNamespace(name='J_Hair_11',parent='J_Head',world=np.eye(4,dtype=np.float32))
        plan['expected_bones'].append(extra)
        target=types.SimpleNamespace(bones=copy.deepcopy(plan['expected_bones']))
        self.assertEqual(patch.verify_written_rig(target,plan,ref)['custom_bones_retained'],1)
        target.bones[-1].world[0,3]=.02
        with self.assertRaisesRegex(ValueError,'matrix changed'):patch.verify_written_rig(target,plan,ref)
    def test_changed_order_missing_bone_and_changed_parent_are_rejected(self):
        source,ref,skeleton,bones=fixture();plan=patch.source_plan(source,ref,skeleton)
        for action,reason in [(lambda b:b.reverse(),'order'),(lambda b:b.pop(),'order'),(lambda b:setattr(b[-1],'parent','J_Head'),'parent changed')]:
            target=types.SimpleNamespace(bones=copy.deepcopy(plan['expected_bones']));action(target.bones)
            with self.assertRaisesRegex(ValueError,reason):patch.verify_written_rig(target,plan,ref)
    def test_post_conversion_unmapped_weighted_helper_is_rejected(self):
        source,ref,skeleton,bones=fixture()
        mesh=types.SimpleNamespace(name='M_Body',num_verts=1,weights={'removed_helper':np.array([1.])})
        with self.assertRaisesRegex(ValueError,'weighted bone is absent'):
            patch.packed_expected(mesh,bones,types.SimpleNamespace())


class PartialRigInstallTests(unittest.TestCase):
    def run_case(self,original_problems=None,corrupt_weight=False,change_source=False,capture_failure=False):
        source,ref,skeleton,bones=fixture()
        with tempfile.TemporaryDirectory() as temp:
            src=Path(temp)/'baseModel.mcd';dst=Path(temp)/'target.mcd';src.write_bytes(b'original source')
            target=types.SimpleNamespace(version=47,bones=copy.deepcopy(bones),meshes=[])
            def read_model(path):return copy.deepcopy(source if Path(path)==src else target)
            def pack_weights(mesh,index):
                names=list(mesh.weights);weights=np.zeros((mesh.num_verts,8),dtype=np.float32);indices=np.zeros((mesh.num_verts,8),dtype=np.int32)
                for i,n in enumerate(names):weights[:,i]=mesh.weights[n];indices[:,i]=index[n]
                return indices.ravel(),weights.ravel(),{'unweighted':0,'dropped_groups':[]}
            vc=types.SimpleNamespace(read_model=read_model,pack_weights=pack_weights,VERSION_2K26=47)
            def convert_weights(mesh,*args,**kwargs):
                if capture_failure:mesh.weights={'J_Unmapped_Helper':np.array([1.,1.])}
                return {'mesh':mesh.name,'verts_changed':0}
            skeleton.convert_weights=convert_weights
            def convert_mcd(src_path,dst_path,ref,body_label=None):
                model=read_model(src_path)
                for mesh in model.meshes:skeleton.convert_weights(mesh,{},ref)
                target.meshes=model.meshes
                if corrupt_weight=='negative':target.meshes[0].weights={'J_Root':np.array([1.2,.2]),'J_Hips':np.array([-.2,.8])}
                elif corrupt_weight:target.meshes[0].weights={'J_Root':np.array([.2,.8]),'J_Hips':np.array([.8,.2])}
                Path(dst_path).write_bytes(b'converted target')
                return {'kind':'base model','source_version':'0x29','unsupported':'original missing helper guard','notes':[]}
            calls=[]
            def verify(src_path,dst_path,ref,attached_dropped=0,variant='male',body_limits=None):
                calls.append((Path(src_path).read_bytes(),variant))
                return not original_problems,list(original_problems or []),{'hide_mask':'unreadable' if original_problems else 'none'}
            module=types.SimpleNamespace(convert_mcd=convert_mcd,verify=verify,vc=vc,rig_family=lambda names,ref:'older')
            patch.install(module,skeleton)
            installed=(module.convert_mcd,module.verify,skeleton.convert_weights)
            patch.install(module,skeleton)
            self.assertEqual(installed,(module.convert_mcd,module.verify,skeleton.convert_weights))
            report=module.convert_mcd(str(src),str(dst),ref)
            if change_source:src.write_bytes(b'changed source')
            result=module.verify(str(src),str(dst),ref)
            return report,result,calls,src.read_bytes()
    def test_valid_target_supersedes_only_missing_source_helper_gate(self):
        report,result,calls,data=self.run_case()
        self.assertTrue(result[0]);self.assertNotIn('unsupported',report);self.assertEqual(len(calls),1)
        self.assertEqual(data,b'original source')
        self.assertEqual(report['partial_legacy_rig']['status'],'target_rig_and_weights_verified')
        self.assertFalse(report['partial_legacy_rig']['new_surface_projection'])
    def test_mask_failure_is_retained_separately_from_verified_rig(self):
        reason='source hide mask is unsupported or unreadable; an empty output does not validate skin hiding'
        report,result,calls,data=self.run_case([reason])
        self.assertFalse(result[0]);self.assertEqual(result[1],[reason]);self.assertNotIn('unsupported',report)
        self.assertEqual(report['partial_legacy_rig']['original_model_verification'],'fail')
    def test_geometry_failure_does_not_relax_original_admission(self):
        report,result,calls,data=self.run_case(['M_Body positions changed'])
        self.assertFalse(result[0]);self.assertIn('unsupported',report)
        self.assertEqual(report['partial_legacy_rig']['admission'],'blocked_by_original_model_verification')
    def test_wrong_normalized_written_weights_are_rejected(self):
        report,result,calls,data=self.run_case(corrupt_weight=True)
        self.assertFalse(result[0]);self.assertIn('unsupported',report)
        self.assertEqual(report['partial_legacy_rig']['status'],'written_verification_failed')
        self.assertIn('differ',result[1][-1])
    def test_negative_written_binding_is_rejected(self):
        report,result,calls,data=self.run_case(corrupt_weight='negative')
        self.assertFalse(result[0]);self.assertIn('invalid',result[1][-1])
    def test_source_change_cannot_be_admitted(self):
        report,result,calls,data=self.run_case(change_source=True)
        self.assertFalse(result[0]);self.assertIn('source changed',result[1][-1])
    def test_capture_failure_preserves_original_write_and_denies_admission(self):
        report,result,calls,data=self.run_case(capture_failure=True)
        self.assertEqual(len(calls),1);self.assertFalse(result[0]);self.assertIn('unsupported',report)
        self.assertEqual(report['partial_legacy_rig']['status'],'written_verification_failed')
        self.assertIn('converted-weight capture failed',result[1][-1])
    def test_pending_context_is_thread_local(self):
        previous=getattr(patch._context,'pending',None);patch._context.pending={'main':'sentinel'}
        found=[]
        def worker():
            found.append(getattr(patch._context,'pending',None))
            patch._context.pending={'worker':'sentinel'}
            found.append(dict(patch._context.pending))
        task=threading.Thread(target=worker);task.start();task.join()
        self.assertEqual(found,[None,{'worker':'sentinel'}]);self.assertEqual(patch._context.pending,{'main':'sentinel'})
        if previous is None:del patch._context.pending
        else:patch._context.pending=previous
    def test_later_failed_read_clears_stale_pending_for_same_target(self):
        with tempfile.TemporaryDirectory() as temp:
            src=Path(temp)/'invalid.mcd';target=Path(temp)/'target.mcd'
            def read(path):raise ValueError('native read failed')
            def convert_mcd(src_path,dst_path,ref):self.fail('a failed read must not reach conversion')
            module=types.SimpleNamespace(convert_mcd=convert_mcd,verify=lambda *a:None,
                vc=types.SimpleNamespace(read_model=read),rig_family=lambda *a:'older')
            skeleton=types.SimpleNamespace(convert_weights=lambda *a:None)
            patch.install(module,skeleton)
            previous=getattr(patch._context,'pending',None);patch._context.pending={patch._path(target):{'stale':True}}
            with self.assertRaisesRegex(ValueError,'native read failed'):module.convert_mcd(str(src),str(target),None)
            self.assertNotIn(patch._path(target),patch._context.pending)
            if previous is None:del patch._context.pending
            else:patch._context.pending=previous


if __name__=='__main__':unittest.main()
