"""Recover a verified existing legacy mask through Gorilla's original writer.

No indices are generated and no unrelated files are searched. A same-stem
readable sidecar, including an intentional empty mask, wins. An embedded
mask wins over the exact-pair profile for the original supplied Bryan mask.
Both fallback sources require this job's verified converted base, unchanged
Body/Head remap and topology, and a complete mask in the actual index domains.
"""
import builtins
import functools
import hashlib
import inspect
import io
import os
from pathlib import Path
import threading
import types

from gmf_mask_recovery import _body_mappings, _domains, _mask_limits
from gmf_supplied_masks import select_profile

PATCH_VERSION = 'verified-existing-and-supplied-legacy-mask-2'
KNOWN_INVALID_SHA256 = '57abd17dd82782bcd4c1509c311d3f70227af707e7975a2e1b3fcbf1eae2c3dd'
KNOWN_INVALID_BYTES = 81408
_context = threading.local()
_CONSUMERS = {'convert_mcd', 'verify', '_sidecar_streams', '_check_mask'}


def _path(path):
    return os.path.normcase(os.path.abspath(os.fspath(path)))


def _character(path):
    return _path(Path(path).parent.parent)


def _fingerprint(path):
    data = Path(path).read_bytes()
    return hashlib.sha256(data).hexdigest(), len(data)


def _functions(function):
    seen = set()
    while isinstance(function, types.FunctionType) and id(function) not in seen:
        seen.add(id(function))
        yield function
        function = getattr(function, '__wrapped__', None)


def _clone(function, namespace, closure=None):
    result = types.FunctionType(function.__code__, namespace, function.__name__,
                                function.__defaults__, function.__closure__ if closure is None else closure)
    result.__kwdefaults__ = function.__kwdefaults__
    result.__dict__.update(function.__dict__)
    return result


def _isolated_consumer(function, expected, cache):
    """Clone consumer globals and captured consumer wrappers, never original globals."""
    if not isinstance(function, types.FunctionType) or function.__code__.co_name not in _CONSUMERS:
        return function
    if id(function) in cache:
        return cache[id(function)]
    namespace = dict(function.__globals__)
    cells = tuple(types.CellType(cell.cell_contents) for cell in function.__closure__ or ())
    clone = _clone(function, namespace, cells if function.__closure__ is not None else None)
    cache[id(function)] = clone
    namespace['expected_mask'] = expected
    for name in ('_sidecar_streams', '_check_mask'):
        dependency = namespace.get(name)
        if isinstance(dependency, types.FunctionType):
            namespace[name] = _isolated_consumer(dependency, expected, cache)
    for cell in cells:
        value = cell.cell_contents
        if isinstance(value, types.FunctionType) and value.__code__.co_name in _CONSUMERS:
            cell.cell_contents = _isolated_consumer(value, expected, cache)
    if isinstance(clone.__dict__.get('__wrapped__'), types.FunctionType):
        clone.__wrapped__ = _isolated_consumer(clone.__wrapped__, expected, cache)
    return clone


def _mappings(model):
    for name in ('M_Body', 'M_Head'):
        if sum(mesh.name == name for mesh in model.meshes) != 1:
            raise ValueError('matching base must have exactly one ' + name)
    mapping = _body_mappings(model)
    for meshes in mapping.values():
        count, remap, triangles = meshes[0]
        if any(index < 0 or index >= count for triangle in triangles for index in triangle):
            raise ValueError('paired base has invalid triangle indices')
    return mapping


def checked_embedded_mask(data, mcd, domains):
    """Reject unknown coverage, LOD maps, names and indices without filtering them."""
    if not mcd.hpl_is_whole(data):
        raise ValueError('embedded HPL is unreadable or incomplete')
    parsed = mcd.parse_hpl(data)
    if 0 not in parsed or not any(ids for groups in parsed[0].values() for name, ids in groups):
        raise ValueError('embedded HPL is empty or has no LOD0')
    if any(groups != parsed[0] for groups in parsed.values()):
        raise ValueError('nonuniform embedded LOD masks require a matching LOD map')
    for groups in parsed[0].values():
        for name, ids in groups:
            if name not in domains or any(int(index) not in domains[name] for index in ids):
                raise ValueError('embedded HPL indices do not fit the actual paired base: ' + name)
    normalized = mcd.build_hpl(parsed[0])
    if not mcd.hpl_is_whole(normalized):
        raise ValueError('original HPL writer did not produce a whole mask')
    written = mcd.parse_hpl(normalized)
    if set(written) != set(range(5)) or any(groups != parsed[0] for groups in written.values()):
        raise ValueError('original HPL writer changed mask flags or indices')
    return normalized


def install(convert_module, folder_module):
    """Install after existing mask recovery; native-preservation routes stay unchanged."""
    if getattr(convert_module, '_embedded_mask_patch', None) == PATCH_VERSION:
        return
    original_expected = convert_module.expected_mask
    parser = list(_functions(original_expected))[-1]
    original_convert = convert_module.convert_mcd
    original_verify = convert_module.verify
    original_folder = folder_module.convert_folder
    vc, mcd, limits = convert_module.vc, convert_module.mcd, convert_module.mask_limits

    def register_base(bound, report):
        job = getattr(_context, 'job', None)
        if job is None or not isinstance(report, dict) or not report.get('kind', '').startswith('base model'):
            return
        src, dst = _path(bound.arguments['src_path']), _path(bound.arguments['dst_path'])
        key = _character(src)
        job['bases'].pop(key, None)
        try:
            if Path(src).parent.name.casefold() != 'basemodel' or Path(src).stem.casefold() != 'basemodel' or src == dst:
                return
            before, after = vc.read_model(src), vc.read_model(dst)
            if before.version not in (40, 41) or after.version != vc.VERSION_2K26:
                return
            mapping = _mappings(before)
            if _mappings(after) != mapping:
                return
            bounds = _mask_limits(limits(before))
            if _mask_limits(limits(after)) != bounds or _mask_limits(report.get('mask_limits', {})) != bounds:
                return
            job['bases'][key] = {'source': src, 'output': dst, 'source_fingerprint': _fingerprint(src),
                'output_fingerprint': _fingerprint(dst), 'mapping': mapping, 'limits': bounds, 'verified': False}
        except Exception:
            return

    def select(current, body_limits):
        job = getattr(_context, 'job', None)
        diagnosis = {'version': PATCH_VERSION, 'state': 'no_verified_embedded_fallback',
            'source_model': current['source'], 'same_stem_sidecar': current['hpl'],
            'matching_source_base': str(Path(current['source']).parent.parent/'BaseModel'/'baseModel.mcd'),
            'coverage_generated': False}
        current['diagnosis'] = diagnosis
        try:
            sidecar_fingerprint = None
            if Path(current['hpl']).is_file():
                fingerprint = _fingerprint(current['hpl'])
                sidecar_fingerprint = fingerprint
                diagnosis.update(sidecar_sha256=fingerprint[0], sidecar_bytes=fingerprint[1])
                if fingerprint == (KNOWN_INVALID_SHA256, KNOWN_INVALID_BYTES):
                    diagnosis.update(state='known_invalid_shared_hpl',
                        reason='previously inspected identical HPL has unavailable mesh names, out-of-domain indices and invalid block framing')
            if job is None:
                return None
            if _fingerprint(current['source']) != current['fingerprint']:
                raise ValueError('source attire changed during conversion')
            previous = job['attires'].get(current['source'])
            if previous is not None and previous != current['fingerprint']:
                raise ValueError('source attire changed after its mask conversion')
            source = vc.read_model(current['source'])
            if source.version not in (40, 41):
                diagnosis['embedded_mask_state'] = 'not_a_legacy_input'
                return None
            streams = [data for tag, data in source.substreams if tag == b'HPL!']
            diagnosis['embedded_mask_count'] = len(streams)
            if len(streams) > 1:
                diagnosis['embedded_mask_state'] = 'ambiguous'
                return None
            if streams:
                diagnosis['embedded_mask_sha256'] = hashlib.sha256(streams[0]).hexdigest()
                diagnosis['embedded_mask_bytes'] = len(streams[0])
            else:
                diagnosis['embedded_mask_state'] = 'absent'
            record = job['bases'].get(_character(current['source']))
            if record is None or not record.get('verified'):
                raise ValueError('matching paired base conversion has not passed verification')
            if body_limits is None or _mask_limits(body_limits) != record['limits']:
                raise ValueError('caller mask bounds do not match the verified paired base')
            if _fingerprint(record['source']) != record['source_fingerprint'] or _fingerprint(record['output']) != record['output_fingerprint']:
                raise ValueError('matching paired base changed after conversion')
            before, after = vc.read_model(record['source']), vc.read_model(record['output'])
            if _mappings(before) != record['mapping'] or _mappings(after) != record['mapping'] or after.version != vc.VERSION_2K26:
                raise ValueError('matching paired base remap or topology changed')
            if _mask_limits(limits(before)) != record['limits'] or _mask_limits(limits(after)) != record['limits']:
                raise ValueError('matching paired base index domain changed')
            domains = _domains(record['mapping'])
            if streams:
                try:
                    data = checked_embedded_mask(streams[0], mcd, domains)
                    diagnosis['embedded_mask_state'] = 'readable_nonempty_indices_valid'
                    return data, record, {'kind': 'embedded',
                        'source_embedded_hpl_sha256': diagnosis['embedded_mask_sha256']}
                except ValueError as error:
                    diagnosis['embedded_mask_state'] = 'not_usable'
                    diagnosis['embedded_mask_error'] = str(error)
            profile = select_profile(current['fingerprint'], record['source_fingerprint'], sidecar_fingerprint)
            if profile is None:
                return None
            data = checked_embedded_mask(profile['data'], mcd, domains)
            return data, record, {'kind': 'supplied', 'profile': profile['profile'],
                'source_supplied_hpl_sha256': profile['supplied_hpl_sha256'],
                'source_supplied_hpl_bytes': profile['supplied_hpl_bytes'],
                'source_invalid_sidecar_sha256': sidecar_fingerprint[0],
                'source_invalid_sidecar_bytes': sidecar_fingerprint[1],
                'supplied_mask_scope': profile['scope']}
        except Exception as error:
            diagnosis['fallback_not_applied_reason'] = str(error)
            return None

    @functools.wraps(original_expected)
    def expected_mask(*args, **kwargs):
        # Precedence includes the exact Rey profile and any valid/empty sidecar.
        result = original_expected(*args, **kwargs)
        if result[1] not in ('none', 'unreadable'):
            return result
        bound = inspect.signature(original_expected).bind(*args, **kwargs)
        bound.apply_defaults()
        current = getattr(_context, 'current', None)
        if current is None or _path(bound.arguments['hpl_path']) != current['hpl']:
            return result
        selected = select(current, bound.arguments['body_limits'])
        if selected is None:
            return result
        data, base, selected_source = selected
        namespace = dict(parser.__globals__)
        real_open = namespace.get('open', builtins.open)

        def virtual_open(path, mode='r', *open_args, **open_kwargs):
            if mode == 'rb' and _path(path) == current['hpl']:
                return io.BytesIO(data)
            return real_open(path, mode, *open_args, **open_kwargs)

        path_proxy = types.SimpleNamespace(**vars(os.path))
        path_proxy.isfile = lambda path: _path(path) == current['hpl'] or os.path.isfile(path)
        namespace['os'] = types.SimpleNamespace(**{**vars(os), 'path': path_proxy})
        namespace['open'] = virtual_open
        recovered = _clone(parser, namespace)(*args, **kwargs)
        if recovered[1] != 'mask' or recovered[2]:
            current['diagnosis']['fallback_not_applied_reason'] = 'original mask filter rejected indices'
            return result
        supplied = selected_source['kind'] == 'supplied'
        current['recovery_key'] = 'supplied_hide_mask_recovery' if supplied else 'embedded_hide_mask_recovery'
        current['recovery'] = {'version': PATCH_VERSION,
            'method': ('verified_original_user_supplied_hpl_through_original_parser_filter_writer' if supplied
                       else 'existing_source_embedded_hpl_through_original_parser_filter_writer'),
            'source_model': current['source'], 'source_model_sha256': current['fingerprint'][0],
            'written_hpl_sha256': hashlib.sha256(data).hexdigest(),
            'paired_source_base': base['source'], 'paired_source_base_sha256': base['source_fingerprint'][0],
            'paired_output_base_sha256': base['output_fingerprint'][0],
            'body_head_remap_and_topology': 'preserved', 'mask_indices': 'all_in_actual_paired_base_domains',
            'original_source_unchanged': _fingerprint(current['source']) == current['fingerprint'],
            'coverage_generated': False, 'in_game_validation': 'required'}
        current['recovery'].update({key: value for key, value in selected_source.items() if key != 'kind'})
        return recovered

    cache = {}
    isolated_convert = _isolated_consumer(original_convert, expected_mask, cache)
    isolated_verify = _isolated_consumer(original_verify, expected_mask, cache)

    def run_scoped(function, args, kwargs):
        bound = inspect.signature(function).bind(*args, **kwargs)
        bound.apply_defaults()
        src = _path(bound.arguments['src_path'])
        previous = getattr(_context, 'current', None)
        current = {'source': src, 'hpl': _path(Path(src).with_suffix('.hpl')), 'fingerprint': _fingerprint(src)}
        _context.current = current
        try:
            return function(*args, **kwargs), current, bound
        finally:
            _context.current = previous

    @functools.wraps(original_convert)
    def convert_mcd(*args, **kwargs):
        report, current, bound = run_scoped(isolated_convert, args, kwargs)
        register_base(bound, report)
        if isinstance(report, dict):
            if current.get('recovery'):
                key = current['recovery_key']
                report[key] = current['recovery']
                message = ('Restored the original user-supplied Bryan hide mask for this exact source pair and exact invalid sidecar; verified paired base indices and topology.' if key == 'supplied_hide_mask_recovery'
                           else 'Restored an existing readable embedded hide mask from this source attire; verified paired base indices and topology.')
                report.setdefault('notes', []).append(message + ' Original files retained; in-game coverage requires checking.')
                job = getattr(_context, 'job', None)
                if job is not None: job['attires'][current['source']] = current['fingerprint']
            elif current.get('diagnosis'):
                report['hide_mask_source_diagnosis'] = current['diagnosis']
                if current['diagnosis']['state'] == 'known_invalid_shared_hpl':
                    report.setdefault('notes', []).append('The sidecar matches previously inspected invalid shared HPL bytes. No verified embedded fallback was available; no hide mask was generated.')
        return report

    @functools.wraps(original_verify)
    def verify(*args, **kwargs):
        bound = inspect.signature(original_verify).bind(*args, **kwargs)
        job = getattr(_context, 'job', None)
        record = job['bases'].get(_character(bound.arguments['src_path'])) if job is not None else None
        paired = record is not None and record['source'] == _path(bound.arguments['src_path']) and record['output'] == _path(bound.arguments['dst_path'])
        if paired: record['verified'] = False
        try:
            result, current, _bound = run_scoped(isolated_verify, args, kwargs)
        except Exception:
            if paired: job['bases'].pop(_character(bound.arguments['src_path']), None)
            raise
        if paired:
            if isinstance(result, tuple) and len(result) == 3 and result[0]: record['verified'] = True
            else: job['bases'].pop(_character(bound.arguments['src_path']), None)
        if isinstance(result, tuple) and len(result) == 3 and isinstance(result[2], dict):
            if current.get('recovery'): result[2][current['recovery_key']] = current['recovery']
            elif current.get('diagnosis'): result[2]['hide_mask_source_diagnosis'] = current['diagnosis']
        return result

    @functools.wraps(original_folder)
    def convert_folder(*args, **kwargs):
        previous_job, previous_current = getattr(_context, 'job', None), getattr(_context, 'current', None)
        _context.job, _context.current = {'bases': {}, 'attires': {}}, None
        try:
            return original_folder(*args, **kwargs)
        finally:
            _context.job, _context.current = previous_job, previous_current

    convert_module.expected_mask = expected_mask
    convert_module.convert_mcd = convert_mcd
    convert_module.verify = verify
    folder_module.convert_folder = convert_folder
    convert_module._embedded_mask_patch = PATCH_VERSION
