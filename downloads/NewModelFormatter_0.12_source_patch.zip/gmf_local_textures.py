"""Bind existing named DDS assets as the supplied comparison workflow does.

Legacy source strings select local DDS files in the Blender importer. Its
exporter then hashes the actual bound image's destination .tex path. This
bounded pass reproduces that binding without changing pixels, shaders or UVs.
An old u64 mismatch is not proof that an external game texture is invalid.
"""
import copy
import hashlib
from pathlib import Path
import struct

from gmf_2k26_repair import path_hash
from gmf_native_assets import atomic_bytes


POLICY = 'comparison_formatter_named_existing_local_dds_binding'
NULL_REFS = (0, 0xffffffffffffffff)
_BLOCK_BYTES = {
    b'DXT1': 8, b'DXT2': 16, b'DXT3': 16, b'DXT4': 16, b'DXT5': 16,
    b'ATI1': 8, b'BC4U': 8, b'BC4S': 8,
    b'ATI2': 16, b'BC5U': 16, b'BC5S': 16,
}
_DXGI_BLOCK_BYTES = {**{i: 8 for i in (70, 71, 72, 79, 80, 81)},
                     **{i: 16 for i in (73, 74, 75, 76, 77, 78, 82, 83, 84,
                                        94, 95, 96, 97, 98, 99)}}


def inspect_dds(data):
    """Validate a single compressed 2D DDS and every declared mip extent.

    Unsupported layouts stay unchanged instead of being treated as confirmed
    local bindings. No texture decoding or game-format conversion occurs.
    """
    if len(data) < 128 or data[:4] != b'DDS ':
        raise ValueError('not a complete DDS header')
    if struct.unpack_from('<I', data, 4)[0] != 124 or struct.unpack_from('<I', data, 76)[0] != 32:
        raise ValueError('DDS header sizes are invalid')
    flags = struct.unpack_from('<I', data, 8)[0]
    height, width = struct.unpack_from('<II', data, 12)
    depth, mips = struct.unpack_from('<II', data, 24)
    caps2 = struct.unpack_from('<I', data, 112)[0]
    # Some supplied, otherwise complete DX10 DDS files omit the redundant
    # CAPS/PIXELFORMAT flag bits. Validate the actual structs and payload
    # instead of rejecting those files on the advisory flags alone.
    if flags & 0x6 != 0x6 or not width or not height or not struct.unpack_from('<I', data, 108)[0] & 0x1000:
        raise ValueError('DDS required dimensions or flags are invalid')
    if depth > 1 or caps2 & 0x20fe00:
        raise ValueError('cube and volume DDS bindings are not supported by this pass')
    if not struct.unpack_from('<I', data, 80)[0] & 4:
        raise ValueError('uncompressed DDS bindings are not supported by this pass')
    fourcc = data[84:88]; start = 128
    block_bytes = _BLOCK_BYTES.get(fourcc)
    format_name = fourcc.decode('latin1')
    if fourcc == b'DX10':
        if len(data) < 148:
            raise ValueError('DX10 DDS extension is truncated')
        format_id, dimension, misc, array_size, _ = struct.unpack_from('<5I', data, 128)
        if dimension != 3 or array_size != 1 or misc & 4:
            raise ValueError('DDS arrays, cubes or non-2D DX10 images are unsupported')
        block_bytes = _DXGI_BLOCK_BYTES.get(format_id)
        format_name = 'DXGI_' + str(format_id); start = 148
    if block_bytes is None:
        raise ValueError('DDS compression format is unsupported: ' + format_name)
    mips = mips or 1
    if mips > max(width, height).bit_length():
        raise ValueError('DDS mip count exceeds its dimensions')
    required = 0
    for level in range(mips):
        w, h = max(1, width >> level), max(1, height >> level)
        required += ((w + 3) // 4) * ((h + 3) // 4) * block_bytes
    if start + required != len(data):
        raise ValueError('DDS payload does not match all declared mip extents')
    return {'width': width, 'height': height, 'mip_count': mips,
            'format': format_name, 'payload_bytes': required,
            'header_and_extents_validated': True}


def _safe_stem(value):
    return (isinstance(value, str) and value not in ('', '.', '..')
            and value[-1] not in ' .'
            and not any(c in value for c in '/\\<>:"|?*')
            and not any(ord(c) < 32 for c in value))


def _virtual_folder(value):
    if not isinstance(value, str):
        raise ValueError('output has no verified game-relative material folder')
    value = value.replace('\\', '/').strip('/')
    parts = value.split('/')
    if (len(parts) < 2 or parts[0].lower() not in ('characters', 'arena', 'props', 'weapons')
            or any(not p or p in ('.', '..') or ':' in p for p in parts)):
        raise ValueError('output game-relative folder is unsafe')
    return value


def bind_named_local_textures(materials, source_library, target_library, *,
                              game_folder, dependency_keys, used_names=None,
                              clean_name=lambda name: name.split(':', 1)[0]):
    """Return cloned materials, binding evidence and explicit unresolved issues.

    ``dependency_keys(material)`` must return the source reference keys actually
    used by the existing shader converter. Missing assets and null references
    remain preserved. Required existing DDS files are copied before returning
    their new hashes, including when generic folder copying is disabled.
    """
    result = []
    for material in materials:
        item = copy.copy(material)
        item.params = dict(material.params)
        if hasattr(material, 'types'):
            item.types = dict(material.types)
        result.append(item)
    evidence, problems = [], []
    source_library, target_library = Path(source_library), Path(target_library)
    source_scope = source_library.parent.resolve()
    output_scope = target_library.parent.resolve()
    textures = source_library.parent / 'Textures'
    if not textures.exists():
        return result, evidence, problems
    if not textures.is_dir() or not textures.resolve().is_relative_to(source_scope):
        return result, evidence, ['local texture binding not completed: source Textures directory leaves the material folder']
    try:
        files = {}
        for path in textures.iterdir():
            if path.suffix.lower() == '.dds':
                files.setdefault(path.name.casefold(), []).append(path)
    except OSError as error:
        return result, evidence, ['local texture binding not completed: ' + str(error)]
    used = set(used_names) if used_names is not None else None
    virtual = None; cache = {}; copied = {}
    for item in result:
        if used is not None and clean_name(item.name) not in used:
            continue
        types = getattr(item, 'types', {})
        for key in sorted(set(dependency_keys(item))):
            if not key.endswith('@ref') or types.get(key) != 7:
                continue
            old = item.params.get(key)
            if not isinstance(old, int) or isinstance(old, bool) or old in NULL_REFS or not 0 < old < 0xffffffffffffffff:
                continue
            name_key = key[:-4]
            name = item.params.get(name_key)
            if types.get(name_key) != 6 or not isinstance(name, str) or not name:
                continue
            context = 'material ' + clean_name(item.name) + ' / ' + key
            if not _safe_stem(name):
                problems.append(context + ': unsafe local texture basename; reference preserved')
                continue
            candidates = files.get((name + '.dds').casefold(), [])
            if not candidates:
                continue  # External/global references were not guessed or replaced.
            if len(candidates) != 1:
                problems.append(context + ': ambiguous local DDS filenames; reference preserved')
                continue
            source = candidates[0]
            try:
                if not source.is_file() or not source.resolve().is_relative_to(source_scope):
                    raise ValueError('source DDS leaves the material folder')
                if (output_scope == source_scope or output_scope.is_relative_to(source_scope)
                        or source_scope.is_relative_to(output_scope)):
                    raise ValueError('local DDS binding requires a separate output folder')
                target = target_library.parent / 'Textures' / source.name
                if not target.resolve().is_relative_to(output_scope) or target.resolve().is_relative_to(source_scope):
                    raise ValueError('output texture path leaves the separate output folder')
                if virtual is None:
                    virtual = _virtual_folder(game_folder(str(target_library.parent)))
                source_key = str(source.resolve())
                if source_key not in cache:
                    data = source.read_bytes(); facts = inspect_dds(data)
                    digest = hashlib.sha256(data).hexdigest()
                    cache[source_key] = data, facts, digest
                data, facts, digest = cache[source_key]
                target_key = str(target.resolve())
                if target_key not in copied:
                    atomic_bytes(target, data)
                    if hashlib.sha256(target.read_bytes()).hexdigest() != digest:
                        raise ValueError('copied DDS bytes failed verification')
                    copied[target_key] = digest
                path = virtual + '/Textures/' + source.with_suffix('.tex').name
                new = path_hash(path)
                item.params[key] = new
                evidence.append({'material': clean_name(item.name), 'field': key,
                    'source_texture_name': name, 'source': str(source), 'output': str(target),
                    'source_sha256': digest, 'output_sha256': digest,
                    'old_hash': old, 'new_hash': new, 'destination_virtual_path': path,
                    'changed': old != new, 'policy': POLICY, 'dds': dict(facts),
                    'old_reference_validity': 'not inferred; actual named local DDS selected',
                    'in_game_validation': 'not_performed'})
            except (OSError, ValueError, struct.error) as error:
                problems.append(context + ': local DDS binding not completed: ' + str(error) + '; reference preserved')
    return result, evidence, problems
