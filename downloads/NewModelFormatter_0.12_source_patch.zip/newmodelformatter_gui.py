"""NewModelFormatter UI built on the original Gorilla window and CakeView gate.

gmf_gui_base is the byte-identical original GUI embedded by the builder.
"""
import tkinter as tk
import os
from pathlib import Path
from gmf_report import last_report_path
import gmf_gui_base as base
from gmf_repair import install, set_gear_policy


class App(base.App):
    def __init__(self, root):
        # Pack the options first so the original expanding log cannot consume
        # all available height and hide the experimental controls.
        options = tk.Frame(root, bg=base.PANEL)
        options.pack(side='bottom', fill='x', padx=20, pady=(0, 10))
        base.VERSION = '0.12 experimental'
        super().__init__(root)
        root.title('NewModelFormatter — experimental')
        root.geometry('880x800')
        root.minsize(760, 720)
        self._gear_enabled = False
        self.gear_option = tk.BooleanVar(root, value=False)
        self._brand_labels(root)
        if getattr(self, 'logo_label', None) is not None:
            self.logo_label.configure(image='', text='NEW', fg=base.TEXT, font=('Segoe UI', 24, 'bold'))
        self.gear_check = tk.Checkbutton(
            options, text='Rey gear: match paired body weights (experimental)',
            variable=self.gear_option, bg=base.PANEL, fg=base.TEXT,
            activebackground=base.PANEL, activeforeground=base.TEXT,
            selectcolor=base.FIELD, font=('Segoe UI', 10))
        self.gear_check.pack(anchor='w', padx=10, pady=(8, 2))
        self.report_button = tk.Button(options, text='Open conversion report',
            command=self.open_report, state='disabled', bg=base.FIELD, fg=base.TEXT,
            activebackground=base.PANEL, activeforeground=base.TEXT,
            font=('Segoe UI', 9))
        self.report_button.pack(anchor='w', padx=10, pady=(2, 4))
        tk.Label(options, text='Applies only to the supplied Rey model. No cloth physics is created.',
                 bg=base.PANEL, fg=base.DIM, font=('Segoe UI', 9)).pack(anchor='w', padx=10)
        tk.Label(options, text='Experimental build • Inspect the report • Entrance/gameplay checks required',
                 bg=base.PANEL, fg=base.AMBER, font=('Segoe UI', 9)).pack(anchor='w', padx=10, pady=(3, 2))
        tk.Label(options, text='Based on Gorilla Model Formatter; model engine: WWE2K_MDL / PWM Mods.',
                 bg=base.PANEL, fg=base.DIM, font=('Segoe UI', 8)).pack(anchor='w', padx=10, pady=(0, 8))
        self.say('NewModelFormatter: material checks and independent Gorilla YCL translation enabled.', 'dim')
        self.say('Already-ported 2K26: missing assets checked; supported repairs and unresolved items recorded.', 'dim')
        # Original main applies its own DPI-scaled dimensions after App returns.
        # Reserve space for the extra controls after that setup completes.
        root.after_idle(self._finish_layout)

    def _finish_layout(self):
        root = self.root
        self.logo_label.configure(image='', text='NEW')
        scale = max(1.0, root.winfo_fpixels('1i') / 96.0)
        root.geometry('%dx%d' % (int(880 * scale), int(800 * scale)))
        root.minsize(int(760 * scale), int(720 * scale))

    @staticmethod
    def _brand_labels(parent):
        for widget in parent.winfo_children():
            if isinstance(widget, tk.Button) and widget.cget('text') in ('Discord', 'Patreon'):
                # Keep attribution below; give the CakeView status enough room.
                widget.pack_forget()
            if isinstance(widget, tk.Label) and widget.cget('text') == 'GORILLA':
                widget.configure(text='NEW')
            if isinstance(widget, tk.Label) and widget.cget('text').replace(' ', '') == '2K25→2K26':
                widget.configure(text='2K24 / 2K25 → 2K26 / repair')
            if isinstance(widget, tk.Label) and widget.cget('text') == '2K25 mod folder':
                widget.configure(text='2K24 / 2K25 / 2K26 folder')
            if isinstance(widget, tk.Label) and widget.cget('text') == 'Pick a 2K25 mod folder to start.':
                widget.configure(text='Pick a 2K24, 2K25 or 2K26 mod folder to start.')
            if isinstance(widget, tk.Label) and widget.cget('text') == 'A new folder. Your 2K25 files are never changed':
                widget.configure(text='A separate output folder. Your original input files are kept.')
            if isinstance(widget, tk.Label) and widget.cget('text').startswith('Hair physics is converted.'):
                widget.configure(text='YCL translation enabled. WDF/YWA companions may still need repair.')
            App._brand_labels(widget)

    def open_report(self):
        path = last_report_path()
        if path and Path(path).is_file():
            try:
                os.startfile(path)
            except OSError:
                try:
                    editor=str(Path(os.environ.get('SystemRoot',r'C:\Windows'))/'notepad.exe')
                    os.spawnv(os.P_NOWAIT,editor,[editor,path])
                except OSError as error:
                    self.say('Could not open report: '+str(error)+'. Saved at: '+path,'warn')

    def start(self, slot=None):
        if self.busy:
            return
        # Tk state is read only on the UI thread, before the inherited worker.
        self._gear_enabled = bool(self.gear_option.get())
        super().start(slot)
        if self.busy:
            self.gear_check.configure(state='disabled')
            self.report_button.configure(state='disabled')

    def work(self, src, dst, slot):
        set_gear_policy(self._gear_enabled, method='surface')
        try:
            super().work(src, dst, slot)
        finally:
            set_gear_policy(False)

    def say(self, text, tag=None):
        if text is None and isinstance(tag, tuple) and len(tag) == 2:
            message, color = tag
            if message == 'Done. All checks passed.':
                tag = ('Structural checks passed. In-game validation is still required.', color)
        super().say(text, tag)

    def finish(self, result):
        super().finish(result)
        if isinstance(result, dict) and result.get('native_2k26_models_preserved'):
            self.say('%d existing 2K26 model(s) preserved and audited; %d material libraries repaired.' %
                     (result['native_2k26_models_preserved'],
                      result.get('native_2k26_material_libraries_repaired', 0)), 'dim')
        self.gear_check.configure(state='normal')
        path = last_report_path()
        self.report_button.configure(state='normal' if path and Path(path).is_file() else 'disabled')
        if path:
            self.say('Conversion report: ' + path, 'dim')


def main():
    install()
    # Preserve the original folder arguments, automation, and DPI setup.
    base.App = App
    return base.main()


if __name__ == '__main__':
    import sys
    sys.exit(main())
