"""Read-only classification of the material layouts the converter can handle.

The original ``mtl25.read_mtls`` returns ``None`` for every non-v3 MTL! block.
That return value does not establish that the file is a 2K26 library. This
reader validates the library envelope and declared v3 extents instead. Native
classification delegates to the existing exact empty-v4-stub validator.

Older block markers are reported as unsupported observations, not as parsed
payloads. This module neither adapts them nor changes input or output bytes.
"""
import hashlib
import struct

from gmf_2k26_repair import read_native_library


PATCH_VERSION = 'bounded-material-library-format-classification-1'


class _Invalid(ValueError):
    pass


class _Ambiguous(ValueError):
    pass


def _align4(value):
    return (value + 3) & ~3


def _cstr(data, offset, context):
    if not 0 <= offset < len(data):
        raise _Invalid(context + ' string offset is outside its table')
    end = data.find(b'\0', offset)
    if end < 0:
        raise _Invalid(context + ' string is not NUL terminated')
    # Match the original inline reader, which decodes legacy strings as latin1.
    return data[offset:end].decode('latin1')


def _envelope(data):
    if len(data) < 16 or data[:4] != b'MTLs':
        raise _Invalid('not a complete MTLs library envelope')
    version, string_bytes = struct.unpack_from('<II', data, 4)
    string_end = 12 + string_bytes
    count_offset = _align4(string_end)
    if count_offset + 4 > len(data):
        raise _Invalid('library string table or count is truncated')
    count = struct.unpack_from('<I', data, count_offset)[0]
    hash_offset = count_offset + 4
    name_offset = hash_offset + count * 8
    blocks_offset = _align4(name_offset + count * 2)
    if blocks_offset > len(data) or count > (len(data) - blocks_offset) // 12:
        raise _Invalid('library material tables or block headers are truncated')
    strings = data[12:string_end]
    names = []
    hashes = []
    for index in range(count):
        offset = struct.unpack_from('<H', data, name_offset + index * 2)[0]
        if offset and (offset >= len(strings) or strings[offset - 1] != 0):
            raise _Invalid('material name offset is not a string boundary')
        name = _cstr(strings, offset, 'material name')
        if not name:
            raise _Invalid('material name is empty')
        names.append(name)
        hashes.append(struct.unpack_from('<Q', data, hash_offset + index * 8)[0])
    if len(set(names)) != len(names):
        raise _Ambiguous('duplicate material names make the library ambiguous')
    return {
        'library_version': version, 'material_count': count,
        'material_names': names, 'material_path_hashes': hashes,
        'blocks_offset': blocks_offset,
    }


def _inline_block(data, start, name):
    """Validate a v3 block using its string and parameter-data byte counts."""
    string_bytes = struct.unpack_from('<I', data, start + 8)[0]
    string_start = start + 12
    string_end = string_start + string_bytes
    head = _align4(string_end)
    if head + 20 > len(data):
        raise _Invalid('inline v3 strings or parameter header are truncated')
    strings = data[string_start:string_end]
    shader = _cstr(strings, 0, 'shader')
    technique = _cstr(strings, len(shader) + 1, 'technique')
    _, _, _, count, data_bytes = struct.unpack_from('<5I', data, head)
    data_start = head + 20
    end = data_start + data_bytes
    # Original v3 stores name offsets, hashes, one type byte per parameter,
    # padding / u64 references, then one four-byte value per parameter.
    types_start = data_start + 8 * count
    types_end = types_start + count
    refs_start = _align4(types_end)
    values_start = end - 4 * count
    if end > len(data) or end % 4 or refs_start > values_start:
        raise _Invalid('inline v3 parameter arrays, values or declared extent are invalid')
    types = data[types_start:types_end]
    if len(types) != count:
        raise _Invalid('inline v3 parameter types are truncated')
    for index, kind in enumerate(types):
        name_offset = struct.unpack_from('<I', data, data_start + 4 * index)[0]
        _cstr(strings, name_offset, 'parameter name')
        value = struct.unpack_from('<I', data, values_start + 4 * index)[0]
        if kind == 6:
            _cstr(strings, value, 'texture name')
        elif kind == 7:
            reference = data_start + value
            if reference < refs_start or reference + 8 > values_start:
                raise _Invalid('inline v3 texture reference points outside the u64 region')
    # The original reader finds the next magic anywhere, even inside strings
    # or parameter values. Such a block cannot safely use that reader.
    if data.find(b'MTL!', start + 4, end) >= 0:
        raise _Ambiguous('interior MTL! marker would split a v3 block in the original reader')
    return {
        'name': name, 'offset': start, 'end': end, 'bytes': end - start,
        'block_version': 3, 'extent_validated': True, 'shader': shader,
        'technique': technique, 'parameter_count': count,
        'parameter_types': sorted(set(types)),
        'uninterpreted_parameter_types': sorted(set(types) - {2, 6, 7}),
    }


def classify_material_library(data):
    """Return serializable format facts without writing or guessing assets.

    ``supported`` means a known reader can consume this bounded layout; it
    does not validate shaders, material bindings, texture resolution or game
    appearance. Only ``safe_as_native`` permits the native preservation path.
    v1/v2 payload structure remains explicitly unvalidated.
    """
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError('material library data must be bytes-like')
    data = bytes(data)
    result = {
        'version': PATCH_VERSION, 'classification': 'malformed',
        'supported': False, 'safe_as_native': False, 'bytes': len(data),
        'sha256': hashlib.sha256(data).hexdigest(), 'blocks': [],
        'observed_block_versions': [], 'envelope_validated': False,
        'payload_extents_validated': False,
        'validation_scope': 'format only; shader, texture and in-game validity not established',
    }
    try:
        result.update(_envelope(data))
        result['envelope_validated'] = True
        try:
            native = read_native_library(data)
        except ValueError:
            native = None
        if native is not None:
            start = result['blocks_offset']
            result.update(
                classification='native_v6_stub', supported=True,
                safe_as_native=True, payload_extents_validated=True,
                observed_block_versions=[4] if native else [],
                blocks=[{'name': entry['name'], 'offset': start + index * 36,
                         'end': start + (index + 1) * 36, 'bytes': 36,
                         'block_version': 4, 'extent_validated': True}
                        for index, entry in enumerate(native)],
                reason='exact native v6 library with empty v4 stubs validated',
            )
            return result
        offset = result['blocks_offset']
        for name in result['material_names']:
            if offset + 12 > len(data) or data[offset:offset + 4] != b'MTL!':
                raise _Invalid('material block header is missing or truncated')
            block_version = struct.unpack_from('<I', data, offset + 4)[0]
            if block_version not in result['observed_block_versions']:
                result['observed_block_versions'].append(block_version)
            if block_version == 3:
                block = _inline_block(data, offset, name)
            elif block_version == 4 and data[offset:offset + 36] == b'MTL!' + struct.pack('<II', 4, 1) + bytes(24):
                block = {'name': name, 'offset': offset, 'end': offset + 36,
                         'bytes': 36, 'block_version': 4, 'extent_validated': True}
            else:
                result['blocks'].append({'name': name, 'offset': offset,
                                         'block_version': block_version,
                                         'extent_validated': False})
                result.update(
                    classification='unsupported_legacy_inline' if block_version in (1, 2) else 'unsupported_block_layout',
                    reason='observed MTL! block v' + str(block_version) +
                           '; its payload layout is not supported or extent-validated',
                )
                return result
            result['blocks'].append(block)
            offset = block['end']
        if offset != len(data):
            raise _Invalid('unaccounted trailing bytes after declared material blocks')
        result['payload_extents_validated'] = True
        if result['observed_block_versions'] == [3] and result['material_count']:
            result.update(classification='supported_inline_v3', supported=True,
                          reason='all inline v3 blocks and declared extents validated')
        elif len(result['observed_block_versions']) > 1:
            raise _Ambiguous('mixed inline and stub blocks do not form a supported library')
        else:
            result.update(classification='unsupported_block_layout',
                          reason='library is not supported inline v3 or exact native v6 stubs')
    except _Ambiguous as error:
        result.update(classification='ambiguous', reason=str(error),
                      supported=False, safe_as_native=False)
    except (_Invalid, struct.error) as error:
        result.update(classification='malformed', reason=str(error),
                      supported=False, safe_as_native=False)
    return result
