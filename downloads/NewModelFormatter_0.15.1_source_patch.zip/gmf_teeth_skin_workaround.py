"""Guarded recreation of the demonstrated body-atlas mouth skin workaround.

Only existing canonical teeth/mouthbag materials proven to use the local body
atlas are recreated with the bundled native skin writer. Source assets, model
bytes, MTLS links and DDS pixels remain unchanged. Appearance is unverified.
"""
import copy
import functools
import hashlib
import inspect
import math
from pathlib import Path
import struct
import threading

from gmf_2k26_repair import game_folder, path_hash, read_native_library
from gmf_jmtl_audit import Table, inspect_material
from gmf_local_textures import inspect_dds
from gmf_native_assets import atomic_bytes


PATCH_VERSION = 'guarded-local-body-atlas-teeth-mouthbag-skin-workaround-2'
ROLES = ('teeth', 'mouthbag')
KNOWN_NATIVE_MODEL_SHA256 = 'a70520caae33e2877260689324d1f0faaf573f578f0ce06492c15dd74a7d4b11'
KNOWN_NATIVE_MODEL_BYTES = 6772748
KNOWN_NATIVE_PASS_REPORT_SHA256 = 'ce8dc2086cef763befa356c77b0ca86e374b4d34ae553ca9cd2b3befa3aa386e'
_UNRELATED_MISSING_JMTL = frozenset(
    "native material library: missing native JMTL for material '" + name + "'"
    for name in ('body', 'eye_l', 'eye_r', 'eyelash', 'head'))
_selection = threading.local()
_NULL = (None, 0, 0xffffffffffffffff)
_GAME_WARNING = ('Body-atlas skin workaround recreates only linked teeth/mouthbag shaders; '
                 'black teeth, lighting and appearance still require an in-game check.')


def set_enabled(enabled):
    """Set this conversion thread's explicit choice; the default is disabled."""
    _selection.enabled = bool(enabled)


def is_enabled():
    return bool(getattr(_selection, 'enabled', False))


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _overlap(a, b):
    return max(a[0], b[0]) < min(a[1], b[1])


def _inspect(data):
    """Bound the two real native schemas, including every present child."""
    if len(data) < 8 or data[4:8] != b'Mate':
        raise ValueError('teeth workaround requires a recognizable native Mate JMTL')
    root = Table(data, struct.unpack_from('<I', data)[0])
    if (root.position % 4 or root.size < 12
            or root.field(1, 2) != root.position + 6
            or root.field(2, 4) != root.position + 8
            or any(off for i, off in enumerate(root.offsets) if i not in (1, 2))):
        raise ValueError('teeth workaround refuses a noncanonical native root')
    shader = root.number(1, '<H', 0)
    if shader not in (0x1a, 0x19):
        raise ValueError('teeth workaround supports only existing teeth 0x1a or skin 0x19')
    payload = root.child(2)
    if payload is None:
        raise ValueError('teeth workaround payload is missing')
    count = 9 if shader == 0x1a else 19
    if any(payload.offsets[count:]):
        raise ValueError('teeth workaround refuses unknown present material fields')
    tables = [root, payload]
    values = {}

    def check_fields(table, schema):
        if table.position % 4:
            raise ValueError('teeth workaround table alignment is invalid')
        if any(table.offsets[len(schema):]):
            raise ValueError('teeth workaround refuses unknown present child fields')
        occupied = []
        result = {}
        for slot, kind in enumerate(schema):
            width = struct.calcsize(kind)
            position = table.field(slot, width)
            if position is None:
                continue
            region = (position, position + width)
            if position % width or any(_overlap(region, other) for other in occupied):
                raise ValueError('teeth workaround material fields overlap or are misaligned')
            occupied.append(region)
            value = table.number(slot, kind)
            if kind == '<f' and not math.isfinite(value):
                raise ValueError('teeth workaround material scalar is nonfinite')
            result[slot] = value
        return result

    if shader == 0x1a:
        schema = ['<Q'] * 5 + ['<f', '<I', '<f', '<f']
        children = {6: ['<B'] * 3}
    else:
        schema = ['<Q'] * 6 + ['<I', '<B', '<B', '<I'] + ['<f'] * 8 + ['<I']
        children = {6: ['<B'] * 3, 9: ['<f'] * 2, 18: ['<f'] * 4}
    fields = check_fields(payload, schema)
    for slot, value in fields.items():
        if shader == 0x19 and slot in (7, 8) and value not in (0, 1):
            raise ValueError('teeth workaround skin bool is invalid')
        if slot not in children:
            values[str(slot)] = value
    for slot, schema in children.items():
        child = payload.child(slot)
        if child is not None:
            tables.append(child)
            values[str(slot)] = {str(k): v for k, v in check_fields(child, schema).items()}
    regions = [((0, 8), 'header')]
    for table in tables:
        vtable = table.position - struct.unpack_from('<i', data, table.position)[0]
        if vtable % 2:
            raise ValueError('teeth workaround vtable is misaligned')
        regions.extend((((table.position, table.position + table.size), 'table'),
                        ((vtable, vtable + struct.unpack_from('<H', data, vtable)[0]), 'vtable')))
    for index, (region, kind) in enumerate(regions):
        for other, other_kind in regions[index + 1:]:
            if _overlap(region, other) and not (kind == other_kind == 'vtable' and region == other):
                raise ValueError('teeth workaround table/vtable regions overlap')
    if any(payload.number(slot, '<Q') not in _NULL for slot in
           ((2, 3, 4) if shader == 0x1a else (2, 3, 4, 5))):
        raise ValueError('teeth workaround refuses additional authored texture maps')
    facts = inspect_material(data)
    refs = {row['field']: row['hash'] for row in facts['texture_references']}
    if set(refs) != {'colorMap@ref', 'nrMap@ref'}:
        raise ValueError('teeth workaround requires exactly existing color and normal references')
    if shader == 0x19 and any(payload.field(slot, 8 if slot in (0, 1) else 4) is None
                             for slot in (0, 1, 6, 9, 15, 18)):
        raise ValueError('teeth workaround skin payload omits a required native field')
    return facts, values, refs


def _safe_file(path, root):
    path, root = Path(path), Path(root)
    current = path
    while True:
        if current.is_symlink():
            raise ValueError('teeth workaround refuses file or directory symlinks')
        if current == current.parent:
            break
        current = current.parent
    if not path.resolve().is_relative_to(root.resolve()) or not path.is_file():
        raise ValueError('teeth workaround asset is missing or outside its selected folder: ' + path.name)
    return path.read_bytes()


def _unique_file(directory, filename):
    directory = Path(directory)
    if directory.is_symlink():
        raise ValueError('teeth workaround refuses asset directory symlinks')
    matches = [p for p in directory.iterdir() if p.name.casefold() == filename.casefold()]
    if len(matches) != 1:
        raise ValueError('teeth workaround requires one unambiguous local ' + filename)
    return matches[0]


def _roots(report, selected_source, selected_output):
    source = Path(report.get('source') or selected_source)
    output = Path(report.get('output') or selected_output)
    roots = [source, output, Path(selected_source), Path(selected_output)]
    for path in roots:
        current = path
        while True:
            if current.is_symlink():
                raise ValueError('teeth workaround refuses source/output root symlinks')
            if current == current.parent:
                break
            current = current.parent
    src, dst, chosen_src, chosen_dst = [p.resolve() for p in roots]
    if (not src.is_relative_to(chosen_src) or not dst.is_relative_to(chosen_dst)
            or chosen_src.is_relative_to(chosen_dst) or chosen_dst.is_relative_to(chosen_src)):
        raise ValueError('teeth workaround requires separate contained source/output folders')
    return source, output


def _native_model(record, path, reader, role='teeth'):
    if reader is None:
        raise ValueError('teeth workaround native model reader is unavailable')
    model = reader.read_model(str(path), with_shapes=False)
    if int(model.version) != 47:
        raise ValueError('teeth workaround requires a successfully read native 2K26 model')
    clean = lambda name: str(name).split(':', 1)[0]
    allowed = ('M_Teeth',) if role == 'teeth' else ('M_MouthBag', 'M_Tongue')
    named = [mesh for mesh in model.meshes if mesh.name in allowed]
    if any(sum(mesh.name == name for mesh in named) > 1 for name in allowed):
        raise ValueError('body-atlas workaround canonical ' + role + ' mesh names are ambiguous')
    bound = [mesh for mesh in model.meshes if any(clean(g[0]) == role for g in mesh.face_groups)]
    if any(mesh.name not in allowed for mesh in bound):
        raise ValueError('body-atlas workaround ' + role + ' material is shared with an unsupported mesh')
    if role == 'teeth' and named and (not bound or named[0] not in bound):
        raise ValueError('teeth workaround M_Teeth does not exclusively bind canonical teeth')
    if not bound:
        return None
    for mesh in bound:
        if int(mesh.num_verts) <= 0 or not mesh.face_groups or any(clean(g[0]) != role for g in mesh.face_groups):
            raise ValueError('body-atlas workaround mesh does not exclusively bind canonical ' + role)
    return [str(mesh.name) for mesh in bound]


def _only_unrelated_material_problems(value):
    return (type(value) is list and bool(value)
            and all(type(problem) is str and problem in _UNRELATED_MISSING_JMTL for problem in value))


def _known_material_only_profile(record, source_bytes, output_bytes):
    """Admit this inspected upload's teeth despite unrelated missing JMTLs.

    The complete attached conversion previously passed this exact native model.
    The partial six-file upload leaves body/eye/head JMTLs unavailable, which
    keeps the overall model marked failed. It does not alter these model bytes.
    This exception never admits another model, geometry error or missing teeth.
    """
    facts = record.get('facts', {})
    weights = record.get('reference_weight_audit', {})
    return (source_bytes == output_bytes and len(output_bytes) == KNOWN_NATIVE_MODEL_BYTES
            and _sha(output_bytes) == KNOWN_NATIVE_MODEL_SHA256
            and record.get('status') == 'preserved_2k26' and record.get('source_version') == 47
            and record.get('verify') == 'fail'
            and _only_unrelated_material_problems(record.get('problems'))
            and type(facts) is dict and facts.get('byte_identical') is True
            and facts.get('source_sha256') == facts.get('output_sha256') == KNOWN_NATIVE_MODEL_SHA256
            and facts.get('mesh_count') == 7 and facts.get('bone_count') == 175
            and type(weights) is dict and weights.get('suspicious_vertices') == 0)


def _metadata(report, material, path, before, after, inspected, facts):
    """Retain provenance while refreshing actual emitted payload facts."""
    target = path.resolve()
    role = facts['role']
    seen = set()
    changed = 0

    def visit(value):
        nonlocal changed
        if not isinstance(value, (dict, list)) or id(value) in seen:
            return
        seen.add(id(value))
        if isinstance(value, list):
            for item in value:
                visit(item)
            return
        recorded = value.get('output') or value.get('file')
        if isinstance(recorded, str) and Path(recorded).resolve() == target:
            prior = ('sha256', 'source_sha256', 'output_sha256', 'byte_identical',
                     'bytes', 'shader_byte', 'texture_references', 'shader_and_texture_values')
            value.setdefault('teeth_skin_workaround_prior_evidence',
                             {k: copy.deepcopy(value[k]) for k in prior if k in value})
            if value.get('source') and 'source_sha256' not in value and value.get('sha256'):
                value['source_sha256'] = value['sha256']
            value['output_sha256'] = _sha(after)
            if 'sha256' in value:
                value['sha256'] = _sha(after)
            if 'bytes' in value:
                value['bytes'] = len(after)
            if 'byte_identical' in value and before != after:
                value['byte_identical'] = False
            if 'shader_byte' in value:
                # The skin schema has no Teeth-only comparison facts. Keep
                # their previous meaning in provenance, never as current data.
                for key in ('face_texture_check', 'texture_resolution',
                            'texture_pair_classification', 'face_shader_validation'):
                    if key in value:
                        value['teeth_skin_workaround_prior_evidence'].setdefault(key, copy.deepcopy(value[key]))
                        del value[key]
                value.update(copy.deepcopy(inspected))
                value['shader_and_texture_values'] = 'body-atlas native skin schema checked; existing local color/normal references preserved'
            value['teeth_skin_workaround'] = copy.deepcopy(facts)
            changed += 1
        for key, item in list(value.items()):
            if key not in ('teeth_skin_workaround', 'teeth_skin_workaround_prior_evidence'):
                visit(item)
    visit(report)
    audit = material.setdefault('written_material_payload_audit', [])
    matching = [item for item in audit if item.get('name') == role]
    item = matching[0] if matching else {'name': role}
    if not matching:
        audit.append(item)
    item.update(copy.deepcopy(inspected), state='payload_inspected', file=str(path), sha256=_sha(after),
                shader_and_texture_values='body-atlas native skin schema checked; existing local color/normal references preserved')
    for row in material.get('materials', []):
        if row.get('name') == role:
            row.setdefault('teeth_skin_workaround_prior_material', copy.deepcopy(row))
            row.update(shader_2k26='0x19', textures=['colorMap@ref', 'nrMap@ref'],
                       teeth_skin_workaround=copy.deepcopy(facts))
    if before != after and 'jmtl_payloads' in material:
        material.setdefault('teeth_skin_workaround_prior_jmtl_payloads', copy.deepcopy(material['jmtl_payloads']))
        material['jmtl_payloads'] = 'guarded body-atlas teeth/mouthbag native skin recreation; other payloads preserved'
    return changed


def process(report, selected_source, selected_output, vcmodel=None, log=lambda text: None, *, writer=None):
    """Apply the explicit workaround only to verified recorded model outputs."""
    summary = {'version': PATCH_VERSION, 'enabled': is_enabled(), 'applied': 0,
               'already_applied': 0, 'refused': 0, 'not_applicable': 0, 'failed_after_write': 0, 'rows': [],
               'source_files_changed': False, 'in_game_validation': 'not_performed',
               'scope': 'canonical teeth/M_Teeth and mouthbag/M_MouthBag or M_Tongue with proven existing local body atlas only'}
    report['teeth_skin_workaround'] = summary
    if not summary['enabled']:
        summary['state'] = 'disabled_no_asset_reads_or_writes'
        return summary
    def warn(message):
        if 'warnings' not in report:
            report['warnings'] = []
        if type(report['warnings']) is list and message not in report['warnings']:
            report['warnings'].append(message)
        try:
            log(message)
        except Exception:
            pass
    try:
        for field in ('models', 'materials'):
            value = report.get(field, [])
            if type(value) is not list or any(type(item) is not dict for item in value):
                raise ValueError('teeth workaround report ' + field + ' metadata is malformed')
        for field in ('warnings', 'problems'):
            if field in report and type(report[field]) is not list:
                raise ValueError('teeth workaround report ' + field + ' metadata is malformed')
        source_root, output_root = _roots(report, selected_source, selected_output)
    except (OSError, ValueError) as error:
        summary.update(state='refused', refused=1)
        summary['rows'].append({'state': 'refused', 'reason': str(error), 'output_file_changes': 'none'})
        warn('Optional teeth skin workaround not applied: ' + str(error))
        return summary
    seen = set()
    owners = {}
    for record in report.get('models', []):
        if record.get('output'):
            key = Path(record['output']).with_suffix('.mtls').resolve()
            owners[key] = owners.get(key, 0) + 1
    for record, role in ((record, role) for record in report.get('models', []) for role in ROLES):
        row = {'output': record.get('output'), 'role': role, 'in_game_validation': 'not_performed'}
        committed = False
        try:
            if record.get('status') in ('failed', 'error', 'skipped'):
                raise ValueError('teeth workaround requires a recorded passed model conversion')
            if not record.get('output') or not record.get('source'):
                raise ValueError('teeth workaround model source/output provenance is missing')
            target, source = Path(record['output']), Path(record['source'])
            if owners.get(target.with_suffix('.mtls').resolve()) != 1:
                raise ValueError('teeth workaround paired material is claimed by multiple model records')
            model_bytes = _safe_file(target, output_root)
            source_bytes = _safe_file(source, source_root)
            material_only_profile = _known_material_only_profile(record, source_bytes, model_bytes)
            if record.get('verify') != 'pass' and not material_only_profile:
                raise ValueError('teeth workaround requires a recorded passed model conversion or its exact inspected material-only profile')
            snapshots = [(target, model_bytes, output_root), (source, source_bytes, source_root)]
            mesh = _native_model(record, target, vcmodel, role)
            if mesh is None:
                row.update(state='not_applicable_no_canonical_' + role + '_binding', output_file_changes='none')
                summary['not_applicable'] += 1; summary['rows'].append(row); continue
            table = target.with_suffix('.mtls'); table_bytes = _safe_file(table, output_root)
            entries = read_native_library(table_bytes)
            matches = [entry for entry in entries if entry['name'].casefold() == role]
            if len(matches) != 1 or matches[0]['name'] != role:
                raise ValueError('body-atlas workaround native MTLS lacks a unique canonical ' + role + ' entry')
            material_path = _unique_file(target.parent / 'Materials', role + '.jmtl')
            virtual = game_folder(table)
            if virtual is None or matches[0]['path_hash'] != path_hash(virtual + '/Materials/' + material_path.name):
                raise ValueError('body-atlas workaround native MTLS does not bind the actual local ' + role + ' JMTL')
            material_rows = [m for m in report.get('materials', []) if m.get('output')
                             and Path(m['output']).resolve() == table.resolve()]
            if len(material_rows) != 1:
                raise ValueError('teeth workaround needs one recorded paired native material table')
            material = material_rows[0]
            if (str(material.get('status', '')).startswith(('failed', 'unsupported'))
                    and not (material_only_profile and material.get('status') == 'unsupported_native_materials'
                             and _only_unrelated_material_problems(material.get('problems')))):
                raise ValueError('teeth workaround paired material conversion failed')
            for field in ('materials', 'written_material_payload_audit'):
                if field in material and (type(material[field]) is not list
                                          or any(type(item) is not dict for item in material[field])):
                    raise ValueError('teeth workaround paired material metadata is malformed')
            before = _safe_file(material_path, output_root)
            inspected_before, original_fields, refs = _inspect(before)
            textures = []
            for filename, field in (('body_color.dds', 'colorMap@ref'), ('body_nrm.dds', 'nrMap@ref')):
                texture = _unique_file(target.parent / 'Textures', filename)
                data = _safe_file(texture, output_root); dds = inspect_dds(data)
                texture_virtual = virtual + '/Textures/' + texture.with_suffix('.tex').name
                if refs[field] != path_hash(texture_virtual):
                    raise ValueError('teeth workaround existing ' + field + ' does not bind the actual local body atlas')
                snapshots.append((texture, data, output_root))
                textures.append({'file': str(texture), 'sha256': _sha(data), 'field': field,
                                 'virtual_path': texture_virtual, 'path_hash': refs[field], **dds})
            snapshots.append((table, table_bytes, output_root))
            # Preserve the known paired source assets too, whenever present.
            for paired in (source.with_suffix('.mtls'), source.parent / 'Materials' / material_path.name,
                           source.parent / 'Textures' / 'body_color.dds', source.parent / 'Textures' / 'body_nrm.dds'):
                if paired.exists() or paired.is_symlink():
                    snapshots.append((paired, _safe_file(paired, source_root), source_root))
            for other_role in ROLES:
                if other_role == role:
                    continue
                other = target.parent / 'Materials' / (other_role + '.jmtl')
                if other.exists() or other.is_symlink():
                    snapshots.append((other, _safe_file(other, output_root), output_root))
            key = material_path.resolve()
            if key in seen:
                raise ValueError('teeth workaround paired material is claimed by multiple model records')
            seen.add(key)
            if inspected_before['shader_byte'] == 0x19:
                after = before
            else:
                if writer is None:
                    from thirdparty.wwe2k_mdl.jmtl_writer import write_jmtl
                    writer = write_jmtl
                after = bytes(writer(0x19, dict(refs)))
            inspected_after, _, after_refs = _inspect(after)
            if inspected_after['shader_byte'] != 0x19 or after_refs != refs:
                raise ValueError('teeth workaround writer did not produce the native skin schema with identical texture references')
            facts = {'version': PATCH_VERSION, 'role': role, 'bound_meshes': mesh, 'state': 'already_applied' if before == after else 'applied_experimental_workaround',
                     'before_sha256': _sha(before), 'after_sha256': _sha(after),
                     'before_shader': inspected_before['shader_byte'], 'after_shader': 0x19,
                     'original_present_fields': original_fields, 'existing_texture_references': refs,
                     'texture_references_unchanged': True, 'texture_pixels_changed': False,
                     'new_skin_parameters': ('existing native skin fields preserved; no rewrite' if before == after else
                         'bundled native writer defaults; old native Teeth parameters are retained as provenance, not reused'),
                     'model_and_mtls_unchanged': True, 'other_materials_unchanged_for_this_role': True, 'source_files_changed': False,
                     'known_material_only_profile': material_only_profile,
                     'known_original_native_pass_report_sha256': KNOWN_NATIVE_PASS_REPORT_SHA256 if material_only_profile else None,
                     'overall_model_verification_unchanged': record.get('verify'),
                     'eligibility_scope': ('exact inspected native model bytes originally passed structural conversion; '
                         'only its linked mouth material is repaired; unrelated missing JMTLs and overall failed verification remain'
                         if material_only_profile else 'recorded passed native model; linked teeth/mouthbag role only'),
                     'in_game_validation': 'not_performed', 'black_teeth_fix_proved': False}
            for path, data, root in snapshots:
                if _safe_file(path, root) != data:
                    raise ValueError('teeth workaround paired asset changed during inspection; output preserved')
            if _safe_file(material_path, output_root) != before:
                raise ValueError('teeth workaround JMTL changed during inspection; output preserved')
            if after != before:
                atomic_bytes(material_path, after); committed = True
            if _safe_file(material_path, output_root) != after:
                raise ValueError('teeth workaround final payload verification failed')
            for path, data, root in snapshots:
                if _safe_file(path, root) != data:
                    raise ValueError('teeth workaround paired asset preservation verification failed')
            facts['metadata_records_updated'] = _metadata(report, material, material_path, before, after, inspected_after, facts)
            row.update(facts, material=str(material_path), local_body_textures=textures,
                       output_file_changes='none' if before == after else 'only ' + role + '.jmtl recreated with native skin schema')
            record.setdefault('body_atlas_skin_workaround', {})[role] = copy.deepcopy(row)
            if role == 'teeth':
                record['teeth_skin_workaround'] = copy.deepcopy(row)
            summary['already_applied' if before == after else 'applied'] += 1
            if _GAME_WARNING not in report.setdefault('warnings', []):
                report['warnings'].append(_GAME_WARNING)
            report['experimental_teeth_skin_game_check'] = True
        except Exception as error:
            row.update(state='written_with_verification_or_reporting_error' if committed else 'refused',
                       reason=str(error),
                       output_file_changes='teeth write committed; final verification/reporting failed' if committed else 'none')
            summary['failed_after_write' if committed else 'refused'] += 1
            message = str(row.get('output') or 'model') + (': optional teeth skin write completed; '
                'final verification/reporting failed: ' if committed else ': optional teeth skin workaround not applied: ') + str(error)
            warn(message)
        summary['rows'].append(row)
    summary['state'] = ('requires_attention_after_write' if summary['failed_after_write'] else
                        'checked_with_refusals' if summary['refused'] else 'checked_with_in_game_validation_required')
    return summary


def install(folder):
    """Wrap after material recovery, before final face auditing and reports."""
    if getattr(folder, '_teeth_skin_workaround_patch', None) == PATCH_VERSION:
        return
    original = folder.convert_folder

    @functools.wraps(original)
    def convert_folder(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs); bound.apply_defaults()
        report = original(*args, **kwargs)
        process(report, bound.arguments['src'], bound.arguments['dst'], getattr(folder, 'vc', None),
                bound.arguments.get('log', lambda text: None))
        from gmf_report import save_intermediate
        save_intermediate(report, bound.arguments['dst'])
        return report
    folder.convert_folder = convert_folder
    folder._teeth_skin_workaround_patch = PATCH_VERSION
