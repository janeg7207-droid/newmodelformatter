"""Apply the user's two ordinary-eye scalars to separate written JMTLs.

This is an explicit output policy, not a claim that two values establish an
in-game eye fix. Known shader 0x12 has only scalar fields and u64 texture hashes.
Existing scalars are patched in place. Omitted scalars use an appended copy of
the complete original Eye object; its old bytes, offsets and padding survive.
"""
import copy
import functools
import hashlib
import inspect
import math
from pathlib import Path
import struct

from gmf_jmtl_audit import Table
from gmf_native_assets import atomic_bytes


PATCH_VERSION = 'user-ordinary-eye-shadow-output-policy-1'
POLICY = {'eyeLidShadowDarkness': 1.0, 'eyeLidShadowFallOff': 0.5}
SLOTS = {'eyeLidShadowDarkness': 12, 'eyeLidShadowFallOff': 13}
PROVENANCE = 'explicit user request and supplied scalar screenshot; not a harvested Cena material default'


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _region(table):
    start = table.position - struct.unpack_from('<i', table.data, table.position)[0]
    return (start, start + struct.unpack_from('<H', table.data, start)[0])


def _overlap(a, b):
    return max(a[0], b[0]) < min(a[1], b[1])


def _bounded_eye(data):
    if len(data) < 8 or data[4:8] != b'Mate':
        raise ValueError('eye policy requires a recognizable Mate JMTL')
    root = Table(data, struct.unpack_from('<I', data, 0)[0])
    # The supplied game-safe root schema is [unused, shader:u16, payload:u32].
    # Reinterpreting unknown root fields or noncanonical writer layouts would
    # exceed this Eye-only policy.
    if (root.position % 4 or root.size < 12 or root.field(1, 2) != root.position + 6
            or root.field(2, 4) != root.position + 8
            or any(root.offsets[i] for i in range(len(root.offsets)) if i not in (1, 2))):
        raise ValueError('eye policy root layout is unsupported')
    shader = root.number(1, '<H', 0)
    if shader != 0x12:
        return root, None
    payload = root.child(2)
    if payload is None or payload.position % 4:
        raise ValueError('eye policy payload alignment is invalid')
    if any(payload.offsets[20:]):
        raise ValueError('eye policy refuses nonzero unknown Eye fields')
    tables = [(root.position, root.position + root.size),
              (payload.position, payload.position + payload.size)]
    vtables = [_region(root), _region(payload)]
    if any(start % 2 for start, end in vtables):
        raise ValueError('eye policy vtable alignment is invalid')
    regions = [(0, 8), *tables, *vtables]
    for i, region in enumerate(regions):
        for other in regions[i + 1:]:
            if _overlap(region, other):
                raise ValueError('eye policy table/vtable regions overlap')
    occupied = []
    for field in range(min(20, len(payload.offsets))):
        width = 8 if field < 4 else (1 if field == 9 else 4)
        position = payload.field(field, width)
        if position is None:
            continue
        if position % width:
            raise ValueError('eye policy field alignment is invalid')
        region = (position, position + width)
        if any(_overlap(region, other) for other in occupied):
            raise ValueError('eye policy fields overlap')
        occupied.append(region)
        if field == 9 and data[position] not in (0, 1):
            raise ValueError('eye policy refraction BOOL is invalid')
        if field >= 4 and field != 9 and not math.isfinite(struct.unpack_from('<f', data, position)[0]):
            raise ValueError('eye policy scalar is not finite')
    return root, payload


def _values(payload):
    return {key: payload.number(slot, '<f') for key, slot in SLOTS.items()}


def _field_bytes(payload):
    fields = {}
    for field in range(min(20, len(payload.offsets))):
        width = 8 if field < 4 else (1 if field == 9 else 4)
        position = payload.field(field, width)
        fields[field] = None if position is None else payload.data[position:position + width]
    # Missing trailing slots are meaningful absences too.
    for field in range(len(fields), 20):
        fields[field] = None
    return fields


def prepare_eye_defaults(data):
    """Return bounded output bytes and exact evidence without changing input."""
    root, payload = _bounded_eye(data)
    if payload is None:
        return data, {'state': 'not_ordinary_eye', 'shader_byte': root.number(1, '<H', 0)}
    before = _values(payload)
    facts = {'version': PATCH_VERSION, 'shader_byte': 0x12, 'policy': dict(POLICY),
             'provenance': PROVENANCE, 'values_before': before, 'source_sha256': _sha(data),
             'texture_references_byte_identical': True, 'other_field_bytes_identical': True,
             'in_game_validation': 'not_performed'}
    if before == POLICY:
        facts.update(state='already_policy_values', output_sha256=_sha(data),
                     values_after=dict(POLICY), changed_original_byte_offsets=[],
                     appended_bytes=0, byte_identical=True)
        return data, facts
    offsets = {key: payload.field(slot, 4) for key, slot in SLOTS.items()}
    missing = [key for key, position in offsets.items() if position is None]
    result = bytearray(data)
    if not missing:
        for key, value in POLICY.items():
            struct.pack_into('<f', result, offsets[key], value)
        state = 'patched_existing_eye_scalars'
        allowed = {offsets[key] + i for key in POLICY for i in range(4)}
    else:
        # Eye fields 0--3 are hashes rather than child pointers, so no relative
        # object references are copied to a different address. The object bytes
        # (including unclaimed padding) and all present field offsets survive.
        new_offsets = list(payload.offsets)
        new_offsets += [0] * (max(14, len(new_offsets)) - len(new_offsets))
        copied = bytearray(data[payload.position:payload.position + payload.size])
        for key in missing:
            copied.extend(bytes((-len(copied)) % 4))
            new_offsets[SLOTS[key]] = len(copied)
            copied.extend(struct.pack('<f', POLICY[key]))
        if len(copied) > 65535 or 4 + 2 * len(new_offsets) > 65535:
            raise ValueError('eye policy appended table exceeds u16 bounds')
        for key, value in POLICY.items():
            struct.pack_into('<f', copied, new_offsets[SLOTS[key]], value)
        result.extend(bytes((-len(result)) % 2))
        vtable_position = len(result)
        result.extend(struct.pack('<HH', 4 + 2 * len(new_offsets), len(copied)))
        result.extend(struct.pack('<' + 'H' * len(new_offsets), *new_offsets))
        # Preserve absolute u64 alignment even when the original table begins
        # at 4 modulo 8. All original offsets remain unchanged.
        result.extend(bytes((payload.position - len(result)) % 8))
        table_position = len(result)
        distance = table_position - vtable_position
        if distance > 0x7fffffff or table_position - root.field(2, 4) > 0xffffffff:
            raise ValueError('eye policy appended pointer exceeds wire bounds')
        struct.pack_into('<i', copied, 0, distance)
        result.extend(copied)
        pointer = root.field(2, 4)
        struct.pack_into('<I', result, pointer, table_position - pointer)
        state = 'appended_missing_eye_scalars'
        allowed = set(range(pointer, pointer + 4))
        facts.update(original_eye_object_preserved_in_file=True,
                     copied_eye_object_padding_preserved=True,
                     original_payload_pointer_offset=pointer,
                     appended_table_position=table_position,
                     added_fields=missing)
    output = bytes(result)
    _, after_payload = _bounded_eye(output)
    before_fields = _field_bytes(payload); after_fields = _field_bytes(after_payload)
    if (_values(after_payload) != POLICY
            or any(before_fields[i] != after_fields[i] for i in range(20) if i not in (12, 13))):
        raise ValueError('eye policy changed a nonpolicy field or failed scalar verification')
    differences = [i for i, (old, new) in enumerate(zip(data, output)) if old != new]
    if not set(differences).issubset(allowed) or len(output) < len(data):
        raise ValueError('eye policy changed unapproved original bytes')
    facts.update(state=state, output_sha256=_sha(output), values_after=_values(after_payload),
                 changed_original_byte_offsets=differences, appended_bytes=len(output) - len(data),
                 byte_identical=False)
    return output, facts


def _safe_path(path, source_root, output_root, selected_source, selected_output):
    if any(Path(value).is_symlink() for value in (source_root, output_root, selected_source, selected_output)):
        raise ValueError('eye policy refuses source/output root symlinks')
    roots = [Path(value).resolve() for value in (source_root, output_root, selected_source, selected_output)]
    src, dst, chosen_src, chosen_dst = roots
    if (not src.is_relative_to(chosen_src) or not dst.is_relative_to(chosen_dst)
            or chosen_src.is_relative_to(chosen_dst) or chosen_dst.is_relative_to(chosen_src)
            or src.is_relative_to(dst) or dst.is_relative_to(src)):
        raise ValueError('eye policy requires separate contained source/output folders')
    if path.is_symlink() or not path.resolve().is_relative_to(dst):
        raise ValueError('eye policy output leaves its folder or is a symlink')
    # Also reject aliases within the output tree; do not replace an aliased
    # directory's eye material even if its final resolved target is contained.
    current = path.parent
    while current != Path(output_root):
        if current.is_symlink():
            raise ValueError('eye policy refuses output directory symlinks')
        if current == current.parent:
            break
        current = current.parent


def _metadata_updates(report, path, facts):
    expected = path.resolve(); seen = set(); updated = 0
    def visit(value):
        nonlocal updated
        if not isinstance(value, (dict, list)) or id(value) in seen:
            return
        seen.add(id(value))
        if isinstance(value, list):
            for item in value: visit(item)
            return
        recorded = value.get('output') or value.get('file')
        matches = False
        if isinstance(recorded, str) and recorded:
            try: matches = Path(recorded).resolve() == expected
            except (OSError, ValueError): pass
        if matches:
            prior_keys = ('sha256', 'source_sha256', 'output_sha256', 'byte_identical', 'bytes')
            if 'eye_scalar_policy_prior_copy_evidence' not in value:
                value['eye_scalar_policy_prior_copy_evidence'] = {
                    key: copy.deepcopy(value[key]) for key in prior_keys if key in value}
            if value.get('source') and 'source_sha256' not in value and value.get('sha256'):
                value['source_sha256'] = value['sha256']
            value['output_sha256'] = facts['output_sha256']
            if 'sha256' in value: value['sha256'] = facts['output_sha256']
            if 'bytes' in value: value['bytes'] = facts['output_bytes']
            if 'byte_identical' in value and not facts['byte_identical']:
                value['byte_identical'] = False
            value['eye_scalar_policy'] = copy.deepcopy(facts)
            updated += 1
        for key, item in list(value.items()):
            if key not in ('eye_scalar_policy_prior_copy_evidence', 'eye_scalar_policy'):
                visit(item)
    visit(report)
    # Native MTLS rows summarize their separately copied JMTLs. That aggregate
    # must stop claiming identical payload bytes when an owned Eye changes,
    # while the independent MTLS/model byte proofs remain intact.
    if not facts['byte_identical']:
        for material in report.get('materials', []):
            if not isinstance(material, dict) or 'jmtl_payloads' not in material:
                continue
            recorded = material.get('output')
            if not isinstance(recorded, str) or not recorded:
                continue
            try: owns = (Path(recorded).parent / 'Materials').resolve() == expected.parent
            except (OSError, ValueError): owns = False
            if owns:
                material.setdefault('eye_scalar_policy_prior_jmtl_payloads', copy.deepcopy(material['jmtl_payloads']))
                material['jmtl_payloads'] = 'explicit ordinary-eye scalar policy applied; all other Eye fields and references preserved'
                applied = material.setdefault('eye_scalar_policy_materials', [])
                if str(path) not in applied: applied.append(str(path))
    return updated


def process(report, selected_source, selected_output, log=lambda text: None):
    """Set policy values on supported, existing output Eye JMTLs only."""
    source_root = Path(report.get('source') or selected_source)
    output_root = Path(report.get('output') or selected_output)
    summary = {'version': PATCH_VERSION, 'policy': dict(POLICY), 'provenance': PROVENANCE,
               'scope': 'supported ordinary-eye shader 0x12 JMTLs already present in the recorded output; missing materials are not synthesized',
               'source_files_changed': False, 'in_game_validation': 'not_performed',
               'changed': 0, 'already_policy_values': 0, 'not_ordinary_eye': 0,
               'failed': 0, 'rows': []}
    # Walking without directory symlink traversal also keeps an unrelated tree
    # from becoming eligible through an alias under the selected destination.
    import os
    paths = []
    for directory, dirs, files in os.walk(output_root, followlinks=False):
        dirs[:] = [name for name in dirs if not (Path(directory) / name).is_symlink()]
        paths.extend(Path(directory) / name for name in files if Path(name).suffix.casefold() == '.jmtl')
    for path in sorted(paths):
        row = {'output': str(path), 'in_game_validation': 'not_performed'}
        try:
            _safe_path(path, source_root, output_root, selected_source, selected_output)
            before = path.read_bytes(); output, facts = prepare_eye_defaults(before)
            if facts['state'] == 'not_ordinary_eye':
                summary['not_ordinary_eye'] += 1
                continue
            source = source_root / path.relative_to(output_root)
            original = None
            if source.is_file():
                if source.is_symlink() or not source.resolve().is_relative_to(source_root.resolve()):
                    raise ValueError('eye policy refuses source material symlinks')
                original = source.read_bytes()
                row.update(source=str(source), original_source_sha256=_sha(original))
            if path.read_bytes() != before:
                raise ValueError('eye output changed during policy preparation; output preserved')
            if original is not None and source.read_bytes() != original:
                raise ValueError('eye source changed during policy preparation; output preserved')
            if output != before:
                atomic_bytes(path, output)
            final = path.read_bytes()
            if final != output or (original is not None and source.read_bytes() != original):
                raise ValueError('eye policy failed final source/output verification')
            facts = {**facts, 'output_bytes': len(final), 'output_sha256_before': _sha(before),
                     'output_sha256': _sha(final), 'source_files_changed': False,
                     'expected_output_bytes_verified': True}
            row.update(facts, source_unchanged=True)
            row['metadata_records_updated'] = _metadata_updates(report, path, facts)
            summary['already_policy_values' if facts['state'] == 'already_policy_values' else 'changed'] += 1
        except (OSError, ValueError, struct.error) as error:
            row.update(state='eye_policy_not_applied', reason=str(error))
            summary['failed'] += 1
            message = str(path.relative_to(output_root)) + ': eye scalar policy not completed: ' + str(error)
            if message not in report.setdefault('problems', []): report['problems'].append(message)
            try: log(message)
            except Exception: pass
        summary['rows'].append(row)
    summary['state'] = 'requires_attention' if summary['failed'] else 'recorded_output_eye_policy'
    report['eye_scalar_policy'] = summary
    return summary


def install(folder):
    """Install after copies/recovery, before final face audit and reports."""
    if getattr(folder, '_eye_scalar_policy_patch', None) == PATCH_VERSION:
        return
    original = folder.convert_folder
    @functools.wraps(original)
    def convert_folder(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs); bound.apply_defaults()
        report = original(*args, **kwargs)
        process(report, bound.arguments['src'], bound.arguments['dst'], bound.arguments.get('log', lambda text: None))
        from gmf_report import save_intermediate
        save_intermediate(report, bound.arguments['dst'])
        return report
    folder.convert_folder = convert_folder
    folder._eye_scalar_policy_patch = PATCH_VERSION
