"""Separate Gorilla YCL translation from unsupported companion conversion.

Keep both original YCL modules unchanged. An unrelated WDF/YWA file must not
prevent translation of a readable YCL. Never declare that translating YCL alone
repairs incompatible companion bindings or in-game motion.
"""
import functools
import hashlib
import inspect
import json
import os
from pathlib import Path
import struct
import tempfile

PATCH_VERSION='independent-gorilla-ycl-translation-3'
PHYSICS_SUFFIXES=('.hair_corr_ywa','.hair_ywa','.other_corr_ywa','.other_ywa','.wdf','.ywa')


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def checked_translation(module, source, target):
    """Stage original carry() output, verify it, then replace only output."""
    source,target=Path(source),Path(target)
    if source.resolve()==target.resolve():raise ValueError('YCL output cannot replace its input')
    before=source.read_bytes()
    target.parent.mkdir(parents=True,exist_ok=True)
    handle,name=tempfile.mkstemp(prefix='.ycl-convert-',suffix='.ycl',dir=target.parent)
    os.close(handle);stage=Path(name)
    try:
        if module.ycl.version(str(source)) == 26:
            stage.write_bytes(before)
            how = 'existing 2K26 YCL preserved'
        else:
            how,why=module.ycl.carry(str(source),str(stage))
            if why is not None:raise ValueError(why)
        data=stage.read_bytes()
        if len(data)<32 or struct.unpack_from('<HH',data,16)!=(1,26):
            raise ValueError('translated YCL is not 2K26')
        if struct.unpack_from('<I',data,8)[0]!=len(data):raise ValueError('translated YCL header size is wrong')
        why=module.ycl.problem(str(source),str(stage))
        if why is not None:raise ValueError(why)
        # The original converter and writer deliberately accept source layouts
        # only. Parse the target using its unchanged structural reader; do not
        # report a target writer round-trip that this engine cannot perform.
        nodes=module.ycl.ycl_own._nodes(data,32,len(data))
        if nodes is None or len(nodes)!=struct.unpack_from('<I',data,12)[0]:
            raise ValueError('translated YCL root node count is wrong')
        if source.read_bytes()!=before:raise ValueError('YCL source changed during translation')
        target_hash=hashlib.sha256(data).hexdigest()
        os.replace(stage,target)
        return {'how':how,'source_bytes':len(before),'output_bytes':len(data),
                'source_sha256':hashlib.sha256(before).hexdigest(),'output_sha256':target_hash,
                'source_version':list(struct.unpack_from('<HH',before,16)),
                'output_version':26,'original_gorilla_translator':True,
                'names_preserved':True,'target_tree_parsed':True,
                'target_root_node_count':len(nodes),'stable_2k26_roundtrip':None,
                'roundtrip_method':'not performed by this source-only translator', 'source_unchanged':True,
                'scope':'YCL format translation; companion compatibility and motion unverified'}
    finally:
        if stage.exists():stage.unlink()


def install(folder_module=None):
    if folder_module is None:
        from gmf import folder as folder_module
    if getattr(folder_module,'_independent_ycl_patch',None)==PATCH_VERSION:return
    original=folder_module.convert_folder

    @functools.wraps(original)
    def convert_folder(*args,**kwargs):
        bound=inspect.signature(original).bind(*args,**kwargs);bound.apply_defaults()
        # The native-2K26 wrapper already checks overlap before any conversion.
        from gmf_2k26_repair import require_separate_output
        source,destination=require_separate_output(bound.arguments['src'],bound.arguments['dst'])
        slot=bound.arguments['slot']
        plan=folder_module._slot_plan(str(source),slot)[1] if slot else {}
        report=original(*args,**kwargs);output=Path(report['output']).resolve()
        handled_unknown=set()
        def unknown_details(paths):
            return {'unknown_companion_suffixes':['.ywa'],
                    'unknown_companion_files':[str(p) for p in paths],
                    'unknown_companion_policy':'format unknown; original blob omitted; no decoder, target tag or compatibility assumption'}
        def record_unknown(paths):
            for path in paths:
                relative_unknown=os.path.relpath(path,source)
                mapped_unknown=folder_module._mapped(relative_unknown,plan)
                if mapped_unknown is None:continue
                handled_unknown.add(str(path))
                entries=report.setdefault('unknown_ywa_companions',[])
                if not any(r.get('source')==str(path) for r in entries):
                    entries.append({'source':str(path),'file':mapped_unknown,
                        'state':'unsupported_unknown_companion_omitted', 'format':'unknown',
                        'decoded':False,'copied_by_ycl_patch':False,'target_tag':None,
                        'in_game_validation':'not_performed'})
        def limitation(relative,companions):
            value=relative+': YCL converted; WDF/YWA companion conversion is incomplete ('+', '.join(p.suffix for p in companions)+'); hair/cloth motion still requires validation'
            if any(p.suffix.lower()=='.ywa' for p in companions):
                value+='; plain .ywa format is unknown and its blob was not decoded or copied'
            if value not in report.setdefault('problems',[]):report['problems'].append(value)
        for source_ycl in sorted(source.rglob('*')):
            if not source_ycl.is_file() or source_ycl.suffix.lower()!='.ycl':continue
            relative=os.path.relpath(source_ycl,source)
            mapped=folder_module._mapped(relative,plan)
            if mapped is None:continue  # Keep the original single-attire slot rule.
            target=(output/mapped).resolve()
            if not target.is_relative_to(output) or target.is_relative_to(source):
                raise ValueError('mapped YCL output leaves the separate output folder')
            companions=[p for ext in PHYSICS_SUFFIXES if (p:=source_ycl.with_suffix(ext)).is_file()]
            unknown=[p for p in companions if p.suffix.lower()=='.ywa']
            # Do not repeat files successfully processed by the original loop.
            completed=[r for r in report.get('physics_converted',[])
                       if r.get('source')==str(source_ycl) and r.get('file')==mapped]
            if completed and target.is_file():
                if unknown:
                    for row in completed:row.update(unknown_details(unknown))
                    record_unknown(unknown);limitation(relative,unknown)
                continue
            if not companions:continue  # Unrelated failures stay with original handling.
            try:
                validation=checked_translation(folder_module,source_ycl,target)
                if unknown:validation.update(unknown_details(unknown));record_unknown(unknown)
                report.setdefault('physics_converted',[]).append({'file':mapped,'source':str(source_ycl),**validation})
                # Remove only the now-obsolete skip for this successfully translated
                # YCL. Unsupported companion omissions remain visible and incomplete.
                def old_skip(value):
                    return (value.startswith(relative+': hair/cloth physics not converted (this attire also has cloth data')
                            or value.startswith(relative+' (2K25 physics file: this attire also has cloth data'))
                for field in ('warnings','problems','left_out'):
                    report[field]=[v for v in report.get(field,[]) if not old_skip(v)]
                limitation(relative,companions)
                bound.arguments['log']('  '+relative+': YCL translated by original Gorilla converter; companion physics remains incomplete')
            except Exception as exc:
                report.setdefault('problems',[]).append(relative+': YCL translation failed: '+str(exc))
        # An unknown omitted companion is incomplete even without a readable
        # YCL (or any model). Do not invent a translator result for this case.
        for path in sorted(source.rglob('*')):
            if not path.is_file() or path.suffix.lower()!='.ywa' or str(path) in handled_unknown:continue
            relative_unknown=os.path.relpath(path,source)
            if folder_module._mapped(relative_unknown,plan) is None:continue
            record_unknown([path])
            problem=relative_unknown+': plain .ywa companion format is unknown; original blob omitted; movement compatibility remains unverified'
            if problem not in report.setdefault('problems',[]):report['problems'].append(problem)
        report['ycl_repair_patch']=PATCH_VERSION
        report['conversion_completeness']='incomplete' if report.get('problems') else 'structural_checks_only'
        report['in_game_validation']='not_performed'
        from gmf_report import save_intermediate
        save_intermediate(report,destination)
        return report

    folder_module.convert_folder=convert_folder
    folder_module._independent_ycl_patch=PATCH_VERSION
