using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

public static class MaterialGenerator
{
    static Assembly editorAssembly;
    static string editorDirectory;
    static string toolDirectory;
    static string texconvPath;
    static bool preserveWweHair;
    static readonly HashSet<string> wweBaseModels = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    static readonly List<string> messages = new List<string>();

    static Type FindType(string name)
    {
        Type type = editorAssembly.GetType(name, false);
        if (type == null) throw new InvalidOperationException("Material Editor type not found: " + name);
        return type;
    }


    static object Create(string typeName, params object[] args)
    {
        return Activator.CreateInstance(FindType(typeName), args);
    }

    static object CallStatic(string typeName, string name, params object[] args)
    {
        Type type = FindType(typeName);
        return FindMethod(type, name, true, args).Invoke(null, args);
    }

    static bool LooksLikeHairMeshSlot(string value)
    {
        string name = (value ?? "").Trim().ToLowerInvariant();
        if (name.Contains("chair")) return false;
        return name.Contains("hairmesh") || name.Contains("hair_mesh");
    }

    static bool LooksLikeHairSlot(string value)
    {
        string name = (value ?? "").Trim().ToLowerInvariant();
        if (name.Contains("chair")) return false;
        return name.Contains("hair");
    }

    static bool LooksLikeFacialHairSlot(string value)
    {
        string name = (value ?? "").Trim().ToLowerInvariant();
        return name.Contains("beard") || name.Contains("mustache") || name.Contains("moustache") || name.Contains("goatee") || name.Contains("sideburn") || name.Contains("side_burn") || name.Contains("facial_hair") || name.Contains("eyebrow") || name.Contains("eyebrows") || name.Contains("brow") || name.Contains("brows");
    }

    static bool LooksLikeEyelashSlot(string value)
    {
        string name = (value ?? "").Trim().ToLowerInvariant();
        return name.Contains("eyelash") || name.Contains("eyelashes") || name.Contains("lashes");
    }

    static bool LooksLikeEyeOverlaySlot(string value)
    {
        string name = (value ?? "").Trim().ToLowerInvariant();
        if (LooksLikeEyelashSlot(name)) return false;
        return name.Contains("eye_overlay") || name.Contains("eyeoverlay") || name.Contains("eyes_overlay") || name.Contains("eyesoverlay") || name.Contains("eye_ov") || name.Contains("eyeov");
    }

    static bool LooksLikeContactLensSlot(string value)
    {
        string name = (value ?? "").Trim().ToLowerInvariant();
        return name.Contains("contactlens") || name.Contains("contact_lens") || name.Contains("contact lens") || name.Contains("lens");
    }

    static bool LooksLikeEyeSlot(string value)
    {
        string name = (value ?? "").Trim().ToLowerInvariant();
        if (LooksLikeEyelashSlot(name)) return false;
        return name == "eye" || name == "eyes" || name.Contains("eye_color") || name.Contains("eye_") || name.Contains("_eye") || name.Contains("eyes_") || name.Contains("_eyes") || name.EndsWith("eye") || name.EndsWith("eyes") || name.Contains("iris") || name.Contains("pupil") || name.Contains("sclera") || LooksLikeContactLensSlot(name);
    }

    static bool LooksLikeCustomBodySlot(string value)
    {
        return NormalizeSlotKey(value) == "custom_body";
    }

    static bool LooksLikeCustomHeadSlot(string value)
    {
        return NormalizeSlotKey(value) == "custom_head";
    }

    static bool LooksLikeFortniteToonFaceSurfaceSlot(string value)
    {
        return NormalizeSlotKey(value) == "custom_toon_face_surface";
    }

    static bool LooksLikeCustomSkinSlot(string value)
    {
        return LooksLikeCustomBodySlot(value) || LooksLikeCustomHeadSlot(value);
    }

    static bool LooksLikeCustomLineworkSlot(string value)
    {
        return NormalizeSlotKey(value).StartsWith("custom_linework_", StringComparison.OrdinalIgnoreCase);
    }


    static bool LooksLikeCustomHairLineworkSlot(string value)
    {
        string key = NormalizeSlotKey(value);
        return key.StartsWith("custom_linework_", StringComparison.OrdinalIgnoreCase) && key.Contains("hair");
    }


    static bool LooksLikeFortniteHairAlphaSlot(string value)
    {
        string key = NormalizeSlotKey(value, false);
        return key == "custom_hair_alpha" || key.StartsWith("custom_hair_alpha_", StringComparison.OrdinalIgnoreCase);
    }

    static bool LooksLikeCustomGenericSlot(string value)
    {
        return NormalizeSlotKey(value).StartsWith("custom_", StringComparison.OrdinalIgnoreCase) && !LooksLikeCustomSkinSlot(value) && !LooksLikeEyeSlot(value) && !LooksLikeEyelashSlot(value) && !LooksLikeContactLensSlot(value) && !LooksLikeTeethSlot(value) && !LooksLikeHairSlot(value) && !LooksLikeFacialHairSlot(value) && !LooksLikeHairMeshSlot(value);
    }

    static bool LooksLikeFortniteGlassSlot(string value)
    {
        string key = NormalizeSlotKey(value, false);
        if (!key.StartsWith("custom_", StringComparison.OrdinalIgnoreCase)) return false;
        return key.Contains("glass") || key.Contains("visor") || key.Contains("dome") || key.Contains("bubble") || key.Contains("canopy") || key.Contains("face_shield") || key.Contains("faceshield") || key.Contains("windshield") || key.Contains("helmet_02") || key.Contains("helmet02");
    }

    static string GenericTextureKey(string value)
    {
        string key = LooksLikeFortniteHairAlphaSlot(value) ? NormalizeSlotKey(value, false) : NormalizeSlotKey(value);
        if (key.EndsWith("_skinned", StringComparison.OrdinalIgnoreCase)) key = key.Substring(0, key.Length - 8);
        return key;
    }

    static bool LooksLikeTeethSlot(string value)
    {
        string name = (value ?? "").Trim().ToLowerInvariant();
        return name == "teeth" || name == "tooth" || name.Contains("teeth_") || name.Contains("_teeth") || name.Contains("tooth_") || name.Contains("_tooth");
    }

    static bool LooksLikeBodySlot(string value)
    {
        string key = NormalizeSlotKey(value);
        return key == "body" || key == "custom_body";
    }

    static bool LooksLikeHeadSlot(string value)
    {
        string key = NormalizeSlotKey(value);
        return key == "head" || key == "custom_head";
    }

    static string NormalizeSlotKey(string value, bool stripAlpha = true)
    {
        string name = (value ?? "").Trim().ToLowerInvariant().Replace('-', '_').Replace(' ', '_');
        if (name.StartsWith("m_")) name = name.Substring(2);
        if (stripAlpha)
        {
            while (name.Contains("_alpha_")) name = name.Replace("_alpha_", "_");
            if (name.EndsWith("_alpha")) name = name.Substring(0, name.Length - 6);
        }
        while (name.StartsWith("_")) name = name.Substring(1);
        while (name.EndsWith("_")) name = name.Substring(0, name.Length - 1);
        return name;
    }

    static string CleanMaterialName(string value)
    {
        if (String.IsNullOrWhiteSpace(value)) return "material";
        string name = value.Trim();
        int colon = name.IndexOf(':');
        if (colon >= 0) name = name.Substring(0, colon);
        while (name.Length > 4 && name[name.Length - 4] == '.' && Char.IsDigit(name[name.Length - 3]) && Char.IsDigit(name[name.Length - 2]) && Char.IsDigit(name[name.Length - 1]))
        {
            name = name.Substring(0, name.Length - 4);
        }
        return name.Length == 0 ? "material" : name;
    }

    static List<string> ReadMaterialSlots(string modelPath)
    {
        object result = CallStatic("MaterialEditor.Services.MdlFileService", "ReadMaterialSlotNames", modelPath);
        List<string> slots = new List<string>();
        HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        IEnumerable values = result as IEnumerable;
        if (values != null)
        {
            foreach (object value in values)
            {
                string name = CleanMaterialName(value == null ? "" : value.ToString());
                if (seen.Add(name)) slots.Add(name);
            }
        }
        return slots;
    }

    static object NewMaterialList()
    {
        Type materialType = FindType("MaterialEditor.Models.MtlMaterial");
        Type listType = typeof(List<>).MakeGenericType(materialType);
        return Activator.CreateInstance(listType);
    }

    static void AddToList(object list, object value)
    {
        list.GetType().GetMethod("Add").Invoke(list, new object[] { value });
    }

    static string MaterialKey(string value)
    {
        return NormalizeSlotKey(CleanMaterialName(value));
    }

    static object FindMaterialProperty(object material, string name)
    {
        IEnumerable properties = Get(material, "Properties") as IEnumerable;
        if (properties == null) return null;
        foreach (object property in properties)
        {
            string propertyName = Convert.ToString(Get(property, "Name"));
            if (String.Equals(propertyName, name, StringComparison.OrdinalIgnoreCase)) return property;
        }
        return null;
    }

    static ulong ResolveTextureHash(string textureName, string mtlsPath)
    {
        ulong value = Convert.ToUInt64(CallStatic("MaterialEditor.Services.TextureRefService", "ResolveTextureNameToHash", textureName, mtlsPath));
        if (value == UInt64.MaxValue || value == 0) throw new FileNotFoundException("Could not resolve Textures\\" + textureName + ".dds", textureName + ".dds");
        return value;
    }

    static ulong TryResolveTextureHash(string textureName, string mtlsPath)
    {
        try
        {
            ulong value = Convert.ToUInt64(CallStatic("MaterialEditor.Services.TextureRefService", "ResolveTextureNameToHash", textureName, mtlsPath));
            if (value == UInt64.MaxValue || value == 0) return 0;
            return value;
        }
        catch { return 0; }
    }

    static void SetMaterialHash(object material, string propertyName, ulong value)
    {
        object property = FindMaterialProperty(material, propertyName);
        if (property == null) throw new MissingMemberException("The material is missing " + propertyName);
        Set(property, "Value", value);
    }

    static bool TrySetMaterialHash(object material, string propertyName, ulong value)
    {
        if (value == 0 || value == UInt64.MaxValue) return false;
        object property = FindMaterialProperty(material, propertyName);
        if (property == null) return false;
        Set(property, "Value", value);
        return true;
    }

    static bool IsAlphaVariantSlot(string value)
    {
        string name = NormalizeSlotKey(value, false);
        return name.EndsWith("_alpha", StringComparison.OrdinalIgnoreCase) || name.Contains("_alpha_");
    }

    static int MaterialPropertyCount(object material)
    {
        if (material == null) return 0;
        try { return CountEnumerable(Get(material, "Properties")); }
        catch { return 0; }
    }

    static object RicherMaterial(object current, object candidate)
    {
        if (candidate == null) return current;
        if (current == null) return candidate;
        return MaterialPropertyCount(candidate) >= MaterialPropertyCount(current) ? candidate : current;
    }

    static bool EnsureMaterialProperty(object material, string propertyName, string propertyType, object value)
    {
        object existing = FindMaterialProperty(material, propertyName);
        if (existing != null)
        {
            Set(existing, "Value", value);
            return true;
        }
        try
        {
            object properties = Get(material, "Properties");
            Type propertyClass = null;
            Type collectionType = properties.GetType();
            Type[] genericArguments = collectionType.GetGenericArguments();
            if (genericArguments.Length == 1) propertyClass = genericArguments[0];
            if (propertyClass == null)
            {
                MethodInfo[] methods = collectionType.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                for (int i = 0; i < methods.Length; i++)
                {
                    if (methods[i].Name != "Add") continue;
                    ParameterInfo[] parameters = methods[i].GetParameters();
                    if (parameters.Length != 1) continue;
                    propertyClass = parameters[0].ParameterType;
                    break;
                }
            }
            if (propertyClass == null) return false;
            object property = null;
            try { property = Activator.CreateInstance(propertyClass); }
            catch
            {
                IEnumerable propertyValues = properties as IEnumerable;
                if (propertyValues != null)
                {
                    foreach (object propertyValue in propertyValues)
                    {
                        object typeValue = Get(propertyValue, "Type");
                        if (!String.Equals(Convert.ToString(typeValue), propertyType, StringComparison.OrdinalIgnoreCase)) continue;
                        MethodInfo cloneMethod = typeof(object).GetMethod("MemberwiseClone", BindingFlags.NonPublic | BindingFlags.Instance);
                        property = cloneMethod == null ? null : cloneMethod.Invoke(propertyValue, null);
                        if (property != null) break;
                    }
                }
            }
            if (property == null) return false;
            Set(property, "Name", propertyName);
            PropertyInfo typeProperty = propertyClass.GetProperty("Type", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (typeProperty == null || !typeProperty.PropertyType.IsEnum) return false;
            typeProperty.SetValue(property, Enum.Parse(typeProperty.PropertyType, propertyType, true), null);
            Set(property, "Value", value);
            MethodInfo addMethod = null;
            MethodInfo[] addMethods = collectionType.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            for (int i = 0; i < addMethods.Length; i++)
            {
                if (addMethods[i].Name != "Add") continue;
                ParameterInfo[] parameters = addMethods[i].GetParameters();
                if (parameters.Length == 1 && parameters[0].ParameterType.IsInstanceOfType(property))
                {
                    addMethod = addMethods[i];
                    break;
                }
            }
            if (addMethod == null) return false;
            addMethod.Invoke(properties, new object[] { property });
            return true;
        }
        catch { return false; }
    }

    static bool SetExistingMaterialValue(object material, string propertyName, object value)
    {
        object property = FindMaterialProperty(material, propertyName);
        if (property == null) return false;
        try
        {
            Set(property, "Value", value);
            return true;
        }
        catch { return false; }
    }

    static void NormalizeCustomHeadLiteralMaterial(object material)
    {
        if (material == null) return;
        Set(material, "Shader", "yCh_gear");
        Set(material, "TemplateType", "Normal");
        SetExistingMaterialValue(material, "casPartFlag", false);
        SetExistingMaterialValue(material, "standardLighting", true);
        SetExistingMaterialValue(material, "standardLit", true);
        SetExistingMaterialValue(material, "microDetail", false);
        SetExistingMaterialValue(material, "exposure", 0.0f);
        SetExistingMaterialValue(material, "irradianceR", 1.0f);
        SetExistingMaterialValue(material, "irradianceG", 1.0f);
        SetExistingMaterialValue(material, "irradianceB", 1.0f);
        SetExistingMaterialValue(material, "irradianceMin", 0.0f);
        SetExistingMaterialValue(material, "glow", new float[] { 0.0f, 0.0f, 0.0f, 0.0f });
        SetExistingMaterialValue(material, "clothSheenR", 0.0f);
        SetExistingMaterialValue(material, "clothSheenG", 0.0f);
        SetExistingMaterialValue(material, "clothSheenB", 0.0f);
        SetExistingMaterialValue(material, "clothSheenRough", 1.0f);
        SetExistingMaterialValue(material, "g_specIntensity", 0.0f);
        SetExistingMaterialValue(material, "g_fSpecLevel", 0.0f);
        SetExistingMaterialValue(material, "g_fSpecFresnel", 0.0f);
        SetExistingMaterialValue(material, "g_receivesSSR", 0.0f);
        SetExistingMaterialValue(material, "g_mPixMsk@ref", 0UL);
        SetExistingMaterialValue(material, "metalMap@ref", 0UL);
        SetExistingMaterialValue(material, "roughnessMap@ref", 0UL);
        SetExistingMaterialValue(material, "occlusionMap@ref", 0UL);
        SetExistingMaterialValue(material, "specularMap@ref", 0UL);
        SetExistingMaterialValue(material, "g_f4CASFlagsPar", new float[] { 0.0f, 0.0f, 0.0f, 0.0f });
        SetExistingMaterialValue(material, "g_fCasParam", new float[] { 0.0f, 0.0f, 0.0f, 0.0f });
    }


    static void NormalizeCustomHairLineworkMaterial(object material)
    {
        NormalizeCustomHeadLiteralMaterial(material);
    }


    static void NormalizeFortniteToonFaceSurfaceMaterial(object material)
    {
        NormalizeCustomHeadLiteralMaterial(material);
        SetExistingMaterialValue(material, "standardLighting", false);
        SetExistingMaterialValue(material, "standardLit", false);
        SetExistingMaterialValue(material, "irradianceR", 1.0f);
        SetExistingMaterialValue(material, "irradianceG", 1.0f);
        SetExistingMaterialValue(material, "irradianceB", 1.0f);
        SetExistingMaterialValue(material, "irradianceMin", 1.0f);
        SetExistingMaterialValue(material, "g_nrmMap@ref", 0UL);
        SetExistingMaterialValue(material, "normalMap@ref", 0UL);
        SetExistingMaterialValue(material, "nrMap@ref", 0UL);
        SetExistingMaterialValue(material, "g_mPixMsk@ref", 0UL);
        SetExistingMaterialValue(material, "metalMap@ref", 0UL);
        SetExistingMaterialValue(material, "roughnessMap@ref", 0UL);
        SetExistingMaterialValue(material, "occlusionMap@ref", 0UL);
        SetExistingMaterialValue(material, "specularMap@ref", 0UL);
        SetExistingMaterialValue(material, "g_nrmMap", "");
        SetExistingMaterialValue(material, "normalMap", "");
        SetExistingMaterialValue(material, "roughnessMap", "");
        SetExistingMaterialValue(material, "metalMap", "");
        SetExistingMaterialValue(material, "occlusionMap", "");
        SetExistingMaterialValue(material, "specularMap", "");
        SetExistingMaterialValue(material, "g_mPixMsk", "");
        SetExistingMaterialValue(material, "g_mPixMsk2", "");
    }


    static void NormalizeCustomLineworkMaterial(object material)
    {
        if (material == null) return;
        Set(material, "Shader", "yCh_eye");
        Set(material, "TemplateType", "Normal");
        SetExistingMaterialValue(material, "casPartFlag", false);
        SetExistingMaterialValue(material, "standardLighting", true);
        SetExistingMaterialValue(material, "standardLit", true);
        SetExistingMaterialValue(material, "microDetail", false);
        SetExistingMaterialValue(material, "exposure", 0.0f);
        SetExistingMaterialValue(material, "caustic", 0.0f);
        SetExistingMaterialValue(material, "g_eyeRoughness", 1.0f);
        SetExistingMaterialValue(material, "g_eyeWetness", 0.0f);
        SetExistingMaterialValue(material, "g_fFresnel", 0.0f);
        SetExistingMaterialValue(material, "g_fSpecLev", 0.0f);
        SetExistingMaterialValue(material, "g_fSpecPow", 0.0f);
        SetExistingMaterialValue(material, "g_specIntensity", 0.0f);
        SetExistingMaterialValue(material, "g_refraction", 0.0f);
        SetExistingMaterialValue(material, "g_pupil_lns", 0.0f);
        SetExistingMaterialValue(material, "g_pupil_par", 0.0f);
        SetExistingMaterialValue(material, "EyeInsideTex@ref", 0UL);
        SetExistingMaterialValue(material, "EyeMaskTex@ref", 0UL);
        SetExistingMaterialValue(material, "g_nrmMap@ref", 0UL);
        SetExistingMaterialValue(material, "normalMap@ref", 0UL);
        SetExistingMaterialValue(material, "metalMap@ref", 0UL);
        SetExistingMaterialValue(material, "roughnessMap@ref", 0UL);
        SetExistingMaterialValue(material, "glow", new float[] { 0.0f, 0.0f, 0.0f, 0.0f });
    }

    static bool TryGetMaterialFloat(object material, string propertyName, out float value)
    {
        value = 0.0f;
        object property = FindMaterialProperty(material, propertyName);
        if (property == null) return false;
        try
        {
            value = Convert.ToSingle(Get(property, "Value"));
            return true;
        }
        catch { return false; }
    }

    static void ReplaceGeneratedAverage(object material, string propertyName, float generatedValue, float replacement, float tolerance)
    {
        float value;
        if (!TryGetMaterialFloat(material, propertyName, out value)) return;
        if (Math.Abs(value - generatedValue) <= tolerance) EnsureMaterialProperty(material, propertyName, "Float", replacement);
    }

    static void NormalizeGeneratedAlphaHairDefaults(object material, string slotName)
    {
        if (material == null || !IsAlphaVariantSlot(slotName)) return;
        string key = NormalizeSlotKey(slotName);
        bool combinationStyle = key.StartsWith("combination", StringComparison.OrdinalIgnoreCase) || LooksLikeFacialHairSlot(key);
        float rootR;
        float rootG;
        float rootB;
        float tipR;
        float tipG;
        float tipB;
        bool generatedColors = TryGetMaterialFloat(material, "g_rootColorR", out rootR) && TryGetMaterialFloat(material, "g_rootColorG", out rootG) && TryGetMaterialFloat(material, "g_rootColorB", out rootB) && TryGetMaterialFloat(material, "g_tipColorR", out tipR) && TryGetMaterialFloat(material, "g_tipColorG", out tipG) && TryGetMaterialFloat(material, "g_tipColorB", out tipB) && Math.Abs(rootR - 0.2862888f) <= 0.03f && Math.Abs(rootG - 0.25415266f) <= 0.03f && Math.Abs(rootB - 0.2437516f) <= 0.03f && Math.Abs(tipR - 0.43499905f) <= 0.03f && Math.Abs(tipG - 0.37945414f) <= 0.03f && Math.Abs(tipB - 0.35569435f) <= 0.03f;
        if (generatedColors)
        {
            float root = combinationStyle ? 0.8f : 0.6f;
            float tip = combinationStyle ? 0.8980392f : 0.69803923f;
            EnsureMaterialProperty(material, "g_rootColorR", "Float", root);
            EnsureMaterialProperty(material, "g_rootColorG", "Float", root);
            EnsureMaterialProperty(material, "g_rootColorB", "Float", root);
            EnsureMaterialProperty(material, "g_tipColorR", "Float", tip);
            EnsureMaterialProperty(material, "g_tipColorG", "Float", tip);
            EnsureMaterialProperty(material, "g_tipColorB", "Float", tip);
        }
        ReplaceGeneratedAverage(material, "g_specKnockout", 0.49310327f, 0.0f, 0.03f);
        ReplaceGeneratedAverage(material, "g_roughMult", 0.76500005f, 1.0f, 0.03f);
        ReplaceGeneratedAverage(material, "g_hairNoise", 0.32215694f, 1.0f, 0.03f);
        ReplaceGeneratedAverage(material, "g_flowJitter", 0.6800001f, 0.3f, 0.03f);
        ReplaceGeneratedAverage(material, "g_hairIntensity", 0.8f, 1.0f, 0.03f);
        ReplaceGeneratedAverage(material, "g_hairAlbedo", 0.5833333f, 1.0f, 0.03f);
        ReplaceGeneratedAverage(material, "g_dyeHack", 1.0f, 0.0f, 0.03f);
    }

    static void EnsureAlphaHairDefaults(object material, string slotName)
    {
        if (material == null || !IsAlphaVariantSlot(slotName)) return;
        string key = NormalizeSlotKey(slotName);
        bool combinationStyle = key.StartsWith("combination", StringComparison.OrdinalIgnoreCase) || LooksLikeFacialHairSlot(key);
        float root = combinationStyle ? 0.8f : 0.6f;
        float tip = combinationStyle ? 0.8980392f : 0.69803923f;
        EnsureMaterialProperty(material, "hairType", "Int", combinationStyle ? 1 : 2);
        EnsureMaterialProperty(material, "g_rootColorR", "Float", root);
        EnsureMaterialProperty(material, "g_rootColorG", "Float", root);
        EnsureMaterialProperty(material, "g_rootColorB", "Float", root);
        EnsureMaterialProperty(material, "g_tipColorR", "Float", tip);
        EnsureMaterialProperty(material, "g_tipColorG", "Float", tip);
        EnsureMaterialProperty(material, "g_tipColorB", "Float", tip);
        EnsureMaterialProperty(material, "g_variation", "Float", 0.0f);
        EnsureMaterialProperty(material, "g_specKnockout", "Float", 0.0f);
        EnsureMaterialProperty(material, "g_noiseUScale", "Float", 24.0f);
        EnsureMaterialProperty(material, "g_noiseVScale", "Float", 24.0f);
        EnsureMaterialProperty(material, "g_hairR", "Float", 1.0f);
        EnsureMaterialProperty(material, "g_hairTRT", "Float", 1.0f);
        EnsureMaterialProperty(material, "g_hairTT", "Float", 1.0f);
        EnsureMaterialProperty(material, "g_hairShift", "Float", 0.135f);
        EnsureMaterialProperty(material, "g_autoVariation", "Bool", true);
        EnsureMaterialProperty(material, "g_hairVariation", "Float", 0.0f);
        EnsureMaterialProperty(material, "primeIntensity", "Float", 1.0f);
        EnsureMaterialProperty(material, "rimIntensity", "Float", 1.0f);
        EnsureMaterialProperty(material, "secondIntensity", "Float", 1.0f);
        EnsureMaterialProperty(material, "primeShift", "Float", 0.0f);
        EnsureMaterialProperty(material, "primeWidth", "Float", combinationStyle ? 0.8f : 0.7f);
        EnsureMaterialProperty(material, "secondShift", "Float", combinationStyle ? 0.7f : 0.0f);
        EnsureMaterialProperty(material, "rimShift", "Float", 0.0f);
        EnsureMaterialProperty(material, "primeSat", "Float", 1.0f);
        EnsureMaterialProperty(material, "secondBright", "Float", 1.0f);
        EnsureMaterialProperty(material, "secondSat", "Float", 1.0f);
        EnsureMaterialProperty(material, "rimBright", "Float", 1.0f);
        EnsureMaterialProperty(material, "g_roughMult", "Float", 1.0f);
        EnsureMaterialProperty(material, "g_shineBoost", "Float", 5.0f);
        EnsureMaterialProperty(material, "secondWidth", "Float", combinationStyle ? 0.35f : 0.3f);
        EnsureMaterialProperty(material, "rimWidth", "Float", combinationStyle ? 0.7f : 0.5f);
        EnsureMaterialProperty(material, "g_hairIntensity", "Float", 1.0f);
        EnsureMaterialProperty(material, "g_hairNoise", "Float", 1.0f);
        EnsureMaterialProperty(material, "g_flowJitter", "Float", 0.3f);
        EnsureMaterialProperty(material, "primeBright", "Float", 1.0f);
        EnsureMaterialProperty(material, "rimSat", "Float", 1.0f);
        EnsureMaterialProperty(material, "g_dyeHack", "Float", 0.0f);
        EnsureMaterialProperty(material, "g_hairAlbedo", "Float", 1.0f);
    }

    static ulong GetMaterialHash(object material, string propertyName)
    {
        object property = FindMaterialProperty(material, propertyName);
        if (property == null) return 0;
        try
        {
            ulong value = Convert.ToUInt64(Get(property, "Value"));
            return value == UInt64.MaxValue ? 0 : value;
        }
        catch { return 0; }
    }

    static List<string> TextureFilesNear(string mtlsPath)
    {
        List<string> result = new List<string>();
        HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        DirectoryInfo modelDirectory = new DirectoryInfo(Path.GetDirectoryName(mtlsPath));
        List<string> roots = new List<string>();
        roots.Add(Path.Combine(modelDirectory.FullName, "Textures"));
        roots.Add(modelDirectory.FullName);
        if (modelDirectory.Parent != null)
        {
            roots.Add(Path.Combine(modelDirectory.Parent.FullName, "Textures"));
            roots.Add(modelDirectory.Parent.FullName);
        }
        for (int r = 0; r < roots.Count; r++)
        {
            string root = roots[r];
            if (!Directory.Exists(root)) continue;
            try
            {
                string[] files = Directory.GetFiles(root, "*.dds", SearchOption.AllDirectories);
                for (int i = 0; i < files.Length; i++)
                {
                    string full = Path.GetFullPath(files[i]);
                    if (seen.Add(full)) result.Add(full);
                }
            }
            catch { }
        }
        return result;
    }

    static string FindTextureStemNear(string mtlsPath, params string[] candidates)
    {
        List<string> files = TextureFilesNear(mtlsPath);
        for (int c = 0; c < candidates.Length; c++)
        {
            string candidate = (candidates[c] ?? "").Trim();
            if (candidate.EndsWith(".dds", StringComparison.OrdinalIgnoreCase)) candidate = Path.GetFileNameWithoutExtension(candidate);
            for (int i = 0; i < files.Count; i++)
            {
                string stem = Path.GetFileNameWithoutExtension(files[i]);
                if (String.Equals(stem, candidate, StringComparison.OrdinalIgnoreCase)) return stem;
            }
        }
        return null;
    }

    static string FindTextureStemByParts(string mtlsPath, string requiredPart, params string[] suffixParts)
    {
        string required = (requiredPart ?? "").ToLowerInvariant();
        List<string> files = TextureFilesNear(mtlsPath);
        for (int s = 0; s < suffixParts.Length; s++)
        {
            string suffix = (suffixParts[s] ?? "").ToLowerInvariant();
            for (int i = 0; i < files.Count; i++)
            {
                string stem = Path.GetFileNameWithoutExtension(files[i]);
                string lower = stem.ToLowerInvariant();
                if (required.Length > 0 && !lower.Contains(required)) continue;
                if (suffix.Length > 0 && !lower.Contains(suffix)) continue;
                return stem;
            }
        }
        return null;
    }

    static ulong ResolveFirstTextureHash(string mtlsPath, params string[] candidates)
    {
        string stem = FindTextureStemNear(mtlsPath, candidates);
        if (stem == null) return 0;
        return TryResolveTextureHash(stem, mtlsPath);
    }

    static bool TextureExistsNear(string mtlsPath, params string[] textureNames)
    {
        return FindTextureStemNear(mtlsPath, textureNames) != null;
    }

    static bool LooksLikeCombinationFacialHairSlot(string value, string mtlsPath)
    {
        string key = NormalizeSlotKey(value);
        return key.StartsWith("combination", StringComparison.OrdinalIgnoreCase) || String.Equals(key, "hair_rai", StringComparison.OrdinalIgnoreCase) || String.Equals(key, "hair_flow", StringComparison.OrdinalIgnoreCase);
    }

    static bool LooksLikeAnyHairSlot(string value, string mtlsPath)
    {
        return LooksLikeCombinationFacialHairSlot(value, mtlsPath) || LooksLikeHairSlot(value) || LooksLikeFacialHairSlot(value) || LooksLikeHairMeshSlot(value);
    }

    static bool LooksLikeKnownHairMaterial(object material)
    {
        if (material == null) return false;
        string shader = Convert.ToString(Get(material, "Shader"));
        string template = Convert.ToString(Get(material, "TemplateType"));
        return String.Equals(shader, "yCh_hair", StringComparison.OrdinalIgnoreCase) || String.Equals(shader, "yCh_hairMesh", StringComparison.OrdinalIgnoreCase) || String.Equals(shader, "yCh_NPChair", StringComparison.OrdinalIgnoreCase) || String.Equals(template, "NewHair_ColorChanging", StringComparison.OrdinalIgnoreCase) || String.Equals(template, "NPC", StringComparison.OrdinalIgnoreCase) || template.StartsWith("NPC_", StringComparison.OrdinalIgnoreCase);
    }

    static bool LooksLikeAnyHairMaterial(object material, string mtlsPath)
    {
        if (material == null) return false;
        string name = Convert.ToString(Get(material, "Name"));
        return LooksLikeAnyHairSlot(name, mtlsPath) || LooksLikeKnownHairMaterial(material);
    }

    static HashSet<string> ReadMaterialNames(object mtlService, string mtlsPath)
    {
        HashSet<string> names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        object file = Call(mtlService, "ReadFile", mtlsPath);
        IEnumerable materials = Get(file, "Materials") as IEnumerable;
        if (materials != null)
        {
            foreach (object material in materials)
            {
                string name = Convert.ToString(Get(material, "Name"));
                if (!String.IsNullOrWhiteSpace(name)) names.Add(MaterialKey(name));
            }
        }
        return names;
    }

    static int MaterialOverlapScore(object mtlService, string mtlsPath, List<string> slots)
    {
        try
        {
            HashSet<string> names = ReadMaterialNames(mtlService, mtlsPath);
            HashSet<string> counted = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            int score = 0;
            for (int i = 0; i < slots.Count; i++)
            {
                string key = MaterialKey(slots[i]);
                if (counted.Add(key) && names.Contains(key)) score++;
            }
            return score;
        }
        catch { return -1; }
    }

    static string PickReferenceMtls(string mcdPath, string targetMtlsPath, object mtlService, List<string> slots, out string note)
    {
        note = "no source material set";
        List<string> preferred = new List<string>();
        if (File.Exists(targetMtlsPath)) preferred.Add(targetMtlsPath);
        for (int i = 0; i < preferred.Count; i++)
        {
            int score = MaterialOverlapScore(mtlService, preferred[i], slots);
            if (score > 0)
            {
                note = "same-name material set";
                return preferred[i];
            }
        }
        string directory = Path.GetDirectoryName(mcdPath);
        string best = null;
        int bestScore = -1;
        bool tied = false;
        List<string> candidates = new List<string>();
        HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        string[] siblingFiles = Directory.GetFiles(directory, "*.mtls", SearchOption.TopDirectoryOnly);
        for (int i = 0; i < siblingFiles.Length; i++) if (seen.Add(siblingFiles[i])) candidates.Add(siblingFiles[i]);
        DirectoryInfo modelDirectory = new DirectoryInfo(directory);
        DirectoryInfo scope = modelDirectory.Parent ?? modelDirectory;
        try
        {
            string[] scopedFiles = Directory.GetFiles(scope.FullName, "*.mtls", SearchOption.AllDirectories);
            for (int i = 0; i < scopedFiles.Length; i++) if (seen.Add(scopedFiles[i])) candidates.Add(scopedFiles[i]);
        }
        catch { }
        for (int i = 0; i < candidates.Count; i++)
        {
            string path = candidates[i];
            if (Path.GetFileNameWithoutExtension(path).EndsWith("_backup", StringComparison.OrdinalIgnoreCase)) continue;
            int score = MaterialOverlapScore(mtlService, path, slots);
            if (score > bestScore)
            {
                best = path;
                bestScore = score;
                tied = false;
            }
            else if (score == bestScore && score > 0)
            {
                tied = true;
            }
        }
        if (best != null && bestScore > 0 && !tied)
        {
            note = "material-slot match (" + bestScore + ")";
            return best;
        }
        return null;
    }

    static string ReferenceMaterialsDirectory(string referenceMtlsPath, string targetDirectory)
    {
        string referenceDirectory = String.IsNullOrWhiteSpace(referenceMtlsPath) ? targetDirectory : Path.GetDirectoryName(referenceMtlsPath);
        string normal = Path.Combine(referenceDirectory, "Materials");
        if (Directory.Exists(normal)) return normal;
        string legacy = Path.Combine(targetDirectory, "Materials.before_2k26_material_fix");
        return Directory.Exists(legacy) ? legacy : normal;
    }

    static object LoadReferenceFile(object mtlService, object jmtlService, string referenceMtlsPath, string materialsDirectory)
    {
        object source = Call(mtlService, "ReadFile", referenceMtlsPath);
        if (Directory.Exists(materialsDirectory))
        {
            try { source = Call(jmtlService, "MergeJmtlIntoMtls", source, materialsDirectory); }
            catch { }
        }
        return source;
    }

    static object CreateSuggestedMaterial(object databaseService, string slotName, string formatKey)
    {
        object suggestion = Call(databaseService, "SuggestShaderForSlot", slotName);
        string shader = Convert.ToString(TupleItem(suggestion, "Item1"));
        string template = Convert.ToString(TupleItem(suggestion, "Item2"));
        object material = Call(databaseService, "CreateMaterial", slotName, shader, template, formatKey);
        Set(material, "Name", slotName);
        return material;
    }

    static bool ApplySlotShaderOverride(object material, string slotName, string mtlsPath, bool wweBaseModel)
    {
        if (LooksLikeFortniteGlassSlot(slotName))
        {
            Set(material, "Shader", "yCh_trans");
            Set(material, "TemplateType", "Normal");
            return true;
        }
        if (LooksLikeFortniteHairAlphaSlot(slotName))
        {
            Set(material, "Shader", "yCh_trans");
            Set(material, "TemplateType", "Normal");
            return true;
        }
        if (LooksLikeCustomHeadSlot(slotName))
        {
            NormalizeCustomHeadLiteralMaterial(material);
            return true;
        }
        if (LooksLikeCustomBodySlot(slotName))
        {
            Set(material, "Shader", "yCh_skin");
            Set(material, "TemplateType", "Normal");
            return true;
        }
        if (LooksLikeFortniteToonFaceSurfaceSlot(slotName))
        {
            NormalizeFortniteToonFaceSurfaceMaterial(material);
            return true;
        }
        if (LooksLikeCustomLineworkSlot(slotName))
        {
            if (LooksLikeCustomHairLineworkSlot(slotName)) NormalizeCustomHairLineworkMaterial(material);
            else NormalizeCustomLineworkMaterial(material);
            return true;
        }
        if (LooksLikeCustomGenericSlot(slotName))
        {
            Set(material, "Shader", "yCh_gear");
            Set(material, "TemplateType", "Normal");
            return true;
        }
        if (LooksLikeTeethSlot(slotName))
        {
            Set(material, "Shader", wweBaseModel ? "yCh_Teeth" : "yCh_skin");
            Set(material, "TemplateType", "Normal");
            return true;
        }
        if (LooksLikeAnyHairSlot(slotName, mtlsPath) || LooksLikeKnownHairMaterial(material))
        {
            Set(material, "Shader", "yCh_hair");
            Set(material, "TemplateType", "NewHair_ColorChanging");
            return true;
        }
        if (LooksLikeEyelashSlot(slotName))
        {
            Set(material, "Shader", "yCh_eye");
            Set(material, "TemplateType", "Eyelash");
            return true;
        }
        if (LooksLikeContactLensSlot(slotName))
        {
            Set(material, "Shader", "yCh_eye");
            Set(material, "TemplateType", "ContactLens");
            return true;
        }
        if (LooksLikeEyeSlot(slotName))
        {
            Set(material, "Shader", "yCh_eye");
            Set(material, "TemplateType", "Normal");
            return true;
        }
        return false;
    }

    static int ApplyTeethSkinFix(object materials, string mtlsPath, bool wweBaseModel)
    {
        IEnumerable values = materials as IEnumerable;
        if (values == null) return 0;
        ulong colorHash = 0;
        ulong normalHash = 0;
        foreach (object material in values)
        {
            string name = Convert.ToString(Get(material, "Name"));
            if (!LooksLikeBodySlot(name)) continue;
            if (colorHash == 0) colorHash = GetMaterialHash(material, "colorMap@ref");
            if (normalHash == 0) normalHash = GetMaterialHash(material, "nrMap@ref");
            if (normalHash == 0) normalHash = GetMaterialHash(material, "g_nrmMap@ref");
            if (normalHash == 0) normalHash = GetMaterialHash(material, "normalMap@ref");
            if (colorHash != 0 && normalHash != 0) break;
        }
        ulong bodyColor = ResolveFirstTextureHash(mtlsPath, "body_color");
        ulong bodyNormal = ResolveFirstTextureHash(mtlsPath, "body_nrm", "body_normal");
        if (bodyColor != 0) colorHash = bodyColor;
        if (bodyNormal != 0) normalHash = bodyNormal;
        int fixedCount = 0;
        foreach (object material in values)
        {
            string name = Convert.ToString(Get(material, "Name"));
            if (LooksLikeCustomGenericSlot(name)) continue;
            if (!LooksLikeTeethSlot(name)) continue;
            Set(material, "Shader", wweBaseModel ? "yCh_Teeth" : "yCh_skin");
            Set(material, "TemplateType", "Normal");
            ulong selectedColor = colorHash != 0 ? colorHash : GetMaterialHash(material, "colorMap@ref");
            ulong selectedNormal = normalHash != 0 ? normalHash : GetMaterialHash(material, "nrMap@ref");
            bool colorSet = TrySetMaterialHash(material, "colorMap@ref", selectedColor);
            bool normalSet = TrySetMaterialHash(material, "nrMap@ref", selectedNormal);
            normalSet |= TrySetMaterialHash(material, "g_nrmMap@ref", selectedNormal);
            normalSet |= TrySetMaterialHash(material, "normalMap@ref", selectedNormal);
            if (colorSet && normalSet) fixedCount++;
        }
        return fixedCount;
    }

    static void VerifyWweBaseTeeth(object materials, string mtlsPath, bool wweBaseModel)
    {
        if (!wweBaseModel) return;
        IEnumerable values = materials as IEnumerable;
        if (values == null) throw new InvalidDataException("The BaseModel MTLs has no readable material list");
        ulong expectedColor = ResolveFirstTextureHash(mtlsPath, "body_color");
        ulong expectedNormal = ResolveFirstTextureHash(mtlsPath, "body_nrm", "body_normal");
        if (expectedColor == 0) throw new FileNotFoundException("BaseModel teeth require Textures\\body_color.dds", "body_color.dds");
        int teethCount = 0;
        foreach (object material in values)
        {
            string name = Convert.ToString(Get(material, "Name"));
            if (!LooksLikeTeethSlot(name)) continue;
            teethCount++;
            string shader = Convert.ToString(Get(material, "Shader"));
            string template = Convert.ToString(Get(material, "TemplateType"));
            if (!String.Equals(shader, "yCh_Teeth", StringComparison.OrdinalIgnoreCase) || !String.Equals(template, "Normal", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("BaseModel teeth must use yCh_Teeth / Normal");
            ulong actualColor = GetMaterialHash(material, "colorMap@ref");
            if (actualColor != expectedColor) throw new InvalidDataException("BaseModel teeth are not bound to body_color");
            if (expectedNormal != 0)
            {
                ulong actualNormal = GetMaterialHash(material, "g_nrmMap@ref");
                if (actualNormal == 0) actualNormal = GetMaterialHash(material, "nrMap@ref");
                if (actualNormal == 0) actualNormal = GetMaterialHash(material, "normalMap@ref");
                if (actualNormal != expectedNormal) throw new InvalidDataException("BaseModel teeth are not bound to body_nrm");
            }
        }
        if (teethCount == 0) throw new InvalidDataException("The BaseModel MCD has no teeth material slot");
    }

    static int ApplySkinTextureFixes(object materials, string mtlsPath)
    {
        IEnumerable values = materials as IEnumerable;
        if (values == null) return 0;
        ulong bodyColor = 0;
        ulong bodyNormal = 0;
        ulong headColor = 0;
        ulong headNormal = 0;
        int fixedCount = 0;
        foreach (object material in values)
        {
            string name = Convert.ToString(Get(material, "Name"));
            if (LooksLikeBodySlot(name))
            {
                string key = GenericTextureKey(name);
                if (bodyColor == 0) bodyColor = ResolveFirstTextureHash(mtlsPath, key + "_color", key + "_diffuse", key + "_d", "body_color");
                if (bodyNormal == 0) bodyNormal = ResolveFirstTextureHash(mtlsPath, key + "_normal", key + "_nrm", key + "_n", "body_nrm", "body_normal");
                Set(material, "Shader", "yCh_skin");
                Set(material, "TemplateType", "Normal");
                bool colorSet = TrySetMaterialHash(material, "colorMap@ref", bodyColor);
                bool normalSet = TrySetMaterialHash(material, "nrMap@ref", bodyNormal);
                TrySetMaterialHash(material, "g_nrmMap@ref", bodyNormal);
                TrySetMaterialHash(material, "normalMap@ref", bodyNormal);
                if (colorSet || normalSet) fixedCount++;
            }
            else if (LooksLikeHeadSlot(name))
            {
                string key = GenericTextureKey(name);
                if (headColor == 0) headColor = ResolveFirstTextureHash(mtlsPath, key + "_color", key + "_diffuse", key + "_d", "head_color");
                if (headNormal == 0) headNormal = ResolveFirstTextureHash(mtlsPath, key + "_normal", key + "_nrm", key + "_n", "head_nrm", "head_normal");
                if (LooksLikeCustomHeadSlot(name)) NormalizeCustomHeadLiteralMaterial(material);
                else
                {
                    Set(material, "Shader", "yCh_skin");
                    Set(material, "TemplateType", "Normal");
                }
                bool colorSet = TrySetMaterialHash(material, "colorMap@ref", headColor);
                bool normalSet = TrySetMaterialHash(material, "nrMap@ref", headNormal);
                TrySetMaterialHash(material, "g_nrmMap@ref", headNormal);
                TrySetMaterialHash(material, "normalMap@ref", headNormal);
                if (colorSet || normalSet) fixedCount++;
            }
        }
        return fixedCount;
    }

    static int ApplyHairTextureFixes(object materials, string mtlsPath, bool preserveNativeShaders)
    {
        IEnumerable values = materials as IEnumerable;
        if (values == null) return 0;
        int fixedCount = 0;
        foreach (object material in values)
        {
            string name = Convert.ToString(Get(material, "Name"));
            if (LooksLikeFortniteHairAlphaSlot(name)) continue;
            if (LooksLikeCustomGenericSlot(name)) continue;
            if (!LooksLikeAnyHairMaterial(material, mtlsPath)) continue;
            string key = NormalizeSlotKey(name);
            string textureKey = NormalizeSlotKey(name, false);
            if (key == "combination") key = "combinations";
            if (textureKey == "combination") textureKey = "combinations";
            if (textureKey == "combination_alpha") textureKey = "combinations_alpha";
            if (!preserveNativeShaders)
            {
                Set(material, "Shader", "yCh_hair");
                Set(material, "TemplateType", "NewHair_ColorChanging");
            }
            string singularKey = key.Replace("combinations", "combination");
            string singularTextureKey = textureKey.Replace("combinations", "combination");
            bool alphaVariant = !String.Equals(textureKey, key, StringComparison.OrdinalIgnoreCase);
            bool combinationStyle = key.StartsWith("combination", StringComparison.OrdinalIgnoreCase);
            bool hairMapPair = String.Equals(key, "hair_rai", StringComparison.OrdinalIgnoreCase) || String.Equals(key, "hair_flow", StringComparison.OrdinalIgnoreCase);
            string flowStem;
            string comboStem;
            if (combinationStyle || hairMapPair)
            {
                flowStem = FindTextureStemNear(mtlsPath, textureKey + "_flow", singularTextureKey + "_flow", alphaVariant ? key + "_flow_alpha" : null, alphaVariant ? singularKey + "_flow_alpha" : null, key + "_flow", singularKey + "_flow", "hair_flow");
                if (flowStem == null && alphaVariant) flowStem = FindTextureStemByParts(mtlsPath, textureKey, "flow");
                if (flowStem == null && combinationStyle) flowStem = FindTextureStemByParts(mtlsPath, "combination", "flow");
                if (flowStem == null) flowStem = FindTextureStemByParts(mtlsPath, "hair", "flow");
                comboStem = FindTextureStemNear(mtlsPath, textureKey + "_rai", singularTextureKey + "_rai", alphaVariant ? key + "_rai_alpha" : null, alphaVariant ? singularKey + "_rai_alpha" : null, textureKey + "_combo", textureKey + "_root", textureKey + "_id", alphaVariant ? key + "_combo_alpha" : null, alphaVariant ? key + "_root_alpha" : null, alphaVariant ? key + "_id_alpha" : null, alphaVariant ? singularKey + "_combo_alpha" : null, alphaVariant ? singularKey + "_root_alpha" : null, alphaVariant ? singularKey + "_id_alpha" : null, key + "_rai", singularKey + "_rai", key + "_combo", key + "_root", key + "_id", "hair_rai");
                if (comboStem == null && alphaVariant) comboStem = FindTextureStemByParts(mtlsPath, textureKey, "rai", "combo", "root", "id");
                if (comboStem == null && combinationStyle) comboStem = FindTextureStemByParts(mtlsPath, "combination", "rai", "combo", "root", "id");
                if (comboStem == null) comboStem = FindTextureStemByParts(mtlsPath, "hair", "rai");
            }
            else
            {
                flowStem = FindTextureStemNear(mtlsPath, textureKey + "_flow", alphaVariant ? key + "_flow_alpha" : null, key + "_flow", singularKey + "_flow");
                if (flowStem == null && alphaVariant) flowStem = FindTextureStemByParts(mtlsPath, textureKey, "flow");
                if (flowStem == null) flowStem = FindTextureStemByParts(mtlsPath, key, "flow");
                comboStem = FindTextureStemNear(mtlsPath, textureKey + "_rai", alphaVariant ? key + "_rai_alpha" : null, textureKey + "_combo", textureKey + "_root", textureKey + "_id", alphaVariant ? key + "_combo_alpha" : null, alphaVariant ? key + "_root_alpha" : null, alphaVariant ? key + "_id_alpha" : null, key + "_rai", singularKey + "_rai", key + "_combo", key + "_root", key + "_id");
                if (comboStem == null && alphaVariant) comboStem = FindTextureStemByParts(mtlsPath, textureKey, "rai", "combo", "root", "id");
                if (comboStem == null) comboStem = FindTextureStemByParts(mtlsPath, key, "rai", "combo", "root", "id");
            }
            ulong flowHash = flowStem == null ? 0 : TryResolveTextureHash(flowStem, mtlsPath);
            ulong comboHash = comboStem == null ? 0 : TryResolveTextureHash(comboStem, mtlsPath);
            TrySetMaterialHash(material, "flowMap@ref", flowHash);
            TrySetMaterialHash(material, "g_comboMap@ref", comboHash);
            fixedCount++;
        }
        return fixedCount;
    }

    static int VerifyFortniteAlphaHairMaterials(object materials, string mtlsPath)
    {
        IEnumerable values = materials as IEnumerable;
        if (values == null) return 0;
        int verifiedCount = 0;
        foreach (object material in values)
        {
            string name = Convert.ToString(Get(material, "Name"));
            if (!LooksLikeFortniteHairAlphaSlot(name)) continue;
            string shader = Convert.ToString(Get(material, "Shader"));
            string template = Convert.ToString(Get(material, "TemplateType"));
            if (!String.Equals(shader, "yCh_trans", StringComparison.OrdinalIgnoreCase) || !String.Equals(template, "Normal", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException("Fortnite alpha hair material '" + name + "' did not retain yCh_trans / Normal after save");
            }
            string key = GenericTextureKey(name);
            ulong expectedColor = ResolveFirstTextureHash(mtlsPath, key + "_color", key + "_diffuse", key + "_d");
            ulong actualColor = GetMaterialHash(material, "colorMap@ref");
            if (expectedColor == 0)
            {
                throw new InvalidDataException("Fortnite alpha hair material '" + name + "' has no converted color texture beside the MTLs");
            }
            if (actualColor == 0 || actualColor != expectedColor)
            {
                throw new InvalidDataException("Fortnite alpha hair material '" + name + "' did not retain its BC3 colorMap texture reference after save");
            }
            ulong expectedNormal = ResolveFirstTextureHash(mtlsPath, key + "_normal", key + "_nrm", key + "_n");
            ulong actualNormalG = GetMaterialHash(material, "g_nrmMap@ref");
            ulong actualNormalNr = GetMaterialHash(material, "nrMap@ref");
            ulong actualNormalMap = GetMaterialHash(material, "normalMap@ref");
            ulong actualNormal = actualNormalG != 0 ? actualNormalG : (actualNormalNr != 0 ? actualNormalNr : actualNormalMap);
            string normalState = "none";
            if (expectedNormal == 0) normalState = "not supplied";
            else if (actualNormalG == expectedNormal) normalState = "g_nrmMap@ref";
            else if (actualNormalNr == expectedNormal) normalState = "nrMap@ref";
            else if (actualNormalMap == expectedNormal) normalState = "normalMap@ref";
            else if (actualNormal == 0) normalState = "optional normal omitted by template";
            else normalState = "optional normal remapped by template";
            messages.Add("HAIR_ALPHA " + name + " | shader=" + shader + " | template=" + template + " | colorMap@ref=0x" + actualColor.ToString("X16") + " | normal=" + normalState + " | normalMap@ref=0x" + actualNormal.ToString("X16"));
            verifiedCount++;
        }
        return verifiedCount;
    }

    static void VerifyHairShaderLocks(object materials, string mtlsPath, Dictionary<string, object> preservedHairSources)
    {
        IEnumerable values = materials as IEnumerable;
        if (values == null) return;
        foreach (object material in values)
        {
            string name = Convert.ToString(Get(material, "Name"));
            if (LooksLikeFortniteHairAlphaSlot(name)) continue;
            if (LooksLikeCustomGenericSlot(name)) continue;
            string shader = Convert.ToString(Get(material, "Shader"));
            string template = Convert.ToString(Get(material, "TemplateType"));
            bool shouldBeHair = LooksLikeAnyHairSlot(name, mtlsPath) || LooksLikeKnownHairMaterial(material);
            if (!shouldBeHair) continue;
            object preservedSource = null;
            if (preservedHairSources != null) preservedHairSources.TryGetValue(CleanMaterialName(name).ToLowerInvariant(), out preservedSource);
            string expectedShader = preservedSource == null ? "yCh_hair" : Convert.ToString(Get(preservedSource, "Shader"));
            string expectedTemplate = preservedSource == null ? "NewHair_ColorChanging" : Convert.ToString(Get(preservedSource, "TemplateType"));
            if (!String.Equals(shader, expectedShader, StringComparison.OrdinalIgnoreCase) || !String.Equals(template, expectedTemplate, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException("Hair material '" + name + "' did not retain " + expectedShader + " / " + expectedTemplate + " after save");
            }
        }
    }

    static object RicherDetailedHairMaterial(object current, object candidate)
    {
        if (!LooksLikeKnownHairMaterial(candidate) || MaterialPropertyCount(candidate) < 20) return current;
        if (current == null || MaterialPropertyCount(candidate) > MaterialPropertyCount(current)) return candidate;
        return current;
    }

    static void CaptureDetailedHairMaterials(object file, Dictionary<string, object> exact, Dictionary<string, object> normalized)
    {
        if (!preserveWweHair || file == null) return;
        IEnumerable values = Get(file, "Materials") as IEnumerable;
        if (values == null) return;
        foreach (object material in values)
        {
            string name = Convert.ToString(Get(material, "Name"));
            if (!LooksLikeAnyHairSlot(name, "") && !LooksLikeKnownHairMaterial(material)) continue;
            object clone = Call(material, "Clone");
            string exactKey = CleanMaterialName(name).ToLowerInvariant();
            string normalizedKey = MaterialKey(name);
            object existing = null;
            exact.TryGetValue(exactKey, out existing);
            exact[exactKey] = RicherDetailedHairMaterial(existing, clone);
            existing = null;
            normalized.TryGetValue(normalizedKey, out existing);
            normalized[normalizedKey] = RicherDetailedHairMaterial(existing, clone);
        }
    }

    static int RebuildInvalidHairMaterials(object file, object databaseService, string mtlsPath, string formatKey, Dictionary<string, object> preservedHairSources)
    {
        IEnumerable values = Get(file, "Materials") as IEnumerable;
        if (values == null) return 0;
        object rebuilt = NewMaterialList();
        int rebuiltCount = 0;
        foreach (object current in values)
        {
            string name = Convert.ToString(Get(current, "Name"));
            string shader = Convert.ToString(Get(current, "Shader"));
            string template = Convert.ToString(Get(current, "TemplateType"));
            bool shouldBeHair = !LooksLikeFortniteHairAlphaSlot(name) && !LooksLikeCustomGenericSlot(name) && (LooksLikeAnyHairSlot(name, mtlsPath) || LooksLikeKnownHairMaterial(current));
            object preservedSource = null;
            if (preservedHairSources != null) preservedHairSources.TryGetValue(CleanMaterialName(name).ToLowerInvariant(), out preservedSource);
            bool incomplete = preservedSource != null && MaterialPropertyCount(current) < MaterialPropertyCount(preservedSource);
            string expectedShader = preservedSource == null ? "yCh_hair" : Convert.ToString(Get(preservedSource, "Shader"));
            string expectedTemplate = preservedSource == null ? "NewHair_ColorChanging" : Convert.ToString(Get(preservedSource, "TemplateType"));
            if (shouldBeHair && (incomplete || !String.Equals(shader, expectedShader, StringComparison.OrdinalIgnoreCase) || !String.Equals(template, expectedTemplate, StringComparison.OrdinalIgnoreCase)))
            {
                ulong flowHash = GetMaterialHash(current, "flowMap@ref");
                ulong comboHash = GetMaterialHash(current, "g_comboMap@ref");
                object replacement = preservedSource == null ? Call(databaseService, "CreateMaterial", name, "yCh_hair", "NewHair_ColorChanging", formatKey) : Call(preservedSource, "Clone");
                Set(replacement, "Name", name);
                Set(replacement, "Shader", expectedShader);
                Set(replacement, "TemplateType", expectedTemplate);
                if (flowHash == 0) flowHash = GetMaterialHash(replacement, "flowMap@ref");
                if (comboHash == 0) comboHash = GetMaterialHash(replacement, "g_comboMap@ref");
                TrySetMaterialHash(replacement, "flowMap@ref", flowHash);
                TrySetMaterialHash(replacement, "g_comboMap@ref", comboHash);
                AddToList(rebuilt, replacement);
                rebuiltCount++;
            }
            else
            {
                AddToList(rebuilt, current);
            }
        }
        if (rebuiltCount > 0) Set(file, "Materials", rebuilt);
        return rebuiltCount;
    }

    static void VerifyPreservedWweHairDetails(object materials, Dictionary<string, object> preservedHairSources)
    {
        if (preservedHairSources == null || preservedHairSources.Count == 0) return;
        Dictionary<string, object> actual = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        IEnumerable values = materials as IEnumerable;
        if (values != null)
        {
            foreach (object material in values)
            {
                string name = CleanMaterialName(Convert.ToString(Get(material, "Name"))).ToLowerInvariant();
                actual[name] = material;
            }
        }
        foreach (KeyValuePair<string, object> entry in preservedHairSources)
        {
            object material = null;
            if (!actual.TryGetValue(entry.Key, out material)) throw new InvalidDataException("Preserved WWE hair material '" + entry.Key + "' is missing after save");
            int expected = MaterialPropertyCount(entry.Value);
            int found = MaterialPropertyCount(material);
            if (found < expected) throw new InvalidDataException("Preserved WWE hair material '" + entry.Key + "' lost parameters after save (expected at least " + expected + ", found " + found + ")");
        }
    }


    static HashSet<string> ReadLiteralColorSlots(string mtlsPath)
    {
        HashSet<string> result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        string directory = Path.GetDirectoryName(mtlsPath);
        if (String.IsNullOrWhiteSpace(directory)) return result;
        string path = Path.Combine(directory, "Fortnite_Literal_Materials.txt");
        if (!File.Exists(path)) return result;
        try
        {
            string[] lines = File.ReadAllLines(path);
            for (int i = 0; i < lines.Length; i++)
            {
                string value = CleanMaterialName(lines[i]);
                if (!String.IsNullOrWhiteSpace(value)) result.Add(NormalizeSlotKey(value));
            }
        }
        catch { }
        return result;
    }

    static void NormalizeLiteralColorMaterial(object material, string slotName, string mtlsPath)
    {
        NormalizeCustomHeadLiteralMaterial(material);
        SetExistingMaterialValue(material, "g_nrmMap@ref", 0UL);
        SetExistingMaterialValue(material, "normalMap@ref", 0UL);
        SetExistingMaterialValue(material, "nrMap@ref", 0UL);
        SetExistingMaterialValue(material, "g_mPixMsk@ref", 0UL);
        SetExistingMaterialValue(material, "metalMap@ref", 0UL);
        SetExistingMaterialValue(material, "roughnessMap@ref", 0UL);
        SetExistingMaterialValue(material, "occlusionMap@ref", 0UL);
        SetExistingMaterialValue(material, "specularMap@ref", 0UL);
        SetExistingMaterialValue(material, "g_nrmMap", "");
        SetExistingMaterialValue(material, "normalMap", "");
        SetExistingMaterialValue(material, "roughnessMap", "");
        SetExistingMaterialValue(material, "metalMap", "");
        SetExistingMaterialValue(material, "occlusionMap", "");
        SetExistingMaterialValue(material, "specularMap", "");
        SetExistingMaterialValue(material, "g_mPixMsk", "");
        SetExistingMaterialValue(material, "g_mPixMsk2", "");
        string key = GenericTextureKey(slotName);
        string colorStem = FindTextureStemNear(mtlsPath, key + "_color", key + "_diffuse", key + "_d");
        if (!String.IsNullOrWhiteSpace(colorStem))
        {
            ulong colorHash = TryResolveTextureHash(colorStem, mtlsPath);
            TrySetMaterialHash(material, "colorMap@ref", colorHash);
            SetExistingMaterialValue(material, "colorMap", colorStem);
        }
    }

    static int ApplyLiteralColorFixes(object materials, string mtlsPath)
    {
        IEnumerable values = materials as IEnumerable;
        if (values == null) return 0;
        HashSet<string> literalSlots = ReadLiteralColorSlots(mtlsPath);
        if (literalSlots.Count == 0) return 0;
        int fixedCount = 0;
        foreach (object material in values)
        {
            string name = Convert.ToString(Get(material, "Name"));
            if (!literalSlots.Contains(NormalizeSlotKey(name))) continue;
            NormalizeLiteralColorMaterial(material, name, mtlsPath);
            fixedCount++;
        }
        return fixedCount;
    }

    static int ApplyGenericTextureFixes(object materials, string mtlsPath)
    {
        IEnumerable values = materials as IEnumerable;
        if (values == null) return 0;
        int fixedCount = 0;
        foreach (object material in values)
        {
            string name = Convert.ToString(Get(material, "Name"));
            string key = GenericTextureKey(name);
            if (!key.StartsWith("custom_", StringComparison.OrdinalIgnoreCase)) continue;
            if (LooksLikeCustomSkinSlot(name)) continue;
            if (LooksLikeEyeSlot(name) || LooksLikeEyelashSlot(name) || LooksLikeContactLensSlot(name)) continue;
            bool glass = LooksLikeFortniteGlassSlot(name);
            bool hairAlpha = LooksLikeFortniteHairAlphaSlot(name);
            bool transparent = glass || hairAlpha;
            bool linework = LooksLikeCustomLineworkSlot(name);
            if (LooksLikeFortniteToonFaceSurfaceSlot(name))
            {
                NormalizeFortniteToonFaceSurfaceMaterial(material);
            }
            else if (linework)
            {
                if (LooksLikeCustomHairLineworkSlot(name)) NormalizeCustomHairLineworkMaterial(material);
                else NormalizeCustomLineworkMaterial(material);
            }
            else
            {
                Set(material, "Shader", transparent ? "yCh_trans" : "yCh_gear");
                Set(material, "TemplateType", "Normal");
            }
            ulong colorHash = ResolveFirstTextureHash(mtlsPath, key + "_color", key + "_diffuse", key + "_d");
            ulong normalHash = ResolveFirstTextureHash(mtlsPath, key + "_normal", key + "_nrm", key + "_n");
            bool changed = false;
            changed |= TrySetMaterialHash(material, "colorMap@ref", colorHash);
            changed |= TrySetMaterialHash(material, "g_nrmMap@ref", normalHash);
            changed |= TrySetMaterialHash(material, "nrMap@ref", normalHash);
            changed |= TrySetMaterialHash(material, "normalMap@ref", normalHash);
            if (glass)
            {
                EnsureMaterialProperty(material, "g_specIntensity", "Float", 0.75f);
                EnsureMaterialProperty(material, "g_fSpecLevel", "Float", 0.7f);
                EnsureMaterialProperty(material, "g_fSpecRough", "Float", 0.08f);
            }
            if (changed) fixedCount++;
        }
        return fixedCount;
    }

    static int ApplyEyeTextureFixes(object materials, string mtlsPath)
    {
        IEnumerable values = materials as IEnumerable;
        if (values == null) return 0;
        int fixedCount = 0;
        foreach (object material in values)
        {
            string name = Convert.ToString(Get(material, "Name"));
            string key = GenericTextureKey(name);
            bool changed = false;
            if (LooksLikeEyelashSlot(name))
            {
                ulong colorHash = ResolveFirstTextureHash(mtlsPath, key + "_color", key + "_diffuse", key + "_d", "eyelashes_color", "eyelash_color", "lashes_color");
                changed |= TrySetMaterialHash(material, "colorMap@ref", colorHash);
            }
            else if (LooksLikeEyeSlot(name))
            {
                ulong colorHash = ResolveFirstTextureHash(mtlsPath, key + "_color", key + "_diffuse", key + "_d", "eye_color", "eyes_color");
                ulong normalHash = ResolveFirstTextureHash(mtlsPath, key + "_normal", key + "_nrm", key + "_n", "eye_nrm", "eyes_nrm", "eye_normal");
                changed |= TrySetMaterialHash(material, "colorMap@ref", colorHash);
                changed |= TrySetMaterialHash(material, "g_nrmMap@ref", normalHash);
                changed |= TrySetMaterialHash(material, "nrMap@ref", normalHash);
                changed |= TrySetMaterialHash(material, "normalMap@ref", normalHash);
            }
            if (changed) fixedCount++;
        }
        return fixedCount;
    }

    static object EmptyPresetDictionary()
    {
        Type presetType = FindType("MaterialEditor.Models.ShaderPreset");
        Type dictionaryType = typeof(Dictionary<,>).MakeGenericType(typeof(string), presetType);
        return Activator.CreateInstance(dictionaryType);
    }

    static object TupleItem(object value, string name)
    {
        FieldInfo field = value.GetType().GetField(name);
        if (field != null) return field.GetValue(value);
        PropertyInfo property = value.GetType().GetProperty(name);
        return property == null ? null : property.GetValue(value, null);
    }

    static MethodInfo FindMethod(Type type, string name, bool isStatic, object[] args)
    {
        BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | (isStatic ? BindingFlags.Static : BindingFlags.Instance);
        MethodInfo[] methods = type.GetMethods(flags);
        for (int i = 0; i < methods.Length; i++)
        {
            MethodInfo method = methods[i];
            if (method.Name != name) continue;
            ParameterInfo[] parameters = method.GetParameters();
            if (parameters.Length != args.Length) continue;
            bool compatible = true;
            for (int j = 0; j < parameters.Length; j++)
            {
                object value = args[j];
                Type parameterType = parameters[j].ParameterType;
                if (value == null)
                {
                    if (parameterType.IsValueType && Nullable.GetUnderlyingType(parameterType) == null)
                    {
                        compatible = false;
                        break;
                    }
                }
                else if (!parameterType.IsInstanceOfType(value))
                {
                    compatible = false;
                    break;
                }
            }
            if (compatible) return method;
        }
        throw new MissingMethodException(type.FullName, name + "(" + args.Length + ")");
    }

    static object Call(object target, string name, params object[] args)
    {
        return FindMethod(target.GetType(), name, false, args).Invoke(target, args);
    }

    static object Get(object target, string property)
    {
        PropertyInfo info = target.GetType().GetProperty(property, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        if (info == null) throw new MissingMemberException(target.GetType().FullName, property);
        return info.GetValue(target, null);
    }

    static void Set(object target, string property, object value)
    {
        PropertyInfo info = target.GetType().GetProperty(property, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        if (info == null) throw new MissingMemberException(target.GetType().FullName, property);
        object converted = value;
        if (value != null && !info.PropertyType.IsInstanceOfType(value))
        {
            Type destination = Nullable.GetUnderlyingType(info.PropertyType) ?? info.PropertyType;
            if (destination.IsEnum) converted = Enum.ToObject(destination, value);
            else converted = Convert.ChangeType(value, destination);
        }
        info.SetValue(target, converted, null);
    }

    static bool TrySetObjectProperty(object target, string property, object value)
    {
        try
        {
            PropertyInfo info = target.GetType().GetProperty(property, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (info == null || !info.CanWrite) return false;
            object converted = value;
            if (value != null && !info.PropertyType.IsInstanceOfType(value))
            {
                Type destination = Nullable.GetUnderlyingType(info.PropertyType) ?? info.PropertyType;
                if (destination.IsEnum) converted = Enum.ToObject(destination, value);
                else converted = Convert.ChangeType(value, destination);
            }
            info.SetValue(target, converted, null);
            return true;
        }
        catch { return false; }
    }

    static void WriteMaterialFile(object mtlService, object jmtlService, object file, string mtlsPath, bool inline)
    {
        if (inline)
        {
            try { Call(mtlService, "WriteFile", file, mtlsPath); }
            catch (MissingMethodException) { Call(mtlService, "WriteFile", file); }
        }
        else Call(jmtlService, "WriteDirectory", file, mtlsPath);
    }

    static object ReopenMaterialFile(object mtlService, object jmtlService, string mtlsPath, string materialsDirectory, bool inline)
    {
        object file = Call(mtlService, "ReadFile", mtlsPath);
        if (!inline) file = Call(jmtlService, "MergeJmtlIntoMtls", file, materialsDirectory);
        return file;
    }

    static int RemoveInlineSlotJmtls(string materialsDirectory, List<string> slots)
    {
        if (!Directory.Exists(materialsDirectory)) return 0;
        int removed = 0;
        for (int i = 0; i < slots.Count; i++)
        {
            string path = Path.Combine(materialsDirectory, CleanMaterialName(slots[i]) + ".jmtl");
            if (!File.Exists(path)) continue;
            File.Delete(path);
            removed++;
        }
        return removed;
    }

    static object GetField(object target, string field)
    {
        FieldInfo info = target.GetType().GetField(field, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        if (info == null) throw new MissingFieldException(target.GetType().FullName, field);
        return info.GetValue(target);
    }

    static int CountEnumerable(object value)
    {
        int count = 0;
        IEnumerable enumerable = value as IEnumerable;
        if (enumerable == null) return 0;
        foreach (object item in enumerable) count++;
        return count;
    }

    static List<string> NormalizeRoots(string root, string selectionFile)
    {
        List<string> roots = new List<string>();
        HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (!String.IsNullOrWhiteSpace(selectionFile) && File.Exists(selectionFile))
        {
            string[] lines = File.ReadAllLines(selectionFile);
            for (int i = 0; i < lines.Length; i++)
            {
                string value = lines[i].Trim().Trim('"');
                if (value.Length == 0 || !Directory.Exists(value)) continue;
                string full = Path.GetFullPath(value);
                if (seen.Add(full)) roots.Add(full);
            }
        }
        if (roots.Count == 0 && !String.IsNullOrWhiteSpace(root) && Directory.Exists(root))
        {
            string full = Path.GetFullPath(root);
            if (seen.Add(full)) roots.Add(full);
        }
        return roots;
    }

    static List<string> ReadFileList(string path, string extension)
    {
        List<string> result = new List<string>();
        HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (String.IsNullOrWhiteSpace(path) || !File.Exists(path)) return result;
        string[] lines = File.ReadAllLines(path);
        for (int i = 0; i < lines.Length; i++)
        {
            string value = lines[i].Trim().Trim('"');
            if (!File.Exists(value)) continue;
            if (!String.Equals(Path.GetExtension(value), extension, StringComparison.OrdinalIgnoreCase)) continue;
            string full = Path.GetFullPath(value);
            if (seen.Add(full)) result.Add(full);
        }
        result.Sort(StringComparer.OrdinalIgnoreCase);
        return result;
    }

    static List<string> FindFiles(List<string> roots, string extension)
    {
        List<string> result = new List<string>();
        HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        for (int r = 0; r < roots.Count; r++)
        {
            string[] files = Directory.GetFiles(roots[r], "*", SearchOption.AllDirectories);
            for (int i = 0; i < files.Length; i++)
            {
                if (!String.Equals(Path.GetExtension(files[i]), extension, StringComparison.OrdinalIgnoreCase)) continue;
                string full = Path.GetFullPath(files[i]);
                if (seen.Add(full)) result.Add(full);
            }
        }
        result.Sort(StringComparer.OrdinalIgnoreCase);
        return result;
    }

    static Exception Actual(Exception exception)
    {
        while (exception is TargetInvocationException && exception.InnerException != null) exception = exception.InnerException;
        return exception;
    }

    static bool GenerateForMcd(string mcdPath)
    {
        string directory = Path.GetDirectoryName(mcdPath);
        string mtlsPath = Path.Combine(directory, Path.GetFileNameWithoutExtension(mcdPath) + ".mtls");
        string materialsDirectory = Path.Combine(directory, "Materials");
        bool wweBaseModel = preserveWweHair && wweBaseModels.Contains(Path.GetFullPath(mcdPath));
        try
        {
            List<string> slots = ReadMaterialSlots(mcdPath);
            if (slots.Count == 0) throw new InvalidDataException("The MCD contains no readable material slots");

            object mtlService = Create("MaterialEditor.Services.MtlFileService");
            object conversionService = Create("MaterialEditor.Services.ConversionService");
            object jmtlService = Create("MaterialEditor.Services.JmtlFileService");
            object databaseService = Create("MaterialEditor.Services.ShaderDatabaseService", mtlService);
            string databasePath = Path.Combine(editorDirectory, "shader_database.json");
            string compressedDatabasePath = databasePath + ".gz";
            if (!File.Exists(databasePath) && !File.Exists(compressedDatabasePath)) throw new FileNotFoundException("shader_database.json or shader_database.json.gz was not found", databasePath);
            bool databaseLoaded = Convert.ToBoolean(Call(databaseService, "LoadDatabase", databasePath, false));
            if (!databaseLoaded) throw new InvalidDataException("Material Editor could not load its shader database");
            object repairService = Create("MaterialEditor.Services.MaterialRepairService", databaseService);
            object targetGame = Enum.Parse(FindType("MaterialEditor.Models.GameTarget"), "WWE_2K26");
            object repairMode = Enum.Parse(FindType("MaterialEditor.Services.RepairMode"), "AddOnly");
            bool inlineWweMaterials = preserveWweHair;
            string formatKey = inlineWweMaterials ? "V6_V4_INLINE" : "V6_V4_JMTL";

            string referenceNote;
            string referenceMtls = PickReferenceMtls(mcdPath, mtlsPath, mtlService, slots, out referenceNote);
            object converted;
            Dictionary<string, object> byExactName = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, object> byName = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, object> byVariantName = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, object> liveByVariantName = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, object> rawWweHairByExactName = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, object> rawWweHairByName = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, object> preservedWweHairSources = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            if (File.Exists(mtlsPath))
            {
                try
                {
                    string liveMaterials = ReferenceMaterialsDirectory(mtlsPath, directory);
                    object rawLiveSource = Call(mtlService, "ReadFile", mtlsPath);
                    CaptureDetailedHairMaterials(rawLiveSource, rawWweHairByExactName, rawWweHairByName);
                    object liveSource = LoadReferenceFile(mtlService, jmtlService, mtlsPath, liveMaterials);
                    CaptureDetailedHairMaterials(liveSource, rawWweHairByExactName, rawWweHairByName);
                    liveSource = Call(conversionService, "ConvertToTarget", liveSource, targetGame);
                    IEnumerable liveMaterialsList = Get(liveSource, "Materials") as IEnumerable;
                    if (liveMaterialsList != null)
                    {
                        foreach (object liveMaterial in liveMaterialsList)
                        {
                            string liveName = Convert.ToString(Get(liveMaterial, "Name"));
                            string liveKey = NormalizeSlotKey(liveName, false);
                            object existingLive = null;
                            if (!liveByVariantName.TryGetValue(liveKey, out existingLive) || MaterialPropertyCount(liveMaterial) > MaterialPropertyCount(existingLive)) liveByVariantName[liveKey] = liveMaterial;
                        }
                    }
                }
                catch { }
            }
            if (referenceMtls != null)
            {
                string referenceMaterials = ReferenceMaterialsDirectory(referenceMtls, directory);
                object rawSource = Call(mtlService, "ReadFile", referenceMtls);
                CaptureDetailedHairMaterials(rawSource, rawWweHairByExactName, rawWweHairByName);
                object source = LoadReferenceFile(mtlService, jmtlService, referenceMtls, referenceMaterials);
                CaptureDetailedHairMaterials(source, rawWweHairByExactName, rawWweHairByName);
                converted = Call(conversionService, "ConvertToTarget", source, targetGame);
                IEnumerable sourceMaterials = Get(converted, "Materials") as IEnumerable;
                if (sourceMaterials != null)
                {
                    foreach (object material in sourceMaterials)
                    {
                        string name = Convert.ToString(Get(material, "Name"));
                        string exactKey = CleanMaterialName(name).ToLowerInvariant();
                        string key = MaterialKey(name);
                        if (!byExactName.ContainsKey(exactKey)) byExactName.Add(exactKey, material);
                        if (!byName.ContainsKey(key)) byName.Add(key, material);
                        string variantKey = NormalizeSlotKey(name, false);
                        object existingVariant = null;
                        if (!byVariantName.TryGetValue(variantKey, out existingVariant) || MaterialPropertyCount(material) > MaterialPropertyCount(existingVariant)) byVariantName[variantKey] = material;
                    }
                }
            }
            else
            {
                try
                {
                    object viewModel = Activator.CreateInstance(FindType("MaterialEditor.ViewModels.MainWindowViewModel"));
                    Task initializationTask = (Task)Call(viewModel, "InitializeAsync");
                    initializationTask.GetAwaiter().GetResult();
                    Set(viewModel, "SelectedGameTarget", targetGame);
                    Set(viewModel, "AutoSyncTextureRefs", true);
                    Task importTask = (Task)Call(viewModel, "ImportMeshesFromMdlPathAsync", mcdPath);
                    importTask.GetAwaiter().GetResult();
                    converted = Get(viewModel, "CurrentFile");
                    if (converted == null) throw new InvalidDataException("Material Editor did not create a material file from the MCD");
                    Set(converted, "FilePath", mtlsPath);
                    Set(converted, "JmtlSourceDir", materialsDirectory);
                    Call(viewModel, "SyncMaterialsToFile");
                    IEnumerable importedMaterials = Get(converted, "Materials") as IEnumerable;
                    if (importedMaterials != null)
                    {
                        foreach (object material in importedMaterials)
                        {
                            string name = Convert.ToString(Get(material, "Name"));
                            string exactKey = CleanMaterialName(name).ToLowerInvariant();
                            string key = MaterialKey(name);
                            if (!byExactName.ContainsKey(exactKey)) byExactName.Add(exactKey, material);
                            if (!byName.ContainsKey(key)) byName.Add(key, material);
                            string variantKey = NormalizeSlotKey(name, false);
                            object existingVariant = null;
                            if (!byVariantName.TryGetValue(variantKey, out existingVariant) || MaterialPropertyCount(material) > MaterialPropertyCount(existingVariant)) byVariantName[variantKey] = material;
                        }
                    }
                    referenceNote = "Material Editor MCD import";
                }
                catch (Exception viewException)
                {
                    converted = Create("MaterialEditor.Models.MtlFile");
                    referenceNote = "shader-database fallback (" + Actual(viewException).Message + ")";
                }
            }

            object ordered = NewMaterialList();
            int preservedCount = 0;
            int generatedCount = 0;
            int forcedOverrides = 0;
            int omittedEyeOverlays = 0;
            for (int i = 0; i < slots.Count; i++)
            {
                string slotName = slots[i];
                if (LooksLikeEyeOverlaySlot(slotName))
                {
                    omittedEyeOverlays++;
                    continue;
                }
                object material;
                object matched = null;
                string exactSlotKey = CleanMaterialName(slotName).ToLowerInvariant();
                bool hasMatched = byExactName.TryGetValue(exactSlotKey, out matched) || byName.TryGetValue(MaterialKey(slotName), out matched);
                object preservedWweHairMaterial = null;
                if (inlineWweMaterials && !LooksLikeFortniteHairAlphaSlot(slotName) && !LooksLikeCustomGenericSlot(slotName) && (LooksLikeAnyHairSlot(slotName, mtlsPath) || (hasMatched && LooksLikeKnownHairMaterial(matched))))
                {
                    object candidate = null;
                    rawWweHairByExactName.TryGetValue(exactSlotKey, out candidate);
                    preservedWweHairMaterial = RicherDetailedHairMaterial(preservedWweHairMaterial, candidate);
                    candidate = null;
                    rawWweHairByName.TryGetValue(MaterialKey(slotName), out candidate);
                    preservedWweHairMaterial = RicherDetailedHairMaterial(preservedWweHairMaterial, candidate);
                    candidate = null;
                    byVariantName.TryGetValue(NormalizeSlotKey(slotName, false), out candidate);
                    preservedWweHairMaterial = RicherDetailedHairMaterial(preservedWweHairMaterial, candidate);
                    candidate = null;
                    liveByVariantName.TryGetValue(NormalizeSlotKey(slotName, false), out candidate);
                    preservedWweHairMaterial = RicherDetailedHairMaterial(preservedWweHairMaterial, candidate);
                }
                if (LooksLikeFortniteGlassSlot(slotName) || LooksLikeFortniteHairAlphaSlot(slotName))
                {
                    material = Call(databaseService, "CreateMaterial", slotName, "yCh_trans", "Normal", formatKey);
                    generatedCount++;
                }
                else if (LooksLikeCustomHeadSlot(slotName))
                {
                    material = Call(databaseService, "CreateMaterial", slotName, "yCh_gear", "Normal", formatKey);
                    NormalizeCustomHeadLiteralMaterial(material);
                    generatedCount++;
                }
                else if (LooksLikeCustomBodySlot(slotName))
                {
                    material = Call(databaseService, "CreateMaterial", slotName, "yCh_skin", "Normal", formatKey);
                    generatedCount++;
                }
                else if (LooksLikeFortniteToonFaceSurfaceSlot(slotName))
                {
                    material = Call(databaseService, "CreateMaterial", slotName, "yCh_gear", "Normal", formatKey);
                    NormalizeFortniteToonFaceSurfaceMaterial(material);
                    generatedCount++;
                }
                else if (LooksLikeCustomLineworkSlot(slotName))
                {
                    if (LooksLikeCustomHairLineworkSlot(slotName))
                    {
                        material = Call(databaseService, "CreateMaterial", slotName, "yCh_gear", "Normal", formatKey);
                        NormalizeCustomHairLineworkMaterial(material);
                    }
                    else
                    {
                        material = Call(databaseService, "CreateMaterial", slotName, "yCh_eye", "Normal", formatKey);
                        NormalizeCustomLineworkMaterial(material);
                    }
                    generatedCount++;
                }
                else if (LooksLikeCustomGenericSlot(slotName))
                {
                    material = Call(databaseService, "CreateMaterial", slotName, "yCh_gear", "Normal", formatKey);
                    generatedCount++;
                }
                else if (LooksLikeTeethSlot(slotName))
                {
                    material = Call(databaseService, "CreateMaterial", slotName, wweBaseModel ? "yCh_Teeth" : "yCh_skin", "Normal", formatKey);
                    generatedCount++;
                }
                else if (LooksLikeEyelashSlot(slotName))
                {
                    material = Call(databaseService, "CreateMaterial", slotName, "yCh_eye", "Eyelash", formatKey);
                    generatedCount++;
                }
                else if (LooksLikeContactLensSlot(slotName))
                {
                    material = Call(databaseService, "CreateMaterial", slotName, "yCh_eye", "ContactLens", formatKey);
                    generatedCount++;
                }
                else if (LooksLikeEyeSlot(slotName))
                {
                    material = Call(databaseService, "CreateMaterial", slotName, "yCh_eye", "Normal", formatKey);
                    generatedCount++;
                }
                else if (preservedWweHairMaterial != null)
                {
                    material = Call(preservedWweHairMaterial, "Clone");
                    preservedWweHairSources[exactSlotKey] = Call(preservedWweHairMaterial, "Clone");
                    preservedCount++;
                }
                else if (LooksLikeAnyHairSlot(slotName, mtlsPath) || (hasMatched && LooksLikeKnownHairMaterial(matched)))
                {
                    material = Call(databaseService, "CreateMaterial", slotName, "yCh_hair", "NewHair_ColorChanging", formatKey);
                    generatedCount++;
                }
                else if (hasMatched)
                {
                    material = Call(matched, "Clone");
                    preservedCount++;
                }
                else
                {
                    material = CreateSuggestedMaterial(databaseService, slotName, formatKey);
                    if (LooksLikeKnownHairMaterial(material))
                    {
                        material = Call(databaseService, "CreateMaterial", slotName, "yCh_hair", "NewHair_ColorChanging", formatKey);
                    }
                    generatedCount++;
                }
                Set(material, "Name", slotName);
                if (preservedWweHairMaterial == null && ApplySlotShaderOverride(material, slotName, mtlsPath, wweBaseModel)) forcedOverrides++;
                AddToList(ordered, material);
            }

            int generatedMaterialCount = CountEnumerable(ordered);
            if (generatedMaterialCount == 0) throw new InvalidDataException("No material slots remained after filtering");
            Set(converted, "Materials", ordered);
            Set(converted, "FilePath", mtlsPath);
            Set(converted, "JmtlSourceDir", materialsDirectory);
            Set(converted, "Version", 6);
            TrySetObjectProperty(converted, "IsJmtlFormat", !inlineWweMaterials);
            PropertyInfo blockVersion = converted.GetType().GetProperty("MtlBlockVersion", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (blockVersion != null) Set(converted, "MtlBlockVersion", 4);

            object presets = EmptyPresetDictionary();
            Call(repairService, "RepairAll", converted, formatKey, presets, repairMode);
            CallStatic("MaterialEditor.Services.TextureRefService", "SyncMaterialRefs", ordered, mtlsPath);
            int skinTextureFixes = ApplySkinTextureFixes(ordered, mtlsPath);
            int genericTextureFixes = ApplyGenericTextureFixes(ordered, mtlsPath);
            int literalColorFixes = ApplyLiteralColorFixes(ordered, mtlsPath);
            int hairTextureFixes = ApplyHairTextureFixes(ordered, mtlsPath, inlineWweMaterials);
            int eyeTextureFixes = ApplyEyeTextureFixes(ordered, mtlsPath);
            int teethFixes = ApplyTeethSkinFix(ordered, mtlsPath, wweBaseModel);

            if (!inlineWweMaterials) Directory.CreateDirectory(materialsDirectory);
            WriteMaterialFile(mtlService, jmtlService, converted, mtlsPath, inlineWweMaterials);

            object reopened = ReopenMaterialFile(mtlService, jmtlService, mtlsPath, materialsDirectory, inlineWweMaterials);
            Set(reopened, "FilePath", mtlsPath);
            Set(reopened, "JmtlSourceDir", materialsDirectory);
            TrySetObjectProperty(reopened, "IsJmtlFormat", !inlineWweMaterials);
            int rebuiltHairMaterials = RebuildInvalidHairMaterials(reopened, databaseService, mtlsPath, formatKey, preservedWweHairSources);
            object reopenedMaterials = Get(reopened, "Materials");
            CallStatic("MaterialEditor.Services.TextureRefService", "SyncMaterialRefs", reopenedMaterials, mtlsPath);
            ApplySkinTextureFixes(reopenedMaterials, mtlsPath);
            ApplyGenericTextureFixes(reopenedMaterials, mtlsPath);
            ApplyLiteralColorFixes(reopenedMaterials, mtlsPath);
            ApplyHairTextureFixes(reopenedMaterials, mtlsPath, inlineWweMaterials);
            ApplyEyeTextureFixes(reopenedMaterials, mtlsPath);
            ApplyTeethSkinFix(reopenedMaterials, mtlsPath, wweBaseModel);
            WriteMaterialFile(mtlService, jmtlService, reopened, mtlsPath, inlineWweMaterials);

            object verified = ReopenMaterialFile(mtlService, jmtlService, mtlsPath, materialsDirectory, inlineWweMaterials);
            int fortniteAlphaHairVerified = VerifyFortniteAlphaHairMaterials(Get(verified, "Materials"), mtlsPath);
            VerifyHairShaderLocks(Get(verified, "Materials"), mtlsPath, preservedWweHairSources);
            VerifyPreservedWweHairDetails(Get(verified, "Materials"), preservedWweHairSources);
            VerifyWweBaseTeeth(Get(verified, "Materials"), mtlsPath, wweBaseModel);
            IEnumerable verifiedMaterials = Get(verified, "Materials") as IEnumerable;
            if (verifiedMaterials != null)
            {
                foreach (object verifiedMaterial in verifiedMaterials)
                {
                    string verifiedName = Convert.ToString(Get(verifiedMaterial, "Name"));
                    if (!LooksLikeCustomHairLineworkSlot(verifiedName)) continue;
                    string verifiedShader = Convert.ToString(Get(verifiedMaterial, "Shader"));
                    string verifiedTemplate = Convert.ToString(Get(verifiedMaterial, "TemplateType"));
                    ulong verifiedColor = GetMaterialHash(verifiedMaterial, "colorMap@ref");
                    messages.Add("HAIR  " + verifiedName + " | shader=" + verifiedShader + " | template=" + verifiedTemplate + " | colorMap@ref=0x" + verifiedColor.ToString("X16"));
                }
            }

            if (!File.Exists(mtlsPath) || new FileInfo(mtlsPath).Length == 0) throw new InvalidDataException("Material Editor did not write the MTLs file");
            int jmtlCount = 0;
            int removedInlineJmtls = 0;
            if (inlineWweMaterials)
            {
                removedInlineJmtls = RemoveInlineSlotJmtls(materialsDirectory, slots);
            }
            else
            {
                if (!Directory.Exists(materialsDirectory)) throw new DirectoryNotFoundException("Material Editor did not create the Materials folder");
                string[] files = Directory.GetFiles(materialsDirectory, "*.jmtl", SearchOption.TopDirectoryOnly);
                for (int i = 0; i < files.Length; i++) if (new FileInfo(files[i]).Length > 0) jmtlCount++;
                if (jmtlCount < generatedMaterialCount) throw new InvalidDataException("Material Editor wrote " + jmtlCount + " JMTLs for " + generatedMaterialCount + " generated material slots");
            }
            string formatNote = inlineWweMaterials ? "standalone WWE 2K26 inline MTLs; removed " + removedInlineJmtls + " stale JMTLs" : jmtlCount + " JMTLs";
            messages.Add("OK    " + mcdPath + " | wrote " + Path.GetFileName(mtlsPath) + " as " + formatNote + "; preserved " + preservedCount + " source material(s), generated " + generatedCount + "; " + forcedOverrides + " shader override(s); " + rebuiltHairMaterials + " post-save hair rebuild(s); " + skinTextureFixes + " skin texture binding fix(es); " + genericTextureFixes + " generic texture binding fix(es); " + literalColorFixes + " literal color material fix(es); " + hairTextureFixes + " WWE hair texture binding fix(es); " + fortniteAlphaHairVerified + " Fortnite alpha hair material(s) verified; " + eyeTextureFixes + " eye texture binding fix(es); " + teethFixes + " teeth skin fix(es); " + omittedEyeOverlays + " eye-overlay slot(s) omitted; source: " + referenceNote);
            return true;
        }
        catch (Exception exception)
        {
            messages.Add("FAIL  " + mcdPath + " | " + Actual(exception).Message);
            return false;
        }
    }


    static uint U32(byte[] data, int offset)
    {
        return BitConverter.ToUInt32(data, offset);
    }

    static string FourCc(uint value)
    {
        char[] chars = new char[4];
        chars[0] = (char)(value & 255);
        chars[1] = (char)((value >> 8) & 255);
        chars[2] = (char)((value >> 16) & 255);
        chars[3] = (char)((value >> 24) & 255);
        return new string(chars);
    }

    static void InvertBcAlphaBlock(byte[] data, int offset)
    {
        byte a0 = data[offset];
        byte a1 = data[offset + 1];
        byte[] map = a0 > a1 ? new byte[] { 1, 0, 7, 6, 5, 4, 3, 2 } : new byte[] { 1, 0, 5, 4, 3, 2, 7, 6 };
        ulong bits = 0;
        for (int i = 0; i < 6; i++) bits |= ((ulong)data[offset + 2 + i]) << (8 * i);
        ulong remapped = 0;
        for (int i = 0; i < 16; i++)
        {
            int index = (int)((bits >> (3 * i)) & 7);
            remapped |= ((ulong)map[index]) << (3 * i);
        }
        data[offset] = (byte)(255 - a1);
        data[offset + 1] = (byte)(255 - a0);
        for (int i = 0; i < 6; i++) data[offset + 2 + i] = (byte)((remapped >> (8 * i)) & 255);
    }

    static int BitShift(uint mask)
    {
        int shift = 0;
        while (shift < 32 && ((mask >> shift) & 1) == 0) shift++;
        return shift;
    }

    static int BitCount(uint mask)
    {
        int count = 0;
        while (mask != 0)
        {
            count += (int)(mask & 1);
            mask >>= 1;
        }
        return count;
    }

    static string InvertDdsAlpha(byte[] data)
    {
        if (data.Length < 128 || data[0] != 0x44 || data[1] != 0x44 || data[2] != 0x53 || data[3] != 0x20) throw new InvalidDataException("not a DDS file");
        if (U32(data, 4) != 124 || U32(data, 76) != 32) throw new InvalidDataException("invalid DDS header");
        uint flags = U32(data, 80);
        string fourCc = FourCc(U32(data, 84));
        int dataOffset = 128;
        int blockBytes = 0;
        int alphaOffset = 0;
        string format = "";
        bool bc2 = false;
        bool bcAlpha = false;
        bool uncompressed = false;
        uint alphaMask = U32(data, 104);
        int bitsPerPixel = (int)U32(data, 88);
        if ((flags & 4) != 0)
        {
            if (fourCc == "DX10")
            {
                if (data.Length < 148) throw new InvalidDataException("truncated DX10 DDS header");
                uint dxgi = U32(data, 128);
                dataOffset = 148;
                if (dxgi == 74 || dxgi == 75) { blockBytes = 16; bc2 = true; format = "BC2"; }
                else if (dxgi == 77 || dxgi == 78) { blockBytes = 16; bcAlpha = true; format = "BC3"; }
                else if (dxgi == 80 || dxgi == 81) { blockBytes = 8; bcAlpha = true; format = "BC4"; }
                else if (dxgi == 28 || dxgi == 29 || dxgi == 87 || dxgi == 91) { uncompressed = true; bitsPerPixel = 32; alphaMask = 0xFF000000; format = "RGBA8"; }
                else if (dxgi == 11) { uncompressed = true; bitsPerPixel = 64; alphaMask = 0; alphaOffset = 6; format = "RGBA16"; }
                else if (dxgi == 24) { uncompressed = true; bitsPerPixel = 32; alphaMask = 0xC0000000; format = "RGB10A2"; }
                else if (dxgi == 98 || dxgi == 99) throw new NotSupportedException("BC7 requires DirectXTex");
                else throw new NotSupportedException("unsupported DXGI DDS format " + dxgi);
            }
            else if (fourCc == "DXT2" || fourCc == "DXT3") { blockBytes = 16; bc2 = true; format = "DXT3/BC2"; }
            else if (fourCc == "DXT4" || fourCc == "DXT5") { blockBytes = 16; bcAlpha = true; format = "DXT5/BC3"; }
            else if (fourCc == "ATI1" || fourCc == "BC4U" || fourCc == "BC4S") { blockBytes = 8; bcAlpha = true; format = "BC4"; }
            else throw new NotSupportedException("unsupported DDS FourCC " + fourCc.TrimEnd('\0'));
        }
        else
        {
            if (alphaMask == 0) throw new NotSupportedException("DDS has no alpha channel");
            uncompressed = true;
            format = "uncompressed " + bitsPerPixel + "-bit";
        }
        if (dataOffset >= data.Length) throw new InvalidDataException("DDS has no image data");
        if (bc2)
        {
            if ((data.Length - dataOffset) % blockBytes != 0) throw new InvalidDataException("compressed DDS data is not block aligned");
            for (int offset = dataOffset; offset < data.Length; offset += blockBytes) for (int i = 0; i < 8; i++) data[offset + i] ^= 0xFF;
        }
        else if (bcAlpha)
        {
            if ((data.Length - dataOffset) % blockBytes != 0) throw new InvalidDataException("compressed DDS data is not block aligned");
            for (int offset = dataOffset; offset < data.Length; offset += blockBytes) InvertBcAlphaBlock(data, offset);
        }
        else if (uncompressed && bitsPerPixel == 64 && alphaOffset == 6)
        {
            if ((data.Length - dataOffset) % 8 != 0) throw new InvalidDataException("RGBA16 DDS data is not pixel aligned");
            for (int offset = dataOffset; offset < data.Length; offset += 8)
            {
                ushort alpha = BitConverter.ToUInt16(data, offset + alphaOffset);
                ushort inverted = (ushort)(65535 - alpha);
                data[offset + alphaOffset] = (byte)(inverted & 255);
                data[offset + alphaOffset + 1] = (byte)(inverted >> 8);
            }
        }
        else if (uncompressed)
        {
            if (bitsPerPixel <= 0 || bitsPerPixel > 32 || bitsPerPixel % 8 != 0) throw new NotSupportedException("unsupported uncompressed DDS pixel size " + bitsPerPixel);
            int stride = bitsPerPixel / 8;
            if ((data.Length - dataOffset) % stride != 0) throw new InvalidDataException("uncompressed DDS data is not pixel aligned");
            int shift = BitShift(alphaMask);
            int count = BitCount(alphaMask);
            if (count <= 0 || count > 16) throw new NotSupportedException("unsupported DDS alpha mask");
            uint maximum = (1u << count) - 1u;
            for (int offset = dataOffset; offset < data.Length; offset += stride)
            {
                uint pixel = 0;
                for (int i = 0; i < stride; i++) pixel |= ((uint)data[offset + i]) << (8 * i);
                uint alpha = (pixel & alphaMask) >> shift;
                uint inverted = maximum - alpha;
                pixel = (pixel & ~alphaMask) | ((inverted << shift) & alphaMask);
                for (int i = 0; i < stride; i++) data[offset + i] = (byte)((pixel >> (8 * i)) & 255);
            }
        }
        return format;
    }

    static bool IsBc7(byte[] data, out uint dxgi)
    {
        dxgi = 0;
        if (data.Length < 148 || data[0] != 0x44 || data[1] != 0x44 || data[2] != 0x53 || data[3] != 0x20) return false;
        if (U32(data, 84) != 0x30315844) return false;
        dxgi = U32(data, 128);
        return dxgi == 98 || dxgi == 99;
    }

    static string Quote(string value)
    {
        return "\"" + value.Replace("\"", "\\\"") + "\"";
    }

    static int RunProcess(string executable, string arguments, string workingDirectory, out string output)
    {
        ProcessStartInfo info = new ProcessStartInfo();
        info.FileName = executable;
        info.Arguments = arguments;
        info.WorkingDirectory = workingDirectory;
        info.UseShellExecute = false;
        info.CreateNoWindow = true;
        info.RedirectStandardOutput = true;
        info.RedirectStandardError = true;
        Process process = new Process();
        process.StartInfo = info;
        process.Start();
        string stdout = process.StandardOutput.ReadToEnd();
        string stderr = process.StandardError.ReadToEnd();
        process.WaitForExit();
        output = (stdout + Environment.NewLine + stderr).Trim();
        return process.ExitCode;
    }

    static string FindFileRecursive(string root, string filename)
    {
        if (String.IsNullOrWhiteSpace(root) || !Directory.Exists(root)) return null;
        try
        {
            string[] files = Directory.GetFiles(root, filename, SearchOption.AllDirectories);
            return files.Length == 0 ? null : files[0];
        }
        catch { return null; }
    }

    static string FindTexconv()
    {
        if (!String.IsNullOrWhiteSpace(texconvPath) && File.Exists(texconvPath)) return texconvPath;
        List<string> candidates = new List<string>();
        candidates.Add(Path.Combine(toolDirectory, "texconv.exe"));
        candidates.Add(Path.Combine(editorDirectory, "texconv.exe"));
        string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        string programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        string programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
        if (!String.IsNullOrWhiteSpace(local)) candidates.Add(Path.Combine(local, "Microsoft", "WinGet", "Links", "texconv.exe"));
        if (!String.IsNullOrWhiteSpace(programFiles)) candidates.Add(Path.Combine(programFiles, "WinGet", "Links", "texconv.exe"));
        if (!String.IsNullOrWhiteSpace(programFilesX86)) candidates.Add(Path.Combine(programFilesX86, "WinGet", "Links", "texconv.exe"));
        string[] pathParts = (Environment.GetEnvironmentVariable("PATH") ?? "").Split(Path.PathSeparator);
        for (int i = 0; i < pathParts.Length; i++)
        {
            string part = pathParts[i].Trim().Trim('"');
            if (part.Length > 0) candidates.Add(Path.Combine(part, "texconv.exe"));
        }
        for (int i = 0; i < candidates.Count; i++)
        {
            try
            {
                string full = Path.GetFullPath(candidates[i]);
                if (File.Exists(full)) { texconvPath = full; return full; }
            }
            catch { }
        }
        string found = null;
        if (!String.IsNullOrWhiteSpace(local)) found = FindFileRecursive(Path.Combine(local, "Microsoft", "WinGet", "Packages"), "texconv.exe");
        if (found == null && !String.IsNullOrWhiteSpace(programFiles)) found = FindFileRecursive(Path.Combine(programFiles, "WinGet", "Packages"), "texconv.exe");
        if (found != null) { texconvPath = found; return found; }
        return null;
    }

    static string FindWinget()
    {
        string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        if (!String.IsNullOrWhiteSpace(local))
        {
            string candidate = Path.Combine(local, "Microsoft", "WindowsApps", "winget.exe");
            if (File.Exists(candidate)) return candidate;
        }
        string[] parts = (Environment.GetEnvironmentVariable("PATH") ?? "").Split(Path.PathSeparator);
        for (int i = 0; i < parts.Length; i++)
        {
            string part = parts[i].Trim().Trim('"');
            if (part.Length == 0) continue;
            string candidate = Path.Combine(part, "winget.exe");
            if (File.Exists(candidate)) return candidate;
        }
        return null;
    }

    static string EnsureTexconv()
    {
        string found = FindTexconv();
        if (found != null) return found;
        string winget = FindWinget();
        if (winget == null) throw new FileNotFoundException("BC7 alpha inversion needs Microsoft DirectXTex Texconv");
        Console.WriteLine("Installing Microsoft DirectXTex Texconv for BC7 alpha inversion...");
        string output;
        int exitCode = RunProcess(winget, "install --id Microsoft.DirectXTex.Texconv --exact --accept-package-agreements --accept-source-agreements --silent --disable-interactivity", toolDirectory, out output);
        found = FindTexconv();
        if (exitCode != 0 || found == null) throw new InvalidOperationException("Texconv installation failed. " + output);
        return found;
    }

    static void DeleteDirectoryQuietly(string path)
    {
        try { if (Directory.Exists(path)) Directory.Delete(path, true); } catch { }
    }

    static void W32(byte[] data, int offset, uint value)
    {
        data[offset] = (byte)(value & 255);
        data[offset + 1] = (byte)((value >> 8) & 255);
        data[offset + 2] = (byte)((value >> 16) & 255);
        data[offset + 3] = (byte)((value >> 24) & 255);
    }

    static uint HeaderMipCount(byte[] data)
    {
        uint count = U32(data, 28);
        return count == 0 ? 1u : count;
    }

    static uint InferBcMipCount(byte[] data, int dataOffset, uint width, uint height, int blockBytes)
    {
        if (dataOffset >= data.Length || width == 0 || height == 0) return HeaderMipCount(data);
        long available = data.Length - dataOffset;
        long total = 0;
        uint levels = 0;
        uint w = width;
        uint h = height;
        while (levels < 32)
        {
            long blocksWide = Math.Max(1L, ((long)w + 3L) / 4L);
            long blocksHigh = Math.Max(1L, ((long)h + 3L) / 4L);
            total += blocksWide * blocksHigh * blockBytes;
            levels++;
            if (total == available) return levels;
            if (total > available || (w == 1 && h == 1)) break;
            w = Math.Max(1u, w / 2u);
            h = Math.Max(1u, h / 2u);
        }
        return HeaderMipCount(data);
    }

    static void SetMipHeader(byte[] data, uint mipCount)
    {
        W32(data, 28, mipCount);
        uint flags = U32(data, 8) | 0x20000u;
        uint caps = U32(data, 108) | 0x8u | 0x400000u;
        W32(data, 8, flags);
        W32(data, 108, caps);
    }

    static bool FilesEqual(string first, string second)
    {
        FileInfo a = new FileInfo(first);
        FileInfo b = new FileInfo(second);
        if (!a.Exists || !b.Exists || a.Length != b.Length) return false;
        byte[] left = new byte[1024 * 1024];
        byte[] right = new byte[1024 * 1024];
        using (FileStream fa = File.OpenRead(first))
        using (FileStream fb = File.OpenRead(second))
        {
            while (true)
            {
                int ca = fa.Read(left, 0, left.Length);
                int cb = fb.Read(right, 0, right.Length);
                if (ca != cb) return false;
                if (ca == 0) return true;
                for (int i = 0; i < ca; i++) if (left[i] != right[i]) return false;
            }
        }
    }

    static string InvertBc7Alpha(string sourcePath, byte[] originalData, uint dxgi, string outputPath)
    {
        string texconv = EnsureTexconv();
        uint width = U32(originalData, 16);
        uint height = U32(originalData, 12);
        uint headerMipCount = HeaderMipCount(originalData);
        uint physicalMipCount = InferBcMipCount(originalData, 148, width, height, 16);
        uint mipCount = Math.Max(headerMipCount, physicalMipCount);
        string sourceFormat = dxgi == 99 ? "BC7_UNORM_SRGB" : "BC7_UNORM";
        string rgbaFormat = dxgi == 99 ? "R8G8B8A8_UNORM_SRGB" : "R8G8B8A8_UNORM";
        string work = Path.Combine(Path.GetTempPath(), "WWE2K26MaterialGenerator_" + Guid.NewGuid().ToString("N"));
        string sourceDirectory = Path.Combine(work, "source");
        string decodedDirectory = Path.Combine(work, "decoded");
        string encodedDirectory = Path.Combine(work, "encoded");
        Directory.CreateDirectory(sourceDirectory);
        Directory.CreateDirectory(decodedDirectory);
        Directory.CreateDirectory(encodedDirectory);
        try
        {
            string patchedSource = Path.Combine(sourceDirectory, Path.GetFileName(sourcePath));
            byte[] sourceData = (byte[])originalData.Clone();
            SetMipHeader(sourceData, mipCount);
            File.WriteAllBytes(patchedSource, sourceData);
            string decodeOutput;
            string decodeArguments = "-nologo -y -sepalpha -f " + rgbaFormat + " -m " + mipCount + " -o " + Quote(decodedDirectory) + " " + Quote(patchedSource);
            int decodeExit = RunProcess(texconv, decodeArguments, work, out decodeOutput);
            string decoded = Path.Combine(decodedDirectory, Path.GetFileNameWithoutExtension(sourcePath) + ".dds");
            if (decodeExit != 0 || !File.Exists(decoded)) throw new InvalidOperationException("Texconv could not decode BC7. " + decodeOutput);
            byte[] rgba = File.ReadAllBytes(decoded);
            string decodedFormat = InvertDdsAlpha(rgba);
            File.WriteAllBytes(decoded, rgba);
            string encodeOutput;
            string encodeArguments = "-nologo -y -sepalpha -f " + sourceFormat + " -bc x -aw 4.0 -m " + mipCount + " -o " + Quote(encodedDirectory) + " " + Quote(decoded);
            int encodeExit = RunProcess(texconv, encodeArguments, work, out encodeOutput);
            string encoded = Path.Combine(encodedDirectory, Path.GetFileNameWithoutExtension(sourcePath) + ".dds");
            if (encodeExit != 0 || !File.Exists(encoded)) throw new InvalidOperationException("Texconv could not recompress BC7. " + encodeOutput);
            byte[] result = File.ReadAllBytes(encoded);
            uint resultDxgi;
            if (!IsBc7(result, out resultDxgi) || resultDxgi != dxgi) throw new InvalidDataException("BC7 output format changed unexpectedly");
            if (U32(result, 16) != width || U32(result, 12) != height) throw new InvalidDataException("BC7 output dimensions changed unexpectedly");
            uint resultMipCount = HeaderMipCount(result);
            if (resultMipCount != mipCount) throw new InvalidDataException("BC7 output mip count changed unexpectedly");
            File.Copy(encoded, outputPath, true);
            string mipText = headerMipCount == physicalMipCount ? mipCount + " mip level(s)" : mipCount + " mip level(s), source header " + headerMipCount + " / physical " + physicalMipCount;
            return sourceFormat + " via DirectXTex; alpha inverted in " + decodedFormat + " across " + mipText;
        }
        finally { DeleteDirectoryQuietly(work); }
    }

    static int InvertNormalFile(string path)
    {
        string sourcePath = path;
        string temporary = path + ".alpha_invert.tmp";
        try
        {
            byte[] data = File.ReadAllBytes(sourcePath);
            uint dxgi;
            string format;
            if (IsBc7(data, out dxgi))
            {
                format = InvertBc7Alpha(sourcePath, data, dxgi, temporary);
            }
            else
            {
                format = InvertDdsAlpha(data);
                File.WriteAllBytes(temporary, data);
                if (new FileInfo(temporary).Length != new FileInfo(sourcePath).Length) throw new InvalidDataException("DDS size changed unexpectedly");
            }
            if (FilesEqual(path, temporary))
            {
                File.Delete(temporary);
                messages.Add("SKIP  " + path + " | already matches exact alpha inversion of " + Path.GetFileName(sourcePath) + " (" + format + ")");
                return 0;
            }
            File.Copy(temporary, path, true);
            File.Delete(temporary);
            messages.Add("OK    " + path + " | alpha inverted from " + Path.GetFileName(sourcePath) + " (" + format + ")");
            return 1;
        }
        catch (Exception exception)
        {
            try { if (File.Exists(temporary)) File.Delete(temporary); } catch { }
            messages.Add("FAIL  " + path + " | " + Actual(exception).Message);
            return -1;
        }
    }

    static int InvertNormalAlphas(List<string> roots, bool bodyOnly, out int failed)
    {
        failed = 0;
        int changed = 0;
        List<string> targets = new List<string>();
        HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        for (int r = 0; r < roots.Count; r++)
        {
            string[] files = Directory.GetFiles(roots[r], "*", SearchOption.AllDirectories);
            for (int i = 0; i < files.Length; i++)
            {
                string name = Path.GetFileName(files[i]);
                DirectoryInfo parent = new DirectoryInfo(Path.GetDirectoryName(files[i]));
                if (!String.Equals(parent.Name, "Textures", StringComparison.OrdinalIgnoreCase)) continue;
                bool isBody = String.Equals(name, "body_nrm.dds", StringComparison.OrdinalIgnoreCase);
                bool isHead = String.Equals(name, "head_nrm.dds", StringComparison.OrdinalIgnoreCase);
                if (!isBody && (!isHead || bodyOnly)) continue;
                string full = Path.GetFullPath(files[i]);
                if (seen.Add(full)) targets.Add(full);
            }
        }
        targets.Sort(StringComparer.OrdinalIgnoreCase);
        if (targets.Count == 0)
        {
            messages.Add(bodyOnly ? "SKIP  normal alpha | no Textures\\body_nrm.dds found" : "SKIP  normal alpha | no Textures\\body_nrm.dds or Textures\\head_nrm.dds found");
            return 0;
        }
        for (int i = 0; i < targets.Count; i++)
        {
            int result = InvertNormalFile(targets[i]);
            if (result > 0) changed++;
            else if (result < 0) failed++;
        }
        return changed;
    }


    sealed class DdsMetadata
    {
        public uint Width;
        public uint Height;
        public uint HeaderMips;
        public uint PhysicalMips;
        public uint Mips;
        public int DataOffset;
        public int BlockBytes;
        public int BytesPerPixel;
        public string Format;
    }

    sealed class RgbaLayout
    {
        public uint Width;
        public uint Height;
        public uint Mips;
        public int DataOffset;
        public int Red;
        public int Green;
        public int Blue;
        public int Alpha;
    }

    static uint InferLinearMipCount(byte[] data, int dataOffset, uint width, uint height, int bytesPerPixel)
    {
        if (dataOffset >= data.Length || width == 0 || height == 0 || bytesPerPixel <= 0) return HeaderMipCount(data);
        long available = data.Length - dataOffset;
        long total = 0;
        uint levels = 0;
        uint w = width;
        uint h = height;
        while (levels < 32)
        {
            total += (long)w * h * bytesPerPixel;
            levels++;
            if (total == available) return levels;
            if (total > available || (w == 1 && h == 1)) break;
            w = Math.Max(1u, w / 2u);
            h = Math.Max(1u, h / 2u);
        }
        return HeaderMipCount(data);
    }

    static DdsMetadata ReadDdsMetadata(byte[] data)
    {
        if (data.Length < 128 || data[0] != 0x44 || data[1] != 0x44 || data[2] != 0x53 || data[3] != 0x20) throw new InvalidDataException("not a DDS file");
        if (U32(data, 4) != 124 || U32(data, 76) != 32) throw new InvalidDataException("invalid DDS header");
        DdsMetadata info = new DdsMetadata();
        info.Width = U32(data, 16);
        info.Height = U32(data, 12);
        info.HeaderMips = HeaderMipCount(data);
        info.DataOffset = 128;
        uint flags = U32(data, 80);
        string fourCc = FourCc(U32(data, 84));
        if ((flags & 4) != 0)
        {
            if (fourCc == "DX10")
            {
                if (data.Length < 148) throw new InvalidDataException("truncated DX10 DDS header");
                info.DataOffset = 148;
                uint dxgi = U32(data, 128);
                if (dxgi == 71) { info.Format = "BC1_UNORM"; info.BlockBytes = 8; }
                else if (dxgi == 72) { info.Format = "BC1_UNORM_SRGB"; info.BlockBytes = 8; }
                else if (dxgi == 74) { info.Format = "BC2_UNORM"; info.BlockBytes = 16; }
                else if (dxgi == 75) { info.Format = "BC2_UNORM_SRGB"; info.BlockBytes = 16; }
                else if (dxgi == 77) { info.Format = "BC3_UNORM"; info.BlockBytes = 16; }
                else if (dxgi == 78) { info.Format = "BC3_UNORM_SRGB"; info.BlockBytes = 16; }
                else if (dxgi == 80) { info.Format = "BC4_UNORM"; info.BlockBytes = 8; }
                else if (dxgi == 81) { info.Format = "BC4_SNORM"; info.BlockBytes = 8; }
                else if (dxgi == 83) { info.Format = "BC5_UNORM"; info.BlockBytes = 16; }
                else if (dxgi == 84) { info.Format = "BC5_SNORM"; info.BlockBytes = 16; }
                else if (dxgi == 95) { info.Format = "BC6H_UF16"; info.BlockBytes = 16; }
                else if (dxgi == 96) { info.Format = "BC6H_SF16"; info.BlockBytes = 16; }
                else if (dxgi == 98) { info.Format = "BC7_UNORM"; info.BlockBytes = 16; }
                else if (dxgi == 99) { info.Format = "BC7_UNORM_SRGB"; info.BlockBytes = 16; }
                else if (dxgi == 28) { info.Format = "R8G8B8A8_UNORM"; info.BytesPerPixel = 4; }
                else if (dxgi == 29) { info.Format = "R8G8B8A8_UNORM_SRGB"; info.BytesPerPixel = 4; }
                else if (dxgi == 87) { info.Format = "B8G8R8A8_UNORM"; info.BytesPerPixel = 4; }
                else if (dxgi == 91) { info.Format = "B8G8R8A8_UNORM_SRGB"; info.BytesPerPixel = 4; }
                else throw new NotSupportedException("unsupported DXGI DDS format " + dxgi);
            }
            else if (fourCc == "DXT1") { info.Format = "BC1_UNORM"; info.BlockBytes = 8; }
            else if (fourCc == "DXT2" || fourCc == "DXT3") { info.Format = "BC2_UNORM"; info.BlockBytes = 16; }
            else if (fourCc == "DXT4" || fourCc == "DXT5") { info.Format = "BC3_UNORM"; info.BlockBytes = 16; }
            else if (fourCc == "ATI1" || fourCc == "BC4U") { info.Format = "BC4_UNORM"; info.BlockBytes = 8; }
            else if (fourCc == "BC4S") { info.Format = "BC4_SNORM"; info.BlockBytes = 8; }
            else if (fourCc == "ATI2" || fourCc == "BC5U") { info.Format = "BC5_UNORM"; info.BlockBytes = 16; }
            else if (fourCc == "BC5S") { info.Format = "BC5_SNORM"; info.BlockBytes = 16; }
            else throw new NotSupportedException("unsupported DDS FourCC " + fourCc.TrimEnd('\0'));
        }
        else
        {
            int bitsPerPixel = (int)U32(data, 88);
            uint redMask = U32(data, 92);
            uint greenMask = U32(data, 96);
            uint blueMask = U32(data, 100);
            uint alphaMask = U32(data, 104);
            if (bitsPerPixel != 32) throw new NotSupportedException("unsupported uncompressed DDS pixel size " + bitsPerPixel);
            if (redMask == 0x000000FF && greenMask == 0x0000FF00 && blueMask == 0x00FF0000 && alphaMask == 0xFF000000) info.Format = "R8G8B8A8_UNORM";
            else if (redMask == 0x00FF0000 && greenMask == 0x0000FF00 && blueMask == 0x000000FF && alphaMask == 0xFF000000) info.Format = "B8G8R8A8_UNORM";
            else throw new NotSupportedException("unsupported uncompressed DDS channel masks");
            info.BytesPerPixel = 4;
        }
        info.PhysicalMips = info.BlockBytes > 0
            ? InferBcMipCount(data, info.DataOffset, info.Width, info.Height, info.BlockBytes)
            : InferLinearMipCount(data, info.DataOffset, info.Width, info.Height, info.BytesPerPixel);
        info.Mips = Math.Max(info.HeaderMips, info.PhysicalMips);
        if (info.Mips == 0) info.Mips = 1;
        return info;
    }

    static int ByteOffsetForMask(uint mask)
    {
        if (BitCount(mask) != 8) throw new NotSupportedException("DDS channel mask is not 8-bit");
        int shift = BitShift(mask);
        if (shift % 8 != 0) throw new NotSupportedException("DDS channel mask is not byte aligned");
        return shift / 8;
    }

    static RgbaLayout ReadRgbaLayout(byte[] data)
    {
        if (data.Length < 128 || data[0] != 0x44 || data[1] != 0x44 || data[2] != 0x53 || data[3] != 0x20) throw new InvalidDataException("not a DDS file");
        RgbaLayout layout = new RgbaLayout();
        layout.Width = U32(data, 16);
        layout.Height = U32(data, 12);
        layout.Mips = HeaderMipCount(data);
        layout.DataOffset = 128;
        uint flags = U32(data, 80);
        string fourCc = FourCc(U32(data, 84));
        if ((flags & 4) != 0 && fourCc == "DX10")
        {
            if (data.Length < 148) throw new InvalidDataException("truncated DX10 DDS header");
            layout.DataOffset = 148;
            uint dxgi = U32(data, 128);
            if (dxgi == 28 || dxgi == 29)
            {
                layout.Red = 0;
                layout.Green = 1;
                layout.Blue = 2;
                layout.Alpha = 3;
            }
            else if (dxgi == 87 || dxgi == 91)
            {
                layout.Red = 2;
                layout.Green = 1;
                layout.Blue = 0;
                layout.Alpha = 3;
            }
            else throw new NotSupportedException("decoded DDS is not 32-bit RGBA/BGRA");
        }
        else
        {
            if ((flags & 4) != 0 || U32(data, 88) != 32) throw new NotSupportedException("decoded DDS is not legacy 32-bit RGBA/BGRA");
            layout.Red = ByteOffsetForMask(U32(data, 92));
            layout.Green = ByteOffsetForMask(U32(data, 96));
            layout.Blue = ByteOffsetForMask(U32(data, 100));
            layout.Alpha = ByteOffsetForMask(U32(data, 104));
        }
        return layout;
    }

    static long RgbaMipBytes(uint width, uint height, uint mipCount)
    {
        long total = 0;
        uint w = width;
        uint h = height;
        for (uint level = 0; level < mipCount; level++)
        {
            total += (long)w * h * 4L;
            w = Math.Max(1u, w / 2u);
            h = Math.Max(1u, h / 2u);
        }
        return total;
    }

    static string DecodeToRgba8(string texconv, string sourcePath, uint mipCount, string outputDirectory, string workingDirectory)
    {
        Directory.CreateDirectory(outputDirectory);
        string processOutput;
        string arguments = "-nologo -y -sepalpha -f R8G8B8A8_UNORM -m " + mipCount + " -o " + Quote(outputDirectory) + " " + Quote(sourcePath);
        int exit = RunProcess(texconv, arguments, workingDirectory, out processOutput);
        string output = Path.Combine(outputDirectory, Path.GetFileNameWithoutExtension(sourcePath) + ".dds");
        if (exit != 0 || !File.Exists(output)) throw new InvalidOperationException("Texconv could not decode " + Path.GetFileName(sourcePath) + ". " + processOutput);
        return output;
    }

    static bool FormatStoresBlueAndAlpha(string format)
    {
        return format.StartsWith("BC2", StringComparison.OrdinalIgnoreCase)
            || format.StartsWith("BC3", StringComparison.OrdinalIgnoreCase)
            || format.StartsWith("BC7", StringComparison.OrdinalIgnoreCase)
            || format.StartsWith("R8G8B8A8", StringComparison.OrdinalIgnoreCase)
            || format.StartsWith("B8G8R8A8", StringComparison.OrdinalIgnoreCase);
    }

    static string PackRoughnessIntoNormal(string normalPath, string normalSourcePath, string roughnessPath, string outputPath)
    {
        string texconv = EnsureTexconv();
        byte[] normalSource = File.ReadAllBytes(normalSourcePath);
        byte[] roughnessSource = File.ReadAllBytes(roughnessPath);
        DdsMetadata normalInfo = ReadDdsMetadata(normalSource);
        DdsMetadata roughnessInfo = ReadDdsMetadata(roughnessSource);
        if (normalInfo.Width != roughnessInfo.Width || normalInfo.Height != roughnessInfo.Height) throw new InvalidDataException("normal and roughness dimensions do not match");
        uint mipCount = normalInfo.Mips;
        string outputFormat = FormatStoresBlueAndAlpha(normalInfo.Format) ? normalInfo.Format : "BC7_UNORM";
        string work = Path.Combine(Path.GetTempPath(), "WWE2K26RoughnessNormal_" + Guid.NewGuid().ToString("N"));
        string sourceDirectory = Path.Combine(work, "source");
        string decodedNormalDirectory = Path.Combine(work, "decoded_normal");
        string decodedRoughnessDirectory = Path.Combine(work, "decoded_roughness");
        string encodedDirectory = Path.Combine(work, "encoded");
        Directory.CreateDirectory(sourceDirectory);
        Directory.CreateDirectory(encodedDirectory);
        try
        {
            string patchedNormal = Path.Combine(sourceDirectory, Path.GetFileName(normalPath));
            byte[] patchedNormalData = (byte[])normalSource.Clone();
            SetMipHeader(patchedNormalData, mipCount);
            File.WriteAllBytes(patchedNormal, patchedNormalData);
            string patchedRoughness = Path.Combine(sourceDirectory, Path.GetFileName(roughnessPath));
            byte[] patchedRoughnessData = (byte[])roughnessSource.Clone();
            SetMipHeader(patchedRoughnessData, roughnessInfo.Mips);
            File.WriteAllBytes(patchedRoughness, patchedRoughnessData);
            string decodedNormal = DecodeToRgba8(texconv, patchedNormal, mipCount, decodedNormalDirectory, work);
            string decodedRoughness = DecodeToRgba8(texconv, patchedRoughness, mipCount, decodedRoughnessDirectory, work);
            byte[] normalRgba = File.ReadAllBytes(decodedNormal);
            byte[] roughnessRgba = File.ReadAllBytes(decodedRoughness);
            RgbaLayout normalLayout = ReadRgbaLayout(normalRgba);
            RgbaLayout roughnessLayout = ReadRgbaLayout(roughnessRgba);
            if (normalLayout.Width != normalInfo.Width || normalLayout.Height != normalInfo.Height || roughnessLayout.Width != normalInfo.Width || roughnessLayout.Height != normalInfo.Height) throw new InvalidDataException("decoded texture dimensions changed unexpectedly");
            if (normalLayout.Mips != mipCount || roughnessLayout.Mips != mipCount) throw new InvalidDataException("decoded texture mip count changed unexpectedly");
            long imageBytes = RgbaMipBytes(normalInfo.Width, normalInfo.Height, mipCount);
            if (normalLayout.DataOffset + imageBytes > normalRgba.Length || roughnessLayout.DataOffset + imageBytes > roughnessRgba.Length) throw new InvalidDataException("decoded texture data is truncated");
            long pixelCount = imageBytes / 4L;
            for (long pixel = 0; pixel < pixelCount; pixel++)
            {
                long normalOffset = normalLayout.DataOffset + pixel * 4L;
                long roughnessOffset = roughnessLayout.DataOffset + pixel * 4L;
                normalRgba[(int)normalOffset + normalLayout.Blue] = roughnessRgba[(int)roughnessOffset + roughnessLayout.Red];
                normalRgba[(int)normalOffset + normalLayout.Alpha] = 0;
            }
            File.WriteAllBytes(decodedNormal, normalRgba);
            string processOutput;
            string compression = outputFormat.StartsWith("BC", StringComparison.OrdinalIgnoreCase) ? " -bc x -aw 4.0" : "";
            string encodeArguments = "-nologo -y -sepalpha -f " + outputFormat + compression + " -m " + mipCount + " -o " + Quote(encodedDirectory) + " " + Quote(decodedNormal);
            int encodeExit = RunProcess(texconv, encodeArguments, work, out processOutput);
            string encoded = Path.Combine(encodedDirectory, Path.GetFileNameWithoutExtension(decodedNormal) + ".dds");
            if (encodeExit != 0 || !File.Exists(encoded)) throw new InvalidOperationException("Texconv could not encode the packed normal. " + processOutput);
            DdsMetadata resultInfo = ReadDdsMetadata(File.ReadAllBytes(encoded));
            if (resultInfo.Width != normalInfo.Width || resultInfo.Height != normalInfo.Height) throw new InvalidDataException("packed normal dimensions changed unexpectedly");
            if (resultInfo.Mips != mipCount) throw new InvalidDataException("packed normal mip count changed unexpectedly");
            File.Copy(encoded, outputPath, true);
            string sourceMipText = normalInfo.HeaderMips == normalInfo.PhysicalMips ? mipCount + " mip level(s)" : mipCount + " mip level(s), source header " + normalInfo.HeaderMips + " / physical " + normalInfo.PhysicalMips;
            return "roughness red copied to normal blue; alpha set to black; " + outputFormat + "; " + sourceMipText;
        }
        finally
        {
            DeleteDirectoryQuietly(work);
        }
    }

    static int PackRoughnessNormalFile(string roughnessPath, string normalPath)
    {
        string sourceNormal = normalPath;
        string temporary = normalPath + ".roughness_pack.tmp";
        try
        {
            string description = PackRoughnessIntoNormal(normalPath, sourceNormal, roughnessPath, temporary);
            if (FilesEqual(normalPath, temporary))
            {
                File.Delete(temporary);
                messages.Add("SKIP  " + normalPath + " | already matches " + Path.GetFileName(roughnessPath) + " (" + description + ")");
                return 0;
            }
            File.Copy(temporary, normalPath, true);
            File.Delete(temporary);
            messages.Add("OK    " + normalPath + " | packed " + Path.GetFileName(roughnessPath) + " (" + description + ")");
            return 1;
        }
        catch (Exception exception)
        {
            try { if (File.Exists(temporary)) File.Delete(temporary); } catch { }
            messages.Add("FAIL  " + normalPath + " | " + Actual(exception).Message);
            return -1;
        }
    }

    static int PackRoughnessNormals(List<string> roots, out int failed)
    {
        failed = 0;
        int changed = 0;
        List<string[]> pairs = new List<string[]>();
        HashSet<string> seenNormals = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        for (int r = 0; r < roots.Count; r++)
        {
            string[] files = Directory.GetFiles(roots[r], "*", SearchOption.AllDirectories);
            for (int i = 0; i < files.Length; i++)
            {
                string path = files[i];
                DirectoryInfo parent = new DirectoryInfo(Path.GetDirectoryName(path));
                if (!String.Equals(parent.Name, "Textures", StringComparison.OrdinalIgnoreCase)) continue;
                string name = Path.GetFileName(path);
                if (!name.EndsWith("_roughness.dds", StringComparison.OrdinalIgnoreCase)) continue;
                if (Path.GetFileNameWithoutExtension(path).EndsWith("_backup", StringComparison.OrdinalIgnoreCase)) continue;
                string prefix = name.Substring(0, name.Length - "_roughness.dds".Length);
                string normal = Path.Combine(parent.FullName, prefix + "_normal.dds");
                if (!File.Exists(normal))
                {
                    messages.Add("SKIP  " + path + " | matching " + prefix + "_normal.dds was not found");
                    continue;
                }
                string fullNormal = Path.GetFullPath(normal);
                if (seenNormals.Add(fullNormal)) pairs.Add(new string[] { Path.GetFullPath(path), fullNormal });
            }
        }
        pairs.Sort(delegate(string[] left, string[] right) { return StringComparer.OrdinalIgnoreCase.Compare(left[1], right[1]); });
        if (pairs.Count == 0)
        {
            messages.Add("SKIP  roughness packing | no matching Textures\\*_roughness.dds and *_normal.dds pairs found");
            return 0;
        }
        for (int i = 0; i < pairs.Count; i++)
        {
            int result = PackRoughnessNormalFile(pairs[i][0], pairs[i][1]);
            if (result > 0) changed++;
            else if (result < 0) failed++;
        }
        return changed;
    }

    static Assembly ResolveAssembly(object sender, ResolveEventArgs args)
    {
        string name = new AssemblyName(args.Name).Name + ".dll";
        string path = Path.Combine(editorDirectory, name);
        return File.Exists(path) ? Assembly.LoadFrom(path) : null;
    }

    [STAThread]
    public static int Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        messages.Clear();
        if (args.Length < 2)
        {
            Console.WriteLine("Usage: MaterialGenerator <MaterialEditor folder> <root folder> [--selection-file <path>] [--mcd-file-list <path>] [--wwe-base-file-list <path>] [--materials-only] [--alpha-only] [--body-only] [--pack-roughness] [--roughness-only] [--preserve-wwe-hair]");
            return 2;
        }
        toolDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        editorDirectory = Path.GetFullPath(args[0].Trim('"'));
        string root = Path.GetFullPath(args[1].Trim('"'));
        string selectionFile = null;
        string mcdFileList = null;
        string wweBaseFileList = null;
        bool materialsEnabled = true;
        bool alphaEnabled = true;
        bool bodyOnly = false;
        bool roughnessEnabled = false;
        preserveWweHair = false;
        for (int i = 2; i < args.Length; i++)
        {
            if (String.Equals(args[i], "--selection-file", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length) selectionFile = Path.GetFullPath(args[++i].Trim('"'));
            else if (String.Equals(args[i], "--mcd-file-list", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length) mcdFileList = Path.GetFullPath(args[++i].Trim('"'));
            else if (String.Equals(args[i], "--wwe-base-file-list", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length) wweBaseFileList = Path.GetFullPath(args[++i].Trim('"'));
            else if (String.Equals(args[i], "--materials-only", StringComparison.OrdinalIgnoreCase)) alphaEnabled = false;
            else if (String.Equals(args[i], "--alpha-only", StringComparison.OrdinalIgnoreCase)) materialsEnabled = false;
            else if (String.Equals(args[i], "--body-only", StringComparison.OrdinalIgnoreCase)) bodyOnly = true;
            else if (String.Equals(args[i], "--pack-roughness", StringComparison.OrdinalIgnoreCase)) roughnessEnabled = true;
            else if (String.Equals(args[i], "--preserve-wwe-hair", StringComparison.OrdinalIgnoreCase)) preserveWweHair = true;
            else if (String.Equals(args[i], "--roughness-only", StringComparison.OrdinalIgnoreCase))
            {
                materialsEnabled = false;
                alphaEnabled = false;
                roughnessEnabled = true;
            }
        }
        wweBaseModels.Clear();
        List<string> listedWweBaseModels = ReadFileList(wweBaseFileList, ".mcd");
        for (int i = 0; i < listedWweBaseModels.Count; i++) wweBaseModels.Add(listedWweBaseModels[i]);
        if (!Directory.Exists(root))
        {
            Console.WriteLine("Folder not found: " + root);
            return 2;
        }
        List<string> selectedRoots = NormalizeRoots(root, selectionFile);
        if (selectedRoots.Count == 0)
        {
            Console.WriteLine("No folders were selected.");
            return 2;
        }
        if (materialsEnabled)
        {
            string editorDll = Path.Combine(editorDirectory, "MaterialEditor.dll");
            if (!File.Exists(editorDll))
            {
                Console.WriteLine("MaterialEditor.dll was not found in: " + editorDirectory);
                return 2;
            }
            AppDomain.CurrentDomain.AssemblyResolve += ResolveAssembly;
            Directory.SetCurrentDirectory(editorDirectory);
            editorAssembly = Assembly.LoadFrom(editorDll);
        }
        List<string> models = materialsEnabled ? ReadFileList(mcdFileList, ".mcd") : new List<string>();
        if (models.Count == 0 && materialsEnabled) models = FindFiles(selectedRoots, ".mcd");
        Console.WriteLine("Selected " + selectedRoots.Count + " folder(s).");
        int materialOk = 0;
        int failed = 0;
        if (materialsEnabled)
        {
            Console.WriteLine("Found " + models.Count + " MCD file(s). Each MCD creates a same-name MTLs and a Materials folder through the Material Editor save workflow.");
            Console.WriteLine();
            for (int i = 0; i < models.Count; i++)
            {
                Console.WriteLine("[" + (i + 1) + "/" + models.Count + "] " + models[i]);
                if (GenerateForMcd(models[i])) materialOk++;
                else failed++;
            }
        }
        int alphaChanged = 0;
        if (alphaEnabled)
        {
            Console.WriteLine();
            Console.WriteLine(bodyOnly ? "Inverting alpha in Textures\\body_nrm.dds only..." : "Inverting alpha in Textures\\body_nrm.dds and Textures\\head_nrm.dds...");
            int alphaFailed;
            alphaChanged = InvertNormalAlphas(selectedRoots, bodyOnly, out alphaFailed);
            failed += alphaFailed;
        }
        int roughnessChanged = 0;
        if (roughnessEnabled)
        {
            Console.WriteLine();
            Console.WriteLine("Packing Textures\\*_roughness.dds into the blue channel of matching *_normal.dds files and setting alpha to black...");
            int roughnessFailed;
            roughnessChanged = PackRoughnessNormals(selectedRoots, out roughnessFailed);
            failed += roughnessFailed;
        }
        Console.WriteLine();
        for (int i = 0; i < messages.Count; i++) Console.WriteLine(messages[i]);
        Console.WriteLine();
        Console.WriteLine("Finished: " + materialOk + " MCD material set(s) generated, " + alphaChanged + (bodyOnly ? " body normal map(s) inverted, " : " body/head normal map(s) inverted, ") + roughnessChanged + " roughness/normal texture(s) packed, " + failed + " failed.");
        return failed == 0 ? 0 : 1;
    }

}
