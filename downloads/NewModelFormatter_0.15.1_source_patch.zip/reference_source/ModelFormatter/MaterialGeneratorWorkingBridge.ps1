param(
    [Parameter(Mandatory=$true)][string]$RootPath,
    [Parameter(Mandatory=$true)][string]$McdListPath,
    [Parameter(Mandatory=$true)][string]$SelectionPath,
    [switch]$AlphaOnly,
    [switch]$BodyOnly,
    [switch]$MaterialsOnly,
    [switch]$PackRoughness,
    [switch]$RoughnessOnly
)

$toolDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$source = Join-Path $toolDirectory "MaterialGeneratorWorking.cs"
$backend = Join-Path $toolDirectory "MaterialGenerator.dll"
$runtime = Join-Path $toolDirectory "MaterialGenerator.runtimeconfig.json"
$materialEditorPath = Join-Path $toolDirectory "material_editor"
$dotnet = $null
$dotnetCommand = Get-Command dotnet.exe -ErrorAction SilentlyContinue
if ($dotnetCommand) { $dotnet = $dotnetCommand.Source }
if (-not $dotnet -and (Test-Path -LiteralPath "$env:ProgramFiles\dotnet\dotnet.exe")) { $dotnet = "$env:ProgramFiles\dotnet\dotnet.exe" }
if (-not $dotnet -and ${env:ProgramFiles(x86)} -and (Test-Path -LiteralPath "${env:ProgramFiles(x86)}\dotnet\dotnet.exe")) { $dotnet = "${env:ProgramFiles(x86)}\dotnet\dotnet.exe" }
if (-not $dotnet) { Write-Error ".NET 8 was not found."; exit 2 }
$csc = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if (-not (Test-Path -LiteralPath $csc)) { $csc = "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\csc.exe" }
if (-not (Test-Path -LiteralPath $csc)) { Write-Error "The Windows C# compiler was not found."; exit 2 }
$needsBuild = $true
if ($needsBuild) {
    & $csc /nologo /optimize+ /target:exe "/out:$backend" $source
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
if (-not (Test-Path -LiteralPath $runtime)) { Write-Error "MaterialGenerator.runtimeconfig.json is missing."; exit 2 }
$generatorArgs = @(
    $backend,
    $materialEditorPath,
    $RootPath,
    "--selection-file",
    $SelectionPath,
    "--mcd-file-list",
    $McdListPath
)
if ($RoughnessOnly) {
    $generatorArgs += "--roughness-only"
} else {
    if ($AlphaOnly) { $generatorArgs += "--alpha-only" }
    elseif ($MaterialsOnly) { $generatorArgs += "--materials-only" }
    if ($BodyOnly) { $generatorArgs += "--body-only" }
    if ($PackRoughness) { $generatorArgs += "--pack-roughness" }
}
& $dotnet @generatorArgs
exit $LASTEXITCODE
