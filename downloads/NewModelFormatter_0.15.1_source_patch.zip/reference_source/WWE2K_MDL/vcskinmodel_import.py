from .Link.interface import *
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty
from bpy_extras.io_utils import ImportHelper
import bpy

class vCSkinModelImport(Operator, ImportHelper):
    """Import Visual Concepts | WWE Model"""
    bl_idname = "import_vcskinmodel.load"
    bl_label = "Import Model"
    filename_ext = ".mcd"

    filter_glob: StringProperty(
        default="*.mdl;*.mcd;*.speedtree",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    import_shape_keys: BoolProperty(
        name="Import Shape Keys",
        description="Imports all MDL Shape Key data.",
        default=True,
    )

    split_material_groups: BoolProperty(
        name="Split Material Groups",
        description="Splits models per defined material group",
        default=False,
    )

    load_textures: BoolProperty(
        name="Load Material Textures",
        description="Adds all color map materials to model meshes",
        default=True,
    )
    
    load_attachment_points: BoolProperty(
        name="Load Attachment Points",
        description="Imports all included attachment points into a dedicated "
                    "'Model APs' collection. OFF by default — faster import, no "
                    "viewport clutter. Turn ON only when you need to PRESERVE "
                    "attach points on a round-trip: export re-emits AtPt records "
                    "that are in the scene, so with this off the source's attach "
                    "points (belt_dyn_APs / body_limit_APs / prop mounts) are "
                    "dropped on save.",
        default=False,
    )

    load_goto_points: BoolProperty(
        name="Load GtPt Anchors",
        description="Imports GtPt anchor records as a hidden VC_GtPt_Anchors "
                    "collection plus per-record vertex groups (VC_GTPT__*) "
                    "on the referenced meshes. Required for the export-side "
                    "resolver to handle topology edits like M_Head_Caruncle "
                    "merged into M_Head.",
        default=True,
    )

    auto_apply_hpl: BoolProperty(
        name="Auto-apply HPL from Attire (2K26)",
        description=(
            "When importing a 2K26 attire that has an embedded HPL masking "
            "sub-stream, automatically read it and create HPL_Ring / "
            "HPL_Entrance vertex groups on the baseModel meshes (M_Head / "
            "M_Body) already in the scene. Without this, the source HPL "
            "is silently lost on re-export when the scene also has empty "
            "HPL groups present. Has no effect for non-attire files or "
            "when no baseModel is loaded — the import succeeds either way"
        ),
        default=True,
    )

        # Adjust the text width for the properties
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Import Options:")
        row = box.row()
        row.prop(self, "import_shape_keys")
        row = box.row()
        row.prop(self, "split_material_groups")
        row = box.row()
        row.prop(self, "load_textures")
        row = box.row()
        row.prop(self, "load_attachment_points")
        row = box.row()
        row.prop(self, "load_goto_points")
        row = box.row()
        row.prop(self, "auto_apply_hpl")

    def doImport(self, context, filepath, keywords):
        # loadModelFile returns False on an invalid/unsupported file (and reports
        # an ERROR banner itself); a mid-parse exception propagates here. Either
        # way the operator must return CANCELLED, not FINISHED — the old code
        # always returned FINISHED, leaving the user an empty scene with no error.
        try:
            ok = loadModelFile(filepath, keywords, operator=self)
        except Exception as e:
            self.report({'ERROR'}, f"Import failed: {e}")
            return {'CANCELLED'}
        if ok is False:
            return {'CANCELLED'}
        return {'FINISHED'}

    def execute(self, context):
        keywords = self.as_keywords(
            ignore=(
                "axis_forward",
                "axis_up",
                "global_scale",
                "check_existing",
                "filter_glob",
            ),
        )
        return self.doImport(context, self.filepath, keywords)
    
def menu_bar_vc_import(self, context):
    self.layout.operator(vCSkinModelImport.bl_idname, text="Visual Concepts Model (.mdl, .mcd)", icon='EVENT_V')

def register_vcs_import():
    bpy.utils.register_class(vCSkinModelImport)
    bpy.types.TOPBAR_MT_file_import.append(menu_bar_vc_import)
    return

def unregister_vcs_import():
    bpy.utils.unregister_class(vCSkinModelImport)
    bpy.types.TOPBAR_MT_file_import.remove(menu_bar_vc_import)
    return