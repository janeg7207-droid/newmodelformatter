from .Link.interface_save import *
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy_extras.io_utils import ExportHelper


def _autodetect_export_target():
    """Best-effort: return the compile_target enum matching the imported SOURCE
    file's game version, so a 2K25 import pre-selects 'WWE 2K25 MCD v2.09' instead
    of silently defaulting to 2K26 (which would emit a wrong-format/unreadable file
    for that game). Returns None to keep the current default. Fully defensive — any
    failure returns None so the export dialog is never affected."""
    try:
        import bpy, os
        from .Link.wrapper import detect_mcd_version
        from .Link.interface import _MDL_VERSION_TO_TARGET
        src = None
        # Mirror model_serialize._find_source_mcd: the selected meshes' stamped
        # collection first, then any stamped collection.
        for obj in (getattr(bpy.context, 'selected_objects', None) or []):
            if obj.type != 'MESH':
                continue
            for col in bpy.data.collections:
                if obj.name in col.objects:
                    p = col.get("vcmodel_source_path")
                    if p and os.path.exists(p):
                        src = p
                        break
            if src:
                break
        if not src:
            for col in bpy.data.collections:
                p = col.get("vcmodel_source_path")
                if p and os.path.exists(p):
                    src = p
                    break
        if not src:
            return None
        return _MDL_VERSION_TO_TARGET.get(detect_mcd_version(src))
    except Exception:
        return None


class vCSkinModelExport(Operator, ExportHelper):
    """Export Visual Concepts | WWE model"""
    bl_idname = "export_vcskinmodel.save"
    bl_label = "Export Model"
    filename_ext = ".model"

    filter_glob: StringProperty(
        default="*.mdl;*.mcd;*.speedtree",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    use_calculate_tangents: BoolProperty(
        name="Calculate vertex tangents",
        description="Set MikkTSpace tangents at each triangle wedge",
        default=True,
    )

    export_shape_keys: BoolProperty(
        name="Export shape keys",
        description="Set shape keys for each mesh",
        default=True,
    )

    compile_target: EnumProperty(
        name="",
        items=COMPILE_TARGETS,
        default="option_vcexport_26",
        description="Select target format",
    )

    export_hpl: BoolProperty(
        name="Export HPL mask",
        description="Creates a masking (.hpl) file for geometry culling",
        default=False,
    )

    generate_mtls: BoolProperty(
        name="Generate MTLs",
        description="Generate .mtls + .jmtl files for 2K26 export, or legacy .mtls for older targets",
        default=False,
    )

    overwrite_existing_jmtls: BoolProperty(
        name="Overwrite Existing JMTLs",
        description="If unchecked, existing .jmtl files in Materials/ will not be overwritten",
        default=True,
    )

    material_context: EnumProperty(
        name="Preset Context",
        description="Which 2K26 preset family auto-inferred materials use. "
                    "Per-material overrides set in Material Properties > "
                    "2K26 Material Export always win over this",
        items=(
            ("AUTO", "Auto-Detect",
             "BaseModel vs Attire from the selected meshes (an M_Head/M_Body "
             "mesh means BaseModel); Arena/Prop presets when the save path "
             "contains an Arena, Props, or Weapons folder"),
            ("BASEMODEL", "Character - BaseModel",
             "Character shader presets (head, body, eyes, teeth, hair); "
             "writes baseModel.mtls"),
            ("ATTIRE", "Character - Attire",
             "Character shader presets with unknown slots falling back to "
             "the gear shader; writes Attire.mtls"),
            ("ENVIRONMENT", "Arena / Prop / Weapon",
             "Environment shader presets (PBR, illumination, glass, water, "
             "foliage) regardless of the save path; .mtls named after the "
             "model file"),
        ),
        default="AUTO",
    )

    export_atpts: BoolProperty(
        name="Include Attachment Points",
        description="Includes all attachment points defined in selected user model",
        default=True,
    )

    export_gtpts: BoolProperty(
        name="Include GtPt Anchors",
        description="Includes the face-shading anchor system: the GtPt "
                    "sub-stream with anchor records (resolved through "
                    "topology edits like M_Head_Caruncle merged into "
                    "M_Head) AND the fixed _ag_ string-table block that "
                    "the engine pairs them with. Disable for attire / "
                    "prop models or to ship a clean no-AO state — both "
                    "the GtPt sub-stream and the _ag_ block are skipped "
                    "together (requires a VCModel build that exports "
                    "setSkipAttributeGroups; older builds skip GtPt only "
                    "and emit a warning that the _ag_ block still emits).",
        default=True,
    )

    preserve_normals: BoolProperty(
        name="Preserve Custom Normals",
        description="Keeps custom split normals instead of recalculating from UV seams",
        default=False,
    )

    preserve_tangents: BoolProperty(
        name="Preserve Vanilla Tangents (Experimental)",
        description="EXPERIMENTAL. On the Preserve Custom Normals path, feed the "
                    "original vanilla tangents (captured at import, byte-exact, "
                    "hash-gated so an edited mesh safely falls back to MikkTSpace) "
                    "instead of regenerating them. Needed for WDF / PackedTBN "
                    "meshes whose deformation is stored in tangent space. If a mesh "
                    "looks wrong with this on, turn it OFF — that restores plain "
                    "MikkTSpace tangents (the default, known-good behavior), which "
                    "is never the broken part. Only affects meshes that take the "
                    "DLL path (Preserve Custom Normals ON, no shape keys).",
        default=False,
    )

    use_vertex_remap: BoolProperty(
        name="Use Vertex Remap",
        description="Preserves original vertex ordering for vanilla roundtrips (disable for custom meshes)",
        default=False,
    )

    generate_ctg: BoolProperty(
        name="Generate / repair CTG",
        description="2K26 baseModels only. (1) When the source has no captured CTG "
                    "(a Blender-only build, or an older head/body modded in), "
                    "synthesize an identity render-space CTG for M_Head/M_Body so "
                    "the game has a valid table instead of none. (2) When a CTG WAS "
                    "captured but the head/body was ported or re-topologized so its "
                    "render vert count no longer matches the captured table, replace "
                    "just that mesh's table with a count-matched identity table "
                    "(passing a stale wrong-sized table through would deform). "
                    "Identity means no vertex reorder, so it cannot deform the mesh. "
                    "Meshes whose counts still match pass through byte-exact. "
                    "Leave off for vanilla roundtrips and attires.",
        default=False,
    )

    belt_cs_fix: BoolProperty(
        name="1 LOD (Belts & Props)",
        description="Exports with a single LOD level (required for belts and prop "
                    "meshes — multi-LOD exports are invisible in Creation Suite "
                    "until you zoom in past the LOD switch threshold). When off, "
                    "the model is written with the standard 4-LOD wrestler layout",
        default=False,
    )

    def doExport(self, context, filepath, keywords):
        # Forward `self` so reconcile_armature_binding can route errors through
        # self.report() (red UI banner instead of buried in the system console).
        ok = saveModelFile(filepath, keywords, operator=self)
        return {'FINISHED'} if ok else {'CANCELLED'}

    # Adjust the text width for the properties
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        
        box.label(text="Game Options:")
        split = box.split(factor=0.2) 
        split.label(text="Target:")
        split.prop(self, "compile_target") 
        box = layout.box()

        box.label(text="Geometry Options:")
        row = box.row()
        row.prop(self, "use_calculate_tangents")
        row = box.row()
        row.prop(self, "export_shape_keys")
        row = box.row()
        row.prop(self, "preserve_normals")
        # Greyed-out unless Preserve Custom Normals is on: only the DLL path can
        # carry per-loop tangents.
        sub = box.row()
        sub.enabled = self.preserve_normals
        sub.separator()
        sub.prop(self, "preserve_tangents")
        row = box.row()
        row.prop(self, "export_atpts")
        row = box.row()
        row.prop(self, "export_gtpts")
        row = box.row()

        box.label(text="Additional Options:")
        row = box.row()
        row.prop(self, "export_hpl")
        row = box.row()
        row.prop(self, "generate_mtls")
        # Greyed-out unless generate_mtls is on.
        sub = box.row()
        sub.enabled = self.generate_mtls
        sub.separator()  # crude indent
        sub.prop(self, "overwrite_existing_jmtls")
        sub = box.row()
        sub.enabled = self.generate_mtls
        sub.separator()
        sub.prop(self, "material_context", text="Presets")
        row = box.row()
        row.prop(self, "use_vertex_remap")
        row = box.row()
        row.prop(self, "generate_ctg")
        row = box.row()
        row.prop(self, "belt_cs_fix")

        
    def invoke(self, context, event):
        # Pre-select the export target to MATCH the imported source's game version
        # (a 2K25 source -> 'WWE 2K25 MCD v2.09' instead of silently defaulting to
        # 2K26). Visible + overridable in the dialog. Defensive: any failure leaves
        # the default and still opens the file browser via ExportHelper.invoke.
        try:
            tgt = _autodetect_export_target()
            if tgt:
                self.compile_target = tgt
        except Exception:
            pass
        return ExportHelper.invoke(self, context, event)

    def execute(self, context):
        keywords = self.as_keywords(
            ignore=(
                "axis_forward",
                "axis_up",
                "global_scale",
                "check_existing",
                "filter_glob",
            ),
        )
        return self.doExport(context, self.filepath, keywords)
    
def menu_bar_vc_export(self, context):
    self.layout.operator(vCSkinModelExport.bl_idname, text="Visual Concepts Model (.mdl, .mcd)", icon='EVENT_V')

def register_vcs_export():
    bpy.utils.register_class(vCSkinModelExport)
    bpy.types.TOPBAR_MT_file_export.append(menu_bar_vc_export)
    return

def unregister_vcs_export():
    bpy.utils.unregister_class(vCSkinModelExport)
    bpy.types.TOPBAR_MT_file_export.remove(menu_bar_vc_export)
    return