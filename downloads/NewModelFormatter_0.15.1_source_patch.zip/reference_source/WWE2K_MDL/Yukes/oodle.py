"""Oodle Kraken decompressor — thin ctypes wrapper around RAD Tools'
oo2core_*_win64.dll. Used by pac_reader.py to decompress OODL+KRKN
blocks inside HSPC/SHDC containers (WWE 2K17 onward).

The DLL itself is NOT bundled — it's proprietary RAD code shipped with
WWE games. The user supplies it from their installed game (or any
other source). This module locates it at runtime via a search path
that covers the most ergonomic drop-in locations.

Search order:
    1. OODLE_DLL_PATH environment variable (absolute path)
    2. Yukes/oo2core_*_win64.dll (next to this file)
    3. Addon root / oo2core_*_win64.dll
    4. Yukes/Oodle/oo2core_*_win64.dll
Tries versions 6 through 9 in each directory (different games shipped
different oo2core versions; whatever the user has, we'll use it).

The OodleLZ_Decompress signature is documented in the public RAD
header. Per WrestleMINUS's working VB.NET wrapper, the call form is:
    OodleLZ_Decompress(in, in_size, out, out_size,
                       0, 0, 0, 0, 0, 0, 0, 0, 0, 3)
14 arguments; 13 of them zero; last one is the `threadPhase` set to 3
(unthreaded, full decode). Returns the decoded byte count or <=0 on
failure.
"""

import ctypes
import os
import sys
from typing import Optional

_OODLE_VERSIONS = (6, 7, 8, 9)
_DLL_NAME_TEMPLATE = "oo2core_{}_win64.dll"

# Module-level cache: once we attempt to load the DLL (whether or not
# the load succeeds), remember the outcome so subsequent calls don't
# re-walk the filesystem or re-emit the non-win32 warning. Cleared by
# `reset_oodle_cache()` for tests / re-init after the user drops a DLL.
_loaded_dll = None
_loaded_decompress = None
_loaded_path: Optional[str] = None
_load_attempted = False

# Preferences override — an absolute DLL path OR a directory / game folder to
# search. Set by the addon's preferences UI via set_oodle_dll_override(); takes
# priority over auto-discovery but below the OODLE_DLL_PATH env var.
_user_override_path: Optional[str] = None
# Cache of game-install dirs discovered once via _discover_game_oodle_dirs().
_discovered_dirs: Optional[list] = None


def reset_oodle_cache() -> None:
    """Clear the cached load-attempt state. Use after the user drops a
    DLL into the search path, points the preferences at one, or in tests
    that need a fresh resolve."""
    global _loaded_dll, _loaded_decompress, _loaded_path, _load_attempted, _discovered_dirs
    _loaded_dll = None
    _loaded_decompress = None
    _loaded_path = None
    _load_attempted = False
    _discovered_dirs = None


def set_oodle_dll_override(path: Optional[str]) -> None:
    """Point the resolver at a specific oo2core DLL or a folder to search
    (e.g. the installed game directory). Called by the addon preferences.
    Clears the load cache so the next resolve picks it up."""
    global _user_override_path
    _user_override_path = path or None
    reset_oodle_cache()


def _candidate_search_dirs() -> list:
    """Build the ordered list of directories to search for the DLL."""
    here = os.path.dirname(os.path.abspath(__file__))
    addon_root = os.path.dirname(here)  # one level up from Yukes/
    dirs = [
        here,                                      # Yukes/
        addon_root,                                # WWE2K_MDL/
        os.path.join(here, "Oodle"),               # Yukes/Oodle/
        os.path.join(addon_root, "Oodle"),         # WWE2K_MDL/Oodle/
        os.path.join(addon_root, "Link"),          # WWE2K_MDL/Link/ (DLL sibling)
    ]
    return dirs


def _find_oo2core_in(directory: str) -> Optional[str]:
    """Return an oo2core_*_win64.dll directly in `directory` or one level
    below it (games sometimes nest it in a bin/ subdir), or None. Bounded
    to depth 1 so we never recurse a 50 GB game install."""
    import glob
    if not directory or not os.path.isdir(directory):
        return None
    for pat in (os.path.join(directory, "oo2core_*_win64.dll"),
                os.path.join(directory, "*", "oo2core_*_win64.dll")):
        hits = sorted(glob.glob(pat))
        if hits:
            return hits[0]
    return None


def _discover_game_oodle_dirs() -> list:
    """Locate installed WWE 2K game directories (which ship oo2core) so the
    addon works out-of-the-box without the user hand-copying the DLL.

    Walks Steam: SteamPath from the registry (+ common install roots) ->
    steamapps/libraryfolders.vdf -> every library's steamapps/common ->
    any 'WWE 2K*' folder. Pure-python, cached, best-effort (any failure is
    swallowed — discovery is a convenience, not a requirement)."""
    global _discovered_dirs
    if _discovered_dirs is not None:
        return _discovered_dirs
    found = []
    try:
        steam_roots = set()
        try:
            import winreg
            for hive, key, val_name in (
                (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath"),
            ):
                try:
                    with winreg.OpenKey(hive, key) as k:
                        v, _ = winreg.QueryValueEx(k, val_name)
                        if v:
                            steam_roots.add(os.path.normpath(v))
                except OSError:
                    pass
        except Exception:
            pass
        for base in (r"C:\Program Files (x86)\Steam", r"C:\Program Files\Steam"):
            if os.path.isdir(base):
                steam_roots.add(base)

        lib_paths = set(steam_roots)
        for sr in steam_roots:
            vdf = os.path.join(sr, "steamapps", "libraryfolders.vdf")
            try:
                with open(vdf, "r", encoding="utf-8", errors="ignore") as f:
                    txt = f.read()
                import re
                for m in re.finditer(r'"path"\s*"([^"]+)"', txt):
                    lib_paths.add(os.path.normpath(m.group(1).replace("\\\\", "\\")))
            except OSError:
                pass

        for lib in lib_paths:
            common = os.path.join(lib, "steamapps", "common")
            if not os.path.isdir(common):
                continue
            try:
                for name in os.listdir(common):
                    nm = name.lower().replace(" ", "")
                    if nm.startswith("wwe2k"):
                        found.append(os.path.join(common, name))
            except OSError:
                pass
    except Exception:
        pass
    _discovered_dirs = found
    return found


def find_oodle_dll() -> Optional[str]:
    """Return the absolute path of the first Oodle DLL we find, or None.

    Resolution order (first hit wins):
      1. OODLE_DLL_PATH env var (explicit absolute path).
      2. Preferences override (set_oodle_dll_override) — a DLL path, or a
         directory / game folder to search.
      3. Addon-relative drop-in dirs (Yukes/, WWE2K_MDL/, .../Oodle, Link).
      4. Auto-discovered installed WWE 2K game dirs (Steam) — the game ships
         oo2core, so this makes import work with zero manual setup.
    """
    env_path = os.environ.get("OODLE_DLL_PATH")
    if env_path and os.path.isfile(env_path):
        return env_path

    if _user_override_path:
        if os.path.isfile(_user_override_path) and \
                os.path.basename(_user_override_path).lower().startswith("oo2core"):
            return _user_override_path
        hit = _find_oo2core_in(_user_override_path)
        if hit:
            return hit

    for d in _candidate_search_dirs():
        for v in _OODLE_VERSIONS:
            p = os.path.join(d, _DLL_NAME_TEMPLATE.format(v))
            if os.path.isfile(p):
                return p

    for gdir in _discover_game_oodle_dirs():
        hit = _find_oo2core_in(gdir)
        if hit:
            return hit
    return None


def _load_dll():
    """Lazily load the DLL and bind OodleLZ_Decompress. Returns
    (decompress_fn, dll_path) or (None, None) on failure.

    Caches BOTH success and failure: a missing DLL is just as expensive
    to re-resolve (filesystem walk across 5 dirs × 4 versions) as a
    successful one, and `oodle_available()` is called from hot paths
    (status checks during HSPC scans). The cache is module-level and
    cleared via `reset_oodle_cache()`.
    """
    global _loaded_dll, _loaded_decompress, _loaded_path, _load_attempted

    if _load_attempted:
        return _loaded_decompress, _loaded_path

    _load_attempted = True  # mark attempt up-front so failures cache too

    if sys.platform != "win32":
        # oo2core_*_win64.dll is a Windows binary. Print once (not on
        # every call) so non-Windows users see a clear "why" message
        # without spamming the console.
        print("[oodle] Oodle decompression not available on this platform "
              "(Windows only — oo2core_*_win64.dll is a Win64 binary).")
        return None, None

    path = find_oodle_dll()
    if path is None:
        return None, None

    try:
        dll = ctypes.WinDLL(path)
    except OSError:
        return None, None

    # OodleLZ_Decompress signature — matches WrestleMINUS's working
    # P/Invoke declaration. 14 args, all the "miscellaneous" ones
    # passed as zero; the last (thread_phase) is 3 = full decode in
    # current thread, no callbacks, no scratch memory.
    fn = dll.OodleLZ_Decompress
    fn.argtypes = [
        ctypes.c_char_p,   # compBuf
        ctypes.c_int64,    # compBufSize
        ctypes.c_char_p,   # rawBuf (output)
        ctypes.c_int64,    # rawLen
        ctypes.c_uint32,   # fuzzSafe
        ctypes.c_uint32,   # checkCRC
        ctypes.c_uint64,   # verbosity
        ctypes.c_uint32,   # decBufBase
        ctypes.c_uint32,   # decBufSize
        ctypes.c_uint32,   # fpCallback
        ctypes.c_uint32,   # callbackUserData
        ctypes.c_uint32,   # decoderMemory
        ctypes.c_uint32,   # decoderMemorySize
        ctypes.c_uint32,   # threadPhase
    ]
    fn.restype = ctypes.c_int64

    _loaded_dll = dll
    _loaded_decompress = fn
    _loaded_path = path
    return fn, path


def oodle_available() -> bool:
    """True if the DLL can be loaded right now."""
    fn, _ = _load_dll()
    return fn is not None


def get_oodle_status() -> dict:
    """Diagnostic info — used by the importer to build helpful error
    messages. Returns a dict with platform, dll_path (or None), the
    DLL's basename (or None), and a `searched_paths` list of
    directories that were checked."""
    fn, path = _load_dll()
    return {
        "platform":       sys.platform,
        "dll_loaded":     fn is not None,
        "dll_path":       path,
        "dll_name":       os.path.basename(path) if path else None,
        "searched_paths": _candidate_search_dirs(),
        "game_dirs":      _discover_game_oodle_dirs(),
        "pref_override":  _user_override_path,
        "env_override":   os.environ.get("OODLE_DLL_PATH"),
    }


def decompress_kraken(compressed: bytes, uncompressed_size: int) -> bytes:
    """Decompress a Kraken-compressed buffer.

    Args:
        compressed: The raw Kraken-compressed bytes (no OODL/KRKN
            wrapper headers — just the algorithm payload).
        uncompressed_size: Decoded length as advertised by the OODL
            block's +0x10 field.

    Returns:
        Decompressed bytes of exactly `uncompressed_size` length.

    Raises:
        RuntimeError if the DLL isn't loaded.
        ValueError if decompression returns <= 0 (Oodle's failure
            indicator) or doesn't produce the expected byte count.
    """
    fn, path = _load_dll()
    if fn is None:
        raise RuntimeError(
            "Oodle DLL not found. Drop oo2core_6_win64.dll (or _7_, _8_, _9_) "
            "into the WWE2K_MDL/Yukes/ folder of your installed addon, or set "
            "OODLE_DLL_PATH to an absolute path."
        )

    # Output buffer must be heap-allocated and writable. A ctypes c_char
    # array is a mutable byte buffer the DLL can write into. Equivalent
    # to create_string_buffer(uncompressed_size) for our usage — both
    # expose .raw of exactly the requested size — but a bit lower-level
    # and skips the create_string_buffer init-path overhead.
    out_buf = (ctypes.c_char * uncompressed_size)()

    n = fn(
        compressed, len(compressed),
        out_buf, uncompressed_size,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 3,
    )

    if n <= 0:
        raise ValueError(
            f"OodleLZ_Decompress returned {n} (failure). "
            f"compressed_size={len(compressed)}, expected_uncompressed={uncompressed_size}."
        )
    if n != uncompressed_size:
        raise ValueError(
            f"OodleLZ_Decompress produced {n} bytes, expected {uncompressed_size}."
        )

    return out_buf.raw[:uncompressed_size]
