"""
YOBJ/JBOY format constants — single source of truth for offsets and sizes.

Rules of thumb for offsets:
 - Most stored "_offset" values are RAW; data starts at (raw_offset + START_OFFSET).
 - Exception: `vertex_offset` is also RAW, but it points to an 8-byte pad
   followed by a uint32[] frame offset table (each entry also RAW, needing
   +START_OFFSET to reach actual frame data).
"""

START_OFFSET = 8

# === File-level header offsets ===
HDR_MAGIC          = 0x00
HDR_FILE_SIZE      = 0x04
HDR_VERSION        = 0x10  # observed: 3 in 2K19
HDR_MESH_COUNT     = 0x18
HDR_MESH_TABLE_OFF = 0x1C
HDR_BONE_COUNT     = 0x20
HDR_UNK_24         = 0x24
HDR_SKEL_OFF       = 0x28
HDR_TEX_OFF        = 0x2C
HDR_MTL_OFF        = 0x30
HDR_MTL_COUNT      = 0x34
HDR_MORPH_NAME_OFF = 0x4C
HDR_BONE_PALETTE_OFF = 0x54

# === Mesh header: 184 bytes per mesh (2K15-2K19 layout, version field = 3) ===
MESH_STRIDE = 184

MESH_VERTEX_COUNT       = 0x00
MESH_FACE_SEC           = 0x04
MESH_USED_BONE_COUNT    = 0x08
MESH_INLINE_PALETTE     = 0x0C   # 20 × uint32 (slot positions matter; 0xFFFFFFFF = unused)
MESH_INLINE_PALETTE_SLOTS = 20
MESH_WEIGHT_COUNT       = 0x5C
MESH_MATERIAL_ID        = 0x60
MESH_MORPH_COUNT        = 0x64   # includes basis (1 = no morphs, just base; 113 = 112 morphs)
MESH_VERTEX_OFFSET      = 0x68   # RAW, special structure
MESH_WEIGHT_OFFSET      = 0x6C   # RAW (+ START_OFFSET for data)
MESH_UV_OFFSET          = 0x70   # RAW (+ START_OFFSET for data)
MESH_NORMAL_OFFSET      = 0x74   # RAW (+ START_OFFSET for data)
MESH_SHADER_TYPE        = 0x7C   # 8 bytes
MESH_SHADER_TYPE_LEN    = 8
MESH_FACE_COUNT         = 0x90
MESH_SHADER_PARAM_COUNT = 0x94
MESH_SHADER_PARAM_OFF   = 0x98   # RAW (+ START_OFFSET)
MESH_FACE_OFFSET        = 0x9C   # RAW (+ START_OFFSET)
MESH_VERTEX_COUNT2      = 0xA0   # always equals vertex_count
MESH_BBOX_PIVOT         = 0xA8   # 4 floats: small_radius/scale, then xyz center

# === Mesh header: 180 bytes per mesh (SVR-era / WWE 12/13 layout, version field = 0) ===
# Differences vs 2K15-19:
#  - Shader name slot is 16 bytes at +0x78 (vs 8 bytes at +0x7C with a 4-byte
#    unknown at +0x78 in newer format).
#  - Removing that 4-byte unk shifts every later field by -4: face_count,
#    shader_param_count, shader_param_offset, face_offset, vertex_count2,
#    and bbox_pivot all live 4 bytes earlier.
MESH_STRIDE_LEGACY = 180

MESH_SHADER_TYPE_LEGACY     = 0x78
MESH_SHADER_TYPE_LEN_LEGACY = 16
MESH_FACE_COUNT_LEGACY      = 0x8C
MESH_SHADER_PARAM_COUNT_LEGACY = 0x90
MESH_SHADER_PARAM_OFF_LEGACY   = 0x94
MESH_FACE_OFFSET_LEGACY     = 0x98
MESH_VERTEX_COUNT2_LEGACY   = 0x9C
MESH_BBOX_PIVOT_LEGACY      = 0xA4

VERSION_LEGACY = 0   # SVR 08-11, WWE 12, WWE 13 (probably)
VERSION_2K15_19 = 3

# === Vertex stream stride ===
VERTEX_STRIDE = 28               # pos(12) + nrm(12) + tail(4)
VERTEX_POS_OFF = 0
VERTEX_NRM_OFF = 12
VERTEX_TAIL_OFF = 24

# === Weight stream stride ===
WEIGHT_STRIDE = 8                # bone_idx_le_u32(4) + weight_be_f32(4)
WEIGHT_PADDING_INDEX = 0xFFFFFFFF

# === UV stream stride ===
UV_STRIDE = 8                    # 2 × float32
UV_HAIR_STRIDE = 16              # 2 UV layers × 8 bytes (yCS_hair shaders)

# === Skeleton: 80 bytes per bone ===
BONE_STRIDE = 80
BONE_NAME = 0
BONE_NAME_LEN = 16
BONE_POS = 16     # 3 floats + 1 pad
BONE_EULER = 32   # 3 floats + 1 pad
BONE_PARENT = 48
BONE_TAIL = 64    # 4 floats — bind-pose tail position (NOT a quaternion)

# === Material: 32 bytes per material ===
MATERIAL_STRIDE = 32
MATERIAL_NAME = 0
MATERIAL_NAME_LEN = 16
MATERIAL_EXTRAS = 16   # 4 × uint32: (morph_count, ?, tex_idx, ?)

# === Texture name table ===
TEX_HEADER_SIZE = 8       # 2 × float32 (UV scale?)
TEX_NAME_STRIDE = 16

# === Morph name table ===
MORPH_HEADER_SIZE = 8     # uint32 count, uint32 ?
MORPH_NAME_STRIDE = 16

# === Face data header (at face_offset + START_OFFSET) ===
FACE_CHECK_VALUE = 6
FACE_CHECK_OFFSET = 0
FACE_INDEX_COUNT_OFFSET = 4
FACE_DATA_OFFSET = 8      # RAW value, needs + START_OFFSET

# === Tristrip restart marker ===
TRISTRIP_RESTART = 0xFFFF

# === Magic numbers ===
MAGIC_JBOY = b'JBOY'
MAGIC_YOBJ = b'YOBJ'
