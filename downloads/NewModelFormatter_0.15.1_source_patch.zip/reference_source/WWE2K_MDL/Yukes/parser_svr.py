"""
SVR06 YOBJ Parser - Parser for SmackDown vs Raw 2006 era YOBJ files.
These files have a different structure than WWE 2K14+ YOBJ files.

SVR06 Format:
- Fixed 64-byte mesh headers stored contiguously
- Submesh entries contain position/normal offsets
- Position format: Y, Z, X, W (16 bytes)
- Normal format: X, Y, Z, W (16 bytes)
- Triangle strip faces (implicit from vertex order)
"""

import numpy as np
from typing import List, Optional, Tuple
from .binary_reader import BinaryReader
from .format_consts import START_OFFSET
from .structures import (
    YOBJModel, YOBJHeader, Bone, Material, Mesh, MorphTarget
)

# Tri-strip restart sentinel — matches the yukes_format.h C++ constant.
# Used both inline within the file's strip data (vertex index 0xFFFF or
# above = restart) and inserted between concatenated strips below.
TRISTRIP_RESTART = 0xFFFF


def _tristrip_to_trilist(indices):
    """Walk a flat tri-strip index buffer with 0xFFFF restart markers and
    emit triangles with alternating winding. Port of the C++
    convertTristripToTriList (yukes_tristrip.cpp).

    Degenerate triangles (any two indices equal) are skipped but DO
    still flip the winding — that's how strips encode a winding swap
    mid-strip without an explicit restart marker.
    """
    out = []
    i = 0
    n = len(indices)
    while i + 2 < n:
        a = indices[i]
        b = indices[i + 1]
        if a == TRISTRIP_RESTART or b == TRISTRIP_RESTART:
            i += 1
            continue
        winding = 1
        i += 2
        while i < n:
            c = indices[i]
            if c == TRISTRIP_RESTART:
                i += 1
                break
            if a != b and b != c and c != a:
                if winding > 0:
                    out.append((a, b, c))
                else:
                    out.append((a, c, b))
            a = b
            b = c
            winding = -winding
            i += 1
    return out


def _parse_explicit_face_data_svr06(reader, face_data_off_raw, max_vidx_exclusive):
    """Read SVR06's explicit per-strip face descriptors and emit a list
    of triangle index triples. Port of yukes_loader_svr06.cpp::
    parseExplicitFaceData.

    The face-data block sits at face_data_off_raw + START_OFFSET. It
    holds 1..16 descriptor slots spaced 0xD0 bytes apart, starting at
    +0xC0. Each descriptor enumerates a set of triangle strips. The
    vertex indices in those strips reference the mesh-global vertex
    array (concatenation of all submesh position blocks).
    """
    if face_data_off_raw == 0:
        return []

    file_size = reader.size()
    fd = face_data_off_raw + START_OFFSET

    FIRST_DESC_OFF = 0xC0
    DESC_SLOT_STRIDE = 0xD0
    MAX_DESCRIPTORS = 16

    joined = []  # flat index buffer with 0xFFFF separators

    for d in range(MAX_DESCRIPTORS):
        desc_off = fd + FIRST_DESC_OFF + d * DESC_SLOT_STRIDE
        if desc_off + 16 > file_size:
            break

        # magic_lo at +0x00 indicates a valid descriptor slot. Two
        # values seen in the wild:
        #   0x0001 — SVR06 (Smackdown vs Raw 2006 era)
        #   0x0002 — pre-SVR / earlier Yukes engine (SmackDown Just
        #            Bring It and similar; identical strip-record and
        #            strip-data layout, only the descriptor tag differs)
        # A mismatch on both means we've walked past the last used
        # descriptor slot.
        reader.seek(desc_off)
        magic_lo = reader.read_uint16()
        if magic_lo not in (0x0001, 0x0002):
            break

        reader.seek(desc_off + 4)
        strip_count = reader.read_int32()
        records_raw = reader.read_int32()
        records_end_raw = reader.read_int32()
        if strip_count <= 0 or strip_count > 1024:
            break

        # records_math: ptr1 + count*16 must equal ptr2; failure
        # indicates an unused descriptor slot.
        if records_raw + strip_count * 16 != records_end_raw:
            break

        records_base = records_raw + START_OFFSET
        if records_base + strip_count * 16 > file_size:
            break

        for r in range(strip_count):
            rec_off = records_base + r * 16
            reader.seek(rec_off + 8)
            f2 = reader.read_int32()
            data_raw = reader.read_int32()
            if f2 < 3 or f2 > 1024:
                continue
            data_base = data_raw + START_OFFSET
            if data_base + f2 * 32 > file_size:
                continue

            if joined:
                joined.append(TRISTRIP_RESTART)

            for e in range(f2):
                reader.seek(data_base + e * 32 + 12)
                idx = reader.read_int32()
                joined.append(idx if idx <= 0xFFFE else TRISTRIP_RESTART)

    if not joined:
        return []

    tris = _tristrip_to_trilist(joined)
    # Defensive: skip any triangle that references a vertex outside the
    # mesh's accumulated position array. Should be a no-op on valid
    # files but protects against malformed descriptors.
    return [list(t) for t in tris
            if t[0] < max_vidx_exclusive
            and t[1] < max_vidx_exclusive
            and t[2] < max_vidx_exclusive]


def is_svr06_format(reader: BinaryReader) -> bool:
    """
    Detect if this is an SVR06 era YOBJ file.
    
    SVR06 format characteristics:
    - Little-endian YOBJ magic
    - Fixed 64-byte mesh headers
    - Header offset at 0x24 is typically 0x40
    - Object count at 0x18 matches mesh header count
    """
    reader.seek(0)
    magic = reader.read_bytes(4)
    
    if magic != b'YOBJ':
        return False
    
    reader.set_endian(False)  # SVR06 is little-endian
    
    # Check header structure
    reader.seek(0x24)
    header_offset = reader.read_int32()
    
    # SVR06 typically has header_offset = 0x40
    if header_offset != 0x40:
        return False
    
    # Check if mesh headers are 64 bytes apart
    reader.seek(header_offset + 8)
    first_draw = reader.read_int32()
    first_mat = reader.read_int32()
    
    reader.seek(header_offset + 8 + 64)
    second_draw = reader.read_int32()
    second_mat = reader.read_int32()
    
    # Both should have reasonable draw counts (1-50) and material indices (<100)
    if (1 <= first_draw <= 50 and first_mat < 100 and
        1 <= second_draw <= 50 and second_mat < 100):
        return True
    
    return False


def parse_header_svr06(reader: BinaryReader) -> YOBJHeader:
    """Parse SVR06 format header."""
    reader.seek(0)
    reader.set_endian(False)  # SVR06 is little-endian
    
    magic = reader.read_bytes(4)
    
    # Skip to relevant header fields
    reader.seek(0x18)
    
    header = YOBJHeader(
        magic=magic,
        is_big_endian=False,
        object_count=reader.read_int32(),      # 0x18
        bone_count=0,
        material_count=0,
        header_offset=0,
        skeleton_offset=0,
        texture_offset=0,
        material_offset=0,
        bone_palette_offset=0,
    )
    
    reader.skip(4)  # 0x1C: total submesh count (informational)
    header.bone_count = reader.read_int32()    # 0x20
    header.header_offset = reader.read_int32() + START_OFFSET  # 0x24
    header.skeleton_offset = reader.read_int32()  # 0x28
    header.material_offset = reader.read_int32()  # 0x2C
    # 0x30: unknown offset
    
    return header


def _looks_like_bone_name(raw16: bytes) -> bool:
    """Heuristic name check matching yukes_loader_svr06.cpp::looksLikeName.
    Stops bone-parsing at the first slot whose 16-byte name field doesn't
    start with an ASCII identifier character — that's where the skeleton
    section's padding (or the next file section) begins."""
    if not raw16:
        return False
    first = raw16[0]
    # Allowed: letters, underscore. SVR-era names are all lowercase ASCII
    # like 'l_momo', 'r_ashi', 'kubi', 'u_kuchi_00'.
    if not ((0x41 <= first <= 0x5A) or (0x61 <= first <= 0x7A) or first == 0x5F):
        return False
    # The name body up to the first NUL must be printable ASCII; reject
    # if a non-printable byte appears before the terminator.
    for byte in raw16:
        if byte == 0:
            return True
        if byte < 0x20 or byte > 0x7E:
            return False
    return True  # name fills the whole 16-byte slot


def parse_bones_svr06(reader: BinaryReader, header: YOBJHeader) -> List[Bone]:
    """
    Parse SVR06 skeleton bone data.

    SVR06 bones are stored at 80-byte intervals with:
    - Name at offset 0 (null-terminated, ~16 bytes)
    - Transform data
    - Parent index at offset 0x30

    The header's ``bone_count`` field is unreliable on SVR06 — the test
    file's header says 21 but the section actually contains 91 bones,
    and the difference matters: vertex skinning references bone indices
    as high as 80+, so a too-low bone count leaves most of the skeleton
    unloaded and every vertex on those bones drops to root.

    Mirroring yukes_loader_svr06.cpp::parseBones: derive ``max_bones``
    from the section span ``(material_offset - skeleton_offset) /
    BONE_SIZE`` (the skeleton section ends where materials begin) and
    early-exit on the first slot whose name doesn't look like an ASCII
    identifier — that's the section padding boundary.
    """
    if header.skeleton_offset == 0:
        return []

    bones = []
    BONE_SIZE = 80

    # SVR06 bone layout (80 bytes, same shape as the 2K-era v3 format):
    #   +0x00  char[16]  name
    #   +0x10  float[3]  position (parent-relative)
    #   +0x1C  float     scale-or-pad (always 1.0 in vanilla — not used)
    #   +0x20  float[3]  euler rotation (radians)
    #   +0x2C  uint32    pad
    #   +0x30  int32     parent_index (-1 = no parent; sometimes self for root)
    #   +0x34  byte[12]  pad
    #   +0x40  float[4]  bind-pose tail (preserved verbatim for round-trip)
    # Earlier this function only read +0x1C as a 3-float "position" —
    # that's actually the scale slot, so every bone came out at
    # (1, 0, 0) and the rig collapsed in Blender.

    skel_start = header.skeleton_offset + START_OFFSET
    if header.material_offset > 0:
        skel_end = header.material_offset + START_OFFSET
        max_bones = (skel_end - skel_start) // BONE_SIZE if skel_end > skel_start else 0
    else:
        # No material offset to clamp against; fall back to the header
        # count if it's plausibly set, else a defensive ceiling.
        max_bones = header.bone_count if header.bone_count > 0 else 100

    if max_bones <= 0:
        return bones

    reader.seek(skel_start)
    raw = reader.read_bytes(max_bones * BONE_SIZE)
    actual_n_bones = 0  # used for parent_idx range-check after the loop

    for i in range(max_bones):
        b = raw[i * BONE_SIZE : (i + 1) * BONE_SIZE]

        # Early-exit on first slot that doesn't look like a valid name —
        # this is the section's padding boundary. The header's nominal
        # count is unreliable so we can't just trust max_bones; the only
        # robust delimiter is "the names stop being names".
        if not _looks_like_bone_name(b[:16]):
            break

        try:
            name = b[:16].split(b'\x00', 1)[0].decode('ascii', errors='replace')
        except Exception:
            name = f'bone_{i}'
        if not name:
            name = f'bone_{i}'

        position = np.frombuffer(b[0x10:0x1C], dtype='<f4').astype(np.float32, copy=True)
        rotation = np.frombuffer(b[0x20:0x2C], dtype='<f4').astype(np.float32, copy=True)
        tail     = np.frombuffer(b[0x40:0x50], dtype='<f4').astype(np.float32, copy=True)

        parent_idx = int(np.frombuffer(b[0x30:0x34], dtype='<i4')[0])
        # Coerce self-references and out-of-range parents to -1. The
        # range check uses max_bones (the upper bound) since we don't
        # know the actual final count until the loop finishes — a few
        # parents may temporarily look in-range but reference bones
        # that turn out to be padding; those get pruned in the post-pass
        # below.
        if parent_idx < -1 or parent_idx >= max_bones or parent_idx == i:
            parent_idx = -1

        bones.append(Bone(
            name=name,
            index=i,
            parent_index=parent_idx,
            position=position,
            rotation=rotation,
            tail=tail,
        ))

    # Post-pass: now that we know the actual bone count, retro-prune
    # any parent_idx that referenced a slot which turned out to be
    # padding (max_bones >= actual_count, so the in-loop check used the
    # ceiling; tighten it here).
    actual_count = len(bones)
    for b in bones:
        if b.parent_index >= actual_count:
            b.parent_index = -1

    return bones


def parse_materials_svr06(reader: BinaryReader, header: YOBJHeader) -> List[Material]:
    """Parse SVR06 material data."""
    if header.material_offset == 0:
        return []
    
    reader.seek(header.material_offset + START_OFFSET)
    materials = []
    
    # Read materials until we hit invalid data
    # Material structure appears to be 32 bytes with name at start
    max_materials = 50  # Safety limit
    
    for i in range(max_materials):
        name_bytes = reader.read_bytes(16)
        reader.skip(16)  # Rest of material entry
        
        # Decode name and check validity
        name = name_bytes.decode('ascii', errors='ignore').split('\x00')[0]
        
        # Valid material names should start with alphanumeric or underscore
        if not name or not name[0].isalnum() and name[0] != '_':
            break
        
        # Check for control characters indicating end of valid materials
        if any(ord(c) < 32 for c in name):
            break
            
        materials.append(Material(
            name=name,
            index=i,
        ))
    
    return materials


def parse_mesh_svr06(
    reader: BinaryReader,
    mesh_idx: int,
    mesh_offset: int,
    materials: List[Material],
    bones: List[Bone],
    flip_uvs: bool = True,
) -> Mesh:
    """Parse a single SVR06 mesh."""
    
    reader.seek(mesh_offset)
    
    # Read mesh header (64 bytes)
    draw_count = reader.read_int32()      # 0x00
    material_id = reader.read_int32()     # 0x04
    submesh_offset = reader.read_int32()  # 0x08 - points to submesh entries
    face_data_offset = reader.read_int32()  # 0x0C
    reader.skip(8)                         # 0x10-0x17: unknown
    weight_offset = reader.read_int32()   # 0x18
    uv_offset = reader.read_int32()       # 0x1C
    vertex_count = reader.read_int32()    # 0x20
    face_count = reader.read_int32()      # 0x24
    submesh_stride = reader.read_int32()  # 0x28
    reader.skip(4)                         # 0x2C: unknown
    bbox = reader.read_float32_array(4)   # 0x30-0x3F: bounding box
    
    # Get material name
    if material_id < len(materials):
        mat_name = materials[material_id].name
        mesh_name = mat_name
    else:
        mat_name = f"Material_{material_id}"
        mesh_name = f"Mesh_{mesh_idx}"
    
    # Parse submesh entries at submesh_offset + 8
    submesh_base = submesh_offset + START_OFFSET
    
    all_positions = []
    all_normals = []
    all_bone_indices = []
    all_bone_weights = []
    face_indices = []
    vertex_base = 0
    max_influences = 0

    # SVR06 bone palette / slot remapping.
    #
    # Other Yukes-era formats (1519 v0/v3) carry a single mesh-header
    # bone palette; vertices store SLOT indices (0..19) and the builder
    # remaps slot → real bone index via that palette. SVR06 instead
    # carries per-submesh 4-bone palettes inline in the submesh entry
    # — so vertex bone indices effectively reference different bones in
    # different submeshes, and there's no global mesh-level palette on
    # disk.
    #
    # To plug SVR06 into the same builder code path the rest of the
    # importer uses, we build a synthetic 20-slot mesh-level palette as
    # we walk submeshes: every unique bone-index encountered gets
    # assigned the next free slot, then the stored vertex bone-indices
    # reference slots rather than raw bones. Without this remap, the
    # current behaviour relies on the builder's "no palette → raw
    # indices" fallback, which works for files where every referenced
    # bone is in model.bones[raw_idx], but breaks for files where the
    # builder also consults the inline_palette path (export round-trip,
    # skinning resolution from custom props, etc.) and finds an
    # unpopulated palette.
    #
    # bone_palette_full = the 20-slot mesh palette (with 0xFFFFFFFF
    #                     padding for unused slots) — stashed on
    #                     mesh.inline_palette_full for round-trip.
    # mesh_bone_palette = flat 4-per-submesh × draw_count list of raw
    #                     bone indices including 0xFFFFFFFF padding
    #                     entries, preserved verbatim for export.
    bone_palette_full = [0xFFFFFFFF] * 20
    palette_used = 0
    mesh_bone_palette = []

    def _get_or_assign_slot(raw_bone_idx):
        nonlocal palette_used
        for i in range(palette_used):
            if bone_palette_full[i] == raw_bone_idx:
                return i
        if palette_used < 20:
            bone_palette_full[palette_used] = raw_bone_idx
            palette_used += 1
            return palette_used - 1
        # Overflow — shouldn't happen for vanilla files (max observed
        # ~13 unique bones per mesh). Fall back to slot 0 so the
        # vertex still lands on a real bone instead of dropping out.
        return 0

    # Track per-submesh vertex ranges (start, end) in mesh-global vertex
    # space so we can group submeshes into anatomically-connected
    # components after the face data is read. SVR06 packs anatomically
    # unrelated geometry into one "mesh" when they share a material
    # (e.g., mesh23 in the test file contains 26 face submeshes + 3
    # right-foot submeshes under material_id=2). The explicit face data
    # never bridges between disconnected anatomical pieces, so triangle
    # connectivity across submesh boundaries is the natural split
    # criterion. See _split_mesh_by_topology below.
    submesh_bounds = []  # list of (start, end) vert indices, one per submesh
    submesh_bone_palettes = []  # raw 4-bone palette per submesh, for diagnostics

    for s in range(draw_count):
        sub_off = submesh_base + s * 32
        reader.seek(sub_off)

        sub_vert_count = reader.read_int32()
        sub_bone_count = reader.read_int32()
        sub_pos_offset = reader.read_int32() + START_OFFSET
        sub_norm_offset = reader.read_int32() + START_OFFSET
        sub_bone_ids = [reader.read_int32() for _ in range(4)]

        # Preserve the raw 4-bone-per-submesh palette verbatim
        # (including 0xFFFFFFFF padding) for export round-trip.
        for raw in sub_bone_ids:
            mesh_bone_palette.append(raw & 0xFFFFFFFF)

        # Filter valid bone indices and assign each a mesh-level slot.
        # valid_slots holds the SLOT each bone got, parallel to
        # valid_bones for the (≤4) entries that go into vertex weights.
        valid_bones = []
        valid_slots = []
        for b in sub_bone_ids:
            if 0 <= b < 256:
                valid_bones.append(b)
                valid_slots.append(_get_or_assign_slot(b))
        max_influences = max(max_influences, len(valid_bones))
        
        # Read position data (16 bytes/vertex: X, Y, Z, W=1.0). Earlier
        # this read the floats as (Y, Z, X, W) and stored [X, Y, Z], but
        # the resulting mesh ended up rotated ~90° relative to the
        # skeleton in Blender — vertex 0 of mesh 0 (the head) came out at
        # (-1.64, -0.087, -8.55) when the head bone was at (0, -7.86,
        # -0.44). Reading the first three floats directly as X, Y, Z and
        # discarding the trailing 1.0 W coordinate places the head mesh
        # right where the head bone is.
        #
        # NB: NO Y/Z/X swap here — that swap is SVR07-only. SVR06 reads
        # positions and normals direct as (X, Y, Z, W) and drops W.
        pos_block = reader.f32_array_at(sub_pos_offset, sub_vert_count * 4).reshape(-1, 4)
        all_positions.extend(pos_block[:, :3].tolist())

        # Per-vertex weight slot/index arrays. Store SLOT indices
        # (0..19) so the builder remaps through inline_palette /
        # bone_palette like it does for 1519 v0/v3 meshes. Empty
        # slots: slot 0 with weight 0 — the builder skips on
        # weight ≤ epsilon, so the slot value is irrelevant.
        bone_idx = [0, 0, 0, 0]
        bone_wgt = [0.0, 0.0, 0.0, 0.0]
        if valid_bones:
            weight = 1.0 / len(valid_bones)
            for i in range(min(len(valid_slots), 4)):
                bone_idx[i] = valid_slots[i]
                bone_wgt[i] = weight
        for _ in range(sub_vert_count):
            all_bone_indices.append(list(bone_idx))
            all_bone_weights.append(list(bone_wgt))

        # Read normal data (same direct (X, Y, Z, W) layout — no swap).
        nrm_block = reader.f32_array_at(sub_norm_offset, sub_vert_count * 4).reshape(-1, 4)
        all_normals.extend(nrm_block[:, :3].tolist())

        submesh_bounds.append((vertex_base, vertex_base + sub_vert_count))
        submesh_bone_palettes.append(tuple(sub_bone_ids))
        vertex_base += sub_vert_count

    # Face indices. SVR06 (and the earlier Yukes pre-SVR engine used in
    # SmackDown Just Bring It and contemporaries) stores EXPLICIT,
    # per-strip vertex indices in a structured face-data block — it is
    # NOT implicit strip-walking on vertex order with spatial-heuristic
    # boundary detection (which was the prior assumption and produced
    # ribbon triangles spanning the body). Layout, matching the
    # YukesModel C++ reference (yukes_loader_svr06.cpp::parseExplicitFaceData):
    #
    #   fd = face_data_offset + START_OFFSET
    #   - fd+0xC0, fd+0x190, fd+0x260, ... (stride 0xD0, up to 16
    #     descriptors per mesh). Stop when magic_lo at +0x00 != 0x0001
    #     and != 0x0002 (pre-SVR uses 0x0002, same layout otherwise), or
    #     records-math fails.
    #   - Each descriptor: magic_lo (u16), strip_count (u32) at +0x04,
    #     records_offset_raw at +0x08, records_end_raw at +0x0C.
    #   - Each record (16 bytes): strip_length at +0x08, data_offset_raw
    #     at +0x0C.
    #   - Each strip data entry (32 bytes): vertex_index (u32) at +0x0C.
    #     0xFFFF (or above) is the restart sentinel.
    #
    # Strips are joined with 0xFFFF restart markers and walked with the
    # standard alternating-winding tri-strip converter (degenerates are
    # skipped but still flip winding — that's how the format encodes a
    # mid-strip winding swap without a restart).
    face_indices = _parse_explicit_face_data_svr06(
        reader, face_data_offset, len(all_positions))
    
    positions = np.array(all_positions, dtype=np.float32)
    normals = np.array(all_normals, dtype=np.float32)
    bone_indices = np.array(all_bone_indices, dtype=np.uint32)
    bone_weights = np.array(all_bone_weights, dtype=np.float32)
    
    # Read UV data
    # UV offset points to UV data with possible header
    uv_base = uv_offset + START_OFFSET + 16  # Skip header
    # Vectorized bulk read of (n_verts, 2) UV array.
    n_verts_uv = len(positions)
    if n_verts_uv > 0:
        uvs = reader.f32_array_at(uv_base, n_verts_uv * 2).reshape(-1, 2).astype(np.float32, copy=False)
    else:
        uvs = np.zeros((0, 2), dtype=np.float32)
    
    # Flip V coordinate if requested
    if flip_uvs:
        uvs[:, 1] = 1.0 - uvs[:, 1]
    
    # SVR06 packs anatomically-unrelated submeshes together by material.
    # Use triangle connectivity to identify topologically separate
    # pieces and emit one Mesh per piece — this turns mesh23's "face +
    # right foot together" into two Blender objects, mesh24's three
    # anatomical regions into three objects, etc. Meshes that are
    # genuinely one connected piece pass through unchanged.
    return _split_mesh_by_topology(
        mesh_idx=mesh_idx,
        base_name=mesh_name,
        material_id=material_id,
        positions=positions,
        normals=normals,
        uvs=uvs,
        face_indices=face_indices,
        bone_indices=bone_indices,
        bone_weights=bone_weights,
        bone_palette_full=bone_palette_full,
        submesh_bounds=submesh_bounds,
        submesh_bone_palettes=submesh_bone_palettes,
        max_influences=max(max_influences, 4),
    )


def _split_mesh_by_topology(*,
                            mesh_idx, base_name, material_id,
                            positions, normals, uvs,
                            face_indices, bone_indices, bone_weights,
                            bone_palette_full, submesh_bounds,
                            submesh_bone_palettes, max_influences):
    """Split a parsed SVR06 mesh into one Mesh per connected component
    of the per-vertex triangle-adjacency graph.

    Algorithm:
      1. Every vertex is a graph node.
      2. For every triangle, union its 3 vertex indices.
      3. Each connected component → one output Mesh containing only
         the verts and faces of that component.

    Vertex-level (rather than submesh-level) granularity matters
    because SVR06 sometimes packs anatomically-distant geometry into
    one submesh when they share a 4-bone palette (e.g., source mesh
    12 sub2 holds 6 upper-body verts at y≈-6 and 7 toe verts at
    y≈+9). Submesh-level union-find can't separate those; vertex-
    level does. Cost is trivially small (~160 verts, ~250 tris per
    SVR06 mesh).

    Meshes with one component pass through unchanged. Multi-component
    meshes get `_p{n}`-suffixed names and the `index` field on each
    output Mesh preserves the source mesh index for traceability.

    Bone palettes are shared across components — each component's
    vertices still reference correct mesh-level slot indices, and
    unused slots are inert (no weight → no vertex group).
    """
    n_verts = len(positions)
    if n_verts == 0:
        return []

    # Vertex-level union-find
    parent = list(range(n_verts))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    # Walk every triangle, union its three vertices
    for tri in face_indices:
        a, b, c = int(tri[0]), int(tri[1]), int(tri[2])
        if 0 <= a < n_verts and 0 <= b < n_verts:
            union(a, b)
        if 0 <= b < n_verts and 0 <= c < n_verts:
            union(b, c)

    # Group vertices by their root component
    components = {}
    for v in range(n_verts):
        root = find(v)
        components.setdefault(root, []).append(v)

    # Drop components with no faces — those are stray verts that no
    # triangle references (the union-find never touched them, so each
    # is its own singleton root). Without this filter, every isolated
    # vert would become its own empty Blender object.
    verts_with_faces = set()
    for tri in face_indices:
        for v in tri:
            verts_with_faces.add(int(v))

    real_components = []
    for root, verts in components.items():
        if any(v in verts_with_faces for v in verts):
            real_components.append(sorted(verts))

    # Single component → original mesh unchanged.
    if len(real_components) <= 1:
        # If there were isolated verts, the single-piece return still
        # carries them — Blender just won't show them as connected
        # geometry, which matches what the pre-split parser did.
        return [Mesh(
            index=mesh_idx,
            name=base_name,
            shader_type="svr06",
            material_index=material_id,
            positions=positions,
            normals=normals,
            uvs=uvs,
            faces=np.array(face_indices, dtype=np.uint32) if face_indices else np.zeros((0, 3), dtype=np.uint32),
            colors=None,
            uvs2=None,
            morph_targets=[],
            bone_indices=bone_indices,
            bone_weights=bone_weights,
            bone_palette=np.array(bone_palette_full, dtype=np.uint32),
            inline_palette_full=tuple(bone_palette_full),
            max_influences=max_influences,
        )]

    # Multi-component: slice arrays per component. Vertices within each
    # component are kept in their original (ascending) order so the
    # builder produces stable indexing.
    output = []
    # Sort components by first vertex index for deterministic output order
    real_components.sort(key=lambda v: v[0])

    # Pre-index: for each vertex, which component is it in?
    vert_component = [-1] * n_verts
    for ci, verts in enumerate(real_components):
        for v in verts:
            vert_component[v] = ci

    # Group faces by component (every triangle's verts are in the same
    # component by union-find invariant; pick any vertex's component).
    component_faces = [[] for _ in real_components]
    for tri in face_indices:
        c = vert_component[int(tri[0])]
        if c >= 0:
            component_faces[c].append(tri)

    for ci, verts in enumerate(real_components):
        # Old → new vertex index map
        old_to_new = {v: i for i, v in enumerate(verts)}
        new_pos  = np.array([positions[v] for v in verts], dtype=np.float32)
        new_norm = np.array([normals[v] for v in verts], dtype=np.float32)
        new_uv   = np.array([uvs[v] for v in verts], dtype=np.float32)
        new_bi   = np.array([bone_indices[v] for v in verts], dtype=np.uint32)
        new_bw   = np.array([bone_weights[v] for v in verts], dtype=np.float32)

        new_faces = [[old_to_new[int(t[0])], old_to_new[int(t[1])], old_to_new[int(t[2])]]
                     for t in component_faces[ci]]

        out_name = f"{base_name}_p{ci}"

        output.append(Mesh(
            index=mesh_idx,  # source mesh idx — for traceability
            name=out_name,
            shader_type="svr06",
            material_index=material_id,
            positions=new_pos,
            normals=new_norm,
            uvs=new_uv,
            faces=np.array(new_faces, dtype=np.uint32) if new_faces else np.zeros((0, 3), dtype=np.uint32),
            colors=None,
            uvs2=None,
            morph_targets=[],
            bone_indices=new_bi,
            bone_weights=new_bw,
            bone_palette=np.array(bone_palette_full, dtype=np.uint32),
            inline_palette_full=tuple(bone_palette_full),
            max_influences=max_influences,
        ))

    return output


def parse_yobj_svr06(
    filepath: str,
    flip_uvs: bool = True,
) -> YOBJModel:
    """
    Parse SVR06 era YOBJ file.
    
    Args:
        filepath: Path to .yobj file
        flip_uvs: Flip V coordinate (1.0 - v)
        
    Returns:
        YOBJModel with all parsed data
    """
    with BinaryReader(filepath) as reader:
        # Parse header
        header = parse_header_svr06(reader)
        
        # Parse bones and materials
        bones = parse_bones_svr06(reader, header)
        materials = parse_materials_svr06(reader, header)
        
        # Parse meshes. Each call returns a LIST of Mesh objects —
        # SVR06 packs anatomically-unrelated submeshes into single
        # material-grouped meshes (e.g., face + right-foot under one
        # material), and parse_mesh_svr06 splits them into separate
        # Mesh objects via triangle-connectivity. Single-piece meshes
        # return a 1-element list.
        meshes = []
        MESH_HEADER_SIZE = 64

        for i in range(header.object_count):
            mesh_offset = header.header_offset + i * MESH_HEADER_SIZE

            mesh_list = parse_mesh_svr06(
                reader, i, mesh_offset,
                materials, bones,
                flip_uvs=flip_uvs,
            )
            meshes.extend(mesh_list)
        
        return YOBJModel(
            version="svr06",
            bones=bones,
            materials=materials,
            meshes=meshes,
            global_bone_palette=None,
        )
