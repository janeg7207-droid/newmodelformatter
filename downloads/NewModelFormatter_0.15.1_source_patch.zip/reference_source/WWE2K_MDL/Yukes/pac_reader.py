"""PAC container reader — extracts embedded YOBJ/JBOY model blobs from
Yukes-era PAC archives.

The PAC format wraps a header (16 bytes: 'PAC ' magic + u32 version +
u32 file_count + 4 bytes), a per-entry index table whose layout varies
across game versions, and the asset payload. Rather than reverse-
engineering the index table for every version (SVR06/07, 2K14, and
the various PSP/PS2/PS3 variants each lay it out differently), we
**scan for embedded YOBJ/JBOY magic bytes** and use each blob's own
self-describing size field (`u32 size_in_bytes` at offset +4 of every
YOBJ/JBOY header) to slice it out. This is robust across all PAC
variants tested so far.

Decompression: some PAC versions wrap their payload in zlib or a
BPE (byte-pair-encoding) stream. Both are handled transparently:
  - zlib via Python stdlib
  - Yukes BPE via the asmodean unrrbpe algorithm (published by
    Luigi Auriemma), implemented inline in `yuke_bpe_decompress`

Known PAC versions and their behaviors:
  v4  - pre-SVR (SmackDown Just Bring It era). Uncompressed payload
        with a single YOBJ blob; descriptor magic in face data is
        0x0002 instead of SVR06's 0x0001 (parser_svr.py handles both).
  v6  - SVR06 era. Uncompressed YOBJ blobs concatenated with a POF0
        fix-up table between them. Fully supported.
  v8  - later-era format. Payload is split into multiple BPE-
        compressed blocks. Each block has a 16-byte header
        ('BPE ' + 0x00000100 dict-size flag + u32 encoded_size +
        u32 decoded_size) followed by encoded data, aligned to 4
        bytes. All blocks decoded and concatenated before YOBJ
        magic-scan extraction.

Public API:
    is_pac_file(data) -> bool
    detect_pac_version(data) -> int | None
    map_bpe_blocks(data) -> list[dict]
    yuke_bpe_decompress(src, target_size, fill_to_target=True) -> bytes
    extract_yobj_blobs(data) -> list[bytes]
    extract_yobj_blobs_from_path(filepath) -> list[bytes]
"""

import struct
import zlib
from typing import List, Optional, Tuple

PAC_MAGIC = b'PAC '
YOBJ_MAGIC = b'YOBJ'
JBOY_MAGIC = b'JBOY'
BPE_MAGIC = b'BPE '
HSPC_MAGIC = b'HSPC'
SHDC_MAGIC = b'SHDC'
PACH_MAGIC = b'PACH'   # alternate inner container inside EPK8 (ZLIB/OODL sub-files)
EPK8_MAGIC = b'EPK8'   # 2K17-19 char-PAC outer wrapper: 0x1C header + 16KB pad + SHDC/PACH
OODL_MAGIC = b'OODL'

# zlib header bytes — first byte 0x78 + a flag byte in {0x01, 0x9C, 0xDA, 0x5E}
_ZLIB_FLAGS = {0x01, 0x9C, 0xDA, 0x5E}


def is_pac_file(data: bytes) -> bool:
    """Quick magic check — fast pre-filter before invoking the extractor."""
    return len(data) >= 4 and data[:4] == PAC_MAGIC


def is_hspc_file(data: bytes) -> bool:
    """Quick HSPC magic check (WWE 2K17+ container)."""
    return len(data) >= 4 and data[:4] == HSPC_MAGIC


def is_epk8_file(data: bytes) -> bool:
    """Quick EPK8 magic check (WWE 2K17-19 char-PAC outer wrapper). EPK8 is
    a thin 0x1C-byte header + zero-pad to a 16 KB boundary around an SHDC
    payload byte-identical to the one inside HSPC, so it decodes through the
    same Oodle/ZLIB SHDC sub-file path once we skip to the SHDC."""
    return len(data) >= 4 and data[:4] == EPK8_MAGIC


def _detect_inner_yukes_container(data: bytes) -> Tuple[bool, bool]:
    """Detect the Yukes named-entry wrapper format used both for some
    2K15-2K19 PACs and (more importantly) for HSPC Oodle-decompressed
    payloads in 2K17+ character PACs. A character PAC's outer HSPC
    decompresses one Oodle block into a buffer that starts with this
    wrapper, which in turn holds multiple named sub-entries — the
    individual YOBJ models, plus sibling entries like "bones" and
    "skin_bone_palette".

    Layout (no fixed 4-byte magic; detection is structural):
        +0x00  u8       endian_flag  (0 = LE, 1 = BE)
        +0x04  u16      material_count  (BE-swapped iff endian_flag)
        +0x06  u16      mesh_count
        +0x08  u32      data_section_offset
        +0x0C           material entries, 36 bytes each
                        ( 32-byte name | u16 mesh_start | u16 mesh_count )
                        mesh entries, 40 bytes each
                        ( 32-byte name | u32 size | u32 other )
                        then the actual concatenated mesh data

    Returns (is_inner, is_big_endian). All structural invariants must
    hold simultaneously; this is enough to discriminate against random
    binary that happens to have a small first byte.
    """
    if len(data) < 0x40:
        return False, False
    endian_flag = data[0]
    if endian_flag not in (0, 1):
        return False, False
    is_be = (endian_flag == 1)
    end = '>' if is_be else '<'
    try:
        mat_count   = struct.unpack_from(f'{end}H', data, 4)[0]
        mesh_count  = struct.unpack_from(f'{end}H', data, 6)[0]
        data_offset = struct.unpack_from(f'{end}I', data, 8)[0]
    except struct.error:
        return False, False
    if not (1 <= mat_count <= 200):
        return False, False
    if not (1 <= mesh_count <= 5000):
        return False, False
    materials_end = 0x0C + mat_count * 36
    meshes_end    = materials_end + mesh_count * 40
    if meshes_end > len(data):
        return False, False
    if not (meshes_end <= data_offset <= len(data)):
        return False, False
    return True, is_be


def _walk_inner_yukes_meshes(data: bytes) -> List[dict]:
    """Walk a Yukes named-entry wrapper and return one descriptor per
    sub-entry:
        { 'name', 'data_offset', 'size', 'other' }

    `name` is the cleaned-up ASCII name (32-byte field, null-terminated).
    `data_offset` is absolute within `data`. Returns [] if the buffer
    doesn't match the wrapper layout.
    """
    is_inner, is_be = _detect_inner_yukes_container(data)
    if not is_inner:
        return []
    end = '>' if is_be else '<'
    mesh_count  = struct.unpack_from(f'{end}H', data, 6)[0]
    data_offset = struct.unpack_from(f'{end}I', data, 8)[0]
    mat_count   = struct.unpack_from(f'{end}H', data, 4)[0]

    meshes_start = 0x0C + mat_count * 36
    cursor       = data_offset
    out: List[dict] = []
    for i in range(mesh_count):
        entry_off = meshes_start + i * 40
        if entry_off + 40 > len(data):
            break
        name_bytes = data[entry_off:entry_off + 32]
        name = name_bytes.split(b'\x00', 1)[0].decode('ascii', errors='replace')
        size  = struct.unpack_from(f'{end}I', data, entry_off + 32)[0]
        other = struct.unpack_from(f'{end}I', data, entry_off + 36)[0]
        if cursor + size > len(data):
            break
        out.append({
            'name':        name,
            'data_offset': cursor,
            'size':        size,
            'other':       other,
        })
        cursor += size
    return out


def detect_pac_version(data: bytes) -> Optional[int]:
    """Return the PAC version (e.g., 4, 6, 8) or None if not a PAC file."""
    if not is_pac_file(data) or len(data) < 8:
        return None
    return struct.unpack_from('<I', data, 4)[0]


def _looks_like_zlib(data: bytes, offset: int = 0) -> bool:
    """Heuristic zlib-stream detector. Checks the 2-byte header for
    a 0x78 first byte and a known FLG.FCHECK in the second."""
    if offset + 2 > len(data):
        return False
    return data[offset] == 0x78 and data[offset + 1] in _ZLIB_FLAGS


def _contains_bpe_blocks(data: bytes) -> bool:
    """True if the buffer contains one or more 'BPE ' block markers
    in the first ~256 bytes after the PAC header — used to detect
    v8-style compressed PACs vs v4/v6-style raw ones."""
    return BPE_MAGIC in data[:0x100]


def _maybe_decompress(data: bytes) -> bytes:
    """If the buffer looks like a zlib stream, return decompressed
    bytes; otherwise return the buffer unchanged. Failures fall
    through silently — the caller's scan-for-magic logic on the raw
    bytes will turn up empty if it really was compressed and we
    couldn't decode it.

    Per-block BPE (Yukes' compression seen in PAC v8) is handled
    separately in `decode_bpe_payload`, not here, because BPE blocks
    are nested inside the PAC structure rather than wrapping the
    whole file.
    """
    if _looks_like_zlib(data):
        try:
            return zlib.decompress(data)
        except zlib.error:
            return data
    return data


def _read_self_size(data: bytes, magic_pos: int) -> int:
    """Each YOBJ/JBOY blob stores its own size at offset +4 of its
    magic. JBOY is always big-endian; YOBJ can be either endian. We
    pick whichever interpretation fits inside the container, with a
    50MB ceiling to reject runaway false positives."""
    if magic_pos + 8 > len(data):
        return 0
    magic = data[magic_pos:magic_pos + 4]
    size_le = struct.unpack_from('<I', data, magic_pos + 4)[0]
    size_be = struct.unpack_from('>I', data, magic_pos + 4)[0]
    LIMIT = 50_000_000
    # JBOY = byte-reversed YOBJ in BE files; its sizes are always BE.
    # YOBJ canonically LE; some 2K17 builds wrote BE. Prefer BE for
    # JBOY, then fall back to LE.
    if magic == JBOY_MAGIC:
        if 0 < size_be < LIMIT and magic_pos + size_be <= len(data):
            return size_be
        if 0 < size_le < LIMIT and magic_pos + size_le <= len(data):
            return size_le
    else:
        if 0 < size_le < LIMIT and magic_pos + size_le <= len(data):
            return size_le
        if 0 < size_be < LIMIT and magic_pos + size_be <= len(data):
            return size_be
    return 0


def _looks_like_real_yobj_header(data: bytes, pos: int) -> bool:
    """Validate that bytes at `pos` form a plausible YOBJ/JBOY header.
    Filters magic-byte false positives — random bytes inside
    compressed payloads, textures, or audio that happen to spell
    YOBJ or JBOY, AND mid-stream slices where the basic header looks
    sane but `skel_off` lands inside mesh-table data rather than the
    real bone table.

    Format-agnostic invariants checked (these hold for SVR06, SVR07,
    2K14, and the 2K15-19 1519 family):

        +0x04  self-size — must fit inside the container.
        +0x18  mesh/object count — 1..1000 plausible.
        +0x1C  mesh_table_off — past basic header, inside the blob.
        +0x20  bone count — 0..5000 plausible.
        +0x28  skel_off — when bone_count>0, must point to a region
               where the bone table (bone_count × 80) fits, the first
               bone's name begins with an ASCII letter/underscore, and
               the first/last bones' parent indices lie in the legal
               range [-1, bone_count-1]. False positives whose
               `skel_off` lands in mesh-table or material-name data
               fail the parent-range check almost every time, because
               random 32-bit values are vanishingly unlikely to fall
               inside a small index range.

    Endianness: JBOY = always BE, YOBJ = probe both, pass if either
    interpretation validates the full chain.
    """
    if pos + 0x40 > len(data):
        return False

    magic = data[pos:pos + 4]
    if magic == JBOY_MAGIC:
        endians = ['>']
    elif magic == YOBJ_MAGIC:
        endians = ['<', '>']
    else:
        return False

    size = _read_self_size(data, pos)
    if size < 0x40:
        return False

    # YOBJ bone struct (matches format_consts.BONE_STRIDE/BONE_PARENT):
    #   +0x00..0x0F  16-byte zero-padded ASCII name
    #   +0x10..0x1F  position (3 floats + pad)
    #   +0x20..0x2F  euler   (3 floats + pad)
    #   +0x30        signed parent index (-1 for root)
    #   +0x40..0x4F  tail (4 floats)
    BONE_STRIDE = 80
    BONE_PARENT = 0x30
    START_OFFSET = 8  # header bytes before in-file offsets are valid

    for endian in endians:
        mesh_count = struct.unpack_from(f'{endian}I', data, pos + 0x18)[0]
        mesh_off   = struct.unpack_from(f'{endian}I', data, pos + 0x1C)[0]
        bone_count = struct.unpack_from(f'{endian}I', data, pos + 0x20)[0]
        skel_off   = struct.unpack_from(f'{endian}I', data, pos + 0x28)[0]

        if not (1 <= mesh_count <= 1000):
            continue
        if not (0 <= bone_count <= 5000):
            continue
        # mesh_off just needs to land inside the blob and leave room
        # for the mesh table. SVR-era accessories legitimately use
        # mesh_off as low as 0x08 (mesh table starts right after the
        # minimal header).
        if not (8 <= mesh_off < size):
            continue
        if mesh_off + mesh_count * 180 > size:
            continue

        # Bone table validation — strong false-positive filter.
        if bone_count > 0:
            bone_table_start = skel_off + START_OFFSET
            if not (0x40 <= bone_table_start < size):
                continue
            if bone_table_start + bone_count * BONE_STRIDE > size:
                continue
            # First bone's name should start with an ASCII letter or
            # underscore. Real bone names are like J_Hips, M_Body,
            # Hair_b00. Mesh-slot data interpreted as a name field
            # tends to start with a digit, a non-printable, or high-
            # bit byte.
            first_byte = data[pos + bone_table_start]
            is_letter = (
                first_byte == ord('_')
                or 0x41 <= first_byte <= 0x5A  # A-Z
                or 0x61 <= first_byte <= 0x7A  # a-z
            )
            if not is_letter:
                continue
            # First bone's parent must be -1 (root) or a valid index.
            first_parent = struct.unpack_from(
                f'{endian}i',
                data,
                pos + bone_table_start + BONE_PARENT,
            )[0]
            if not (first_parent == -1 or 0 <= first_parent < bone_count):
                continue
            # Last bone's parent likewise — two-sample check is enough
            # to reject false positives without scanning every bone.
            if bone_count > 1:
                last_parent_off = (
                    pos
                    + bone_table_start
                    + (bone_count - 1) * BONE_STRIDE
                    + BONE_PARENT
                )
                last_parent = struct.unpack_from(
                    f'{endian}i', data, last_parent_off
                )[0]
                if not (
                    last_parent == -1 or 0 <= last_parent < bone_count
                ):
                    continue

        return True

    return False


def map_bpe_blocks(data: bytes) -> List[dict]:
    """Walk PAC payload from offset 0x48 and return one descriptor
    per BPE block found, with the fields:
        { 'header_offset', 'data_offset', 'encoded_size',
          'decoded_size', 'dict_flag' }
    Returns an empty list if no BPE blocks present. Walks until the
    next position isn't a BPE marker (handles trailing padding).
    """
    blocks: List[dict] = []
    pos = 0x48  # observed start of first BPE block in v8 PAC
    if pos >= len(data):
        return blocks

    while pos + 16 <= len(data) and data[pos:pos + 4] == BPE_MAGIC:
        dict_flag    = struct.unpack_from('<I', data, pos + 4)[0]
        encoded_size = struct.unpack_from('<I', data, pos + 8)[0]
        decoded_size = struct.unpack_from('<I', data, pos + 12)[0]
        if encoded_size == 0 or pos + 16 + encoded_size > len(data):
            break
        blocks.append({
            'header_offset': pos,
            'data_offset':   pos + 16,
            'encoded_size':  encoded_size,
            'decoded_size':  decoded_size,
            'dict_flag':     dict_flag,
        })
        # Advance past the block, aligned to 4 bytes
        pos = (pos + 16 + encoded_size + 3) & ~3
        if len(blocks) > 256:  # safety cap
            break

    return blocks


def yuke_bpe_decompress(src: bytes, target_size: int,
                        fill_to_target: bool = True) -> bytes:
    """Yukes BPE decompressor — ported byte-for-byte from asmodean's
    unrrbpe.exe (algorithm published by Luigi Auriemma). Takes the
    BPE block's encoded payload (i.e.,
    the bytes AFTER the 16-byte 'BPE ' wrapper header) and returns
    the decoded bytes.

    Stream format:
        Multiple sub-blocks until input exhausted. Each sub-block:
          1. Pair table — for each code 0..255:
               count = next byte
               if count > 127:
                   skip (count - 127) entries (left[i] = i, literal)
               then ALSO read 1 pair (the skip and pair are fused
               into one count byte — this was the key insight that
               classic Gage BPE doesn't share)
               if count <= 127, no skip; read (count + 1) pairs
               Each pair: read 'left' byte. If i != left, also read
               'right' byte. Otherwise the entry is a literal.
          2. Block size — 2 bytes LITTLE-ENDIAN (NOT big-endian like
             classic Gage); count of input bytes to consume.
          3. Decode `size` input bytes; each byte is recursively
             expanded through the pair table via an internal stack.

    Args:
        src: BPE-encoded data (no wrapper header).
        target_size: Expected uncompressed size from the wrapper.
        fill_to_target: If decoder finishes early (early EOF), zero-
            pad output to target_size. Asmodean's note: 'this is
            what is wanted by the format' — the wrapper expects the
            exact decoded_size, and Yukes' encoder sometimes emits
            less than that (the trailing zero region is implicit).
    """
    pos = 0
    n = len(src)
    output = bytearray()
    # 512 bytes for the pair table (256 codes × 2 bytes for left/right)
    # 4096 bytes for the expansion stack used during recursive decode
    stack = bytearray(512 + 4096)
    count = 0  # count of bytes currently on the expansion stack

    while pos < n:
        # --- Build pair table ---
        i = 0
        eof = False
        while i < 256:
            if pos >= n:
                eof = True
                break
            c = src[pos]
            pos += 1

            if c > 127:
                # Skip range — these codes remain literals
                c -= 127
                while c > 0 and i < 256:
                    stack[i * 2] = i  # literal: left[i] = i
                    c -= 1
                    i += 1

            # ALSO read (c+1) pair entries after the skip (the post-
            # skip pair count is what makes Yukes' format diverge
            # from classic Gage — Gage has skip XOR pair, Yukes has
            # skip AND pair in one count byte).
            c += 1
            while c > 0 and i < 256:
                if pos >= n:
                    eof = True
                    break
                stack[i * 2] = src[pos]
                pos += 1
                if i != stack[i * 2]:
                    if pos >= n:
                        eof = True
                        break
                    stack[i * 2 + 1] = src[pos]
                    pos += 1
                c -= 1
                i += 1

            if eof:
                break

        if eof:
            break

        # --- Read 2-byte LITTLE-ENDIAN block size ---
        if pos + 2 > n:
            break
        size = src[pos] | (src[pos + 1] << 8)
        pos += 2

        # --- Decode `size` input bytes with recursive expansion ---
        while size > 0 or count > 0:
            if count > 0:
                count -= 1
                code = stack[count + 512]
            else:
                if pos >= n:
                    break
                code = src[pos]
                pos += 1
                size -= 1

            c = stack[code * 2]
            if code == c:
                # Literal — emit
                output.append(code)
            else:
                # Pair — push (right, left) onto expansion stack
                if count + 512 + 2 > len(stack):
                    # Stack overflow — abort this sub-block defensively
                    break
                stack[count + 512] = stack[code * 2 + 1]
                stack[count + 512 + 1] = c
                count += 2

    if fill_to_target and len(output) < target_size:
        output.extend(b'\x00' * (target_size - len(output)))
    return bytes(output)


def decode_bpe_payload(data: bytes) -> bytes:
    """Decode all 'BPE ' blocks in a v8-style PAC and return the
    concatenated decompressed payload. Returns empty bytes if no
    blocks are present.
    """
    blocks = map_bpe_blocks(data)
    if not blocks:
        return b''
    out = bytearray()
    for b in blocks:
        encoded = data[b['data_offset']:b['data_offset'] + b['encoded_size']]
        out.extend(yuke_bpe_decompress(encoded, b['decoded_size'],
                                       fill_to_target=True))
    return bytes(out)


def map_oodl_blocks(data: bytes) -> List[dict]:
    """Scan a buffer for all 'OODL'+(KRKN|MRMD|SLKI|LEVI) Oodle-
    compressed sub-files and return one descriptor per block:
        { 'header_offset', 'data_offset',
          'uncompressed_size', 'compressed_size', 'algorithm' }

    Format per block (24-byte header, then payload):
        +0x00  'OODL'                magic
        +0x04  u32                   zero
        +0x08  u32                   0x2E060030 constant
        +0x0C  4-byte algorithm tag  one of:
                  'KRKN' = Kraken    (Oodle algo id 8)
                  'MRMD' = Mermaid   (id 9)
                  'SLKI' = Selkie    (id 11, internally LZBLO)
                  'LEVI' = Leviathan (id 13)
        +0x10  u32 LE                uncompressed_size
        +0x14  u32 LE                compressed_size
        +0x18  ...                   compressed payload

    OodleLZ_Decompress autodetects the algorithm from the compressed
    stream itself, so we don't need separate code paths per algorithm —
    we just need to recognize the wrapper format on all four tags.
    """
    KNOWN_ALGOS = (b'KRKN', b'MRMD', b'SLKI', b'LEVI')
    blocks: List[dict] = []
    pos = 0
    n = len(data)
    while pos < n - 0x18:
        found = data.find(OODL_MAGIC, pos)
        if found < 0:
            break
        if found + 0x18 > n:
            break
        algo = data[found + 0x0C:found + 0x10]
        if algo not in KNOWN_ALGOS:
            pos = found + 4
            continue
        uncomp = struct.unpack_from('<I', data, found + 0x10)[0]
        comp   = struct.unpack_from('<I', data, found + 0x14)[0]
        if comp == 0 or found + 0x18 + comp > n or comp > 100_000_000:
            pos = found + 4
            continue
        blocks.append({
            'header_offset':     found,
            'data_offset':       found + 0x18,
            'uncompressed_size': uncomp,
            'compressed_size':   comp,
            'algorithm':         algo.decode('ascii'),
        })
        pos = found + 0x18 + comp
        if len(blocks) > 4096:
            break
    return blocks


def map_zlib_blocks(data: bytes) -> List[dict]:
    """Scan for 'ZLIB' sub-files (also part of the SHDC dispatch
    surface — see the game's SHDC decompression dispatcher).

    Format per block (16-byte header, then payload):
        +0x00  'ZLIB'    magic
        +0x04  u32 LE    flag (observed: 0x1230 across all real samples)
        +0x08  u32 LE    compressed_size
        +0x0C  u32 LE    uncompressed_size
        +0x10  ...       deflate stream (zlib header: 0x78 followed by
                         flag byte 0x01/0x5E/0x9C/0xDA)

    False-positive filter: the +0x10 byte must be 0x78 and the +0x11
    byte must be one of the valid zlib flag values. Random byte
    patterns spelling 'ZLIB' inside other decompressed data fail this
    check.
    """
    blocks: List[dict] = []
    pos = 0
    n = len(data)
    ZLIB_TAG = b'ZLIB'
    while pos < n - 0x12:
        found = data.find(ZLIB_TAG, pos)
        if found < 0:
            break
        if found + 0x12 > n:
            break
        # Validate zlib stream signature at +0x10
        if data[found + 0x10] != 0x78 or data[found + 0x11] not in _ZLIB_FLAGS:
            pos = found + 4
            continue
        comp   = struct.unpack_from('<I', data, found + 0x08)[0]
        uncomp = struct.unpack_from('<I', data, found + 0x0C)[0]
        if comp == 0 or uncomp == 0 or found + 0x10 + comp > n:
            pos = found + 4
            continue
        if comp > 100_000_000 or uncomp > 100_000_000:
            pos = found + 4
            continue
        blocks.append({
            'header_offset':     found,
            'data_offset':       found + 0x10,
            'uncompressed_size': uncomp,
            'compressed_size':   comp,
        })
        pos = found + 0x10 + comp
        if len(blocks) > 4096:
            break
    return blocks


def _load_oodle():
    """Resolve and import the sibling `oodle` module under all three
    import contexts the addon runs in:

      1. Package-relative — when the addon is loaded normally by Blender
         and `Yukes/` is a package.
      2. Top-level — when this file is imported by a script that put
         `Yukes/` on `sys.path` directly.
      3. Filesystem fallback — when neither import works (e.g. tooling
         that loads this file out-of-tree), load `oodle.py` from the
         same directory via `importlib.util`.

    Returns the loaded module. Raises ImportError only if the file
    physically isn't next to this one.
    """
    try:
        from . import oodle as _oodle
        return _oodle
    except ImportError:
        pass
    try:
        import oodle as _oodle  # type: ignore
        return _oodle
    except ImportError:
        pass
    import importlib.util
    import os
    spec = importlib.util.spec_from_file_location(
        'oodle',
        os.path.join(os.path.dirname(__file__), 'oodle.py'),
    )
    _oodle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(_oodle)
    return _oodle


def _decompress_hspc_subfiles(data: bytes) -> List[bytes]:
    """Walk every recognised compressed sub-file in an SHDC payload
    (OODL/Kraken/Mermaid/Selkie/Leviathan + ZLIB) and return each one
    as an independent decompressed buffer. Each buffer is one sub-file
    in the game's dispatch sense; YOBJ/JBOY models live inside these
    buffers, not in a single concatenated stream."""
    sub_files: List[bytes] = []

    # OODL blocks via Oodle DLL
    oodl_blocks = map_oodl_blocks(data)
    if oodl_blocks:
        oodle = _load_oodle()

        for b in oodl_blocks:
            comp_payload = data[b['data_offset']:b['data_offset'] + b['compressed_size']]
            try:
                sub_files.append(
                    oodle.decompress_kraken(comp_payload, b['uncompressed_size'])
                )
            except RuntimeError:
                # Oodle DLL unavailable -> NO OODL block can decode. Do not
                # abort the whole walk: break out and still run the ZLIB loop
                # below so DLL-free sub-files are recovered. The importer
                # surfaces the missing-DLL reason separately via
                # oodle.get_oodle_status(), so we don't need to re-raise.
                break
            except ValueError:
                # A single corrupt/unexpected OODL block -> skip it, keep going.
                continue

    # ZLIB blocks via Python's zlib (no external dependency)
    zlib_blocks = map_zlib_blocks(data)
    if zlib_blocks:
        import zlib as _zlib
        for b in zlib_blocks:
            comp_payload = data[b['data_offset']:b['data_offset'] + b['compressed_size']]
            try:
                sub_files.append(_zlib.decompress(comp_payload))
            except _zlib.error:
                continue

    return sub_files


def decode_hspc_payload(data: bytes) -> bytes:
    """Legacy entry point — returns the concatenation of all
    decompressed sub-files. Kept for diagnostic callers that want a
    rough byte-count view of the container. The actual YOBJ/JBOY
    extractor uses _decompress_hspc_subfiles directly for per-sub-file
    scanning, which is the architecture the game itself uses."""
    return b''.join(_decompress_hspc_subfiles(data))


def diagnose_hspc(data: bytes, log = print) -> None:
    """Verbose diagnostic for HSPC containers — prints what's actually
    inside after decompression so we can debug "no models found" or
    wrong-blob-content cases without needing the user to manually
    inspect the temp directory. Output is intended to be pasted from
    Blender's console.

    For each compressed sub-file (OODL/Kraken or ZLIB), reports:
        - block offset, algorithm, comp/uncomp sizes
        - whether decompression succeeded
        - first 32 bytes of the decompressed payload (hex + ASCII)
        - every YOBJ/JBOY magic match inside, with header-field
          dump and whether `_looks_like_real_yobj_header` accepts it
    """
    log("=== HSPC diagnostic ===")
    log(f"  container size: {len(data):,} bytes")
    if not is_hspc_file(data):
        log("  NOT an HSPC container (magic mismatch).")
        return

    oodl_blocks = map_oodl_blocks(data)
    zlib_blocks = map_zlib_blocks(data)
    log(f"  OODL blocks: {len(oodl_blocks)}")
    log(f"  ZLIB blocks: {len(zlib_blocks)}")

    # Walk OODL blocks via Oodle DLL if available
    oodle = _load_oodle()

    oodle_status = oodle.get_oodle_status()
    log(f"  Oodle: dll_loaded={oodle_status['dll_loaded']}, path={oodle_status['dll_path']}")

    def _report_subfile(label: str, sub: bytes) -> None:
        head_hex = sub[:32].hex()
        head_ascii = ''.join(
            chr(b) if 0x20 <= b < 0x7F else '.'
            for b in sub[:32]
        )
        log(f"  --- {label}: {len(sub):,} bytes ---")
        log(f"      first 32 hex:   {head_hex}")
        log(f"      first 32 ascii: {head_ascii!r}")

        # If this sub-file is a Yukes named-entry wrapper, walk it and
        # report each entry by name. This is how character PACs pack
        # their multiple YOBJ models — one per slot.
        inner = _walk_inner_yukes_meshes(sub)
        if inner:
            log(f"      inner Yukes wrapper: {len(inner)} entries")
            for m in inner[:32]:
                head4 = sub[m['data_offset']:m['data_offset']+4]
                is_yobj = head4 in (YOBJ_MAGIC, JBOY_MAGIC)
                tag = 'YOBJ' if is_yobj else f"first4={head4.hex()}"
                log(f"        '{m['name']}'  @0x{m['data_offset']:X}  "
                    f"size={m['size']:,}  {tag}")
            if len(inner) > 32:
                log(f"        ... and {len(inner)-32} more")
            return

        # Look for YOBJ/JBOY magic anywhere
        positions = []
        p = 0
        while True:
            py = sub.find(YOBJ_MAGIC, p)
            pj = sub.find(JBOY_MAGIC, p)
            cands = [x for x in (py, pj) if x >= 0]
            if not cands: break
            m = min(cands)
            positions.append(m)
            p = m + 4
            if len(positions) > 16: break
        if not positions:
            log(f"      no YOBJ/JBOY magic found and no inner wrapper")
            return
        log(f"      {len(positions)} magic match(es); validation status per match:")
        for pos in positions[:8]:
            ok = _looks_like_real_yobj_header(sub, pos)
            magic = sub[pos:pos+4].decode('ascii', errors='replace')
            endian = '>' if sub[pos:pos+4] == JBOY_MAGIC else '<'
            try:
                mc = struct.unpack_from(f'{endian}I', sub, pos+0x18)[0]
                mo = struct.unpack_from(f'{endian}I', sub, pos+0x1C)[0]
                bc = struct.unpack_from(f'{endian}I', sub, pos+0x20)[0]
                so = struct.unpack_from(f'{endian}I', sub, pos+0x28)[0]
                size = _read_self_size(sub, pos)
                log(f"        @0x{pos:X}  {magic}  size={size}  meshes={mc}  bones={bc}  "
                    f"mesh_off=0x{mo:X}  skel_off=0x{so:X}  → {'ACCEPT' if ok else 'reject'}")
            except struct.error:
                log(f"        @0x{pos:X}  {magic}  (header read failed)  → reject")

    for i, b in enumerate(oodl_blocks):
        if not oodle_status['dll_loaded']:
            log(f"  OODL[{i}] @0x{b['header_offset']:X} algo={b['algorithm']} "
                f"comp={b['compressed_size']:,} uncomp={b['uncompressed_size']:,}  "
                f"(can't decompress — no DLL)")
            continue
        comp_payload = data[b['data_offset']:b['data_offset'] + b['compressed_size']]
        try:
            sub = oodle.decompress_kraken(comp_payload, b['uncompressed_size'])
        except (RuntimeError, ValueError) as e:
            log(f"  OODL[{i}] @0x{b['header_offset']:X} algo={b['algorithm']}: "
                f"decompress FAILED: {e}")
            continue
        _report_subfile(
            f"OODL[{i}] @0x{b['header_offset']:X} algo={b['algorithm']}",
            sub,
        )

    import zlib as _zlib
    for i, b in enumerate(zlib_blocks):
        comp_payload = data[b['data_offset']:b['data_offset'] + b['compressed_size']]
        try:
            sub = _zlib.decompress(comp_payload)
        except _zlib.error as e:
            log(f"  ZLIB[{i}] @0x{b['header_offset']:X}: decompress FAILED: {e}")
            continue
        _report_subfile(f"ZLIB[{i}] @0x{b['header_offset']:X}", sub)

    log("=== end HSPC diagnostic ===")


def extract_yobj_blobs(data: bytes) -> List[bytes]:
    """Scan a PAC/HSPC (or any container) for embedded YOBJ/JBOY blobs
    and return them as a list of byte buffers in container order.

    HSPC path: decompress each SHDC sub-file independently (OODL via
    Oodle DLL, ZLIB via Python's zlib), then scan each decompressed
    buffer for YOBJ/JBOY models. This mirrors how the game's SHDC
    dispatcher treats each sub-file as a separate
    decompression unit — concatenating everything first creates false
    sub-file boundaries that don't exist in the real format.

    PAC v8 path: decompress all 'BPE ' blocks via the Yukes BPE
    decoder, scan the concatenated payload.

    Other paths: try transparent zlib decompression, scan raw.

    Spurious magic-byte matches inside compressed binary data are
    filtered by `_looks_like_real_yobj_header` — random bytes that
    happen to spell YOBJ or JBOY don't survive header validation.
    """
    # EPK8 (2K17-19 char PACs) is a thin 0x1C-byte header + zero-pad to a
    # 16 KB boundary wrapping an inner container — either SHDC (identical to
    # HSPC's) or PACH (alternate; ZLIB/OODL sub-files). Both decode through
    # the same Oodle/ZLIB sub-file path below, since map_oodl_blocks/
    # map_zlib_blocks locate the compressed blocks by magic regardless of the
    # outer wrapper. Strip to the inner container (16 KB-aligned payload).
    if is_epk8_file(data):
        inner = data.find(SHDC_MAGIC)
        if inner < 0:
            inner = data.find(PACH_MAGIC)
        if inner < 0 and len(data) > 0x4000:
            inner = 0x4000
        if inner >= 0:
            data = data[inner:]

    if is_hspc_file(data) or (len(data) >= 4 and data[:4] in (SHDC_MAGIC, PACH_MAGIC)):
        try:
            sub_files = _decompress_hspc_subfiles(data)
        except (RuntimeError, ValueError):
            # Oodle unavailable or failed — caller surfaces the error
            # via the importer diagnostic.
            return []

        blobs: List[bytes] = []
        for sub in sub_files:
            # Most common 2K17+ case: the decompressed OODL block IS
            # a single complete YOBJ/JBOY file, magic at offset 0.
            # When that's true the buffer is one self-contained model
            # (one armature, N meshes inside the YOBJ) and we MUST NOT
            # scan further — coincidental YOBJ/JBOY byte patterns
            # inside the geometry/texture/morph regions would otherwise
            # be turned into bogus extra "yobj" blobs whose synthetic
            # armatures inherit junk bones from arbitrary offsets.
            # This was the root cause of the Skeleton/Skeleton.001-005
            # duplication and the cross-mesh vertex-group bleeding.
            if len(sub) >= 8 and sub[:4] in (YOBJ_MAGIC, JBOY_MAGIC):
                blobs.append(bytes(sub))
                continue

            # Some HSPC sub-files (belt, arena floor, h_other...) use a
            # named-entry wrapper format instead of a direct YOBJ. Walk
            # the wrapper's entry table and pull each YOBJ-magic entry
            # in isolation, bounded to its own byte range so a slice
            # can't extend past the entry it started in.
            inner_meshes = _walk_inner_yukes_meshes(sub)
            wrapper_blobs: List[bytes] = []
            if inner_meshes:
                for m in inner_meshes:
                    if m['size'] < 8:
                        continue
                    entry_data = sub[m['data_offset']:
                                     m['data_offset'] + m['size']]
                    if entry_data[:4] in (YOBJ_MAGIC, JBOY_MAGIC):
                        wrapper_blobs.append(bytes(entry_data))
                    else:
                        # Search inside this one entry only.
                        wrapper_blobs.extend(_scan_for_yobj(entry_data))

            if wrapper_blobs:
                blobs.extend(wrapper_blobs)
                continue

            # Fall-through: no magic at offset 0 and no wrapper hit.
            # Validated magic-scan over the whole sub-file as last
            # resort for any older HSPC layouts.
            blobs.extend(_scan_for_yobj(sub))
        return blobs

    # 2K15-19 CAS parts container — structural parse by mesh name.
    # This is much more reliable than scanning for magic bytes because
    # it picks the model mesh by its named slot rather than by where
    # a 'YOBJ'/'JBOY' byte pattern happens to appear.
    cas_meshes = _walk_inner_yukes_meshes(data)
    if cas_meshes:
        blobs = []
        for m in cas_meshes:
            buf = data[m['data_offset']:m['data_offset'] + m['size']]
            if len(buf) >= 4 and buf[:4] in (YOBJ_MAGIC, JBOY_MAGIC):
                # Pure structural pick — mesh data IS the YOBJ blob,
                # no offset hunting needed.
                blobs.append(bytes(buf))
        if blobs:
            return blobs
        # No YOBJ-named mesh found — fall through to magic scan over
        # the concatenated mesh data area just in case the structure
        # was identified but the model is stored differently.

    if is_pac_file(data) and detect_pac_version(data) == 8 and _contains_bpe_blocks(data):
        decoded = decode_bpe_payload(data)
        if decoded:
            data = decoded
    else:
        data = _maybe_decompress(data)

    return _scan_for_yobj(data)


def _scan_for_yobj(data: bytes) -> List[bytes]:
    """Scan a flat buffer left-to-right for YOBJ/JBOY blobs with
    header validation. Used both inside HSPC sub-files and for raw
    PAC payloads.

    Tracks separate cursors for YOBJ and JBOY so that rejecting a
    false-positive match doesn't require re-scanning the entire buffer
    for both magics every iteration — only the magic we just consumed
    is re-searched. Matters on large HSPC sub-files where decompressed
    payload contains hundreds of coincidental magic byte patterns
    inside textures/vertex data.
    """
    blobs: List[bytes] = []
    pos = 0
    n = len(data)

    # Initial scan: find the first occurrence of each magic.
    next_yobj_pos = data.find(YOBJ_MAGIC, pos)
    next_jboy_pos = data.find(JBOY_MAGIC, pos)

    while pos < n - 4:
        # Advance any stale cursor that's behind the current scan pos.
        if 0 <= next_yobj_pos < pos:
            next_yobj_pos = data.find(YOBJ_MAGIC, pos)
        if 0 <= next_jboy_pos < pos:
            next_jboy_pos = data.find(JBOY_MAGIC, pos)

        # Pick the earlier of the two (matching old min(candidates) logic).
        candidates = [p for p in (next_yobj_pos, next_jboy_pos) if p >= 0]
        if not candidates:
            break
        m = min(candidates)

        # Identify which magic this match belongs to so we know which
        # cursor to refresh after consuming it.
        is_yobj_match = (m == next_yobj_pos)

        # Reject false positives — random bytes inside decompressed
        # payload (textures, vertex data, etc.) that happen to spell
        # YOBJ or JBOY. Without this, we'd slice from a mid-stream
        # match and hand the parser a truncated/garbage blob.
        if not _looks_like_real_yobj_header(data, m):
            pos = m + 4
            # Only the magic we just rejected needs re-searching; the
            # other cursor is still valid as long as it's >= pos.
            if is_yobj_match:
                next_yobj_pos = data.find(YOBJ_MAGIC, pos)
            else:
                next_jboy_pos = data.find(JBOY_MAGIC, pos)
            continue

        size = _read_self_size(data, m)
        if size == 0:
            pos = m + 4
            if is_yobj_match:
                next_yobj_pos = data.find(YOBJ_MAGIC, pos)
            else:
                next_jboy_pos = data.find(JBOY_MAGIC, pos)
            continue

        blobs.append(bytes(data[m:m + size]))
        pos = m + size
        # Accepted blob — re-search the magic we consumed; the other
        # cursor stays valid (its match might now be inside the accepted
        # blob's range, but the `< pos` check at the top of the loop will
        # refresh it lazily on the next iteration).
        if is_yobj_match:
            next_yobj_pos = data.find(YOBJ_MAGIC, pos)
        else:
            next_jboy_pos = data.find(JBOY_MAGIC, pos)

    return blobs


def extract_yobj_blobs_from_path(filepath: str) -> List[bytes]:
    """Convenience wrapper — reads the file and dispatches to
    extract_yobj_blobs. Returns a list of byte buffers, one per
    embedded YOBJ/JBOY model."""
    with open(filepath, 'rb') as f:
        return extract_yobj_blobs(f.read())
