"""
YOBJ Exporter — writes WWE 2K15-2K19 (.yobj/.jboy) and SVR-era (.jboy) models.

Two layout variants are supported, identified by the `version` field at byte
+0x10 of the file header:

* v3 (2K15-19): 184-byte mesh stride, 8-byte shader name slot at +0x7C, full
  morph-name table and global bone-palette table.
* v0 (SVR 07 - WWE 13 BE/JBOY): 180-byte mesh stride, 16-byte shader name slot
  at +0x78, multi-section face strips, no morph or palette tables in header.

Two entry points:
* `write_yobj_from_model(filepath, model)` — round-trip path: takes a parsed
  YOBJModel and rewrites it. No Blender required.
* `export_yobj(filepath, objects, armature)` — Blender-driven path: collects
  data from the scene, builds an in-memory model, then calls the round-trip
  writer. Reads format hints (magic, version) from custom properties on the
  armature so import → tweak → re-export preserves format.
"""

from __future__ import annotations
import struct
import numpy as np
from typing import List, Optional, Tuple

from .format_consts import (
    START_OFFSET,
    MAGIC_JBOY, MAGIC_YOBJ, WEIGHT_PADDING_INDEX,
    VERTEX_STRIDE, WEIGHT_STRIDE, UV_STRIDE, UV_HAIR_STRIDE,
    BONE_STRIDE, MATERIAL_STRIDE, TEX_HEADER_SIZE, TEX_NAME_STRIDE,
    MORPH_HEADER_SIZE, MORPH_NAME_STRIDE,
    HDR_MESH_COUNT, HDR_MESH_TABLE_OFF, HDR_BONE_COUNT, HDR_SKEL_OFF,
    HDR_TEX_OFF, HDR_MTL_OFF, HDR_MTL_COUNT, HDR_MORPH_NAME_OFF,
    HDR_BONE_PALETTE_OFF, HDR_VERSION,
    MESH_STRIDE, MESH_STRIDE_LEGACY,
    MESH_VERTEX_COUNT, MESH_FACE_SEC, MESH_USED_BONE_COUNT,
    MESH_INLINE_PALETTE, MESH_INLINE_PALETTE_SLOTS,
    MESH_WEIGHT_COUNT, MESH_MATERIAL_ID, MESH_MORPH_COUNT,
    MESH_VERTEX_OFFSET, MESH_WEIGHT_OFFSET, MESH_UV_OFFSET, MESH_NORMAL_OFFSET,
    MESH_SHADER_TYPE, MESH_SHADER_TYPE_LEN,
    MESH_SHADER_TYPE_LEGACY, MESH_SHADER_TYPE_LEN_LEGACY,
    MESH_FACE_COUNT, MESH_SHADER_PARAM_COUNT, MESH_SHADER_PARAM_OFF,
    MESH_FACE_OFFSET, MESH_VERTEX_COUNT2, MESH_BBOX_PIVOT,
    MESH_FACE_COUNT_LEGACY, MESH_FACE_OFFSET_LEGACY, MESH_BBOX_PIVOT_LEGACY,
    BONE_NAME, BONE_NAME_LEN, BONE_POS, BONE_EULER, BONE_PARENT, BONE_TAIL,
    MATERIAL_NAME, MATERIAL_NAME_LEN, MATERIAL_EXTRAS,
    FACE_INDEX_COUNT_OFFSET, FACE_DATA_OFFSET,
    VERSION_LEGACY,
)
from .structures import YOBJModel, Mesh, Bone, Material, MorphTarget
from .stripifier import stripify


# ── Layout dispatch ──────────────────────────────────────────────────────────

def _layout_for(version: int) -> dict:
    """Return field-offset dict for the given version's mesh header layout."""
    if version == VERSION_LEGACY:
        return {
            'stride':              MESH_STRIDE_LEGACY,
            'shader_off':          MESH_SHADER_TYPE_LEGACY,
            'shader_len':          MESH_SHADER_TYPE_LEN_LEGACY,
            'face_count_off':      MESH_FACE_COUNT_LEGACY,
            'face_offset_off':     MESH_FACE_OFFSET_LEGACY,
            'bbox_off':            MESH_BBOX_PIVOT_LEGACY,
            # In the legacy layout shader_param_count, shader_param_off and
            # vc2 sit relative to face_offset (-8, -4, +4). We don't expose
            # them as constants because they're only consumed here.
            'shader_param_count_off': MESH_FACE_OFFSET_LEGACY - 8,
            'shader_param_off_off':   MESH_FACE_OFFSET_LEGACY - 4,
            'vc2_off':                MESH_FACE_OFFSET_LEGACY + 4,
            'header_size':         0x48,
            'has_morph_table':     False,
            'has_palette_table':   False,
        }
    return {
        'stride':              MESH_STRIDE,
        'shader_off':          MESH_SHADER_TYPE,
        'shader_len':          MESH_SHADER_TYPE_LEN,
        'face_count_off':      MESH_FACE_COUNT,
        'face_offset_off':     MESH_FACE_OFFSET,
        'bbox_off':            MESH_BBOX_PIVOT,
        'shader_param_count_off': MESH_SHADER_PARAM_COUNT,
        'shader_param_off_off':   MESH_SHADER_PARAM_OFF,
        'vc2_off':                MESH_VERTEX_COUNT2,
        'header_size':         0x58,
        'has_morph_table':     True,
        'has_palette_table':   True,
    }


# ── Binary writer ────────────────────────────────────────────────────────────

class _Writer:
    """Endian-aware byte buffer with tracked position and back-patching."""

    def __init__(self, big_endian: bool = True):
        self.buf = bytearray()
        self.be = big_endian
        self.fmt = '>' if big_endian else '<'

    def pos(self) -> int:
        return len(self.buf)

    def raw(self, p: int) -> int:
        """File pos → raw offset value (= file pos − START_OFFSET)."""
        return p - START_OFFSET

    def reserve(self, n: int):
        self.buf.extend(b'\x00' * n)

    def w_bytes(self, b: bytes):
        self.buf.extend(b)

    def w_u32(self, v: int):
        self.buf.extend(struct.pack(self.fmt + 'I', v & 0xFFFFFFFF))

    def w_u32_le(self, v: int):
        self.buf.extend(struct.pack('<I', v & 0xFFFFFFFF))

    def w_i32(self, v: int):
        self.buf.extend(struct.pack(self.fmt + 'i', v))

    def w_u16(self, v: int):
        self.buf.extend(struct.pack(self.fmt + 'H', v & 0xFFFF))

    def w_f32(self, v: float):
        self.buf.extend(struct.pack(self.fmt + 'f', float(v)))

    def w_string(self, s: str, length: int):
        """Fixed-length null-padded ASCII string."""
        encoded = (s or '').encode('ascii', errors='replace')[:length]
        self.buf.extend(encoded)
        self.buf.extend(b'\x00' * (length - len(encoded)))

    def patch_u32(self, file_pos: int, v: int):
        self.buf[file_pos:file_pos + 4] = struct.pack(self.fmt + 'I', v & 0xFFFFFFFF)

    def align(self, alignment: int):
        rem = len(self.buf) % alignment
        if rem:
            self.buf.extend(b'\x00' * (alignment - rem))


# ── Block writers ────────────────────────────────────────────────────────────


def _write_shader_param_block(w: _Writer, mesh: Mesh) -> int:
    """Write the per-mesh shader-parameter block. Returns raw sp-offset.

    Unlike vertex/weight/uv/face blocks, the shader_param block in the
    source files does NOT have a leading 8-byte zero pad — its `raw_offset`
    points 8 bytes BEFORE its data, and those 8 bytes are owned by the
    block that precedes it (typically the mesh table for the first mesh,
    or whichever block was last written for subsequent meshes). The bytes
    can be anything; the engine just adds START_OFFSET to dereference.

    So we write the data directly at the current position and store
    raw_value = current_pos − START_OFFSET. The captured bytes contain
    the entire shader-param record stream verbatim, including any
    POF0-encoded sub-data the engine derefs at shader setup.
    """
    data_start = w.pos()
    raw_value = data_start - START_OFFSET
    if mesh.raw_shader_param_bytes:
        w.w_bytes(mesh.raw_shader_param_bytes)
    return raw_value

def _write_vertex_block(w: _Writer, mesh: Mesh) -> int:
    """
    Write the vertex block for one mesh and return the raw vertex-offset to
    record in the mesh header.

    Layout (matches what the parser expects):
        At raw + 0:   8 bytes pad (the START_OFFSET convention).
        At raw + 8:   uint32[morph_count] frame-offsets table (each entry is
                      itself a raw offset; the data sits at frame_off + 8).
        After table:  morph_count × vc × 28 bytes of interleaved vertex data
                      (position 12, normal 12, tail 4).
    """
    morph_count = 1 + len(mesh.morph_targets)
    vc = len(mesh.positions)

    # The file format uses TIGHT packing: each block's content runs from
    # data_pos right up to the next block's data_pos, with raw_off
    # conventionally pointing 8 bytes back (into the previous block's
    # last 8 bytes of content). There's no zero-padded gap between
    # blocks. Earlier this writer reserved 8 bytes here to satisfy a
    # raw + 8 = data_pos invariant by writing zeros — but that bloated
    # every block by 8 bytes vs vanilla, shifting every later position
    # in the file. POF0 (a relocation table) references absolute file
    # offsets, so any shift desyncs the engine's pointer fixups → freeze
    # at draw time.
    block_data_pos = w.pos()
    raw_value = block_data_pos - START_OFFSET

    # Round-trip: splice the entire vertex block verbatim — FOT + frame0 +
    # morph frames + any shader-specific trailing data (hair geometry, v7
    # per-vertex extras) that the frame-by-frame re-encode below cannot
    # reproduce. The internal FOT holds absolute raw offsets that remain valid
    # because the block lands at its original file position in a clean
    # round-trip. Only re-encode when no raw bytes were captured (edited/new).
    raw_vb = getattr(mesh, 'raw_vertex_bytes', b'')
    if raw_vb:
        w.w_bytes(raw_vb)
        return raw_value

    fot_pos = w.pos()
    w.reserve(morph_count * 4)
    w.align(4)

    frames = [(mesh.positions, mesh.normals, mesh.vertex_tail, b'')]
    for mt in mesh.morph_targets:
        frame_normals = mt.normals if mt.normals is not None else mesh.normals
        frames.append((mt.positions, frame_normals, mesh.vertex_tail,
                       getattr(mt, 'raw_frame_bytes', b'')))

    frame_positions: List[int] = []
    endian_f4 = '>f4' if w.be else '<f4'

    for pos, nrm, tail, raw_fb in frames:
        frame_positions.append(w.pos())
        # Round-trip: splice the captured frame bytes verbatim. Morph frames
        # carry a per-vertex tail (and sometimes zero-filled normals) the
        # decoded positions/normals can't reproduce bit-exactly. frame0 passes
        # b'' here so the base mesh always re-encodes (stays editable).
        if raw_fb and len(raw_fb) == vc * VERTEX_STRIDE:
            w.w_bytes(raw_fb)
            continue
        # Build an interleaved 28-byte record buffer, then dump.
        rec = np.zeros((vc, VERTEX_STRIDE), dtype=np.uint8)
        rec[:, 0:12] = np.ascontiguousarray(
            pos.astype(endian_f4)).view(np.uint8).reshape(vc, 12)
        rec[:, 12:24] = np.ascontiguousarray(
            nrm.astype(endian_f4)).view(np.uint8).reshape(vc, 12)
        if tail is not None and len(tail) == vc:
            rec[:, 24:28] = tail.astype(np.uint8)
        else:
            # Engine expects 0xFFFFFFFF as the per-vertex "no color / fully
            # opaque white" sentinel — vanilla files set all 4 trailing
            # bytes to 0xFF when there's no real per-vertex color. Writing
            # zeros instead can render the mesh fully transparent or
            # otherwise invisible at draw time.
            rec[:, 24:28] = 0xFF
        w.w_bytes(rec.tobytes())

    # Backfill frame-offsets table with raw values.
    for i, fp in enumerate(frame_positions):
        w.patch_u32(fot_pos + i * 4, w.raw(fp))

    return raw_value


def _write_weight_block(w: _Writer, mesh: Mesh) -> int:
    """
    Write the weight block. Returns raw weight-offset.

    Layout: 8-byte pad, then `vc × max_influences × 8` bytes of
    `(LE uint32 palette_idx, file-endian f32 weight)` pairs. Padding
    influences use palette_idx = 0xFFFFFFFF and weight = 0.

    When the parsed mesh carries `raw_weight_bytes` (round-trip path), we
    splice them in verbatim. This preserves the exact 0xFFFFFFFF padding
    sentinel and the original float bit-patterns — both of which the
    parser otherwise normalises (sentinel → bone-0, weights re-summed to
    1.0). Writing bone-0 with weight 0 is what the engine reads as "skin
    to root" and crashes on bone-chain walk; the sentinel is the
    "skip this slot" signal.

    For from-scratch authoring (no raw bytes) we synthesize the block
    from `bone_indices`/`bone_weights`. Slots beyond what was parsed get
    the padding sentinel.
    """
    # See `_write_vertex_block` for the rationale on tight packing — same
    # convention applies here. We do NOT reserve(8) leading bytes; the
    # 8-byte raw_off zone overlaps with the previous block's tail, which
    # the previous writer has already produced.
    block_data_pos = w.pos()
    raw_value = block_data_pos - START_OFFSET

    if mesh.raw_weight_bytes:
        w.w_bytes(mesh.raw_weight_bytes)
        return raw_value

    if mesh.bone_weights is None or mesh.bone_indices is None:
        return raw_value

    vc = len(mesh.bone_weights)
    n_inf = mesh.max_influences if mesh.max_influences > 0 else mesh.bone_weights.shape[1]

    # Structured dtype: idx is always little-endian (matches the original
    # w_u32_le call); weight uses file endian (matches w_f32 which uses
    # _Writer.fmt). Per-record stride is 8 bytes — same as the loop's
    # two struct.pack calls. We do NOT renormalize weights — parser.py
    # preserves non-renormalized values for byte-perfect round-trip.
    weight_endian = '>f4' if w.be else '<f4'
    dt = np.dtype([('idx', '<u4'), ('w', weight_endian)])
    rec = np.empty((vc, n_inf), dtype=dt)
    src_w = mesh.bone_indices.shape[1]
    fill_w = min(src_w, n_inf)
    if fill_w > 0:
        rec['idx'][:, :fill_w] = mesh.bone_indices[:, :fill_w].astype(np.uint32, copy=False)
        rec['w'][:, :fill_w] = mesh.bone_weights[:, :fill_w].astype(np.float32, copy=False)
    if fill_w < n_inf:
        rec['idx'][:, fill_w:] = WEIGHT_PADDING_INDEX
        rec['w'][:, fill_w:] = 0.0
    w.w_bytes(rec.tobytes())

    return raw_value


def _write_uv_block(w: _Writer, mesh: Mesh, flip_v: bool = True) -> int:
    """Write UV block. Returns raw UV-offset.

    Hair shaders use 2 UV layers (16 bytes/v); other shaders use 1 (8/v).
    """
    block_data_pos = w.pos()
    raw_value = block_data_pos - START_OFFSET

    # Round-trip path: splice the captured UV bytes verbatim. The `1.0 - v`
    # flip re-encode below rounds some f32 mantissa LSBs differently than the
    # original encoder, so a fresh encode is NOT byte-exact. Only re-encode
    # when no raw bytes were captured (from-scratch / edited mesh).
    raw = getattr(mesh, 'raw_uv_bytes', b'')
    if raw:
        w.w_bytes(raw)
        return raw_value

    is_hair = 'hair' in (mesh.shader_type or '').lower()
    vc = len(mesh.uvs)
    if vc == 0:
        return raw_value

    endian_f4 = '>f4' if w.be else '<f4'

    # Build u/v columns as numpy arrays then a single .tobytes() — semantically
    # identical to the per-element struct.pack loop (same f64 math for the
    # `1.0 - v` flip, same f32 rounding on cast, same big/little endian
    # byte order).
    u_arr = np.asarray(mesh.uvs[:, 0], dtype=np.float64)
    v_arr = np.asarray(mesh.uvs[:, 1], dtype=np.float64)
    if flip_v:
        v_arr = 1.0 - v_arr

    if is_hair:
        # Start with layer-1 values (the per-vertex fallback for missing
        # uvs2 rows), then overlay any rows that uvs2 actually provides.
        u2_arr = u_arr.copy()
        v2_arr = v_arr.copy()
        if mesh.uvs2 is not None and len(mesh.uvs2) > 0:
            n2 = min(len(mesh.uvs2), vc)
            u2_arr[:n2] = np.asarray(mesh.uvs2[:n2, 0], dtype=np.float64)
            v2_src = np.asarray(mesh.uvs2[:n2, 1], dtype=np.float64)
            v2_arr[:n2] = (1.0 - v2_src) if flip_v else v2_src
        rec = np.column_stack([u_arr, v_arr, u2_arr, v2_arr]).astype(endian_f4, copy=False)
    else:
        rec = np.column_stack([u_arr, v_arr]).astype(endian_f4, copy=False)

    w.w_bytes(np.ascontiguousarray(rec).tobytes())

    return raw_value


def _write_normal_block_v3(w: _Writer, mesh: Mesh) -> int:
    """Write standalone normal block (v3 only). Returns raw normal-offset.

    v3 files store normals in two places:
      1. Interleaved in the vertex stream (positions + normals + tail).
      2. As a standalone block of 12 bytes/vertex pointed to by `normal_off`.

    The game reads from the standalone block. Writing 0 here causes a null
    deref when the engine dereferences it. v0/SVR-era files don't have this
    block (normal_off is 0 in source files).
    """
    block_data_pos = w.pos()
    raw_value = block_data_pos - START_OFFSET

    # Round-trip path: splice the captured normal block verbatim. The on-disk
    # block is frequently all zeros (the engine reads interleaved vertex
    # normals, not this block), so re-encoding mesh.normals writes non-zero
    # bytes where the file had zeros. Only re-encode from .normals when no raw
    # bytes were captured (from-scratch authoring — a zero block would null
    # deref, so we must emit something the engine can read).
    raw = getattr(mesh, 'raw_normal_bytes', b'')
    if raw:
        w.w_bytes(raw)
        return raw_value

    vc = len(mesh.normals)
    endian_f4 = '>f4' if w.be else '<f4'
    arr = np.ascontiguousarray(mesh.normals.astype(endian_f4))
    w.w_bytes(arr.tobytes())

    return raw_value


def _patch_face_block_data_offs(w: _Writer, block_data_pos: int,
                                  raw_bytes: bytes, face_sec: int,
                                  orig_block_data_pos: Optional[int] = None) -> None:
    """Patch the internal absolute `data_off_raw` field(s) inside a face
    block we just spliced in verbatim.

    Each section descriptor is 12 bytes laid out as:
        +0 uint32 check (=6)
        +4 uint32 idx_count
        +8 uint32 data_off_raw   ← absolute (file-pos minus 8)
    For face_sec=1 there is one descriptor at the start of the block.
    For face_sec>1 there are `face_sec` descriptors, each 12 bytes,
    followed by the per-section strip data. The shift between the
    original first data_off and the new first data_off applies uniformly
    to all descriptors because their positions inside the block are
    preserved by the verbatim splice.

    `orig_block_data_pos` is the block's data position in the SOURCE file
    (= original face raw_off + START_OFFSET). When provided we compute the
    shift directly from it — robust to any internal padding between the
    descriptors and the strips (some v7 face blocks have a 12-byte gap there,
    which the no-gap heuristic below mis-measures, corrupting data_off).
    """
    if face_sec <= 0 or len(raw_bytes) < 12:
        return
    fmt = w.fmt + 'I'
    if orig_block_data_pos is not None:
        shift = block_data_pos - orig_block_data_pos
    else:
        # Fallback heuristic: assume strips begin immediately after the
        # face_sec descriptors (no gap). Correct for v3/v0, not for v7.
        orig_first_data_off = struct.unpack(fmt, raw_bytes[8:12])[0]
        orig_first_strip_pos = orig_first_data_off + START_OFFSET
        orig_block_data_pos = orig_first_strip_pos - face_sec * 12
        shift = block_data_pos - orig_block_data_pos
    if shift == 0:
        return
    for i in range(face_sec):
        desc_off = i * 12
        if desc_off + 12 > len(raw_bytes):
            break
        field_pos = block_data_pos + desc_off + 8
        orig_value = struct.unpack(fmt, bytes(w.buf[field_pos:field_pos + 4]))[0]
        w.patch_u32(field_pos, (orig_value + shift) & 0xFFFFFFFF)


def _write_face_block_v3(w: _Writer, faces: np.ndarray, mesh: Optional[Mesh] = None,
                          orig_face_raw: int = 0) -> int:
    """v3 single-strip face block. Returns raw face-offset.

    Layout at face_off + START_OFFSET:
        +0  uint32  check_value (=6)
        +4  uint32  index_count
        +8  uint32  data_offset (raw; +START_OFFSET to reach strip)
        ...        strip data (uint16, with 0xFFFF restarts between sub-strips)

    When `mesh.raw_face_bytes` is present (round-trip path) we splice
    those bytes in verbatim and patch the internal data_off so it points
    at the strip's new file location. Re-stripifying instead would
    produce equivalent triangles but a different on-disk size, which
    would shift every later block in the file.
    """
    block_data_pos = w.pos()
    raw_value = block_data_pos - START_OFFSET

    if mesh is not None and mesh.raw_face_bytes:
        w.w_bytes(mesh.raw_face_bytes)
        orig_pos = (orig_face_raw + START_OFFSET) if orig_face_raw else None
        _patch_face_block_data_offs(w, block_data_pos, mesh.raw_face_bytes, 1, orig_pos)
        return raw_value

    strips = stripify(faces)

    if not strips:
        w.w_u32(6); w.w_u32(0); w.w_u32(w.raw(w.pos() + 4))
        return raw_value

    parts = []
    for i, s in enumerate(strips):
        parts.append(s)
        if i < len(strips) - 1:
            parts.append(np.array([0xFFFF], dtype=np.uint16))
    strip = np.concatenate(parts)

    w.w_u32(6)
    w.w_u32(len(strip))
    data_off_pos = w.pos()
    w.w_u32(0)

    strip_start = w.pos()
    w.patch_u32(data_off_pos, w.raw(strip_start))
    arr = strip.astype('>u2' if w.be else '<u2')
    w.w_bytes(arr.tobytes())
    w.align(4)

    return raw_value


def _write_face_block_v0(w: _Writer, faces: np.ndarray, n_sections: int = 1,
                         mesh: Optional[Mesh] = None) -> Tuple[int, int]:
    """v0 face block. Returns (raw_face_offset, n_sections).

    Layout at face_off + START_OFFSET:
        For each section:  uint32 check(=6), uint32 index_count, uint32 data_off_raw
        Then strip data follows; each section's bytes start at its own data_off.

    The on-disk format supports both single-section (one big strip with
    0xFFFF restarts inside it — the common SVR-era case) and multi-section
    (each strip is its own descriptor — used by some SVR07 files for
    material subgroups). We default to single-section because that's what
    the game most reliably accepts; the parser handles either flavour.

    On the round-trip path (mesh.raw_face_bytes present) we splice the
    captured bytes verbatim and patch the internal data_off field(s).
    """
    block_data_pos = w.pos()
    raw_value = block_data_pos - START_OFFSET

    if mesh is not None and mesh.raw_face_bytes:
        w.w_bytes(mesh.raw_face_bytes)
        # Use the section count from the mesh-header field (face_sec).
        face_sec = max(1, n_sections if n_sections > 0 else 1)
        _patch_face_block_data_offs(w, block_data_pos, mesh.raw_face_bytes, face_sec)
        return raw_value, face_sec

    strips = stripify(faces)

    if not strips:
        w.w_u32(6); w.w_u32(0); w.w_u32(w.raw(w.pos() + 4))
        return raw_value, 1

    if n_sections == 1 or len(strips) == 1:
        # Single section: concatenate all strips with 0xFFFF restart markers
        # (same approach as v3). The game reads one continuous strip.
        parts = []
        for i, s in enumerate(strips):
            parts.append(s)
            if i < len(strips) - 1:
                parts.append(np.array([0xFFFF], dtype=np.uint16))
        strip = np.concatenate(parts)

        w.w_u32(6)
        w.w_u32(len(strip))
        data_off_pos = w.pos()
        w.w_u32(0)

        strip_start = w.pos()
        w.patch_u32(data_off_pos, w.raw(strip_start))
        arr = strip.astype('>u2' if w.be else '<u2')
        w.w_bytes(arr.tobytes())
        w.align(4)
        return raw_value, 1

    # Multi-section path (preserved for the rare cases that need it).
    desc_positions: List[int] = []
    for s in strips:
        w.w_u32(6)
        w.w_u32(len(s))
        desc_positions.append(w.pos())
        w.w_u32(0)

    for s, desc_pos in zip(strips, desc_positions):
        sec_start = w.pos()
        w.patch_u32(desc_pos, w.raw(sec_start))
        arr = s.astype('>u2' if w.be else '<u2')
        w.w_bytes(arr.tobytes())
        w.align(4)

    return raw_value, len(strips)


def _write_skeleton(w: _Writer, bones: List[Bone]) -> int:
    """Write skeleton block. Returns raw skel-offset.

    Unlike the per-mesh blocks (which tight-pack with the previous block's
    trailing content), the boundary between the last mesh's face block and
    the skel block has a real 8-byte zero pad: vanilla files have eight
    zero bytes between `mesh[N-1].face_block_end` and `skel_data_pos`,
    so we reserve them explicitly here.
    """
    w.reserve(8)
    block_data_pos = w.pos()
    raw_value = block_data_pos - START_OFFSET

    for b in bones:
        w.w_string(b.name, BONE_NAME_LEN)            # +0  name (16)
        for v in b.position[:3]: w.w_f32(float(v))   # +16 pos (12)
        w.w_u32(0)                                    # +28 pad
        for v in b.rotation[:3]: w.w_f32(float(v))   # +32 euler (12)
        w.w_u32(0)                                    # +44 pad
        w.w_i32(int(b.parent_index))                  # +48 parent
        w.reserve(12)                                 # +52 zeros
        if b.tail is not None and len(b.tail) >= 4:   # +64 tail (16)
            for v in b.tail[:4]: w.w_f32(float(v))
        else:
            w.reserve(16)

    return raw_value


def _write_textures(w: _Writer, model: YOBJModel) -> int:
    """Texture block: 8-byte header + 16-byte name slots. Returns raw tex-offset."""
    block_start = w.pos()
    raw_value = block_start

    th = model.texture_header or (0.0, 0.0)
    w.w_f32(float(th[0]))
    w.w_f32(float(th[1]))

    for name in model.textures:
        w.w_string(name or '', TEX_NAME_STRIDE)

    return raw_value


def _write_materials(w: _Writer, materials: List[Material]) -> int:
    """Material block. Returns raw mtl-offset."""
    block_data_pos = w.pos()
    raw_value = block_data_pos - START_OFFSET

    for m in materials:
        w.w_string(m.name, MATERIAL_NAME_LEN)
        ex = m.extras if m.extras else (0, 0, 0, 0)
        for v in (tuple(ex) + (0, 0, 0, 0))[:4]:
            w.w_u32(int(v))

    return raw_value


def _write_morph_names(w: _Writer, names: List[str]) -> int:
    """Morph-name table (v3 only). Returns raw morph-name-offset.

    8-byte header (parser reads count at +0), then 16-byte names.
    """
    block_start = w.pos()
    raw_value = block_start
    w.w_u32(len(names))
    w.w_u32(0)
    for name in names:
        w.w_string(name or '', MORPH_NAME_STRIDE)
    return raw_value


def _write_bone_palette(w: _Writer, palette: Optional[np.ndarray]) -> int:
    """Global bone palette (v3 only). Returns raw palette-offset.

    At raw + START_OFFSET: uint32 count, uint32 data_off_raw, int32[count].
    """
    block_data_pos = w.pos()
    raw_value = block_data_pos - START_OFFSET

    if palette is None or len(palette) == 0:
        w.w_u32(0)
        w.w_u32(w.raw(w.pos() + 4))
        return raw_value

    w.w_u32(len(palette))
    data_off_pos = w.pos()
    w.w_u32(0)
    data_start = w.pos()
    w.patch_u32(data_off_pos, w.raw(data_start))

    arr = np.asarray(palette, dtype=np.uint32).astype('>u4' if w.be else '<u4')
    w.w_bytes(arr.tobytes())
    return raw_value


# ── Mesh-header writer ───────────────────────────────────────────────────────

def _write_mesh_header(buf: bytearray, layout: dict, mesh: Mesh, info: dict, be: bool):
    """Fill in a single mesh header into the stride-sized `buf`.

    When `mesh.raw_header` is populated, the buffer starts as a verbatim
    copy of the on-disk header bytes and we patch only the fields whose
    values change (offsets, vertex/face counts, inline palette, etc.). All
    other bytes — including game-critical fields we don't decode like
    shader_param_count, face_count_field at +0x8C/+0x90, and the various
    +0x80/+0x84/+0xA0/+0xB0 regions — survive untouched.

    From-scratch authoring (empty raw_header) writes default values for the
    unknown regions while still producing a structurally valid file.
    """
    fmt = '>' if be else '<'
    stride = layout['stride']
    assert len(buf) == stride

    if mesh.raw_header and len(mesh.raw_header) != stride:
        print(
            f"[Yukes] mesh '{mesh.name}': raw_header stride mismatch "
            f"(got {len(mesh.raw_header)}, expected {stride}); "
            f"falling back to from-scratch — may lose engine-critical fields"
        )

    if mesh.raw_header and len(mesh.raw_header) == stride:
        buf[:] = mesh.raw_header

    def put_u32(off, v):
        struct.pack_into(fmt + 'I', buf, off, v & 0xFFFFFFFF)

    def put_f32(off, v):
        struct.pack_into(fmt + 'f', buf, off, float(v))

    def put_str(off, s, length):
        encoded = (s or '').encode('ascii', errors='replace')[:length]
        buf[off:off + length] = encoded + b'\x00' * (length - len(encoded))

    # Round-trip path: buf already holds the verbatim source header. The ONLY
    # fields that can legitimately differ are the per-block OFFSETS (the data
    # was re-laid-out). Patch just those and leave everything else — vertex /
    # face-section / used-bone counts, the inline bone palette, bbox, shader
    # type — exactly as the source had it. Re-deriving those from decoded data
    # is lossy on some versions: v7 stores values in the face_sec, inline-
    # palette and count fields that the from-scratch synthesis below does not
    # reproduce, which corrupted the header at byte level (e.g. face_sec 2->1,
    # inline_palette[0] 2->1). For v3 these re-derivations happened to match,
    # so preserving them instead is a no-op for already-passing models.
    if mesh.raw_header and len(mesh.raw_header) == stride:
        put_u32(MESH_VERTEX_OFFSET, info['vertex_off'])
        put_u32(MESH_WEIGHT_OFFSET, info['weight_off'])
        put_u32(MESH_UV_OFFSET,     info['uv_off'])
        if layout.get('stride') != MESH_STRIDE_LEGACY:
            put_u32(MESH_NORMAL_OFFSET, info.get('normal_off', 0))
        put_u32(layout['face_offset_off'],      info['face_off'])
        put_u32(layout['shader_param_off_off'], info.get('shader_param_off', info['face_off']))
        return

    vc = len(mesh.positions)

    if mesh.inline_palette_full:
        used_bn = sum(1 for x in mesh.inline_palette_full if x != 0xFFFFFFFF)
    elif mesh.bone_palette is not None:
        used_bn = len(mesh.bone_palette)
    else:
        used_bn = 0

    morph_count = 1 + len(mesh.morph_targets)

    # Identity / counts — always patched.
    put_u32(MESH_VERTEX_COUNT,    vc)
    put_u32(MESH_FACE_SEC,        info['face_section_count'])
    put_u32(MESH_USED_BONE_COUNT, used_bn)

    # Inline palette — patch all 20 slots.
    palette = list(mesh.inline_palette_full) if mesh.inline_palette_full else []
    if not palette and mesh.bone_palette is not None:
        palette = [int(x) for x in mesh.bone_palette[:MESH_INLINE_PALETTE_SLOTS]]
    while len(palette) < MESH_INLINE_PALETTE_SLOTS:
        palette.append(0xFFFFFFFF)
    for i, p in enumerate(palette[:MESH_INLINE_PALETTE_SLOTS]):
        put_u32(MESH_INLINE_PALETTE + i * 4, int(p) & 0xFFFFFFFF)

    # Skinning + per-block offsets — always patched (data was re-laid-out).
    put_u32(MESH_WEIGHT_COUNT,    mesh.max_influences if mesh.max_influences > 0 else 1)
    put_u32(MESH_MATERIAL_ID,     mesh.material_index)
    put_u32(MESH_MORPH_COUNT,     morph_count)
    put_u32(MESH_VERTEX_OFFSET,   info['vertex_off'])
    put_u32(MESH_WEIGHT_OFFSET,   info['weight_off'])
    put_u32(MESH_UV_OFFSET,       info['uv_off'])
    # The +0x74 slot is normal_off in the 2K-era v3 layout but means
    # something else (a small per-mesh index, possibly a shader-param sub-id)
    # in the SVR-era v0 layout — its values in vanilla (1, 3, 4, …) don't
    # look like file offsets at all. Patching it to zero scrambles a
    # per-mesh game-side lookup. We only write it for v3, where info
    # carries a real raw offset; for v0 we leave whatever raw_header had.
    if layout.get('stride') != MESH_STRIDE_LEGACY:
        put_u32(MESH_NORMAL_OFFSET, info.get('normal_off', 0))

    # Shader type — always patched (string).
    put_str(layout['shader_off'], mesh.shader_type, layout['shader_len'])

    # Face / param block — patch face_off and vc2. Preserve face_count_field
    # and shader_param_count when raw_header is present (these are values the
    # game consumes that we don't synthesize correctly from scratch).
    # shader_param_off MUST be patched in both paths: the block has been
    # re-laid-out so its raw value changed even when its size didn't.
    put_u32(layout['face_offset_off'], info['face_off'])
    put_u32(layout['vc2_off'],         vc)
    put_u32(layout['shader_param_off_off'], info.get('shader_param_off', info['face_off']))
    if not (mesh.raw_header and len(mesh.raw_header) == stride):
        # From-scratch defaults for the fields we'd otherwise leave untouched.
        put_u32(layout['face_count_off'],         info['face_section_count'])
        put_u32(layout['shader_param_count_off'], 1)

    # Bbox/pivot — always patched.
    bbox = mesh.bbox_pivot or (0.0, 0.0, 0.0, 0.0)
    for i in range(4):
        put_f32(layout['bbox_off'] + i * 4, bbox[i] if i < len(bbox) else 0.0)


# ── Top-level entry point: round-trip from in-memory model ──────────────────

def _finalize_pof0_relocations(w, model, mesh_infos, layout,
                               mesh_table_pos, materials_end_new):
    """Regenerate the POF0 relocation table when a NEW mesh (no captured
    raw_header) shifts the layout: every existing relocation is remapped to its
    new file position and the moved interior pointers are re-based; the new
    mesh's own relocations (its sp pointer-table, face self-pointer, and
    mesh-table pointer columns) are added. NO-OP when every mesh has raw_header
    (the 25/25 byte-exact path is left untouched). Raises on any uncertainty so
    the caller keeps the verbatim POF0 (never worse than today)."""
    from . import pof0
    import struct as _s
    fmt, START = w.fmt, START_OFFSET
    rh = model.raw_header
    if not rh or not model.raw_trailer:
        return
    stride = layout['stride']
    field = {'vtx': MESH_VERTEX_OFFSET, 'weight': MESH_WEIGHT_OFFSET,
             'uv': MESH_UV_OFFSET, 'normal': MESH_NORMAL_OFFSET,
             'face': layout['face_offset_off'], 'sp': layout['shader_param_off_off']}
    raw_attr = {'vtx': 'raw_vertex_bytes', 'weight': 'raw_weight_bytes',
                'uv': 'raw_uv_bytes', 'normal': 'raw_normal_bytes',
                'face': 'raw_face_bytes', 'sp': 'raw_shader_param_bytes'}
    info_key = {'vtx': 'vertex_off', 'weight': 'weight_off', 'uv': 'uv_off',
                'normal': 'normal_off', 'face': 'face_off', 'sp': 'shader_param_off'}

    # Fire ONLY when the layout actually moved: a new mesh (no raw_header), or any
    # per-mesh data block whose new offset differs from its captured source
    # offset (e.g. an edited mesh whose vertex count changed, resizing a block
    # and shifting everything after it). When nothing moved — pure round-trip or
    # value-only edits — keep the verbatim spliced POF0 so the byte-exact path is
    # preserved (encode() need not reproduce a non-minimal source payload).
    moved = False
    for mesh, info in zip(model.meshes, mesh_infos):
        if not getattr(mesh, 'raw_header', b''):
            moved = True
            break
        mh = mesh.raw_header
        for bt, foff in field.items():
            so = _s.unpack(fmt + 'I', mh[foff:foff + 4])[0]
            no = info.get(info_key[bt], 0)
            if so and no and so != no:
                moved = True
                break
        if moved:
            break
    if not moved:
        return

    src_field = _s.unpack(fmt + 'I', rh[0x04:0x08])[0]
    chunk_off_in_tr = src_field - model.raw_trailer_orig_start      # offset of 0x0a within trailer
    if not (0 <= chunk_off_in_tr + 8 <= len(model.raw_trailer) - 4):
        raise ValueError("POF0 chunk not in raw_trailer")
    if model.raw_trailer[chunk_off_in_tr + 8:chunk_off_in_tr + 12] != b'POF0':
        raise ValueError("POF0 magic not at expected offset")
    plen = _s.unpack('>I', model.raw_trailer[chunk_off_in_tr + 12:chunk_off_in_tr + 16])[0]
    payload = model.raw_trailer[chunk_off_in_tr + 16:chunk_off_in_tr + 16 + plen]
    src_slots = pof0.decode(payload)
    new_chunk_start = materials_end_new + chunk_off_in_tr          # == the +0x04 the writer set

    src_mt = _s.unpack(fmt + 'I', rh[HDR_MESH_TABLE_OFF:HDR_MESH_TABLE_OFF + 4])[0] + START

    # (src_start, size, new_start) for every interior-pointer-bearing block.
    blocks = []
    for mesh, info in zip(model.meshes, mesh_infos):
        if not getattr(mesh, 'raw_header', b''):
            continue
        mh = mesh.raw_header
        for bt in ('vtx', 'weight', 'uv', 'normal', 'face', 'sp'):
            raw = getattr(mesh, raw_attr[bt], b'')
            if not raw:
                continue
            so = _s.unpack(fmt + 'I', mh[field[bt]:field[bt] + 4])[0]
            no = info.get(info_key[bt], 0)
            if so and no:
                blocks.append((so + START, len(raw), no + START, bt))
    skel_src = _s.unpack(fmt + 'I', rh[HDR_SKEL_OFF:HDR_SKEL_OFF + 4])[0] + START
    if model.raw_skel_to_mtl_bytes:
        blocks.append((skel_src, model.raw_trailer_orig_start - skel_src,
                       materials_end_new - len(model.raw_skel_to_mtl_bytes), 'skel'))
    blocks.append((model.raw_trailer_orig_start, len(model.raw_trailer),
                   materials_end_new, 'trailer'))
    blocks.sort()

    def locate(p):
        for s, sz, ns, bt in blocks:
            if s <= p < s + sz:
                return s, ns, bt
        return None

    new_slots = set()
    n_existing = sum(1 for m in model.meshes if getattr(m, 'raw_header', b''))
    mt_cols = set()        # learn which mesh-table columns are relocated (v3/v7 differ)
    for slot in src_slots:
        if slot < layout['header_size']:
            new_slots.add(slot)                                    # header — never moves
            continue
        if src_mt <= slot < src_mt + n_existing * stride:
            rel = slot - src_mt
            mt_cols.add(rel % stride)
            new_slots.add(mesh_table_pos + rel)                    # mesh table at same base
            continue
        loc = locate(slot)
        if loc is None:
            raise ValueError(f"reloc slot 0x{slot:x} unmapped")
        ss, ns, bt = loc
        npos = ns + (slot - ss)
        new_slots.add(npos)
        # Re-base ONLY genuine INTRA-block pointers — those whose target lands in
        # the SAME captured block as the pointer itself (sp record tables -> own
        # records; vertex FOT -> own morph frames). The v3 face block stores its
        # inline u16 index strip in a region POF0 also enumerates; those words
        # are index DATA, and a value that merely happens to resolve into some
        # far block is NOT a pointer the parser dereferences as one — shifting it
        # turns a valid vertex index out of range and crashes the reader. A
        # same-block target is the reliable signal that a value is a real pointer
        # we must move with its block; everything else is left verbatim (the
        # engine's own relocation handles header/mesh-table/data-offset fields,
        # which are patched elsewhere or used file-relative).
        cur = _s.unpack(fmt + 'I', bytes(w.buf[npos:npos + 4]))[0]
        tloc = locate(cur + START) if cur else None
        if tloc is not None and tloc[0] == ss and (ns - ss):
            w.patch_u32(npos, (cur + (ns - ss)) & 0xFFFFFFFF)

    # New meshes (no raw_header): add their own relocations.
    for mi, (mesh, info) in enumerate(zip(model.meshes, mesh_infos)):
        if getattr(mesh, 'raw_header', b''):
            continue
        row = mesh_table_pos + mi * stride
        for col in mt_cols:                                        # same columns as existing rows
            if _s.unpack(fmt + 'I', bytes(w.buf[row + col:row + col + 4]))[0]:
                new_slots.add(row + col)
        # face-block self pointer (+0 of the block)
        fo = info.get('face_off', 0)
        if fo and getattr(mesh, 'raw_face_bytes', b''):
            new_slots.add(fo + START)
        # cloned shader-param pointer table: re-base each entry to the clone's
        # own record positions + register every entry as a relocation.
        sp = getattr(mesh, 'raw_shader_param_bytes', b'')
        spo = info.get('shader_param_off', 0)
        if sp and spo and len(sp) % 28 == 0:
            n = len(sp) // 28
            base = spo + START                                     # block data start (file pos)
            for k in range(n):
                rec_pos = base + n * 4 + k * 24                    # clone's own record k
                w.patch_u32(base + k * 4, (rec_pos - START) & 0xFFFFFFFF)
                new_slots.add(base + k * 4)

    # Sanity: every slot 4-aligned and inside the data region (before POF0).
    for s in new_slots:
        if s % 4 or not (0 <= s < new_chunk_start):
            raise ValueError(f"slot 0x{s:x} out of range / misaligned")

    chunk = pof0.build_chunk(sorted(new_slots))
    del w.buf[new_chunk_start:]
    w.buf.extend(chunk)


def write_yobj_from_model(filepath: str, model: YOBJModel) -> bool:
    """Write `model` to disk as a YOBJ/JBOY file, honoring its format hints.

    When `model.raw_header` is populated (round-trip path from a parsed file),
    we start the output with those exact bytes and only patch the fields whose
    values change as a result of re-laying-out the data blocks: file size,
    mesh table offset, skeleton/texture/material offsets, morph-name offset
    (v3) and bone-palette offset (v3). Every other byte of the on-disk
    header is preserved verbatim — including unknown fields the engine may
    validate (e.g. +0x24 texture count, +0x48 morph count, plus any
    game-specific fields we haven't decoded).

    From-scratch authoring (empty `raw_header`) builds a header from semantic
    fields with sensible defaults for the unknown regions.
    """
    layout = _layout_for(model.version_field)
    w = _Writer(big_endian=model.is_big_endian)
    n_meshes = len(model.meshes)

    # ── File header ──────────────────────────────────────────────────────────
    magic = bytes(model.magic) if model.magic in (MAGIC_JBOY, MAGIC_YOBJ) else MAGIC_JBOY

    if model.raw_header and len(model.raw_header) != layout['header_size']:
        print(
            f"[Yukes] raw_header size mismatch "
            f"(got {len(model.raw_header)}, expected {layout['header_size']}); "
            f"falling back to from-scratch — may lose engine-critical fields"
        )

    if model.raw_header and len(model.raw_header) == layout['header_size']:
        # Round-trip path: start from the original bytes and patch only the
        # fields whose values change.
        w.w_bytes(model.raw_header)
        file_size_pos = 0x04
        file_size_dup_pos = 0x0C
        # +0x18 mesh_count, +0x1C mesh_table_off, +0x20 bone_count, +0x24
        # texture count, +0x34 mtl_count are stable for a re-lay-out as long
        # as the model object's counts match what's already in the bytes; we
        # patch them to be safe.
        w.patch_u32(0x18, n_meshes)
        w.patch_u32(0x1C, layout['header_size'] - START_OFFSET)
        w.patch_u32(0x20, len(model.bones))
        # Do NOT patch +0x24 (nominally "texture count"). The parser derives the
        # texture list from the tex_off..mtl_off layout, but on some versions
        # (v7) the +0x24 field holds a different value than that count, so
        # re-patching it with len(textures) corrupts the header. It doesn't
        # change on a re-layout, so preserve whatever raw_header already has.
        w.patch_u32(0x34, len(model.materials))
        skel_off_pos = 0x28
        tex_off_pos  = 0x2C
        mtl_off_pos  = 0x30
        morph_off_pos = palette_off_pos = -1
        if layout['has_morph_table']:
            morph_off_pos = HDR_MORPH_NAME_OFF
            palette_off_pos = HDR_BONE_PALETTE_OFF
            # Do NOT patch +0x48 (global morph count): it's version-specific
            # (v7 stores a value that differs from len(morph_names)) and doesn't
            # change on a re-layout, so preserve the raw_header value.
    else:
        # From-scratch authoring path.
        w.w_bytes(magic)
        file_size_pos = w.pos();   w.w_u32(0)
        w.w_u32(0)                                         # +0x08
        file_size_dup_pos = w.pos(); w.w_u32(0)            # +0x0C
        w.w_u32(model.version_field)                       # +0x10
        w.w_u32(0)                                         # +0x14

        w.w_u32(n_meshes)                                  # +0x18
        w.w_u32(layout['header_size'] - START_OFFSET)      # +0x1C
        w.w_u32(len(model.bones))                          # +0x20
        w.w_u32(len(model.textures))                       # +0x24 texture count

        skel_off_pos = w.pos();   w.w_u32(0)               # +0x28
        tex_off_pos  = w.pos();   w.w_u32(0)               # +0x2C
        mtl_off_pos  = w.pos();   w.w_u32(0)               # +0x30
        w.w_u32(len(model.materials))                      # +0x34

        morph_off_pos = palette_off_pos = -1
        if layout['has_morph_table']:
            while w.pos() < 0x48:
                w.w_u32(0)
            w.w_u32(len(model.morph_names))                # +0x48 morph count
            morph_off_pos = w.pos();   w.w_u32(0)          # +0x4C
            w.w_u32(1)                                     # +0x50
            palette_off_pos = w.pos(); w.w_u32(0)          # +0x54

        while w.pos() < layout['header_size']:
            w.w_u32(0)

    # ── Reserve mesh table ───────────────────────────────────────────────────
    mesh_table_pos = w.pos()
    assert mesh_table_pos == layout['header_size']
    w.reserve(n_meshes * layout['stride'])

    # Some models carry an unreferenced positional block right after the mesh
    # table (no header offset points at it; the engine locates it by position).
    # Splice it verbatim so the first per-mesh block lands at its original
    # offset. Empty for the common case where blocks pack tight to the table.
    if model.raw_preblock_bytes:
        w.w_bytes(model.raw_preblock_bytes)

    # ── Mesh data blocks, emitted in the SOURCE file's block order ──────────
    # The per-mesh blocks are NOT always laid out vtx,weight,uv,normal,face,sp
    # in mesh-index order: some files place the shader-param block FIRST (before
    # the vertex block), and some interleave different meshes' blocks. A fixed
    # emission order writes byte-identical block contents but at shifted
    # positions, so every per-mesh offset field ends up wrong. Re-deriving the
    # order from each mesh's raw_header offsets reproduces the source layout
    # exactly (and is identical to the canonical order for files that already
    # follow it). From-scratch meshes (no usable raw_header) use the canonical
    # per-version order.
    is_legacy = model.version_field == VERSION_LEGACY
    mesh_infos: List[dict] = [
        {'vertex_off': 0, 'weight_off': 0, 'uv_off': 0,
         'normal_off': 0, 'face_off': 0, 'face_section_count': 1}
        for _ in model.meshes
    ]
    bt_field = {
        'vtx':    MESH_VERTEX_OFFSET,  'weight': MESH_WEIGHT_OFFSET,
        'uv':     MESH_UV_OFFSET,      'normal': MESH_NORMAL_OFFSET,
        'face':   layout['face_offset_off'],
        'sp':     layout['shader_param_off_off'],
    }

    def _emit_block(mi: int, bt: str) -> None:
        mesh = model.meshes[mi]
        info = mesh_infos[mi]
        if bt == 'sp':
            info['shader_param_off'] = _write_shader_param_block(w, mesh)
        elif bt == 'vtx':
            info['vertex_off'] = _write_vertex_block(w, mesh)
        elif bt == 'weight':
            info['weight_off'] = _write_weight_block(w, mesh)
        elif bt == 'uv':
            info['uv_off'] = _write_uv_block(w, mesh)
        elif bt == 'normal':
            info['normal_off'] = 0 if is_legacy else _write_normal_block_v3(w, mesh)
        elif bt == 'face':
            if is_legacy:
                n_sec_target = mesh.face_sec if mesh.face_sec else 1
                fo, n_sec = _write_face_block_v0(w, mesh.faces, n_sec_target, mesh)
                info['face_off'] = fo
                info['face_section_count'] = n_sec
            else:
                orig_face_raw = 0
                if mesh.raw_header and len(mesh.raw_header) == layout['stride']:
                    orig_face_raw = struct.unpack_from(
                        w.fmt + 'I', mesh.raw_header, layout['face_offset_off'])[0]
                info['face_off'] = _write_face_block_v3(
                    w, mesh.faces, mesh, orig_face_raw)
                info['face_section_count'] = 1

    all_raw = all(m.raw_header and len(m.raw_header) == layout['stride']
                  for m in model.meshes)
    if all_raw and not is_legacy:
        # Emit every PRESENT block (raw_off != 0) in ascending original-offset
        # order. A block whose source offset is 0 doesn't exist in the file and
        # must NOT be synthesized (that would shift everything after it).
        prio = {'vtx': 0, 'weight': 1, 'uv': 2, 'normal': 3, 'face': 4, 'sp': 5}
        field_key = {'vtx': 'vertex_off', 'weight': 'weight_off', 'uv': 'uv_off',
                     'normal': 'normal_off', 'face': 'face_off', 'sp': 'shader_param_off'}
        emission = []
        for mi, mesh in enumerate(model.meshes):
            for bt in ('vtx', 'weight', 'uv', 'normal', 'face', 'sp'):
                raw_off = struct.unpack_from(
                    w.fmt + 'I', mesh.raw_header, bt_field[bt])[0]
                if raw_off != 0:
                    emission.append((raw_off, mi, prio[bt], bt))
        emission.sort(key=lambda t: (t[0], t[1], t[2]))
        # Some versions ALIAS block offsets within a mesh (e.g. v1 sets
        # sp_off == vtx_off — the "sp" field just points at the vertex block).
        # Emit each distinct (mesh, source-offset) region ONCE; an aliased block
        # reuses the already-written region's new offset instead of writing a
        # duplicate (which would grow the file). prio ensures the primary block
        # (vtx < weight < ... < sp) is the one actually emitted.
        emitted = {}
        for raw_off, mi, _p, bt in emission:
            key = (mi, raw_off)
            if key in emitted:
                mesh_infos[mi][field_key[bt]] = emitted[key]
                continue
            emitted[key] = w.raw(w.pos())
            _emit_block(mi, bt)
    else:
        # From-scratch / legacy: canonical per-version order (sp first on v0).
        for mi in range(len(model.meshes)):
            seq = (['sp', 'vtx', 'weight', 'uv', 'face'] if is_legacy
                   else ['vtx', 'weight', 'uv', 'normal', 'face', 'sp'])
            for bt in seq:
                _emit_block(mi, bt)

    # ── Skeleton / textures / materials ─────────────────────────────────────
    if (model.raw_skel_to_mtl_bytes and model.raw_header
            and model.version_field != VERSION_LEGACY):
        # Round-trip: splice the skeleton + texture + material region verbatim.
        # Re-encoding bones from decoded fields loses exact float bits, and the
        # bone-tail[2,3] / texture_header[0,1] 8-byte overlap is fragile — the
        # engine validates all of it. The region tight-packs between the last
        # sp block (whose trailing 8 bytes ARE the skeleton's raw-off zone, so
        # we do NOT reserve here) and materials_end. Drop it in as one blob and
        # patch the three header offsets by however far the region shifted
        # (zero in a clean round-trip, but stay robust to earlier-block drift).
        new_skel_data_pos = w.pos()
        orig_skel_off = struct.unpack(w.fmt + 'I', model.raw_header[0x28:0x2C])[0]
        orig_tex_off  = struct.unpack(w.fmt + 'I', model.raw_header[0x2C:0x30])[0]
        orig_mtl_off  = struct.unpack(w.fmt + 'I', model.raw_header[0x30:0x34])[0]
        shift = new_skel_data_pos - (orig_skel_off + START_OFFSET)
        w.w_bytes(model.raw_skel_to_mtl_bytes)
        w.patch_u32(skel_off_pos, (orig_skel_off + shift) & 0xFFFFFFFF)
        w.patch_u32(tex_off_pos,  (orig_tex_off + shift) & 0xFFFFFFFF)
        w.patch_u32(mtl_off_pos,  (orig_mtl_off + shift) & 0xFFFFFFFF)
    else:
        # From-scratch / legacy: re-encode each block. Lossy at the bit level
        # but structurally valid. _write_skeleton reserve(8)s its own raw-off
        # pad; the bone-tail/texture-header overlap is reproduced by rewinding
        # 8 before the texture writer overlays texture_header onto tail[2,3].
        w.patch_u32(skel_off_pos, _write_skeleton(w, model.bones))
        del w.buf[-8:]
        w.patch_u32(tex_off_pos,  _write_textures(w, model))
        w.patch_u32(mtl_off_pos,  _write_materials(w, model.materials))

    # ── Trailer: bytes from materials_end onward ────────────────────────────
    # When round-tripping a parsed model, we splice the original trailer
    # back in. This carries:
    #   * v0 (SVR-era): the global POF0 shader block the engine derefs.
    #   * v3 (2K15-19): the morph-name table, global bone palette, plus
    #     POF0 sub-data after both. The header's morph_name_off and
    #     bone_palette_off must be patched so they still point into the
    #     re-laid-out trailer. Additionally, the bone_palette block has an
    #     INTERNAL absolute offset (its `data_off_raw` field at +4 of the
    #     block) that points to the int32 array; that field also has to be
    #     shifted because the trailer landed at a new file position.
    # When authoring from scratch (no raw_trailer), fall back to writing
    # synthesized morph-name and bone-palette blocks for v3.
    materials_end_new = w.pos()
    if model.raw_trailer:
        # Compute the byte shift between original trailer start and our new
        # trailer start. The shift uniformly applies to every offset that
        # pointed into the trailer.
        shift = materials_end_new - model.raw_trailer_orig_start
        trailer_file_pos = w.pos()
        w.w_bytes(model.raw_trailer)

        # Patch v3 header offsets (morph_name_off, bone_palette_off) by the
        # shift so they continue to point at the right spots in the trailer.
        if layout['has_morph_table'] and morph_off_pos >= 0 and model.raw_header:
            orig_morph_off = struct.unpack(w.fmt + 'I',
                                            model.raw_header[HDR_MORPH_NAME_OFF:HDR_MORPH_NAME_OFF + 4])[0]
            if orig_morph_off:
                w.patch_u32(morph_off_pos, (orig_morph_off + shift) & 0xFFFFFFFF)
        if layout['has_palette_table'] and palette_off_pos >= 0 and model.raw_header:
            orig_palette_off = struct.unpack(w.fmt + 'I',
                                              model.raw_header[HDR_BONE_PALETTE_OFF:HDR_BONE_PALETTE_OFF + 4])[0]
            if orig_palette_off:
                # Header field shift.
                w.patch_u32(palette_off_pos, (orig_palette_off + shift) & 0xFFFFFFFF)

                # The bone_palette block's internal data_off_raw field is at
                # offset +4 of the block, where the block starts at
                # (orig_palette_off + START_OFFSET). Find that field's
                # location WITHIN the trailer bytes we just wrote, then
                # shift its value by `shift`.
                internal_field_pos_in_trailer = (
                    (orig_palette_off + START_OFFSET + 4)
                    - model.raw_trailer_orig_start
                )
                if 0 <= internal_field_pos_in_trailer <= len(model.raw_trailer) - 4:
                    new_internal_pos = trailer_file_pos + internal_field_pos_in_trailer
                    orig_internal = struct.unpack(
                        w.fmt + 'I',
                        bytes(w.buf[new_internal_pos:new_internal_pos + 4])
                    )[0]
                    w.patch_u32(new_internal_pos, (orig_internal + shift) & 0xFFFFFFFF)
    else:
        # No raw trailer (from-scratch authoring) — synthesize v3 tables.
        if layout['has_morph_table'] and morph_off_pos >= 0:
            w.patch_u32(morph_off_pos, _write_morph_names(w, model.morph_names or []))
        if layout['has_palette_table'] and palette_off_pos >= 0:
            w.patch_u32(palette_off_pos, _write_bone_palette(w, model.global_bone_palette))

    # ── Backfill file size and mesh table ───────────────────────────────────
    # The +0x04 field (duplicated at +0x0C) is NOT the file length and is NOT
    # materials_end — it's the raw offset of the trailer's POF0 relocation
    # block. Verified on every corpus sample: field + START_OFFSET == the
    # filepos of the (last) POF0 magic, exactly, while the distance from the
    # field to materials_end varies from -12 to -3640 bytes. The engine uses
    # this field to locate POF0 and fix up pointers, so it must land on POF0.
    # POF0 lives inside raw_trailer at a fixed offset; we write raw_trailer
    # verbatim at the (possibly shifted) materials_end_new, so the new POF0
    # sits at materials_end_new + (POF0's offset within the original trailer).
    # Recover that offset from the captured original field and trailer start.
    if model.raw_trailer and model.raw_header:
        orig_field = struct.unpack(w.fmt + 'I', model.raw_header[0x04:0x08])[0]
        pof0_off_in_trailer = (orig_field + START_OFFSET) - model.raw_trailer_orig_start
        final_size_raw = w.raw(materials_end_new + max(0, pof0_off_in_trailer))
    else:
        final_size_raw = w.raw(materials_end_new)
    w.patch_u32(file_size_pos, final_size_raw)
    w.patch_u32(file_size_dup_pos, final_size_raw)

    for mi, (mesh, info) in enumerate(zip(model.meshes, mesh_infos)):
        header_buf = bytearray(layout['stride'])
        _write_mesh_header(header_buf, layout, mesh, info, w.be)
        start = mesh_table_pos + mi * layout['stride']
        w.buf[start:start + layout['stride']] = header_buf

    # POF0 relocation regen — only when a NEW mesh shifts the layout; the clean
    # byte-exact path is untouched. Never worse than verbatim: on ANY uncertainty
    # it raises and the caller keeps the spliced POF0.
    try:
        _finalize_pof0_relocations(w, model, mesh_infos, layout,
                                   mesh_table_pos, materials_end_new)
    except Exception as _e:
        print(f"[Yukes] POF0 regen kept verbatim ({_e})")

    with open(filepath, 'wb') as f:
        f.write(w.buf)
    return True


# ── Blender-driven entry point ──────────────────────────────────────────────

def export_yobj(filepath, objects, armature=None, version: int = 3,
                magic: bytes = MAGIC_JBOY, big_endian: bool = True) -> bool:
    """
    Collect data from a Blender scene and write it as a YOBJ file.

    For round-trip use, read `version`, `magic`, `big_endian` from custom
    properties on the armature so an imported file can be re-exported in the
    same on-disk format. Defaults are the 2K15-2K19 BE/JBOY combination.
    """
    import bpy
    from .exporter_blender import (
        collect_meshes_from_blender, collect_bones_from_blender,
        collect_round_trip_metadata_from_armature,
    )

    bones = collect_bones_from_blender(armature) if armature else []
    meshes, materials, textures, morph_names = collect_meshes_from_blender(
        objects, armature, bones
    )

    # Pull file-level round-trip metadata stashed on the armature by import.
    rt_meta = collect_round_trip_metadata_from_armature(armature)

    model = YOBJModel(
        version=f"v{version}",
        bones=bones,
        materials=materials,
        meshes=meshes,
        textures=textures,
        texture_header=rt_meta.get('texture_header', (1.0, 1.0)),
        morph_names=morph_names,
        global_bone_palette=rt_meta.get('global_bone_palette', None),
        magic=magic,
        version_field=version,
        is_big_endian=big_endian,
        raw_header=rt_meta.get('raw_header', b''),
        raw_trailer=rt_meta.get('raw_trailer', b''),
        raw_trailer_orig_start=rt_meta.get('raw_trailer_orig_start', 0),
        raw_skel_to_mtl_bytes=rt_meta.get('raw_skel_to_mtl_bytes', b''),
    )

    if version != VERSION_LEGACY and model.global_bone_palette is None:
        # Build from used bones if not preserved.
        used = set()
        for m in meshes:
            if m.bone_indices is not None:
                used.update(int(x) for x in m.bone_indices.flatten()
                            if int(x) != 0 and int(x) != WEIGHT_PADDING_INDEX)
        if used:
            model.global_bone_palette = np.array(sorted(used), dtype=np.uint32)

    return write_yobj_from_model(filepath, model)
