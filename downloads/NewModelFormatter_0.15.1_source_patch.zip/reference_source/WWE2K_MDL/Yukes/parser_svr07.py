"""
SVR07/2K14 YOBJ Parser - Parser for WWE SVR 2007 through 2K14 era YOBJ files.

This format is a variant of SVR06 with DIFFERENT field layout after +0x08:
- SVR06: +0x0C=face_data_offset, +0x18=weight_offset, +0x1C=uv_offset
- SVR07: +0x0C=weight_offset, +0x18=uv_offset, +0x1C=shader_params

The first three fields are the SAME as SVR06:
- +0x00: draw_count (submesh count)
- +0x04: material_id
- +0x08: submesh_offset

Other similarities to SVR06:
- 64-byte mesh headers
- 32-byte submesh entries with embedded bone palette
- Position format: Y, Z, X, W (16 bytes per vertex)
- Triangle strip faces (generated from vertex order, no explicit indices)
"""

import numpy as np
from typing import List, Tuple
from .binary_reader import BinaryReader
from .format_consts import START_OFFSET
from .structures import (
    YOBJModel, YOBJHeader, Bone, Material, Mesh
)

MESH_HEADER_SIZE = 64
SUBMESH_ENTRY_SIZE = 32


def is_svr07_format(reader: BinaryReader) -> bool:
    """
    Detect if this is an SVR07/2K14 era YOBJ file.
    
    Key difference from SVR06:
    - +0x0C has weight_offset (SVR06 has face_data_offset there)
    - +0x18 has uv_offset (SVR06 has weight_offset there)
    - No explicit face indices - uses triangle strips
    
    Detection strategy: Check if +0x0C offset points to weight data (floats)
    rather than face index data (integers 0-vertcount).
    """
    reader.seek(0)
    magic = reader.read_bytes(4)
    
    if magic != b'YOBJ':
        return False
    
    reader.set_endian(False)  # Little-endian
    
    # Check header_offset at 0x24
    reader.seek(0x24)
    header_offset = reader.read_int32()
    
    # Must be 0x40 like SVR06
    if header_offset != 0x40:
        return False
    
    # Read first mesh entry
    mesh_start = header_offset + START_OFFSET
    
    reader.seek(mesh_start)
    draw_count = reader.read_int32()      # 0x00
    material_id = reader.read_int32()     # 0x04
    submesh_offset = reader.read_int32()  # 0x08
    val_0c = reader.read_int32()          # 0x0C - weight_offset in SVR07, face_data in SVR06
    
    file_size = reader.size()
    
    # Basic sanity checks
    if not (1 <= draw_count <= 100 and 0 <= material_id <= 100):
        return False
    if val_0c <= 0 or val_0c >= file_size:
        return False
    
    # Read data at +0x18 (uv_offset in SVR07, weight_offset in SVR06)
    reader.seek(mesh_start + 0x18)
    val_18 = reader.read_int32()
    
    # Key check: In SVR07, val_0c points to weight data and val_18 points to UV data
    # In SVR06, val_0c points to face indices and val_18 points to weight data
    
    # Check if val_18 < val_0c - this suggests SVR07 layout where:
    # UV data (val_18 ~0x860) comes BEFORE weight data (val_0c ~0x2280)
    # In SVR06, weight (val_18) would come AFTER face indices (val_0c)
    if val_18 > 0 and val_18 < val_0c:
        # Additional verification: check submesh structure
        reader.seek(submesh_offset + START_OFFSET + 8)  # Skip bounding header
        sub_vert_count = reader.read_int32()
        sub_bone_count = reader.read_int32()
        sub_pos_offset = reader.read_int32()
        
        # Valid submesh with reasonable values
        if (0 < sub_vert_count < 10000 and 
            0 <= sub_bone_count <= 16 and
            0 < sub_pos_offset < file_size):
            return True
    
    return False


def parse_header_svr07(reader: BinaryReader) -> YOBJHeader:
    """Parse SVR07/2K14 format header."""
    reader.seek(0)
    reader.set_endian(False)
    
    magic = reader.read_bytes(4)
    
    reader.seek(0x18)
    
    header = YOBJHeader(
        magic=magic,
        is_big_endian=False,
        object_count=reader.read_int32(),      # 0x18
        bone_count=0,
        material_count=0,
        header_offset=0,
        skeleton_offset=0,
        texture_offset=0,
        material_offset=0,
        bone_palette_offset=0,
    )
    
    reader.skip(4)  # 0x1C: total submesh count
    header.bone_count = reader.read_int32()    # 0x20
    header.header_offset = reader.read_int32() + START_OFFSET  # 0x24
    header.skeleton_offset = reader.read_int32()  # 0x28
    header.material_offset = reader.read_int32()  # 0x2C
    
    return header


def parse_bones_svr07(reader: BinaryReader, header: YOBJHeader) -> List[Bone]:
    """Parse SVR07 skeleton bone data (same as SVR06)."""
    if header.skeleton_offset == 0:
        return []
    
    reader.seek(header.skeleton_offset + START_OFFSET)
    bones = []
    
    BONE_SIZE = 80
    
    # Estimate max bones from material offset
    reader.seek(0x2C)
    material_offset_raw = reader.read_int32()
    
    if material_offset_raw == 0:
        max_bones = header.bone_count if header.bone_count > 0 else 100
    else:
        skel_start = header.skeleton_offset + START_OFFSET
        skel_end = material_offset_raw + START_OFFSET
        skel_size = skel_end - skel_start
        max_bones = skel_size // BONE_SIZE
    
    reader.seek(header.skeleton_offset + START_OFFSET)
    
    for i in range(max_bones):
        start_pos = reader.position
        
        name_bytes = reader.read_bytes(16)
        
        try:
            name = name_bytes.decode('ascii', errors='ignore').split('\x00')[0]
            if not name or not (name[0].isalpha() or name[0] == '_'):
                break
        except Exception:
            break
        
        reader.skip(12)
        position = reader.read_float32_array(3)
        reader.skip(4)
        
        parent_idx = reader.read_int32()
        if parent_idx < -1 or parent_idx >= max_bones or parent_idx == i:
            parent_idx = -1
        
        bytes_read = reader.position - start_pos
        if bytes_read < BONE_SIZE:
            reader.skip(BONE_SIZE - bytes_read)
        
        bones.append(Bone(
            name=name,
            index=i,
            parent_index=parent_idx,
            position=position,
            rotation=np.zeros(3, dtype=np.float32),
            tail=None,
        ))
    
    return bones


def parse_materials_svr07(reader: BinaryReader, header: YOBJHeader) -> List[Material]:
    """Parse SVR07 material data (same as SVR06)."""
    if header.material_offset == 0:
        return []
    
    reader.seek(header.material_offset + START_OFFSET)
    materials = []
    
    max_materials = 100
    
    for i in range(max_materials):
        name_bytes = reader.read_bytes(16)
        reader.skip(16)
        
        name = name_bytes.decode('ascii', errors='ignore').split('\x00')[0]
        
        if not name or (not name[0].isalnum() and name[0] != '_'):
            break
        
        if any(ord(c) < 32 for c in name):
            break
        
        materials.append(Material(
            name=name,
            index=i,
        ))
    
    return materials


def parse_mesh_svr07(
    reader: BinaryReader,
    mesh_idx: int,
    mesh_offset: int,
    materials: List[Material],
    bones: List[Bone],
    flip_uvs: bool = True,
) -> Mesh:
    """
    Parse a single SVR07/2K14 mesh.
    
    Key difference from SVR06: 
    - +0x0C has weight_offset (SVR06 expects face_data)
    - +0x18 has uv_offset (SVR06 expects weight)
    - +0x1C has shader_params (SVR06 expects uv)
    - No explicit face indices - faces generated from triangle strips
    """
    reader.seek(mesh_offset)
    
    # Read mesh header (64 bytes) - SAME as SVR06 for first 3 fields
    draw_count = reader.read_int32()      # 0x00 - submesh/draw count
    material_id = reader.read_int32()     # 0x04 - material ID
    submesh_offset = reader.read_int32()  # 0x08 - points to submesh entries
    weight_data_offset = reader.read_int32()  # 0x0C - weight data (NOT face_data!)
    reader.skip(8)                         # 0x10-0x17: unknown/padding
    uv_data_offset = reader.read_int32()  # 0x18 - UV data location (NOT weight!)
    shader_params = reader.read_int32()   # 0x1C - shader params (NOT uv!)
    index_count = reader.read_int32()     # 0x20 - total index count
    face_count = reader.read_int32()      # 0x24 - face/vertex count
    total_verts = reader.read_int32()     # 0x28 - total vertices or stride
    reader.skip(4)                         # 0x2C: padding
    bbox = reader.read_float32_array(4)   # 0x30-0x3F: bounding box
    
    # Get material name
    if material_id < len(materials):
        mat_name = materials[material_id].name
        mesh_name = mat_name
    else:
        mat_name = f"Material_{material_id}"
        mesh_name = f"Mesh_{mesh_idx}"
    
    # Parse submesh entries
    # Submesh table starts at submesh_offset + 8 (skip 2-float bounding header)
    submesh_base = submesh_offset + START_OFFSET + 8
    
    all_positions = []
    all_normals = []
    all_bone_indices = []
    all_bone_weights = []
    face_indices = []
    vertex_base = 0
    max_influences = 0
    
    for s in range(draw_count):
        sub_off = submesh_base + s * SUBMESH_ENTRY_SIZE
        reader.seek(sub_off)
        
        sub_vert_count = reader.read_int32()
        sub_bone_count = reader.read_int32()
        sub_pos_offset = reader.read_int32() + START_OFFSET
        sub_norm_offset = reader.read_int32() + START_OFFSET
        sub_bone_ids = [reader.read_int32() for _ in range(4)]
        
        # Filter valid bone indices
        valid_bones = [b for b in sub_bone_ids if b != 0xFFFFFFFF and b < 256]
        max_influences = max(max_influences, len(valid_bones))
        
        # Skip submesh header at position data (8 bytes of zeros/marker)
        actual_pos_offset = sub_pos_offset + 8
        actual_norm_offset = sub_norm_offset + 8
        
        # Read position data (format: Y, Z, X, W - 16 bytes per vertex).
        # Vectorized: bulk-read the (sub_vert_count, 4) float block and swap
        # columns Y,Z,X,W → X,Y,Z (drop W). Preserves SVR07's distinctive
        # Y,Z,X position swap (different from SVR06, which reads X,Y,Z direct).
        pos_block = reader.f32_array_at(actual_pos_offset, sub_vert_count * 4).reshape(-1, 4)
        sub_positions = pos_block[:, [2, 0, 1]]  # (y,z,x,w) → (x,y,z)
        all_positions.extend(sub_positions.tolist())

        # Per-vertex bone weights — same template per submesh, then repeated.
        bone_idx = [0, 0, 0, 0]
        bone_wgt = [0.0, 0.0, 0.0, 0.0]
        if valid_bones:
            weight = 1.0 / len(valid_bones)
            for i, b in enumerate(valid_bones[:4]):
                bone_idx[i] = b
                bone_wgt[i] = weight
        for _ in range(sub_vert_count):
            all_bone_indices.append(list(bone_idx))
            all_bone_weights.append(list(bone_wgt))

        # Read normal data (same Y,Z,X,W layout as positions).
        nrm_block = reader.f32_array_at(actual_norm_offset, sub_vert_count * 4).reshape(-1, 4)
        sub_normals = nrm_block[:, [2, 0, 1]]  # (ny,nz,nx,nw) → (nx,ny,nz)
        all_normals.extend(sub_normals.tolist())
        
        # Generate triangle strip faces for this submesh
        for t in range(sub_vert_count - 2):
            if t % 2 == 0:
                face_indices.append([
                    vertex_base + t,
                    vertex_base + t + 1,
                    vertex_base + t + 2
                ])
            else:
                face_indices.append([
                    vertex_base + t + 1,
                    vertex_base + t,
                    vertex_base + t + 2
                ])
        
        vertex_base += sub_vert_count
    
    positions = np.array(all_positions, dtype=np.float32)
    normals = np.array(all_normals, dtype=np.float32)
    faces = np.array(face_indices, dtype=np.uint32) if face_indices else np.zeros((0, 3), dtype=np.uint32)
    bone_indices = np.array(all_bone_indices, dtype=np.uint32)
    bone_weights = np.array(all_bone_weights, dtype=np.float32)
    
    # Read UV data
    # UV data has an 8-byte header to skip
    if uv_data_offset > 0 and len(positions) > 0:
        uv_base = uv_data_offset + START_OFFSET + 8
        # Vectorized bulk read of (n_verts, 2) UV array.
        uvs = reader.f32_array_at(uv_base, len(positions) * 2).reshape(-1, 2).astype(np.float32, copy=False)

        if flip_uvs:
            uvs[:, 1] = 1.0 - uvs[:, 1]
    else:
        uvs = np.zeros((len(positions), 2), dtype=np.float32)
    
    return Mesh(
        index=mesh_idx,
        name=mesh_name,
        shader_type="svr07",
        material_index=material_id,
        positions=positions,
        normals=normals,
        uvs=uvs,
        faces=faces,
        colors=None,
        uvs2=None,
        morph_targets=[],
        bone_indices=bone_indices,
        bone_weights=bone_weights,
        bone_palette=None,
        max_influences=max(max_influences, 4),
    )


def parse_yobj_svr07(
    filepath: str,
    flip_uvs: bool = True,
) -> YOBJModel:
    """
    Parse SVR07/2K14 era YOBJ file.
    
    Args:
        filepath: Path to .yobj file
        flip_uvs: Flip V coordinate (1.0 - v)
        
    Returns:
        YOBJModel with all parsed data
    """
    with BinaryReader(filepath) as reader:
        header = parse_header_svr07(reader)
        bones = parse_bones_svr07(reader, header)
        materials = parse_materials_svr07(reader, header)
        
        meshes = []
        
        for i in range(header.object_count):
            mesh_offset = header.header_offset + i * MESH_HEADER_SIZE
            
            mesh = parse_mesh_svr07(
                reader, i, mesh_offset,
                materials, bones,
                flip_uvs=flip_uvs,
            )
            meshes.append(mesh)
        
        return YOBJModel(
            version="svr07",
            bones=bones,
            materials=materials,
            meshes=meshes,
            global_bone_palette=None,
        )
