"""
YOBJ Parser — high-performance, vectorized, format-correct.

Differences from the previous implementation:
 * No heuristic endianness detection — JBOY = big-endian, YOBJ = little-endian.
 * No heuristic weight-format detection — fixed format (LE u32 + file-endian f32).
 * No DEFAULT_MORPH_NAMES fallback — names are in the file; if missing, we
   surface that rather than masking it.
 * Vectorized weight, morph, and UV reads (NumPy frombuffer + reshape) rather
   than per-vertex Python loops. ~50× faster for typical character meshes.
 * Uses the on-disk frame offset table at vertex_offset rather than assuming
   contiguous frame layout. Robust to format variations.
 * Reads texture name table, material extras, and per-mesh bbox/pivot — all
   were previously discarded.
 * The bone "tail" field at byte +64 is preserved verbatim (was incorrectly
   labeled "quaternion" before — it's not a quaternion).

Note: SVR06, SVR07, and 2K14 era files are still routed through their
existing dedicated parser modules. This module is the unified parser for
the WWE 2K15-2K19 family.
"""

import struct
import numpy as np
from typing import List, Optional

from .binary_reader import BinaryReader
from .format_consts import (
    START_OFFSET, MESH_STRIDE, MESH_STRIDE_LEGACY, VERTEX_STRIDE, WEIGHT_STRIDE, UV_STRIDE,
    UV_HAIR_STRIDE, BONE_STRIDE, MATERIAL_STRIDE, TEX_HEADER_SIZE,
    TEX_NAME_STRIDE, MORPH_HEADER_SIZE, MORPH_NAME_STRIDE,
    MAGIC_JBOY, MAGIC_YOBJ, WEIGHT_PADDING_INDEX,
    HDR_MESH_COUNT, HDR_MESH_TABLE_OFF, HDR_BONE_COUNT, HDR_SKEL_OFF,
    HDR_TEX_OFF, HDR_MTL_OFF, HDR_MTL_COUNT, HDR_MORPH_NAME_OFF,
    HDR_BONE_PALETTE_OFF, HDR_VERSION,
    MESH_VERTEX_COUNT, MESH_USED_BONE_COUNT, MESH_INLINE_PALETTE,
    MESH_INLINE_PALETTE_SLOTS, MESH_WEIGHT_COUNT, MESH_MATERIAL_ID,
    MESH_MORPH_COUNT, MESH_VERTEX_OFFSET, MESH_WEIGHT_OFFSET,
    MESH_UV_OFFSET, MESH_NORMAL_OFFSET,
    MESH_SHADER_TYPE, MESH_SHADER_TYPE_LEN,
    MESH_SHADER_TYPE_LEGACY, MESH_SHADER_TYPE_LEN_LEGACY,
    MESH_FACE_COUNT, MESH_FACE_OFFSET, MESH_BBOX_PIVOT, MESH_FACE_SEC,
    MESH_FACE_COUNT_LEGACY, MESH_FACE_OFFSET_LEGACY, MESH_BBOX_PIVOT_LEGACY,
    FACE_INDEX_COUNT_OFFSET, FACE_DATA_OFFSET,
    BONE_NAME, BONE_NAME_LEN, BONE_POS, BONE_EULER, BONE_PARENT, BONE_TAIL,
    MATERIAL_NAME, MATERIAL_NAME_LEN, MATERIAL_EXTRAS,
    VERSION_LEGACY,
)
from .structures import YOBJModel, Bone, Material, Mesh, MorphTarget
from .tristrip import convert_tristrip_with_restarts

# Older-format detection still routes to dedicated parsers
from .parser_svr import is_svr06_format, parse_yobj_svr06
from .parser_svr07 import is_svr07_format, parse_yobj_svr07
from .parser_2k14 import is_2k14_format, parse_yobj_2k14


class YOBJParseError(Exception):
    """Exception raised when YOBJ parsing fails."""
    pass


def _detect_format(reader: BinaryReader) -> str:
    """Return one of: '15-19', '2k14', 'svr06', 'svr07'."""
    reader.seek(0)
    magic = reader.read_bytes(4)
    if magic not in (MAGIC_JBOY, MAGIC_YOBJ):
        raise YOBJParseError(f"Invalid magic: {magic.hex()}, expected YOBJ or JBOY")
    if is_svr07_format(reader):
        return "svr07"
    if is_svr06_format(reader):
        return "svr06"
    if is_2k14_format(reader):
        return "2k14"
    return "15-19"


# ─────────────────────────────────────────────────────────────────────────────
# 15-19 unified parser
# ─────────────────────────────────────────────────────────────────────────────

def _parse_header_1519(reader: BinaryReader) -> dict:
    """Read the 88-byte file header for 2K15-2K19 format files.

    Endianness inference: JBOY magic is always big-endian. YOBJ magic can
    be either big- or little-endian depending on the platform the file
    was authored for (BE for some 2K17 builds, LE for others). We pick
    the interpretation whose +4 size field is closest to the actual
    file size, which has been an unambiguous signal across all samples
    seen so far.
    """
    reader.seek(0)
    magic = reader.read_bytes(4)

    if magic == MAGIC_JBOY:
        is_be = True
    elif magic == MAGIC_YOBJ:
        # Probe: which endian gives a +4 size field closest to the actual file size?
        be_size = struct.unpack_from('>I', reader._data, 4)[0]
        le_size = struct.unpack_from('<I', reader._data, 4)[0]
        actual = reader.size()
        is_be = abs(actual - be_size) < abs(actual - le_size)
    else:
        raise YOBJParseError(f"Bad magic: {magic}")
    reader.set_endian(is_be)

    # SVR-era files (version 0) have a 0x48-byte header (mesh table sits at
    # +0x48) — they don't carry a separate morph-name table or a global bone
    # palette. Each mesh uses only its own inline palette in those eras.
    is_legacy = reader.u32_at(HDR_VERSION) == VERSION_LEGACY
    if is_legacy:
        morph_name_off = 0
        bone_palette_off = 0
        header_size = 0x48
    else:
        morph_name_off = reader.u32_at(HDR_MORPH_NAME_OFF)
        bone_palette_off = reader.u32_at(HDR_BONE_PALETTE_OFF)
        header_size = 0x58

    raw_header = bytes(reader._data[:header_size])

    return {
        'magic': magic,
        'is_big_endian': is_be,
        'version':          reader.u32_at(HDR_VERSION),
        'mesh_count':       reader.u32_at(HDR_MESH_COUNT),
        'mesh_table_off':   reader.u32_at(HDR_MESH_TABLE_OFF),
        'bone_count':       reader.u32_at(HDR_BONE_COUNT),
        'skel_off':         reader.u32_at(HDR_SKEL_OFF),
        'tex_off':          reader.u32_at(HDR_TEX_OFF),
        'mtl_off':          reader.u32_at(HDR_MTL_OFF),
        'mtl_count':        reader.u32_at(HDR_MTL_COUNT),
        'morph_name_off':   morph_name_off,
        'bone_palette_off': bone_palette_off,
        'raw_header':       raw_header,
    }


def _parse_bones(reader: BinaryReader, hdr: dict) -> List[Bone]:
    """Read the skeleton bone table.

    Each bone is 80 bytes:
      +0   char[16]  name
      +16  float[4]  position (last is pad)
      +32  float[4]  euler rotation (last is pad)
      +48  int32     parent_index (-1 = no parent)
      +52  byte[12]  zeros
      +64  float[4]  bind-pose tail (NOT a quaternion; preserved as-is)
    """
    if hdr['bone_count'] == 0:
        return []
    base = hdr['skel_off'] + START_OFFSET
    bones = []
    for i in range(hdr['bone_count']):
        b = base + i * BONE_STRIDE
        bones.append(Bone(
            name=reader.read_string_at(b + BONE_NAME, BONE_NAME_LEN),
            index=i,
            parent_index=reader.i32_at(b + BONE_PARENT),
            position=reader.f32_array_at(b + BONE_POS, 3),
            rotation=reader.f32_array_at(b + BONE_EULER, 3),
            tail=reader.f32_array_at(b + BONE_TAIL, 4),
        ))
    return bones


def _parse_materials(reader: BinaryReader, hdr: dict) -> List[Material]:
    """Read the material table. 32 bytes per material (16 name + 4×u32 extras)."""
    if hdr['mtl_count'] == 0:
        return []
    base = hdr['mtl_off'] + START_OFFSET
    mats = []
    for i in range(hdr['mtl_count']):
        b = base + i * MATERIAL_STRIDE
        name = reader.read_string_at(b + MATERIAL_NAME, MATERIAL_NAME_LEN)
        extras = tuple(reader.u32_array_at(b + MATERIAL_EXTRAS, 4).tolist())
        mats.append(Material(name=name, index=i, extras=extras))
    return mats


def _parse_textures(reader: BinaryReader, hdr: dict) -> tuple:
    """Read texture name table. Returns (header_floats, [name_strs]).

    Layout: 8 bytes at the raw offset hold the table header (2 floats —
    appears to be UV scale/range). Actual name slots begin at raw +
    START_OFFSET, with stride 16 each.
    """
    if hdr['tex_off'] == 0:
        return ((0.0, 0.0), [])

    # Header lives in the 8 bytes AT the raw offset
    header = (reader.f32_at(hdr['tex_off']), reader.f32_at(hdr['tex_off'] + 4))

    names_start = hdr['tex_off'] + START_OFFSET
    names_end = hdr['mtl_off'] + START_OFFSET   # textures end where materials begin
    n_slots = max(0, (names_end - names_start) // TEX_NAME_STRIDE)

    names = [reader.read_string_at(names_start + i * TEX_NAME_STRIDE,
                                   TEX_NAME_STRIDE) for i in range(n_slots)]
    while names and not names[-1]:
        names.pop()
    return (header, names)


def _parse_morph_names(reader: BinaryReader, hdr: dict) -> List[str]:
    """Read morph target name table. Returns [] if missing — does NOT fall back to defaults.

    Layout: 8 bytes at the raw offset hold (uint32 count, uint32 ?). Name slots
    begin at raw + START_OFFSET, stride 16.
    """
    if hdr['morph_name_off'] == 0:
        return []

    names_start = hdr['morph_name_off'] + START_OFFSET
    names_end = hdr['bone_palette_off'] + START_OFFSET
    n_slots = max(0, (names_end - names_start) // MORPH_NAME_STRIDE)

    return [reader.read_string_at(names_start + i * MORPH_NAME_STRIDE,
                                  MORPH_NAME_STRIDE)
            for i in range(n_slots)]


def _parse_bone_palette(reader: BinaryReader, hdr: dict) -> Optional[np.ndarray]:
    """Read the global bone palette.

    The palette is optional. Pre-2K15 files don't have one (we'd never
    get here — header would set bone_palette_off=0). 2K15-2K19 files
    usually have one. 2K17+ files in HSPC/SHDC containers sometimes
    carry a malformed or extended palette section that doesn't match
    the 1519 layout — in those cases we fail-soft instead of throwing
    an opaque numpy error, since meshes carry inline per-mesh palettes
    that the parser can fall back on.
    """
    if hdr['bone_palette_off'] == 0:
        return None
    bp_off = hdr['bone_palette_off'] + START_OFFSET
    file_size = reader.size()

    # Need at least 8 bytes for [count, data_off]
    if bp_off + 8 > file_size:
        return None

    count = reader.u32_at(bp_off)
    if count == 0:
        return None
    # Sanity ceiling — real palettes are hundreds, not millions
    if count > 10000:
        return None

    data_off = reader.u32_at(bp_off + 4) + START_OFFSET
    if data_off + count * 4 > file_size:
        return None

    return reader.i32_array_at(data_off, count).astype(np.uint32)


def _parse_mesh(reader: BinaryReader, hdr: dict, mesh_idx: int,
                materials: List[Material],
                global_palette: Optional[np.ndarray],
                morph_names: List[str],
                import_morphs: bool,
                flip_uvs: bool) -> Mesh:
    """Parse a single mesh — vectorized hot paths.

    Layout differs slightly between version 0 (SVR 08-11, WWE 12/13) and
    version 3 (WWE 2K15-2K19): legacy uses a 180-byte stride with a
    16-byte shader name slot at +0x78, while 2K15-19 uses a 184-byte
    stride with an 8-byte shader name slot at +0x7C and a 4-byte unknown
    field preceding it. The fields after the shader slot all shift by 4
    bytes in the legacy layout. Vertex/weight/UV/face block formats
    themselves are identical.
    """
    if hdr.get('version', 3) == VERSION_LEGACY:
        stride = MESH_STRIDE_LEGACY
        shader_off = MESH_SHADER_TYPE_LEGACY
        shader_len = MESH_SHADER_TYPE_LEN_LEGACY
        face_count_off = MESH_FACE_COUNT_LEGACY
        face_offset_off = MESH_FACE_OFFSET_LEGACY
        bbox_off = MESH_BBOX_PIVOT_LEGACY
    else:
        stride = MESH_STRIDE
        shader_off = MESH_SHADER_TYPE
        shader_len = MESH_SHADER_TYPE_LEN
        face_count_off = MESH_FACE_COUNT
        face_offset_off = MESH_FACE_OFFSET
        bbox_off = MESH_BBOX_PIVOT

    base = hdr['mesh_table_off'] + START_OFFSET + mesh_idx * stride
    raw_mesh_header = bytes(reader._data[base:base + stride])

    vc = reader.u32_at(base + MESH_VERTEX_COUNT)
    used_bn = reader.u32_at(base + MESH_USED_BONE_COUNT)
    inline_palette_full = tuple(
        reader.u32_array_at(base + MESH_INLINE_PALETTE,
                            MESH_INLINE_PALETTE_SLOTS).tolist()
    )
    wc = reader.u32_at(base + MESH_WEIGHT_COUNT)
    mat_id = reader.u32_at(base + MESH_MATERIAL_ID)
    morph_count = reader.u32_at(base + MESH_MORPH_COUNT)
    vtx_off_raw = reader.u32_at(base + MESH_VERTEX_OFFSET)
    weight_off = reader.u32_at(base + MESH_WEIGHT_OFFSET) + START_OFFSET
    uv_off = reader.u32_at(base + MESH_UV_OFFSET) + START_OFFSET
    nrm_off = reader.u32_at(base + MESH_NORMAL_OFFSET) + START_OFFSET
    shader_type = reader.read_string_at(base + shader_off, shader_len)
    face_count_field = reader.u32_at(base + face_count_off)
    face_off_raw = reader.u32_at(base + face_offset_off)
    bbox_pivot = tuple(reader.f32_array_at(base + bbox_off, 4).tolist())

    # The shader-parameter block is captured in a post-pass after all
    # meshes are parsed (see parse_yobj) since for v3 its bound comes from
    # the next mesh's blocks. We initialize empty here.
    raw_shader_param_bytes = b''

    if used_bn > 0:
        bone_palette = np.array(inline_palette_full[:used_bn], dtype=np.uint32)
    else:
        bone_palette = global_palette

    if 0 <= mat_id < len(materials):
        mat_name = materials[mat_id].name
        mesh_name = mat_name[2:] if mat_name.startswith('M_') else mat_name
    else:
        mesh_name = f"Material_{mat_id}"

    # ── Vertex data (basis + morphs in one batched read) ──────────────────────
    # Layout at vtx_off_raw + 0:
    #   +0..+7   8 bytes pad (zero) — these are "consumed" by the START_OFFSET
    #            convention; the table itself starts at vtx_off_raw + START_OFFSET.
    #   +8..     uint32[?] frame offsets (each RAW; +START_OFFSET to reach the
    #            actual frame's vertex data).
    #
    # The mesh-header `morph_count` field tells us the count for 2K15/16/18/19
    # files but is reliably wrong on 2K17 (always reads 1 even when 111 frames
    # are present). We probe the table and use the *actual* number of valid,
    # sequential, plausibly-spaced offsets it contains. This handles both:
    #   - well-formed headers: walk stops at exactly morph_count entries
    #   - 2K17's "morph_count = 1 but actually has N frames" quirk
    fot_pos = vtx_off_raw + START_OFFSET
    # First entry is always valid; walk forward as long as entries look like
    # plausibly-spaced frame offsets (each a `vc * VERTEX_STRIDE` block apart).
    frame_size = vc * VERTEX_STRIDE
    first_frame = int(reader.u32_at(fot_pos)) + START_OFFSET
    # The frame-offset table cannot extend past the first frame's data, so
    # cap how many entries we'll inspect to avoid reading frame bytes as
    # offsets.
    max_entries_by_layout = max(1, (first_frame - fot_pos) // 4)
    actual_count = 1
    prev = int(reader.u32_at(fot_pos))
    for k in range(1, int(max_entries_by_layout)):
        e = int(reader.u32_at(fot_pos + k * 4))
        if e <= prev:
            break
        gap = e - prev
        # Accept if the gap matches the frame size (allowing slack for any
        # alignment padding the writer might insert).
        if gap < frame_size or gap > frame_size + 64:
            break
        actual_count += 1
        prev = e

    morph_count_actual = max(morph_count, actual_count)

    frame_offsets_raw = reader.u32_array_at(fot_pos, morph_count_actual)
    frame0_pos = int(frame_offsets_raw[0]) + START_OFFSET
    expected_bytes = morph_count_actual * vc * VERTEX_STRIDE

    raw = reader.bytes_at(frame0_pos, expected_bytes).reshape(
        (morph_count_actual, vc, VERTEX_STRIDE))
    pos_view = reader.view_floats(raw[:, :, 0:12]).reshape(morph_count_actual, vc, 3)
    nrm_view = reader.view_floats(raw[:, :, 12:24]).reshape(morph_count_actual, vc, 3)
    tail_view = raw[:, :, 24:28].copy()

    positions = pos_view[0].copy()
    normals = nrm_view[0].copy()
    vertex_tail = tail_view[0].copy()

    # Derive RGBA vertex colors only if the tail bytes vary across vertices.
    # If they're uniform across the whole mesh they're padding/sentinel, not
    # real per-vertex color, and applying them in Blender just clutters the
    # mesh with a flat color attribute.
    colors = None
    if vc > 0:
        unique_tails = np.unique(vertex_tail.view('<u4'))
        if len(unique_tails) > 1:
            colors = (vertex_tail.astype(np.float32) / 255.0)

    morph_targets: List[MorphTarget] = []
    if import_morphs and morph_count_actual > 1:
        for mt_idx in range(morph_count_actual - 1):
            frame = mt_idx + 1
            mt_name = (morph_names[mt_idx]
                       if mt_idx < len(morph_names) and morph_names[mt_idx]
                       else f"Morph_{mt_idx}")
            morph_targets.append(MorphTarget(
                name=mt_name,
                positions=pos_view[frame].copy(),
                normals=nrm_view[frame].copy(),
                # Verbatim frame bytes (incl. per-vertex tail) for byte-exact
                # round-trip; `raw` is already shaped (frame, vc, 28).
                raw_frame_bytes=raw[frame].tobytes(),
            ))

    # ── UVs ───────────────────────────────────────────────────────────────────
    is_hair = 'hair' in shader_type.lower()
    uvs2 = None
    if is_hair:
        raw_uv = reader.bytes_at(uv_off, vc * UV_HAIR_STRIDE).reshape(vc, UV_HAIR_STRIDE)
        uvs = reader.view_floats(raw_uv[:, 0:8]).reshape(vc, 2).copy()
        uvs2 = reader.view_floats(raw_uv[:, 8:16]).reshape(vc, 2).copy()
    else:
        uvs = reader.f32_array_at(uv_off, vc * 2).reshape(vc, 2).copy()
    if flip_uvs:
        uvs[:, 1] = 1.0 - uvs[:, 1]
        if uvs2 is not None:
            uvs2[:, 1] = 1.0 - uvs2[:, 1]

    # ── Weights ───────────────────────────────────────────────────────────────
    bone_indices = np.zeros((vc, wc), dtype=np.uint32)
    bone_weights = np.zeros((vc, wc), dtype=np.float32)
    if wc > 0:
        wraw = reader.bytes_at(weight_off, vc * wc * WEIGHT_STRIDE).reshape(vc, wc, WEIGHT_STRIDE)
        # Bone index: ALWAYS little-endian uint32, regardless of file endian
        bone_indices = wraw[:, :, 0:4].copy().view('<u4').reshape(vc, wc).astype(np.uint32)
        bone_weights = reader.view_floats(wraw[:, :, 4:8]).reshape(vc, wc).copy()

        # 2K17+ packed-byte weight encoding ────────────────────────────────
        # Some meshes in 2K17+ JBOY files encode the palette index in
        # bytes 1-2 of the 4-byte slot (u16 LE) with byte 0 as a flag,
        # rather than using the whole slot as a u32 index. The trigger is
        # any active influence whose u32 value exceeds the bone palette
        # size — a real u32 index is bounded by len(palette), so values
        # above that bound are necessarily the packed layout. The format
        # is consistent within a single mesh (per-vertex format never
        # changes mid-mesh), so a single test on the active-influence max
        # decides for the whole array.
        palette_len = len(bone_palette) if bone_palette is not None else 0
        if palette_len > 0:
            active = bone_weights > 1e-6
            if active.any():
                max_active_idx = int(bone_indices[active].max())
                if max_active_idx >= palette_len:
                    bone_indices = ((bone_indices >> 8) & 0xFFFF).astype(np.uint32)

        # Zero the padding sentinel (0xFFFFFFFF index) and any near-zero
        # weights so Blender's vertex-group display doesn't show garbage
        # bone references for slots the engine ignores. We do NOT renormalize
        # to sum=1 here — that introduces sub-ULP float drift that breaks
        # bytewise round-trip and can interact poorly with the game's own
        # skinning math when weights are reflected back into the file.
        padding_mask = (bone_indices == WEIGHT_PADDING_INDEX) | (bone_weights < 1e-6)
        bone_indices[padding_mask] = 0
        bone_weights[padding_mask] = 0.0

    # ── Faces ─────────────────────────────────────────────────────────────────
    # Layout differs by version:
    #
    # v3 (2K15-19): one strip per mesh.
    #   At face_off + START_OFFSET:
    #     +0  check (=6)
    #     +4  index_count
    #     +8  data_offset_raw (+START_OFFSET to reach strip)
    #     strip starts at max(face_off+12, data_off+START_OFFSET)
    #
    # v0 (SVR-era): N strips per mesh, where N = mesh.face_sec (read at +0x04).
    #   At face_off + START_OFFSET:
    #     N × { check(4), index_count(4), data_offset_raw(4) }
    #     Each section's strip starts at data_offset_raw + START_OFFSET.
    #   We concatenate all strips with 0xFFFF restart markers between them
    #   so a single tristrip-with-restarts conversion yields the full mesh.
    face_sec = reader.u32_at(base + 0x04)
    face_off = face_off_raw + START_OFFSET

    if hdr.get('version', 3) == VERSION_LEGACY and face_sec > 1:
        strips = []
        for sec in range(face_sec):
            sec_off = face_off + sec * 12
            count = reader.u32_at(sec_off + FACE_INDEX_COUNT_OFFSET)
            data_off_raw = reader.u32_at(sec_off + FACE_DATA_OFFSET)
            sec_strip = reader.u16_array_at(data_off_raw + START_OFFSET, count)
            strips.append(sec_strip)
            # Insert restart marker between sections so a single tristrip
            # conversion produces correct triangulation.
            if sec < face_sec - 1:
                strips.append(np.array([0xFFFF], dtype=sec_strip.dtype))
        strip = np.concatenate(strips) if strips else np.array([], dtype=np.uint16)
    else:
        face_indices_n = reader.u32_at(face_off + FACE_INDEX_COUNT_OFFSET)
        face_data_off_raw = reader.u32_at(face_off + FACE_DATA_OFFSET)
        strip_start = max(face_off + 12, face_data_off_raw + START_OFFSET)
        strip = reader.u16_array_at(strip_start, face_indices_n)

    faces = convert_tristrip_with_restarts(strip)

    return Mesh(
        index=mesh_idx,
        name=mesh_name,
        shader_type=shader_type,
        material_index=mat_id,
        positions=positions,
        normals=normals,
        uvs=uvs,
        faces=faces,
        vertex_tail=vertex_tail,
        colors=colors,
        uvs2=uvs2,
        morph_targets=morph_targets,
        bone_indices=bone_indices,
        bone_weights=bone_weights,
        bone_palette=bone_palette,
        max_influences=wc,
        bbox_pivot=bbox_pivot,
        inline_palette_full=inline_palette_full,
        face_sec=face_sec,
        raw_header=raw_mesh_header,
        raw_shader_param_bytes=raw_shader_param_bytes,
    )


def parse_yobj(filepath: str,
               flip_uvs: bool = True,
               alternate_uv_stride: bool = False,  # accepted for backward-compat; auto-detected from shader
               import_morphs: bool = True) -> YOBJModel:
    """Parse a YOBJ/JBOY file and return a YOBJModel."""
    with BinaryReader(filepath) as reader:
        version = _detect_format(reader)

        if version == "svr07":
            return parse_yobj_svr07(filepath, flip_uvs=flip_uvs)
        if version == "svr06":
            return parse_yobj_svr06(filepath, flip_uvs=flip_uvs)
        if version == "2k14":
            return parse_yobj_2k14(filepath, flip_uvs=flip_uvs)

        # 15-19 unified path
        hdr = _parse_header_1519(reader)
        bones = _parse_bones(reader, hdr)
        materials = _parse_materials(reader, hdr)
        tex_header, textures = _parse_textures(reader, hdr)
        morph_names = _parse_morph_names(reader, hdr)
        global_palette = _parse_bone_palette(reader, hdr)

        meshes = []
        for i in range(hdr['mesh_count']):
            meshes.append(_parse_mesh(
                reader, hdr, i, materials, global_palette,
                morph_names, import_morphs, flip_uvs))

        # ── Second pass: capture shader-param blocks using globally-sorted
        # offsets. The sp block sits at sp_off+8 and runs until the next
        # data block in file-position order. In v0 the next block is
        # typically this same mesh's vertex block, but in v3 the sp block
        # is the *last* per-mesh block so the bound has to come from the
        # next mesh (or the skeleton if this is the last mesh).
        is_legacy = hdr.get('version', 3) == VERSION_LEGACY
        stride = MESH_STRIDE_LEGACY if is_legacy else MESH_STRIDE
        sp_off_field = (MESH_FACE_OFFSET_LEGACY - 4) if is_legacy else 0x98

        # Collect every block's data position (file pos = raw_off + 8) into
        # one sorted set so we can find "the next thing after this sp block".
        all_data_positions = set()
        all_data_positions.add(hdr['skel_off'] + START_OFFSET)
        all_data_positions.add(hdr['tex_off'] + START_OFFSET)
        all_data_positions.add(hdr['mtl_off'] + START_OFFSET)
        if hdr.get('morph_name_off'):
            all_data_positions.add(hdr['morph_name_off'] + START_OFFSET)
        if hdr.get('bone_palette_off'):
            all_data_positions.add(hdr['bone_palette_off'] + START_OFFSET)
        for i in range(hdr['mesh_count']):
            base = hdr['mesh_table_off'] + START_OFFSET + i * stride
            for off_field in (MESH_VERTEX_OFFSET, MESH_WEIGHT_OFFSET,
                              MESH_UV_OFFSET, MESH_NORMAL_OFFSET, sp_off_field,
                              (MESH_FACE_OFFSET_LEGACY if is_legacy else MESH_FACE_OFFSET)):
                v = reader.u32_at(base + off_field)
                if v != 0:
                    all_data_positions.add(v + START_OFFSET)
        sorted_positions = sorted(all_data_positions)

        # Capture any unreferenced positional block sitting between the
        # mesh-table end and the first per-mesh block. A few models store a
        # structure there (bone-palette-style padding + offsets + bbox) that no
        # header offset points at — the engine finds it by position — and a
        # writer that jumps straight from the mesh table to the first block
        # drops it, shifting everything after. Bound it by the smallest
        # per-mesh block data position (NOT skel/tex/mtl, which sit later).
        mesh_table_end = (hdr['mesh_table_off'] + START_OFFSET
                          + hdr['mesh_count'] * stride)
        first_block = reader.size()
        for i in range(hdr['mesh_count']):
            base = hdr['mesh_table_off'] + START_OFFSET + i * stride
            for off_field in (MESH_VERTEX_OFFSET, MESH_WEIGHT_OFFSET,
                              MESH_UV_OFFSET, MESH_NORMAL_OFFSET, sp_off_field,
                              (MESH_FACE_OFFSET_LEGACY if is_legacy else MESH_FACE_OFFSET)):
                v = reader.u32_at(base + off_field)
                if v != 0:
                    first_block = min(first_block, v + START_OFFSET)
        raw_preblock = b''
        if mesh_table_end < first_block <= reader.size():
            raw_preblock = bytes(reader._data[mesh_table_end:first_block])

        for i, mesh in enumerate(meshes):
            base = hdr['mesh_table_off'] + START_OFFSET + i * stride

            def _next_after(pos: int) -> int:
                """Smallest data position strictly greater than `pos`."""
                for p in sorted_positions:
                    if p > pos:
                        return p
                return reader.size()

            # Whole vertex block (FOT + frame0 + morph frames + any shader-
            # specific trailing data). Captured to the next block's data
            # position so hair meshes' large extra geometry stream and v7
            # per-vertex extras — neither frame0 nor a decoded morph frame —
            # are preserved. Spliced verbatim on round-trip (the re-encode path
            # would drop everything past the decoded frames).
            vtx_off_raw = reader.u32_at(base + MESH_VERTEX_OFFSET)
            if vtx_off_raw != 0:
                vtx_data_pos = vtx_off_raw + START_OFFSET
                vtx_end = _next_after(vtx_data_pos)
                if vtx_end <= vtx_data_pos:
                    vtx_end = vtx_data_pos
                mesh.raw_vertex_bytes = bytes(reader._data[vtx_data_pos:vtx_end])
            else:
                mesh.raw_vertex_bytes = b''

            # Shader-param block (no leading pad — same convention as the
            # other per-mesh blocks). Content extends from sp_data_pos
            # right up to the next block's data_pos. The 8 bytes of the
            # next block's "raw_off zone" (raw_data - 8 .. raw_data) are
            # actually the LAST 8 bytes of THIS block's content under the
            # tight-packing convention these files use, so we include
            # them by stopping at next_data_pos rather than next raw_off.
            sp_off_raw = reader.u32_at(base + sp_off_field)
            if sp_off_raw != 0:
                sp_data_pos = sp_off_raw + START_OFFSET
                sp_end = _next_after(sp_data_pos)
                if sp_end <= sp_data_pos:
                    sp_end = sp_data_pos
                mesh.raw_shader_param_bytes = bytes(reader._data[sp_data_pos:sp_end])
            else:
                mesh.raw_shader_param_bytes = b''

            # Normal block (v3 standalone, tight-packed like sp). Frequently
            # all zeros — the engine uses the interleaved vertex normals — so a
            # re-encode from mesh.normals writes real values where the file had
            # zeros. Capture verbatim: content from normal_data_pos up to the
            # next block's data_pos (tight-packing means that bound includes
            # the trailing 8 bytes that double as the next block's raw_off).
            nrm_raw = reader.u32_at(base + MESH_NORMAL_OFFSET)
            if nrm_raw != 0:
                nrm_data_pos = nrm_raw + START_OFFSET
                nrm_end = _next_after(nrm_data_pos)
                if nrm_end <= nrm_data_pos:
                    nrm_end = nrm_data_pos
                mesh.raw_normal_bytes = bytes(reader._data[nrm_data_pos:nrm_end])
            else:
                mesh.raw_normal_bytes = b''

            # UV block (tight-packed like sp/normal). The `1.0 - v` flip
            # re-encode rounds some f32 LSBs differently than the original
            # encoder; capture verbatim so round-trip stays byte-exact.
            uv_raw = reader.u32_at(base + MESH_UV_OFFSET)
            if uv_raw != 0:
                uv_data_pos = uv_raw + START_OFFSET
                uv_end = _next_after(uv_data_pos)
                if uv_end <= uv_data_pos:
                    uv_end = uv_data_pos
                mesh.raw_uv_bytes = bytes(reader._data[uv_data_pos:uv_end])
            else:
                mesh.raw_uv_bytes = b''

            # Weight block. Captured as CONTENT ONLY (vc × wc × 8 bytes from
            # weight_data_pos) — not including the 8-byte "raw_off zone"
            # before data. The exporter pairs this with reserve(8) so the
            # raw_off convention (raw + 8 = data) holds. Capturing from
            # raw_off would either include 8 bytes of the previous block's
            # tail (in 2K-era files where blocks pack tight) or 8 zero
            # bytes of gap (in SVR-era files); content-only sidesteps the
            # difference.
            we_raw = reader.u32_at(base + MESH_WEIGHT_OFFSET)
            mesh_vc = reader.u32_at(base + MESH_VERTEX_COUNT)
            mesh_wc = reader.u32_at(base + MESH_WEIGHT_COUNT)
            if we_raw != 0 and mesh_wc > 0 and mesh_vc > 0:
                we_data_pos = we_raw + START_OFFSET
                # Capture to the next block's data position (tight-pack extent),
                # not just vc*wc*8: some meshes pad the weight block with ~12
                # trailing zero bytes before the next block, and a content-only
                # capture drops them, shifting every later block by that much.
                we_end = _next_after(we_data_pos)
                if we_end <= we_data_pos:
                    we_end = min(we_data_pos + mesh_vc * mesh_wc * WEIGHT_STRIDE,
                                 reader.size())
                mesh.raw_weight_bytes = bytes(reader._data[we_data_pos:we_end])
            else:
                mesh.raw_weight_bytes = b''

            # Face block (no leading pad — same convention as sp). The
            # block contains a header (check, idx_count, data_off) plus
            # strip indices; data_off is an ABSOLUTE file offset that
            # needs patching at write time when the block lands at a new
            # file position. We compute the block size from the on-disk
            # header rather than from the next block's offset, because
            # the trailing-byte ownership convention differs depending
            # on whether the next block has its own leading pad (skel,
            # vtx, etc.) or not (sp). Reading idx_count gives us an
            # unambiguous size.
            face_off_field = (MESH_FACE_OFFSET_LEGACY if is_legacy else MESH_FACE_OFFSET)
            face_raw = reader.u32_at(base + face_off_field)
            if face_raw != 0:
                face_data_pos = face_raw + START_OFFSET
                # Tight-pack extent to the next block, so trailing zero padding
                # (some meshes pad the face block with ~12 bytes before the next
                # block) is preserved verbatim. Fall back to the section-
                # descriptor walk only if there is no following block.
                end = _next_after(face_data_pos)
                if end <= face_data_pos:
                    face_sec = reader.u32_at(base + MESH_FACE_SEC) or 1
                    end = face_data_pos + face_sec * 12
                    for s in range(face_sec):
                        desc = face_data_pos + s * 12
                        sec_idx_count = reader.u32_at(desc + 4)
                        sec_data_off = reader.u32_at(desc + 8) + START_OFFSET
                        sec_end = sec_data_off + sec_idx_count * 2
                        if sec_end > end:
                            end = sec_end
                    end = (end + 3) & ~3  # 4-byte alignment, matching the writer
                mesh.raw_face_bytes = bytes(reader._data[face_data_pos:end])
            else:
                mesh.raw_face_bytes = b''

        # Version label: human-readable era + data version field
        v_field = hdr.get('version', None)
        if v_field == VERSION_LEGACY:
            ver_label = "svr-era (v0)"
        elif v_field == 3:
            ver_label = "2k15-19 (v3)"
        else:
            ver_label = f"unknown (v{v_field})"

        # ── Capture the trailer: bytes from materials_end to file_end ───
        # Every sample has data past materials_end. For v0 it's a POF0-
        # encoded global shader block the engine derefs at draw time. For
        # v3 it's the morph-name table, global bone palette, and additional
        # POF0 sub-data. We treat it all as opaque bytes for round-trip.
        materials_end = hdr['mtl_off'] + START_OFFSET + hdr['mtl_count'] * MATERIAL_STRIDE
        raw_trailer = b''
        trailer_orig_start = materials_end
        if materials_end < reader.size():
            raw_trailer = bytes(reader._data[materials_end:reader.size()])

        # Capture the skeleton + texture + material region as one verbatim
        # blob, [skel_data_pos .. materials_end]. Re-encoding bones loses exact
        # float bits and the bone-tail/texture-header byte overlap; splicing
        # this back unchanged makes that whole region byte-exact on round-trip.
        skel_data_pos = hdr['skel_off'] + START_OFFSET
        raw_skel_to_mtl = b''
        if 0 < skel_data_pos < materials_end <= reader.size():
            raw_skel_to_mtl = bytes(reader._data[skel_data_pos:materials_end])

        return YOBJModel(
            version=ver_label,
            bones=bones,
            materials=materials,
            meshes=meshes,
            textures=textures,
            texture_header=tex_header,
            morph_names=morph_names,
            global_bone_palette=global_palette,
            magic=bytes(hdr['magic']),
            version_field=hdr.get('version', 3),
            is_big_endian=hdr.get('is_big_endian', True),
            raw_header=hdr.get('raw_header', b''),
            raw_trailer=raw_trailer,
            raw_trailer_orig_start=trailer_orig_start,
            raw_skel_to_mtl_bytes=raw_skel_to_mtl,
            raw_preblock_bytes=raw_preblock,
        )
