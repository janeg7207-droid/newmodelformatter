"""
Data structures for YOBJ format.

All numeric arrays use NumPy. Fields that the format carries but which
are not yet semantically interpreted (e.g. material extras) are preserved
as opaque tuples so round-trip export can write them back unchanged.
"""

from dataclasses import dataclass, field
from typing import Optional
import numpy as np


@dataclass
class Bone:
    """Skeleton bone data.

    `tail` is the 4-float field at byte +64 of the on-disk bone record.
    It looks like a bind-pose tail position (`J_Hips` shows sensible
    head/tail values). We preserve it verbatim so we can render the
    armature with proper bone lengths and round-trip cleanly.
    """
    name: str
    index: int
    parent_index: int
    position: np.ndarray
    rotation: np.ndarray
    tail: Optional[np.ndarray] = None


@dataclass
class Material:
    """Material reference + opaque format extras.

    `extras` is the raw 4-uint32 tail of the on-disk material record:
        (morph_count, ?, texture_index_or_count, ?)
    Preserved byte-for-byte to support round-trip export.
    """
    name: str
    index: int
    extras: tuple = (0, 0, 0, 0)


@dataclass
class MorphTarget:
    """Blend shape / morph target data."""
    name: str
    positions: np.ndarray
    normals: Optional[np.ndarray] = None

    # Verbatim 28-byte/vertex frame bytes (pos 12 + normal 12 + tail 4)
    # captured from the source file. A morph frame carries a per-vertex tail
    # the decoded positions/normals don't preserve, and some frames store
    # zero-filled normals the re-encode can't reproduce — splice these back
    # for byte-exact round-trip. Empty for edited/new morphs (then the
    # exporter re-encodes from positions/normals).
    raw_frame_bytes: bytes = b''


@dataclass
class Mesh:
    """Mesh geometry and attributes."""
    index: int
    name: str
    shader_type: str
    material_index: int

    # Geometry
    positions: np.ndarray
    normals: np.ndarray
    uvs: np.ndarray
    faces: np.ndarray

    # Optional / additional attributes
    vertex_tail: Optional[np.ndarray] = None    # uint8[n, 4] — opaque trailing 4 bytes per vertex
    colors: Optional[np.ndarray] = None         # float32[n, 4] — RGBA derived from vertex_tail (if applied)
    uvs2: Optional[np.ndarray] = None
    morph_targets: list = field(default_factory=list)

    # Skinning
    bone_indices: Optional[np.ndarray] = None
    bone_weights: Optional[np.ndarray] = None
    bone_palette: Optional[np.ndarray] = None
    max_influences: int = 0

    # Round-trip fields (preserved verbatim for export)
    bbox_pivot: tuple = (0.0, 0.0, 0.0, 0.0)
    inline_palette_full: tuple = ()             # all 20 slots (preserves 0xFFFFFFFF padding)
    face_sec: int = 1                            # source file's face_section count (v0 may be >1)

    # Raw bytes of the ENTIRE vertex block: frame-offset table + frame0 +
    # all morph frames + any shader-specific trailing data (e.g. hair meshes
    # carry a large extra geometry stream after frame0, and version-7 meshes
    # carry extra per-vertex data). Re-encoding only reproduces frame0 plus the
    # decoded morph frames and silently drops everything else. Captured to the
    # next block's data position (tight-pack extent) and spliced back verbatim
    # for byte-exact round-trip; the internal FOT offsets stay valid because
    # the block lands at its original file position. Empty for edited/new
    # meshes (then the exporter re-encodes frame0 + morphs from decoded data).
    raw_vertex_bytes: bytes = b''

    # Raw on-disk mesh-header bytes (180 for v0, 184 for v3). Exporter starts
    # from these and patches only the fields whose values change (offsets and
    # counts). Preserves shader_param_count/off, face_count_field, and any
    # other game-critical fields whose meaning we don't decode but the engine
    # validates. Empty signals from-scratch authoring.
    raw_header: bytes = b''

    # Raw bytes of the shader-parameter block (lives at shader_param_off+8 in
    # the source file and runs until the next data block). Contains shader-
    # param name records plus POF0-encoded sub-data the engine derefs during
    # shader setup. We don't decode the contents; we copy them verbatim and
    # rewrite shader_param_off to point at the new location. Empty when the
    # mesh has no shader-param block (or none was captured).
    raw_shader_param_bytes: bytes = b''

    # Raw bytes of the weight block (vc × max_inf × 8 bytes plus 8 leading
    # pad). Captured to preserve the 0xFFFFFFFF padding sentinel and exact
    # float bit-patterns that the parser would otherwise normalise. Without
    # this, the engine can read bone-0 with zero weight (instead of the
    # "skip this slot" sentinel) and walk an invalid bone chain → crash.
    raw_weight_bytes: bytes = b''

    # Raw bytes of the face block (header + strip indices). Captured to
    # preserve the original stripification — a re-stripify pass produces
    # equivalent triangles but a different on-disk size, which shifts every
    # subsequent block in the file. Internal data_off field(s) inside this
    # block are patched at write time to reflect the new file location.
    raw_face_bytes: bytes = b''

    # Raw bytes of the standalone normal block (v3). The on-disk block is
    # frequently ALL ZEROS — the engine reads the interleaved vertex normals,
    # not this block — so re-encoding real normals here writes non-zero bytes
    # where the file had zeros and breaks byte-exact round-trip. Captured
    # verbatim (content + tight-pack trailing 8 bytes) and spliced back
    # unchanged. Empty when the mesh has no normal block or was authored
    # outside the source file (then the exporter re-encodes from .normals).
    raw_normal_bytes: bytes = b''

    # Raw bytes of the UV block (1 layer = 8 B/v, hair = 16 B/v). Captured
    # verbatim because the `1.0 - v` flip re-encode rounds some f32 mantissa
    # LSBs differently than the original encoder (off-by-one bytes). Spliced
    # back unchanged for round-trip; re-encoded only for edited/new meshes.
    raw_uv_bytes: bytes = b''


@dataclass
class YOBJModel:
    """Complete YOBJ model data."""
    version: str
    bones: list
    materials: list
    meshes: list

    # Round-trip fields
    textures: list = field(default_factory=list)
    texture_header: tuple = (0.0, 0.0)
    morph_names: list = field(default_factory=list)
    global_bone_palette: Optional[np.ndarray] = None

    # Format identification (set by parser; used by exporter to round-trip
    # back to the same byte-level format the file came from).
    magic: bytes = b'JBOY'
    version_field: int = 3                      # 0 = SVR-era, 3 = 2K15-19
    is_big_endian: bool = True

    # Raw on-disk file header — when present, the exporter starts from these
    # bytes and only patches the fields whose values change (offsets, counts).
    # All "unknown" fields the game may rely on are preserved verbatim. Empty
    # bytes signals a from-scratch authoring path with no source file.
    raw_header: bytes = b''

    # Raw bytes of everything between materials_end and file_end. Every Yukes
    # sample seen so far has a trailer here — for v0 it's a POF0-encoded
    # global shader block the engine derefs at draw time; for v3 it's the
    # morph-name table, global bone palette, and additional POF0 sub-data.
    # The engine knows to read bytes past the +0x04 size field; if we drop
    # this region the game loses shader/skinning data and crashes.
    raw_trailer: bytes = b''
    # Original mtl_data_end position, captured so the exporter can compute
    # the byte shift between original and re-laid-out trailer locations.
    raw_trailer_orig_start: int = 0

    # Raw bytes of the skeleton + texture + material region, [skel_data_pos ..
    # materials_end], captured as one verbatim blob. Re-encoding bones from
    # decoded fields loses exact float bits (bone matrices, the bone-tail /
    # texture-header 8-byte overlap), all of which the engine validates.
    # Spliced back as a unit for byte-exact round-trip, with the three header
    # offsets (skel/tex/mtl) patched by however far the region shifted. Empty
    # signals from-scratch authoring (the exporter re-encodes each block).
    raw_skel_to_mtl_bytes: bytes = b''

    # Raw bytes of any unreferenced positional block between the mesh-table end
    # and the first per-mesh block. A few models carry a structure here
    # (bone-palette-style 0xFFFFFFFF padding + offsets + bbox) that no header
    # offset points at — the engine finds it by position. The writer must
    # splice it back verbatim or every later block shifts. Empty when the
    # per-mesh blocks pack tight against the mesh table (the common case).
    raw_preblock_bytes: bytes = b''


# Backwards-compat name (some old code might import this — keep it as an alias)
@dataclass
class YOBJHeader:
    """Parsed YOBJ header."""
    magic: bytes
    is_big_endian: bool
    object_count: int
    bone_count: int
    material_count: int
    header_offset: int
    skeleton_offset: int
    texture_offset: int
    material_offset: int
    bone_palette_offset: int
    morph_name_offset: int = 0
