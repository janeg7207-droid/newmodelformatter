"""
YOBJ Importer - Main entry point for importing YOBJ files.
"""

import os
import time
from typing import Optional

from .parser import parse_yobj, YOBJParseError
from .builder import build_model


def import_yobj(
    filepath: str,
    import_skeleton: bool = True,
    import_weights: bool = True,
    import_morphs: bool = True,
    import_vertex_colors: bool = True,
    flip_uvs: bool = True,
    alternate_uv_stride: bool = False,
) -> bool:
    """
    Import YOBJ file into Blender.
    
    Args:
        filepath: Path to .yobj or .jboy file
        import_skeleton: Import armature with bones
        import_weights: Import vertex weights
        import_morphs: Import morph targets (shape keys)
        import_vertex_colors: Import vertex color data
        flip_uvs: Flip V coordinate
        alternate_uv_stride: Use 16-byte UV stride (for hair)
        
    Returns:
        True if import succeeded
    """
    start_time = time.time()
    
    # Get filename for naming
    filename = os.path.splitext(os.path.basename(filepath))[0]
    
    print(f"[YOBJ] Importing: {filepath}")
    
    try:
        # Parse YOBJ file
        parse_start = time.time()
        model = parse_yobj(
            filepath,
            flip_uvs=flip_uvs,
            alternate_uv_stride=alternate_uv_stride,
            import_morphs=import_morphs,
        )
        parse_time = time.time() - parse_start
        
        print(f"[YOBJ] Parsed in {parse_time:.3f}s")
        print(f"[YOBJ] Version: {model.version}")
        print(f"[YOBJ] Meshes: {len(model.meshes)}")
        print(f"[YOBJ] Bones: {len(model.bones)}")
        print(f"[YOBJ] Materials: {len(model.materials)}")
        
        # Count total vertices, faces, and morph targets
        total_verts = sum(m.positions.shape[0] for m in model.meshes)
        total_faces = sum(m.faces.shape[0] for m in model.meshes)
        total_morphs = sum(len(m.morph_targets) for m in model.meshes)
        print(f"[YOBJ] Total vertices: {total_verts}")
        print(f"[YOBJ] Total faces: {total_faces}")
        if total_morphs > 0:
            print(f"[YOBJ] Total morph targets: {total_morphs}")
        
        # Build Blender objects
        build_start = time.time()
        success = build_model(
            model,
            filename,
            import_skeleton=import_skeleton,
            import_weights=import_weights,
            import_morphs=import_morphs,
            import_vertex_colors=import_vertex_colors,
        )
        build_time = time.time() - build_start
        
        print(f"[YOBJ] Built in {build_time:.3f}s")
        
        total_time = time.time() - start_time
        print(f"[YOBJ] Total import time: {total_time:.3f}s")
        
        return success
        
    except YOBJParseError as e:
        print(f"[YOBJ] Parse error: {e}")
        return False
    except Exception as e:
        print(f"[YOBJ] Import error: {e}")
        import traceback
        traceback.print_exc()
        return False
