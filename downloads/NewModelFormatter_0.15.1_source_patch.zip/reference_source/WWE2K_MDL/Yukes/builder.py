"""
Blender mesh builder - Creates Blender objects from parsed YOBJ data.
Uses efficient Blender APIs (direct data access instead of bpy.ops).
"""

import bpy
import bmesh
import numpy as np
from mathutils import Vector, Matrix, Euler
import math
from typing import List, Optional, Dict

from .structures import YOBJModel, Mesh, Bone, MorphTarget
from ..Link.log import dwarn


def _is_skeleton_bone(name: str) -> bool:
    """Determine if a bone entry is a real skeleton bone vs a mesh marker/control point.

    Real skeleton bones use prefixes like J_ (joint) and H_ (helper/twist).
    Mesh markers follow patterns like m000_0000, m001_0100, etc. — these are
    facial rig control points or morph blend positions and should NOT be
    included in the armature. The unnamed root entry "vector" is also
    excluded; it's an internal anchor that holds no skinning weights.
    """
    if not name:
        return False

    # Known skeleton bone prefixes
    if name.startswith(('J_', 'H_', 'j_', 'h_')):
        return True

    # Mesh marker pattern: 'm' or 'M' followed by digits then underscore
    if len(name) >= 4 and name[0] in ('m', 'M') and name[1:4].isdigit():
        return False

    # Internal root anchor bone — excluded so the armature doesn't get a phantom root
    if name.lower() == 'vector':
        return False

    # Default: include unknown prefixes as skeleton bones (safer for older formats)
    return True


def build_armature(
    model: YOBJModel,
    name: str,
) -> Optional[bpy.types.Object]:
    """
    Build armature from bone data.
    
    Computes world-space bone matrices from the hierarchy, converts from
    game Y-up coordinate system to Blender Z-up, and sets bone transforms
    directly. No object-level rotation is used — the coordinate conversion
    is baked into the bone data so animations apply correctly.
    
    Mesh marker entries (m000_XXXX pattern) are excluded from the armature
    but kept in the model bone list for weight index stability.
    
    Args:
        model: Parsed YOBJ model
        name: Name for the armature object
        
    Returns:
        Armature object or None if no bones
    """
    if not model.bones:
        return None
    
    # Build the armature from EVERY named bone. WWE 2K15-19 skeletons drive
    # deformation with TWO bone sets: the J_/H_ FK joints AND a large set of
    # parentless 'm###' deform bones (shoes, outfit layers, facial markers)
    # that the .yanm keys DIRECTLY. An earlier assumption that the m### bones
    # were only facial-morph markers filtered them out of the armature — but
    # shoes/outfit/body-layer meshes skin to them at 47-100%, so those vertex
    # groups had no bone to drive them and those parts stayed frozen during
    # animation. Keeping every named bone lets the animation plugin find them
    # by name-hash and key them; unkeyed markers simply rest at bind pose.
    skeleton_indices = set()
    marker_count = 0
    for bone_data in model.bones:
        if not bone_data.name:
            continue
        skeleton_indices.add(bone_data.index)
        if not _is_skeleton_bone(bone_data.name):
            marker_count += 1

    if marker_count > 0:
        print(f"[Yukes] Armature includes {len(skeleton_indices)} bones "
              f"({marker_count} deform/marker bones the animation may key directly)")
    
    if not skeleton_indices:
        return None
    
    # Coordinate conversion matrix: Game Y-up → Blender Z-up
    # Mapping: (x, y, z) → (x, z, -y)  [det=+1, proper rotation]
    GAME_TO_BLENDER = Matrix((
        ( 1,  0,  0, 0),
        ( 0,  0,  1, 0),
        ( 0, -1,  0, 0),
        ( 0,  0,  0, 1),
    ))
    GAME_TO_BLENDER_INV = GAME_TO_BLENDER.inverted()
    
    # --- Step 1: Build local matrices and compute world matrices ---
    local_matrices = {}
    world_matrices = {}
    
    for bone_data in model.bones:
        pos = bone_data.position
        rot = bone_data.rotation
        
        # Build local transform: Translation @ Rotation
        local_mat = (
            Matrix.Translation(pos) @
            Euler(rot, 'XYZ').to_matrix().to_4x4()
        )
        local_matrices[bone_data.index] = local_mat
    
    # Compute world matrices by walking the hierarchy
    # world = parent_world @ local
    # `_in_progress` tracks bones currently being resolved so that a
    # cycle (e.g. a malformed file where bone X's parent chain loops
    # back to X) breaks rather than recursing forever. Without this a
    # bad file can blow Blender's stack instead of importing as a flat
    # rig — we'd rather lose hierarchy than fail to load.
    _in_progress = set()
    def compute_world(bone_idx):
        if bone_idx in world_matrices:
            return world_matrices[bone_idx]
        if bone_idx in _in_progress:
            # Cycle detected — treat this bone as if it had no parent.
            print(f"[Yukes] Bone hierarchy cycle at index {bone_idx} ({model.bones[bone_idx].name!r}); "
                  f"breaking and treating as root.")
            return local_matrices[bone_idx].copy()
        _in_progress.add(bone_idx)

        bone_data = model.bones[bone_idx]
        local = local_matrices[bone_idx]

        if (bone_data.parent_index >= 0
                and bone_data.parent_index < len(model.bones)
                and bone_data.parent_index != bone_idx):
            parent_world = compute_world(bone_data.parent_index)
            world = parent_world @ local
        else:
            world = local.copy()

        world_matrices[bone_idx] = world
        _in_progress.discard(bone_idx)
        return world
    
    for bone_data in model.bones:
        compute_world(bone_data.index)

    # NOTE: world_matrices are kept in RAW GAME space. We no longer bake the
    # Y-up->Z-up conversion into them — each bone is placed via ebone.matrix =
    # world_matrices[idx] (game bind frame) and the flip is the armature
    # object's -90deg X rotation, so bone.matrix_local stays in the frame the
    # animation keys target. (GAME_TO_BLENDER above is now unused but kept for
    # reference.)

    # --- Step 2: Create armature ---
    armature_data = bpy.data.armatures.new("Armature")
    armature_obj = bpy.data.objects.new("Skeleton", armature_data)
    
    bpy.context.collection.objects.link(armature_obj)
    bpy.context.view_layer.objects.active = armature_obj
    # Y-up (game) -> Z-up (Blender) flip applied ONCE at the object level so the
    # bones' matrix_local stays in game space for the animation keys. Meshes
    # parent to this armature and inherit the rotation (matches the 2K26 path).
    armature_obj.rotation_euler[0] = math.radians(-90)
    
    # Enter edit mode to create bones
    bpy.ops.object.mode_set(mode='EDIT')
    edit_bones = armature_data.edit_bones
    bone_map: Dict[int, bpy.types.EditBone] = {}
    
    # Create all edit bones — skeleton bones only
    for bone_data in model.bones:
        if bone_data.index not in skeleton_indices:
            continue
        
        ebone = edit_bones.new(bone_data.name)
        
        # Place the bone using its FULL game-space world bind matrix (head +
        # orientation + roll), exactly like the modern 2K26 importer
        # (blender_skeleton.createRigJoint). The animation plugin applies its
        # game-space euler/translation keys relative to bone.matrix_local, so
        # matrix_local MUST be the raw game bind frame — NOT a coordinate-
        # converted one. The Y-up->Z-up flip is the armature OBJECT's -90deg X
        # rotation (set after this loop); Rx(-90) equals the old per-bone
        # (x,z,-y) bake but applied once at the object level so the bone-local
        # frame the animation keys target stays in game space.
        ebone.tail = Vector((0.0, 1.0, 0.0))   # temp length so .matrix can orient
        ebone.matrix = world_matrices[bone_data.index]
        if ebone.length < 1e-8:
            ebone.length = ebone.length + 0.0001
        
        # Store custom properties
        ebone["prop_id"] = bone_data.index
        ebone["prop_childCount"] = 0

        # Stash the raw on-disk values so the export path can write them
        # back verbatim. The file format stores bone position/rotation as
        # parent-relative in the game's coordinate system; the builder
        # accumulates these through `parent_world @ local` to place the
        # bone in armature space. Reversing that on export (taking
        # `head_local` and decomposing back to local-relative game-space)
        # is fragile, especially after coordinate-system conversion. The
        # robust answer is the same one we already use for `tail`: keep
        # the original bytes and re-emit them, only falling back to
        # computed values when the user has actually edited the bone.
        ebone["yobj_pos"] = [float(v) for v in bone_data.position[:3]]
        ebone["yobj_rot"] = [float(v) for v in bone_data.rotation[:3]]
        if bone_data.tail is not None and len(bone_data.tail) >= 4:
            ebone["yobj_tail"] = [float(v) for v in bone_data.tail[:4]]

        bone_map[bone_data.index] = ebone
    
    # Set parents (only between skeleton bones)
    for bone_data in model.bones:
        if bone_data.index not in skeleton_indices:
            continue
        if bone_data.parent_index >= 0 and bone_data.parent_index in bone_map:
            ebone = bone_map[bone_data.index]
            parent_ebone = bone_map[bone_data.parent_index]
            ebone.parent = parent_ebone
            parent_ebone["prop_childCount"] = parent_ebone.get("prop_childCount", 0) + 1
    
    # NOTE: deliberately NO tail refinement. Each bone's orientation was set via
    # `ebone.matrix = <game world bind>` above. Overwriting the tail to point at
    # children would re-derive a DIFFERENT rest orientation and change
    # bone.matrix_local — which the animation plugin reads to frame its keys
    # (rotation is rest-invariant, but the translation path uses
    # bone.matrix.inverted() @ world_pos, so the rest orientation must stay the
    # game bind frame). The modern 2K26 importer likewise leaves the
    # matrix-derived tail alone. Bones display as uniform ~1.0-length stubs
    # along their local axis — cosmetic only; deformation and animation use
    # matrix_local, not the visible tail direction.

    # Return to object mode
    bpy.ops.object.mode_set(mode='OBJECT')

    # Stash format hints on the armature for round-trip export so the user
    # can re-export to the exact same on-disk format (magic, endianness,
    # version) without re-specifying anything.
    #
    # We keep this paranoid because Blender's IDProperty system across
    # versions has quirks around long lists, signed-int overflows, and list
    # types (particularly lists of strings). A failure here must NEVER block
    # the import — the data is a nice-to-have for round-trip auto-detect,
    # not load-bearing for the imported scene.
    try:
        armature_obj['yobj_magic'] = bytes(model.magic).decode('ascii', errors='replace')
    except Exception as e:
        print(f"[Yukes] Could not stash yobj_magic: {e}")
    try:
        armature_obj['yobj_version'] = int(model.version_field)
        armature_obj['yobj_big_endian'] = 1 if model.is_big_endian else 0
    except Exception as e:
        print(f"[Yukes] Could not stash yobj_version/endian: {e}")
    # Store textures as a single newline-separated string rather than a list —
    # IDProperty arrays of strings are unreliable across Blender versions.
    if model.textures:
        try:
            armature_obj['yobj_textures'] = '\n'.join(str(t) for t in model.textures)
        except Exception as e:
            print(f"[Yukes] Could not stash yobj_textures: {e}")

    # Critical for round-trip game compatibility: stash the entire on-disk
    # file header (0x48 v0 / 0x58 v3) verbatim. Without it the Blender
    # export path can't preserve unknown game-critical header fields.
    if model.raw_header:
        try:
            armature_obj['yobj_raw_file_header'] = bytes(model.raw_header)
        except Exception as e:
            print(f"[Yukes] Could not stash raw file header: {e}")
    # File trailer (post-materials POF0 block / morph-name table / palette).
    if model.raw_trailer:
        try:
            armature_obj['yobj_raw_trailer'] = bytes(model.raw_trailer)
            armature_obj['yobj_trailer_orig_start'] = int(model.raw_trailer_orig_start)
        except Exception as e:
            print(f"[Yukes] Could not stash raw trailer: {e}")
    # Verbatim skeleton→material region. Feeding this back makes the writer take
    # its byte-exact skel-splice branch (no redundant 8-byte pad) instead of the
    # from-scratch branch that re-adds the pad and shifts the whole trailer +8.
    if getattr(model, 'raw_skel_to_mtl_bytes', b''):
        try:
            armature_obj['yobj_raw_skel_mtl'] = bytes(model.raw_skel_to_mtl_bytes)
        except Exception as e:
            print(f"[Yukes] Could not stash raw skel→mtl: {e}")
    # Texture block header (2 floats — usually scale/range).
    try:
        armature_obj['yobj_tex_header'] = list(float(x) for x in model.texture_header)
    except Exception as e:
        print(f"[Yukes] Could not stash tex_header: {e}")
    # Morph-name list (v3 only).
    if model.morph_names:
        try:
            armature_obj['yobj_morph_names'] = '\n'.join(str(n) for n in model.morph_names)
        except Exception as e:
            print(f"[Yukes] Could not stash morph_names: {e}")
    # Global bone palette (v3 only).
    if model.global_bone_palette is not None and len(model.global_bone_palette) > 0:
        try:
            import struct as _struct
            pal = [int(x) & 0xFFFFFFFF for x in model.global_bone_palette]
            armature_obj['yobj_global_palette'] = _struct.pack(f'<{len(pal)}I', *pal)
        except Exception as e:
            print(f"[Yukes] Could not stash global_palette: {e}")

    return armature_obj


def _build_material(yobj_mat, model: YOBJModel) -> bpy.types.Material:
    """Build (or fetch existing) Blender Material for a YOBJ material entry.

    Creates a Principled BSDF node graph and tags the material with custom
    properties for round-trip export (extras tuple, raw texture name list).
    The material's primary texture name is taken from extras[2] when it
    looks valid, falling back to a name-similarity guess.
    """
    name = yobj_mat.name or f"Material_{yobj_mat.index}"
    if name in bpy.data.materials:
        return bpy.data.materials[name]

    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nt = mat.node_tree
    for node in list(nt.nodes):
        nt.nodes.remove(node)

    out = nt.nodes.new(type='ShaderNodeOutputMaterial')
    out.location = (400, 0)
    bsdf = nt.nodes.new(type='ShaderNodeBsdfPrincipled')
    bsdf.location = (100, 0)
    nt.links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])

    # Determine candidate textures: the index in extras[2] if in range,
    # otherwise scan textures for a name resembling the material.
    primary_tex = None
    if model.textures:
        if 0 <= yobj_mat.extras[2] < len(model.textures):
            cand = model.textures[yobj_mat.extras[2]]
            if cand:
                primary_tex = cand
        if primary_tex is None:
            stem = name[2:] if name.startswith('M_') else name
            stem_l = stem.lower()
            for t in model.textures:
                if t and t.lower() == stem_l:
                    primary_tex = t
                    break

    if primary_tex:
        tex = nt.nodes.new(type='ShaderNodeTexImage')
        tex.location = (-200, 100)
        tex.label = primary_tex
        # Create a placeholder Image so Blender shows the slot — the user can
        # repoint it to the real file.
        img = bpy.data.images.get(primary_tex)
        if img is None:
            img = bpy.data.images.new(primary_tex, width=2, height=2, alpha=True)
            img.source = 'FILE'
            img.filepath = ""  # unresolved — user fills in
        tex.image = img
        nt.links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])

    # Stash format metadata for round-trip
    mat["yobj_extras"] = list(yobj_mat.extras)
    mat["yobj_index"] = yobj_mat.index
    if primary_tex:
        mat["yobj_primary_texture"] = primary_tex
    return mat


def build_mesh(
    mesh_data: Mesh,
    model: YOBJModel,
    armature: Optional[bpy.types.Object],
    import_weights: bool = True,
    import_morphs: bool = True,
    import_vertex_colors: bool = True,
) -> bpy.types.Object:
    """
    Build Blender mesh from parsed mesh data using efficient APIs.
    
    Applies coordinate conversion from game Y-up to Blender Z-up
    to match the armature bone positions (which are also converted).
    
    Args:
        mesh_data: Parsed mesh data
        model: Full model for material/bone references
        armature: Armature object for skinning
        import_weights: Import vertex weights
        import_morphs: Import shape keys
        import_vertex_colors: Import vertex colors
        
    Returns:
        Mesh object
    """
    # Get material name
    mat_name = "Material"
    if mesh_data.material_index < len(model.materials):
        mat_name = model.materials[mesh_data.material_index].name
    
    # Create mesh data
    bl_mesh = bpy.data.meshes.new(mat_name)
    
    # Vertices and normals stay in RAW GAME space. The Y-up->Z-up flip is the
    # armature object's -90deg X rotation, inherited by this mesh through
    # parenting (set below) — matches the modern 2K26 path. Baking the
    # conversion into the verts here would double-rotate once parented to the
    # rotated armature AND, more importantly, put the geometry in a different
    # frame than the game-space animation skinning expects.
    verts = mesh_data.positions.tolist()
    faces = mesh_data.faces.tolist()

    # Create mesh geometry
    bl_mesh.from_pydata(verts, [], faces)

    # Set up custom normals (raw game space, same frame as the verts)
    _apply_custom_normals(bl_mesh, mesh_data.normals)
    
    # Create object
    obj = bpy.data.objects.new(mesh_data.name, bl_mesh)
    bpy.context.collection.objects.link(obj)

    # Assign Blender Material (and its texture metadata) — was previously skipped
    if 0 <= mesh_data.material_index < len(model.materials):
        bl_mat = _build_material(model.materials[mesh_data.material_index], model)
        if bl_mesh.materials:
            bl_mesh.materials[0] = bl_mat
        else:
            bl_mesh.materials.append(bl_mat)

    # Parent to armature so the mesh inherits its -90deg X (Y-up->Z-up) rotation
    # and deforms in the same game-space frame as the bones. The API parent
    # assignment leaves matrix_parent_inverse at identity, so the rotation IS
    # inherited. A mesh with no armature is flipped at its own object level.
    if armature:
        obj.parent = armature
    else:
        obj.rotation_euler[0] = math.radians(-90)
    
    # Apply UVs efficiently using foreach_set
    _apply_uvs(bl_mesh, mesh_data.uvs, "UVMap")
    
    # Apply second UV layer if present (hair meshes)
    if mesh_data.uvs2 is not None:
        _apply_uvs(bl_mesh, mesh_data.uvs2, "UVMap2")
    
    # Apply vertex colors
    if import_vertex_colors and mesh_data.colors is not None:
        _apply_vertex_colors(bl_mesh, mesh_data.colors)
    
    # Apply shape keys (morph targets) — raw game space now (no coordinate
    # conversion; the object-level -90deg X rotation handles the up-axis, same
    # as the base mesh verts).
    if import_morphs and mesh_data.morph_targets:
        _apply_shape_keys(obj, mesh_data, convert_coords=False)
    
    # Apply vertex weights
    if import_weights and armature and mesh_data.bone_weights is not None:
        _apply_vertex_weights_with_mapping(obj, mesh_data, model, armature)
        
        # Add armature modifier
        mod = obj.modifiers.new(name="Armature", type='ARMATURE')
        mod.object = armature
    
    # Store custom properties
    obj["prop_id"] = mesh_data.index
    obj["shader_type"] = mesh_data.shader_type
    # Mark that this mesh's vertex data is in RAW GAME space (up-axis handled by
    # the armature object's -90deg X rotation, inherited via parenting). The
    # exporter reads this flag to know it must NOT re-invert a coordinate
    # conversion that no longer exists. Absent on legacy (pre-this-version)
    # imports, which baked game->Blender into the verts.
    obj["yobj_gamespace"] = True

    # Round-trip metadata. Encoded as bytes/strings rather than int arrays to
    # sidestep Blender IDProperty quirks (signed-int overflow on uint32
    # sentinels, slow long arrays, version differences in list-of-int handling).
    # Each write is wrapped so a Blender quirk can't hang or kill the import.
    if mesh_data.bbox_pivot:
        try:
            obj['yobj_bbox_pivot'] = list(float(x) for x in mesh_data.bbox_pivot)
        except Exception as e:
            print(f"[Yukes] {obj.name}: could not stash bbox_pivot: {e}")

    if mesh_data.inline_palette_full:
        try:
            # Pack the 20 uint32 slots as little-endian bytes — bytes
            # IDProperties are stable across all Blender versions and avoid
            # the 0xFFFFFFFF-as-signed-int problem entirely.
            import struct as _struct
            slots = [int(x) & 0xFFFFFFFF for x in mesh_data.inline_palette_full]
            # Pad/trim to exactly 20 slots
            while len(slots) < 20:
                slots.append(0xFFFFFFFF)
            obj['yobj_inline_palette'] = _struct.pack('<20I', *slots[:20])
        except Exception as e:
            print(f"[Yukes] {obj.name}: could not stash inline_palette: {e}")

    if 0 <= mesh_data.material_index < len(model.materials):
        mat_extras = model.materials[mesh_data.material_index].extras
        if mat_extras:
            try:
                import struct as _struct
                ex = [int(x) & 0xFFFFFFFF for x in mat_extras]
                while len(ex) < 4:
                    ex.append(0)
                obj['yobj_material_extras'] = _struct.pack('<4I', *ex[:4])
            except Exception as e:
                print(f"[Yukes] {obj.name}: could not stash material_extras: {e}")

    # Critical for round-trip game compatibility: stash the entire on-disk
    # mesh-header bytes and the shader-parameter block bytes. Without these,
    # the Blender export path builds a fresh Mesh from scene data and loses
    # all the unknown game-critical fields the original file carried.
    # Both are bytes IDProperties — the most robust IDProperty type.
    if mesh_data.raw_header:
        try:
            obj['yobj_raw_mesh_header'] = bytes(mesh_data.raw_header)
        except Exception as e:
            print(f"[Yukes] {obj.name}: could not stash raw mesh header: {e}")
    if mesh_data.raw_shader_param_bytes:
        try:
            obj['yobj_raw_shader_params'] = bytes(mesh_data.raw_shader_param_bytes)
        except Exception as e:
            print(f"[Yukes] {obj.name}: could not stash sp bytes: {e}")
    # Raw weight-block bytes (incl. 8-byte leading pad). Preserves the
    # 0xFFFFFFFF padding sentinel and original float bit-patterns the
    # parser otherwise normalises — both game-critical for skinning.
    if mesh_data.raw_weight_bytes:
        try:
            obj['yobj_raw_weight'] = bytes(mesh_data.raw_weight_bytes)
        except Exception as e:
            print(f"[Yukes] {obj.name}: could not stash weight bytes: {e}")
    # Raw face-block bytes (header + strip indices, no leading pad).
    # Preserves the original stripification — re-stripifying produces
    # equivalent triangles but a different on-disk size, which would
    # shift every later block in the file.
    if mesh_data.raw_face_bytes:
        try:
            obj['yobj_raw_face'] = bytes(mesh_data.raw_face_bytes)
        except Exception as e:
            print(f"[Yukes] {obj.name}: could not stash face bytes: {e}")
    # Per-vertex 4-byte tail (the trailing uint8[4] in the 28-byte vertex
    # record). Vanilla SVR-era files set this to 0xFFFFFFFF as a "no
    # per-vertex color" sentinel; some 2K-era files use real RGBA. The
    # parser only converts to a Blender color attribute when the bytes
    # vary across vertices (otherwise it's just padding), so for the
    # uniform-sentinel case we'd lose the values entirely on a
    # re-export. Stash them verbatim so the export path can splice
    # them back in regardless of what Blender did with vertex colors.
    if mesh_data.vertex_tail is not None and len(mesh_data.vertex_tail) > 0:
        try:
            obj['yobj_vertex_tail'] = bytes(mesh_data.vertex_tail.astype('uint8').tobytes())
        except Exception as e:
            print(f"[Yukes] {obj.name}: could not stash vertex_tail: {e}")
    # Per-vertex normals (game-space, native float32). The builder
    # applies the file's per-vertex normals as custom split normals,
    # but Blender's auto-computed `vert.normal` (which the exporter
    # reads back) is the average of adjacent face normals — that
    # doesn't match the file's normals for any vertex on a creased
    # edge or corner, even with no user edits. Round-trip ends up with
    # subtly different normals on ~10–20% of vertices. Stash them in
    # game-space so the export path can splice them back in verbatim,
    # skipping Blender's read + the coord conversion entirely.
    if mesh_data.normals is not None and len(mesh_data.normals) > 0:
        try:
            n = mesh_data.normals.astype('<f4', copy=False)
            obj['yobj_normals'] = bytes(n.tobytes())
        except Exception as e:
            print(f"[Yukes] {obj.name}: could not stash normals: {e}")
    # Per-mesh face section count (v0 may be > 1 in some files).
    obj['yobj_face_sec'] = int(mesh_data.face_sec or 1)

    # Raw vertex-position + UV blocks — game-critical for BYTE-EXACT round-trip.
    # The export path otherwise re-encodes positions/UVs from the Blender mesh,
    # drifting f32 LSBs through the coord conversion (vanilla round-trip differs
    # in ~85% of bytes without these, ~2% with them). Stash verbatim; the export
    # side splices them only when the geometry is unedited (hash gate below).
    if getattr(mesh_data, 'raw_vertex_bytes', b''):
        try:
            obj['yobj_raw_vertex'] = bytes(mesh_data.raw_vertex_bytes)
        except Exception as e:
            print(f"[Yukes] {obj.name}: could not stash raw_vertex: {e}")
    if getattr(mesh_data, 'raw_uv_bytes', b''):
        try:
            obj['yobj_raw_uv'] = bytes(mesh_data.raw_uv_bytes)
        except Exception as e:
            print(f"[Yukes] {obj.name}: could not stash raw_uv: {e}")
    if getattr(mesh_data, 'raw_normal_bytes', b''):
        try:
            obj['yobj_raw_normal'] = bytes(mesh_data.raw_normal_bytes)
        except Exception as e:
            print(f"[Yukes] {obj.name}: could not stash raw_normal: {e}")
    # Geometry hash of the imported Blender positions; the exporter recomputes it
    # and only splices the raw blocks when it matches (no edits). Edited/new
    # meshes fall through to a fresh re-encode.
    try:
        import hashlib as _hl
        _co = np.empty(len(obj.data.vertices) * 3, dtype=np.float32)
        obj.data.vertices.foreach_get('co', _co)
        obj['yobj_geom_hash'] = _hl.sha1(_co.tobytes()).hexdigest()[:16]
    except Exception:
        pass

    return obj


def _apply_custom_normals(bl_mesh: bpy.types.Mesh, normals: np.ndarray):
    """Apply custom split normals to mesh. Compatible with Blender 3.x, 4.x, and 5.x."""
    
    try:
        # Check Blender version
        is_blender_3x = bpy.app.version < (4, 1, 0)
        is_blender_5x = bpy.app.version >= (5, 0, 0)
        
        if is_blender_5x:
            # Blender 5.0+ - use shade_smooth method
            bl_mesh.shade_smooth()
        else:
            # Blender 3.x / 4.x - set smooth shading per polygon
            for poly in bl_mesh.polygons:
                poly.use_smooth = True
        
        if is_blender_3x:
            # Blender 3.x / 4.0 - requires use_auto_smooth and create_normals_split
            # Order matters!
            if hasattr(bl_mesh, 'use_auto_smooth'):
                bl_mesh.use_auto_smooth = True
            if hasattr(bl_mesh, 'create_normals_split'):
                bl_mesh.create_normals_split()
            
            # Use normals_split_custom_set_from_vertices for vertex normals
            vertex_normals = [normals[i].tolist() for i in range(len(normals))]
            bl_mesh.normals_split_custom_set_from_vertices(vertex_normals)
        else:
            # Blender 4.1+ / 5.x - build loop normals.
            # Vectorized via foreach_get('vertex_index') + numpy gather —
            # same pattern as perf.fast_set_tex_coords. The previous
            # Python-side `for loop in bl_mesh.loops` walk was the
            # slowest part of mesh assembly on character meshes (50k+
            # loops × per-element attribute access).
            n_loops = len(bl_mesh.loops)
            n_normals = len(normals)
            if n_loops == 0 or n_normals == 0:
                bl_mesh.normals_split_custom_set([])
            else:
                loop_vidx = np.empty(n_loops, dtype=np.int32)
                bl_mesh.loops.foreach_get('vertex_index', loop_vidx)

                # Build a padded normals table where any out-of-range slot
                # falls back to (0, 0, 1) — the same default the slow
                # path produced. Then gather by loop_vidx.
                normals_arr = np.asarray(normals, dtype=np.float32)
                if normals_arr.ndim == 1:
                    normals_arr = normals_arr.reshape(-1, 3)
                # Clamp indices into the array; the OOB rows will be
                # overwritten with (0, 0, 1) below to match slow-path
                # semantics rather than wrapping.
                safe_idx = np.clip(loop_vidx, 0, n_normals - 1)
                gathered = normals_arr[safe_idx]
                # Where the original index was OOB, force (0, 0, 1).
                oob_mask = (loop_vidx < 0) | (loop_vidx >= n_normals)
                if oob_mask.any():
                    gathered = gathered.copy()
                    gathered[oob_mask] = (0.0, 0.0, 1.0)
                bl_mesh.normals_split_custom_set(gathered.tolist())
        
        bl_mesh.update()
    except Exception as e:
        # If custom normals fail, just update the mesh without them
        print(f"[Yukes] Warning: Could not apply custom normals: {e}")
        bl_mesh.update()


def _apply_uvs(bl_mesh: bpy.types.Mesh, uvs: np.ndarray, layer_name: str = "UV_SINGLE"):
    """Apply UV coordinates efficiently — vectorized via foreach_get/foreach_set.

    For a typical 4K-vertex mesh with ~12K loops this is ~50× faster than
    iterating polys/loops in Python.
    """
    if len(uvs) == 0:
        return

    uv_layer = bl_mesh.uv_layers.new(name=layer_name)

    n_loops = len(bl_mesh.loops)
    if n_loops == 0:
        return

    # Get the vertex_index for every loop in one batch call
    loop_vidx = np.empty(n_loops, dtype=np.int32)
    bl_mesh.loops.foreach_get('vertex_index', loop_vidx)

    # Clamp out-of-range indices (shouldn't normally happen, but guards)
    safe_vidx = np.clip(loop_vidx, 0, len(uvs) - 1)

    # Gather UVs in loop order, flatten for foreach_set
    uv_data = uvs[safe_vidx].astype(np.float32, copy=False).ravel()
    uv_layer.data.foreach_set("uv", uv_data)


def _apply_vertex_colors(bl_mesh: bpy.types.Mesh, colors: np.ndarray):
    """Apply vertex colors efficiently — vectorized via foreach_get/foreach_set."""
    if len(colors) == 0:
        return

    n_loops = len(bl_mesh.loops)
    if n_loops == 0:
        return

    # Get vertex_index per loop in one batch call
    loop_vidx = np.empty(n_loops, dtype=np.int32)
    bl_mesh.loops.foreach_get('vertex_index', loop_vidx)
    safe_vidx = np.clip(loop_vidx, 0, len(colors) - 1)
    color_data = colors[safe_vidx].astype(np.float32, copy=False).ravel()

    if hasattr(bl_mesh, 'color_attributes'):
        color_layer = bl_mesh.color_attributes.new(
            name="Color",
            type='FLOAT_COLOR',
            domain='CORNER'
        )
        color_layer.data.foreach_set("color", color_data)
    else:
        # Legacy vertex colors for older Blender
        color_layer = bl_mesh.vertex_colors.new(name="Color")
        color_layer.data.foreach_set("color", color_data)


def _detect_morph_format(base_positions: np.ndarray, morph_positions: np.ndarray) -> bool:
    """
    Detect if morph data is stored as deltas or absolute positions.
    
    Returns:
        True if morph data appears to be deltas, False if absolute positions
    """
    if len(morph_positions) == 0 or len(base_positions) == 0:
        return False
    
    # Calculate average magnitude of base positions and morph positions
    base_magnitude = np.mean(np.abs(base_positions))
    morph_magnitude = np.mean(np.abs(morph_positions))
    
    # If morph values are much smaller than base (< 10% of base magnitude),
    # they're likely deltas
    if base_magnitude > 0.1:  # Avoid division issues with tiny meshes
        ratio = morph_magnitude / base_magnitude
        return ratio < 0.1  # Deltas are typically very small compared to base
    
    # Fallback: if morph values are all very small (< 1 unit avg), treat as deltas
    return morph_magnitude < 1.0


def _apply_shape_keys(obj: bpy.types.Object, mesh_data: Mesh, convert_coords: bool = False):
    """Apply morph targets as shape keys.

    Vectorized: each shape key's coordinate buffer is built with NumPy
    (delta-detect, optional coord conversion, padding) and uploaded with
    a single `foreach_set` call. ~30-100× faster than the per-vertex Python
    loop on character-sized meshes.
    """
    if not mesh_data.morph_targets:
        return

    # Create basis shape key
    sk_basis = obj.shape_key_add(name="Basis", from_mix=False)
    sk_basis.interpolation = 'KEY_LINEAR'
    obj.data.shape_keys.use_relative = True

    base_positions = mesh_data.positions

    # Detect format from first morph target
    is_delta_format = False
    if mesh_data.morph_targets:
        is_delta_format = _detect_morph_format(base_positions, mesh_data.morph_targets[0].positions)

    use_foreach = bpy.app.version >= (4, 0, 0)
    n_target = len(obj.data.vertices)

    for i, morph in enumerate(mesh_data.morph_targets):
        sk_name = morph.name if morph.name else f"Morph_{i}"
        sk = obj.shape_key_add(name=sk_name, from_mix=False)
        sk.interpolation = 'KEY_LINEAR'
        sk.value = 0.0

        # Build absolute positions in numpy
        coords = morph.positions.astype(np.float32, copy=False)
        if is_delta_format and len(base_positions):
            n = min(len(coords), len(base_positions))
            coords = coords[:n] + base_positions[:n].astype(np.float32, copy=False)

        # Optional coordinate conversion: (x, y, z) → (x, z, -y)
        if convert_coords and len(coords):
            converted = np.empty_like(coords)
            converted[:, 0] = coords[:, 0]
            converted[:, 1] = coords[:, 2]
            converted[:, 2] = -coords[:, 1]
            coords = converted

        # Pad/truncate to match shape key buffer size
        if len(coords) < n_target:
            padding = np.zeros((n_target - len(coords), 3), dtype=np.float32)
            coords = np.vstack([coords, padding])
        elif len(coords) > n_target:
            coords = coords[:n_target]

        flat = np.ascontiguousarray(coords).ravel()
        if use_foreach:
            sk.data.foreach_set("co", flat)
        else:
            for v_idx in range(n_target):
                sk.data[v_idx].co = (
                    float(coords[v_idx, 0]),
                    float(coords[v_idx, 1]),
                    float(coords[v_idx, 2]),
                )

    # Force update for Blender 5.0+
    obj.data.update()


def _apply_vertex_weights(
    obj: bpy.types.Object,
    mesh_data: Mesh,
    model: YOBJModel,
):
    """Apply vertex weights to vertex groups.
    
    Weight bone indices are PALETTE indices that must be remapped through
    the mesh's bone palette to get the actual skeleton bone index.
    Palette entries of 0xFFFFFFFF are treated as invalid/unused.
    """
    if mesh_data.bone_weights is None or mesh_data.bone_indices is None:
        return
    
    # Get bone palette for remapping (if available)
    bone_palette = mesh_data.bone_palette if mesh_data.bone_palette is not None else None
    
    # Create vertex groups for bones referenced in weight data
    bone_to_group: Dict[int, str] = {}
    referenced_bones = set()
    
    # Collect all referenced bone indices (remapped through palette)
    for v_idx in range(len(mesh_data.bone_indices)):
        for w_idx in range(mesh_data.max_influences):
            if mesh_data.bone_weights[v_idx, w_idx] > 0.0001:
                palette_idx = int(mesh_data.bone_indices[v_idx, w_idx])
                if palette_idx != 255 and palette_idx != 0xFFFFFFFF:
                    # Remap through bone palette if available
                    if bone_palette is not None and palette_idx < len(bone_palette):
                        actual_bone_idx = int(bone_palette[palette_idx])
                        # Skip invalid palette entries (0xFFFFFFFF padding)
                        if actual_bone_idx == 0xFFFFFFFF or actual_bone_idx < 0:
                            continue
                    else:
                        actual_bone_idx = palette_idx
                    referenced_bones.add(actual_bone_idx)
    
    for bone_idx in sorted(referenced_bones):
        if bone_idx < len(model.bones):
            bone_name = model.bones[bone_idx].name
            # Skip mesh marker bones (m000_XXXX) - no armature bone exists for them
            if not _is_skeleton_bone(bone_name):
                continue
            if bone_name not in obj.vertex_groups:
                obj.vertex_groups.new(name=bone_name)
            bone_to_group[bone_idx] = bone_name
    
    # Build weight data - group by vertex group for efficiency
    weight_data: Dict[str, List[tuple]] = {}
    
    for v_idx in range(len(mesh_data.bone_weights)):
        for w_idx in range(mesh_data.max_influences):
            weight = mesh_data.bone_weights[v_idx, w_idx]
            if weight > 0.0001:
                palette_idx = int(mesh_data.bone_indices[v_idx, w_idx])
                
                if palette_idx == 255 or palette_idx == 0xFFFFFFFF:
                    continue
                
                # Remap through bone palette if available
                if bone_palette is not None and palette_idx < len(bone_palette):
                    actual_bone_idx = int(bone_palette[palette_idx])
                    # Skip invalid palette entries (0xFFFFFFFF padding)
                    if actual_bone_idx == 0xFFFFFFFF or actual_bone_idx < 0:
                        continue
                else:
                    actual_bone_idx = palette_idx
                
                if actual_bone_idx in bone_to_group:
                    group_name = bone_to_group[actual_bone_idx]
                    if group_name not in weight_data:
                        weight_data[group_name] = []
                    weight_data[group_name].append((v_idx, weight))
    
    # Apply weights per group (much faster than per-vertex).
    #
    # CRASH FIX: vg.add([v_idx], weight, 'REPLACE') with an out-of-range
    # v_idx does NOT raise on Blender 3.x / early 4.x — it silently
    # corrupts adjacent memory. The mesh loads fine, then the depsgraph
    # evaluation a few seconds later walks into the corrupted region
    # and Blender crashes. On 5.x the same call raises IndexError.
    # Either way we must bound-check v_idx against the actual vertex
    # count before the call. (Mirrors blender_mesh.setVertexGroups.)
    num_verts = len(obj.data.vertices)
    total_skipped = 0
    for group_name, verts in weight_data.items():
        vg = obj.vertex_groups[group_name]
        for v_idx, weight in verts:
            if v_idx < 0 or v_idx >= num_verts:
                total_skipped += 1
                continue
            vg.add([v_idx], weight, 'REPLACE')
    if total_skipped:
        dwarn(f"[Yukes] vg.add: skipped {total_skipped} out-of-bounds "
              f"vertex indices for mesh '{obj.name}' (num_verts={num_verts})")


def _bone_world_positions(model: YOBJModel):
    """Game-space rest world position of every bone (cached on the model).

    world = parent_world @ (Translation(pos) @ Euler(rot,'XYZ')), matching the
    armature builder. Used to geometrically resolve the per-mesh palette offset.
    """
    cached = getattr(model, '_bwp_cache', None)
    if cached is not None:
        return cached
    bones = model.bones
    n = len(bones)
    if n == 0:
        return None
    local = [Matrix.Translation(b.position) @ Euler(b.rotation, 'XYZ').to_matrix().to_4x4()
             for b in bones]
    world: Dict[int, Matrix] = {}

    def cw(i, seen):
        if i in world:
            return world[i]
        if i in seen:
            world[i] = local[i].copy(); return world[i]
        seen.add(i)
        p = bones[i].parent_index
        world[i] = (cw(p, seen) @ local[i]) if (0 <= p < n and p != i) else local[i].copy()
        return world[i]

    for i in range(n):
        cw(i, set())
    arr = np.array([tuple(world[i].translation) for i in range(n)], dtype=np.float64)
    try:
        model._bwp_cache = arr
    except Exception:
        pass
    return arr


def _best_palette_offset(mesh_data: Mesh, model: YOBJModel, palette) -> int:
    """Recover a mesh's skin_bone_palette start offset by geometry.

    The skin's per-vertex bone indices are local to a slice of the global
    palette beginning at a per-part "Start boneSet" offset (verified against the
    game's hkSkinnedMeshShape + corpus: ~85% of meshes bind tightly at some
    offset; offsets cluster at 0 / 256). Picks the offset that binds each vertex
    to its NEAREST bone, but only OVERRIDES 0 when that offset more than halves
    the bind AND lands it tight (<20) — so meshes that are already correct at
    offset 0 are never disturbed, and the few multi-part meshes simply keep 0.
    """
    if palette is None or len(palette) == 0:
        return 0
    bi, bw = mesh_data.bone_indices, mesh_data.bone_weights
    if bi is None or bw is None or bi.size == 0:
        return 0
    bpos = _bone_world_positions(model)
    if bpos is None:
        return 0
    n_bones = len(bpos)
    pal = np.asarray(palette, dtype=np.int64)
    L = len(pal)
    valid = (bw > 0.0001) & (bi != 0xFFFFFFFF)
    if not valid.any():
        return 0
    # dominant (max-weight) local bone index per vertex
    bwm = np.where(valid, bw, -1.0)
    dom = bi[np.arange(bi.shape[0]), np.argmax(bwm, axis=1)].astype(np.int64)
    keep = dom != 0xFFFFFFFF
    dom = dom[keep]
    pos = np.asarray(mesh_data.positions, dtype=np.float64)[keep]
    if len(dom) == 0:
        return 0
    mx = int(dom.max())

    def median_bind(off):
        gi = off + dom
        ok = gi < L
        if not ok.any():
            return 1e18
        g = pal[gi[ok]]
        ok2 = (g >= 0) & (g < n_bones)
        if not ok2.any():
            return 1e18
        return float(np.median(np.linalg.norm(pos[ok][ok2] - bpos[g[ok2]], axis=1)))

    base = median_bind(0)
    best_off, best = 0, base
    for off in range(1, max(1, L - mx)):
        m = median_bind(off)
        if m < best:
            best, best_off = m, off
    if best_off != 0 and best < 20.0 and best < base * 0.5:
        return best_off
    return 0


def _apply_vertex_weights_with_mapping(
    obj: bpy.types.Object,
    mesh_data: Mesh,
    model: YOBJModel,
    armature: bpy.types.Object,
):
    """Apply vertex weights to vertex groups — vectorized.

    Weight bone indices may be:
      * Palette indices (remapped through mesh.bone_palette to global bone idx)
      * Direct global bone indices (when bone_palette is None or indices exceed
        palette size — segment-formatted older eras).

    Vectorized strategy: build a (vert_idx, bone_name, weight) table in NumPy
    using boolean masks and palette lookup, then group-by bone name and call
    `vg.add` once per (group, vertex_subset) combination — turning what used
    to be ~10 calls per vertex into ~1 per (bone × weight slot) pair, which
    is hundreds of calls for a typical character mesh instead of millions.
    """
    if mesh_data.bone_weights is None or mesh_data.bone_indices is None:
        return

    bone_palette = mesh_data.bone_palette
    bi = mesh_data.bone_indices         # uint32[v, w]
    bw = mesh_data.bone_weights         # float32[v, w]
    vc, wc = bi.shape
    if vc == 0 or wc == 0:
        return

    # Mask out invalid/padding entries
    valid = (bw > 0.0001) & (bi != 0xFFFFFFFF)
    if not valid.any():
        return

    raw_idx_flat = bi[valid].astype(np.int64)
    weight_flat = bw[valid].astype(np.float32)
    vert_grid, _ = np.indices(bi.shape)
    vert_idx_flat = vert_grid[valid].astype(np.int64)

    # Per-mesh skin_bone_palette START OFFSET (the engine's "Start boneSet" from
    # hkSkinnedMeshShape): a mesh's local bone indices are relative to a SLICE
    # of the global palette that, for some meshes, begins partway in. Without
    # it, those meshes resolve to far/wrong bones and explode into spikes under
    # animation. Recover it geometrically — the offset that binds each vertex to
    # its NEAREST bone — gated inside the helper so it only overrides 0 when it
    # dramatically tightens the bind (already-correct meshes stay at 0).
    pal_offset = _best_palette_offset(mesh_data, model, bone_palette)

    # Decide palette vs direct interpretation
    use_palette = False
    if bone_palette is not None and len(bone_palette) > 0:
        use_palette = bool(((raw_idx_flat + pal_offset) < len(bone_palette)).all())

    if use_palette:
        palette_arr = np.asarray(bone_palette, dtype=np.int64)
        global_idx_flat = palette_arr[raw_idx_flat + pal_offset]
        # Filter padding palette entries (0xFFFFFFFF)
        valid2 = global_idx_flat != 0xFFFFFFFF
        if not valid2.all():
            global_idx_flat = global_idx_flat[valid2]
            vert_idx_flat = vert_idx_flat[valid2]
            weight_flat = weight_flat[valid2]
    else:
        global_idx_flat = raw_idx_flat
        if bone_palette is not None and len(bone_palette) > 0:
            print(f"[Yukes]   Bone indices exceed palette size, using direct indices")

    # Resolve to bone names; skip mesh markers
    n_bones = len(model.bones)
    in_range = (global_idx_flat >= 0) & (global_idx_flat < n_bones)
    out_of_range_count = int((~in_range).sum())
    global_idx_flat = global_idx_flat[in_range]
    vert_idx_flat = vert_idx_flat[in_range]
    weight_flat = weight_flat[in_range]

    # Build name array, marker-filter mask, and unique bone enumeration
    bone_names = np.array(
        [model.bones[i].name if 0 <= i < n_bones else '' for i in range(n_bones)],
        dtype=object,
    )
    # Note: markers (m###_####) are kept as vertex groups even though they
    # don't get armature bones. ~64% of weights in Yukes character meshes
    # go to marker bones (joint-cap deformers, twist helpers, flesh
    # correctives). Filtering them at weight-assignment time loses the
    # primary skin deformers — the J_Shoulder_L / J_Elbow_L vertex groups
    # only carry the secondary blend influences. Keeping them as orphan
    # vertex groups preserves the data for round-trip export and lets the
    # user see the full skinning. The armature build still filters them
    # so the visible rig stays clean.
    keep_per_bone = np.array(
        [bool(model.bones[i].name) and model.bones[i].name.lower() != 'vector'
         if 0 <= i < n_bones else False
         for i in range(n_bones)],
        dtype=bool,
    )

    keep = keep_per_bone[global_idx_flat]
    skipped_count = int((~keep).sum())
    global_idx_flat = global_idx_flat[keep]
    vert_idx_flat = vert_idx_flat[keep]
    weight_flat = weight_flat[keep]

    if len(global_idx_flat) == 0:
        return

    unique_bones = np.unique(global_idx_flat)

    # Diagnostic
    print(f"[Yukes] Mesh '{obj.name}': "
          f"{len(unique_bones)} vertex groups, {len(global_idx_flat)} weight assignments"
          + (f", {out_of_range_count} OOR" if out_of_range_count else "")
          + (f", {skipped_count} bone-name-skipped" if skipped_count else ""))

    # Create vertex groups & apply weights, grouping by bone
    vgroups = obj.vertex_groups
    name_to_group = {}
    for bone_idx in unique_bones:
        name = bone_names[bone_idx]
        if name and name not in vgroups:
            vgroups.new(name=name)
        if name:
            name_to_group[int(bone_idx)] = vgroups[name]

    # For each unique bone, mask the relevant assignments and call vg.add per
    # weight value in tight Python (foreach-style group ops aren't exposed for
    # vertex_groups). Still ~10× fewer iterations than per-(v_idx, w_idx).
    #
    # CRASH FIX: bound-check v_idx against the mesh's actual vertex count.
    # Out-of-range indices silently corrupt memory on Blender 3.x / early
    # 4.x (deferred crash) and raise IndexError on 5.x. Either way we
    # filter here. (Mirrors blender_mesh.setVertexGroups.)
    num_verts = len(obj.data.vertices)
    total_skipped = 0
    for bone_idx in unique_bones:
        vg = name_to_group.get(int(bone_idx))
        if vg is None:
            continue
        m = global_idx_flat == bone_idx
        verts_for_bone = vert_idx_flat[m]
        weights_for_bone = weight_flat[m]
        # Vectorize the bound check; only iterate the survivors.
        oob_mask = (verts_for_bone < 0) | (verts_for_bone >= num_verts)
        if oob_mask.any():
            total_skipped += int(oob_mask.sum())
            keep = ~oob_mask
            verts_for_bone = verts_for_bone[keep]
            weights_for_bone = weights_for_bone[keep]
        for v, w in zip(verts_for_bone.tolist(), weights_for_bone.tolist()):
            vg.add([v], w, 'REPLACE')
    if total_skipped:
        dwarn(f"[Yukes] vg.add: skipped {total_skipped} out-of-bounds "
              f"vertex indices for mesh '{obj.name}' (num_verts={num_verts})")


def build_model(
    model: YOBJModel,
    name: str,
    import_skeleton: bool = True,
    import_weights: bool = True,
    import_morphs: bool = True,
    import_vertex_colors: bool = True,
) -> bool:
    """
    Build complete Blender scene from YOBJ model.
    
    Args:
        model: Parsed YOBJ model
        name: Base name for objects
        import_skeleton: Import armature
        import_weights: Import vertex weights
        import_morphs: Import shape keys
        import_vertex_colors: Import vertex colors
        
    Returns:
        True if successful
    """
    # Deselect all
    bpy.ops.object.select_all(action='DESELECT')
    
    # Build armature
    armature = None
    if import_skeleton and model.bones:
        armature = build_armature(model, name)
    
    # Build meshes
    mesh_objects = []
    for mesh_data in model.meshes:
        obj = build_mesh(
            mesh_data,
            model,
            armature,
            import_weights=import_weights,
            import_morphs=import_morphs,
            import_vertex_colors=import_vertex_colors,
        )
        mesh_objects.append(obj)
    
    # Select armature or first mesh
    if armature:
        bpy.context.view_layer.objects.active = armature
        armature.select_set(True)
    elif mesh_objects:
        bpy.context.view_layer.objects.active = mesh_objects[0]
        mesh_objects[0].select_set(True)
    
    return True
