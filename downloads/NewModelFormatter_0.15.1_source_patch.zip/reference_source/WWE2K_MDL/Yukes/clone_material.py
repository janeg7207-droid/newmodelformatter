"""Clone-from-sibling material identity for NEW Yukes/YOBJ meshes.

WHY: a brand-new Blender mesh has no captured `yobj_raw_shader_params` (the
per-mesh shader-param block), so the exporter's from-scratch path writes an
EMPTY shader-param block + bogus header counts. Worse, the YOBJ format is held
together by a single global POF0 absolute-offset relocation table that the addon
never decodes — so a *synthesized* shader-param block has no POF0 fixups and the
engine derefs unrelocated pointers at shader setup (draw-time crash). The
re-importer tolerates it; the game does not.

THE PRAGMATIC, GAME-SAFE PATH: make the new mesh ADOPT an imported sibling
("donor") mesh's render identity wholesale — its shader name, its captured
shader-param block (already POF0-consistent), its material extras, and its
material slot (→ same material-table row → same already-present texture). The
exporter then takes its proven round-trip path and writes the donor's known-good
bytes verbatim.

CAVEAT (must be in-game tested, not assumed): cloning the sp BYTES does not
clone any POF0 entries that point *into* the donor's original block position. A
self-contained shader (e.g. yCS_skin) is low risk; hair/complex shaders whose sp
block holds inward POF0 pointers are the riskiest clone and need an in-game check.
"""
import bpy

# Object-level props that carry a mesh's YOBJ render identity (read by
# exporter_blender.py via obj.get(...)). Geometry-specific raw blocks
# (raw_weight/raw_face/raw_mesh_header/vertex_tail/normals) are intentionally
# NOT cloned — the new mesh's own geometry is re-encoded; only the material/
# shader identity is inherited.
_IDENTITY_PROPS = (
    'shader_type',
    'yobj_raw_shader_params',
    'yobj_material_extras',
    'yobj_gamespace',
)


def clone_material_identity(new_obj, donor_obj):
    """Stamp donor_obj's YOBJ material/shader identity onto new_obj and reuse the
    donor's material slot. Returns a short status string."""
    copied = []
    for k in _IDENTITY_PROPS:
        if k in donor_obj.keys():
            new_obj[k] = donor_obj[k]
            copied.append(k)
    # Reuse the donor's material slot so material_index resolves to the same
    # material-table row → same extras[2] tex_idx → same already-present texture.
    new_obj.data.materials.clear()
    donor_mat = None
    if donor_obj.material_slots and donor_obj.material_slots[0].material:
        donor_mat = donor_obj.material_slots[0].material
        new_obj.data.materials.append(donor_mat)
    return f"cloned {len(copied)} identity props + material '{donor_mat.name if donor_mat else None}'"


class YOBJ_OT_CloneMaterial(bpy.types.Operator):
    """Give the selected NEW mesh(es) a game-valid Yukes material by cloning it
    from the ACTIVE (donor) imported mesh. Select new mesh(es), then shift-select
    an imported donor mesh whose shader matches the look you want, and run."""
    bl_idname = "object.yobj_clone_material_from_donor"
    bl_label = "YOBJ: Clone Material From Active (donor)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        sel = [o for o in context.selected_objects if o.type == 'MESH']
        return (context.active_object is not None
                and context.active_object.type == 'MESH'
                and 'yobj_raw_shader_params' in context.active_object.keys()
                and len(sel) >= 2)

    def execute(self, context):
        donor = context.active_object
        targets = [o for o in context.selected_objects
                   if o.type == 'MESH' and o is not donor]
        if not targets:
            self.report({'WARNING'}, "Select new mesh(es) + the donor as active.")
            return {'CANCELLED'}
        if 'yobj_raw_shader_params' not in donor.keys():
            self.report({'ERROR'}, "Active (donor) mesh has no captured YOBJ "
                                   "material — pick an imported mesh as donor.")
            return {'CANCELLED'}
        for t in targets:
            clone_material_identity(t, donor)
        self.report({'INFO'},
                    f"Cloned YOBJ material from '{donor.name}' onto "
                    f"{len(targets)} mesh(es).")
        return {'FINISHED'}
