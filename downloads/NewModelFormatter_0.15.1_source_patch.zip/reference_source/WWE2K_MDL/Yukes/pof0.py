"""POF0 relocation table codec for Yukes/Eighting YOBJ/JBOY files.

A YOBJ file ends with a POF0 chunk (located via the file header's +0x04 field,
which points 8 bytes before the chunk's "POF0" magic). POF0 enumerates the file
offset of EVERY absolute-pointer u32 the engine must fix up at load — header
offset fields, per-mesh shader-param pointer tables, face self-pointers, the
skel/tex/mtl/morph/palette pointers. The addon historically spliced the whole
trailer (incl. POF0) verbatim and relied on block positions never moving; that
breaks the instant a new/edited/resized block shifts the layout, because the
absolute pointers POF0 fixes up would then be wrong.

This module decodes POF0 to the set of relocated-pointer file offsets, and
re-encodes a slot set back to the exact on-disk byte stream — so the exporter
can REGENERATE POF0 for a new layout (and keep round-trip byte-exact).

ENCODING (proven byte-exact against real 2K17-2K19 files): a delta stream over a
running cursor. Each entry's lead byte top-2 bits select width; the value is the
delta to the next relocated pointer in 32-bit WORDS (value*4 = byte delta):
  0b01 -> 1 byte : val = b0 & 0x3F
  0b10 -> 2 bytes: val = (b0 & 0x3F) << 8  | b1
  0b11 -> 4 bytes: val = (b0 & 0x3F) << 24 | b1<<16 | b2<<8 | b3
  0b00 -> a 0x00 byte is trailing alignment pad (skip)
The chunk wrapper is: u32 0x0000000a, u32 0x0000000d, b"POF0", u32 payload_len,
then the payload; the +0x04 (and +0x0C) header fields point at chunk_start-8.
"""
import struct

POF0_MAGIC = b'POF0'


def decode(payload: bytes) -> list:
    """Decode a POF0 payload to a sorted list of relocated-pointer file offsets."""
    slots = []
    cur = 0
    i = 0
    n = len(payload)
    while i < n:
        b0 = payload[i]
        sel = b0 >> 6
        lo = b0 & 0x3F
        if b0 == 0:               # trailing alignment pad
            i += 1
            continue
        if sel == 1:
            val = lo; i += 1
        elif sel == 2:
            val = (lo << 8) | payload[i + 1]; i += 2
        elif sel == 3:
            val = (lo << 24) | (payload[i + 1] << 16) | (payload[i + 2] << 8) | payload[i + 3]; i += 4
        else:                     # sel == 0 but non-zero lead byte
            val = lo; i += 1
        cur += val * 4
        slots.append(cur)
    return slots


def encode(slots, align=4) -> bytes:
    """Encode a list of relocated-pointer file offsets back to a POF0 payload.
    `slots` need not be pre-sorted. Output is zero-padded to `align` bytes."""
    out = bytearray()
    prev = 0
    for s in sorted(slots):
        delta = (s - prev) // 4
        if (s - prev) % 4 != 0:
            raise ValueError(f"POF0 slot {s:#x} not 4-aligned vs prev {prev:#x}")
        prev = s
        if delta < 0x40:
            out.append(0x40 | delta)
        elif delta < 0x4000:
            out.append(0x80 | (delta >> 8)); out.append(delta & 0xFF)
        else:
            out.append(0xC0 | ((delta >> 24) & 0x3F))
            out += bytes([(delta >> 16) & 0xFF, (delta >> 8) & 0xFF, delta & 0xFF])
    while len(out) % align != 0:
        out.append(0)
    return bytes(out)


def build_chunk(slots, align=4) -> bytes:
    """Build the full POF0 chunk (wrapper + payload) for a slot set."""
    payload = encode(slots, align=align)
    return struct.pack('>II', 0x0000000a, 0x0000000d) + POF0_MAGIC + \
        struct.pack('>I', len(payload)) + payload


def locate(data: bytes):
    """Return (chunk_start, payload_offset, payload_len) for the POF0 chunk in a
    YOBJ file, or None. chunk_start = header+0x04 value + 8 (START_OFFSET)."""
    if len(data) < 0x10:
        return None
    field = struct.unpack_from('>I', data, 0x04)[0]
    chunk = field + 8
    if chunk + 12 <= len(data) and data[chunk:chunk + 4] == POF0_MAGIC:
        plen = struct.unpack_from('>I', data, chunk + 4)[0]
        return (chunk, chunk + 8, plen)
    return None
