"""
Blender → YOBJModel collection.

Pulls vertex positions, normals, UVs, vertex colors, weights, and shape keys
from Blender objects and an armature, returning lists ready to feed into the
round-trip exporter (`write_yobj_from_model`). Imported only when bpy is
available — never imported by the round-trip path.
"""

from __future__ import annotations
import hashlib
import numpy as np
from typing import List, Optional, Tuple

from .structures import Bone, Material, Mesh, MorphTarget
from .format_consts import WEIGHT_PADDING_INDEX, MESH_INLINE_PALETTE_SLOTS


def collect_bones_from_blender(armature) -> List[Bone]:
    """Pull bones in armature-data order, preserving raw on-disk values.

    The file format stores bone position and rotation as parent-relative
    in the game's coordinate system. The builder accumulates these via
    `parent_world @ local` to place each bone in armature space, and
    also flips the coordinate system (Y-up → Z-up) on import. Reading
    `b.head_local` here would give us the *armature-space* position
    (i.e., already accumulated and coordinate-flipped) — writing that
    back to the file would store world coordinates in slots that the
    engine and the builder both interpret as parent-relative. On
    re-import the builder would accumulate again, scattering distal
    bones out into space (a starfish/sprinting-skeleton silhouette).

    To avoid that, the builder stashes the original on-disk position,
    rotation, and tail as `yobj_pos` / `yobj_rot` / `yobj_tail` on the
    edit-bone at import time. We prefer those when present; we fall
    back to deriving from `head_local` only when the user has clearly
    authored the bone from scratch (no stashed value).
    """
    import bpy
    bones: List[Bone] = []
    bone_names = [b.name for b in armature.data.bones]
    for i, b in enumerate(armature.data.bones):
        parent_idx = bone_names.index(b.parent.name) if b.parent else -1

        stashed_pos = b.get('yobj_pos')
        stashed_rot = b.get('yobj_rot')
        stashed_tail = b.get('yobj_tail')

        if stashed_pos is not None:
            position = np.asarray(list(stashed_pos)[:3], dtype=np.float32)
        else:
            # Fallback: armature-space head. This is wrong for round-trip
            # of unedited bones, but it's the only signal we have for
            # bones the user added themselves.
            position = np.array(list(b.head_local), dtype=np.float32)

        if stashed_rot is not None:
            rotation = np.asarray(list(stashed_rot)[:3], dtype=np.float32)
        else:
            rotation = np.array(list(b.matrix_local.to_euler()), dtype=np.float32)

        if stashed_tail is not None:
            tail_arr = np.asarray(list(stashed_tail), dtype=np.float32)
        else:
            tail_arr = np.array(list(b.tail_local) + [0.0], dtype=np.float32)

        bones.append(Bone(
            name=b.name,
            index=i,
            parent_index=parent_idx,
            position=position,
            rotation=rotation,
            tail=tail_arr,
        ))
    return bones


def _collect_one_mesh(obj, armature, bones, materials_out: List[Material],
                     textures_seen: List[str], morph_names_global: List[str],
                     mesh_index: int) -> Mesh:
    """Build a Mesh from a Blender object."""
    import bpy

    mesh = obj.data

    # Use Blender's native loop-triangle calculator instead of bmesh — it's
    # faster and avoids constructing a parallel bmesh copy. Triangulation
    # output is per-loop (mesh.loops indices), so we resolve back to
    # mesh.vertices indices below.
    mesh.calc_loop_triangles()

    vc = len(mesh.vertices)
    positions = np.zeros((vc, 3), dtype=np.float32)
    normals = np.zeros((vc, 3), dtype=np.float32)
    if vc > 0:
        flat = np.zeros(vc * 3, dtype=np.float32)
        mesh.vertices.foreach_get('co', flat)
        positions = flat.reshape(vc, 3).copy()
        mesh.vertices.foreach_get('normal', flat)
        normals = flat.reshape(vc, 3).copy()

    # Coordinate handling depends on which import convention produced this mesh:
    #   * Current builder (stamps obj['yobj_gamespace']=True): vertices are kept
    #     in RAW GAME space and the Y-up->Z-up flip is the armature object's
    #     -90deg X rotation (inherited via parenting). mesh.vertices.co is
    #     already game-space → write it straight back, NO inversion.
    #   * Legacy builder (no flag): verts were baked game->Blender (x,z,-y), so
    #     we invert here (Blender x,y,z -> game x,-z,y) for a clean round-trip.
    # Gating on the flag keeps both old and freshly-imported .blend files
    # exporting correctly.
    if not obj.get('yobj_gamespace'):
        old_y = positions[:, 1].copy()
        old_z = positions[:, 2].copy()
        positions[:, 1] = -old_z
        positions[:, 2] = old_y
        old_ny = normals[:, 1].copy()
        old_nz = normals[:, 2].copy()
        normals[:, 1] = -old_nz
        normals[:, 2] = old_ny

    # If the original game-space normals were stashed at import (the
    # `yobj_normals` IDProperty), prefer them verbatim. Blender's
    # auto-computed v.normal is an average of adjacent face normals, so
    # for any creased vertex it differs from the per-vertex custom normals
    # in the source file — even without a single user edit. Splicing the
    # stash here makes the no-edit round-trip byte-perfect on normals.
    # If the user did edit geometry, the stash will have a stale length
    # (vc mismatch) and we fall through to the Blender-computed values.
    stashed_n = obj.get('yobj_normals')
    if stashed_n is not None:
        try:
            n_bytes = bytes(stashed_n)
            if len(n_bytes) == vc * 12:
                normals = np.frombuffer(n_bytes, dtype='<f4').reshape(vc, 3).astype(np.float32, copy=True)
        except Exception:
            pass

    n_tris = len(mesh.loop_triangles)
    if n_tris > 0:
        tri_verts = np.zeros(n_tris * 3, dtype=np.int32)
        mesh.loop_triangles.foreach_get('vertices', tri_verts)
        faces = tri_verts.reshape(n_tris, 3).astype(np.uint32)
    else:
        faces = np.zeros((0, 3), dtype=np.uint32)

    # UVs — pull per-loop UVs in one bulk read, then scatter to per-vertex.
    # The original (loop-by-loop) walk had "last write wins" semantics for
    # vertices shared by polygons with different UVs; we preserve that here
    # by walking the loop array in order rather than using numpy fancy
    # assignment (whose duplicate-index behaviour isn't guaranteed).
    uvs = np.zeros((vc, 2), dtype=np.float32)
    if mesh.uv_layers and vc > 0:
        uv_layer = mesh.uv_layers[0]
        n_loops = len(mesh.loops)
        if n_loops > 0:
            uv_flat = np.zeros(n_loops * 2, dtype=np.float32)
            uv_layer.data.foreach_get('uv', uv_flat)
            loop_vidx = np.zeros(n_loops, dtype=np.int32)
            mesh.loops.foreach_get('vertex_index', loop_vidx)
            uv_pairs = uv_flat.reshape(n_loops, 2)
            for li in range(n_loops):
                uvs[loop_vidx[li]] = uv_pairs[li]

    # Vertex tail bytes (4 trailing bytes per vertex in the 28-byte
    # vertex record). Round-trip preference order:
    #   1. Stashed `yobj_vertex_tail` bytes from import — verbatim splice.
    #      Required for vanilla SVR-era files where the tail is the
    #      uniform 0xFFFFFFFF sentinel that the parser DOESN'T convert
    #      to a Blender color attribute (uniform values aren't useful as
    #      vertex colors), so the data would otherwise be lost.
    #   2. Blender color_attributes — for meshes the user authored or
    #      where the parser saw varying tail bytes worth surfacing as
    #      vertex colors.
    #   3. None — exporter falls back to writing the 0xFF sentinel.
    vertex_tail = None
    stashed_tail = obj.get('yobj_vertex_tail')
    if stashed_tail is not None:
        try:
            tail_bytes = bytes(stashed_tail)
            if len(tail_bytes) == vc * 4:
                vertex_tail = np.frombuffer(tail_bytes, dtype=np.uint8).reshape(vc, 4).copy()
        except Exception:
            vertex_tail = None
    if vertex_tail is None and getattr(mesh, "color_attributes", None):
        ca = mesh.color_attributes[0]
        if ca.domain == 'POINT' and len(ca.data) >= vc and vc > 0:
            col_flat = np.zeros(len(ca.data) * 4, dtype=np.float32)
            ca.data.foreach_get('color', col_flat)
            colors = col_flat.reshape(-1, 4)[:vc]
            vertex_tail = (colors * 255.0).clip(0, 255).astype(np.uint8)

    # Bone weights — route through the perf fast path. Previously this
    # was a double Python loop (max_inf discovery + per-vertex fill) and
    # was the slowest part of YOBJ export on character-class meshes
    # (~30k verts × 8 influences). The fast path:
    #   * Builds vg_to_bone via dict lookups instead of repeated
    #     list.index() (one O(B) prebuild instead of O(V * G) total).
    #   * Fuses the max_inf discovery pass with the fill pass.
    #   * Normalizes via numpy in one shot.
    # Semantics preserved: top-N-by-weight, WEIGHT_PADDING_INDEX in
    # unused slots, per-vertex sum-to-1 normalization, max_inf clamped
    # to [1, 4].
    bone_indices_arr = None
    bone_weights_arr = None
    max_inf = 0
    if armature and obj.vertex_groups and bones:
        bone_names = [b.name for b in bones]
        try:
            from ..Blender.perf import fast_get_yobj_weights
            bone_indices_arr, bone_weights_arr, max_inf = fast_get_yobj_weights(
                obj, bone_names, WEIGHT_PADDING_INDEX, max_inf_cap=4
            )
        except Exception as e:
            # Fall through to the original Python path on any failure
            # (import error in older bundled perf.py, numpy shape
            # weirdness, etc.). The slow path keeps the export alive.
            print(f"[Yukes] weight extraction fast path skipped ({e}); using slow path.")
            bone_indices_arr = None
            bone_weights_arr = None
            max_inf = 0

        if bone_indices_arr is None:
            vg_to_bone = {}
            for vg in obj.vertex_groups:
                if vg.name in bone_names:
                    vg_to_bone[vg.index] = bone_names.index(vg.name)

            # Determine max influences (cap at 4 — game format never exceeds this in practice)
            for v in mesh.vertices:
                valid = [g for g in v.groups if g.group in vg_to_bone and g.weight > 0]
                if len(valid) > max_inf:
                    max_inf = len(valid)
            if max_inf > 0:
                max_inf = max(1, min(max_inf, 4))

                bone_indices_arr = np.full((vc, max_inf), WEIGHT_PADDING_INDEX, dtype=np.uint32)
                bone_weights_arr = np.zeros((vc, max_inf), dtype=np.float32)
                for v in mesh.vertices:
                    grps = sorted(
                        (g for g in v.groups if g.group in vg_to_bone and g.weight > 0),
                        key=lambda g: g.weight, reverse=True
                    )[:max_inf]
                    for i, g in enumerate(grps):
                        bone_indices_arr[v.index, i] = vg_to_bone[g.group]
                        bone_weights_arr[v.index, i] = g.weight
                # Normalize per-vertex
                sums = bone_weights_arr.sum(axis=1, keepdims=True)
                sums[sums == 0] = 1.0
                bone_weights_arr = bone_weights_arr / sums

    # Shape keys → morph targets
    morph_targets: List[MorphTarget] = []
    if mesh.shape_keys and len(mesh.shape_keys.key_blocks) > 1:
        basis = mesh.shape_keys.key_blocks[0]
        for sk in mesh.shape_keys.key_blocks[1:]:
            n_sk = len(sk.data)
            if n_sk > 0:
                sk_flat = np.zeros(n_sk * 3, dtype=np.float32)
                sk.data.foreach_get('co', sk_flat)
                mp = sk_flat.reshape(n_sk, 3)[:vc].astype(np.float32, copy=True)
                if mp.shape[0] < vc:
                    pad = np.zeros((vc - mp.shape[0], 3), dtype=np.float32)
                    mp = np.concatenate([mp, pad], axis=0)
            else:
                mp = np.zeros((vc, 3), dtype=np.float32)
            morph_targets.append(MorphTarget(name=sk.name, positions=mp, normals=None))
            if sk.name not in morph_names_global:
                morph_names_global.append(sk.name)

    # Material
    mat_name = "M_Default"
    shader_type = obj.get('shader_type', "yCS_skin")
    if obj.material_slots and obj.material_slots[0].material:
        mat_name = obj.material_slots[0].material.name

    # Find or create material in the global list
    mat_index = next((i for i, m in enumerate(materials_out) if m.name == mat_name), -1)
    if mat_index < 0:
        # Read material extras: prefer new bytes-encoded property, fall back
        # to old int-list property, then to a sane default.
        extras = (1, 0, 0, 0)
        ex_bytes = obj.get('yobj_material_extras', None)
        if ex_bytes is not None and len(bytes(ex_bytes)) >= 16:
            import struct as _struct
            extras = _struct.unpack('<4I', bytes(ex_bytes)[:16])
        else:
            ex_list = obj.get('material_extras', None)
            if ex_list is not None:
                extras = tuple(int(x) & 0xFFFFFFFF for x in ex_list)
        mat_index = len(materials_out)
        materials_out.append(Material(name=mat_name, index=mat_index, extras=tuple(extras)))

    # Inline palette — prefer bytes-encoded property, fall back to legacy
    # int-list, then compute from used bones.
    inline_palette_full = None
    ip_bytes = obj.get('yobj_inline_palette', None)
    if ip_bytes is not None and len(bytes(ip_bytes)) >= 80:
        import struct as _struct
        inline_palette_full = _struct.unpack('<20I', bytes(ip_bytes)[:80])
    else:
        ip_list = obj.get('inline_palette_full', None)
        if ip_list is not None:
            inline_palette_full = tuple(int(x) & 0xFFFFFFFF for x in ip_list)

    if inline_palette_full is None:
        # Compute from used bones
        used = set()
        if bone_indices_arr is not None:
            used.update(int(x) for x in bone_indices_arr.flatten()
                        if int(x) != WEIGHT_PADDING_INDEX)
        palette = sorted(used)[:MESH_INLINE_PALETTE_SLOTS]
        inline_palette_full = tuple(palette + [0xFFFFFFFF] * (MESH_INLINE_PALETTE_SLOTS - len(palette)))
        # Remap bone_indices to palette positions
        if bone_indices_arr is not None and palette:
            remap = {b: i for i, b in enumerate(palette)}
            for vi in range(vc):
                for ii in range(bone_indices_arr.shape[1]):
                    bi = int(bone_indices_arr[vi, ii])
                    if bi in remap:
                        bone_indices_arr[vi, ii] = remap[bi]

    # bbox/pivot — preserve from custom prop if present, else compute
    bbox = obj.get('yobj_bbox_pivot', None)
    if bbox is not None:
        bbox_pivot = tuple(float(x) for x in bbox)
    else:
        if vc > 0:
            radius = float(np.linalg.norm(positions.max(0) - positions.min(0)) * 0.5)
            center = positions.mean(0)
            bbox_pivot = (radius, float(center[0]), float(center[1]), float(center[2]))
        else:
            bbox_pivot = (0.0, 0.0, 0.0, 0.0)

    # Round-trip metadata stashed by the importer — these are what enable
    # game-compatible re-export. Bytes IDProperties come back as
    # IDPropertyBytes objects which `bytes(...)` converts cleanly.
    raw_header = b''
    raw_sp = b''
    raw_weight = b''
    raw_face = b''
    rh = obj.get('yobj_raw_mesh_header', None)
    if rh is not None:
        try:
            raw_header = bytes(rh)
        except Exception as e:
            print(f"[Yukes] {obj.name}: lost raw_mesh_header ({e})")
    sp = obj.get('yobj_raw_shader_params', None)
    if sp is not None:
        try:
            raw_sp = bytes(sp)
        except Exception as e:
            print(f"[Yukes] {obj.name}: lost raw_shader_params ({e})")
    rw = obj.get('yobj_raw_weight', None)
    if rw is not None:
        try:
            raw_weight = bytes(rw)
        except Exception as e:
            print(f"[Yukes] {obj.name}: lost raw_weight ({e})")
    rf = obj.get('yobj_raw_face', None)
    if rf is not None:
        try:
            raw_face = bytes(rf)
        except Exception as e:
            print(f"[Yukes] {obj.name}: lost raw_face ({e})")
    face_sec_val = int(obj.get('yobj_face_sec', 1))

    # When the original weight bytes are present and vc still matches the
    # capture (no geometry edits that changed vertex count), the
    # influence count is fixed by the data: wc = bytes / (vc * 8). We
    # MUST honour this rather than the Blender-computed max_inf, because
    # the on-disk weight block is padded with sentinels (0xFFFFFFFF +
    # weight 0) up to a per-mesh wc, but Blender doesn't materialise
    # those padding entries as real vertex groups. So a vanilla mesh
    # with wc=4 (with one slot frequently being padding) ends up with
    # Blender-computed max_inf=3, the writer stamps WEIGHT_COUNT=3 in
    # the mesh header, and the engine then reads 3-weight stride from
    # 4-weight-stride data — every vertex skins to the wrong bones,
    # collapsing the mesh onto bone 0 / origin in-game.
    if raw_weight is not None and vc > 0 and len(raw_weight) % (vc * 8) == 0:
        wc_from_raw = len(raw_weight) // (vc * 8)
        if wc_from_raw > 0:
            max_inf = wc_from_raw

    # Splice raw vertex + UV blocks for byte-exact round-trip — gated on the
    # import-time geometry hash so only UNEDITED meshes use the verbatim bytes;
    # edited/new meshes (hash mismatch / no prop) re-encode from the Blender mesh.
    raw_vertex = b''
    raw_uv = b''
    raw_normal = b''
    stash_hash = obj.get('yobj_geom_hash', None)
    if stash_hash:
        try:
            _cur = np.empty(len(obj.data.vertices) * 3, dtype=np.float32)
            obj.data.vertices.foreach_get('co', _cur)
            _cur_hash = hashlib.sha1(_cur.tobytes()).hexdigest()[:16]
        except Exception:
            _cur_hash = None
        if _cur_hash == stash_hash:
            _rv = obj.get('yobj_raw_vertex', None)
            if _rv is not None:
                try: raw_vertex = bytes(_rv)
                except Exception: pass
            _ru = obj.get('yobj_raw_uv', None)
            if _ru is not None:
                try: raw_uv = bytes(_ru)
                except Exception: pass
            _rn = obj.get('yobj_raw_normal', None)
            if _rn is not None:
                try: raw_normal = bytes(_rn)
                except Exception: pass

    return Mesh(
        index=mesh_index,
        name=obj.name,
        shader_type=shader_type,
        material_index=mat_index,
        positions=positions,
        normals=normals,
        uvs=uvs,
        faces=faces,
        vertex_tail=vertex_tail,
        colors=None,
        uvs2=None,
        morph_targets=morph_targets,
        bone_indices=bone_indices_arr,
        bone_weights=bone_weights_arr,
        bone_palette=None,
        max_influences=max_inf,
        bbox_pivot=bbox_pivot,
        inline_palette_full=inline_palette_full,
        face_sec=face_sec_val,
        raw_header=raw_header,
        raw_shader_param_bytes=raw_sp,
        raw_weight_bytes=raw_weight,
        raw_face_bytes=raw_face,
        raw_vertex_bytes=raw_vertex,
        raw_uv_bytes=raw_uv,
        raw_normal_bytes=raw_normal,
    )


def collect_meshes_from_blender(
    objects, armature, bones
) -> Tuple[List[Mesh], List[Material], List[str], List[str]]:
    """Walk objects, return (meshes, materials, textures, morph_names)."""
    materials: List[Material] = []
    morph_names: List[str] = []
    meshes: List[Mesh] = []

    # Sort by prop_id (original mesh index, stashed on import) so we round-
    # trip in the same order the source file had. Falls back to scene order
    # for objects that weren't imported (have no prop_id).
    mesh_objs = [o for o in objects if o.type == 'MESH']
    mesh_objs.sort(key=lambda o: o.get('prop_id', 1_000_000))

    mi = 0
    for obj in mesh_objs:
        meshes.append(_collect_one_mesh(
            obj, armature, bones, materials, [], morph_names, mi
        ))
        mi += 1

    # Texture list — collect from custom props on armature, falls back to empty.
    textures: List[str] = []
    if armature is not None:
        tex_prop = armature.get('yobj_textures', None)
        if tex_prop is not None:
            # New format: single newline-separated string. Old format: list.
            if isinstance(tex_prop, str):
                textures = [t for t in tex_prop.split('\n') if t]
            else:
                textures = [str(t) for t in tex_prop]

        # Morph names — preserve the original list from import. Falls back to
        # whatever the per-mesh shape-key collection gathered.
        mn_prop = armature.get('yobj_morph_names', None)
        if mn_prop is not None and isinstance(mn_prop, str):
            stashed = [n for n in mn_prop.split('\n') if n]
            if stashed:
                morph_names = stashed

    return meshes, materials, textures, morph_names


def collect_round_trip_metadata_from_armature(armature) -> dict:
    """Pull file-level round-trip metadata stashed on the armature by import.

    Returns a dict with `raw_header`, `texture_header`, `global_bone_palette`
    keys (each absent if not stashed). Used by export_yobj to populate the
    YOBJModel before calling write_yobj_from_model.
    """
    out: dict = {}
    if armature is None:
        return out
    rh = armature.get('yobj_raw_file_header', None)
    if rh is not None:
        try:
            out['raw_header'] = bytes(rh)
        except Exception as e:
            print(f"[Yukes] {armature.name}: lost raw_file_header ({e})")
    rt = armature.get('yobj_raw_trailer', None)
    if rt is not None:
        try:
            out['raw_trailer'] = bytes(rt)
            out['raw_trailer_orig_start'] = int(armature.get('yobj_trailer_orig_start', 0))
        except Exception as e:
            print(f"[Yukes] {armature.name}: lost raw_trailer ({e})")
    rsm = armature.get('yobj_raw_skel_mtl', None)
    if rsm is not None:
        try:
            out['raw_skel_to_mtl_bytes'] = bytes(rsm)
        except Exception as e:
            print(f"[Yukes] {armature.name}: lost raw_skel_to_mtl ({e})")
    th = armature.get('yobj_tex_header', None)
    if th is not None:
        try:
            out['texture_header'] = tuple(float(x) for x in th)
        except Exception as e:
            print(f"[Yukes] {armature.name}: lost tex_header ({e})")
    gp = armature.get('yobj_global_palette', None)
    if gp is not None:
        try:
            import struct as _struct
            import numpy as _np
            data = bytes(gp)
            count = len(data) // 4
            if count > 0:
                out['global_bone_palette'] = _np.array(
                    _struct.unpack(f'<{count}I', data[:count * 4]),
                    dtype=_np.uint32
                )
        except Exception as e:
            print(f"[Yukes] Could not unpack global_palette: {e}")
    return out
