"""
High-performance binary reader for YOBJ files.

Two access patterns:

* Sequential (stateful): `read_uint32()`, `read_string(n)`, etc. — uses
  the internal cursor. Used by the older parser modules (svr, svr07, 2k14).

* Random-access: `u32_at(offset)`, `f32_array_at(offset, count)`,
  `bytes_at(offset, n)` — does not move the cursor. Used by the new
  vectorized 15-19 parser, which knows offsets up-front.
"""

import mmap
import struct
from typing import Optional, Tuple
import numpy as np


class BinaryReader:
    __slots__ = ('_data', '_pos', '_size', '_endian', '_mmap', '_file')

    def __init__(self, filepath: str):
        self._file = open(filepath, 'rb')
        self._mmap = mmap.mmap(self._file.fileno(), 0, access=mmap.ACCESS_READ)
        self._data = self._mmap
        self._size = len(self._data)
        self._pos = 0
        self._endian = '>'  # JBOY default

    def close(self):
        if self._mmap:
            self._mmap.close()
        if self._file:
            self._file.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    @property
    def position(self) -> int:
        return self._pos

    @position.setter
    def position(self, pos: int):
        self._pos = pos

    def size(self) -> int:
        return self._size

    def seek(self, pos: int, whence: int = 0):
        if whence == 0:
            self._pos = pos
        elif whence == 1:
            self._pos += pos
        elif whence == 2:
            self._pos = self._size + pos

    def skip(self, count: int):
        self._pos += count

    def set_endian(self, big_endian: bool):
        self._endian = '>' if big_endian else '<'

    @property
    def endian(self) -> str:
        return self._endian

    # ─── Sequential (stateful) reads ────────────────────────────────────────
    def read_bytes(self, count: int) -> bytes:
        data = self._data[self._pos:self._pos + count]
        self._pos += count
        return data

    def read_string(self, size: int, encoding: str = 'sjis') -> str:
        data = self._data[self._pos:self._pos + size]
        self._pos += size
        try:
            null_idx = data.index(b'\x00')
            data = data[:null_idx]
        except ValueError:
            pass
        return data.decode(encoding, errors='replace')

    def read_int8(self) -> int:
        val = self._data[self._pos]
        self._pos += 1
        return val if val < 128 else val - 256

    def read_uint8(self) -> int:
        val = self._data[self._pos]
        self._pos += 1
        return val

    def read_int16(self) -> int:
        val = struct.unpack_from(f'{self._endian}h', self._data, self._pos)[0]
        self._pos += 2
        return val

    def read_uint16(self) -> int:
        val = struct.unpack_from(f'{self._endian}H', self._data, self._pos)[0]
        self._pos += 2
        return val

    def read_int32(self) -> int:
        val = struct.unpack_from(f'{self._endian}i', self._data, self._pos)[0]
        self._pos += 4
        return val

    def read_uint32(self) -> int:
        val = struct.unpack_from(f'{self._endian}I', self._data, self._pos)[0]
        self._pos += 4
        return val

    def read_float32(self) -> float:
        val = struct.unpack_from(f'{self._endian}f', self._data, self._pos)[0]
        self._pos += 4
        return val

    def read_float32_array(self, count: int) -> np.ndarray:
        dtype = '>f4' if self._endian == '>' else '<f4'
        arr = np.frombuffer(self._data, dtype=dtype, count=count, offset=self._pos).copy()
        self._pos += count * 4
        return arr

    def read_int32_array(self, count: int) -> np.ndarray:
        dtype = '>i4' if self._endian == '>' else '<i4'
        arr = np.frombuffer(self._data, dtype=dtype, count=count, offset=self._pos).copy()
        self._pos += count * 4
        return arr

    def read_uint32_array(self, count: int) -> np.ndarray:
        dtype = '>u4' if self._endian == '>' else '<u4'
        arr = np.frombuffer(self._data, dtype=dtype, count=count, offset=self._pos).copy()
        self._pos += count * 4
        return arr

    def read_uint16_array(self, count: int) -> np.ndarray:
        dtype = '>u2' if self._endian == '>' else '<u2'
        arr = np.frombuffer(self._data, dtype=dtype, count=count, offset=self._pos).copy()
        self._pos += count * 2
        return arr

    def read_int16_array(self, count: int) -> np.ndarray:
        dtype = '>i2' if self._endian == '>' else '<i2'
        arr = np.frombuffer(self._data, dtype=dtype, count=count, offset=self._pos).copy()
        self._pos += count * 2
        return arr

    def read_uint8_array(self, count: int) -> np.ndarray:
        arr = np.frombuffer(self._data, dtype=np.uint8, count=count, offset=self._pos).copy()
        self._pos += count
        return arr

    def read_vec3_array(self, count: int) -> np.ndarray:
        return self.read_float32_array(count * 3).reshape((count, 3))

    def read_vec4_array(self, count: int) -> np.ndarray:
        return self.read_float32_array(count * 4).reshape((count, 4))

    def read_vec2_array(self, count: int) -> np.ndarray:
        return self.read_float32_array(count * 2).reshape((count, 2))

    def read_vertex_data_interleaved(
        self, count: int, has_position: bool = True, has_normal: bool = True,
        has_color: bool = True, stride: int = 28
    ) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], Optional[np.ndarray]]:
        """Legacy interleaved reader — kept for backwards-compat with older parsers."""
        total_bytes = count * stride
        raw = np.frombuffer(self._data, dtype=np.uint8, count=total_bytes, offset=self._pos).copy()
        self._pos += total_bytes
        raw = raw.reshape((count, stride))

        positions = normals = colors = None
        offset = 0
        dtype = '>f4' if self._endian == '>' else '<f4'
        if has_position:
            pos_bytes = raw[:, offset:offset + 12].tobytes()
            positions = np.frombuffer(pos_bytes, dtype=dtype).reshape((count, 3))
            offset += 12
        if has_normal:
            nrm_bytes = raw[:, offset:offset + 12].tobytes()
            normals = np.frombuffer(nrm_bytes, dtype=dtype).reshape((count, 3))
            offset += 12
        if has_color:
            colors = raw[:, offset:offset + 4].astype(np.float32) / 255.0
        return positions, normals, colors

    # ─── Random-access (cursor-free) reads ──────────────────────────────────

    def u32_at(self, offset: int) -> int:
        return struct.unpack_from(f'{self._endian}I', self._data, offset)[0]

    def i32_at(self, offset: int) -> int:
        return struct.unpack_from(f'{self._endian}i', self._data, offset)[0]

    def f32_at(self, offset: int) -> float:
        return struct.unpack_from(f'{self._endian}f', self._data, offset)[0]

    def u16_at(self, offset: int) -> int:
        return struct.unpack_from(f'{self._endian}H', self._data, offset)[0]

    def read_string_at(self, offset: int, max_len: int, encoding: str = 'ascii') -> str:
        raw = self._data[offset:offset + max_len]
        nul = raw.find(b'\x00')
        if nul != -1:
            raw = raw[:nul]
        return raw.decode(encoding, errors='replace')

    def f32_array_at(self, offset: int, count: int) -> np.ndarray:
        dtype = '>f4' if self._endian == '>' else '<f4'
        return np.frombuffer(self._data, dtype=dtype, count=count, offset=offset).copy()

    def u32_array_at(self, offset: int, count: int) -> np.ndarray:
        dtype = '>u4' if self._endian == '>' else '<u4'
        return np.frombuffer(self._data, dtype=dtype, count=count, offset=offset).copy()

    def i32_array_at(self, offset: int, count: int) -> np.ndarray:
        dtype = '>i4' if self._endian == '>' else '<i4'
        return np.frombuffer(self._data, dtype=dtype, count=count, offset=offset).copy()

    def u16_array_at(self, offset: int, count: int) -> np.ndarray:
        dtype = '>u2' if self._endian == '>' else '<u2'
        return np.frombuffer(self._data, dtype=dtype, count=count, offset=offset).copy()

    def bytes_at(self, offset: int, count: int) -> np.ndarray:
        """Return a uint8 array (copied) of `count` bytes at `offset`."""
        return np.frombuffer(self._data, dtype=np.uint8, count=count, offset=offset).copy()

    def view_floats(self, byte_array: np.ndarray) -> np.ndarray:
        """Reinterpret a contiguous uint8 array as file-endian float32."""
        contig = np.ascontiguousarray(byte_array)
        dtype = '>f4' if self._endian == '>' else '<f4'
        return contig.view(dtype)
