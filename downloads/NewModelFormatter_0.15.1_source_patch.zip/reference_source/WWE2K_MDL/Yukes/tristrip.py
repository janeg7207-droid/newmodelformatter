"""
Triangle strip decoder.

Yukes face buffers store geometry as a single triangle strip with 0xFFFF
restart markers between sub-strips. `convert_tristrip_with_restarts`
walks the buffer, applies the alternating-winding rule, drops degenerate
triangles, and returns a flat triangle list.

Used by parser.py and parser_2k14.py during YOBJ import.
"""

import numpy as np


def convert_tristrip_with_restarts(indices: np.ndarray) -> np.ndarray:
    """
    Memory-efficient tristrip conversion that handles restart markers inline.

    Args:
        indices: uint16 array with 0xFFFF restart markers between sub-strips.

    Returns:
        uint32 triangle array of shape (n, 3). Empty array if the strip
        is too short or only contains degenerate runs.
    """
    result = []

    i = 0
    n = len(indices)

    while i < n - 2:
        idx0 = indices[i]
        idx1 = indices[i + 1]

        # Skip restart markers at start
        if idx0 == 0xFFFF or idx1 == 0xFFFF:
            i += 1
            continue

        winding = 1
        i += 2

        while i < n:
            idx2 = indices[i]

            if idx2 == 0xFFFF:
                i += 1
                break

            # Non-degenerate triangle
            if idx0 != idx1 and idx1 != idx2 and idx2 != idx0:
                if winding > 0:
                    result.append([idx0, idx1, idx2])
                else:
                    result.append([idx0, idx2, idx1])

            idx0 = idx1
            idx1 = idx2
            winding = -winding
            i += 1

    if not result:
        return np.zeros((0, 3), dtype=np.uint32)

    return np.array(result, dtype=np.uint32)
