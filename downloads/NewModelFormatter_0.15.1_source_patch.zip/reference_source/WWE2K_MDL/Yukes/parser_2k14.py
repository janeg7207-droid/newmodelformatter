"""
WWE 2K14 YOBJ Parser - Parser for WWE 2K14 era YOBJ/JBOY files.

This format has the following characteristics:
- Big-endian (JBOY magic) or little-endian (YOBJ magic)
- 184-byte mesh headers with embedded bone palette
- Position+Normal interleaved with FFFFFFFF markers
- 4 bone weights per vertex (bone_idx LE + weight BE format)
- Triangle strip face indices
- Proper vertex weight support
"""

import numpy as np
from typing import List, Optional, Tuple
import struct
from .binary_reader import BinaryReader
from .format_consts import START_OFFSET
from .structures import (
    YOBJModel, YOBJHeader, Bone, Material, Mesh, MorphTarget
)
from .tristrip import convert_tristrip_with_restarts

MESH_HEADER_SIZE = 184


def is_2k14_format(reader: BinaryReader) -> bool:
    """
    Detect if this is a WWE 2K14 era YOBJ file.
    
    2K14 format characteristics:
    - YOBJ or JBOY magic
    - 184-byte mesh headers
    - Bone palette at 0x50 with size indicator
    - Position data has format header with 0x000F00XX pattern
    - Mesh headers start at 0xB0
    """
    try:
        reader.seek(0)
        magic = reader.read_bytes(4)
        
        if magic not in (b'YOBJ', b'JBOY'):
            return False
        
        # Set endianness based on magic
        is_big = (magic == b'JBOY')
        reader.set_endian(is_big)
        
        # Check for bone palette size at 0x50
        reader.seek(0x50)
        bone_palette_size = reader.read_int32()
        
        # Valid bone palette size is typically 1-256
        if bone_palette_size < 1 or bone_palette_size > 300:
            return False
        
        # Check mesh header at 0xB0
        reader.seek(0xB0)
        padding = reader.read_int32()
        material_id = reader.read_int32()
        pos_offset = reader.read_int32()
        
        # Position offset should be a reasonable file offset (after headers, before end)
        # Typical range: 0x100 to file_size
        file_size = reader.size()
        if pos_offset < 0x100 or pos_offset >= file_size:
            return False
        
        # Check position data format header
        reader.seek(pos_offset)
        format_header = reader.read_uint32()
        
        # 2K14 format has 0x000F00XX where XX is stride (typically 0x18 = 24)
        if (format_header >> 16) == 0x000F:
            return True
        
        return False
    except:
        return False


def parse_header_2k14(reader: BinaryReader) -> YOBJHeader:
    """Parse WWE 2K14 format header."""
    reader.seek(0)
    magic = reader.read_bytes(4)
    
    # Set endianness based on magic
    is_big_endian = (magic == b'JBOY')
    reader.set_endian(is_big_endian)
    
    reader.seek(0x18)
    
    header = YOBJHeader(
        magic=magic,
        is_big_endian=is_big_endian,
        object_count=reader.read_int32(),      # 0x18
        bone_count=0,
        material_count=0,
        header_offset=0,
        skeleton_offset=0,
        texture_offset=0,
        material_offset=0,
        bone_palette_offset=0,
    )
    
    reader.skip(4)  # 0x1C: total submesh count
    header.bone_count = reader.read_int32()    # 0x20
    raw_header_offset = reader.read_int32()    # 0x24
    header.skeleton_offset = reader.read_int32()  # 0x28
    header.material_offset = reader.read_int32()  # 0x2C
    
    # In 2K14 format, the header_offset points to a bone palette section
    # The actual mesh headers start after this palette
    # Bone palette is at 0x50, and palette size is at 0x50
    reader.seek(0x50)
    bone_palette_size = reader.read_int32()  # Number of bone indices in global palette
    
    # Bone palette starts at 0x58 and each entry is 4 bytes
    # Mesh headers start after the bone palette
    # Calculate: 0x58 + (num_bones_in_palette * 4), rounded to nearest 8
    # But we need to find the actual start of mesh headers
    
    # The mesh headers start at a fixed offset after the bone palette
    # Based on analysis: bone palette at 0x58, size varies
    # Mesh header 0 starts at 0xB0 in the sample file (bone_palette_size=63 -> but only ~24 used)
    
    # Actually, look for first mesh header by finding position offset pattern
    # For now, use the formula: 0x50 + 8 + (bone_palette_size + 1) * 4 rounded up
    # But simpler: mesh headers start at raw_header_offset + START_OFFSET + bone_palette_region
    
    # The structure is:
    # 0x50: bone_palette_size (e.g., 63)
    # 0x54: unknown (often 1)
    # 0x58-0xAF: bone palette data (24 entries * 4 bytes = 96 bytes to 0xB8)
    # 0xB0: first mesh header starts
    
    # Calculate mesh header offset: 0x50 + 8 + ceil(bone_indices/8)*32 or similar
    # Simpler approach: scan for first valid mesh header pattern
    
    # For 2K14, mesh headers appear to start at 0xB0 regardless of palette size
    # The palette region is 0x58 to 0xB0 = 88 bytes = 22 bone indices.
    # NB: this is hardcoded against sample files — any file whose
    # bone_palette_size > 22 would overflow into the 0xB0 mesh-header
    # region. Emit a runtime warning so the failure mode is at least
    # diagnosable rather than silently garbled.
    if bone_palette_size > 22:
        print(f"[Yukes 2K14] Warning: large bone palette ({bone_palette_size}) may overflow hardcoded 0xB0 mesh-header offset")
    header.header_offset = 0xB0  # Fixed offset for mesh headers
    header.bone_palette_offset = 0x58  # Bone palette location
    
    header.texture_offset = header.material_offset
    
    return header


def parse_bones_2k14(reader: BinaryReader, header: YOBJHeader) -> List[Bone]:
    """Parse WWE 2K14 skeleton bone data."""
    if header.skeleton_offset == 0 or header.bone_count == 0:
        return []
    
    reader.seek(header.skeleton_offset + START_OFFSET)
    bones = []
    
    # 2K14 bones are 80 bytes each
    BONE_SIZE = 80
    
    for i in range(header.bone_count):
        start_pos = reader.position
        
        # Bone name (16 bytes)
        name = reader.read_string(16)
        
        # Transform data
        reader.skip(12)  # Unknown
        position = reader.read_float32_array(3)
        reader.skip(4)  # W component or scale
        
        # Parent index at offset 0x30 from bone start
        reader.seek(start_pos + 0x30)
        parent_idx = reader.read_int32()
        
        # Validate parent index
        if parent_idx < -1 or parent_idx >= header.bone_count or parent_idx == i:
            parent_idx = -1
        
        # Skip to next bone
        reader.seek(start_pos + BONE_SIZE)
        
        bones.append(Bone(
            name=name,
            index=i,
            parent_index=parent_idx,
            position=position,
            rotation=np.zeros(3, dtype=np.float32),
            tail=None,
        ))
    
    return bones


def parse_materials_2k14(reader: BinaryReader, header: YOBJHeader) -> List[Material]:
    """Parse WWE 2K14 material/texture data."""
    if header.material_offset == 0:
        return []
    
    reader.seek(header.material_offset + START_OFFSET)
    materials = []
    
    # Read materials until we hit invalid data
    max_materials = 100  # Safety limit
    
    for i in range(max_materials):
        name_bytes = reader.read_bytes(16)
        
        # Decode name
        try:
            name = name_bytes.decode('ascii', errors='ignore').split('\x00')[0]
        except:
            break
        
        # Valid material names should start with alphanumeric or underscore
        if not name or (not name[0].isalnum() and name[0] != '_'):
            # Rewind and stop
            reader.seek(reader.position - 16)
            break
        
        reader.skip(16)  # Material params/padding
        
        materials.append(Material(
            name=name,
            index=i,
        ))
    
    return materials


def read_position_normal_data_2k14(
    reader: BinaryReader,
    pos_offset: int,
) -> Tuple[np.ndarray, np.ndarray, int]:
    """
    Read position and normal data from 2K14 format.
    
    Format at pos_offset:
    - Header: format_info (4 bytes) + vertex_count (4 bytes) + sub_pointer (4 bytes) = 12 bytes
    - First vertex: 24 bytes (position 12 + normal 12)
    - Subsequent: 28 bytes (marker 4 + position 12 + normal 12)
    
    Returns: (positions, normals, vertex_count)
    """
    import math
    
    def is_valid_position(pos):
        """Check if position values are valid (not NaN/Inf and within reasonable range)"""
        for v in pos:
            if math.isnan(v) or math.isinf(v) or abs(v) > 10000:
                return False
        return True
    
    reader.seek(pos_offset)  # Raw offset (no START_OFFSET for internal data)
    
    # Read header (12 bytes)
    format_info = reader.read_uint32()  # 0x000F00XX where XX is stride
    header_vertex_count = reader.read_uint32()  # Vertex count hint
    reader.skip(4)  # Sub-pointer (skip)
    
    positions = []
    normals = []
    
    # Read first vertex (no marker)
    pos = reader.read_float32_array(3)
    norm = reader.read_float32_array(3)
    if is_valid_position(pos):
        positions.append(pos)
        normals.append(norm)
    
    # Read remaining vertices (with FFFFFFFF marker prefix)
    for i in range(1, 10000):  # Safety limit
        marker = reader.read_uint32()
        
        if marker != 0xFFFFFFFF:
            # End of position data
            break
        
        pos = reader.read_float32_array(3)
        norm = reader.read_float32_array(3)
        
        # Stop if we hit invalid data
        if not is_valid_position(pos):
            break
            
        positions.append(pos)
        normals.append(norm)
    
    return (
        np.array(positions, dtype=np.float32),
        np.array(normals, dtype=np.float32),
        len(positions)
    )


def read_weight_data_2k14(
    reader: BinaryReader,
    weight_offset: int,
    vertex_count: int,
    max_influences: int = 4
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Read vertex weight data from 2K14 format.
    
    Format at weight_offset:
    - Header: 8 bytes (skip)
    - Per vertex: 4 weight slots, each 8 bytes:
      - Bone index: 4 bytes (little-endian)
      - Weight: 4 bytes (big-endian float)
    
    If mixed-endian weights don't validate, falls back to native endianness.
    
    Returns: (bone_indices, bone_weights)
    """
    reader.seek(weight_offset + 8)  # Skip 8-byte header
    weight_data_start = reader.position
    
    bone_indices = np.zeros((vertex_count, max_influences), dtype=np.uint32)
    bone_weights = np.zeros((vertex_count, max_influences), dtype=np.float32)
    
    # Save original endianness
    original_endian = reader._endian
    
    # Try mixed endianness first (LE index + BE weight)
    for v in range(vertex_count):
        for w in range(max_influences):
            # Bone index is little-endian
            reader.set_endian(False)
            bone_idx = reader.read_uint32()
            
            # Weight is big-endian
            reader.set_endian(True)
            weight = reader.read_float32()
            
            # Filter padding values (0xFF, 0xFF000000, 0xFFFFFFFF)
            if bone_idx == 0xFF or bone_idx == 0xFF000000 or bone_idx == 0xFFFFFFFF:
                bone_idx = 0
                weight = 0.0
            elif bone_idx > 1000:  # Invalid bone index
                bone_idx = 0
                weight = 0.0
            
            bone_indices[v, w] = bone_idx
            bone_weights[v, w] = weight
    
    # Restore endianness
    reader._endian = original_endian
    
    # Validate weights
    valid_weights = True
    nonzero_verts = np.any(bone_weights > 0.0001, axis=1)
    if np.any(nonzero_verts):
        weight_sums = bone_weights[nonzero_verts].sum(axis=1)
        max_weight = bone_weights.max()
        
        if max_weight > 2.0 or np.mean(weight_sums) < 0.1 or np.mean(weight_sums) > 2.0:
            valid_weights = False
            print(f"[Yukes 2K14] Mixed-endian weights invalid (max={max_weight:.3f}, mean_sum={np.mean(weight_sums):.3f}), trying native endian...")
    
    # If mixed endian failed, retry with native endianness
    if not valid_weights:
        reader.seek(weight_data_start)
        reader.set_endian(original_endian)
        bone_indices = np.zeros((vertex_count, max_influences), dtype=np.uint32)
        bone_weights = np.zeros((vertex_count, max_influences), dtype=np.float32)
        
        for v in range(vertex_count):
            for w in range(max_influences):
                bone_idx = reader.read_uint32()
                weight = reader.read_float32()
                
                if bone_idx == 0xFF or bone_idx == 0xFF000000 or bone_idx == 0xFFFFFFFF:
                    bone_idx = 0
                    weight = 0.0
                elif bone_idx > 1000:
                    bone_idx = 0
                    weight = 0.0
                
                bone_indices[v, w] = bone_idx
                bone_weights[v, w] = weight
        
        reader._endian = original_endian
    
    # Normalize weights per vertex
    weight_sums = bone_weights.sum(axis=1, keepdims=True)
    nonzero_mask = weight_sums > 0.0001
    if np.any(nonzero_mask):
        bone_weights = np.where(nonzero_mask, bone_weights / np.where(nonzero_mask, weight_sums, 1.0), bone_weights)
    
    return bone_indices, bone_weights


def read_uv_data_2k14(
    reader: BinaryReader,
    uv_offset: int,
    vertex_count: int,
    flip_uvs: bool = True
) -> np.ndarray:
    """
    Read UV data from 2K14 format.
    
    Format at uv_offset:
    - Header: 8 bytes (skip)
    - Per vertex: 8 bytes (2 floats)
    """
    reader.seek(uv_offset + 8)  # Skip 8-byte header
    
    uvs = reader.read_vec2_array(vertex_count)
    
    if flip_uvs:
        uvs[:, 1] = 1.0 - uvs[:, 1]
    
    return uvs


def read_face_data_2k14(
    reader: BinaryReader,
    face_offset: int,
) -> np.ndarray:
    """
    Read face index data from 2K14 format.
    
    Format at face_offset:
    - Header: 12 bytes (2 floats + format info)
    - Index count: 4 bytes
    - Data offset pointer: 4 bytes (skip)
    - Triangle strip indices
    
    Returns: Face array (Nx3 triangles)
    """
    reader.seek(face_offset)
    
    # Read header
    reader.skip(12)  # Skip 2 floats (bounding?) + format info
    index_count = reader.read_uint32()
    reader.skip(4)  # Skip data offset pointer
    
    # Read face indices
    if index_count <= 0 or index_count > 100000:
        return np.zeros((0, 3), dtype=np.uint32)
    
    indices = reader.read_uint16_array(index_count)
    
    # Convert triangle strip to triangle list
    faces = convert_tristrip_with_restarts(indices)
    
    return faces


def parse_mesh_2k14(
    reader: BinaryReader,
    mesh_idx: int,
    mesh_offset: int,
    materials: List[Material],
    bones: List[Bone],
    flip_uvs: bool = True,
) -> Mesh:
    """Parse a single WWE 2K14 mesh."""
    
    reader.seek(mesh_offset)
    
    # Read mesh header (184 bytes)
    reader.skip(4)  # Padding/flags
    material_id = reader.read_int32()  # 0x04
    pos_offset = reader.read_int32()   # 0x08
    weight_offset = reader.read_int32()  # 0x0C
    uv_offset = reader.read_int32()    # 0x10
    face_header_offset = reader.read_int32()  # 0x14 (not used)
    vertex_count_header = reader.read_int32()  # 0x18 (not reliable)
    
    # Shader name (12 bytes at 0x1C)
    shader_name = reader.read_string(12)
    
    reader.skip(4)  # Padding
    face_count = reader.read_int32()  # 0x2C
    reader.skip(8)  # Unknown
    shader_params_offset = reader.read_int32()  # 0x38
    face_data_offset = reader.read_int32()  # 0x3C (actual face data!)
    bone_palette_size = reader.read_int32()  # 0x40
    reader.skip(4)  # Padding
    
    # Bounding box (4 floats at 0x48)
    bbox = reader.read_float32_array(4)
    
    # Additional fields
    reader.skip(8)  # 0x58, 0x5C
    actual_vertex_count = reader.read_int32()  # 0x60
    
    # Bone palette (embedded in header at 0x64, up to 21 entries)
    # CRITICAL: preserve ALL entries positionally - don't filter out high values
    # Weight bone indices reference positions in this palette
    bone_palette = []
    for i in range(21):
        bp_idx = reader.read_int32()
        bone_palette.append(bp_idx)
    
    bone_palette_arr = np.array(bone_palette, dtype=np.uint32) if bone_palette else None
    
    # Get material name
    if material_id < len(materials):
        mat_name = materials[material_id].name
        mesh_name = mat_name
    else:
        mat_name = f"Material_{material_id}"
        mesh_name = f"Mesh_{mesh_idx}"
    
    # Read position and normal data (uses raw offsets internally)
    positions, normals, vertex_count = read_position_normal_data_2k14(
        reader, pos_offset
    )
    
    # Read weight data
    bone_indices, bone_weights = read_weight_data_2k14(
        reader, weight_offset, vertex_count, max_influences=4
    )
    
    # Read UV data
    uvs = read_uv_data_2k14(reader, uv_offset, vertex_count, flip_uvs)
    
    # Read face data
    faces = read_face_data_2k14(reader, face_data_offset)
    
    return Mesh(
        index=mesh_idx,
        name=mesh_name,
        shader_type=shader_name,
        material_index=material_id,
        positions=positions,
        normals=normals,
        uvs=uvs,
        faces=faces,
        colors=None,
        uvs2=None,
        morph_targets=[],
        bone_indices=bone_indices,
        bone_weights=bone_weights,
        bone_palette=bone_palette_arr,
        max_influences=4,
    )


def parse_yobj_2k14(
    filepath: str,
    flip_uvs: bool = True,
) -> YOBJModel:
    """
    Parse WWE 2K14 era YOBJ file.
    
    Args:
        filepath: Path to .yobj/.jboy file
        flip_uvs: Flip V coordinate (1.0 - v)
        
    Returns:
        YOBJModel with all parsed data
    """
    with BinaryReader(filepath) as reader:
        # Parse header
        header = parse_header_2k14(reader)
        
        # Parse bones and materials
        bones = parse_bones_2k14(reader, header)
        materials = parse_materials_2k14(reader, header)
        
        # Parse meshes
        meshes = []
        
        for i in range(header.object_count):
            mesh_offset = header.header_offset + i * MESH_HEADER_SIZE
            
            try:
                mesh = parse_mesh_2k14(
                    reader, i, mesh_offset,
                    materials, bones,
                    flip_uvs=flip_uvs,
                )
                meshes.append(mesh)
            except Exception as e:
                print(f"Warning: Failed to parse mesh {i}: {e}")
                continue
        
        return YOBJModel(
            version="2k14",
            bones=bones,
            materials=materials,
            meshes=meshes,
            global_bone_palette=None,
        )
