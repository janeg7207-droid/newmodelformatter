"""Yukes-era YOBJ/JBOY import/export — bundled sub-module of WWE2K_MDL.

Covers the pre-VC-engine WWE 2K family (SVR06 through WWE 2K19) plus the
SVR06/07 era PS2/PSP variants. The main WWE2K_MDL addon handles VC-engine
MCD/MDL (2K20+); this sub-module handles the older Yukes-engine files.

Registered alongside the parent addon — no separate bl_info or install
needed. File > Import/Export > "WWE 2K Yukes-era Model (.yobj/.jboy)".
"""

import bpy
from bpy.props import StringProperty, BoolProperty, EnumProperty, CollectionProperty
from bpy_extras.io_utils import ImportHelper, ExportHelper
from pathlib import Path


class YOBJ_OT_Import(bpy.types.Operator, ImportHelper):
    """Import Yukes YOBJ/JBOY Model"""
    bl_idname = "import_mesh.yobj"
    bl_label = "Import YOBJ"
    bl_options = {'UNDO', 'PRESET'}

    filename_ext = ".yobj"

    filter_glob: StringProperty(
        default="*.yobj;*.jboy;*.pac",
        options={'HIDDEN'},
    )

    files: CollectionProperty(type=bpy.types.PropertyGroup)

    import_skeleton: BoolProperty(
        name="Import Skeleton",
        description="Import armature with bones",
        default=True,
    )

    import_weights: BoolProperty(
        name="Import Weights",
        description="Import vertex weights and groups",
        default=True,
    )

    import_morphs: BoolProperty(
        name="Import Morph Targets",
        description="Import shape keys (blend shapes)",
        default=True,
    )

    import_vertex_colors: BoolProperty(
        name="Import Vertex Colors",
        description="Import vertex color data",
        default=True,
    )

    flip_uvs: BoolProperty(
        name="Flip UVs Vertically",
        description="Flip V coordinate (1.0 - v)",
        default=True,
    )

    alternate_uv_stride: BoolProperty(
        name="Alternate UV Stride",
        description="Use 16-byte UV stride (for hair meshes)",
        default=False,
    )

    convert_shapes_to_facs: BoolProperty(
        name="Convert Shape Keys to FACS",
        description=("Rename 2K15-2K19 semantic shape keys (BrowInn_L_Up, "
                     "Eye_L_Blink, LipUpr_L_Up, …) into the 2K25/2K26 FACS "
                     "Action Unit naming (au001_l, au045_l, au010_l, …). "
                     "Use this when porting older characters forward; the "
                     "geometry deltas are preserved, only the names change "
                     "(1:1 mappings) or are split across multiple AUs with "
                     "scaled deltas (1:N mappings). Unmapped shapes pass "
                     "through with their original 2K19 names so nothing is "
                     "silently lost"),
        default=False,
    )

    def execute(self, context):
        from . import importer
        from . import pac_reader
        import os
        import tempfile

        folder = Path(self.filepath).parent

        for file_elem in self.files:
            filepath = folder / file_elem.name

            # Detect container by magic. PAC (Yukes-era) and HSPC
            # (WWE 2K17+) hold one-or-many YOBJ/JBOY blobs; we extract
            # each blob to a temp file (the parser uses mmap on a real
            # file path) and import them in container order. Each
            # imported root carries `yobj_pac_source` + `yobj_pac_index`
            # custom props for traceability.
            try:
                with open(filepath, 'rb') as f:
                    head = f.read(4)
            except OSError as e:
                self.report({'ERROR'}, f"Cannot read {file_elem.name}: {e}")
                return {'CANCELLED'}

            if head in (b'PAC ', b'HSPC', b'EPK8'):
                with open(filepath, 'rb') as f:
                    container = f.read()
                blobs = pac_reader.extract_yobj_blobs(container)
                if not blobs:
                    # Empty result — figure out why and tell the user.
                    if head in (b'HSPC', b'EPK8'):
                        # HSPC needs Oodle. Most likely the DLL is missing.
                        from . import oodle
                        status = oodle.get_oodle_status()
                        oodl_blocks = pac_reader.map_oodl_blocks(container)
                        if not status['dll_loaded']:
                            search_summary = " | ".join(status['searched_paths'])
                            self.report({'ERROR'},
                                        f"{file_elem.name}: HSPC container with "
                                        f"{len(oodl_blocks)} Oodle/Kraken blocks. "
                                        f"oo2core_6/7/8/9_win64.dll not found. "
                                        f"Drop it into one of: {search_summary} "
                                        f"or set OODLE_DLL_PATH env var.")
                        else:
                            # DLL is there, decompression presumably worked,
                            # but no YOBJ/JBOY survived validation. Dump
                            # everything we know about the sub-files so the
                            # user can paste the console output.
                            print(f"\n[YOBJ] No models found in {file_elem.name}.")
                            print(f"[YOBJ] Decompressed sub-file dump follows so we can see what's actually inside:\n")
                            pac_reader.diagnose_hspc(container)
                            self.report({'WARNING'},
                                        f"{file_elem.name}: HSPC decoded "
                                        f"({len(oodl_blocks)} blocks via "
                                        f"{os.path.basename(status['dll_path'])}) "
                                        f"but no YOBJ/JBOY models survived "
                                        f"validation. See console for sub-file dump.")
                        continue
                    # PAC path diagnostic (unchanged)
                    version = pac_reader.detect_pac_version(container)
                    bpe_blocks = pac_reader.map_bpe_blocks(container)
                    if bpe_blocks:
                        total_decoded = sum(b['decoded_size'] for b in bpe_blocks)
                        self.report({'WARNING'},
                                    f"{file_elem.name}: PAC v{version}, "
                                    f"{len(bpe_blocks)} BPE blocks decoded "
                                    f"({total_decoded:,} bytes), but no "
                                    f"YOBJ/JBOY models found — this PAC "
                                    f"likely contains other asset types.")
                    else:
                        self.report({'WARNING'},
                                    f"{file_elem.name}: PAC v{version} found "
                                    f"but no YOBJ/JBOY blobs extracted "
                                    f"(unknown layout).")
                    continue

                pac_basename = os.path.splitext(file_elem.name)[0]
                tmp_dir = tempfile.mkdtemp(prefix='yobj_pac_')
                try:
                    for i, blob in enumerate(blobs):
                        tmp_path = os.path.join(tmp_dir, f"{pac_basename}_part{i}.yobj")
                        with open(tmp_path, 'wb') as f:
                            f.write(blob)
                        result = importer.import_yobj(
                            tmp_path,
                            import_skeleton=self.import_skeleton,
                            import_weights=self.import_weights,
                            import_morphs=self.import_morphs,
                            import_vertex_colors=self.import_vertex_colors,
                            flip_uvs=self.flip_uvs,
                            alternate_uv_stride=self.alternate_uv_stride,
                        )
                        if not result:
                            self.report({'ERROR'},
                                        f"Failed to import {pac_basename} part {i}")
                            return {'CANCELLED'}

                        # Tag the most recently active object (armature root
                        # of this just-imported model) so users can trace it
                        # back to the source PAC + entry index.
                        active = context.view_layer.objects.active
                        if active is not None:
                            active['yobj_pac_source'] = str(filepath.name)
                            active['yobj_pac_index']  = i

                        # Optional 2K19→FACS shape-key rename pass. Runs
                        # against every mesh child of the just-imported
                        # armature root so multi-mesh characters (head +
                        # body + accessories) all get converted in one go.
                        if self.convert_shapes_to_facs:
                            _convert_imported_shapes(active, self.report)
                finally:
                    # Best-effort cleanup; if a file is still mmap-locked
                    # we leave it for the OS to clean up at exit.
                    try:
                        for entry in os.listdir(tmp_dir):
                            try:
                                os.remove(os.path.join(tmp_dir, entry))
                            except OSError:
                                pass
                        os.rmdir(tmp_dir)
                    except OSError:
                        pass
                continue

            # Plain YOBJ/JBOY file — original path
            result = importer.import_yobj(
                str(filepath),
                import_skeleton=self.import_skeleton,
                import_weights=self.import_weights,
                import_morphs=self.import_morphs,
                import_vertex_colors=self.import_vertex_colors,
                flip_uvs=self.flip_uvs,
                alternate_uv_stride=self.alternate_uv_stride,
            )

            if not result:
                self.report({'ERROR'}, f"Failed to import {file_elem.name}")
                return {'CANCELLED'}

            # Optional 2K19→FACS shape-key rename pass — same as the
            # PAC path above, applied to whatever the importer leaves
            # active (the armature root of the just-imported model).
            if self.convert_shapes_to_facs:
                active = context.view_layer.objects.active
                if active is not None:
                    _convert_imported_shapes(active, self.report)

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        box = layout.box()
        box.label(text="Import Options", icon='IMPORT')
        box.prop(self, "import_skeleton")
        box.prop(self, "import_weights")
        box.prop(self, "import_morphs")
        box.prop(self, "import_vertex_colors")
        
        box = layout.box()
        box.label(text="UV Options", icon='UV')
        box.prop(self, "flip_uvs")
        box.prop(self, "alternate_uv_stride")

        box = layout.box()
        box.label(text="Port Forward (15-19 → 25/26)", icon='SHAPEKEY_DATA')
        box.prop(self, "convert_shapes_to_facs")


class YOBJ_OT_Export(bpy.types.Operator, ExportHelper):
    """Export Yukes YOBJ/JBOY Model"""
    bl_idname = "export_mesh.yobj"
    bl_label = "Export YOBJ"
    bl_options = {'UNDO', 'PRESET'}

    filename_ext = ".yobj"

    filter_glob: StringProperty(
        default="*.yobj;*.jboy",
        options={'HIDDEN'},
    )

    export_selected: BoolProperty(
        name="Selected Only",
        description="Export only selected objects",
        default=False,
    )

    export_skeleton: BoolProperty(
        name="Export Skeleton",
        description="Export armature with bones",
        default=True,
    )

    export_weights: BoolProperty(
        name="Export Weights",
        description="Export vertex weights",
        default=True,
    )

    export_morphs: BoolProperty(
        name="Export Morph Targets",
        description="Export shape keys (blend shapes)",
        default=True,
    )

    format_version: EnumProperty(
        name="Game Format",
        description="On-disk format to write. Auto detects from imported file's "
                    "stored hints; falls back to 2K15-19 (v3) for new content.",
        items=[
            ('AUTO', "Auto (from imported file)",
             "Use format hints stored on the armature when this model was imported"),
            ('V3',   "WWE 2K15-2K19 (v3, JBOY/YOBJ BE)",
             "184-byte mesh stride, full morph + palette tables"),
            ('V0',   "SVR07-WWE13 (v0, JBOY BE)",
             "180-byte mesh stride, multi-section faces, no morph table"),
        ],
        default='AUTO',
    )

    use_jboy_magic: BoolProperty(
        name="Use JBOY Magic",
        description="Use JBOY magic bytes (the SVR-era and console default). "
                    "Uncheck to write YOBJ magic instead.",
        default=True,
    )

    def execute(self, context):
        from . import exporter
        from .format_consts import MAGIC_JBOY, MAGIC_YOBJ, VERSION_LEGACY

        if self.export_selected:
            objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        else:
            objects = [obj for obj in context.scene.objects if obj.type == 'MESH']

        if not objects:
            self.report({'ERROR'}, "No mesh objects to export")
            return {'CANCELLED'}

        armature = None
        if self.export_skeleton:
            for obj in context.scene.objects:
                if obj.type == 'ARMATURE':
                    armature = obj
                    break

        # Resolve format settings — armature custom props win in AUTO mode.
        version = 3
        magic = MAGIC_JBOY if self.use_jboy_magic else MAGIC_YOBJ
        big_endian = True
        if self.format_version == 'AUTO' and armature is not None:
            version = int(armature.get('yobj_version', 3))
            stored_magic = armature.get('yobj_magic', None)
            if stored_magic:
                magic = stored_magic.encode('ascii') if isinstance(stored_magic, str) else bytes(stored_magic)
            big_endian = bool(armature.get('yobj_big_endian', True))
        elif self.format_version == 'V0':
            version = VERSION_LEGACY
        elif self.format_version == 'V3':
            version = 3

        try:
            result = exporter.export_yobj(
                self.filepath,
                objects,
                armature if self.export_weights else None,
                version=version,
                magic=magic,
                big_endian=big_endian,
            )
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.report({'ERROR'}, f"Export failed: {e}")
            return {'CANCELLED'}

        if result:
            ver_label = 'v0 (SVR-era)' if version == VERSION_LEGACY else 'v3 (2K15-19)'
            self.report({'INFO'}, f"Exported {len(objects)} meshes [{ver_label}] to {self.filepath}")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, "Export failed")
            return {'CANCELLED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        box = layout.box()
        box.label(text="Export Options", icon='EXPORT')
        box.prop(self, "export_selected")
        box.prop(self, "export_skeleton")
        box.prop(self, "export_weights")
        box.prop(self, "export_morphs")

        box = layout.box()
        box.label(text="Format Options", icon='FILE')
        box.prop(self, "format_version")
        box.prop(self, "use_jboy_magic")


def menu_func_import(self, context):
    self.layout.operator(YOBJ_OT_Import.bl_idname, text="WWE 2K Yukes-era Model (.yobj/.jboy/.pac)")


def menu_func_export(self, context):
    self.layout.operator(YOBJ_OT_Export.bl_idname, text="WWE 2K Yukes-era Model (.yobj/.jboy)")


def _convert_imported_shapes(root, report_fn):
    """Walk a just-imported armature root, find every mesh child, and run
    the 2K19→FACS shape-key conversion on each. `root` may be the armature
    itself or any object the importer left as active; both branches handle
    multi-mesh models cleanly. `report_fn` is the operator's `self.report`
    callable so messages surface in the Blender info area."""
    if root is None:
        return
    from . import shapekey_facs_map as facs

    targets = []
    if root.type == 'MESH':
        targets.append(root)
    if root.type == 'ARMATURE':
        targets.extend(c for c in root.children if c.type == 'MESH')
    # Also catch children of mesh roots, in case the importer changes the
    # active-object convention later.
    for c in getattr(root, 'children', ()):
        if c.type == 'MESH' and c not in targets:
            targets.append(c)

    total_ren = total_split = 0
    all_unmapped = set()
    all_collisions = set()
    for obj in targets:
        rep = facs.convert_object_shapes_to_facs(obj)
        total_ren   += rep['renamed']
        total_split += rep['split']
        all_unmapped.update(rep['unmapped'])
        all_collisions.update(rep['collisions'])

    if total_ren or total_split:
        msg = (f"FACS conversion: {total_ren} renamed, "
               f"{total_split} split across multiple AUs")
        if all_unmapped:
            msg += f" — {len(all_unmapped)} shape(s) had no FACS mapping"
        if all_collisions:
            msg += f" — merged into {len(all_collisions)} existing AU(s)"
        report_fn({'INFO'}, msg)


class YOBJ_OT_ConvertShapesToFACS(bpy.types.Operator):
    """Rename 2K15-2K19 semantic shape keys on the selected mesh(es) to the
    2K25/2K26 FACS Action Unit naming. Runs the same conversion the import
    operator's checkbox does, against meshes that are already in the scene."""
    bl_idname = "object.yobj_convert_shapes_to_facs"
    bl_label = "Convert Shape Keys: 2K19 → FACS"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' and o.data.shape_keys is not None
                   for o in context.selected_objects)

    def execute(self, context):
        from . import shapekey_facs_map as facs
        meshes = [o for o in context.selected_objects
                  if o.type == 'MESH' and o.data.shape_keys is not None]
        if not meshes:
            self.report({'WARNING'}, "No selected mesh has shape keys.")
            return {'CANCELLED'}

        ren = split = 0
        unmapped = set()
        collisions = set()
        for obj in meshes:
            rep = facs.convert_object_shapes_to_facs(obj)
            ren   += rep['renamed']
            split += rep['split']
            unmapped.update(rep['unmapped'])
            collisions.update(rep['collisions'])

        if ren == 0 and split == 0:
            self.report({'INFO'},
                        "Nothing to convert (no 2K19-named shape keys found).")
            return {'FINISHED'}
        msg = f"FACS conversion: {ren} renamed, {split} split"
        if unmapped:
            msg += f", {len(unmapped)} unmapped"
        if collisions:
            msg += f", {len(collisions)} merged"
        self.report({'INFO'}, msg)
        return {'FINISHED'}


from .clone_material import YOBJ_OT_CloneMaterial

classes = (
    YOBJ_OT_Import,
    YOBJ_OT_Export,
    YOBJ_OT_ConvertShapesToFACS,
    YOBJ_OT_CloneMaterial,
)


# register/unregister are per-class defensive (matching the other addon
# modules): a machine with a second copy of this addon enabled (e.g. a
# WWE2K_MDL_pre_audit_backup_* folder) registers these idnames first, our
# register partially fails, and an unguarded unregister then raised
# "missing bl_rna" — which wedged addon_utils.enable's unregister-first
# path and made the addon impossible to (re-)enable from Preferences.

def register():
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except Exception as e:
            print(f"[Yukes] Failed to register {cls.__name__}: {e}")
    try:
        bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
        bpy.types.TOPBAR_MT_file_export.append(menu_func_export)
    except Exception as e:
        print(f"[Yukes] Failed to append menu entries: {e}")


def unregister():
    try:
        bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
        bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    except Exception as e:
        print(f"[Yukes] Failed to remove menu entries: {e}")
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as e:
            print(f"[Yukes] Failed to unregister {cls.__name__}: {e}")
