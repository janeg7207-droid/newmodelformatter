"""Centralized debug logger for the WWE2K_MDL addon.

Keeps the Blender console clean by default: dlog() is silent unless verbose
is on; dwarn()/derror() always print. Enable verbose at runtime via
set_verbose(True), or set the WWE2K_MDL_VERBOSE env var before launching.
"""

import os
import sys

_VERBOSE = os.environ.get('WWE2K_MDL_VERBOSE', '0').lower() in ('1', 'true', 'yes')


def set_verbose(on):
    """Toggle verbose console logging at runtime."""
    global _VERBOSE
    _VERBOSE = bool(on)


def is_verbose():
    return _VERBOSE


def dlog(*args, **kwargs):
    """Diagnostic log — silent by default. Use for status/progress/counts
    that helped while developing but isn't useful for end users."""
    if _VERBOSE:
        print(*args, **kwargs)


def dwarn(*args, **kwargs):
    """Warning — always prints. Use for non-fatal anomalies the user
    should know about (e.g. 'companion file missing, skipping')."""
    print(*args, **kwargs)


def derror(*args, **kwargs):
    """Error — always prints. Use for caught exceptions and hard
    failures the user needs to know about for bug reports."""
    print(*args, **kwargs)
