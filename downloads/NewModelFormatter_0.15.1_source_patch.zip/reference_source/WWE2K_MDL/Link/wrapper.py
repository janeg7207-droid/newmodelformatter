import ctypes
import os
import numpy as np
# WARNING: stateful global — call use_lib_for_target() (export) or
# use_lib_for_version() (import) BEFORE constructing ExternalLibary or touching
# the cmesh / cmodellib staticmethods, else calls route silently to whichever
# DLL was last selected (or None on fresh load). Every staticmethod resolves
# `lib` at call time, so wrong-way routing mid-pipeline hits the wrong DLL with
# no error.
global lib
lib = None


# ============================================================================
# numpy-backed ctypes pass-through
#
# Replaces the per-call ``(ctypes.c_type * N)(*python_list)`` per-element copy.
# ``np.ascontiguousarray`` builds a contiguous C-layout array in one numpy-side
# pass (~10-50x faster on character meshes); ``.ctypes.data_as(POINTER(...))``
# points into that already-correct layout — zero further copies.
#
# LIFETIME RULE (do not violate): every caller MUST bind the numpy array to a
# named local that stays in scope across the DLL call. CPython frees temporaries
# at end-of-expression, so the one-liner
# ``lib.func(np.ascontiguousarray(...).ctypes.data_as(...))`` is a
# use-after-free — the array is unreferenced before the C call returns. The
# helpers return BOTH array (keep alive) AND pointer; store both in named
# locals before the call. See set_data / set_normals for the canonical pattern.
#
# The DLLs are synchronous setters — every set_* copies the buffer into the
# cmesh struct before returning, so the backing memory can be freed at function
# scope (no need to keep it alive past the call).
# ============================================================================

def _as_c_float_ptr(seq):
    """Return (numpy_array, c_float_pointer) for a sequence of floats.
    Caller must keep numpy_array alive until the DLL call returns (see
    LIFETIME RULE above) — the pointer alone is not enough.
    """
    arr = np.ascontiguousarray(seq, dtype=np.float32)
    return arr, arr.ctypes.data_as(ctypes.POINTER(ctypes.c_float))


def _as_c_int_ptr(seq):
    """Return (numpy_array, c_int_pointer) for a sequence of signed ints."""
    arr = np.ascontiguousarray(seq, dtype=np.int32)
    return arr, arr.ctypes.data_as(ctypes.POINTER(ctypes.c_int))


def _as_c_uint32_ptr(seq):
    """Return (numpy_array, c_uint32_pointer) for a sequence of u32 indices."""
    arr = np.ascontiguousarray(seq, dtype=np.uint32)
    return arr, arr.ctypes.data_as(ctypes.POINTER(ctypes.c_uint32))

# ============================================================================
# Dual-DLL routing
#
# Two native libraries ship:
#   - vcmodel.dll       (modern)  - WWE 2K26 (v2.15) + new 2K20/2K21 support
#   - vcmodellegacy.dll (legacy)  - frozen v1.9.6, handles 2K22-2K25
#                                   (v2.5 / v2.8 / v2.9)
#
# Each session picks the DLL up-front: import -> use_lib_for_version(),
# export -> use_lib_for_target(). All cmesh / cmodellib calls use the global
# `lib`; ExternalLibary captures it at construction, so create it AFTER a
# use_lib_* helper.
# ============================================================================

_legacy_lib = None
_modern_lib = None

# Compile-target enum values (from interface_save.py) that route to MODERN.
# Anything else routes to LEGACY.
#
# 2K26 (option_vcexport_26), 2K25 (option_vcexport_25) AND 2K24 (option_vcexport_24)
# all use the MODERN DLL's native serializers (CModelSerializer_2_15 / _2_9 / the base
# CModelSerializer for 0x28). The LEGACY DLL's 2K25 AND 2K24 writers are BOTH BROKEN —
# they emit undersized files that NEITHER DLL (nor the game) can read back.
#   - 2K25 PROVEN: legacy 117612B src -> 48808B out, re-import 0 meshes; modern -> 117604B
#     out, re-import matches (both DLLs load it).
#   - 2K24 PROVEN (2026-06-07): legacy 0x28 writer -> 94272B out, re-import 0 meshes;
#     modern 0x28 (CModelSerializer) -> 350144B out, re-import MATCH. Validated 72/72 on a
#     stratified corpus sample (18 categories, 1..327 meshes, 62..89557 verts) — every file
#     MATCH with vertex totals byte-equal. So 2K24 export now routes to MODERN.
# 2K22 (0x20) / 2K23 (0x25) have NO modern serializer (no CModelSerializer_2_0/_2_3 wired in
# saveModelToFile) and NO addon export target — they are import-only (re-export = upgrade to
# a 2K24+ target). Leave them off this set.
_MODERN_TARGETS = {"option_vcexport_26", "option_vcexport_25", "option_vcexport_24"}

# Canonical MDL version bytes (from VCModel src/meshtags.h enModelFormats):
#   0x1D = 2K20  | 0x1F = 2K21  | 0x20 = 2K22
#   0x25 = 2K23  | 0x28 = 2K24  | 0x29 = 2K25
#   0x2F = 2K26
#
# IMPORT-path routing only (feeds _is_modern_version via use_lib_for_version;
# EXPORT uses the separate _MODERN_TARGETS set). The modern VCModel.dll contains
# real CSkinModel_2_0/_2_5/_2_8/_2_9/_2_15 readers (modelfile.cpp:218 switch on
# m_version; 0x20->CSkinModel_2_0, 0x25->CSkinModel_2_5) and ALL versions now
# import via modern. Proven 2026-06-07:
#   - Geometry agreement modern-vs-legacy: 2K24 16,866 + 2K25 19,072 + 2K23 3,127
#     + 2K22 13,452, zero divergences.
#   - DEEP full-surface byte A/B (bones+normals+tris+UV+colors+blendshape deltas+
#     skin weights+face groups+materials+AtPt+string table) modern-vs-legacy:
#     2K23 ENTIRE corpus 3,098/3,098 IDENTICAL; 2K22 3,400 incl. 130-bone base
#     models + 8-FACS faces IDENTICAL. (_p1val/deep_ab.py, deep_sweep.py)
# 2K22(0x20)/2K23(0x25) were PREVIOUSLY routed to LEGACY out of pure caution (the
# exclusion was justified by EXPORT limits that don't apply to import). Switching
# them to modern is LOSSLESS (the byte-consuming readers live in the shared
# CSerializedModel base — legacy skips the exact same WDF/HPL/MBfD-tail substreams)
# and ADDS the modern-only lanes legacy stubs to NULL: tangents / PackedTBN preserve
# hashes (fixes the upgrade-to-2K24 path: 113/113 EXACT, was 89), multi-material
# face groups, all vertex-color layers, authoritative getModelFileVersion.
# 2K22/2K23 stay IMPORT-ONLY for EXPORT (no native serializer — _2_5/_2_8 are
# declared-only shells; the working path is import -> upgrade-to-2K24 target).
_MODERN_VERSIONS = {
    0x1D,  # 2K20
    0x1F,  # 2K21
    0x20,  # 2K22 — import via modern (.mdl/v2.00; deep-A/B byte-identical to legacy)
    0x25,  # 2K23 — import via modern (.mdl/v2.05; full corpus deep-A/B identical)
    0x28,  # 2K24 — import via modern (.mdl/v2.08; corpus-verified)
    0x29,  # 2K25 — import via modern (.mcd/v2.09; data-bleed fixed + corpus-verified)
    0x2F,  # 2K26
}

def _is_modern_version(v):
    return v in _MODERN_VERSIONS


def _resolve_dll_path(filename):
    pyPath = os.path.abspath(__file__)
    return os.path.join(os.path.dirname(pyPath), filename)


def GetDLLPath():
    """Backward-compat: returns the modern DLL path."""
    return _resolve_dll_path("VCModel.dll")


def _load_dll(filename, optional=False):
    path = _resolve_dll_path(filename)
    if not os.path.exists(path):
        if optional:
            return None
        raise FileNotFoundError(f"Required DLL not found: {path}")
    return _GracefulDLL(ctypes.CDLL(path))


def _ensure_libs_loaded():
    """Lazy-load both DLLs on first use. Modern is required; legacy is optional
    (if not installed, legacy targets fall back to modern)."""
    global _modern_lib, _legacy_lib
    if _modern_lib is None:
        _modern_lib = _load_dll("VCModel.dll", optional=False)
    if _legacy_lib is None:
        _legacy_lib = _load_dll("VCModelLegacy.dll", optional=True)


def use_modern_lib():
    """Activate the modern DLL (vcmodel.dll) for subsequent calls."""
    global lib
    _ensure_libs_loaded()
    lib = _modern_lib


def use_legacy_lib():
    """Activate the legacy DLL (vcmodellegacy.dll) for subsequent calls.
    Falls back to modern if legacy isn't installed alongside the addon."""
    global lib
    _ensure_libs_loaded()
    lib = _legacy_lib if _legacy_lib is not None else _modern_lib


def use_lib_for_target(compile_target):
    """Route by export target enum (e.g. 'option_vcexport_26')."""
    if compile_target in _MODERN_TARGETS:
        use_modern_lib()
    else:
        use_legacy_lib()


def use_lib_for_version(file_version):
    """Route by detected MDL version byte (e.g. 0x29 for 2K25, 0x2F for 2K26).

    Unknown / undetectable versions (file_version == 0) fall back to MODERN,
    not legacy. Modern handles all versions on import; legacy is only needed on
    the EXPORT path for 2K22-2K25's pre-QTangent serialization. Defaulting
    unknowns to legacy was the original mistake — any layout detect_mcd_version
    doesn't recognize (e.g. CTG-first baseModels) would route to the more
    restrictive DLL and fail to import.
    """
    if file_version == 0 or _is_modern_version(file_version):
        use_modern_lib()
    else:
        use_legacy_lib()


def detect_mcd_version(filepath):
    """Read the MDL version uint32 directly from an MCD/MDL file header.

    Returns the version byte (e.g. 0x29 for 2K25, 0x2F for 2K26) or 0 if
    unrecognized.

    Layouts handled:
      1. Bare MDL (2K20-2K24):
           [0x00] 'MDL!'   [0x04] version uint32
      2. MCD-wrapped attire (2K25/2K26 — MDL is the FIRST sub-stream):
           [0x00] 'MCD!'   [0x04] count   [0x08] inner_size
           [0x0c] 'MDL!'   [0x10] 'MDL!'  [0x14] version uint32
      3. MCD-wrapped baseModel (2K26 — CTG first, MDL later):
           [0x00] 'MCD!' ... [0x0c] 'CTG!' ... then 'MDL!MDL!<version_u32>'
           somewhere later. Located by scanning for the unique 8-byte
           'MDL!MDL!' signature (sub-stream outer tag + file magic).

    An earlier version checked only layouts 1+2 and returned 0 on layout 3,
    making use_lib_for_version fall through to legacy and fail to load 2K26
    baseModels. Reads up to 8 MB to cover any plausible CTG block size.
    """
    import os as _os
    try:
        size = _os.path.getsize(filepath)
        # 8 MB cap: CTG + MDL header for the largest body baseModels is well
        # under that, while keeping memory bounded for huge files.
        read_size = min(size, 8 * 1024 * 1024)
        with open(filepath, 'rb') as f:
            head = f.read(read_size)
    except Exception:
        return 0

    if len(head) < 8:
        return 0

    sig = head[:4]

    # Layout 1: bare MDL.
    if sig == b'MDL!':
        v = int.from_bytes(head[4:8], 'little')
        return v if v < 0x100 else 0

    # Layouts 2 + 3: MCD wrapper. The MDL sub-stream's outer-tag + inner magic
    # are both 'MDL!', producing the unique 8-byte 'MDL!MDL!' signature
    # followed by the version uint32 — handles MDL-first (attires) and
    # CTG-first (baseModels) uniformly. Start at 0x0c to skip the MCD! header.
    if sig == b'MCD!':
        idx = head.find(b'MDL!MDL!', 0x0c)
        if idx >= 0 and idx + 12 <= len(head):
            v = int.from_bytes(head[idx+8:idx+12], 'little')
            return v if v < 0x100 else 0

    return 0

# ============================================================================
# Graceful DLL proxy
#
# The legacy DLL (frozen v1.9.6) lacks some newer modern-DLL exports
# (vertex_remap, raw sub-stream, blend-shape helpers). Calling one while routed
# to legacy would raise AttributeError on first access. So every CDLL is
# wrapped in _GracefulDLL: missing functions become _MissingFunc stubs that
# absorb argtypes/restype assignments and return 0 (== NULL) on call. Caller
# code already treats 0/None as "feature unavailable", so the pipeline degrades
# gracefully on legacy without crashes.
# ============================================================================

class _MissingFunc:
    """Stand-in for a DLL export that doesn't exist on the loaded library.
    Acts like a ctypes function pointer: tolerates argtypes/restype assignment,
    returns 0 (== NULL ptr) on call. Caller-side code already treats 0/None
    as 'feature unavailable' for the newer DLL APIs."""
    __slots__ = ("_name", "argtypes", "restype")

    def __init__(self, name):
        object.__setattr__(self, "_name", name)
        object.__setattr__(self, "argtypes", [])
        object.__setattr__(self, "restype", None)

    def __setattr__(self, key, value):
        # Absorb any attribute assignment (argtypes, restype, errcheck, etc.)
        object.__setattr__(self, key, value)

    def __call__(self, *args, **kwargs):
        return 0

    def __bool__(self):
        return False


class _GracefulDLL:
    """ctypes.CDLL wrapper: returns _MissingFunc for absent exports.
    Caches stubs so repeated accesses to the same missing function
    return the same object (mirrors how ctypes caches FuncPtr instances
    so argtypes/restype assignments persist across accesses)."""

    def __init__(self, cdll):
        # Use object.__setattr__ so __setattr__ delegate doesn't trip on init.
        object.__setattr__(self, "_cdll", cdll)
        object.__setattr__(self, "_stub_cache", {})

    def __getattr__(self, name):
        # Called only when attribute isn't found normally on the proxy itself.
        try:
            return getattr(self._cdll, name)
        except AttributeError:
            cache = self._stub_cache
            if name not in cache:
                cache[name] = _MissingFunc(name)
            return cache[name]

    def __setattr__(self, key, value):
        # Delegate attribute writes to the wrapped CDLL.
        setattr(self._cdll, key, value)


class cmesh():
    global lib

    @staticmethod
    def new():
        return cmesh()
    
    def __build_cmesh(self):
        lib.getNewMesh.restype = ctypes.c_void_p
        return lib.getNewMesh()
    
    def set_data(self, vertices, index_list):
        lib.setMeshData.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_int), ctypes.c_int, ctypes.c_int]

        # arr_* locals MUST stay in scope until setMeshData returns (LIFETIME
        # RULE — synchronous setter copies before returning).
        n_verts = len(vertices)
        n_faces = len(index_list)
        if n_verts == 0 or n_faces == 0:
            return None
        arr_v, p_v = _as_c_float_ptr(vertices)
        arr_f, p_f = _as_c_int_ptr(index_list)

        return lib.setMeshData(self.__struct, p_v, p_f, n_verts, n_faces)

    def set_normals(self, normals):
        lib.setMeshNormals.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int]

        n = len(normals) if normals is not None else 0
        if n == 0:
            return None
        arr_n, p_n = _as_c_float_ptr(normals)

        return lib.setMeshNormals(self.__struct, p_n, n)

    def add_uv_channel(self, texcoords):
        lib.addUvMap.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int]

        n = len(texcoords) if texcoords is not None else 0
        if n == 0:
            return None
        arr_uv, p_uv = _as_c_float_ptr(texcoords)

        return lib.addUvMap(self.__struct, p_uv, n)

    def add_vertex_colors(self, color_map):
        # `is None` not `== None`: the latter triggers numpy element-wise
        # compare on an ndarray ("truth value of array is ambiguous").
        if color_map is None: return
        lib.addMeshColorMap.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int]

        n = len(color_map)
        if n == 0:
            return None
        arr_c, p_c = _as_c_float_ptr(color_map)

        return lib.addMeshColorMap(self.__struct, p_c, n)

    def set_skin_data(self, skin):
        if (skin == None):
            return

        lib.setMeshSkinData.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_float), ctypes.c_int, ctypes.c_int]

        n_idx = len(skin.blendindices)
        if n_idx == 0:
            return None
        # Bind BOTH arrays to named locals — indices and weights are read in
        # parallel, so either falling out of scope = DLL reads freed memory.
        arr_i, p_i = _as_c_int_ptr(skin.blendindices)
        arr_w, p_w = _as_c_float_ptr(skin.blendweights)

        return lib.setMeshSkinData(self.__struct, p_i, p_w, n_idx, skin.weights_per_vertex)
    
    def set_name_info(self, mesh_name, material_name):
        lib.setMeshNameInfo.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_char_p]
        lib.setMeshNameInfo(self.__struct, mesh_name.encode("utf-8"), material_name.encode("utf-8"))
        return

    def clear_face_groups(self):
        """Drop the DLL's default single face-group (created by setMeshData from
        set_name_info) so per-material groups can be re-added. No-op on a legacy DLL
        lacking the export (lib returns a _MissingFunc stub)."""
        lib.clearMeshFaceGroups.argtypes = [ctypes.c_void_p]
        lib.clearMeshFaceGroups(self.__struct)
        return

    def add_face_group(self, material_name, face_begin, num_triangles):
        """Append one contiguous material face-group. face_begin / num_triangles are
        in TRIANGLE units; the serializer writes them *3 as index-buffer offsets and
        emits the index buffer group-by-group, so the union of groups must cover all
        triangles in order (getMaterialFaceGroups guarantees this)."""
        lib.addMeshFaceGroup.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_int]
        lib.addMeshFaceGroup(self.__struct, material_name.encode("utf-8"), int(face_begin), int(num_triangles))
        return

    @staticmethod
    def has_face_group_api():
        """True only if the loaded DLL really exports the face-group WRITE API. Probes
        the underlying CDLL directly (the graceful proxy would otherwise hand back a
        _MissingFunc stub for any name), so a frozen legacy DLL is correctly detected
        and the multi-material override is skipped (default single-group path kept)."""
        try:
            cd = getattr(lib, "_cdll", lib)
            return hasattr(cd, "clearMeshFaceGroups") and hasattr(cd, "addMeshFaceGroup")
        except Exception:
            return False
    
    def set_model_game_flags(self, scene_flag, motion_flag):
        lib.setModelGameFlags.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
        lib.setModelGameFlags(self.__struct, scene_flag, motion_flag)
        return

    def add_blendshape(self, shape):
        if (not shape):
            return

        num_coords = len(shape.verts)
        if num_coords == 0:
            return None
        # Runs in a loop over `shapes` in set_blendshapes; the named local is
        # safe because the synchronous setter copies into the cmesh struct
        # before returning (LIFETIME RULE).
        arr_v, p_v = _as_c_float_ptr(shape.verts)

        lib.addBlendShape.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int]
        return lib.addBlendShape(self.__struct, shape.name.encode("utf-8"), p_v, num_coords)

    def set_blendshapes(self, shapes):
        if (not shapes): return
        for shape in shapes:
            self.add_blendshape(shape)
        return
    
    def get_cstruct(self):
        return self.__struct
    
    # ---- DLL preprocessing path (Preserve Custom Normals) ----

    def set_positions_raw(self, positions):
        """Send raw vertex positions — DLL handles coordinate swap."""
        lib.setMeshPositions.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int]
        n_floats = len(positions)
        if n_floats == 0:
            return None
        num_verts = n_floats // 3
        arr_p, p_p = _as_c_float_ptr(positions)
        return lib.setMeshPositions(self.__struct, p_p, num_verts)

    def set_polygons(self, face_sizes, indices):
        """Send raw polygon data (mixed tris/quads/ngons) — DLL triangulates."""
        lib.setMeshPolygons.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int), ctypes.c_int, ctypes.POINTER(ctypes.c_int), ctypes.c_int]
        n_faces = len(face_sizes)
        n_idx = len(indices)
        if n_faces == 0 or n_idx == 0:
            return None
        arr_s, p_s = _as_c_int_ptr(face_sizes)
        arr_i, p_i = _as_c_int_ptr(indices)
        return lib.setMeshPolygons(self.__struct, p_s, n_faces, p_i, n_idx)

    def add_loop_uv_map(self, uvs, num_loops):
        """Send per-loop UVs — DLL splits vertices at UV seams."""
        lib.addLoopUvMap.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int]
        if not uvs:
            return None
        arr_uv, p_uv = _as_c_float_ptr(uvs)
        return lib.addLoopUvMap(self.__struct, p_uv, num_loops)

    def set_loop_normals(self, normals, num_loops):
        """Send per-loop normals — DLL preserves them through vertex splitting."""
        lib.setLoopNormals.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int]
        if not normals:
            return None
        arr_n, p_n = _as_c_float_ptr(normals)
        return lib.setLoopNormals(self.__struct, p_n, num_loops)

    def set_tangents(self, tangents):
        """Legacy per-vertex TANGENT setter (makeSkinMesh path).

        `tangents` is a flat stride-4 list ([x,y,z,w]*numVerts) in game/local
        coords. The DLL applies the (x,-z,y) axis swap and passes handedness w
        unchanged. Count must equal numVerts*4 or the DLL rejects the set.
        """
        lib.setMeshTangents.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int]
        n = len(tangents) if tangents is not None else 0
        if n == 0:
            return None
        arr_t, p_t = _as_c_float_ptr(tangents)
        return lib.setMeshTangents(self.__struct, p_t, n)

    def set_loop_tangents(self, tangents, num_loops):
        """Per-loop TANGENT setter (DLL-preprocess makeSkinMeshRaw path).

        `tangents` is a flat stride-4 list ([x,y,z,w]*num_loops) in game/local
        coords. splitUvSeams() moves these into the per-vertex tangent buffer
        parallel to loop normals, so the serializer writes carried vanilla
        tangents byte-for-byte. Reads num_loops*4 floats; same (x,-z,y) swap +
        w passthrough as set_tangents.
        """
        lib.setLoopTangents.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int]
        if not tangents:
            return None
        arr_t, p_t = _as_c_float_ptr(tangents)
        return lib.setLoopTangents(self.__struct, p_t, num_loops)

    def set_loop_packedtbn(self, words, num_loops):
        """Per-loop PackedTBN word setter (DLL-preprocess makeSkinMeshRaw path).

        `words` is a flat list of uint32 octahedral TBN words (one per loop),
        captured verbatim from the vanilla MCD at import — opaque, NO axis swap,
        NO decode. splitUvSeams() moves them into the per-vertex word buffer
        parallel to loop normals/tangents; reorderSplitToVanilla permutes back
        to vanilla render order; the serializer gate emits each UNEDITED vert's
        word byte-for-byte (edited verts re-encode). DLL stores them opaquely.
        """
        lib.setLoopPackedTBN.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32), ctypes.c_int]
        if not words:
            return None
        arr_w, p_w = _as_c_uint32_ptr(words)
        return lib.setLoopPackedTBN(self.__struct, p_w, num_loops)

    def prepare_for_export(self):
        """Run DLL-side preprocessing (triangulate + UV seam split)."""
        lib.prepareMeshForExport.argtypes = [ctypes.c_void_p]
        return lib.prepareMeshForExport(self.__struct)

    def set_vertex_remap(self, remap):
        """Send vertex remap data for HPL/CTG ordering."""
        if (not remap or len(remap) == 0): return
        lib.setMeshVertexRemap.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32), ctypes.c_int]
        n = len(remap)
        # vertex_remap uses unsigned 32-bit indices (np.uint32 matches the DLL
        # signature; the addon never produces negative entries).
        arr_r, p_r = _as_c_uint32_ptr(remap)
        lib.setMeshVertexRemap(self.__struct, p_r, n)
        return
    
    def free(self):
        lib.freeMesh.argtypes = [ctypes.c_void_p]
        lib.freeMesh(self.__struct)
        return
    
    def __init__(self):
        self.__struct = self.__build_cmesh()

class cmodellib():

    global lib

    @staticmethod
    def saveModelToFile(cmodel, path, target_version, use_shape_keys, recalculate_tangents, use_mtls, num_lods, use_vertex_remap=True, generate_ctg=False):
        lib.saveModelToFile.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_int, ctypes.c_bool, ctypes.c_bool]
        return lib.saveModelToFile(cmodel, path.encode("utf-8"), target_version, use_shape_keys, recalculate_tangents, use_mtls, num_lods, use_vertex_remap, generate_ctg)

    @staticmethod
    def addBoneToModel(cskinmodel, bone_name, matrix, index, parent_name ):
        lib.setNewModelBone.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int, ctypes.c_char_p, ctypes.c_bool]

        # 16-float bone matrix. numpy is overkill here but keeps the pattern
        # uniform with the bulk setters and handles the flattened `matrix`
        # from unpack_matrices without python-list edge cases.
        parent_name = "" if not parent_name else parent_name
        arr_m, p_m = _as_c_float_ptr(matrix)
        return lib.setNewModelBone(cskinmodel, bone_name.encode("utf-8"), p_m, index, parent_name.encode("utf-8"), True)

    @staticmethod
    def free_cskinmodel(cmodelfile):
        lib.release_model.argtypes = [ctypes.c_void_p]
        return lib.release_model(cmodelfile)

    # ---- Sub-stream access (HPL roundtrip) ----

    @staticmethod
    def getNumRawSubStreams(cskinmodel):
        lib.getNumRawSubStreams.restype = ctypes.c_int
        lib.getNumRawSubStreams.argtypes = [ctypes.c_void_p]
        return lib.getNumRawSubStreams(cskinmodel)

    @staticmethod
    def getRawSubStreamData(cskinmodel, stream_index):
        """Returns (bytes, size) tuple for a raw sub-stream blob."""
        out_size = ctypes.c_int(0)
        lib.getRawSubStreamData.restype = ctypes.c_void_p
        lib.getRawSubStreamData.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_int)]
        ptr = lib.getRawSubStreamData(cskinmodel, stream_index, ctypes.byref(out_size))
        if ptr and out_size.value > 0:
            return ctypes.string_at(ptr, out_size.value), out_size.value
        return None, 0

    @staticmethod
    def replaceOrAddSubStreamByTag(cskinmodel, data, size):
        """Atomically replace an existing sub-stream by tag, or append if not found."""
        lib.replaceOrAddSubStreamByTag.restype = ctypes.c_int
        lib.replaceOrAddSubStreamByTag.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_char), ctypes.c_int]
        buf = (ctypes.c_char * size).from_buffer_copy(data)
        return lib.replaceOrAddSubStreamByTag(cskinmodel, buf, size)

    @staticmethod
    def addRawSubStream(cskinmodel, data, size):
        """Append a raw sub-stream blob to the model."""
        lib.addRawSubStream.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_char), ctypes.c_int]
        buf = (ctypes.c_char * size).from_buffer_copy(data)
        lib.addRawSubStream(cskinmodel, buf, size)

    # ---- Vertex Remap (HPL index mapping) ----

    @staticmethod
    def getVertexRemapSize(cskinmodel, mesh_index):
        lib.getVertexRemapSize.restype = ctypes.c_int
        lib.getVertexRemapSize.argtypes = [ctypes.c_void_p, ctypes.c_int]
        return lib.getVertexRemapSize(cskinmodel, mesh_index)

    @staticmethod
    def getVertexRemapData(cskinmodel, mesh_index):
        lib.getVertexRemapData.restype = ctypes.POINTER(ctypes.c_uint32)
        lib.getVertexRemapData.argtypes = [ctypes.c_void_p, ctypes.c_int]
        return lib.getVertexRemapData(cskinmodel, mesh_index)

    # ---- Sub-stream transfers (roundtrip without string table) ----

    @staticmethod
    def transferRawSubStreams(source_model, dest_model):
        """Transfer raw sub-streams (HPL, HCYW, HYWA, etc.) from source to dest."""
        lib.transferRawSubStreams.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        lib.transferRawSubStreams(source_model, dest_model)

    @staticmethod
    def transferHstData(source_model, dest_model):
        """Transfer HST! data from source to dest."""
        lib.transferHstData.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        lib.transferHstData(source_model, dest_model)

    @staticmethod
    def transferSpdtHeader(source_model, dest_model):
        """Transfer the captured 40-byte SpeedTree (.speedtree) wrapper header
        from source to dest. Required for .speedtree round-trip — without it the
        writer falls through to MCD output and produces an unrecognized file.
        No-op for MCD imports (no SPDT header, writer follows the MCD path)."""
        lib.transferSpdtHeader.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        lib.transferSpdtHeader(source_model, dest_model)

    @staticmethod
    def hasSpdtHeader(cmodel):
        """True if the model carries a captured SpeedTree (.speedtree) wrapper
        header — i.e. the writer emitted a SPDT-wrapped file (not a plain MCD).
        No-op-safe on a DLL without the export (graceful proxy -> 0 -> False)."""
        lib.hasSpdtHeader.restype = ctypes.c_int
        lib.hasSpdtHeader.argtypes = [ctypes.c_void_p]
        return bool(lib.hasSpdtHeader(cmodel))

    @staticmethod
    def transferGotoPoints(source_model, dest_model):
        """Transfer GtPt data from source to dest."""
        lib.transferGotoPoints.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        lib.transferGotoPoints(source_model, dest_model)

    @staticmethod
    def setSkipAttributeGroups(model, skip):
        """Suppress the fixed _ag_ attribute-group block in
        generateStringTable() for this export. When set, the saved string table
        omits the 13-entry _ag_ block (and its interleaved
        M_Teeth/M_Head/M_Tongue/M_Head_Caruncle anchor strings) that
        pushAttributeGroupBlock emits when isHeadBaseModel() detects head meshes.

        Pairs with the No-AO export option: skipping GtPt alone leaves orphan
        _ag_ strings the engine tries to resolve into nonexistent records;
        skipping both gives a clean "no face-shading anchor system" state (eyes/
        teeth/tongue render with default lighting, no dark-eyes regression).

        Returns True when the call landed on a real export, False on the
        missing-export stub (older DLLs no-op and emit the _ag_ block as before;
        caller should skip the GtPt pipeline halves regardless, and can warn the
        user an updated DLL is needed for full No-AO mode)."""
        fn = lib.setSkipAttributeGroups
        # _MissingFunc.__bool__ returns False — clean missing-export detection.
        if not fn:
            return False
        fn.argtypes = [ctypes.c_void_p, ctypes.c_int]
        fn(model, 1 if skip else 0)
        return True

    @staticmethod
    def transferStringTable(source_model, dest_model):
        """Transfer the original string table from source to dest. Lets
        generateStringTable recover canonical entries (:skinned materials,
        lambert1, belt_APs, UV/color channel names) and lock canonical casing
        during the roundtrip's string-table regeneration."""
        lib.transferStringTable.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        lib.transferStringTable(source_model, dest_model)

    @staticmethod
    def transferMaterialTable(source_model, dest_model):
        """Transfer source's full material list to dest. Used by
        generateStringTable's originalMats fallback to push materials that
        have no Blender face-group assignments (lambert1, belt_*, etc.)."""
        lib.transferMaterialTable.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        lib.transferMaterialTable(source_model, dest_model)

    @staticmethod
    def transferLodCaptures(source_model, dest_model):
        """Transfer multi-LOD round-trip captures (per-mesh raw bytes, LOD1+
        tail, source numFaceBufs, source LOD0 mesh count) from source to dest.
        Without it the writer clones LOD0 N times instead of preserving the
        source's distinct LOD1+ geometry. Safe to call unconditionally —
        captures are empty for single-LOD content (belts) and the writer skips
        the preserve path when hasLodCaptures() is false."""
        lib.transferLodCaptures.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        lib.transferLodCaptures(source_model, dest_model)

    @staticmethod
    def setUseLodCaptures(model, enabled):
        """Opt the writer into preserving source LOD1+ data verbatim.
        Defaults off — wrestler and belt exports rely on the cloning path
        so sculpt/edit changes show at every distance. Crowd exports must
        flip this on, because cloned LOD1+ data renders the model invisible
        in-game."""
        lib.setUseLodCaptures.argtypes = [ctypes.c_void_p, ctypes.c_int]
        lib.setUseLodCaptures(model, 1 if enabled else 0)

    @staticmethod
    def setGenerateMeshlets(model, enabled):
        """Opt this model into per-mesh D3D12 MeshletBuffer GENERATION at save.
        Set for crowd/audience exports so edited/new meshes carry the mesh-shader
        cluster data the crowd render path requires. Off for wrestlers/attires.
        No-op on older DLLs that don't export it."""
        lib.setGenerateMeshlets.argtypes = [ctypes.c_void_p, ctypes.c_int]
        lib.setGenerateMeshlets(model, 1 if enabled else 0)

    @staticmethod
    def free_float_array(cfloat_arr):
        lib.freeMemory_float32.argtypes = [ctypes.POINTER(ctypes.c_float)] 
        lib.freeMemory_float32(cfloat_arr)
        return
    
    @staticmethod
    def free_int_arr(cint_arr):
        lib.freeMemory_intArr.argtypes = [ctypes.POINTER(ctypes.c_int)] 
        lib.freeMemory_intArr(cint_arr)
        return
    
    @staticmethod
    def free_string_arr(ccharp_arr):
        lib.freeMemory_charArrPtr.argtypes = [ctypes.POINTER(ctypes.c_char_p)]
        lib.freeMemory_charArrPtr(ccharp_arr)
        return
    
    @staticmethod
    def free_cskin(cskin_ptr):
        lib.freeMemory_skinData.argtypes = [ctypes.c_void_p]
        lib.freeMemory_skinData(cskin_ptr)
        return
    
    @staticmethod
    def getNumMeshes(cskinmodel):
        lib.getMeshTotal.restype  = ctypes.c_int
        lib.getMeshTotal.argtypes = [ctypes.c_void_p]
        return lib.getMeshTotal(cskinmodel)
    
    @staticmethod
    def getNewSkinModel():
        lib.getNewSkinModel.restype  = ctypes.c_void_p
        return lib.getNewSkinModel()
    
    @staticmethod
    def addMeshToModel(cskinmodel, cskinmesh):
        lib.linkMeshToModel.argtypes  = [ctypes.c_void_p, ctypes.c_void_p]
        return lib.linkMeshToModel(cskinmodel, cskinmesh)
        
    @staticmethod
    def getMeshName(cskinmodel, mesh_index):
        lib.getMeshName.restype  = ctypes.c_char_p
        lib.getMeshName.argtypes = [ctypes.c_void_p, ctypes.c_int]
        return lib.getMeshName(cskinmodel, mesh_index)

    @staticmethod
    def getNumTriangles(cskinmodel, mesh_index):
        lib.getNumTriangles.restype  = ctypes.c_int
        lib.getNumTriangles.argtypes = [ctypes.c_void_p, ctypes.c_int] 
        return lib.getNumTriangles(cskinmodel, mesh_index)

    @staticmethod
    def getNumVerts(cskinmodel, mesh_index):
        lib.getNumVerts.restype  = ctypes.c_int
        lib.getNumVerts.argtypes = [ctypes.c_void_p, ctypes.c_int] 
        return lib.getNumVerts(cskinmodel, mesh_index)

    @staticmethod
    def getMeshTriangleList(cskinmodel, mesh_index):
        lib.getMeshTriangleList.restype  = ctypes.POINTER(ctypes.c_uint32)
        lib.getMeshTriangleList.argtypes = [ctypes.c_void_p, ctypes.c_int] 
        return lib.getMeshTriangleList(cskinmodel, mesh_index)

    @staticmethod
    def getMeshNormals(cskinmodel, mesh_index):
        lib.getMeshNormals.restype  = ctypes.POINTER(ctypes.c_float)
        lib.getMeshNormals.argtypes = [ctypes.c_void_p, ctypes.c_int]
        return lib.getMeshNormals(cskinmodel, mesh_index)

    @staticmethod
    def getMeshTangents(cskinmodel, mesh_index):
        """Return (float* ptr, num_floats) for the per-vertex TANGENT lane.

        Tangents are in game/local coords (NO axis swap). Stride via out-param:
        3 (xyz) or 4 (xyz + handedness w). ptr is None when absent.
        """
        lib.getMeshTangents.restype  = ctypes.POINTER(ctypes.c_float)
        lib.getMeshTangents.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_int)]
        size = ctypes.c_int(0)
        ptr = lib.getMeshTangents(cskinmodel, mesh_index, ctypes.byref(size))
        return ptr, size.value

    @staticmethod
    def getMeshBinormals(cskinmodel, mesh_index):
        """Return (float* ptr, num_floats) for the per-vertex BINORMAL lane.

        The binormal xyz is the bitangent; its orientation vs. (normal x
        tangent) encodes the handedness sign needed to rebuild a stride-4
        tangent. Paired with getMeshTangents. ptr is None when absent.
        """
        lib.getMeshBinormals.restype  = ctypes.POINTER(ctypes.c_float)
        lib.getMeshBinormals.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_int)]
        size = ctypes.c_int(0)
        ptr = lib.getMeshBinormals(cskinmodel, mesh_index, ctypes.byref(size))
        return ptr, size.value

    @staticmethod
    def getMeshOriginalPackedTBN(cskinmodel, mesh_index):
        """Return an (num_verts,) uint32 ndarray of the verbatim vanilla
        PackedTBN octahedral words captured at load (4 bytes/vert, vanilla
        render order), or None when the lane is absent.

        DLL returns const char* + BYTE count via the outSize out-param. restype
        MUST be c_void_p (NOT c_char_p — that stops at the first NUL in the
        binary stream); copy `size` bytes with string_at, reinterpret as LE u32.
        """
        lib.getMeshOriginalPackedTBN.restype  = ctypes.c_void_p
        lib.getMeshOriginalPackedTBN.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_int)]
        size = ctypes.c_int(0)
        ptr = lib.getMeshOriginalPackedTBN(cskinmodel, mesh_index, ctypes.byref(size))
        if not ptr or size.value <= 0:
            return None
        buf = ctypes.string_at(ptr, size.value)
        return np.frombuffer(buf, dtype="<u4").copy()

    @staticmethod
    def getVertexData(cskinmodel, mesh_index):
        lib.getVertexData.restype  = ctypes.POINTER(ctypes.c_float)
        lib.getVertexData.argtypes = [ctypes.c_void_p, ctypes.c_int] 
        return lib.getVertexData(cskinmodel, mesh_index)

    @staticmethod
    def getMaterialName(cskinmodel, mesh_index):
        lib.getMaterialName.restype  = ctypes.c_char_p
        lib.getMaterialName.argtypes = [ctypes.c_void_p, ctypes.c_int]
        return lib.getMaterialName(cskinmodel, mesh_index)

    @staticmethod
    def getMaterialFaceGroup(cskinmodel, mesh_index, group_index, face_begin_p, face_end_p):
        lib.getMaterialFaceGroup.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int)] 
        return lib.getMaterialFaceGroup(cskinmodel, mesh_index, group_index, face_begin_p, face_end_p)
    
    @staticmethod
    def getMaterialDiffuseMap(cskinmodel, mesh_index, group_index):
        lib.getMaterialDiffuseMap.restype  = ctypes.c_char_p
        lib.getMaterialDiffuseMap.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int] 
        return lib.getMaterialDiffuseMap(cskinmodel, mesh_index, group_index)

    @staticmethod
    def getAllFaceGroups(cskinmodel, mesh_index, size_p):
        lib.getAllFaceGroups.restype  = ctypes.POINTER(ctypes.c_char_p)
        lib.getAllFaceGroups.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_int)] 
        return lib.getAllFaceGroups(cskinmodel, mesh_index, size_p)

    @staticmethod
    def getNumMeshVertexColors(cskinmodel, mesh_index):
        lib.getNumMeshVertexColors.restype  = ctypes.c_int
        lib.getNumMeshVertexColors.argtypes = [ctypes.c_void_p, ctypes.c_int] 
        return lib.getNumMeshVertexColors(cskinmodel, mesh_index)

    @staticmethod
    def getMeshVertexColors(cskinmodel, mesh_index, map_index, size_p):
        lib.getMeshVertexColors.restype  = ctypes.POINTER(ctypes.c_float)
        lib.getMeshVertexColors.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_int)] 
        return lib.getMeshVertexColors(cskinmodel, mesh_index, map_index, size_p)

    @staticmethod
    def getAllMeshMorphs(cskinmodel, mesh_index, num_shapes_p):
        lib.getAllMeshMorphs.restype  = ctypes.POINTER(ctypes.c_char_p)
        lib.getAllMeshMorphs.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_int)] 
        return lib.getAllMeshMorphs(cskinmodel, mesh_index, num_shapes_p)

    @staticmethod
    def getMeshBlendShape(cskinmodel, mesh_index, shape_index, size_p):
        lib.getMeshBlendShape.restype  = ctypes.POINTER(ctypes.c_float)
        lib.getMeshBlendShape.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_int)] 
        return lib.getMeshBlendShape(cskinmodel, mesh_index, shape_index, size_p)

    @staticmethod
    def getVtxMorphIndices(cskinmodel, mesh_index, shape_index, size_p):
        lib.getVtxMorphIndices.restype  = ctypes.POINTER(ctypes.c_int)
        lib.getVtxMorphIndices.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_int)] 
        return lib.getVtxMorphIndices(cskinmodel, mesh_index, shape_index, size_p)
    
    @staticmethod
    def getNumBones(cskinmodel):
        lib.getNumBones.restype  = ctypes.c_int
        lib.getNumBones.argtypes = [ctypes.c_void_p] 
        return lib.getNumBones(cskinmodel)

    @staticmethod
    def getBoneName(cskinmodel, bone_index):
        lib.getBoneName.restype  = ctypes.c_char_p
        lib.getBoneName.argtypes = [ctypes.c_void_p, ctypes.c_int] 
        return lib.getBoneName(cskinmodel, bone_index)

    @staticmethod
    def getBoneMatrix(cskinmodel, bone_index):
        lib.getBoneTransformMatrix.restype  = ctypes.POINTER(ctypes.c_float)
        lib.getBoneTransformMatrix.argtypes = [ctypes.c_void_p, ctypes.c_int] 
        return lib.getBoneTransformMatrix(cskinmodel, bone_index)

    @staticmethod
    def getBoneParentIndex(cskinmodel, bone_index):
        lib.getBoneParentIndex.restype  = ctypes.c_int
        lib.getBoneParentIndex.argtypes = [ctypes.c_void_p, ctypes.c_int] 
        return lib.getBoneParentIndex(cskinmodel, bone_index)

    @staticmethod
    def getSkinData(cskinmodel, mesh_index):
        lib.getSkinData.restype  = ctypes.c_void_p
        lib.getSkinData.argtypes = [ctypes.c_void_p, ctypes.c_int] 
        return lib.getSkinData(cskinmodel, mesh_index)

    @staticmethod
    def getAllSkinGroups(cskinmodel, num_bones_p):
        lib.getAllSkinGroups.restype  = ctypes.POINTER(ctypes.c_char_p)
        lib.getAllSkinGroups.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int)] 
        return lib.getAllSkinGroups(cskinmodel, num_bones_p)

    @staticmethod
    def getAllJointWeights(cskinmodel, bone_name, size_p):
        lib.getAllJointWeights.restype  = ctypes.POINTER(ctypes.c_float)
        lib.getAllJointWeights.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_int)] 
        return lib.getAllJointWeights(cskinmodel, bone_name, size_p)

    @staticmethod
    def getMeshUvChannel(cskinmodel, mesh_index, map_index):
        lib.getMeshUvChannel.restype  = ctypes.POINTER(ctypes.c_float)
        lib.getMeshUvChannel.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int] 
        return lib.getMeshUvChannel(cskinmodel, mesh_index, map_index)

    @staticmethod
    def getNumUvChannels(cskinmodel, mesh_index):
        lib.getNumUvChannels.restype  = ctypes.c_int
        lib.getNumUvChannels.argtypes = [ctypes.c_void_p, ctypes.c_int] 
        return lib.getNumUvChannels(cskinmodel, mesh_index)

    @staticmethod
    def getMeshSceneFlag(cskinmodel, mesh_index):
        lib.getMeshSceneFlag.restype  = ctypes.c_int
        lib.getMeshSceneFlag.argtypes = [ctypes.c_void_p, ctypes.c_int] 
        return lib.getMeshSceneFlag(cskinmodel, mesh_index)

    @staticmethod
    def getMeshMotionFlag(cskinmodel, mesh_index):
        lib.getMeshMotionFlag.restype  = ctypes.c_int
        lib.getMeshMotionFlag.argtypes = [ctypes.c_void_p, ctypes.c_int] 
        return lib.getMeshMotionFlag(cskinmodel, mesh_index)
    
    @staticmethod
    def getNumAttachPoints(cskinmodel):
        lib.getNumAttachPoints.restype  = ctypes.c_int
        lib.getNumAttachPoints.argtypes = [ctypes.c_void_p] 
        return lib.getNumAttachPoints(cskinmodel)
    
    @staticmethod
    def getAttachmentPointData(cskinmodel, point_index, id_a, id_b, joint, flag, x, y, z):
        lib.getAttachmentPointData.argtypes = [ ctypes.c_void_p,                # cmodel
                                                ctypes.c_int,                   # point index
                                                ctypes.POINTER(ctypes.c_int),   # id a
                                                ctypes.POINTER(ctypes.c_int),   # id b
                                                ctypes.POINTER(ctypes.c_int),   # joint id
                                                ctypes.POINTER(ctypes.c_int),   # flag
                                                ctypes.POINTER(ctypes.c_float), # co x
                                                ctypes.POINTER(ctypes.c_float), # co y
                                                ctypes.POINTER(ctypes.c_float)] # co z 

        return lib.getAttachmentPointData(cskinmodel, point_index, id_a, id_b, joint, flag, x, y, z)
    
    @staticmethod
    def addPointToModel(cskinmodel, bone_index, id1, id2, flag, co):
        lib.setNewAttachPoint.argtypes  = [ctypes.c_void_p, 
                                         ctypes.c_int, 
                                         ctypes.c_int, 
                                         ctypes.c_int, 
                                         ctypes.c_int, 
                                         ctypes.c_float, 
                                         ctypes.c_float, 
                                         ctypes.c_float, ]
        return lib.setNewAttachPoint(cskinmodel, bone_index, id1, id2, flag, co[0], co[1], co[2])

    # ── GtPt round-trip (mirrors the AtPt set above) ─────────────────────
    #
    # Wire-format + field semantics live on vCGotoPoint (skinmodel_gp.py);
    # this layer is just ctypes plumbing (the resolver interprets the four
    # shorts). All three calls are gated behind hasattr probes — legacy DLLs
    # shipped without them, and callers fall back to transferGotoPoints.

    @staticmethod
    def has_gtpt_api():
        """True iff the loaded DLL exposes the new GtPt round-trip ABI.

        Probes the underlying _cdll directly: lib is a _GracefulDLL proxy that
        returns _MissingFunc stubs for absent exports, so plain hasattr(lib, …)
        always succeeds — we must ask the real CDLL.
        """
        cdll = getattr(lib, '_cdll', lib)
        return (hasattr(cdll, 'getNumGotoPoints') and
                hasattr(cdll, 'getGotoPointData') and
                hasattr(cdll, 'addGotoPoint'))

    @staticmethod
    def getNumGotoPoints(cskinmodel):
        lib.getNumGotoPoints.restype  = ctypes.c_int
        lib.getNumGotoPoints.argtypes = [ctypes.c_void_p]
        return lib.getNumGotoPoints(cskinmodel)

    @staticmethod
    def getGotoPointData(cskinmodel, point_index, no_0, no_1, no_2, no_3):
        lib.getGotoPointData.argtypes = [ctypes.c_void_p,
                                         ctypes.c_int,
                                         ctypes.POINTER(ctypes.c_int),
                                         ctypes.POINTER(ctypes.c_int),
                                         ctypes.POINTER(ctypes.c_int),
                                         ctypes.POINTER(ctypes.c_int)]
        return lib.getGotoPointData(cskinmodel, point_index, no_0, no_1, no_2, no_3)

    @staticmethod
    def addGotoPoint(cskinmodel, no_0, no_1, no_2, no_3):
        lib.addGotoPoint.argtypes = [ctypes.c_void_p,
                                     ctypes.c_int, ctypes.c_int,
                                     ctypes.c_int, ctypes.c_int]
        return lib.addGotoPoint(cskinmodel, no_0, no_1, no_2, no_3)

    # ── String-table read access ─────────────────────────────────────────
    #
    # Resolves GtPt no_0/no_1 indices to anchor/mesh names at import time —
    # a read-only view of the DLL's already-loaded table. Probed because older
    # DLLs may not expose the call.

    @staticmethod
    def has_string_table_api():
        cdll = getattr(lib, '_cdll', lib)
        return (hasattr(cdll, 'getStringTableSize') and
                hasattr(cdll, 'getStringTableEntry'))

    @staticmethod
    def getNumStringTableEntries(cskinmodel):
        # DLL export is `getStringTableSize`; exposed under a clearer Python
        # alias to avoid churn in existing callers.
        lib.getStringTableSize.restype  = ctypes.c_int
        lib.getStringTableSize.argtypes = [ctypes.c_void_p]
        return lib.getStringTableSize(cskinmodel)

    @staticmethod
    def getStringTableEntry(cskinmodel, index):
        """Returns the string at `index` as a Python str, or None if
        the index is out of range or the entry is empty.
        """
        lib.getStringTableEntry.restype  = ctypes.c_char_p
        lib.getStringTableEntry.argtypes = [ctypes.c_void_p, ctypes.c_int]
        raw = lib.getStringTableEntry(cskinmodel, index)
        if raw is None:
            return None
        try:
            return raw.decode('utf-8', errors='replace')
        except Exception:
            return None

    @staticmethod
    def has_string_table_write_api():
        """True iff the DLL exposes addStringTableEntry — needed for the GtPt
        resolver to push new anchor/mesh names into the dest string table.
        Older builds may lack it (resolver then drops records whose strings
        aren't already in the table). Probes _cdll directly (see has_gtpt_api).
        """
        cdll = getattr(lib, '_cdll', lib)
        return hasattr(cdll, 'addStringTableEntry')

    @staticmethod
    def addStringTableEntry(cskinmodel, s):
        """Append a string to the destination's string table.

        DLL sig is `void addStringTableEntry(void* model, const char*)` — no
        return; call findStringTableIndex to get the index back. The append is
        unconditional (caller dedupes if needed); serialize()'s
        generateStringTable later rebuilds the table from canonical sources.
        """
        lib.addStringTableEntry.restype  = None
        lib.addStringTableEntry.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
        if isinstance(s, str):
            s = s.encode('utf-8')
        lib.addStringTableEntry(cskinmodel, s)

    @staticmethod
    def findStringTableIndex(cskinmodel, s):
        """Return the index of `s` in the destination's string table,
        or -1 if not present. Linear scan — fine for the GtPt resolver's
        13 lookups per export.
        """
        if not cmodellib.has_string_table_api():
            return -1
        try:
            n = cmodellib.getNumStringTableEntries(cskinmodel)
        except Exception:
            return -1
        target = s if isinstance(s, str) else s.decode('utf-8', errors='replace')
        for i in range(n):
            entry = cmodellib.getStringTableEntry(cskinmodel, i)
            if entry == target:
                return i
        return -1

    @staticmethod
    def findOrAppendStringTableIndex(cskinmodel, s):
        """Return the index of `s` in the destination's string table.
        If not present, appends it and returns the new index. Combines
        findStringTableIndex + addStringTableEntry into the one operation
        the GtPt resolver actually wants.
        """
        existing = cmodellib.findStringTableIndex(cskinmodel, s)
        if existing >= 0:
            return existing
        # Append, then re-find (not just return size-1) to defend against any
        # DLL-side dedup we don't know about.
        cmodellib.addStringTableEntry(cskinmodel, s)
        return cmodellib.findStringTableIndex(cskinmodel, s)


class ExternalLibary():
    def getLoadOperator(self):
        # Defines Call for 'void* loadModelFile(const char* filePath)'
        self.dynamic_lib.loadModelFile.restype  = ctypes.c_void_p
        self.dynamic_lib.loadModelFile.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p), ctypes.c_bool]
        return self.dynamic_lib.loadModelFile
    
    def getDeleteOperator(self):
        # Defines Call for 'void release_model_file(void* pModelFile)'
        self.dynamic_lib.release_model_file.argtypes = [ctypes.c_void_p]
        return self.dynamic_lib.release_model_file

    def getModelFileVersion(self, model_file_ptr):
        """Query the parsed MDL/MCD format version from a CModelContainer pointer.

        Returns a uint32 (0x2F=2K26, 0x29=2K25, 0x28=2K24), or 0 if the export
        is unavailable or the pointer is invalid. Older DLLs don't expose this —
        callers treat 0 as "unknown" and fall back to heuristic detection.
        """
        if not model_file_ptr:
            return 0
        try:
            fn = self.dynamic_lib.getModelFileVersion
        except AttributeError:
            return 0
        try:
            fn.restype = ctypes.c_uint32
            fn.argtypes = [ctypes.c_void_p]
            return int(fn(model_file_ptr))
        except Exception:
            return 0

    def __init__(self):
        # Bind to whichever DLL is currently active. Caller is responsible for
        # routing first via use_lib_for_target() / use_lib_for_version().
        # If nothing has been routed yet, default to modern (most common case).
        global lib
        if lib is None:
            use_modern_lib()
        
        self.dynamic_lib          = lib
        self.load_model           = self.getLoadOperator()
        self.release_model_file   = self.getDeleteOperator()

