import time
import os
import ctypes
from .wrapper import (
    ExternalLibary, cmodellib,
    detect_mcd_version, use_lib_for_version, _is_modern_version,
)
from ..SkinModel.skinmodel    import vCSkinModel
from ..Blender.blender_scene  import vCBlenderScene
from .log import derror, dlog


# MDL/MCD format version bytes (see VCModel meshtags.h enModelFormats).
# Used when the DLL's getModelFileVersion export is available.
_MDL_VERSION_TO_TARGET = {
    0x2F: "option_vcexport_26",  # WWE 2K26 (MDL v2.15)
    0x29: "option_vcexport_25",  # WWE 2K25 (MDL v2.9)
    0x28: "option_vcexport_24",  # WWE 2K24 (MDL v2.8)
}


def _detect_source_target(model_path, skin_model_pointer, model_file_pointer, module):
    """Identify which game the source file was authored for.

    Returns one of "option_vcexport_24" / "option_vcexport_25" / "option_vcexport_26".

    Detection order:
      1. Authoritative — DLL getModelFileVersion() maps the MDL version byte
         straight to a compile target.
      2. Heuristic fallback (older DLLs without the export):
         - .mdl extension -> 2K24 (legacy MDL)
         - .mcd + sub-streams -> 2K26 (v2.15 embeds CTG/HPL/YWA inline)
         - .mcd + no sub-streams -> 2K25 (v2.09 keeps companions as siblings)
    """
    try:
        if module is not None and model_file_pointer:
            try:
                ver = module.getModelFileVersion(model_file_pointer)
            except Exception:
                ver = 0
            if ver and ver in _MDL_VERSION_TO_TARGET:
                return _MDL_VERSION_TO_TARGET[ver]

        # Fallback heuristic for older DLLs.
        ext = os.path.splitext(model_path)[1].lower()
        if ext == '.mdl':
            return "option_vcexport_24"
        if skin_model_pointer:
            try:
                num = cmodellib.getNumRawSubStreams(skin_model_pointer)
            except Exception:
                num = 0
            if num and num > 0:
                return "option_vcexport_26"
        return "option_vcexport_25"
    except Exception:
        return "option_vcexport_26"


def buildModel(skin_model_pointer, model_path, args, model_file_pointer=None, module=None):
    model = vCSkinModel(skin_model_pointer)

    # Send loaded model to blender for import
    scene = vCBlenderScene([model])
    scene.set_name(model_path)
    scene.set_load_args(args)
    scene.build()

    # Stamp the source MCD path on the import collection so export-time
    # sub-stream transfers (GtPt in model_serialize.py, the 25→26 upgrade
    # in companion_upgrade.py) can locate the source file. The 25→26
    # upgrade re-detects the source's MDL version at upgrade time, so the
    # source target enum is no longer recorded here.
    if scene.collections:
        scene.collections[0]["vcmodel_source_path"] = model_path

    return

def loadModelFile( filepath , args , operator=None ):
    # begin timer
    start_time = time.time()

    # Detect MDL version from file header and route to the appropriate DLL
    # BEFORE creating ExternalLibary (which binds to the currently-active lib).
    detected_version = detect_mcd_version(filepath)
    use_lib_for_version(detected_version)
    if detected_version:
        # Mirror use_lib_for_version's actual routing so the log can't drift.
        is_modern = _is_modern_version(detected_version)
        dlog(f"[MDL Addon] Detected MDL v0x{detected_version:02x}; "
             f"routing to {'modern' if is_modern else 'legacy'} DLL")
    else:
        # Unknowns route to modern (more permissive on the read side).
        dlog("[MDL Addon] Could not detect MDL version; defaulting to modern DLL")

    # setup all 'vcmodel' dll exports into a single class
    module = ExternalLibary()

    # loads the model from specified path and retrieves the skinmodel pointer
    model_file = ctypes.c_void_p()
    skin_model = module.load_model( filepath.encode('utf-8'), ctypes.byref(model_file), args['load_textures'] )

    # ── DLL texture-pass crash guard ─────────────────────────────────────
    # The DLL's load_textures=True path access-faults inside SOME Blender
    # processes (reproduced 2026-07: same file + same DLL loads fine in
    # Blender 5.1 and in every standalone Python, but the DLL's SEH guard
    # aborts with "corrupt/truncated (access fault)" inside Blender
    # 2.93-5.0 — process-state-dependent fault in the texture loader, not
    # a bad file). Geometry import is unaffected, so retry once without
    # the texture pass rather than failing the whole import. args is
    # updated so the Blender-side build stays consistent with what the
    # DLL actually loaded.
    if (not model_file or not skin_model) and args.get('load_textures'):
        dlog("[MDL Addon] load with textures failed; retrying without "
             "DLL texture pass (known process-dependent fault)")
        model_file = ctypes.c_void_p()
        skin_model = module.load_model(
            filepath.encode('utf-8'), ctypes.byref(model_file), False)
        if model_file and skin_model:
            args['load_textures'] = False
            if operator is not None:
                operator.report(
                    {'WARNING'},
                    "Model loaded, but the DLL texture pass failed in this "
                    "Blender version — imported without embedded textures. "
                    "Geometry, materials, and export are unaffected.")

    # evaluate result type
    if (not model_file or not skin_model):
        derror("[MDL Addon] Could not load invalid model.")
        # Surface the failure to the user (the operator otherwise returned
        # FINISHED with an empty scene and no banner — silent failure).
        if operator is not None:
            operator.report({'ERROR'},
                            f"Could not load '{os.path.basename(filepath)}': not a "
                            f"valid/supported MCD/MDL (corrupt, truncated, or "
                            f"unsupported version).")
        return False
    else:
        # Pass model_file + module through so buildModel can query the
        # authoritative MDL version via the DLL before release. release_model_file
        # MUST run even if buildModel raises mid-parse (partial parse: model_file
        # set, skin_model populated) — otherwise the model_file heap leaks. The
        # old code released only on the success line, so any exception in
        # buildModel skipped it. try/finally guarantees release.
        try:
            buildModel(skin_model, filepath, args, model_file, module)
        finally:
            module.release_model_file(model_file)  # clean model + file heap

        # Auto-apply HPL from 2K26 attire source onto baseModel meshes.
        # Runs only when (a) user opted in, (b) source is a 2K26 attire (not
        # a baseModel), (c) the source MCD has an HPL sub-stream, and (d)
        # baseModel meshes (M_Head / M_Body) are in the scene to receive the
        # groups. Any miss is logged + surfaced via operator.report — never
        # an error, since the import itself succeeded.
        if (args.get('auto_apply_hpl', False)
                and detected_version == 0x2F
                and 'basemodel' not in os.path.basename(filepath).lower()):
            try:
                from ..Serialize.hpl_roundtrip import (
                    extract_hpl_from_mcd, apply_hpl_to_basemodel,
                    find_basemodel_meshes,
                )
                base_meshes = find_basemodel_meshes()
                if not base_meshes:
                    msg = ("Auto-apply HPL skipped: no baseModel in scene. "
                           "Load the baseModel first, then click 'Apply HPL "
                           "to BaseModel' in the HPL Masking panel to bring "
                           "the source attire's masking onto it.")
                    dlog(f"[MDL Addon] {msg}")
                    if operator is not None:
                        operator.report({'INFO'}, msg)
                else:
                    hpl_data = extract_hpl_from_mcd(filepath)
                    if hpl_data is None:
                        dlog("[MDL Addon] Auto-apply HPL: source attire has no HPL sub-stream "
                             "(nothing to apply).")
                    else:
                        ok, message = apply_hpl_to_basemodel(hpl_data)
                        dlog(f"[MDL Addon] Auto-apply HPL: {message}")
                        if operator is not None:
                            operator.report({'INFO' if ok else 'WARNING'},
                                            f"Auto-apply HPL: {message}")
            except Exception as e:
                derror(f"[MDL Addon] Auto-apply HPL error: {e}")
                if operator is not None:
                    operator.report({'WARNING'},
                                    f"Auto-apply HPL failed: {e} (import itself succeeded)")

   # end timer and print elapsed time
    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"[MDL Addon] Model Imported in {elapsed_time:.2f}s")
    return True

