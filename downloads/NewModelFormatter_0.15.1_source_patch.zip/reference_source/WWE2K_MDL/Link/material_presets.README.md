# material_presets.json

This file is the **2K26 material-template registry**. It is consumed by
`Serialize/material_templates.py`, which exposes a small public API for
looking up shader presets by `(shader, type, alias)` or by engine shader
byte.

## What it is

A dump of named shader presets from the Visual Concepts (WWE 2K) material
editor. Each entry under `Templates` is a shader preset with its full
parameter set (floats, colors, texture slot names, render-state flags,
etc.). Its schema mirrors what the engine's
`CMaterialTemplates::loadTemplates()` consumes.

## Shape

```jsonc
{
    "General": {
        "Material Editor Version": 1.0
    },
    "Templates": [
        {
            "Shader":   "<shader_name>",  // e.g. "yCh_skin"
            "Template": "<alias>",        // e.g. "Default"
            "Type":     "<type_name>",    // e.g. "Normal"
            "<param_name>": { "<type>": <value> },
            ...
        },
        ...
    ]
}
```

`<type>` is one of `float`, `string`, `hash`, `uint`, `vector`,
`shared_vec`, or `shared_long`. A handful of bare-int fields (`flag0` ..
`flag4`) appear unwrapped. See `Serialize/material_templates.py` for the
exact normalisation rules applied at load time.

## Adding new templates

Edit this JSON in place; no Python change is required. Call
`material_templates.reload()` (or restart Blender) to pick up changes.
