import time
import os
import ctypes
import traceback
from .wrapper                     import ExternalLibary, cmodellib, use_lib_for_target
from ..Blender.blender_save       import *
from ..Serialize.model_serialize  import *
from ..Serialize.model_serialize  import _find_source_mcd, _patch_gtpt_records_in_file, _build_gtpt_records_for_dest
from ..Blender.Extras.masking_hpl import *
from ..Blender.blender_points     import *
from .log import dlog, derror, dwarn


def _clean_material_name(raw_name):
    """Strip the ``:Skinned``/``:variant`` suffix and Blender's ``.NNN`` dup
    marker. Mirrors ``Serialize.material_export._sanitize_material_name`` so
    both sides agree on the engine slot name for a given raw input.
    """
    if not raw_name:
        return ""
    name = raw_name
    if ":" in name:
        name = name.split(":", 1)[0]
    import re as _re
    m = _re.match(r"^(.*?)(\.\d{3,})$", name)
    if m:
        name = m.group(1)
    return name


_SOFTWARE_DEFAULT_MATERIALS = frozenset({
    "lambert1", "phong1", "blinn1", "standard_surface1",
    "material", "material.001", "defaultmaterial", "default material",
    "scene_material", "initialshadinggroup", "initialparticlese",
})


def _is_software_default_material_name(name):
    """True for DCC placeholders that must not become engine MTLS slots."""
    return (name or "").strip().lower() in _SOFTWARE_DEFAULT_MATERIALS


def _collect_materials_in_dll_order(cskinmodel):
    """Query the cskinmodel for the canonical material name list as the
    .mcd writes it, and pair each entry with a Blender material lookup.

    FIX for the Triple H 2018 wrong-materials bug. The .mcd's material table
    is ground truth — its per-mesh face groups carry material_index values
    the engine pairs against the .mtls slot order. A .mtls in a different
    order (e.g. Blender's slot-walk order, the OLD broken path) renders
    every face group with the wrong shader/textures.

    Per mesh, prefer the face-group list (``getAllFaceGroups``, captures
    multi-material meshes); fall back to ``getMaterialName`` when empty
    (single-material mesh, common case). The V6 MTLS wrapper is a unique
    hash/name set, not a row per face group: shipped models with two
    ``mouthbag`` face groups still contain one MTLS row. Keep the first
    occurrence of each cleaned name and omit DCC defaults such as Maya's
    ``lambert1``.

    Args:
        cskinmodel: vCSkinModel wrapper; must be alive (not ``.free()``d)
            at call time — invoke BEFORE the free at the end of saveSkinModel.

    Returns:
        Ordered list of ``(cleaned_slot_name, bpy_material_or_None)`` in .mcd
        material-table order. Empty list on any DLL failure (caller falls
        back to the deprecated Blender-slot-walk path with a warning).
    """
    import bpy as _bpy

    ordered = []
    seen_slots = set()
    skipped_defaults = set()
    skipped_duplicates = set()
    # Track duplicates per cleaned name for reporting only — does NOT omit
    # any DLL-listed entry from ``ordered``.
    dup_winners = {}  # cleaned_name -> [list of bpy.types.Material]

    try:
        model_ptr = cskinmodel.get_model_ptr()
    except Exception as e:
        dwarn(f"[MaterialExport] _collect_materials_in_dll_order: "
              f"cskinmodel.get_model_ptr() failed ({e}); falling back "
              f"to Blender slot order")
        return []
    if not model_ptr:
        dwarn("[MaterialExport] _collect_materials_in_dll_order: "
              "cskinmodel ptr is NULL; falling back to Blender slot order")
        return []

    try:
        n_meshes = cmodellib.getNumMeshes(model_ptr)
    except Exception as e:
        dwarn(f"[MaterialExport] _collect_materials_in_dll_order: "
              f"getNumMeshes raised ({e}); falling back")
        return []

    if not n_meshes or n_meshes <= 0:
        dwarn("[MaterialExport] _collect_materials_in_dll_order: "
              "cskinmodel has zero meshes; falling back")
        return []

    def _decode(raw_bytes):
        if raw_bytes is None:
            return ""
        try:
            return raw_bytes.decode("utf-8", errors="replace")
        except Exception:
            return ""

    def _lookup_bpy_material(raw_name, clean_name):
        """Try several Blender name variants to locate the source material."""
        mats = _bpy.data.materials
        # Raw name first (preserves any :Skinned suffix), then cleaned, then
        # common variants the import side might have produced.
        candidates = [
            raw_name,
            clean_name,
            f"{clean_name}:Skinned",
            f"{clean_name}:skinned",
            f"{raw_name}:Skinned",
            f"{clean_name}.001",
        ]
        for cand in candidates:
            if not cand:
                continue
            try:
                m = mats.get(cand)
            except Exception:
                m = None
            if m is not None:
                return m
        # Last resort: case-insensitive scan over all bpy.data.materials.
        clean_lc = clean_name.lower() if clean_name else ""
        try:
            for m in mats:
                if not m or not getattr(m, "name", None):
                    continue
                m_clean_lc = _clean_material_name(m.name).lower()
                if m_clean_lc and m_clean_lc == clean_lc:
                    return m
        except Exception:
            pass
        return None

    def _all_bpy_matches(clean_name):
        """All Blender materials that clean to the same engine slot name.
        Logging only — the engine renders just the first match."""
        out = []
        clean_lc = clean_name.lower() if clean_name else ""
        if not clean_lc:
            return out
        try:
            for m in _bpy.data.materials:
                if not m or not getattr(m, "name", None):
                    continue
                if _clean_material_name(m.name).lower() == clean_lc:
                    out.append(m)
        except Exception:
            pass
        return out

    for mi in range(n_meshes):
        names_for_mesh = []

        # Prefer face-group list — captures multi-material meshes. The DLL
        # fills size_p with the group count and returns a char_p array.
        try:
            size = ctypes.c_int(0)
            fg_ptr = cmodellib.getAllFaceGroups(
                model_ptr, mi, ctypes.byref(size))
            if fg_ptr and size.value > 0:
                for gi in range(size.value):
                    raw = fg_ptr[gi]
                    s = _decode(raw)
                    if s:
                        names_for_mesh.append(s)
                # Free only the outer array; the char* entries are owned by
                # the DLL's internal material table.
                try:
                    cmodellib.free_string_arr(fg_ptr)
                except Exception:
                    # Some DLL builds don't export the free; the leak is one
                    # pointer array per mesh per export, bounded/acceptable.
                    pass
        except Exception as e:
            dwarn(f"[MaterialExport] getAllFaceGroups(mesh={mi}) "
                  f"raised: {e}")

        # Fall back to per-mesh material name when face groups are empty
        # (single-material mesh — the typical case).
        if not names_for_mesh:
            try:
                raw = cmodellib.getMaterialName(model_ptr, mi)
                s = _decode(raw)
                if s:
                    names_for_mesh.append(s)
            except Exception as e:
                dwarn(f"[MaterialExport] getMaterialName(mesh={mi}) "
                      f"raised: {e}")

        for raw_name in names_for_mesh:
            clean = _clean_material_name(raw_name)
            if not clean:
                continue
            if _is_software_default_material_name(clean):
                skipped_defaults.add(clean)
                continue
            slot_key = clean.casefold()
            if slot_key in seen_slots:
                skipped_duplicates.add(clean)
                continue
            seen_slots.add(slot_key)
            bpy_mat = _lookup_bpy_material(raw_name, clean)
            ordered.append((clean, bpy_mat))
            # Record all Blender mats that clean to this name for the dwarn.
            matches = _all_bpy_matches(clean)
            if len(matches) > 1 and clean not in dup_winners:
                dup_winners[clean] = matches

    for clean, matches in dup_winners.items():
        winner = matches[0].name
        names = [m.name for m in matches]
        dwarn(f"[MaterialExport] Multiple Blender materials clean to "
              f"the same engine slot name '{clean}': {names}. Each DLL "
              f"slot entry uses '{winner}' for textures/overrides; the "
              f"other Blender material(s) are unused by export.")

    if skipped_duplicates:
        dwarn(
            "[MaterialExport] Collapsed repeated face-group materials to "
            f"one MTLS entry each: {sorted(skipped_duplicates)}"
        )
    if skipped_defaults:
        dwarn(
            "[MaterialExport] Omitted software-default materials from "
            f"MTLS/JMTL output: {sorted(skipped_defaults)}"
        )

    return ordered

COMPILE_TARGETS = \
[
    ("option_vcexport_26", "WWE 2K26 MCD v2.15", "Formats model for WWE 2K26 platform"),
    ("option_vcexport_25", "WWE 2K25 MCD v2.09", "Formats model for WWE 2K25 platform"),
    ("option_vcexport_24", "WWE 2K24 MDL v2.08", "Formats model for WWE 2K24 platform")
]

COMPILE_TARGETS_MAP = {
    "option_vcexport_26": 0x2F,
    "option_vcexport_25": 0x29,
    "option_vcexport_24": 0x28,
}

def get_compile_target_value(option):
    """Get the magic value based on the selected enum option"""
    return COMPILE_TARGETS_MAP.get(option, None)  # Returns None if not found

def handle_context():
    objs = get_obj_selection()
    if len(objs) == 0: return False

    dlog("[MDL Addon] invalid object context. attempting resolve...")
    bpy.context.view_layer.objects.active = objs[0]
    bpy.ops.object.mode_set(mode='OBJECT')
    return True

def is_valid_context():
    try:
        bpy.ops.object.mode_set(mode='OBJECT')
    except:
        return handle_context()
    return True

def get_obj_selection():
    mesh_objects = getActiveModels()
    return mesh_objects

def set_obj_selection(objects):
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objects:
        obj.select_set(True)
    return

def run_external_utils(path, args):
    target_objects = get_obj_selection()
    if (len(target_objects) == 0): return

    if (args["export_hpl"]): 
        write_some_data_hpl (bpy.context, path) # Optionally create target masking file
        set_obj_selection   (target_objects)    # Reselect all mesh object targets
    return

def saveSkinModel(path, lib, args, operator=None):
    if (not is_valid_context()): return False

    # Route to the appropriate DLL by export target. Must run BEFORE any
    # ExternalLibary is created downstream — they bind to the active lib.
    use_lib_for_target(args.get("compile_target"))

    run_external_utils(path, args)

    # Audit armature binding on the selection. Two jobs in one pass:
    #   1. Hygiene — repair unambiguous half-bound states (parented without
    #      modifier, or modifier with no object) that would drop skinning.
    #   2. Cross-version auto-redirect — if exporting as 2K26 but a mesh is
    #      still bound to a 2K25 skeleton (a port where the user built the
    #      2K26 armature but forgot to re-bind), rebind to the correct-version
    #      armature and notify via the UI banner. Non-blocking: export always
    #      continues (the game loads the file either way).
    #
    # Reconcile always returns True under the current policy; the return
    # check is kept so a future stricter mode can abort without another edit.
    if not reconcile_armature_binding(
            getMeshSelection(),
            compile_target=args.get("compile_target"),
            operator=operator):
        dlog("[MDL Addon] Export aborted by armature reconciliation.")
        return False

    # Collect all skinmeshes from active scene (user selection)
    preserve_normals = args.get("preserve_normals", False)
    preserve_tangents = args.get("preserve_tangents", False)
    scene_meshes = getSceneMeshes(preserve_normals=preserve_normals,
                                  preserve_tangents=preserve_tangents)
    if (not scene_meshes): return False

    # Surface per-mesh weight validation warnings (built in getVertexSkin) to
    # the Blender UI. operator.report pops them as info-header banners — the
    # only place modders reliably see feedback (system console is off by
    # default on Windows). Also printed to console for bug-report pastes.
    if operator is not None:
        for mesh in scene_meshes:
            skin = getattr(mesh, 'skin', None)
            if skin is None:
                continue
            for severity, msg in getattr(skin, 'validation_warnings', []):
                dlog(f"[MDL Addon] {severity}: {msg}")
                try:
                    operator.report({severity}, msg)
                except Exception:
                    pass

    # Interface with blender and send all model data to dll
    scene_armature = getSceneArmature()
    attach_points = None
     
    if args["export_atpts"]:
        # Coords written verbatim. The vanilla 2K26 baseModel's attach points
        # are byte-identical to the 2K25 template, so the old per-target
        # normalize_for_2k25 nudge was unnecessary and perturbed non-2K25
        # exports — removed wholesale.
        attach_points = getSceneAttachPoints()

    # ── Basemodel-export detection ─────────────────────────────────────
    # Single source of truth for "is the user exporting a basemodel (not an
    # attire)?" — gates basemodel-only features: GtPt eye-lighting anchors,
    # CTG vertex-remap substream, and the canonical empty-HPL stub. This is a
    # SELECTION-content check, not scene-content: an attire export with the
    # basemodel also loaded must NOT trip it. Asks "is any SELECTED mesh a
    # basemodel mesh (M_Head / M_Body by data.name root)?"
    #
    # Computed HERE (right after scene_meshes) before to_cmodel/build, because
    # CTG injection happens inside build() and needs to know the target.
    is_basemodel_export = False
    if args["compile_target"] == "option_vcexport_26":
        try:
            from ..Serialize.hpl_roundtrip import find_basemodel_meshes

            def _is_basemodel_mesh_obj(o):
                if o.type != 'MESH':
                    return False
                data_name = o.data.name
                if '.' in data_name:
                    data_name = data_name.rsplit('.', 1)[0]
                return data_name in ('M_Head', 'M_Body')

            _sel = getMeshSelection() or []
            if any(_is_basemodel_mesh_obj(o) for o in _sel):
                is_basemodel_export = True
                base_meshes = find_basemodel_meshes(scope_objects=_sel)
                head_name = base_meshes.get('M_Head').name if 'M_Head' in base_meshes else '<not found>'
                body_name = base_meshes.get('M_Body').name if 'M_Body' in base_meshes else '<not found>'
                dlog(f"[MDL Addon] baseModel export detected from selection "
                     f"(M_Head='{head_name}', M_Body='{body_name}')")
            else:
                dlog("[MDL Addon] attire export detected — GtPt, CTG, and "
                     "basemodel-only paths will be skipped")
        except Exception as e:
            dlog(f"[MDL Addon] baseModel-detection failed: {e}; "
                 f"defaulting is_basemodel_export=False (treat as attire)")

    # to_cmodel.build() unconditionally runs transferGotoPoints when a source
    # MCD is stamped on the selection; the resulting GtPt block is later
    # either (a) overwritten in-place by the resolver-driven post-save patcher
    # when scene anchors exist, or (b) remapped via source-file derivation
    # otherwise. Both fallbacks live further down, after save_to_file.

    cskinmodel = CModelSerializer.to_cmodel(
        scene_meshes,
        compile_target=args["compile_target"],
        export_gtpts=args.get("export_gtpts", True),
        is_basemodel_export=is_basemodel_export,
    )

    # Surface any warnings the serializer collected during build. Generic
    # drain — currently unpopulated, but future serializer-side validation
    # can plug in by appending (severity, msg) tuples to export_warnings.
    if operator is not None:
        for severity, msg in getattr(cskinmodel, 'export_warnings', []):
            try:
                operator.report({severity}, msg)
            except Exception:
                pass

    if (scene_armature):
        cskinmodel.set_skeleton(scene_armature)
        cskinmodel.set_attach_points(attach_points)

    # GtPt resolver. Walks VC_GtPt_Anchors empties + per-record anchor vertex
    # groups, resolves each record's (mesh, vertex_index) in the dest scene,
    # and stashes resolved records for the post-save patch step.
    #
    # BASEMODEL-ONLY: GtPt is the eye-lighting anchor system vanilla ships in
    # the basemodel MCD. Attire MCDs carry no GtPt — running the resolver on
    # an attire export pulled basemodel mesh names (eye_l, mouthbag, M_Head,
    # …) into the saved string table though those meshes aren't selected.
    # Skipping it on attire exports keeps the table clean and leaves the saved
    # file untouched (post-save patcher is also gated on is_basemodel_export).
    #
    # Solves the merged-caruncle dark-eyes regression: when modders weld
    # M_Head_Caruncle into M_Head, source GtPt records still point at a mesh
    # that no longer exists. The resolver detects the merge via
    # GROUP_MERGE_FALLBACKS and rewrites the group to M_Head while preserving
    # the anchor name and slot (engine lookup key, round-tripped verbatim).
    # Vertex resolution prefers the per-record anchor vertex group (which the
    # importer pinned to the source vertex), else nearest-vertex-on-target.
    #
    # Architecture — post-save patch, NOT pre-save addGotoPoint: pushing
    # records pre-save fails because serialize() runs generateStringTable()
    # FIRST, rebuilding the table from canonical sources, so any pre-save
    # indices are stale by save's end. Post-save patching reads the file's
    # actual final TEXT block and produces matching records. Records are
    # collected here; the patch runs after save_to_file(), alongside the
    # source-file-derived patcher (the no-scene-anchors fallback).
    cskinmodel.gtpt_resolver_records = None
    if args.get("export_gtpts", True) and is_basemodel_export:
        try:
            from ..Serialize.gtpt_resolver import resolve_scene_gtpts
            records, gtpt_warnings = resolve_scene_gtpts()
            for severity, msg in gtpt_warnings:
                if operator is not None:
                    try:
                        operator.report({severity}, msg)
                    except Exception:
                        pass
                dlog(f"[MDL Addon] GtPt {severity}: {msg}")
            if records:
                cskinmodel.gtpt_resolver_records = records
        except Exception as e:
            derror(f"[MDL Addon] GtPt resolver error: {e}")
            traceback.print_exc()

    # 2K25 → 2K26 sub-stream upgrade. When exporting as 2K26 from a 2K25
    # attire source, embed the source's sibling .ctg / .hair_ywa /
    # .hair_corr_ywa / .other_ywa / .other_corr_ywa as MCD sub-streams (the
    # layout 2K26 expects vs. 2K25's sibling files). companion_upgrade
    # re-detects the source MDL version, gates strictly on 2K25-attire-only,
    # and refuses to touch .mtls / .ycl (sidecars in both versions, and the
    # bleed-through vector in the old companion_files path).
    #
    # .hpl is intentionally NOT embedded from the 25 source. Instead the
    # empty-HPL fallback below injects the canonical zero-mask HPL when this
    # upgrade ran AND the scene has no HPL edits; if it does have edits, the
    # HPL round-trip block overrides it via replaceOrAddSubStreamByTag.
    upgrade_ran = False
    if args["compile_target"] == "option_vcexport_26":
        try:
            from ..Serialize.companion_upgrade import embed_25_companions_for_2k26
            source_path = _find_source_mcd()
            upgrade_ran, upgrade_reason = embed_25_companions_for_2k26(
                cskinmodel.get_model_ptr(), source_path)
            if not upgrade_ran:
                dlog(f"[MDL Addon] 25→26 sub-stream upgrade skipped: "
                     f"{upgrade_reason}")
        except Exception as e:
            derror(f"[MDL Addon] 25→26 sub-stream upgrade error: {e}")
            traceback.print_exc()

    # HPL Round-Trip: if scene has HPL vertex group edits, regenerate and inject
    use_vertex_remap = args.get("use_vertex_remap", False)
    hpl_injected_from_scene = False

    # Capture the user's mesh selection ONCE for the HPL pipeline — every
    # downstream HPL call needs the same scope, and re-deriving risks drift if
    # anything below mutates selection. Also fixes "two baseModels in scene —
    # HPL bleeds from the one I didn't select": the scope is forwarded to
    # find_basemodel_meshes, which filters candidates to those sharing a
    # collection with the selection, excluding the second basemodel entirely.
    hpl_scope_objects = getMeshSelection() or []

    # baseModel exports SCRUB the HPL sub-stream: baseModel MCDs ship an empty
    # 8-byte HPL stub and must NOT carry attire-style polygon mask data.
    # Guards two cases:
    #   (A) Forward — "Auto-apply HPL from Attire" left HPL_Ring/HPL_Entrance
    #       groups on the baseModel's M_Head/M_Body; a baseModel export would
    #       round-trip them as ~240 KB attire-context mask data, deadlocking
    #       the engine on contact-pose lookups (grapples, deformation).
    #   (B) Round-trip — importing an already-broken baseModel (HPL baked in
    #       by an old addon version) keeps the 240 KB stream attached;
    #       saveModelToFile would emit it verbatim without scrubbing.
    #
    # Fix: force-inject the canonical empty HPL stub via
    # replaceOrAddSubStreamByTag (overwrites whatever's attached; no-op for
    # clean vanilla files which already carry the same stub).
    #
    # Reuses is_basemodel_export (computed at the top). That SELECTION-content
    # check is precise — the old "find_basemodel_meshes() returned M_Head and
    # M_Body" fired whenever a basemodel was loaded anywhere, mis-scrubbing
    # attire exports that keep the basemodel alongside as the HPL source.

    if is_basemodel_export:
        # Force-inject the canonical empty HPL stub — scrubs round-trip case (B).
        try:
            from ..Serialize.companion_upgrade import inject_empty_hpl_substream
            inject_empty_hpl_substream(cskinmodel.get_model_ptr())
            dlog("[MDL Addon] HPL: baseModel — forced empty HPL stub "
                 "(scrubbed any pre-existing HPL data)")
        except Exception as e:
            derror(f"[MDL Addon] HPL baseModel scrub error: {e}")
            traceback.print_exc()
    elif args["compile_target"] == "option_vcexport_26":
        try:
            from ..Serialize.hpl_roundtrip import scene_has_hpl_edits, generate_hpl_substream

            # Both calls take the same scope so they agree on which basemodel
            # they read from — misaligned scope is exactly the A-vs-B bleed
            # pattern this fix addresses.
            if scene_has_hpl_edits(scope_objects=hpl_scope_objects):
                hpl_blob = generate_hpl_substream(
                    use_vertex_remap=use_vertex_remap,
                    scope_objects=hpl_scope_objects)
                if hpl_blob:
                    result = cmodellib.replaceOrAddSubStreamByTag(
                        cskinmodel.get_model_ptr(), hpl_blob, len(hpl_blob))
                    if result == -1:
                        derror(f"[MDL Addon] HPL: ERROR injecting "
                               f"{len(hpl_blob)} bytes "
                               f"(remap={'ON' if use_vertex_remap else 'OFF'})")
                    hpl_injected_from_scene = True
        except Exception as e:
            derror(f"[MDL Addon] HPL Round-Trip error: {e}")
            traceback.print_exc()

    # Empty-HPL fallback for the 25→26 upgrade path. Skipped for baseModel
    # exports — those already got their canonical empty stub above.
    if (args["compile_target"] == "option_vcexport_26"
            and upgrade_ran
            and not hpl_injected_from_scene
            and not is_basemodel_export):
        try:
            from ..Serialize.companion_upgrade import inject_empty_hpl_substream
            inject_empty_hpl_substream(cskinmodel.get_model_ptr())
        except Exception as e:
            derror(f"[MDL Addon] Empty HPL fallback error: {e}")
            traceback.print_exc()

    # Physics Update: compose the final hair/body physics sub-streams from the
    # model's loaded originals + the donor blobs from the Physics Swap panel.
    # Runs AFTER the HPL round-trip so composed physics wins, landing
    # replaceOrAddSubStreamByTag on the final sub-stream set.
    #
    # Composition rules (physics_patcher.update_physics_for_export):
    #   HCYW: donor (MOD1 patched/extended for scene M_*/S_* pairs), else orig.
    #   HYWA: donor (optional bone rename), else original.
    #   OCYW: original if present + non-placeholder, else donor (barren attires
    #         pick body collision up from the donor). OYWA: same fallback.
    #
    # 2K26-only (sub-stream embedded); 2K25/2K24 would need sidecars (separate
    # feature) and are skipped.
    if args["compile_target"] == "option_vcexport_26":
        try:
            from ..Blender.Extras.physics_swap import get_physics_swap_substreams
            from ..Serialize.physics_patcher import (
                update_physics_for_export, extract_original_substreams,
            )

            donor_blobs, donor_colliders = get_physics_swap_substreams()
            if donor_blobs:
                # Augment with scene-side collider geometry. The user commonly
                # loads baseModel head/body for reference but keeps them OUT of
                # selection; without this scan the patcher sees no M_Head/M_Body
                # and falls back to placeholder bindings (every vert -> tri 0).
                from ..Blender.blender_save import getSceneColliderGeometry
                scene_colliders = getSceneColliderGeometry()
                merged_colliders = dict(donor_colliders or {})
                for name, geom in scene_colliders.items():
                    if name not in merged_colliders:
                        merged_colliders[name] = geom
                        dlog(f"[MDL Addon] Physics: scene-side {name} "
                             f"used as collider ({len(geom[0])} verts, "
                             f"{len(geom[1])} tris) — found in scene "
                             f"but not in export selection")
                model_ptr = cskinmodel.get_model_ptr()
                original_blobs = extract_original_substreams(model_ptr, cmodellib)

                # Extract bone parent map from the scene armature so the
                # patcher can extend MOD!=2 bone-tree palettes with sim bones
                # `align_skeleton` added during a port. Without it, donor
                # substreams keep their original palette only and match-mode
                # physics skips the new bones (symptom: entrance/cutscene
                # physics works, in-match collisions don't).
                scene_bones_with_parents = None
                if scene_armature is not None:
                    scene_bones_with_parents = {
                        bone.name: bone.parent for bone in scene_armature.bones
                    }

                final_blobs = update_physics_for_export(
                    original_blobs, donor_blobs, scene_meshes,
                    donor_colliders=merged_colliders,
                    scene_bones_with_parents=scene_bones_with_parents,
                )
                for ext, blob in final_blobs.items():
                    rc = cmodellib.replaceOrAddSubStreamByTag(
                        model_ptr, blob, len(blob))
                    if rc == -1:
                        derror(f"[MDL Addon] Physics Update: {ext} ERROR "
                               f"({len(blob) // 1024} KB)")
        except Exception as e:
            derror(f"[MDL Addon] Physics Update error: {e}")
            traceback.print_exc()

    # LOD count selection.
    #   Belts / props  → 1 LOD  (Creation Suite needs single-level meshes —
    #                            multi-LOD belts go invisible until zoom-in
    #                            crosses the LOD switch threshold)
    #   Everything else → 4 LODs (unconditional default for wrestler/object)
    if args.get("belt_cs_fix", False):
        model_levels = 1
    else:
        model_levels = 4

    target = get_compile_target_value(args["compile_target"])

    # LOD-captures (preserve LOD1+ verbatim) is crowd-only. Wrestler/belt must
    # run cloning so sculpt/edit changes propagate to every LOD distance —
    # keep this off.
    try:
        cskinmodel.set_use_lod_captures(False)
    except Exception as e:
        derror(f"[MDL Addon] Could not set LOD-captures flag: {e}")

    # Roundtrip exports often save over the source path, clobbering it on
    # disk. The post-save GtPt remap needs the original source via DLL for
    # nearest-vertex resolution, so copy it to a temp file before save. Only
    # when GtPt is being exported (otherwise the remap doesn't run).
    source_temp_path = None
    if (args["compile_target"] == "option_vcexport_26"
            and args.get("export_gtpts", True)
            and is_basemodel_export):
        try:
            _src = _find_source_mcd()
            if _src and os.path.exists(_src):
                source_temp_path = path + '.gtpt_src_tmp'
                with open(_src, 'rb') as fr, open(source_temp_path, 'wb') as fw:
                    fw.write(fr.read())
        except Exception:
            source_temp_path = None

    # Face-shading anchor suppression. With "Include GtPt Anchors" off, the
    # GtPt sub-stream is already suppressed (build() + post-save patcher gated
    # on export_gtpts). The _ag_ attribute-group string-table block is the
    # matching half — both move together so the engine has no orphan _ag_NNNN
    # entries pointing at GtPt records that no longer exist.
    #
    # Graceful on older DLLs: the wrapper returns False when the export is
    # absent; we warn that the half-disabled state shipped (GtPt suppressed,
    # _ag_ block still emitting from legacy isHeadBaseModel() detection).
    if not args.get("export_gtpts", True):
        landed = cmodellib.setSkipAttributeGroups(
            cskinmodel.get_model_ptr(), True)
        if not landed:
            warn = ("[MDL Addon] GtPt off: setSkipAttributeGroups not "
                    "exported by the loaded DLL — _ag_ string-table "
                    "block will still emit. GtPt sub-stream is "
                    "suppressed; to fully suppress _ag_ entries, "
                    "rebuild VCModel.dll with the setSkipAttributeGroups "
                    "export wired into generateStringTable's "
                    "pushAttributeGroupBlock gate.")
            dwarn(warn)
            if operator is not None:
                try:
                    operator.report({'WARNING'}, warn)
                except Exception:
                    pass

    # Save model to disk file.
    #
    # ── DLL legacy .mtls writer gate ──────────────────────────────────────
    # saveModelToFile's generate_mtls flag triggers its INTERNAL legacy
    # 2K22-2K25 .mtls writer. For 2K26 we MUST pass False because:
    #   1. The Python writer at the post-save hook below emits the proper 2K26
    #      dual-stream (.mtls + per-material .jmtl); the DLL's legacy writer
    #      can't produce 2K26 format.
    #   2. The DLL's legacy material pass interferes with vertex_remap and
    #      corrupts HPL polygon masking on the saved .mcd.
    # The user-facing checkbox semantics are preserved — the Python writer
    # below still gates on args.get("generate_mtls"). For 2K22-2K25 the DLL
    # writer is the only material path, so keep the original behavior.
    is_2k26 = args.get("compile_target") == "option_vcexport_26"
    dll_generate_mtls = args.get("generate_mtls", False) and not is_2k26

    if args.get("generate_mtls") and is_2k26:
        dlog("[MDL Addon] 2K26 export: DLL legacy .mtls writer disabled "
             "(Python writer handles 2K26 dual-stream). This prevents the "
             "vertex_remap interference that previously broke HPL masking.")

    cskinmodel.save_to_file(path,
                            target,
                            args["export_shape_keys"],
                            args["use_calculate_tangents"],
                            dll_generate_mtls,
                            model_levels,
                            args.get("use_vertex_remap", False),
                            args.get("generate_ctg", False)
                            )

    # 2K26 materials: write .mtls + per-material .jmtl after the .mcd is saved.
    # Gated to 2K26 + generate_mtls (24/25 use the DLL's own legacy path).
    # Runs BEFORE the CTG-strip below so a failure here can't leave a CTG
    # block bleeding into an attire export.
    #
    # ── DLL-canonical material order ──────────────────────────────────────
    # The .mcd's material table is the SINGLE SOURCE OF TRUTH for slot order:
    # the engine pairs each face group's material_index against the .mtls slot
    # index — they MUST agree or face groups render with the wrong shader.
    # _collect_materials_in_dll_order (querying the still-alive cskinmodel)
    # returns the canonical (slot_name, bpy_material_or_None) list; the
    # orchestrator writes the .mtls in that exact order, falling back to
    # template defaults for slots with no Blender side.
    #
    # ─── BUG HISTORY ────────────────────────────────────────────────────
    # 1. BLEED BUG (Triple H 2018 attire): old code walked every slot on every
    #    selected mesh, bleeding UNUSED slots into the .mtls/.jmtl set.
    # 2. WRONG-MATERIAL-ON-FACE-GROUP (Triple H 2018 basemodel): even after
    #    (1), the .mtls used Blender's slot-walk order, not the DLL's
    #    face-group order — wrong materials in-game (attire shader as black
    #    chunks on the body), with ``mouthbag`` duplicated. Fixed by querying
    #    the DLL post-save for canonical order. The bleed/software-default
    #    filters are now implicit (the DLL table only lists referenced slots;
    #    the orchestrator pre-pass warns on engine-rejected names).
    if (args.get("compile_target") == "option_vcexport_26"
            and args.get("generate_mtls")):
        try:
            # Resolve the actual saved file path (DLL may have rewritten
            # .model -> .mcd). Mirrors the CTG-strip block's resolution.
            actual_path = path if os.path.exists(path) else None
            if actual_path is None:
                base, _ = os.path.splitext(path)
                for ext in ('.mcd', '.mdl'):
                    candidate = base + ext
                    if os.path.exists(candidate):
                        actual_path = candidate
                        break

            from ..Serialize.material_export import write_materials_for_export

            # Query the DLL for the canonical material list. MUST run before
            # cskinmodel.free() — the helper grabs get_model_ptr() at call time.
            ordered_materials = _collect_materials_in_dll_order(cskinmodel)

            if not ordered_materials:
                # Empty query (cskinmodel already freed, zero meshes, or a
                # wrapper raise). Skip the write rather than fall back to the
                # broken slot-walk path — a wrong-order .mtls is worse than
                # none (the engine then loads any pre-existing on-disk .mtls,
                # which is at least known-good for vanilla content).
                dwarn("[MaterialExport] DLL returned zero materials; "
                      "skipping .mtls/.jmtl write. Pre-existing files "
                      "in the model directory (if any) are untouched.")
                material_result = {
                    "mtls_path": "", "jmtl_paths": [],
                    "warnings": [], "errors": [],
                    "materials_written": 0, "materials_skipped": 0,
                }
            else:
                # ── Preset context (export dialog "Presets" selector) ─────
                # AUTO keeps both heuristics: selection-based basemodel
                # detection (computed above) and path-based arena detection
                # (is_environment=None → the orchestrator sniffs save_path
                # for Arena/Props/Weapons folders). The explicit choices
                # exist because both heuristics have blind spots — an arena
                # saved outside an Arena/ folder silently inferred CHARACTER
                # GEAR for every material. Scoped to material output only;
                # GtPt/CTG/HPL gating stays on is_basemodel_export.
                mat_context = args.get("material_context", "AUTO")
                if mat_context == "BASEMODEL":
                    mat_is_basemodel, mat_is_environment = True, False
                elif mat_context == "ATTIRE":
                    mat_is_basemodel, mat_is_environment = False, False
                elif mat_context == "ENVIRONMENT":
                    mat_is_basemodel, mat_is_environment = False, True
                else:
                    mat_is_basemodel, mat_is_environment = (
                        is_basemodel_export, None)
                if (mat_context != "AUTO"
                        and mat_is_basemodel != is_basemodel_export):
                    dlog(f"[MaterialExport] preset context '{mat_context}' "
                         f"overrides detected "
                         f"is_basemodel={is_basemodel_export} for the "
                         f".mtls/.jmtl write (GtPt/CTG gating unaffected)")
                material_result = write_materials_for_export(
                    ordered_materials=ordered_materials,
                    save_path=actual_path,
                    is_basemodel=mat_is_basemodel,
                    is_environment=mat_is_environment,
                    attire_scope=bpy.context.scene.get(
                        "vc_2k26_attire_scope", ""),
                    overwrite=args.get("overwrite_existing_jmtls", True),
                )
            if material_result.get("errors"):
                for e in material_result["errors"]:
                    derror(f"[MaterialExport] {e}")
            if material_result.get("warnings"):
                for w in material_result["warnings"]:
                    dwarn(f"[MaterialExport] {w}")
            dlog(f"[MaterialExport] wrote {material_result.get('materials_written', 0)} materials, "
                 f"skipped {material_result.get('materials_skipped', 0)}")
        except Exception as e:
            derror(f"[MaterialExport] failed: {e}")
            traceback.print_exc()

    # Post-save CTG strip (attire exports only). Defense in depth: build-time
    # CTG injection is gated on is_basemodel_export, the 25→26 embedder drops
    # .ctg, and the DLL's CTG generator is opt-in + M_Head/M_Body-only — but a
    # passed-through CTG from a mis-tagged source could still leak. Vanilla
    # 2K26 attires carry ZERO CTG (verified), so any CTG! at offset 0xC of an
    # attire export is bleed. Strip it in place.
    if (args["compile_target"] == "option_vcexport_26"
            and not is_basemodel_export):
        try:
            actual_path = path if os.path.exists(path) else None
            if actual_path is None:
                base, _ = os.path.splitext(path)
                for ext in ('.mcd', '.mdl'):
                    candidate = base + ext
                    if os.path.exists(candidate):
                        actual_path = candidate; break
            if actual_path:
                from ..Serialize.model_serialize import _strip_ctg_substream_from_file
                if _strip_ctg_substream_from_file(actual_path):
                    dlog(f"[MDL Addon] CTG strip: removed leading CTG! "
                         f"substream from attire export at '{actual_path}'")
        except Exception as e:
            derror(f"[MDL Addon] CTG strip error: {e}")

    # GtPt records post-save remap.
    #
    # GtPt records are 4×int16 tuples (name_id, group_id, ordinal,
    # vertex_index): name_id/group_id are string-table indices, vertex_index
    # is into the mesh referenced by group_id. The DLL writes source's values,
    # but source's indices may be stale vs. dest's regenerated string table
    # and Blender's possibly-reordered verts. The remap resolves all four:
    # name_id/group_id via source→dest TEXT lookup, ordinal passthrough,
    # vertex_index via nearest-vertex search on DLL-loaded mesh data. Without
    # it, eye-lighting bindings resolve to wrong meshes/verts → dark eyes.
    #
    # Two record sources (resolver wins — it's what the user actually wants):
    #   1. Scene resolver records (VC_GtPt_Anchors collection) — reflect the
    #      actual scene (caruncle merges, anchoring, manual edits). Built via
    #      _build_gtpt_records_from_resolver against the saved TEXT block.
    #   2. Source-file derivation (no scene anchors) — reads source GtPt,
    #      remaps strings to the saved TEXT table, nearest-vertex-resolves.
    if (args["compile_target"] == "option_vcexport_26"
            and args.get("export_gtpts", True)
            and is_basemodel_export):
        try:
            actual_path = path
            if not os.path.exists(actual_path):
                base, _ = os.path.splitext(path)
                for ext in ('.mcd', '.mdl'):
                    candidate = base + ext
                    if os.path.exists(candidate):
                        actual_path = candidate
                        break
                else:
                    actual_path = None

            source_path = _find_source_mcd()
            remap_source = source_temp_path if (source_temp_path and os.path.exists(source_temp_path)) else source_path

            if actual_path:
                with open(actual_path, 'rb') as f:
                    has_gtpt = b'GtPt' in f.read()
                if has_gtpt:
                    # Try resolver records first.
                    resolver_recs = getattr(cskinmodel, 'gtpt_resolver_records', None)
                    patched = False
                    if resolver_recs:
                        from ..Serialize.model_serialize import _build_gtpt_records_from_resolver
                        records_bytes, log = _build_gtpt_records_from_resolver(
                            resolver_recs, actual_path)
                        for line in log:
                            dlog(f"[MDL Addon] GtPt patch: {line}")
                        if records_bytes is not None:
                            patched = _patch_gtpt_records_in_file(
                                actual_path, records_bytes)
                            if not patched:
                                dlog(f"[MDL Addon] GtPt resolver patch "
                                     f"declined (record-count mismatch with "
                                     f"saved GtPt block — falling back to "
                                     f"source-file derivation).")

                    # Fall through to source-file derivation if resolver
                    # didn't apply (no records, or count mismatch).
                    if not patched and remap_source:
                        records, _ = _build_gtpt_records_for_dest(remap_source, actual_path)
                        if records is not None:
                            _patch_gtpt_records_in_file(actual_path, records)
                else:
                    # No GtPt block in the saved file — typical of the
                    # Generate-from-file workflow (the picked source MCD is an
                    # anchor donor, so the DLL never ran transferGotoPoints).
                    # With resolver records (scene anchors), inject a fresh
                    # block by byte-splicing into the saved MDL! envelope;
                    # strings resolve against the saved final TEXT table.
                    resolver_recs = getattr(cskinmodel, 'gtpt_resolver_records', None)
                    if resolver_recs:
                        from ..Serialize.model_serialize import (
                            _build_gtpt_records_from_resolver,
                            _inject_gtpt_block_in_file)
                        records_bytes, log = _build_gtpt_records_from_resolver(
                            resolver_recs, actual_path)
                        for line in log:
                            dlog(f"[MDL Addon] GtPt inject: {line}")
                        if records_bytes is not None:
                            n_records = len(records_bytes) // 8
                            injected = _inject_gtpt_block_in_file(
                                actual_path, records_bytes, n_records)
                            if not injected:
                                dlog(f"[MDL Addon] GtPt block inject failed "
                                     f"— could not locate MDL!/MTL! anchor "
                                     f"points for splice.")
        except Exception as e:
            derror(f"[MDL Addon] GtPt remap error: {e}")
            traceback.print_exc()

    # Clean up the temp source file used by the remap.
    if source_temp_path:
        try:
            if os.path.exists(source_temp_path):
                os.remove(source_temp_path)
        except Exception:
            pass

    # Post-save HPL scrub for baseModel exports. The pre-save
    # inject_empty_hpl_substream replaces only the FIRST HPL sub-stream by
    # tag. A previously-broken baseModel mod (~240 KB attire HPL baked in)
    # loads as BOTH the empty stub AND the oversized block; saveModelToFile
    # emits both, and the pre-save scrub catches only the first.
    #
    # The DLL has no removeSubStreamByTag, so scrub at the file level:
    # scrub_oversized_hpl_substreams walks every [u32 size][HPL!][payload]
    # wrapper and deletes any over the 32-byte threshold (above the 12-byte
    # canonical empty stub, below the smallest real attire HPL). No-op for
    # clean files.
    if (is_basemodel_export
            and args["compile_target"] == "option_vcexport_26"
            and 'actual_path' in dir() and actual_path
            and os.path.exists(actual_path)):
        try:
            from ..Serialize.companion_upgrade import scrub_oversized_hpl_substreams
            scrub_oversized_hpl_substreams(actual_path, threshold_bytes=32)
        except Exception as e:
            derror(f"[MDL Addon] HPL post-save scrub error: {e}")
            traceback.print_exc()

    cskinmodel.free()
    return True

def saveModelFile(filepath, args, operator=None):
    """Run the export. Returns True on success, False if anything blocked it
    (e.g. cross-version skeleton leak, no meshes selected)."""
    # Begin timer
    start_time = time.time()

    # Call save function...
    success = False
    try:
        success = bool(saveSkinModel(filepath, ExternalLibary(), args,
                                     operator=operator))
    except Exception as e:
        derror(f"[MDL Addon] Error during model export: {str(e)}")
        traceback.print_exc()
        success = False

    # End timer and print elapsed time
    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"[MDL Addon] Model Serialized in {elapsed_time:.2f}s")
    return success
