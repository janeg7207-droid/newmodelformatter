"""
Stub module — registration of the MDL scene-flag panel is handled by
streamline4_1.py, which owns the real MDLProperties PropertyGroup and
MDLPanel UI class.

This file previously contained a duplicate MDLProperties / MDLPanel pair
that was never registered (streamline4_1.py wins at register time). Those
definitions were removed in v1.9.10 to eliminate the dead code.

`__init__.py` still imports register_mdl_panel / unregister_mdl_panel
from this module, so we keep those as no-ops for backward compatibility
with the existing top-level call sites.
"""


def register_mdl_panel():
    # Registration handled by streamline4_1.py (via register_streamline_tools).
    pass


def unregister_mdl_panel():
    # Unregistration handled by streamline4_1.py.
    pass
