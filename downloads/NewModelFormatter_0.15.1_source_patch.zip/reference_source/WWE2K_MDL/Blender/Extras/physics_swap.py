"""
Physics Swap panel — source hair/body physics from a donor on export.

Source modes:
  - MCD (single file): a donor MCD/MDL; sidecars auto-discovered (2K25-) or embedded
    sub-streams extracted (2K26).
  - DIRECTORY (folder): dedicated physics files from older games, grouped by basename
    (<base>.hair_ywa / .hair_corr_ywa / .other_ywa / .other_corr_ywa); pin a basename
    or auto-pick the first complete set.

Every resolver returns {ext: wrapped_substream_blob} where the blob is
[u32 size][4-byte OUTER_TAG][raw payload] — exactly what replaceOrAddSubStreamByTag /
addRawSubStream consume (one call per override regardless of source).

Categories: Hair = HYWA (.hair_ywa) + HCYW (.hair_corr_ywa);
            Other = OYWA (.other_ywa) + OCYW (.other_corr_ywa).
"""

import bpy
import os
import struct
import ctypes
from bpy.props import StringProperty, BoolProperty, EnumProperty

from ...Link.wrapper import ExternalLibary, cmodellib
from ...Link.log import derror, dlog
from ...Serialize.physics_constants import PHYSICS_OUTER_TAGS as _ALL_PHYSICS_TAGS


# ── Extension groupings ─────────────────────────────────────────────────────

HAIR_EXTENSIONS  = ['.hair_ywa', '.hair_corr_ywa']
OTHER_EXTENSIONS = ['.other_ywa', '.other_corr_ywa']
ALL_EXTENSIONS   = HAIR_EXTENSIONS + OTHER_EXTENSIONS

# Full-attire outer tags only. physics_constants.PHYSICS_OUTER_TAGS is the superset
# (also CAS tags CYWA/YWA!); we filter to the four full-attire tags here. Re-exported
# under the historic name so external `physics_swap.PHYSICS_OUTER_TAGS` imports resolve.
PHYSICS_OUTER_TAGS = {
    tag: ext for tag, ext in _ALL_PHYSICS_TAGS.items() if ext in ALL_EXTENSIONS
}
EXT_TO_TAG = {v: k for k, v in PHYSICS_OUTER_TAGS.items()}

HAIR_TAGS  = {k for k, v in PHYSICS_OUTER_TAGS.items() if v in HAIR_EXTENSIONS}
OTHER_TAGS = {k for k, v in PHYSICS_OUTER_TAGS.items() if v in OTHER_EXTENSIONS}


# ═══════════════════════════════════════════════════════════════════════════
#  COMMON HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def _get_props():
    try:
        return bpy.context.scene.vcmodel_physics_swap
    except AttributeError:
        return None


def _active_extensions(props):
    """Subset of ALL_EXTENSIONS the user has opted into."""
    if not props or not props.enabled:
        return set()
    active = set()
    if props.swap_hair:
        active.update(HAIR_EXTENSIONS)
    if props.swap_other:
        active.update(OTHER_EXTENSIONS)
    return active


def _wrap_as_substream(payload: bytes, ext: str) -> bytes:
    """Wrap a raw physics-file payload into the MCD sub-stream layout
    [u32 size][4-byte TAG][payload]. Older-game sidecar files on disk are
    raw payloads, so they must be wrapped before injection."""
    tag = EXT_TO_TAG.get(ext)
    if not tag:
        return b''
    return struct.pack('<I', len(payload)) + tag + payload


def _looks_already_wrapped(blob: bytes, ext: str) -> bool:
    """Quick check: does this file content already start with [size][TAG]?
    Some 2K26 donor sidecar dumps may already be in sub-stream form."""
    if len(blob) < 8:
        return False
    tag = EXT_TO_TAG.get(ext)
    if not tag:
        return False
    declared = struct.unpack_from('<I', blob, 0)[0]
    return blob[4:8] == tag and declared == len(blob) - 8


def _read_payload_as_blob(filepath: str, ext: str) -> bytes:
    """Read a physics file from disk and return a wrapped sub-stream blob.
    Auto-detects whether the file is already wrapped or raw-payload."""
    with open(filepath, 'rb') as f:
        data = f.read()
    if _looks_already_wrapped(data, ext):
        return data
    return _wrap_as_substream(data, ext)


# ═══════════════════════════════════════════════════════════════════════════
#  MODE A — DONOR MCD (file picker)
# ═══════════════════════════════════════════════════════════════════════════

def _has_separate_sidecars(donor_path: str) -> bool:
    if not donor_path or not os.path.isfile(donor_path):
        return False
    donor_dir  = os.path.dirname(donor_path)
    donor_base = os.path.splitext(os.path.basename(donor_path))[0]
    for ext in ALL_EXTENSIONS:
        if os.path.exists(os.path.join(donor_dir, donor_base + ext)):
            return True
    return False


def _harvest_colliders_from_mcd(mcd_path: str) -> dict:
    """Load `mcd_path` as a CSkinModel and pull M_Head / M_Body /
    M_Combinations geometry. Returns {} on any failure.

    Used by all donor-resolution paths so the patcher can do real
    closest-triangle bindings even when the user's Blender scene
    doesn't include the baseModel head/body. The donor MCD itself
    has those meshes in its MDL section regardless of which physics
    flavor (HCYW/CYWA/sidecars) it ships.
    """
    colliders = {}
    if not mcd_path or not os.path.isfile(mcd_path):
        return colliders
    try:
        module = ExternalLibary()
        model_file = ctypes.c_void_p()
        skin_model = module.load_model(mcd_path.encode('utf-8'),
                                       ctypes.byref(model_file), False)
        if not skin_model or not model_file:
            return colliders
        try:
            from ...SkinModel.skinmesh import vCSkinMesh
            num_meshes = cmodellib.getNumMeshes(skin_model)
            wanted = {'M_Head', 'M_Body', 'M_Combinations'}
            for mi in range(num_meshes):
                mesh = vCSkinMesh(skin_model, mi)
                nm = mesh.mesh_name
                # mesh.vertices and .index_list are numpy ndarrays in
                # v2.3.1+ (skinmesh.py returns them directly). Avoid
                # bare-truthiness check — numpy raises ambiguity error on
                # non-scalar arrays.
                if (nm in wanted
                        and mesh.vertices is not None and len(mesh.vertices) > 0
                        and mesh.index_list is not None and len(mesh.index_list) > 0):
                    colliders[nm] = (list(mesh.vertices),
                                     list(mesh.index_list))
        finally:
            module.release_model_file(model_file)
    except Exception as e:
        derror(f"[Physics Swap] collider harvest from {mcd_path} skipped: {e}")
    return colliders


def _find_basemodel_mcd_near(seed_path: str, max_levels: int = 3) -> str:
    """Walk up from seed_path's dir for a baseModel.mcd (any case), stopping at
    max_levels. Modders place the baseModel near the attire (same dir, parent, or a
    basemodel/ sibling). Returns the path, or "" if not found.
    """
    if not seed_path:
        return ""
    candidates = ('baseModel.mcd', 'basemodel.mcd', 'BaseModel.mcd', 'BASEMODEL.MCD')
    cur = os.path.dirname(os.path.abspath(seed_path)) if os.path.isfile(seed_path) \
          else os.path.abspath(seed_path)
    for _ in range(max_levels + 1):
        for name in candidates:
            candidate = os.path.join(cur, name)
            if os.path.isfile(candidate):
                return candidate
        # Also peek into common sibling subdirs for the same baseModel name.
        for sib in ('basemodel', 'BaseModel', 'baseModel', '..'):
            sib_dir = os.path.join(cur, sib)
            if os.path.isdir(sib_dir):
                for name in candidates:
                    candidate = os.path.join(sib_dir, name)
                    if os.path.isfile(candidate):
                        return candidate
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return ""


def _harvest_colliders_with_fallback(primary_path: str) -> dict:
    """Try `primary_path` first; if it has no head/body geometry, walk up
    looking for a baseModel.mcd to use as a fallback. Logs clearly which
    source the colliders came from (or that nothing was found, so the user
    knows why their export got placeholder records).
    """
    colliders = _harvest_colliders_from_mcd(primary_path)
    if colliders and ('M_Head' in colliders or 'M_Body' in colliders):
        dlog(f"[Physics Swap] colliders harvested from donor "
             f"({os.path.basename(primary_path)}): {sorted(colliders.keys())}")
        return colliders

    # Donor is attire-only (no head/body in MDL). Look for baseModel.mcd.
    basemodel = _find_basemodel_mcd_near(primary_path)
    if basemodel:
        bm_colliders = _harvest_colliders_from_mcd(basemodel)
        if bm_colliders:
            dlog(f"[Physics Swap] donor MCD lacks M_Head/M_Body; using "
                 f"baseModel fallback at '{basemodel}' "
                 f"→ {sorted(bm_colliders.keys())}")
            # Merge: prefer donor's M_Combinations if present, baseModel's
            # head/body; fall through to whatever was found.
            merged = dict(bm_colliders)
            for k, v in colliders.items():
                if k not in merged:
                    merged[k] = v
            return merged

    if not colliders:
        dlog(f"[Physics Swap] no collider geometry found near donor "
             f"({os.path.basename(primary_path)}). Searched: donor MCD itself, "
             f"plus baseModel.mcd up to 3 directory levels above. The patcher "
             f"will write PLACEHOLDER physics records — physics will be wrong "
             f"in-game. Drop a baseModel.mcd next to the donor (or in the "
             f"parent directory) to get real collision bindings.")
    return colliders


def _resolve_from_mcd_sidecars(donor_path: str, active: set) -> dict:
    """Older-game style: load <basename>.<ext> sidecars next to the donor."""
    out = {}
    if not donor_path or not os.path.isfile(donor_path):
        return out
    donor_dir  = os.path.dirname(donor_path)
    donor_base = os.path.splitext(os.path.basename(donor_path))[0]
    for ext in active:
        sidecar = os.path.join(donor_dir, donor_base + ext)
        if os.path.exists(sidecar):
            out[ext] = _read_payload_as_blob(sidecar, ext)
    return out


def _resolve_from_mcd_substreams(donor_path: str, active: set,
                                 collect_colliders: bool = True
                                 ) -> tuple:
    """2K26: extract embedded physics sub-streams from the donor MCD. While loaded,
    also harvest M_Head/M_Body/M_Combinations geometry as a patcher collider fallback
    (when exporting attire-only). Returns (substreams, donor_colliders):
        substreams = {ext: wrapped_substream_blob}
        donor_colliders = {mesh_name: (verts_list, tris_list)}.
    """
    out = {}
    colliders = {}
    if not donor_path or not os.path.isfile(donor_path):
        return out, colliders
    try:
        module = ExternalLibary()
        model_file = ctypes.c_void_p()
        skin_model = module.load_model(donor_path.encode('utf-8'),
                                       ctypes.byref(model_file), False)
        if not skin_model or not model_file:
            return out, colliders
        try:
            num_streams = cmodellib.getNumRawSubStreams(skin_model)
            for i in range(num_streams):
                blob, size = cmodellib.getRawSubStreamData(skin_model, i)
                if not blob or size < 8:
                    continue
                tag = blob[4:8]
                if tag in PHYSICS_OUTER_TAGS:
                    ext = PHYSICS_OUTER_TAGS[tag]
                    if ext in active:
                        out[ext] = blob[:size]

            # Harvest collider geometry while the donor is loaded.
            if collect_colliders:
                try:
                    from ...SkinModel.skinmesh import vCSkinMesh
                    num_meshes = cmodellib.getNumMeshes(skin_model)
                    wanted = {'M_Head', 'M_Body', 'M_Combinations'}
                    for mi in range(num_meshes):
                        mesh = vCSkinMesh(skin_model, mi)
                        nm = mesh.mesh_name
                        # numpy ndarray-safe truthiness (see v2.3.1 note above)
                        if (nm in wanted
                                and mesh.vertices is not None and len(mesh.vertices) > 0
                                and mesh.index_list is not None and len(mesh.index_list) > 0):
                            colliders[nm] = (list(mesh.vertices),
                                             list(mesh.index_list))
                except Exception as e:
                    derror(f"[Physics Swap] collider harvest skipped: {e}")
        finally:
            module.release_model_file(model_file)
    except Exception as e:
        derror(f"[Physics Swap] Error extracting from donor MCD: {e}")
    return out, colliders


# ═══════════════════════════════════════════════════════════════════════════
#  MODE B — DONOR DIRECTORY (folder picker)
# ═══════════════════════════════════════════════════════════════════════════

def scan_directory_basenames(donor_dir: str) -> dict:
    """Group physics files in a directory by basename.

    Returns {basename: {ext: filepath, ...}}. Used by the panel to surface
    available donor sets and by the resolver to pick a default.
    """
    if not donor_dir or not os.path.isdir(donor_dir):
        return {}
    groups = {}
    try:
        entries = os.listdir(donor_dir)
    except OSError:
        return {}
    for name in entries:
        # Only LAST extension matters here; physics files are flat (.hair_ywa,
        # .hair_corr_ywa, .other_ywa, .other_corr_ywa) — splitext keeps the
        # everything-before-last-dot as the basename.
        base, ext = os.path.splitext(name)
        ext = ext.lower()
        if ext not in ALL_EXTENSIONS:
            continue
        full = os.path.join(donor_dir, name)
        if not os.path.isfile(full):
            continue
        groups.setdefault(base, {})[ext] = full
    return groups


def _pick_directory_basename(props, groups: dict) -> str:
    """Resolve which basename to use: user override, else first complete set,
    else first set with anything in the active categories, else None."""
    if not groups:
        return ""
    # Honor explicit user choice first
    requested = (props.donor_basename or "").strip()
    if requested:
        # Case-insensitive match for resilience against typos / casing
        for base in groups:
            if base.lower() == requested.lower():
                return base
        # Fallback: substring match (one entry, unambiguous)
        partial = [b for b in groups if requested.lower() in b.lower()]
        if len(partial) == 1:
            return partial[0]
        # No match — let caller surface "not found"
        return ""

    active = _active_extensions(props)

    # Prefer a basename that has every active extension
    for base, files in groups.items():
        if active.issubset(set(files.keys())):
            return base

    # Otherwise the first basename providing ANY active extension
    for base, files in groups.items():
        if any(e in files for e in active):
            return base

    # Last resort: first basename, period
    return next(iter(groups))


def _resolve_from_directory(donor_dir: str, active: set, props) -> tuple:
    """Returns (resolved_blobs, resolved_basename, all_groups)."""
    groups = scan_directory_basenames(donor_dir)
    if not groups:
        return {}, "", {}
    base = _pick_directory_basename(props, groups)
    if not base:
        return {}, "", groups
    files = groups[base]
    out = {}
    for ext in active:
        path = files.get(ext)
        if path:
            try:
                out[ext] = _read_payload_as_blob(path, ext)
            except OSError as e:
                derror(f"[Physics Swap] Could not read {path}: {e}")
    return out, base, groups


# ═══════════════════════════════════════════════════════════════════════════
#  PUBLIC API
# ═══════════════════════════════════════════════════════════════════════════

def get_physics_swap_substreams() -> tuple:
    """Resolve donor sub-stream blobs + collider geometry from user settings.

    Returns (substreams, donor_colliders):
        substreams = {ext: wrapped_substream_blob} for replaceOrAddSubStreamByTag.
        donor_colliders = {mesh_name: (verts, tris)} — M_Head/M_Body/M_Combinations
            harvested while loaded, as a patcher collider fallback when scene meshes
            lack the baseModel head/body. Empty for sidecar/directory modes (only the
            2K26 single-MCD path loads a CSkinModel).
    ({}, {}) if disabled, no donor, or no match.
    """
    props = _get_props()
    if not props or not props.enabled:
        return {}, {}
    active = _active_extensions(props)
    if not active:
        return {}, {}

    if props.source_mode == 'DIRECTORY':
        donor_dir = bpy.path.abspath(props.donor_directory) \
                    if props.donor_directory else ""
        blobs, _, _ = _resolve_from_directory(donor_dir, active, props)
        # Use the directory itself as the seed for the baseModel walk.
        colliders = {}
        if donor_dir and os.path.isdir(donor_dir):
            basemodel = _find_basemodel_mcd_near(donor_dir)
            if basemodel:
                colliders = _harvest_colliders_from_mcd(basemodel)
                if colliders:
                    dlog(f"[Physics Swap] colliders from directory-mode "
                         f"baseModel '{basemodel}' → {sorted(colliders.keys())}")
            if not colliders:
                dlog(f"[Physics Swap] directory donor in '{donor_dir}' has no "
                     f"baseModel.mcd nearby — patcher will use placeholder "
                     f"physics. Drop a baseModel.mcd in the donor directory "
                     f"for real collision bindings.")
        return blobs, colliders

    # Default: MCD file mode
    donor_path = bpy.path.abspath(props.donor_mcd_path) \
                 if props.donor_mcd_path else ""
    if not donor_path:
        return {}, {}
    if _has_separate_sidecars(donor_path):
        # Sidecar mode loads physics from .hair_ywa / .hair_corr_ywa /
        # etc. files. Try the donor MCD first (might be baseModel.mcd
        # itself); if it lacks head/body, walk for baseModel.
        return (_resolve_from_mcd_sidecars(donor_path, active),
                _harvest_colliders_with_fallback(donor_path))
    # 2K26 single-MCD mode — substreams are embedded in the MCD itself.
    blobs, colliders = _resolve_from_mcd_substreams(donor_path, active)
    if not colliders or ('M_Head' not in colliders and 'M_Body' not in colliders):
        # Donor MCD didn't have head/body in MDL (typical for attire
        # MCDs). Walk for baseModel as a fallback.
        fallback = _find_basemodel_mcd_near(donor_path)
        if fallback:
            bm = _harvest_colliders_from_mcd(fallback)
            if bm:
                merged = dict(bm)
                for k, v in (colliders or {}).items():
                    if k not in merged:
                        merged[k] = v
                colliders = merged
                dlog(f"[Physics Swap] donor MCD lacks M_Head/M_Body; using "
                     f"baseModel fallback at '{fallback}' "
                     f"→ {sorted(colliders.keys())}")
        if not colliders:
            dlog(f"[Physics Swap] no collider geometry found near "
                 f"'{donor_path}'. Patcher will write placeholder physics. "
                 f"Drop a baseModel.mcd next to the donor for real bindings.")
    return blobs, colliders


def get_skip_tags() -> set:
    """Outer-tag bytes the export should treat as 'overridden by swap'.
    Useful if the export pipeline wants to suppress source companions for
    extensions the swap is going to provide anyway."""
    props = _get_props()
    if not props or not props.enabled:
        return set()
    if props.source_mode == 'DIRECTORY':
        if not props.donor_directory:
            return set()
    else:
        if not props.donor_mcd_path:
            return set()
    tags = set()
    if props.swap_hair:
        tags.update(HAIR_TAGS)
    if props.swap_other:
        tags.update(OTHER_TAGS)
    return tags


# Path-based sidecar discovery — used by the panel status label to show "sidecars
# found" vs "embedded". The export pipeline goes through get_physics_swap_substreams.
def discover_physics_sidecars(donor_mcd_path: str) -> dict:
    """Returns {ext: filepath} for a donor MCD's sidecars, gated by the
    active categories."""
    props = _get_props()
    active = _active_extensions(props) if props else set(ALL_EXTENSIONS)
    if not active or not donor_mcd_path or not os.path.isfile(donor_mcd_path):
        return {}
    donor_dir  = os.path.dirname(donor_mcd_path)
    donor_base = os.path.splitext(os.path.basename(donor_mcd_path))[0]
    out = {}
    for ext in active:
        path = os.path.join(donor_dir, donor_base + ext)
        if os.path.exists(path):
            out[ext] = path
    return out


# ═══════════════════════════════════════════════════════════════════════════
#  PROPERTIES & OPERATORS
# ═══════════════════════════════════════════════════════════════════════════

class PhysicsSwapProperties(bpy.types.PropertyGroup):
    enabled: BoolProperty(
        name="Enable Physics Swap",
        description="Source selected physics data from the donor on export",
        default=False,
    )
    source_mode: EnumProperty(
        name="Source",
        description="Where the donor physics comes from",
        items=[
            ('MCD',
             "Donor MCD",
             "Pick one donor MCD/MDL. Sidecars next to it (2K25 and older) "
             "or its embedded sub-streams (2K26) provide the physics."),
            ('DIRECTORY',
             "Donor Directory",
             "Pick a folder of dedicated physics files (older-game dumps). "
             "Files are grouped by basename — pin a specific one or let the "
             "addon auto-pick the first complete set."),
        ],
        default='MCD',
    )
    donor_mcd_path: StringProperty(
        name="Donor MCD",
        description="Path to the donor MCD whose physics will be used on export",
        subtype='FILE_PATH', default="",
    )
    donor_directory: StringProperty(
        name="Donor Directory",
        description="Folder containing dedicated physics files "
                    "(.hair_ywa / .hair_corr_ywa / .other_ywa / .other_corr_ywa)",
        subtype='DIR_PATH', default="",
    )
    donor_basename: StringProperty(
        name="Basename",
        description="Pin a specific basename within the directory. Leave blank "
                    "to auto-pick the first complete set",
        default="",
    )
    swap_hair: BoolProperty(
        name="Hair (HYWA / HCYW)",
        description="Swap hair sim and hair corrective data from donor",
        default=True,
    )
    swap_other: BoolProperty(
        name="Other (OYWA / OCYW)",
        description="Swap body/attire sim and corrective data from donor",
        default=False,
    )


class VCMODEL_OT_BrowsePhysicsDonorMcd(bpy.types.Operator):
    """File browser for a donor MCD/MDL → props.donor_mcd_path. Explicit Browse
    affordance (the built-in FILE_PATH folder icon gets squeezed by the Clear button).
    """
    bl_idname = "vcmodel.browse_physics_donor_mcd"
    bl_label = "Browse"
    bl_description = "Choose a donor MCD/MDL file"
    bl_options = {'INTERNAL'}

    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default="*.mcd;*.mdl", options={'HIDDEN'})

    def execute(self, context):
        props = context.scene.vcmodel_physics_swap
        props.donor_mcd_path = self.filepath
        return {'FINISHED'}

    def invoke(self, context, event):
        # Pre-seed the browser with the existing path if the user is
        # picking a replacement, so they don't restart from /home/.
        props = context.scene.vcmodel_physics_swap
        if props.donor_mcd_path:
            self.filepath = bpy.path.abspath(props.donor_mcd_path)  # pre-seed the browser
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class VCMODEL_OT_BrowsePhysicsDonorDir(bpy.types.Operator):
    """File browser for a donor physics directory. On select, also auto-fills the
    basename so a complete donor set is already chosen for the common one-set case.
    """
    bl_idname = "vcmodel.browse_physics_donor_dir"
    bl_label = "Browse"
    bl_description = "Choose a folder containing donor physics files"
    bl_options = {'INTERNAL'}

    # fileselect_add with a `directory` prop returns the navigated-into directory
    # (any highlighted file ignored); filename exists only so the field is present.
    directory: StringProperty(subtype='DIR_PATH')
    filename: StringProperty()
    filter_glob: StringProperty(default="", options={'HIDDEN'})

    def execute(self, context):
        props = context.scene.vcmodel_physics_swap
        props.donor_directory = self.directory
        # Auto-fill basename from whatever complete set the directory
        # turns out to contain. If there's nothing in there, the
        # auto-fill operator no-ops and the user sees the
        # "no physics files" status hint in the panel.
        try:
            bpy.ops.vcmodel.physics_swap_autofill_basename()  # auto-fill if a set exists
        except Exception:
            pass
        return {'FINISHED'}

    def invoke(self, context, event):
        props = context.scene.vcmodel_physics_swap
        if props.donor_directory:
            self.directory = bpy.path.abspath(props.donor_directory)
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class VCMODEL_OT_ClearPhysicsSwap(bpy.types.Operator):
    """Clear donor paths and disable the swap"""
    bl_idname = "vcmodel.clear_physics_swap"
    bl_label = "Clear"

    def execute(self, context):
        props = context.scene.vcmodel_physics_swap
        props.donor_mcd_path = ""
        props.donor_directory = ""
        props.donor_basename = ""
        props.enabled = False
        return {'FINISHED'}


class VCMODEL_OT_AutoFillBasename(bpy.types.Operator):
    """Fill the basename field with the first detected donor set in the directory"""
    bl_idname = "vcmodel.physics_swap_autofill_basename"
    bl_label = "Auto"

    def execute(self, context):
        props = context.scene.vcmodel_physics_swap
        donor_dir = bpy.path.abspath(props.donor_directory) \
                    if props.donor_directory else ""
        groups = scan_directory_basenames(donor_dir)
        if not groups:
            self.report({'WARNING'}, "No physics files found in directory.")
            return {'CANCELLED'}
        chosen = _pick_directory_basename(props, groups)
        if not chosen:
            self.report({'WARNING'}, "No matching donor set in directory.")
            return {'CANCELLED'}
        props.donor_basename = chosen
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════════
#  PANEL
# ═══════════════════════════════════════════════════════════════════════════

class VCMODEL_PT_PhysicsSwapPanel(bpy.types.Panel):
    bl_label = "Physics Swap"
    bl_idname = "VCMODEL_PT_PhysicsSwapPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'MDL Tools'
    bl_order = 25
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        self.layout.label(text="", icon='PHYSICS')

    def draw(self, context):
        layout = self.layout
        props = context.scene.vcmodel_physics_swap

        # ── Enable toggle ──
        row = layout.row(align=True)
        row.prop(props, "enabled", text="Enable",
                 icon='PLAY' if props.enabled else 'PAUSE')
        if props.enabled:
            sub = row.row(align=True)
            sub.alignment = 'RIGHT'
            sub.label(text="Active", icon='CHECKMARK')

        layout.separator(factor=0.3)

        # ── Source selector ──
        body = layout.column()
        body.enabled = props.enabled

        body.label(text="Donor Source", icon='IMPORT')
        body.prop(props, "source_mode", expand=True)

        # ── Source-specific picker ──
        box = body.box()
        if props.source_mode == 'MCD':
            box.label(text="Donor MCD / MDL", icon='FILE_3D')
            # Three-button row (input, Browse, Clear): explicit Browse since the
            # built-in folder icon gets squeezed by the adjacent Clear button.
            row = box.row(align=True)
            row.prop(props, "donor_mcd_path", text="")
            row.operator("vcmodel.browse_physics_donor_mcd",
                         text="", icon='FILEBROWSER')
            row.operator("vcmodel.clear_physics_swap", text="", icon='X')
        else:
            box.label(text="Donor Directory", icon='FILE_FOLDER')
            row = box.row(align=True)
            row.prop(props, "donor_directory", text="")
            row.operator("vcmodel.browse_physics_donor_dir",
                         text="", icon='FILEBROWSER')
            row.operator("vcmodel.clear_physics_swap", text="", icon='X')

            row = box.row(align=True)
            row.prop(props, "donor_basename", text="Basename",
                     icon='OUTLINER_OB_FONT')
            row.operator("vcmodel.physics_swap_autofill_basename",
                         text="", icon='SHADERFX')

        body.separator(factor=0.3)

        # ── Category toggles ──
        body.label(text="Categories", icon='FILTER')
        row = body.row(align=True)
        row.prop(props, "swap_hair",  text="Hair",  toggle=True,
                 icon='PARTICLE_DATA')
        row.prop(props, "swap_other", text="Other", toggle=True,
                 icon='MESH_DATA')

        # ── Status / Preview ──
        if props.enabled:
            self._draw_status(layout, props)

    # ── Status helpers ─────────────────────────────────────────────────────

    def _draw_status(self, layout, props):
        active = _active_extensions(props)
        if not active:
            layout.separator(factor=0.3)
            layout.box().label(text="No categories selected", icon='ERROR')
            return

        if props.source_mode == 'MCD':
            self._draw_mcd_status(layout, props, active)
        else:
            self._draw_directory_status(layout, props, active)

    def _draw_mcd_status(self, layout, props, active):
        if not props.donor_mcd_path:
            return
        donor_path = bpy.path.abspath(props.donor_mcd_path)
        layout.separator(factor=0.3)
        status_box = layout.box()
        if not os.path.exists(donor_path):
            status_box.label(text="File not found", icon='ERROR')
            return

        sidecar_paths = discover_physics_sidecars(donor_path)
        if sidecar_paths:
            status_box.label(text="Sidecar files found", icon='CHECKMARK')
            col = status_box.column(align=True)
            for ext, path in sidecar_paths.items():
                size_kb = os.path.getsize(path) / 1024
                col.label(text=f"  {ext}  ({size_kb:.0f} KB)", icon='FILE_TICK')
        else:
            status_box.label(text="Embedded — extracted on export", icon='INFO')

    def _draw_directory_status(self, layout, props, active):
        if not props.donor_directory:
            return
        donor_dir = bpy.path.abspath(props.donor_directory)
        layout.separator(factor=0.3)
        status_box = layout.box()
        if not os.path.isdir(donor_dir):
            status_box.label(text="Directory not found", icon='ERROR')
            return

        groups = scan_directory_basenames(donor_dir)
        if not groups:
            status_box.label(text="No physics files in directory", icon='ERROR')
            return

        chosen = _pick_directory_basename(props, groups)
        if not chosen:
            status_box.label(text="No matching basename — set 'Basename' or "
                                  "use Auto", icon='ERROR')
            return

        files = groups[chosen]
        present_active = [e for e in active if e in files]
        missing_active = [e for e in active if e not in files]

        head_icon = 'CHECKMARK' if not missing_active else 'INFO'
        head_text = f"Donor set: {chosen}"
        status_box.label(text=head_text, icon=head_icon)

        col = status_box.column(align=True)
        for ext in present_active:
            size_kb = os.path.getsize(files[ext]) / 1024
            col.label(text=f"  {ext}  ({size_kb:.0f} KB)", icon='FILE_TICK')
        for ext in missing_active:
            col.label(text=f"  {ext}  (missing)", icon='X')

        # Tell the user when there are other choices in the folder
        if len(groups) > 1:
            status_box.separator(factor=0.3)
            extra = sorted(b for b in groups if b != chosen)
            preview = ", ".join(extra[:3])
            if len(extra) > 3:
                preview += f", … (+{len(extra) - 3} more)"
            status_box.label(text=f"Other sets: {preview}", icon='COLLAPSEMENU')


# ═══════════════════════════════════════════════════════════════════════════
#  REGISTRATION
# ═══════════════════════════════════════════════════════════════════════════

_CLASSES = (
    PhysicsSwapProperties,
    VCMODEL_OT_BrowsePhysicsDonorMcd,
    VCMODEL_OT_BrowsePhysicsDonorDir,
    VCMODEL_OT_ClearPhysicsSwap,
    VCMODEL_OT_AutoFillBasename,
    # VCMODEL_PT_PhysicsSwapPanel intentionally NOT registered (2026-07):
    # its 'MDL Tools' sidebar slot (bl_order 25) now hosts the 2K26
    # Materials overview panel (material_export_panel.
    # VCMODEL_PT_MaterialsOverview). The swap feature itself remains fully
    # functional — properties/operators stay registered and the export
    # pipeline still honors a .blend with vcmodel_physics_swap.enabled
    # (disable via F3 search > "Clear" / vcmodel.clear_physics_swap).
    # Re-adding the class here restores the UI.
)


def register_physics_swap():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.vcmodel_physics_swap = bpy.props.PointerProperty(
        type=PhysicsSwapProperties)


def unregister_physics_swap():
    if hasattr(bpy.types.Scene, "vcmodel_physics_swap"):
        del bpy.types.Scene.vcmodel_physics_swap
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
