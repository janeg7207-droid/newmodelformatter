import bpy
import os
from ..blender_points   import getSceneAttachPoints, vCAttachPoint
from ..blender_save     import getMeshSelection, has_armature_modifier
from ..blender_scene    import getNewSceneCollection
from ..blender_skeleton import *
from ...Link.log import dlog, derror

def get_scene_armature_object():
    selection = getMeshSelection()
    bpy.context.view_layer.update()

    for obj in selection:
        if (has_armature_modifier(obj)):
            armature = obj.parent
            return armature
    
    return None

def run_ap_builder():
    # Creates default APs, must select a skeleton to retrieve APs
    points = getSceneAttachPoints()
    if (not points): return

    file_dir = os.path.dirname(os.path.abspath(__file__))
    vCAttachPoint.serialize_to_json(points, file_dir + "/default_char_APs.json")
    return

def get_default_aps():
    try:
        file_dir = os.path.dirname(os.path.abspath(__file__))
        default_points = vCAttachPoint.points_from_json(file_dir + "/default_char_APs.json")
        return default_points
    except:
        return None
    
def filter_points(armature, points_list):
    filtered_points = []

    for point in points_list:
        index = find_bone_index(armature, point.bone_id)
        if index is not None:
            point.joint = index
            filtered_points.append(point)

    return filtered_points

def run_ap_gen():
    armature_obj = get_scene_armature_object()
    if not armature_obj:
        derror("[AP Gen] Failed to retrieve user skeleton")
        return False

    default_points = get_default_aps()
    if not default_points: 
        derror("[AP Gen] Failed to retrieve user APs")
        return False
    
    if not armature_obj.users_collection:
        derror("[AP Gen] Failed to find top level collection")
        return False

    # create a new collection under model hierarchy 
    collection = armature_obj.users_collection[0]
    ap_col = getNewSceneCollection("Model APs", False)
    collection.children.link(ap_col)

    # create ap root node
    root = build_sphere("ap_root", ap_col)
    root.hide_set(True)

    # filter for non existing bone nodes
    default_points = filter_points(armature_obj, default_points)
    load_attachment_points(ap_col, root, armature_obj, default_points)
    dlog(f"[AP Gen] Found {len(default_points)} points. Operation complete.")
    return True

class VCAutoGenCharAPs(bpy.types.Operator):
    bl_idname = "object.generate_vc_char_aps"
    bl_label = "Generate Character APs"
    bl_description = "Generates attachment point nodes for character models"

    def execute(self, context):
        # run_ap_builder()
        run_ap_gen()
        return {'FINISHED'}

def register_vc_ap_generator():
    bpy.utils.register_class(VCAutoGenCharAPs)

def unregister_vc_ap_generator():
    bpy.utils.unregister_class(VCAutoGenCharAPs)


