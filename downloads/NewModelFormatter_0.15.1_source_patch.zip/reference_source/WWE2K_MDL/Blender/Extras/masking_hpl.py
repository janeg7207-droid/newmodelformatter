import bpy
import os
import io
import json
import numpy as np
from typing import NamedTuple

from bpy.types import Operator
from bpy_extras.io_utils import ExportHelper
from bpy.props import StringProperty
from ...Link.log import dwarn

class HPLObject(NamedTuple):
    sceneFlag: int
    name: str
    visibility_vector: list

class HPLLods(NamedTuple):
    lodLevel: int
    objects: list

class modelLods(NamedTuple):
    name: str
    flag: int
    indices: list

def roundUp( numToRound , multiple ):
    if (multiple == 0): return numToRound
    remainder = numToRound % multiple
    if (remainder == 0): return numToRound
    return (numToRound + multiple - remainder)

def checkAlignment(  value ):
    return roundUp( value , 4 )

def getLODsFromFlagIndex(sceneLODs,name,flag):
    for lod in sceneLODs:
        if (name == lod[0]) and (flag == lod[1]):
            return lod
        
    return False

def cleanSpecialMeshString(string):
    # Strip Blender's ".NNN" duplicate suffix (rsplit on the LAST period; ".001"
    # always trails).
    if "." in string:
        parts = string.rsplit(".", 1)
        if len(parts) == 2 and parts[1].isdigit():
            string = parts[0]
    # Strip appearance-flag markers (must rebind — str.replace returns a new string;
    # the old code discarded the result).
    string = string.replace('?', '')
    string = string.replace('!', '')
    string = string.replace('$', '')
    return string

#Returns Bytes object containing HPL buffer
def getBinaryHPL( sceneLODs, sceneMeshes, flagCeiling ):
    # Minimal empty form: when no mesh contributes masked verts (no HPL groups, or
    # all empty — the "Generate Empty HPL" case), emit just HPL!+END!+0. Matches the
    # hand-crafted zero-mask HPLs and avoids the 92-byte skeleton form that some game
    # builds misread as stray mask regions.
    has_content = any(
        LOD and len(LOD[2]) > 0 for LOD in sceneLODs
    ) if sceneLODs else False
    if not sceneMeshes or not has_content:
        return b'HPL!' + b'END!' + b'\x00\x00\x00\x00'

    in_memory = io.BytesIO(b'HPL!')
    in_memory.seek(0, 2)  # Position at end; subsequent writes are all appends.
    numLods = 5 # Amount of lod levels

    for i in range(numLods):
        in_memory.write( b'LOD!' )
        in_memory.write( int(i).to_bytes(4, 'little') ) #lodLevel

        #Iterate through DATA buffer
        for flag in range(flagCeiling+1):
            in_memory.write( b'DATA' )
            in_memory.write( int(flag).to_bytes(4, 'little') ) #lodLevel

            for meshName in sceneMeshes:
                LODs = getLODsFromFlagIndex(sceneLODs,meshName,flag)
                # Skip the MESH block for an empty vertex list. A 0-vert MESH marker
                # (the old "Generate Empty HPL" output) is misread as stray mask data
                # by some builds → random masking spots. parseHPL handles absent MESH
                # blocks cleanly, so no compatibility loss; a real mask writes normally.
                if LODs and len(LODs[2]) > 0:
                    in_memory.write( b'MESH' )
                    writeBinaryStringToBuffer( in_memory, cleanSpecialMeshString( LODs[0] ) )
                    # Pad to 4-byte boundary (-tell() & 3) without materializing the buffer.
                    in_memory.write( b'\x00' * (-in_memory.tell() & 3) )
                    in_memory.write( int(len(LODs[2])).to_bytes(4, 'little') ) #length of affected vertices

                    # Write the whole vertex-index array in one shot as LE u32.
                    in_memory.write( np.asarray(LODs[2], dtype='<u4').tobytes() )

    #buffer end signature
    in_memory.write( b'END!' )
    in_memory.write( int(0).to_bytes(4, 'little') ) #lodLevel

    return in_memory.getvalue()

def createHPLFile( filePath, sceneLODs, sceneMeshes, flagCeiling ):
    # Don't swallow OSError — a permission/path error used to return cleanly while
    # the pipeline reported FINISHED with no file written. Warn + re-raise.
    try:
        with open(filePath, 'wb') as file:
            file.write( getBinaryHPL(sceneLODs,sceneMeshes, flagCeiling) )  #Write Binaries
    except OSError as e:
        dwarn(f"[HPL Export] Could not open/write file: {filePath} ({e})")
        raise

def findDirHPL( modelPath ):
    #Search for first hpl
    path = os.path.dirname(modelPath)
    for file in os.listdir(path):
        if file.endswith(".hpl"):
            return os.path.join(path, file)
    return False

def getHPLPath( modelPath ):
    #Splits directory path and appends .hpl extension
    path = os.path.dirname(modelPath)
    fileName = os.path.basename(modelPath).split(".model")[0] + ".hpl"
    return os.path.join(path, fileName) #return path

def readMESH(hplBuffer,hplBfDef,sceneFlagGlobal):
    #Get Visibility Flags
    meshCharLength = int.from_bytes( hplBuffer.read(4) , "little" )
    meshName = hplBuffer.read(meshCharLength).decode("utf-8")
    hplObj = HPLObject(sceneFlag=sceneFlagGlobal, name=meshName, visibility_vector=[])

    #align position
    alignPos = checkAlignment( hplBuffer.tell() )
    hplBuffer.seek( alignPos )
    numVisibleVerts = int.from_bytes( hplBuffer.read(4) , "little" )

    #Collect Array — bulk read as little-endian u32 then convert to list.
    if numVisibleVerts:
        hplObj.visibility_vector.extend(
            np.frombuffer(hplBuffer.read(numVisibleVerts * 4), dtype='<u4').tolist()
        )

    hplBfDef.objects.append(hplObj)
    return

def writeBinaryStringToBuffer( buffer, string ):
    # Caller keeps the cursor at end-of-stream, so no pre-write seek(0,2) is needed.
    buffer.write( int(len(string)).to_bytes(4, 'little') ) #Append Character Length
    buffer.write( string.encode('utf-8') )
    buffer.write( b'\x00' )

def switch(hplBuffer,blockMagic,hplBfDef,sceneFlagGlobal):
    #Evaluate Type
    if blockMagic == b'LOD!':
        lodIdx = int.from_bytes( hplBuffer.read(4) , "little" )
        hplBfDef = HPLLods(lodLevel=lodIdx, objects=[])
    elif blockMagic == b'DATA':
        sceneFlagGlobal = int.from_bytes( hplBuffer.read(4) , "little" )
    elif blockMagic == b'MESH':
        readMESH(hplBuffer,hplBfDef,sceneFlagGlobal)
    return hplBfDef,sceneFlagGlobal

def parseHPL( hplBuffer ):
    #Create an HPL vector and store all parsed entries
    hplDefs = []
    fileSig = hplBuffer.read(4)
    if (fileSig != b'HPL!'): return False
    
    #Iterate/Collect data until file end
    bufferSig = hplBuffer.read(4)
    while( bufferSig != b'END!'):
        # Guard a truncated HPL with no END! marker — otherwise both loops spin
        # forever on repeated b'' reads, hanging Blender.
        if bufferSig == b'':
            raise ValueError("HPL parse failed: unexpected EOF before END! marker")
        sceneFlagGlobal = 0 #Default as zero, modify as we parse
        hplBfDef = HPLLods(lodLevel=None,objects=None)
        subLODbf = b''
        while( subLODbf != b'LOD!' and subLODbf != b'END!'):
            #Parse data only through specified LOD level
            hplBfDef,sceneFlagGlobal = switch(hplBuffer,bufferSig,hplBfDef,sceneFlagGlobal)
            subLODbf = hplBuffer.read(4)
            if subLODbf == b'':
                raise ValueError("HPL parse failed: unexpected EOF inside LOD block")
            bufferSig = subLODbf
        bufferSig = subLODbf
        hplDefs.append(hplBfDef)
    return hplDefs

def readHPLFile( hplPath ):
    if os.path.exists(hplPath):
        with open(hplPath, 'rb') as file:
            return parseHPL(file)
    else:
        return False

def getActiveModels():
    selection_names = bpy.context.selected_objects
    selection_ = []
    
    for sel in selection_names:
        if sel.type == 'MESH':
            selection_.append( sel )
            
    return selection_

def exportSceneHPL( filepath ):
    bpy.ops.object.mode_set(mode='OBJECT')
    sceneModels = getActiveModels()

    if ( len( sceneModels ) == 0 ):
        dwarn( "[HPL Export] No objects selected." )
        return
    else:
        generateHPL(sceneModels,filepath)
 
def generateHPL( sceneModels , outFile ):
    if not outFile.endswith(".hpl"):
        outFile = getHPLPath(outFile)
    sceneMaps = []
    sceneMeshes = []
    flagCeiling = -1    #Informs how many DATA buffers to look for

    #Collect all valid masks found in scene selection
    for model in sceneModels:
        vertexGroups = model.vertex_groups

        if len(vertexGroups) != 0:

            # Pre-cache per-group membership in ONE walk over the vertex list (the old
            # nested per-group comprehension was orders of magnitude slower on bodies
            # with many HPL groups). Same shape as hpl_roundtrip.collect_hpl_from_scene.
            hpl_group_indices = {g.index for g in vertexGroups if g.name.startswith("HPL_")}
            group_to_verts = {gi: [] for gi in hpl_group_indices}
            if hpl_group_indices:
                for v in model.data.vertices:
                    for vg in v.groups:
                        if vg.group in hpl_group_indices:
                            group_to_verts[vg.group].append(v.index)

            # Strip ".NNN" at COLLECTION time so sceneMeshes / modelLods.name already
            # match what cleanSpecialMeshString writes — else a re-imported "M_Body.001"
            # propagates a raw lookup key through getLODsFromFlagIndex and mis-matches.
            modelName = cleanSpecialMeshString(model.data.name)

            # Index space: vcmodel_vertex_remap → MCD order (vanilla baseModel); else
            # simulate the export split so HPL indices match the post-split baseModel.
            vremap = None
            split_map = None
            raw_remap = model.get("vcmodel_vertex_remap")
            if raw_remap is not None:
                try:
                    vremap = json.loads(raw_remap)
                except (json.JSONDecodeError, TypeError):
                    vremap = None

            if not vremap:
                try:
                    from ...Serialize.hpl_roundtrip import _simulate_export_split
                    split_map = _simulate_export_split(model)
                except Exception:
                    split_map = None

            # Pick HPL groups by NAME, not iteration order. The engine reads exactly
            # two flag channels: flag 0 (Ring), flag 1 (Entrance). The old "first two
            # HPL_ groups by list order" let a leftover HPL_Test/HPL_Old eat a slot and
            # silently drop the real mask ("works for some meshes, not others"). By-name
            # lookup is deterministic; other HPL_ groups are ignored cleanly.
            ring_vg = vertexGroups.get("HPL_Ring")
            entrance_vg = vertexGroups.get("HPL_Entrance")
            mesh_contributed = False
            for sceneFlag, vg in ((0, ring_vg), (1, entrance_vg)):
                if vg is None:
                    continue
                vertex_indices = group_to_verts.get(vg.index, [])

                # Remap indices to the correct space
                if vremap and vertex_indices:
                    remapped = []
                    for bi in vertex_indices:
                        if bi < len(vremap):
                            remapped.append(vremap[bi])
                    vertex_indices = remapped
                elif split_map and vertex_indices:
                    expanded = []
                    for bi in vertex_indices:
                        clones = split_map.get(bi)
                        if clones:
                            expanded.extend(clones)
                        else:
                            expanded.append(bi)
                    vertex_indices = expanded

                if not vertex_indices:
                    # Empty HPL group — skip (a 0-vert MESH block is misread as stray
                    # mask data; see getBinaryHPL).
                    continue

                lodSet = modelLods(name=modelName, flag=sceneFlag, indices=vertex_indices)
                sceneMaps.append(lodSet)
                if sceneFlag > flagCeiling:
                    flagCeiling = sceneFlag
                mesh_contributed = True

            if mesh_contributed and modelName not in sceneMeshes:
                sceneMeshes.append(modelName)


    # No HPL groups contributed (flagCeiling == -1): still write a file — getBinaryHPL's
    # empty-form early-out emits the minimal HPL!/END! payload from empty inputs.
    if flagCeiling == -1:
        sceneMaps = []
        sceneMeshes = []
        flagCeiling = 0
    createHPLFile( outFile , sceneMaps , sceneMeshes, flagCeiling)

def write_some_data_hpl(context, filepath):
    exportSceneHPL( filepath )
    bpy.ops.object.mode_set(mode='OBJECT')
    return {'FINISHED'}

class ExportHPLData(Operator, ExportHelper):
    """Export masks from selected objects"""
    bl_idname = "export_hpl.some_data"
    bl_label = "Export HPL!"

    # ExportHelper mixin class uses this
    filename_ext = ".hpl"

    filter_glob: StringProperty(
        default="*.hpl",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    def execute(self, context):
        keywords = self.as_keywords(
            ignore=(
                "axis_forward",
                "axis_up",
                "global_scale",
                "check_existing",
                "filter_glob",
            ),
        )

        return write_some_data_hpl(context, self.filepath)

def menu_func_export_hpl(self, context):
    self.layout.operator(ExportHPLData.bl_idname, text="WWE 2K HPL (.hpl)") 

def register_hpl_export():
    bpy.utils.register_class(ExportHPLData)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export_hpl)
    return

def unregister_hpl_export():
    bpy.utils.unregister_class(ExportHPLData)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export_hpl)
    return

