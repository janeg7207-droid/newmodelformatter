"""GtPt anchor generator — transfers GtPt records from a user-picked source
baseModel.mcd onto the current scene's matching meshes.

Workflow: click → (confirm if hand-tuned anchors exist) → file browser → pick a
vanilla baseModel.mcd → load it, read its 13 GtPt records, resolve each to a user
target vertex (see _resolve_target_vertex) → wipe existing anchors → drop empties +
bind vertex groups. User-pick (not a bundled ref) so anchors match the studio-tuned
per-character placement.

baseModel_ref_26.mcd is still bundled for skeleton_remap / ctg_generator; the
generator no longer defaults to it, but _load_ref_model falls back to it on None.
"""

import bpy
import os
import ctypes
from mathutils import Vector

from ...Link.log    import dlog, dwarn, derror
from ...Link.wrapper import ExternalLibary, cmodellib
from ...SkinModel.skinmodel import vCSkinModel
from ...Serialize.gtpt_resolver import (
    GROUP_MERGE_FALLBACKS,
    _nearest_vertex,
    canonical_mesh_name_from_str,
)
from ...SkinModel.skinmodel_gp import gtpt_vertex_group_name
from ..blender_save import getMeshSelection
from ..blender_gtpt import (
    GTPT_COLLECTION_NAME, _create_anchor_empty, _get_or_create_collection,
    _find_mesh_by_name, _vertex_world_position, _attach_vertex_group,
)


# Scene-level storage for the last source baseModel.mcd path. Lets the
# file browser pre-fill with whatever the user picked last session so
# they don't have to navigate back to the same folder on every Generate
# click. Registered via register_vc_gtpt_generator alongside the operator.
LAST_SOURCE_PATH_PROP = 'vcmodel_last_gtpt_source_path'


REF_FILENAME = 'baseModel_ref_26.mcd'


def _ref_mcd_path():
    """Absolute path to the bundled reference baseModel."""
    here = os.path.dirname(os.path.abspath(__file__))
    # Extras/ → Blender/ → addon root → Serialize/
    addon_root = os.path.dirname(os.path.dirname(here))
    return os.path.join(addon_root, 'Serialize', REF_FILENAME)


def _get_user_root_collection():
    """Find the collection the user's selected mesh lives in.

    Mirrors the AtPt generator's selection logic — picks the topmost
    collection that contains a mesh with an armature modifier. Lets
    users click a head mesh and have anchors generated under that
    character's collection rather than at scene root.
    """
    selection = getMeshSelection()
    bpy.context.view_layer.update()

    for obj in selection:
        # Walk up to find the parent collection — the AtPt generator
        # uses obj.parent.users_collection[0] (parent armature's
        # collection); we use the same path so the generated GtPt
        # collection lives next to the AtPt collection in the outliner.
        if obj.parent is not None and obj.parent.users_collection:
            return obj.parent.users_collection[0]
        if obj.users_collection:
            return obj.users_collection[0]

    # Fall back to scene root collection. Better than failing the
    # generation entirely — user can drag the anchor collection
    # wherever they want afterward.
    return bpy.context.scene.collection


def _load_ref_model(source_path=None):
    """Load a source baseModel.mcd via the DLL into a vCSkinModel.

    Args:
        source_path: Absolute path to a .mcd file. When None, falls back
                     to the bundled baseModel_ref_26.mcd. The user-pick
                     workflow always passes an explicit path; the bundle
                     is the implicit default for code that hasn't been
                     migrated.

    Returns (model, file_handle) — both must stay alive until anchor
    extraction is complete. Caller is responsible for calling
    _release_ref_model(file_handle) after use.

    Returns (None, None) on any load failure (file missing, DLL load
    error, not a valid MCD, etc.) — caller surfaces a UI error.
    """
    ref_path = source_path if source_path else _ref_mcd_path()
    if not ref_path or not os.path.exists(ref_path):
        return None, None
    try:
        module = ExternalLibary()
        file_handle = ctypes.c_void_p()
        skin_data = module.load_model(
            ref_path.encode('utf-8'), ctypes.byref(file_handle), False)
        if not skin_data:
            return None, None
        model = vCSkinModel(skin_data)
        return model, file_handle
    except Exception as e:
        derror(f"[GtPt Gen] Failed to load source baseModel: {e}")
        return None, None


def _release_ref_model(file_handle):
    """Release the file handle returned by _load_ref_model."""
    if file_handle is None:
        return
    try:
        module = ExternalLibary()
        module.release_model_file(file_handle)
    except Exception:
        pass


def _extract_source_anchors(source_model):
    """Pull GtPt records out of the source MCD with enough data for
    both exact-passthrough vertex mapping and nearest-vertex fallback.

    Returns a list of dicts per record:
      {
        'name':           anchor name string ('_ag_0005'),
        'group_name':     source mesh name ('M_Head_Caruncle'),
        'slot':           int slot,
        'source_vertex':  int vertex index on the source mesh,
        'source_local':   (x, y, z) source vertex's local position,
        'source_group_vert_count':   total verts on source mesh
                                     (e.g., M_Head_Caruncle has ~50),
        'source_head_vert_count':    total verts on source M_Head
                                     (precomputed for the caruncle-merge
                                     offset case; 0 if M_Head missing in
                                     source — shouldn't happen).
      }

    The source_local coord plus the source's mesh transform gives world
    position when needed. Most callers do fallback nearest-vertex search
    against the user's mesh, which only needs world coords.

    The vert-count fields drive the exact-passthrough decision in
    _resolve_target_vertex: caruncle vertex N on source becomes
    head_count + N on a merged user head, IFF the user's M_Head has
    exactly head_count + caruncle_count verts. Detected at apply time.
    """
    if source_model is None or source_model.goto_points is None:
        return []

    # Index source meshes by canonical name.
    meshes_by_name = {}
    for mesh in source_model.getMeshes():
        meshes_by_name[mesh.mesh_name] = mesh

    head_mesh = meshes_by_name.get('M_Head')
    # NB: mesh.vertices is a numpy array — testing it for truthiness raises
    # "truth value of an array is ambiguous". Guard with `is not None` (mirrors
    # the per-record check below). This line errored on EVERY base-model source
    # (M_Head always present), which is why Generate GtPts failed on MCD select.
    head_vert_count = (len(head_mesh.vertices)
                       if head_mesh is not None and head_mesh.vertices is not None
                       else 0)

    out = []
    for p in source_model.goto_points:
        if not p.name or not p.group_name:
            continue
        src_mesh = meshes_by_name.get(p.group_name)
        if src_mesh is None:
            continue
        verts = src_mesh.vertices
        if verts is None:
            continue
        vi = p.vertex_index
        if vi < 0 or vi >= len(verts):
            continue
        v = verts[vi]
        # verts is a numpy (N,3) array, so a row is indexed [0]/[1]/[2] — it has
        # no .x/.y/.z attributes (the old code assumed a Vector type and raised
        # AttributeError on every record).
        out.append({
            'name': p.name,
            'group_name': p.group_name,
            'slot': int(p.slot),
            'source_vertex': int(vi),
            'source_local': (float(v[0]), float(v[1]), float(v[2])),
            'source_group_vert_count': len(verts),
            'source_head_vert_count':  head_vert_count,
        })
    return out


def _wipe_existing_anchors(parent_collection):
    """Remove the existing VC_GtPt_Anchors collection + empties and ALL VC_GTPT__*
    vertex groups across every user mesh (mesh-wide, since a prior source may have
    left groups on M_Head_Caruncle/M_Teeth/etc.). Generate is a rebuild-from-scratch.
    """
    import bpy as _bpy

    # 1. Remove every empty in the anchor collection, then the collection.
    anchor_col = _bpy.data.collections.get(GTPT_COLLECTION_NAME)
    if anchor_col is not None:
        # Snapshot the list — we're mutating during iteration.
        for obj in list(anchor_col.objects):
            if obj.type == 'EMPTY':
                _bpy.data.objects.remove(obj, do_unlink=True)
        # Remove the (now-empty) collection itself if it has no children.
        # Stay defensive about leaving user-added stuff alone.
        if not anchor_col.objects and not anchor_col.children:
            _bpy.data.collections.remove(anchor_col)

    # 2. Sweep VC_GTPT__* vertex groups off all meshes.
    from ...SkinModel.skinmodel_gp import GTPT_VG_PREFIX
    for obj in _bpy.data.objects:
        if obj.type != 'MESH' or obj.data is None:
            continue
        # Snapshot names — we're mutating vertex_groups during iteration.
        stale_names = [vg.name for vg in obj.vertex_groups
                       if vg.name.startswith(GTPT_VG_PREFIX)]
        for n in stale_names:
            vg = obj.vertex_groups.get(n)
            if vg is not None:
                obj.vertex_groups.remove(vg)


def run_gtpt_gen(source_path=None):
    """Top-level generator entry point. source_path None falls back to the bundled
    ref; the file-browser workflow always passes an explicit path. Returns True on
    success. Loads the source MCD, extracts its 13 GtPt records, resolves each to a
    user vertex (see _resolve_target_vertex), and creates empty + vertex-group bindings.
    """
    user_root = _get_user_root_collection()
    if user_root is None:
        derror("[GtPt Gen] Could not locate a target collection for "
               "the generated anchors. Select a mesh first.")
        return False

    source_model, source_handle = _load_ref_model(source_path)
    if source_model is None:
        msg_path = source_path if source_path else _ref_mcd_path()
        derror(f"[GtPt Gen] Source baseModel not loadable: {msg_path}")
        return False

    try:
        anchors = _extract_source_anchors(source_model)
    finally:
        _release_ref_model(source_handle)

    if not anchors:
        derror("[GtPt Gen] Source baseModel produced zero resolvable "
               "GtPt records. The MCD may be missing GtPt data or may "
               "not be a baseModel.")
        return False

    # Index the USER's scene meshes by canonical name (which mesh each anchor lands
    # on after merge-fallback rules).
    user_meshes_by_canonical = {}
    for obj in bpy.data.objects:
        if obj.type != 'MESH' or obj.data is None:
            continue
        c = canonical_mesh_name_from_str(obj.data.name)
        if c and c not in user_meshes_by_canonical:
            user_meshes_by_canonical[c] = obj
    user_canonical_names = set(user_meshes_by_canonical.keys())

    def _resolve_target_group(ref_group_name):
        """Map source group name to the user's actual scene mesh.
        Same logic the export resolver uses (GROUP_MERGE_FALLBACKS)."""
        if ref_group_name in user_canonical_names:
            return ref_group_name
        fallback = GROUP_MERGE_FALLBACKS.get(ref_group_name)
        if fallback and fallback in user_canonical_names:
            return fallback
        return ref_group_name  # stamp anyway; resolver will handle later

    def _nearest_unclaimed(mesh_obj, world_pos, claimed_per_mesh):
        """Nearest-vertex on `mesh_obj` to `world_pos`, skipping verts
        already claimed by an earlier anchor on this mesh. Used as the
        fallback when exact-passthrough doesn't apply (custom topology).
        """
        if mesh_obj is None or mesh_obj.type != 'MESH' or world_pos is None:
            return None
        if not mesh_obj.data.vertices:
            return None
        claimed = claimed_per_mesh.setdefault(id(mesh_obj), set())
        inv = mesh_obj.matrix_world.inverted()
        local_target = inv @ Vector(world_pos)
        best = None
        for v in mesh_obj.data.vertices:
            if v.index in claimed:
                continue
            d = v.co - local_target
            sq = d.x*d.x + d.y*d.y + d.z*d.z
            if best is None or sq < best[0]:
                best = (sq, v.index)
        if best is None:
            return _nearest_vertex(mesh_obj, world_pos)
        claimed.add(best[1])
        return best[1]

    def _resolve_target_vertex(anchor, target_group, target_mesh,
                                claimed_per_mesh):
        """Pick the user-side target vertex for an anchor. Returns
        (vertex_index, resolution_path) where resolution_path is one of
        'exact_passthrough', 'exact_merge_offset', 'nearest_fallback'.

        Exact-passthrough policy (the simple case in 26 — characters
        share head topology):
          1. If anchor's source group == user target group AND the user
             mesh has the same vertex count as the source mesh, just
             reuse anchor.source_vertex directly.
          2. If anchor's source group is M_Head_Caruncle but the user
             only has M_Head AND user's M_Head vert count equals
             source M_Head + source caruncle counts (clean Blender Join),
             then user vertex = source_M_Head_count + source caruncle
             vertex index.
          3. Otherwise fall back to nearest-unclaimed-vertex on the
             user's mesh from the anchor's world position.

        Returns (None, 'no_target') if there's no resolvable user mesh
        to target.
        """
        if target_mesh is None:
            return None, 'no_target'

        user_vert_count = len(target_mesh.data.vertices)
        src_group       = anchor['group_name']
        src_vertex      = anchor['source_vertex']
        src_grp_count   = anchor['source_group_vert_count']
        src_head_count  = anchor['source_head_vert_count']

        # Case 1: same group, same vert count → direct passthrough.
        if src_group == target_group and user_vert_count == src_grp_count:
            # Claim the vertex so a fallback later in the loop doesn't
            # collide on it (mostly defensive; fallback shouldn't run
            # when passthrough succeeded).
            claimed_per_mesh.setdefault(id(target_mesh), set()).add(src_vertex)
            return src_vertex, 'exact_passthrough'

        # Case 2: caruncle-merge offset. Source caruncle vert N → user
        # M_Head vert (head_count + N). Only safe when user's M_Head
        # vert count exactly matches the merge sum.
        if (src_group == 'M_Head_Caruncle' and target_group == 'M_Head'
            and src_head_count > 0
            and user_vert_count == src_head_count + src_grp_count):
            mapped_vertex = src_head_count + src_vertex
            claimed_per_mesh.setdefault(id(target_mesh), set()).add(mapped_vertex)
            return mapped_vertex, 'exact_merge_offset'

        # Case 3: fallback. Source meshes load with identity transform, so
        # source_local IS the source world position; project onto the user mesh by
        # applying its transform, then nearest-vertex.
        world_pos = target_mesh.matrix_world @ Vector(anchor['source_local'])
        v_idx = _nearest_unclaimed(target_mesh, world_pos, claimed_per_mesh)
        if v_idx is None:
            return None, 'no_target'
        return v_idx, 'nearest_fallback'

    # Wipe before regenerate. Modder accepts rebuild-from-scratch UX.
    _wipe_existing_anchors(user_root)
    anchor_col = _get_or_create_collection(GTPT_COLLECTION_NAME, user_root)

    claimed_verts_per_mesh = {}
    created = 0
    by_path = {'exact_passthrough': 0, 'exact_merge_offset': 0,
                'nearest_fallback': 0, 'no_target': 0}

    for a in anchors:
        empty_name = f"gtpt_{a['slot']:03d}_{a['name']}"
        target_group = _resolve_target_group(a['group_name'])
        target_mesh = user_meshes_by_canonical.get(target_group)

        target_vertex, path = _resolve_target_vertex(
            a, target_group, target_mesh, claimed_verts_per_mesh)
        by_path[path] = by_path.get(path, 0) + 1

        # Compute the actual placement world position. For target_mesh
        # cases (any of the three resolution paths that found one), use
        # the resolved vertex's world position. For no-target, use the
        # source local coord verbatim — empty floats in space but its
        # custom-prop record still represents intent.
        if target_mesh is not None and target_vertex is not None:
            place_pos = target_mesh.matrix_world @ \
                         target_mesh.data.vertices[target_vertex].co
        else:
            place_pos = Vector(a['source_local'])

        empty = _create_anchor_empty(empty_name, place_pos, anchor_col)

        # Vertex group binding for durable anchoring (survives mesh
        # edits via the resolver's vertex-group lookup).
        if target_mesh is not None and target_vertex is not None:
            vg_name = gtpt_vertex_group_name(a['slot'], a['name'])
            _attach_vertex_group(target_mesh, vg_name, target_vertex)

        # Custom-prop schema (resolver reads these):
        empty['gtpt_name']            = a['name']
        empty['gtpt_group']           = target_group
        empty['gtpt_slot']            = a['slot']
        empty['gtpt_source_vertex']   = int(target_vertex if target_vertex is not None else -1)
        empty['gtpt_source_position'] = [float(place_pos.x),
                                         float(place_pos.y),
                                         float(place_pos.z)]
        created += 1

    # The picked source MCD is an anchor-position donor for THIS step only — never
    # stamped as vcmodel_source_path (that would mislead the export about CTG/HST/
    # material origins). Export commits the GtPt block via interface_save's post-save
    # inject from the resolver records on these anchors, no donor lookup needed.

    dwarn(f"[GtPt Gen] Generated {created} anchor(s) "
          f"({by_path['exact_passthrough']} exact, "
          f"{by_path['exact_merge_offset']} merge-offset, "
          f"{by_path['nearest_fallback']} nearest-fallback, "
          f"{by_path['no_target']} no-target).")
    return True


def _count_hand_tuned_anchors():
    """Count anchor empties whose current world position differs from
    `gtpt_source_position` by more than the resolver's drag threshold.

    Mirrors the resolver's drag detection (gtpt_resolver.py DRAG_EPSILON_SQ
    at line 324, value 0.05*0.05). Used by the generator's overwrite
    confirmation so re-clicking Generate doesn't silently wipe anchors
    the modder spent time positioning by hand.

    Returns 0 if the anchor collection doesn't exist (first-time run) so
    the confirm dialog is skipped in the common case.
    """
    DRAG_EPSILON_SQ = 0.05 * 0.05
    anchor_col = bpy.data.collections.get(GTPT_COLLECTION_NAME)
    if anchor_col is None:
        return 0
    count = 0
    for obj in anchor_col.objects:
        if obj.type != 'EMPTY':
            continue
        src_pos_raw = obj.get('gtpt_source_position')
        if src_pos_raw is None:
            continue
        try:
            current = obj.matrix_world.translation
            dx = float(current.x) - float(src_pos_raw[0])
            dy = float(current.y) - float(src_pos_raw[1])
            dz = float(current.z) - float(src_pos_raw[2])
            if dx*dx + dy*dy + dz*dz > DRAG_EPSILON_SQ:
                count += 1
        except (TypeError, ValueError, IndexError, AttributeError):
            continue
    return count


class VCAutoGenCharGtPts(bpy.types.Operator):
    """File-browser-driven GtPt generator (see module docstring for the workflow).
    Confirms before wiping hand-tuned anchors; prefills the browser with the last
    source (per-scene Scene.<LAST_SOURCE_PATH_PROP>); fresh rebuild every click.
    """
    bl_idname = "object.generate_vc_char_gtpts"
    bl_label = "Generate Character GtPts"
    bl_description = ("Pick a vanilla baseModel.mcd and the addon will "
                      "transfer its 13 GtPt anchor records onto the "
                      "current scene's matching meshes. Anchors land on "
                      "exact source vertices when topology matches "
                      "(passthrough / merge-offset for caruncle), with "
                      "nearest-vertex fallback for customized geometry. "
                      "Re-clicking REPLACES existing generated anchors.")
    bl_options = {'REGISTER', 'UNDO'}

    # ImportHelper-style file picker. Defining `filepath` directly on
    # the operator makes Blender pop up its native file browser when
    # invoke is called without prior args.
    filepath: bpy.props.StringProperty(
        name="Source baseModel",
        description="Path to a vanilla baseModel.mcd file to extract "
                    "GtPt records from. Usually the character's source "
                    "MCD that you ripped from.",
        subtype='FILE_PATH',
    )
    filter_glob: bpy.props.StringProperty(
        default="*.mcd",
        options={'HIDDEN'},
    )
    # SKIP_SAVE so the flag never persists across operator invocations
    # — each click starts fresh and re-runs the confirm check. HIDDEN
    # keeps it out of the F6 redo panel.
    confirmed: bpy.props.BoolProperty(
        default=False,
        options={'HIDDEN', 'SKIP_SAVE'},
    )
    # Hand-tuned anchor count snapshot for the confirm dialog's draw
    # method. A bpy property (not a plain attr) so it survives Blender's
    # operator-state shuffling between invoke and draw calls.
    tuned_count: bpy.props.IntProperty(
        default=0,
        options={'HIDDEN', 'SKIP_SAVE'},
    )

    def invoke(self, context, event):
        # Confirm before wiping hand-tuned anchors (dragged off spawn); on OK,
        # execute re-invokes with confirmed=True. Freshly-generated/no anchors skip
        # the dialog. filepath cleared so execute() distinguishes dialog-OK (empty)
        # from file-browser (set).
        if not self.confirmed:
            tuned = _count_hand_tuned_anchors()
            if tuned > 0:
                self.tuned_count = tuned
                self.filepath = ""
                return context.window_manager.invoke_props_dialog(self)

        # Prefill with the last-picked path (stored on Scene so it persists in the .blend).
        if not self.filepath:
            stored = getattr(context.scene, LAST_SOURCE_PATH_PROP, "")
            if stored and os.path.exists(stored):
                self.filepath = stored

        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        # Confirm-dialog draw only (the file browser uses Blender's own UI).
        layout = self.layout
        layout.label(text=f"Overwrite {self.tuned_count} hand-tuned anchor(s)?",
                     icon='ERROR')
        layout.label(text="Generate will wipe all existing GtPt anchors.")

    def execute(self, context):
        # Two paths: file browser (filepath set → run gen), or dialog-OK (filepath
        # empty → re-invoke with confirmed=True to reach the file browser).
        if not self.confirmed and not self.filepath:
            bpy.ops.object.generate_vc_char_gtpts(
                'INVOKE_DEFAULT', confirmed=True)
            return {'FINISHED'}

        if not self.filepath:
            self.report({'ERROR'},
                "No source baseModel selected. Pick a .mcd file in the "
                "browser to use as the GtPt template.")
            return {'CANCELLED'}
        if not os.path.exists(self.filepath):
            self.report({'ERROR'},
                f"Source baseModel not found: {self.filepath}")
            return {'CANCELLED'}
        ok = run_gtpt_gen(source_path=self.filepath)
        if not ok:
            self.report({'ERROR'},
                "Generator failed — see system console for details.")
            return {'CANCELLED'}

        # Persist the successfully-used path so the next invocation
        # opens the file browser at the same folder. Attribute-set
        # (not ID-property set) because we registered this as a
        # bpy.props.StringProperty on bpy.types.Scene in register().
        try:
            setattr(context.scene, LAST_SOURCE_PATH_PROP, self.filepath)
        except Exception:
            pass

        self.report({'INFO'},
            f"GtPt anchors generated from {os.path.basename(self.filepath)}")
        return {'FINISHED'}


def register_vc_gtpt_generator():
    bpy.utils.register_class(VCAutoGenCharGtPts)
    # Scene-level last-picked path. setattr keeps the property registration
    # idempotent across reload/disable-enable cycles in Blender.
    if not hasattr(bpy.types.Scene, LAST_SOURCE_PATH_PROP):
        setattr(bpy.types.Scene, LAST_SOURCE_PATH_PROP, bpy.props.StringProperty(
            name="Last GtPt Source MCD",
            description="Path to the most recently used baseModel.mcd "
                        "for the GtPt anchor generator. Used to prefill "
                        "the file browser next time.",
            default="",
            subtype='FILE_PATH',
        ))


def unregister_vc_gtpt_generator():
    bpy.utils.unregister_class(VCAutoGenCharGtPts)
    if hasattr(bpy.types.Scene, LAST_SOURCE_PATH_PROP):
        try:
            delattr(bpy.types.Scene, LAST_SOURCE_PATH_PROP)
        except Exception:
            pass
