"""
2K26 .jmtl colorMap resolver — Python-side import fallback.

Why: WWE 2K26 ships materials as `<material>.jmtl` (JSFB FlatBuffer) instead of the
legacy binary `.mtls`. Our linked vcmodel DLL has no .jmtl parser — linkMaterialsFile
catches the .mtls failure and returns empty color_map strings, so 2K26 characters
import with correct geometry but untextured materials. This module recovers just the
colorMap reference setup_material needs; it runs only when diffuse_id is empty (the
2K22-2K25 path is untouched) and leaves the rest of the shader graph to MaterialEditor.

Format: .jmtl is a JSFB FlatBuffer. Root vtable slot 1 = u8 shader-type enum
(0x01-0x1D), slot 2 = offset to the per-shader material-data table. colorMap is a u64
FNV-1a hash of the lowercase .tex rel-path under the mod root. Per-shader colorMap@ref
field indices (shader-type enum -> colorMap field index in that shader's table):
    0x12 Eye->0  0x13 Caruncle->0  0x14 Eyelash->0  0x15 Gear/Cloth->9
    0x16 Hair->see below  0x17 Head->1  0x18 SkinFull->0
    0x19 Skin/Body->0  0x1A Teeth->0  0x1B Fur/0x1C HairMesh/0x1D ShellFur->12
    Environment (rare on characters): 0x05 Hologram->9  0x09 TwoLayerBlend->5
    0x0C Lightmapped->9  0x0B HairNpc->15
Hair (0x16) is two-tier: colorMap lives in the variant inner table (NPC field 15);
New/Std compute color procedurally (g_rootColor+g_tipColor) → resolver returns None.

Hash→file: the .jmtl hash is FNV1a_lower(<rel-path>.tex) anchored at the mod root
(dir above the first Characters/Arena/... folder). We walk every .dds under mod root
once (cached per session, only when a .jmtl was found), hash each rel-path, and look
the JMTL hash up.

Error mode: every op is broadly try/except'd to "no resolution" — worst case is
untextured materials (pre-this-module behavior), never a crash or partial state.
"""

import os
import struct


# ─── FNV-1a 64-bit hash (matches MaterialEditor TextureRefService) ──────────

_FNV_OFFSET_BASIS = 0xCBF29CE484222325
_FNV_PRIME        = 0x100000001B3
_U64_MASK         = 0xFFFFFFFFFFFFFFFF


def _fnv1a_64_lower(s: str) -> int:
    """FNV-1a 64-bit hash of `s` after lowercasing.

    Matches MaterialEditor's TextureRefService.ComputeFnv1aLower exactly:
    the engine uses this on the ASCII bytes of the lowercase relative
    path (e.g. "Characters/100_The_Rock_2017/BaseModel/Textures/head_color.tex")
    to produce the u64 stored in the .jmtl colorMap@ref field.
    """
    h = _FNV_OFFSET_BASIS
    for ch in s.lower():
        h ^= ord(ch) & 0xFF
        h = (h * _FNV_PRIME) & _U64_MASK
    return h


# ─── FlatBuffer minimal reader ──────────────────────────────────────────────
#
# JMTL uses standard FlatBuffer 2.0 wire format. We only need the subset
# required to read u8 / u64 / sub-table offsets — no string tables, no
# vectors, no unions.

class _Fb:
    """Cursor-style accessor over a .jmtl byte buffer."""

    __slots__ = ("data", "n")

    def __init__(self, data: bytes):
        self.data = data
        self.n = len(data)

    def u8(self, p: int) -> int:
        return self.data[p]

    def u16(self, p: int) -> int:
        return struct.unpack_from("<H", self.data, p)[0]

    def u32(self, p: int) -> int:
        return struct.unpack_from("<I", self.data, p)[0]

    def i32(self, p: int) -> int:
        return struct.unpack_from("<i", self.data, p)[0]

    def u64(self, p: int) -> int:
        return struct.unpack_from("<Q", self.data, p)[0]

    def follow(self, p: int) -> int:
        """Resolve a relative-offset pointer at p into an absolute table address."""
        return p + self.u32(p)


class _VTable:
    """Parsed FlatBuffer vtable — slot offsets relative to the table position."""

    __slots__ = ("vt_size", "tbl_size", "offsets")

    def __init__(self, vt_size: int, tbl_size: int, offsets):
        self.vt_size = vt_size
        self.tbl_size = tbl_size
        self.offsets = offsets

    def has(self, field: int) -> bool:
        # FlatBuffer convention: offset == 0 means "field absent, use default."
        return 0 <= field < len(self.offsets) and self.offsets[field] != 0

    def off(self, field: int) -> int:
        return self.offsets[field]


def _read_vtable(fb: _Fb, table_pos: int):
    """Parse the vtable that owns the FlatBuffer table at `table_pos`.

    Returns None if the vtable header looks invalid (defensive — JMTL files
    have been seen with truncated tails on partial extracts, and we don't
    want a single bad file to crash the whole import).
    """
    try:
        if table_pos < 0 or table_pos + 4 > fb.n:
            return None
        soff = fb.i32(table_pos)
        vp = table_pos - soff
        if vp < 0 or vp + 4 > fb.n:
            return None
        vt_size = fb.u16(vp)
        tbl_size = fb.u16(vp + 2)
        # Sanity bounds — same magnitudes MaterialEditor's TryVT uses.
        if vt_size < 4 or vt_size > 500 or tbl_size > 500:
            return None
        n_offsets = (vt_size - 4) // 2
        if vp + 4 + n_offsets * 2 > fb.n:
            return None
        offsets = struct.unpack_from(f"<{n_offsets}H", fb.data, vp + 4)
        return _VTable(vt_size, tbl_size, offsets)
    except Exception:
        return None


def _read_u64_field(fb: _Fb, table_pos: int, vt: _VTable, field: int):
    """Read a u64 at `field` of a JMTL material table, or None if absent / sentinel.

    JMTL uses 0xFFFFFFFFFFFFFFFF as the "null hash" marker (same as
    MaterialEditor's NULL_TEXTURE_HASH). We treat 0 the same — the engine
    treats both as "no texture bound."
    """
    if not vt.has(field):
        return None
    a = table_pos + vt.off(field)
    if a + 8 > fb.n:
        return None
    val = fb.u64(a)
    if val == 0 or val == _U64_MASK:
        return None
    return val


# ─── Per-shader colorMap field index map ────────────────────────────────────

# Field index of the primary colorMap@ref u64 inside each shader's material
# data table (see the per-shader field map in the module docstring).
#
# Shaders not in this map are either (a) parameter-only with no colorMap at
# all (Glass refraction params, Water surface tints, etc.) or (b) compound
# shaders where the visible color comes from a procedural path rather than
# a single bound texture (Hair_New / Hair_Std). Returning None for those
# is the correct behavior — the user's MaterialEditor handles the full
# shader graph; we're just doing the obvious texture-import case.

_PRIMARY_COLOR_FIELD = {
    0x01: 4,    # yPBR
    0x02: 4,    # yIllumination
    0x03: 6,    # yGlass
    0x06: 3,    # speedTree
    0x07: 5,    # Water
    # Environment / prop shaders we plausibly hit on character imports
    0x05: 9,    # Hologram_MultiScroll  - color2Map@ref
    0x09: 5,    # TwoLayer_Blend        - colorMap1@ref
    0x0B: 15,   # Hair_NPC              - colorMap@ref (in inner table)
    0x0C: 9,    # Lightmapped           - colorMap@ref (after lightmap+sampIllum)

    # Character shaders — primary path for 99% of WWE 2K26 character mods
    0x12: 0,    # Eye
    0x13: 0,    # Caruncle (eye_caruncle)
    0x14: 0,    # Eyelash
    0x15: 9,    # Gear/Cloth
    0x17: 1,    # Head (field 0 is detailzoneMap; colorMap is at 1)
    0x18: 0,    # SkinFull (head-like with eyeShadow params)
    0x19: 0,    # Skin/Body
    0x1A: 0,    # Teeth/Mouthbag
    0x1B: 12,   # ShellFur
    0x1C: 12,   # HairMesh (yCh_hairMesh)
    0x1D: 12,   # ShellFur variant
}

# 0x16 (Hair) is a two-tier shader — outer table at vtable slot 1 holds
# shader variant info; the colorMap (when present) lives in an inner
# sub-table reached via slot 1 of the outer table. Only the NPC variant
# (hairType == 3, inner ReadHairNpcInner handler) actually has a texture
# colorMap at inner field 15. New/Std variants compute color procedurally
# from g_rootColor + g_tipColor. We handle this with a small specialized
# code path inside extract_color_hash rather than overloading the table.

_HAIR_SHADER_TYPE = 0x16
_HAIR_INNER_NPC_COLORMAP_FIELD = 15
_HAIR_INNER_NPC_NORMALMAP_FIELD = 14


# ─── Per-shader normalMap field index map ───────────────────────────────────
# Field index of the primary normalMap (nrMap@ref) u64 per shader's material-data
# table (from jmtl_reader.cpp). Some shaders have no normal map (Eyelash, Hair) →
# None. Kept separate from _PRIMARY_COLOR_FIELD so the shipped diffuse path can't regress.

_PRIMARY_NORMAL_FIELD = {
    # Character shaders (the only ones the metadata stamp realistically
    # cares about for round-trip — environment shaders are not typical on
    # character imports and aren't materially round-tripped by the writer).
    0x12: 3,    # yCh_eye             nrMap at vtable index 3
    0x13: 1,    # yCh_head Caruncle   nrMap at index 1
    # 0x14 yCh_eye Eyelash — no normal map.
    0x15: 12,   # yCh_gear            nrMap at index 12 (presence guarded)
    # 0x16 yCh_hair — complex, skipped per spec.
    0x17: 5,    # yCh_head            nrMap at index 5
    0x18: 5,    # yCh_head SkinFull   nrMap at index 5
    0x19: 1,    # yCh_skin            nrMap at index 1
    0x1A: 1,    # yCh_Teeth           nrMap at index 1

    # Environment fallback — yPBR uses nrMap at field 1. Included so a stray
    # yPBR-tagged JMTL in the basemodel stamps cleanly.
    0x01: 5,    # yPBR                g_nrmMap
    0x02: 6,    # yIllumination       g_nrmMap
    0x03: 7,    # yGlass              g_nrmMap
    0x06: 4,    # speedTree           nrMap
    0x07: 12,   # Water               normalMap
    0x1B: 11,   # Fur                 nrMap
    0x1C: 11,   # HairMesh            g_nrmMap
    0x1D: 11,   # ShellFur            nrMap
}


# ─── Shader byte → (shader name, type name) lookup ──────────────────────────
# Like material_inference.SLOT_FAMILY_TABLE but keyed on the shader byte. Gives
# extract_full_material_metadata a self-describing "vc_2k26_template" (e.g.
# "yCh_skin::Normal"). Also covers a few environment shaders absent from SLOT_FAMILY_TABLE.

_SHADER_BYTE_TO_NAMES = {
    0x01: ("yPBR",        "t_BRDF"),
    0x02: ("yIllumination", "t_Illumination"),
    0x03: ("yGlass",      "t_Translucency"),
    0x06: ("speedTree",   "Default"),
    0x07: ("Water",       "t_Water"),
    0x05: ("yHologram",   "MultiScroll"),
    0x09: ("yTwoLayer",   "Blend"),
    0x0B: ("yHair",       "Npc"),
    0x0C: ("yLightmapped", "Normal"),

    0x12: ("yCh_eye",     "Normal"),
    0x13: ("yCh_head",    "Caruncle"),
    0x14: ("yCh_eyeOv",   "Eyelash"),
    0x15: ("yCh_gear",    "Normal"),
    0x16: ("yCh_hair",    "NewHair_ColorChanging"),
    0x17: ("yCh_head",    "Normal"),
    0x18: ("yCh_head",    "SkinFull"),
    0x19: ("yCh_skin",    "Normal"),
    0x1A: ("yCh_Teeth",   "Normal"),
    0x1B: ("yCh_fur",     "Default"),
    0x1C: ("yCh_hairMesh", "Default"),
    0x1D: ("yCh_shellFur", "Default"),
}


def extract_color_hash(jmtl_data: bytes):
    """Parse a .jmtl and return its primary colorMap u64, or None when: not a valid
    JMTL ('Mate' tag), no single bindable colorMap (Hair New/Std, parameter-only),
    the slot is the null marker (0 or 0xFFFFFFFFFFFFFFFF), or any structural read
    fails. None is normal (~10% of materials) — caller must not treat it as an error.
    """
    try:
        # JMTL identifier check: bytes 4..7 spell 'Mate' (the start of the
        # FlatBuffer's root identifier). MaterialEditor uses the same test.
        if len(jmtl_data) < 8:
            return None
        if (jmtl_data[4], jmtl_data[5], jmtl_data[6], jmtl_data[7]) != (
                ord('M'), ord('a'), ord('t'), ord('e')):
            return None

        fb = _Fb(jmtl_data)
        root_pos = fb.i32(0)
        rv = _read_vtable(fb, root_pos)
        if rv is None:
            return None

        # Root vtable layout (verified hex dumps): slot 1 = u8 shader type,
        # slot 2 = offset to material-data table.
        shader_type = fb.u8(root_pos + rv.off(1)) if rv.has(1) else 0
        if not rv.has(2):
            return None

        mat_pos = fb.follow(root_pos + rv.off(2))
        mv = _read_vtable(fb, mat_pos)
        if mv is None:
            return None

        # Hair (0x16) — descend into the variant-specific inner table.
        if shader_type == _HAIR_SHADER_TYPE:
            # hairType lives at outer field 0 (u16). Only NPC (3) has a
            # bindable colorMap; the other variants compute color
            # procedurally and return None correctly.
            hair_type = fb.u16(mat_pos + mv.off(0)) if mv.has(0) else 0
            if hair_type != 3 or not mv.has(1):
                return None
            inner_pos = fb.follow(mat_pos + mv.off(1))
            iv = _read_vtable(fb, inner_pos)
            if iv is None:
                return None
            return _read_u64_field(fb, inner_pos, iv, _HAIR_INNER_NPC_COLORMAP_FIELD)

        # All other supported shaders — direct field lookup.
        field = _PRIMARY_COLOR_FIELD.get(shader_type)
        if field is None:
            return None
        return _read_u64_field(fb, mat_pos, mv, field)

    except Exception:
        # Catch-all — any structural bug or unexpected file shape falls
        # through to "couldn't resolve." Better than crashing import.
        return None


def extract_full_material_metadata(jmtl_data: bytes):
    """Parse a .jmtl and extract metadata. Returns None if not a recognizable JMTL,
    else::
        {"shader_byte": int, "shader_name": str, "type_name": str,
         "color_map_hash": int|None, "normal_map_hash": int|None,
         "hair_type": int|None, "hair_length": int|None}  # u64 FNV1a maps
    shader_byte set with both maps None is normal (parameter-only/procedural shaders;
    export falls back to template defaults).

    Reuses extract_color_hash's reader (the proven diffuse path) so a metadata bug
    can't shadow it; the normal-map read is additive (failure only zeroes that field).
    Hair (0x16) also preserves the outer variant discriminator and the optional
    type-1/type-2 length discriminator. Type 3 has real texture refs in its inner
    table, so those are recovered as well. Without these fields an imported NPC,
    Afro, or Short hair material silently exported again as type-1 default hair.
    """
    try:
        if len(jmtl_data) < 8:
            return None
        if (jmtl_data[4], jmtl_data[5], jmtl_data[6], jmtl_data[7]) != (
                ord('M'), ord('a'), ord('t'), ord('e')):
            return None

        fb = _Fb(jmtl_data)
        root_pos = fb.i32(0)
        rv = _read_vtable(fb, root_pos)
        if rv is None:
            return None

        shader_byte = fb.u8(root_pos + rv.off(1)) if rv.has(1) else 0

        # color_map_hash: reuse the verified extractor. It handles Hair's
        # variant-specific descent internally and returns None for any
        # shader without a single bindable color texture.
        color_map_hash = extract_color_hash(jmtl_data)

        # normal_map_hash: direct vtable read on the material-data table.
        # Hair additionally carries two discriminators that must survive an
        # import/export round-trip. Keep None for non-hair so callers can use
        # one metadata shape without special-casing missing keys.
        normal_map_hash = None
        hair_type = None
        hair_length = None
        if rv.has(2):
            mat_pos = fb.follow(root_pos + rv.off(2))
            mv = _read_vtable(fb, mat_pos)
            if mv is not None:
                if shader_byte == _HAIR_SHADER_TYPE:
                    # The outer discriminator is u16. Field 1 points at one
                    # of three different table layouts; only type 1/2 put the
                    # optional u8 hairLength at inner field 0. Type 3 uses
                    # that same byte range for an f32, so never read length
                    # unless the discriminator says it is safe.
                    hair_type = (
                        fb.u16(mat_pos + mv.off(0)) if mv.has(0) else 1
                    )
                    if mv.has(1):
                        inner_pos = fb.follow(mat_pos + mv.off(1))
                        iv = _read_vtable(fb, inner_pos)
                        if iv is not None:
                            if hair_type in (1, 2) and iv.has(0):
                                a = inner_pos + iv.off(0)
                                if a < fb.n:
                                    hair_length = fb.u8(a)
                            elif hair_type == 3:
                                normal_map_hash = _read_u64_field(
                                    fb, inner_pos, iv,
                                    _HAIR_INNER_NPC_NORMALMAP_FIELD,
                                )
                else:
                    nfield = _PRIMARY_NORMAL_FIELD.get(shader_byte)
                    if nfield is not None:
                        normal_map_hash = _read_u64_field(
                            fb, mat_pos, mv, nfield
                        )

        shader_name, type_name = _SHADER_BYTE_TO_NAMES.get(
            shader_byte, ("unknown", "Unknown")
        )

        return {
            "shader_byte":     shader_byte,
            "shader_name":     shader_name,
            "type_name":       type_name,
            "color_map_hash":  color_map_hash,
            "normal_map_hash": normal_map_hash,
            "hair_type":       hair_type,
            "hair_length":     hair_length,
        }

    except Exception:
        return None


# ─── Mod-root detection + texture index ─────────────────────────────────────

# Top-level game folders that mark the boundary of a mod root, in priority
# order. The first one found in the model path determines the rel-path
# anchor for hashing. Mirrors MaterialEditor TextureRefService.KnownGameFolders.
_GAME_FOLDERS = (
    "Characters", "Arena", "Props", "Weapons", "UI", "Audio",
    "Belts", "Crowds", "Effects", "Lighting", "Movies", "Rings",
    "Textures", "Shaders", "Models", "MaterialLibrary",
)


def _detect_mod_root(model_path: str):
    """Walk up from the model file to the first known game-folder boundary. Returns
    the path ENDING just before that folder (so rel-paths "Characters/...", "Arena/..."
    hash correctly), or None if no boundary is found (callers fall back to local-folder
    scanning).
    """
    try:
        normalized = os.path.normpath(model_path).replace("\\", "/")
        # Start from the model's directory, not the file itself.
        folder = os.path.dirname(normalized)
        parts = folder.split("/")
        # Walk left-to-right; first match wins. Case-insensitive.
        for i, part in enumerate(parts):
            for known in _GAME_FOLDERS:
                if part.lower() == known.lower():
                    # Mod root is everything strictly before this index.
                    if i == 0:
                        return None
                    return "/".join(parts[:i])
        return None
    except Exception:
        return None


# (mod_root → {hash: full_dds_path}) so successive materials don't re-walk the FS.
# Cleared only via clear_cache(); files don't change mid-session.
_HASH_INDEX_CACHE = {}

# Per-(model_path, material_name) resolved diffuse-path cache. setup_material calls
# resolve_diffuse_path once per material GROUP, and characters reuse slot names across
# many face groups + head/body meshes; each uncached call re-runs _find_jmtl_file
# (listdir + isfile/isdir fan, ~3 ms warm, worse under AV scanning) + a .jmtl read.
# Result is deterministic/file-stable → memoize to one lookup per (model, slot).
# _CACHE_MISS sentinel: None is a VALID result ("no bindable texture") and the most
# expensive to recompute (exhausts the full search), so it must be cached too.
_CACHE_MISS = object()
_DIFFUSE_PATH_CACHE = {}


def clear_cache():
    """Drop all cached hash indices and resolved diffuse paths.

    Call between unrelated import sessions if the user has been editing
    files on disk and wants the next import to re-scan. Not currently
    wired anywhere — exposed for diagnostics / future hooks.
    """
    _HASH_INDEX_CACHE.clear()
    _DIFFUSE_PATH_CACHE.clear()


def _build_indexes(mod_root: str, model_dir: str):
    """Walk mod_root for .dds files; return (hash_index, stem_index) in one walk.

      1. hash_index: {fnv1a_64(rel_path.tex): full_dds_path} — hits when the model
         path keeps the engine-expected ancestor (Characters/<id>/...), so the
         rel-path hashes to the game-pack-time value.
      2. stem_index: {lowercase_stem: full_dds_path} — works regardless of layout via
         the engine's <slot>_color.dds convention (MaterialEditor's "slot+suffix
         heuristic"); resolves by name when the hash misses.

    Also walks model_dir if it's outside mod_root. Non-relativizable files are
    skipped in hash_index but kept in stem_index. Cached per (mod_root, model_dir).
    """
    cache_key = (mod_root, model_dir)
    if cache_key in _HASH_INDEX_CACHE:
        return _HASH_INDEX_CACHE[cache_key]

    hash_index = {}
    stem_index = {}

    # Walk mod_root for the hash index (full-rel-path hashing). We walk
    # model_dir below as well so the stem index always covers the local
    # textures even if mod_root excludes them.
    walk_roots = []
    if mod_root and os.path.isdir(mod_root):
        walk_roots.append(mod_root)
    if model_dir and os.path.isdir(model_dir) and model_dir not in walk_roots:
        # Only add as a separate walk root if model_dir is OUTSIDE mod_root.
        # If it's inside, the mod_root walk already covers it.
        try:
            common = os.path.commonpath([mod_root or "", model_dir])
            if common != (mod_root or ""):
                walk_roots.append(model_dir)
        except ValueError:
            walk_roots.append(model_dir)

    seen_paths = set()
    for walk_root in walk_roots:
        try:
            for root, _dirs, files in os.walk(walk_root):
                for name in files:
                    if not name.lower().endswith(".dds"):
                        continue
                    full = os.path.join(root, name)
                    if full in seen_paths:
                        continue
                    seen_paths.add(full)

                    # Hash index — only meaningful when mod_root is the
                    # real engine-expected root.
                    if mod_root:
                        try:
                            rel = os.path.relpath(full, mod_root).replace("\\", "/")
                            tex_rel = rel[:-4] + ".tex"
                            h = _fnv1a_64_lower(tex_rel)
                            if h not in hash_index:
                                hash_index[h] = full
                        except ValueError:
                            pass  # different drive on Windows etc.

                    # Stem index — strip extension, lowercase. Always
                    # populated regardless of mod-root resolution.
                    stem = os.path.splitext(name)[0].lower()
                    if stem not in stem_index:
                        stem_index[stem] = full
        except Exception:
            # Permission or transient IO — fall through with whatever
            # we collected. Never raise out of the scan.
            pass

    indexes = (hash_index, stem_index)
    _HASH_INDEX_CACHE[cache_key] = indexes
    return indexes


# Keep the old _build_hash_index name available for any external caller
# (none in tree) — delegate to the new builder and return only the hash
# index for backward compatibility.
def _build_hash_index(mod_root: str):
    h, _ = _build_indexes(mod_root, mod_root)
    return h


# Common stem suffixes the engine uses for the primary diffuse map.
# Order matters — first match wins. "_color" is overwhelmingly the
# convention; the others cover the few outlier slots seen in practice
# (eyelash uses "_color" but some attire pieces use "_diff").
_DIFFUSE_STEM_SUFFIXES = ("_color", "_diff", "_diffuse", "_d", "")


def _stem_lookup(stem_index: dict, slot_name: str):
    """Find a diffuse texture for `slot_name` in the stem index via the engine's
    suffix conventions. Returns the .dds path or None.

    Tries two slot-name variants × the priority suffix list:
      1. The name as given (body→body_color, l_elbowpad→l_elbowpad_color). FIRST so
         per-side attire textures (l_elbowpad_color.dds / r_elbowpad_color.dds are
         distinct files) bind to their own slot.
      2. Trailing L/R stripped — the engine ships ONE shared eye_color.dds for both
         eye_l.jmtl and eye_r.jmtl; stripping _l/_r recovers the bare stem.
    First match wins; _color dominates, "" handles suffix-less prop/arena slots.

    Deliberately NOT done: strip leading l_/r_ prefixes (verified: per-side attire
    files are distinct — stripping collapses them) or _ALPHA/_LOD* tags (unverified;
    binding the wrong file is worse than no texture). The exact hash lookup runs
    BEFORE this fallback in resolve_diffuse_path.
    """
    if not slot_name:
        return None

    base = slot_name.lower()
    candidates = [base]

    # Trailing L/R designator: ``eye_l`` → ``eye``.
    no_trail = base
    for suffix in ("_l", "_r", "_left", "_right"):
        if no_trail.endswith(suffix) and len(no_trail) > len(suffix):
            no_trail = no_trail[:-len(suffix)]
            break
    if no_trail != base:
        candidates.append(no_trail)

    for candidate_base in candidates:
        for suffix in _DIFFUSE_STEM_SUFFIXES:
            candidate = candidate_base + suffix
            if candidate in stem_index:
                return stem_index[candidate]
    return None


def _find_jmtl_file(model_dir: str, lookup_names):
    """Locate <name>.jmtl for any of lookup_names in or near model_dir. Returns the
    first match, or None.

    Search order (first hit wins):
      1. <model_dir>/<name>.jmtl
      2. <model_dir>/Materials/<name>.jmtl
      3. <sibling>/Materials/<name>.jmtl for each sibling under the character root.
         Attire imports expose base-model slots (head/body) whose .jmtl sits in a
         SIBLING BaseModel/Materials/ — without this scan they'd import untextured.

    Sibling scan is one level only (flat character-root layout), ~5 folders ×
    isfile per name — negligible. Tries every lookup_name at every location
    (preserves the colon→bare-prefix fallback from resolve_diffuse_path).
    """
    # 1 + 2: own folder and own Materials/ subdir.
    for name in lookup_names:
        for candidate in (
            os.path.join(model_dir, name + ".jmtl"),
            os.path.join(model_dir, "Materials", name + ".jmtl"),
        ):
            if os.path.isfile(candidate):
                return candidate

    # 3: sibling folders' Materials/ subdirs.
    parent_dir = os.path.dirname(model_dir)
    if not parent_dir or parent_dir == model_dir:
        # No parent (we're at filesystem root) — nothing to scan.
        return None
    try:
        siblings = os.listdir(parent_dir)
    except OSError:
        return None
    for sibling in siblings:
        sibling_path = os.path.join(parent_dir, sibling)
        if sibling_path == model_dir or not os.path.isdir(sibling_path):
            continue
        sibling_materials = os.path.join(sibling_path, "Materials")
        if not os.path.isdir(sibling_materials):
            continue
        for name in lookup_names:
            candidate = os.path.join(sibling_materials, name + ".jmtl")
            if os.path.isfile(candidate):
                return candidate
    return None


# ─── Public entrypoint ──────────────────────────────────────────────────────

def resolve_diffuse_path(model_path: str, material_name: str):
    """Memoizing front for the diffuse-path resolver, keyed (model_path,
    material_name). Resolution is deterministic per on-disk layout, so caching is
    session-safe (call clear_cache() if files change mid-session). See
    _resolve_diffuse_path_uncached for the flow.
    """
    key = (model_path, material_name)
    cached = _DIFFUSE_PATH_CACHE.get(key, _CACHE_MISS)
    if cached is not _CACHE_MISS:
        return cached
    result = _resolve_diffuse_path_uncached(model_path, material_name)
    _DIFFUSE_PATH_CACHE[key] = result
    return result


def _resolve_diffuse_path_uncached(model_path: str, material_name: str):
    """For a 2K26 model + material slot name, return the local .dds path of the
    primary colorMap, or None. Never raises.

    model_path anchors both the companion .jmtl lookup and the mod-root walk.
    material_name is the raw getAllFaceGroups slot (same name the .jmtl uses).

    Flow: (1) find the .jmtl beside the model or a sibling Materials/. (2) parse it,
    extract the colorMap@ref u64. (3) detect mod root (walk up to Characters/Arena/
    ...). (4) build cached hash + stem indexes. (5) try the exact hash first (hits
    when the engine ancestry is preserved). (6) else fall back to the stem index via
    slot+suffix (body→body_color). None silently → caller leaves it untextured.
    """
    try:
        if not material_name:
            return None

        # Strip the variant suffix (colon onward): names are "body:skinned" etc.,
        # the prefix is the slot key, and .jmtl/textures use the bare slot. Mirrors
        # the DLL's linkMaterialsFile fallback:
        #     index = library->indexOf(group_id);
        #     if (index == -1) index = library->indexOf(split(group_id, ":").front());
        # Try the full name first (a colon-named .jmtl is technically allowed), then
        # the stripped form.
        lookup_names = [material_name]
        if ":" in material_name:
            lookup_names.append(material_name.split(":", 1)[0])

        # Step 1: find the .jmtl on disk (own folder + Materials/, then sibling
        # Materials/). The sibling scan matters because attire imports reference
        # base-model slots (head/body) whose .jmtl lives in a sibling BaseModel/.
        model_dir = os.path.dirname(model_path)
        jmtl_path = _find_jmtl_file(model_dir, lookup_names)
        if jmtl_path is None:
            return None

        # Step 2: extract colorMap hash from JMTL.
        try:
            with open(jmtl_path, "rb") as f:
                jmtl_data = f.read()
        except OSError:
            return None
        color_hash = extract_color_hash(jmtl_data)

        # Step 3 + 4: detect mod root, build dual index.
        mod_root = _detect_mod_root(model_path)
        hash_index, stem_index = _build_indexes(mod_root, model_dir)

        # Step 5: try the exact hash first. Only meaningful if we have
        # both a non-None hash from the JMTL and a populated hash_index
        # (which requires mod_root to have resolved).
        if color_hash is not None and color_hash in hash_index:
            return hash_index[color_hash]

        # Step 6: stem-name fallback. Try each candidate name (full and
        # colon-stripped) so a slot like ``body:skinned`` correctly
        # falls through to ``body_color.dds`` via the stripped key.
        for name in lookup_names:
            result = _stem_lookup(stem_index, name)
            if result is not None:
                return result
        return None

    except Exception:
        return None


def find_jmtl_for_material(model_path: str, material_name: str):
    """Public locator: full path to the .jmtl for material_name near model_path, or
    None. Used by the metadata stamper (reads raw .jmtl bytes). Mirrors
    resolve_diffuse_path's :variant-strip then delegates to _find_jmtl_file. Never raises.
    """
    try:
        if not material_name or not model_path:
            return None
        lookup_names = [material_name]
        if ":" in material_name:
            lookup_names.append(material_name.split(":", 1)[0])
        model_dir = os.path.dirname(model_path)
        return _find_jmtl_file(model_dir, lookup_names)
    except Exception:
        return None
