import bpy
from .mesh_data_transfer import MeshDataTransfer, TopologyData, DeformationTransfer


# ─────────────────────────────────────────────────────────────────────────────
# Store Shape Key Base Reference
# ─────────────────────────────────────────────────────────────────────────────

class StoreShapeKeyReference(bpy.types.Operator):
    bl_idname = "object.mdt_store_sk_reference"
    bl_label  = "Store Base Reference"
    bl_description = ("Save the current Basis shape key as a hidden reference. "
                      "Do this BEFORE editing the base mesh. "
                      "Used by 'Recalculate to Base' to know what changed.")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return False
        mesh = obj.data
        return bool(mesh.shape_keys and mesh.shape_keys.key_blocks.get("Basis"))

    def execute(self, context):
        obj  = context.active_object
        mesh = obj.data
        keys = mesh.shape_keys.key_blocks

        REF_NAME = '_mdt_basis_ref'

        # Remove existing reference if present
        if REF_NAME in [k.name for k in keys]:
            obj.shape_key_remove(keys[REF_NAME])

        # Duplicate Basis into reference key
        basis = keys["Basis"]
        ref   = obj.shape_key_add(name=REF_NAME, from_mix=False)
        ref.interpolation = 'KEY_LINEAR'
        ref.value         = 0.0
        ref.mute          = True  # hidden from slider UI

        # Copy Basis vertex positions into the reference key
        v_count = len(mesh.vertices)
        import numpy as np
        co = np.zeros(v_count * 3, dtype=np.float32)
        basis.data.foreach_get("co", co)
        ref.data.foreach_set("co", co)
        mesh.update()

        self.report({'INFO'}, f"Base reference stored in '{REF_NAME}'. "
                               "Now edit the Basis mesh, then click 'Recalculate to Base'.")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
# Recalculate Shape Keys to New Base
# ─────────────────────────────────────────────────────────────────────────────

class RecalculateShapeKeys(bpy.types.Operator):
    bl_idname  = "object.mdt_recalculate_shape_keys"
    bl_label   = "Recalculate to Base"
    bl_description = ("Recalculate all shape keys so they produce the same visual "
                      "deformation relative to the NEW Basis as they did before. "
                      "Requires 'Store Base Reference' to have been clicked first.")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return False
        mesh = obj.data
        if not mesh.shape_keys:
            return False
        key_names = [k.name for k in mesh.shape_keys.key_blocks]
        return '_mdt_basis_ref' in key_names and 'Basis' in key_names

    def execute(self, context):
        obj = context.active_object

        count, err = DeformationTransfer.recalculate_to_new_base(
            obj, ref_key_name='_mdt_basis_ref')

        if err:
            self.report({'ERROR'}, err)
            return {'CANCELLED'}

        self.report({'INFO'}, f"Recalculated {count} shape key(s) to new base.")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _resolve_space(active_prop):
    """
    Return (world_space, uv_space) from the panel properties.
    UV is driven by search_method == 'UVS', not sample_space.
    world_space and uv_space are mutually exclusive.
    """
    uv_space = active_prop.search_method == 'UVS'
    world_space = (not uv_space) and (active_prop.mesh_object_space == 'WORLD')
    return world_space, uv_space


def _build_transfer(context, active_prop, active):
    """Construct a MeshDataTransfer from current panel state."""
    source = active_prop.mesh_source
    world_space, uv_space = _resolve_space(active_prop)
    return MeshDataTransfer(
        target=active,
        source=source,
        world_space=world_space,
        uv_space=uv_space,
        deformed_source=active_prop.transfer_modified_source,
        search_method=active_prop.search_method,
        vertex_group=active_prop.vertex_group_filter or None,
        invert_vertex_group=active_prop.invert_vertex_group_filter,
        restrict_to_selection=active_prop.transfer_edit_selection,
        exclude_muted_shapekeys=active_prop.exclude_muted_shapekeys,
        exclude_locked_groups=active_prop.exclude_locked_groups,
        snap_to_closest=active_prop.snap_to_closest_shape,
        snap_to_closest_shape_key=active_prop.snap_to_closest_shapekey,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Transfer Mesh Data (main operator)
# ─────────────────────────────────────────────────────────────────────────────

class TransferMeshData(bpy.types.Operator):
    bl_idname = "object.transfer_mesh_data"
    bl_label = "Transfer Mesh Data"
    bl_description = "Transfer the selected attribute from source to active mesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return False
        props = obj.mesh_data_transfer_object
        if not props.mesh_source:
            return False
        # UV search + UV transfer is not meaningful
        if props.search_method == 'UVS' and props.attributes_to_transfer == 'UVS':
            return False
        # Topology requires matching vert count
        if props.search_method == 'TOPOLOGY':
            src = props.mesh_source
            if not src or len(src.data.vertices) != len(obj.data.vertices):
                return False
        return context.mode in {'OBJECT', 'EDIT_MESH'}

    def execute(self, context):
        active = context.active_object
        active_prop = active.mesh_data_transfer_object

        # Force object mode for the transfer
        prev_mode = context.mode
        if prev_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        try:
            transfer_data = _build_transfer(context, active_prop, active)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to build transfer: {e}")
            if prev_mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=prev_mode.replace('EDIT_MESH', 'EDIT'))
            return {'CANCELLED'}

        if transfer_data.has_zero_area_faces:
            self.report({'WARNING'},
                        "Zero area faces detected in source mesh — transfer may have artefacts.")

        attribute = active_prop.attributes_to_transfer
        transferred = False

        # ── unified report-emission helper ────────────────────────────────
        def emit_reports(label, reports):
            """Surface a list of report strings via operator.report. Picks
            severity from the message — anything mentioning a coverage miss,
            a confidence fallback, or a low-confidence match becomes WARNING;
            everything else (positive transfer counts, structural-match
            confirmations) is INFO so it doesn't spam red banners.
            """
            for r in reports:
                low = r.lower()
                if any(k in low for k in ('miss', 'fallback', 'low', "don't overlap",
                                          "no structural", "wrong")):
                    sev = 'WARNING'
                else:
                    sev = 'INFO'
                self.report({sev}, f"{label}: {r}")

        def emit_uv_reports_for_passive_method(label):
            """For transfer methods that don't accept report_matches (SHAPE,
            SHAPE_KEYS), pull UV match/coverage info directly off the
            transfer_data instance after the transfer runs. This keeps
            messaging uniform across all attribute types — every UV-space
            transfer surfaces the same "which layer pair we used" and
            "how many verts had no source coverage" info.
            """
            try:
                lines = transfer_data._uv_transfer_report_lines()
            except Exception:
                lines = []
            if lines:
                emit_reports(label, lines)

        try:
            if attribute == 'SHAPE':
                transferred = transfer_data.transfer_vertex_position(
                    as_shape_key=active_prop.transfer_shape_as_key,
                    tangent_space=active_prop.shape_tangent_space)
                emit_uv_reports_for_passive_method("Shape")

            elif attribute == 'UVS':
                result = transfer_data.transfer_uvs(report_matches=True)
                if isinstance(result, tuple):
                    transferred, reports = result
                    emit_reports("UV", reports)
                else:
                    transferred = result

            elif attribute == 'NORMALS':
                result = transfer_data.transfer_normals(report_matches=True)
                if isinstance(result, tuple):
                    transferred, reports = result
                    emit_reports("Normals", reports)
                else:
                    transferred = result

            elif attribute == 'VERTEX_COLORS':
                result = transfer_data.transfer_vertex_colors(report_matches=True)
                if isinstance(result, tuple):
                    transferred, reports = result
                    emit_reports("Colors", reports)
                else:
                    transferred = result

            elif attribute == 'SHAPE_KEYS':
                prefix = active_prop.sk_prefix_filter.strip() or None
                suffix = active_prop.sk_suffix_filter.strip() or None
                if active_prop.sk_use_deformation_transfer:
                    transferred = transfer_data.transfer_shape_keys_deformation(
                        prefix_filter=prefix,
                        suffix_filter=suffix,
                        create_missing_only=active_prop.sk_create_missing_only,
                        delta_scale=active_prop.sk_delta_scale,
                    )
                else:
                    transferred = transfer_data.transfer_shape_keys(
                        prefix_filter=prefix,
                        suffix_filter=suffix,
                        create_missing_only=active_prop.sk_create_missing_only,
                        delta_scale=active_prop.sk_delta_scale,
                        tangent_space=active_prop.sk_tangent_space,
                    )
                emit_uv_reports_for_passive_method("Shape Keys")

            elif attribute == 'VERTEX_GROUPS':
                result = transfer_data.transfer_vertex_groups(
                    normalize=active_prop.vg_normalize,
                    clamp=True,
                    threshold=active_prop.vg_threshold,
                    report_matches=True,
                )
                if isinstance(result, tuple):
                    transferred, reports = result
                    emit_reports("Vertex Groups", reports)
                else:
                    transferred = result

        except Exception as e:
            self.report({'ERROR'}, f"Transfer failed: {e}")
            transfer_data.free()
            if prev_mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=prev_mode.replace('EDIT_MESH', 'EDIT'))
            return {'CANCELLED'}

        transfer_data.free()

        if prev_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode=prev_mode.replace('EDIT_MESH', 'EDIT'))
        context.view_layer.objects.active = active

        if not transferred:
            self.report({'WARNING'}, "Nothing was transferred.")
            return {'CANCELLED'}

        self.report({'INFO'}, "Transfer complete.")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
# Transfer Shape Key Drivers
# ─────────────────────────────────────────────────────────────────────────────

class TransferShapeKeyDrivers(bpy.types.Operator):
    bl_idname = "object.transfer_shape_key_drivers"
    bl_label = "Transfer Shape Key Drivers"
    bl_description = "Transfer shape key drivers from source to active mesh, remapping armature targets"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return False
        props = obj.mesh_data_transfer_object
        return (props.mesh_source is not None
                and props.arm_source is not None
                and context.mode == 'OBJECT')

    def execute(self, context):
        active = context.active_object
        active_prop = active.mesh_data_transfer_object
        world_space, uv_space = _resolve_space(active_prop)

        try:
            transfer_data = MeshDataTransfer(
                target=active,
                source=active_prop.mesh_source,
                world_space=world_space,
                uv_space=uv_space,
                deformed_source=active_prop.transfer_modified_source,
                search_method=active_prop.search_method,
                vertex_group=active_prop.vertex_group_filter or None,
                invert_vertex_group=active_prop.invert_vertex_group_filter,
                exclude_muted_shapekeys=active_prop.exclude_muted_shapekeys,
                snap_to_closest=active_prop.snap_to_closest_shapekey,
                source_arm=active_prop.arm_source,
                target_arm=active_prop.arm_target,
            )
        except Exception as e:
            self.report({'ERROR'}, f"Failed to build transfer: {e}")
            return {'CANCELLED'}

        if transfer_data.has_zero_area_faces:
            self.report({'WARNING'}, "Zero area faces detected in source mesh.")

        transferred = transfer_data.transfer_shape_keys_drivers()
        transfer_data.free()

        if not transferred:
            self.report({'WARNING'}, "No drivers transferred.")
            return {'CANCELLED'}

        self.report({'INFO'}, "Drivers transferred.")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
# Map Topology (debug / utility)
# ─────────────────────────────────────────────────────────────────────────────

class MapTopology(bpy.types.Operator):
    bl_idname = "object.map_topology"
    bl_label = "Map Topology"
    bl_description = "Debug: print topology mapping to console"
    bl_options = {'REGISTER'}

    def execute(self, context):
        active = context.active_object
        topo = TopologyData(active)
        print("Active edge:", topo.active_edge)
        if topo.selected_face:
            print("Selected face:", topo.selected_face[0])
        topo.free()
        return {'FINISHED'}
