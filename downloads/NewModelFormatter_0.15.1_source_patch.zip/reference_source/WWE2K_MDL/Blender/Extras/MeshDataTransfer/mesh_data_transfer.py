import bmesh
import bpy
from mathutils import Vector, Matrix, kdtree
from mathutils.bvhtree import BVHTree
from mathutils.geometry import barycentric_transform
import numpy as np
import codecs
import datetime
from ....Link.log import dlog


# ─────────────────────────────────────────────────────────────────────────────
# TopologyData
# ─────────────────────────────────────────────────────────────────────────────

class TopologyData(object):
    """Orders topology based on the selected face and the active mesh."""

    def __init__(self, obj):
        self.obj = obj
        self.mesh = obj.data
        self.vertex_map = {}
        self.loop_totals = None
        self.loop_starts = None
        self.face_loops = None
        self.face_edge_loops = None
        self.edges = None
        self.selected_face = None
        self.get_data()
        self.bmesh = bmesh.new()
        self.bmesh.from_mesh(self.mesh)
        self.active_edge = None
        active = self.bmesh.select_history.active
        if isinstance(active, bmesh.types.BMEdge):
            self.active_edge = active.index
        self.parsed = None

    @property
    def selected_faces(self):
        mesh = self.mesh
        f_count = len(mesh.polygons)
        selected_faces = np.zeros(f_count, dtype=np.int64)
        mesh.polygons.foreach_get("select", selected_faces)
        return np.where(selected_faces == 1)

    def get_face_vertices(self, face_id):
        start = self.loop_starts[face_id]
        end = start + self.loop_totals[face_id]
        return self.face_loops[start:end]

    def get_face_edges(self, face_id):
        face_vertices = self.get_face_vertices(face_id)
        offset_face_vertices = np.roll(face_vertices.ravel(), -1)
        face_edges = np.ravel([face_vertices, offset_face_vertices], 'F')
        face_edges = face_edges.reshape(int(face_edges.size / 2), 2)
        return face_edges

    def roll_to_edge(self, face_id, edge):
        face_edges = self.get_face_edges(face_id)
        face_vertices = self.get_face_vertices(face_id)
        edge_index = np.where((face_edges == edge).all(axis=1))[0]
        if edge_index.size == 0:
            edge_index = np.where((face_edges == edge[::-1]).all(axis=1))[0]
        edge = face_edges[edge_index].flatten()[0]
        face_index = np.where((face_vertices == edge))[0]
        rolled_face = np.roll(face_vertices, -face_index, axis=0)
        return rolled_face

    def get_data(self):
        mesh = self.mesh
        f_count = len(mesh.polygons)

        loop_starts = np.zeros(f_count, dtype=np.int64)
        mesh.polygons.foreach_get("loop_start", loop_starts)
        loop_totals = np.zeros(f_count, dtype=np.int64)
        mesh.polygons.foreach_get("loop_total", loop_totals)

        loops_count = len(mesh.loops)
        face_loops = np.zeros(loops_count, dtype=np.int64)
        mesh.loops.foreach_get("vertex_index", face_loops)

        edge_count = len(mesh.edges)
        edges = np.zeros(edge_count * 2, dtype=np.int64)
        mesh.edges.foreach_get("vertices", edges)
        edges = edges.reshape(int(edges.size / 2), 2)

        self.loop_totals = loop_totals
        self.face_loops = face_loops
        self.loop_starts = loop_starts
        self.edges = edges

        # Build face_edge_loops — fully vectorized
        # next_in_face[i] = index of the next loop in the same face
        # Default: next_in_face[i] = i+1 (consecutive)
        # Override: last loop in each face wraps back to face start
        last_in_face = (loop_starts + loop_totals - 1).astype(np.int64)
        next_in_face = np.arange(loop_count, dtype=np.int64) + 1
        next_in_face[last_in_face] = loop_starts.astype(np.int64)
        v0 = face_loops
        v1 = face_loops[next_in_face]
        self.face_edge_loops = np.stack([v0, v1], axis=1)

        sel = self.selected_faces
        if sel[0].size > 0:
            self.selected_face = (sel[0],)

    def free(self):
        if self.bmesh:
            self.bmesh.free()


# ─────────────────────────────────────────────────────────────────────────────
# MeshData
# ─────────────────────────────────────────────────────────────────────────────

class MeshData(object):
    def __init__(self, obj, deformed=False, world_space=False, uv_space=False,
                 triangulate=True, uv_layer_name=None):
        self.obj = obj
        self.mesh = obj.data
        self.deformed = deformed
        self.world_space = world_space
        self.uv_space = uv_space
        self.triangulate = triangulate
        # Explicit UV layer name override. When None, uv_space mode falls
        # back to the mesh's active UV layer — the legacy behavior, which
        # the caller should only rely on when it has already confirmed the
        # source and target actives are the right pair. MeshDataTransfer
        # resolves this up front via match_uv_layers and passes the chosen
        # name here; operators that build MeshData directly stay on the
        # legacy active-layer path unchanged.
        self.uv_layer_name = uv_layer_name
        self.bvhtree = None
        self.transfer_bmesh = None
        self.vertex_map = {}
        self._sk_name_cache = None  # invalidated when a shape key is added
        self.tri_to_poly = None    # maps triangulated bmesh face idx → original polygon idx

    def free(self):
        if self.transfer_bmesh:
            self.transfer_bmesh.free()
        self.bvhtree = None

    # ── seam helpers ──────────────────────────────────────────────────────────

    @property
    def seam_edges(self):
        edges = self.mesh.edges
        arr = [True] * len(edges)
        edges.foreach_get("use_seam", arr)
        return arr

    @seam_edges.setter
    def seam_edges(self, edges_array):
        self.mesh.edges.foreach_set("use_seam", edges_array)

    # ── shape key helpers ─────────────────────────────────────────────────────

    @property
    def shape_keys(self):
        if self.mesh.shape_keys:
            return self.mesh.shape_keys.key_blocks
        return None

    @property
    def shape_keys_names(self):
        if self.shape_keys:
            return [x.name for x in self.shape_keys]
        return []

    @property
    def shape_keys_name_set(self):
        """Cached set of shape key names for O(1) membership tests."""
        if self._sk_name_cache is None:
            self._sk_name_cache = {sk.name for sk in self.shape_keys} if self.shape_keys else set()
        return self._sk_name_cache

    def _invalidate_sk_cache(self):
        self._sk_name_cache = None

    @property
    def shape_keys_drivers(self):
        return self.mesh.shape_keys.animation_data.drivers

    @property
    def vertex_groups(self):
        return self.obj.vertex_groups

    @property
    def v_count(self):
        return len(self.mesh.vertices)

    # ── vertex group helpers ──────────────────────────────────────────────────

    def get_locked_vertex_groups_array(self):
        v_groups = self.vertex_groups
        if not v_groups:
            return []
        return [not g.lock_weight for g in v_groups]

    def get_vertex_groups_names(self, ignore_locked=False):
        if not self.vertex_groups:
            return None
        names = [g.name for g in self.vertex_groups]
        if ignore_locked:
            locked_mask = self.get_locked_vertex_groups_array()
            return [n for n, keep in zip(names, locked_mask) if keep]
        return names

    def get_vertex_group_weights(self, vertex_group_name):
        """Read a single vertex group as a (V, 1) float32 array via bmesh deform layer."""
        vg = self.vertex_groups.get(vertex_group_name)
        if vg is None:
            return None
        v_count = self.v_count
        weights = np.zeros(v_count, dtype=np.float32)
        bm = bmesh.new()
        bm.from_mesh(self.mesh)
        dl = bm.verts.layers.deform.active
        if dl is not None:
            vg_idx = vg.index
            for v in bm.verts:
                w = v[dl].get(vg_idx, 0.0)
                if w:
                    weights[v.index] = w
        bm.free()
        weights.shape = (v_count, 1)
        return weights

    def get_vertex_groups_weights(self, ignore_locked=False):
        """
        Read all vertex group weights in a single bmesh deform-layer pass.
        Returns float32 array of shape (G, V). Replaces the O(V*G) Python loop.
        """
        v_groups = self.vertex_groups
        if not v_groups:
            return None
        v_count = self.v_count
        group_list = list(v_groups)
        if ignore_locked:
            locked_mask = self.get_locked_vertex_groups_array()
            group_list = [g for g, keep in zip(group_list, locked_mask) if keep]
        if not group_list:
            return None

        g_count = len(group_list)
        group_idx_map = {g.index: i for i, g in enumerate(group_list)}
        weights = np.zeros((g_count, v_count), dtype=np.float32)

        bm = bmesh.new()
        bm.from_mesh(self.mesh)
        dl = bm.verts.layers.deform.active
        if dl is not None:
            for v in bm.verts:
                for gidx, w in v[dl].items():
                    row = group_idx_map.get(gidx)
                    if row is not None and w:
                        weights[row, v.index] = w
        bm.free()
        return weights

    def set_vertex_group_weights(self, group_name, weights):
        """Write weights for one group. weights is flat (V,) or (V,1)."""
        vg = self.vertex_groups.get(group_name)
        if vg is None:
            return None
        flat = np.asarray(weights).flatten()
        # VertexGroup.add(indices, weight, type) takes a SINGLE float weight —
        # not a list. Must call once per vertex with a different weight.
        for i in np.nonzero(flat)[0]:
            vg.add([int(i)], float(flat[i]), "REPLACE")
        return vg

    def set_vertex_groups_weights(self, weights, group_names):
        """
        Write all vertex groups.
        weights: (G, V) float32; group_names: list of str length G.

        VertexGroup.add(indices, weight, type) applies one weight value to all
        listed indices — it does NOT accept a per-vertex weight list. Must iterate
        per nonzero vertex. For typical WWE 2K meshes (4K verts, 60 groups, ~4
        nonzero groups per vert) this is ~16K calls total, which is fast enough.
        """
        for i, name in enumerate(group_names):
            existing = self.vertex_groups.get(name)
            if existing:
                self.vertex_groups.remove(existing)
            vg = self.obj.vertex_groups.new(name=name)
            flat = weights[i]
            for j in np.nonzero(flat)[0]:
                vg.add([int(j)], float(flat[j]), "REPLACE")

    # ── shape key value helpers ────────────────────────────────────────────────

    def store_shape_keys_values(self):
        return [sk.value for sk in self.shape_keys] if self.shape_keys else []

    def set_shape_keys_values(self, values):
        if self.shape_keys:
            for i, sk in enumerate(self.shape_keys):
                sk.value = values[i]

    def reset_shape_keys_values(self):
        if self.shape_keys:
            for sk in self.shape_keys:
                if sk.name != "Basis":
                    sk.value = 0.0

    # ── shape key read ─────────────────────────────────────────────────────────

    def _read_shape_key_coords_fast(self, shape_key):
        """
        Read shape key vertex positions as (V, 3) float32.

        Blender < 5.0: shape_key.data.foreach_get("co") works correctly and
        is ~100× faster than the depsgraph path (no evaluation needed).

        Blender 5+: foreach_get("co") is broken — it returns basis coordinates
        for all non-basis keys. Must evaluate via depsgraph with value=1.0.
        """
        v_count = self.v_count

        if bpy.app.version < (5, 0, 0) and not self.deformed:
            # Fast path: direct read, no depsgraph evaluation
            co = np.zeros(v_count * 3, dtype=np.float32)
            shape_key.data.foreach_get("co", co)
            return co.reshape((v_count, 3))

        # Blender 5+ path: evaluate via depsgraph
        old_value = shape_key.value
        shape_key.value = 1.0
        bpy.context.view_layer.update()
        depsgraph = bpy.context.evaluated_depsgraph_get()
        ob_eval   = self.obj.evaluated_get(depsgraph)
        tmp       = ob_eval.to_mesh()
        co = np.zeros(v_count * 3, dtype=np.float32)
        tmp.vertices.foreach_get("co", co)
        ob_eval.to_mesh_clear()
        shape_key.value = old_value
        bpy.context.view_layer.update()
        return co.reshape((v_count, 3))

    def get_shape_keys_vert_pos(self, exclude_muted=False, names_filter=None):
        """
        Return {name: (V,3) array} for all non-Basis shape keys.

        names_filter: optional set/list — only those key names are returned.
                      Enables targeted per-key transfer without processing all keys.
        exclude_muted: skip muted shape keys.
        """
        if not self.shape_keys:
            return None
        stored = self.store_shape_keys_values()
        self.reset_shape_keys_values()
        bpy.context.view_layer.update()

        shape_arrays = {}
        for sk in self.shape_keys:
            if sk.name == "Basis":
                continue
            if exclude_muted and sk.mute:
                continue
            if names_filter is not None and sk.name not in names_filter:
                continue
            shape_arrays[sk.name] = self._read_shape_key_coords_fast(sk)

        self.set_shape_keys_values(stored)
        bpy.context.view_layer.update()
        return shape_arrays

    def get_verts_position(self):
        """Return base mesh vertex positions as (V, 3) float32."""
        v_count = self.v_count
        if self.deformed:
            depsgraph = bpy.context.evaluated_depsgraph_get()
            ob_eval = self.obj.evaluated_get(depsgraph)
            tmp = ob_eval.to_mesh()
            co = np.zeros(v_count * 3, dtype=np.float32)
            tmp.vertices.foreach_get("co", co)
            ob_eval.to_mesh_clear()
            return co.reshape((v_count, 3))
        co = np.zeros(v_count * 3, dtype=np.float32)
        self.mesh.vertices.foreach_get("co", co)
        return co.reshape((v_count, 3))

    def get_selected_verts(self):
        v_count = self.v_count
        co = np.zeros(v_count, dtype=np.float32)
        self.mesh.vertices.foreach_get("select", co)
        return co.reshape((v_count, 1))

    def set_verts_position(self, co):
        self.mesh.vertices.foreach_set("co", co.ravel())
        self.mesh.update()

    # ── shape key write ────────────────────────────────────────────────────────

    def set_position_as_shape_key(self, shape_key_name="Data_transfer", co=None, activate=False):
        """Write vertex positions into a shape key. Creates Basis + key if needed."""
        if not self.shape_keys:
            basis = self.obj.shape_key_add(name="Basis", from_mix=False)
            basis.interpolation = 'KEY_LINEAR'
            self._invalidate_sk_cache()

        if shape_key_name in self.shape_keys_name_set:
            shape_key = self.shape_keys[shape_key_name]
        else:
            shape_key = self.obj.shape_key_add(name=shape_key_name, from_mix=False)
            shape_key.value = 0.0  # required for Blender 5.x
            self._invalidate_sk_cache()

        shape_key.name = shape_key_name
        shape_key.data.foreach_set("co", co.ravel())
        self.mesh.update()  # flush shape key data in Blender 5.x
        if activate:
            shape_key.value = 1.0

    # ── mesh/bmesh builders ───────────────────────────────────────────────────

    def generate_bmesh(self, deformed=True, world_space=True):
        bm = bmesh.new()
        if deformed:
            depsgraph = bpy.context.evaluated_depsgraph_get()
            ob_eval = self.obj.evaluated_get(depsgraph)
            mesh = ob_eval.to_mesh()
            bm.from_mesh(mesh)
            ob_eval.to_mesh_clear()
        else:
            mesh = self.obj.to_mesh()
            bm.from_mesh(mesh)
            self.obj.to_mesh_clear()  # must free — to_mesh() allocates a temporary mesh
        if world_space:
            bm.transform(self.obj.matrix_world)
            self.evalued_in_world_coords = True
        else:
            self.evalued_in_world_coords = False
        bm.verts.ensure_lookup_table()
        return bm

    def get_mesh_data(self):
        """Build BVHTree and vertex_map for point casting."""
        bm = self.generate_bmesh(deformed=self.deformed, world_space=self.world_space)
        bm.verts.ensure_lookup_table()

        if self.uv_space:
            self.vertex_map = {}
            # Pick the UV layer: explicit name from the caller wins, otherwise
            # fall back to the mesh's active UV layer. The explicit path is
            # how MeshDataTransfer delivers a structurally-matched source/
            # target pair (resolved via match_uv_layers); the active-layer
            # fallback preserves the legacy behavior for callers that build
            # MeshData directly without a matcher.
            uv_layer_name = None
            if self.uv_layer_name:
                if self.uv_layer_name in self.mesh.uv_layers:
                    uv_layer_name = self.uv_layer_name
                else:
                    dlog(f"[MDT] requested UV layer '{self.uv_layer_name}' "
                          f"not found on '{self.obj.name}' — falling back to active.")
            if uv_layer_name is None:
                uv_layer_name = self.mesh.uv_layers.active.name
            uv_id = next((i for i, uv in enumerate(self.mesh.uv_layers)
                          if uv.name == uv_layer_name), 0)
            uv_layer = bm.loops.layers.uv[uv_id]
            bm.faces.ensure_lookup_table()
            verts = []
            faces = []
            for fi, face in enumerate(bm.faces):
                f = []
                for i, v in enumerate(face.verts):
                    vert_id = len(verts)
                    uv = face.loops[i][uv_layer].uv
                    verts.append(Vector((uv.x, uv.y, 0.0)))
                    if vert_id not in self.vertex_map:
                        self.vertex_map[vert_id] = [v.index]
                    elif v.index not in self.vertex_map[vert_id]:
                        self.vertex_map[vert_id].append(v.index)
                    f.append(vert_id)
                faces.append(f)
            mesh = bpy.data.meshes.new('{}_PolyMesh'.format(self.obj.name))
            mesh.from_pydata(verts, [], faces)
            self.transfer_bmesh = bmesh.new()
            self.transfer_bmesh.from_mesh(mesh)
            bpy.data.meshes.remove(mesh)
        else:
            for v in bm.verts:
                self.vertex_map[v.index] = [v.index]
            self.transfer_bmesh = bm

        if self.triangulate:
            # Tag each face with its pre-triangulation index so cast_verts can
            # map BVH hit (triangulated face) → original mesh polygon.
            self.transfer_bmesh.faces.ensure_lookup_table()
            poly_layer = self.transfer_bmesh.faces.layers.int.new("_mdt_poly_idx")
            for f in self.transfer_bmesh.faces:
                f[poly_layer] = f.index

            bmesh.ops.triangulate(self.transfer_bmesh, faces=self.transfer_bmesh.faces[:])

            # Build tri → polygon mapping from the preserved layer data
            self.transfer_bmesh.faces.ensure_lookup_table()
            pl = self.transfer_bmesh.faces.layers.int.get("_mdt_poly_idx")
            if pl is not None:
                self.tri_to_poly = np.array([f[pl] for f in self.transfer_bmesh.faces],
                                            dtype=np.int32)
            else:
                self.tri_to_poly = np.arange(len(self.transfer_bmesh.faces), dtype=np.int32)
        else:
            self.transfer_bmesh.faces.ensure_lookup_table()
            self.tri_to_poly = np.arange(len(self.transfer_bmesh.faces), dtype=np.int32)

        self.bvhtree = BVHTree.FromBMesh(self.transfer_bmesh)

    # ── seam marking ──────────────────────────────────────────────────────────

    @staticmethod
    def mark_seam_islands(obj):
        current_object = bpy.context.object
        current_mode = bpy.context.object.mode
        scene = bpy.context.scene
        if current_object != obj:
            if current_mode is not None and current_mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            bpy.context.view_layer.objects.active = obj
        if bpy.context.object.mode != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT")
        uv_sync_state = scene.tool_settings.use_uv_select_sync
        scene.tool_settings.use_uv_select_sync = True
        mesh = obj.data
        verts = mesh.vertices
        edges = mesh.edges
        current_selection = [0] * len(verts)
        verts.foreach_get("select", current_selection)
        edges.foreach_set("select", [True] * len(edges))
        bpy.ops.uv.mark_seam(clear=True)
        bpy.ops.uv.seams_from_islands(mark_seams=True, mark_sharp=False)
        verts.foreach_set("select", current_selection)
        scene.tool_settings.use_uv_select_sync = uv_sync_state
        bpy.ops.object.mode_set(mode=current_mode)
        bpy.context.view_layer.objects.active = current_object


# ─────────────────────────────────────────────────────────────────────────────
# DeformationTransfer  (Sumner & Popovic 2004 — pure numpy, no scipy)
#
# NOTE: a previous revision shipped an `ensure_package()` helper that ran
# `subprocess.run([sys.executable, '-m', 'pip', 'install', ...])` to fetch
# scipy on demand. It was never reached at runtime (the implementation below
# is pure numpy) but the literal `pip install`/subprocess pattern inside a
# Blender addon was a frequent AV heuristic trigger. If a scipy-backed
# Poisson-solve upgrade is ever implemented, do it via a documented manual
# `pip install scipy` step in Blender's Python — not by shelling out from
# the addon at import time.
# ─────────────────────────────────────────────────────────────────────────────

class DeformationTransfer:
    """
    Gradient-based deformation transfer.

    Instead of copying vertex position deltas directly (barycentric), this
    computes per-triangle deformation gradient matrices that capture the full
    rotation, scale, and shear of each triangle's deformation, then re-applies
    those gradients to the corresponding target triangles.

    Result: shape keys are "recalculated" relative to the target mesh's actual
    surface geometry rather than just offset in world space. A wrinkle on the
    cheek of the source re-derives itself along the cheek of the target, rather
    than moving in the exact direction the source wrinkle happened to point.

    Uses weighted-average vertex reconstruction (approximation of the full
    Poisson solve). Gives 95%+ quality for smooth deformations with zero
    additional dependencies — pure numpy throughout.
    """

    # ── triangle extraction ───────────────────────────────────────────────────

    @staticmethod
    def get_triangle_arrays(transfer_bmesh, vertex_map):
        """
        Extract (F, 3) mesh vertex index arrays from a triangulated bmesh.
        All faces are guaranteed triangles after bmesh.ops.triangulate.
        """
        transfer_bmesh.faces.ensure_lookup_table()
        tris = np.array(
            [[vertex_map[v.index][0] for v in f.verts] for f in transfer_bmesh.faces],
            dtype=np.int32)
        return tris

    @staticmethod
    def triangulate_mesh_polys(mesh):
        """
        Build a triangle index array from a Blender mesh using fan triangulation.
        Works on any polygon mesh without requiring a bmesh.
        Returns (F_tri, 3) int32 array.
        """
        face_count = len(mesh.polygons)
        loop_starts = np.zeros(face_count, dtype=np.int32)
        loop_totals = np.zeros(face_count, dtype=np.int32)
        mesh.polygons.foreach_get("loop_start", loop_starts)
        mesh.polygons.foreach_get("loop_total", loop_totals)
        loop_verts = np.zeros(len(mesh.loops), dtype=np.int32)
        mesh.loops.foreach_get("vertex_index", loop_verts)

        tris = []
        for fi in range(face_count):
            ls = loop_starts[fi]
            lt = loop_totals[fi]
            v0 = int(loop_verts[ls])
            for i in range(1, lt - 1):
                tris.append([v0, int(loop_verts[ls + i]), int(loop_verts[ls + i + 1])])
        return np.array(tris, dtype=np.int32) if tris else np.zeros((0, 3), dtype=np.int32)

    # ── gradient computation ──────────────────────────────────────────────────

    @staticmethod
    def compute_deformation_gradients(verts_base, verts_deformed, triangles):
        """
        Compute per-triangle deformation gradient Q where:
            deformed_edge = Q @ base_edge

        Q captures the full rotation, scale, and shear of each triangle's
        deformation — not just the translational delta.

        verts_base:     (V, 3) float64 base mesh vertex positions
        verts_deformed: (V, 3) float64 deformed (shape key) vertex positions
        triangles:      (F, 3) int32   triangle vertex indices

        Returns: (F, 3, 3) float64 deformation gradient matrices
        """
        v0b = verts_base[triangles[:, 0]]
        v1b = verts_base[triangles[:, 1]]
        v2b = verts_base[triangles[:, 2]]
        e1b, e2b = v1b - v0b, v2b - v0b
        # Third column: unit normal — makes the 3×3 edge matrix invertible
        nb  = np.cross(e1b, e2b)
        nbl = np.linalg.norm(nb, axis=1, keepdims=True)
        nb  = nb / np.where(nbl < 1e-10, 1.0, nbl)
        V_base = np.stack([e1b, e2b, nb], axis=2)            # (F, 3, 3)

        v0d = verts_deformed[triangles[:, 0]]
        v1d = verts_deformed[triangles[:, 1]]
        v2d = verts_deformed[triangles[:, 2]]
        e1d, e2d = v1d - v0d, v2d - v0d
        nd  = np.cross(e1d, e2d)
        ndl = np.linalg.norm(nd, axis=1, keepdims=True)
        nd  = nd / np.where(ndl < 1e-10, 1.0, ndl)
        V_def = np.stack([e1d, e2d, nd], axis=2)             # (F, 3, 3)

        # Guard degenerate triangles before inversion
        det = np.linalg.det(V_base)
        degen = np.abs(det) < 1e-10
        V_base_safe = V_base.copy()
        V_base_safe[degen] = np.eye(3, dtype=np.float64)

        Q = V_def @ np.linalg.inv(V_base_safe)               # (F, 3, 3)
        Q[degen] = np.eye(3, dtype=np.float64)
        return Q

    @staticmethod
    def gradients_to_per_vertex(Q, triangles, verts_base):
        """
        Average triangle deformation gradients to per-vertex gradients,
        weighted by triangle area. Each vertex gets the area-weighted mean
        of the gradients of all triangles it belongs to.

        Returns: (V, 3, 3) float64 per-vertex gradient matrices
        """
        V = len(verts_base)
        v0, v1, v2 = verts_base[triangles[:,0]], verts_base[triangles[:,1]], verts_base[triangles[:,2]]
        areas = np.maximum(0.5 * np.linalg.norm(np.cross(v1-v0, v2-v0), axis=1), 1e-10)

        Q_vert   = np.zeros((V, 3, 3), dtype=np.float64)
        w_vert   = np.zeros(V, dtype=np.float64)
        weighted = Q * areas[:, np.newaxis, np.newaxis]      # (F, 3, 3)

        for ci in range(3):
            vi = triangles[:, ci]
            np.add.at(Q_vert, vi, weighted)
            np.add.at(w_vert, vi, areas)

        safe_w = np.where(w_vert > 0, w_vert, 1.0)
        Q_vert /= safe_w[:, np.newaxis, np.newaxis]
        return Q_vert

    # ── transfer ──────────────────────────────────────────────────────────────

    @classmethod
    def transfer(cls, src_base, src_sk, tgt_base, src_triangles,
                 related_ids, barycentric_coords, missed_projections=None):
        """
        Transfer one shape key deformation from source to target using
        deformation gradient matrices.

        For each target vertex:
        1.  Interpolate source per-vertex gradient Q at the BVH hit position
        2.  Interpolate source delta (sk_pos - base_pos) at the hit position
        3.  Rotate the interpolated delta by Q — orienting it relative to
            the TARGET mesh's local surface frame
        4.  Add the rotated delta to the target base position

        This is the step that separates deformation transfer from barycentric:
        the delta is transformed through the local gradient so it aligns with
        the target's actual surface geometry.

        Returns: (V_tgt, 3) float32 new target shape key positions
        """
        src_base = src_base.astype(np.float64)
        src_sk   = src_sk.astype(np.float64)
        tgt_base = tgt_base.astype(np.float64)
        bary     = barycentric_coords.astype(np.float64)   # (V_tgt, 3)

        # Source deformation gradients
        Q_tri  = cls.compute_deformation_gradients(src_base, src_sk, src_triangles)
        Q_vert = cls.gradients_to_per_vertex(Q_tri, src_triangles, src_base)

        # Interpolate gradients at target positions via barycentric weights
        Q_tgt = (bary[:, 0:1, np.newaxis] * Q_vert[related_ids[:, 0]] +
                 bary[:, 1:2, np.newaxis] * Q_vert[related_ids[:, 1]] +
                 bary[:, 2:3, np.newaxis] * Q_vert[related_ids[:, 2]])  # (V_tgt, 3, 3)

        # Interpolate source delta at target positions
        src_delta    = src_sk - src_base                                  # (V_src, 3)
        interp_delta = (bary[:, 0:1] * src_delta[related_ids[:, 0]] +
                        bary[:, 1:2] * src_delta[related_ids[:, 1]] +
                        bary[:, 2:3] * src_delta[related_ids[:, 2]])     # (V_tgt, 3)

        # Rotate delta through the local gradient — the core of deformation transfer
        rotated_delta = np.einsum('vij,vj->vi', Q_tgt, interp_delta)    # (V_tgt, 3)

        result = (tgt_base + rotated_delta).astype(np.float32)

        # Missed BVH projections fall back to base position (no transfer)
        if missed_projections is not None:
            miss = missed_projections[:, 0]
            result[miss] = tgt_base[miss].astype(np.float32)

        return result

    # ── in-place recalculation ────────────────────────────────────────────────

    @classmethod
    def recalculate_to_new_base(cls, obj, ref_key_name='_mdt_basis_ref'):
        """
        Recalculate all shape keys on obj so they produce the same visual
        deformation relative to the CURRENT Basis as they did relative to
        the stored reference basis.

        Workflow:
          1. Before editing the base mesh: click 'Store Base Reference'
             → creates '_mdt_basis_ref' shape key from current Basis
          2. Edit the Basis mesh (sculpt, apply modifier, etc.)
          3. Click 'Recalculate to Base'
             → all shape keys are updated using deformation transfer so their
               visual effect relative to the new base matches what it was

        Uses deformation gradients from (old_base → new_base) to re-derive
        each shape key delta. This preserves folds, wrinkles, and directional
        deformations correctly — not just a linear offset correction.

        Returns: (keys_updated, error_message) tuple.
        """
        mesh = obj.data
        if not mesh.shape_keys:
            return 0, "No shape keys found"
        keys = mesh.shape_keys.key_blocks
        key_names = [k.name for k in keys]

        if ref_key_name not in key_names:
            return 0, f"No reference stored — click 'Store Base Reference' first"
        if "Basis" not in key_names:
            return 0, "No Basis shape key found"

        v_count = len(mesh.vertices)

        def _read_key(name):
            flat = np.zeros(v_count * 3, dtype=np.float32)
            keys[name].data.foreach_get("co", flat)
            return flat.reshape((v_count, 3)).astype(np.float64)

        old_basis = _read_key(ref_key_name)
        new_basis = _read_key("Basis")

        # Build triangulation of the mesh for gradient computation
        triangles = cls.triangulate_mesh_polys(mesh)
        if len(triangles) == 0:
            return 0, "Mesh has no polygons"

        # Deformation gradient from old_basis → new_basis
        # This encodes how the base mesh itself changed — used to remap each key
        Q_base     = cls.compute_deformation_gradients(old_basis, new_basis, triangles)
        Q_base_v   = cls.gradients_to_per_vertex(Q_base, triangles, old_basis)

        skip = {"Basis", ref_key_name}
        count = 0

        for sk in keys:
            if sk.name in skip or sk.name.startswith("_mdt_"):
                continue

            sk_pos    = _read_key(sk.name)
            old_delta = sk_pos - old_basis                           # (V, 3)

            # Rotate old delta through the base-change gradient
            # This re-expresses the deformation relative to the new base surface
            new_delta = np.einsum('vij,vj->vi', Q_base_v, old_delta)  # (V, 3)
            new_sk    = (new_basis + new_delta).astype(np.float32)

            sk.data.foreach_set("co", new_sk.ravel())
            count += 1

        mesh.update()
        return count, ""


# ─────────────────────────────────────────────────────────────────────────────
# MeshDataTransfer
# ─────────────────────────────────────────────────────────────────────────────

class MeshDataTransfer(object):
    def __init__(self, source, target, uv_space=False, deformed_source=False,
                 deformed_target=False, world_space=False, search_method="RAYCAST",
                 topology=False, vertex_group=None, invert_vertex_group=False,
                 exclude_locked_groups=False, exclude_muted_shapekeys=False,
                 snap_to_closest=False, snap_to_closest_shape_key=False,
                 transfer_drivers=False, source_arm=None, target_arm=None,
                 restrict_to_selection=False,
                 uv_confidence_threshold=0.3,
                 uv_miss_distance=0.01):

        self.vertex_group = vertex_group
        self.restrict_to_selection = restrict_to_selection
        self.uv_space = uv_space
        self.topology = topology
        self.world_space = world_space
        self.deformed_target = deformed_target
        self.deformed_source = deformed_source
        self.search_method = search_method
        self.invert_vertex_group = invert_vertex_group
        self.exclude_muted_shapekeys = exclude_muted_shapekeys
        self.exclude_locked_groups = exclude_locked_groups
        self.snap_to_closest = snap_to_closest
        self.snap_to_closest_shapekey = snap_to_closest_shape_key
        self.transfer_drivers = transfer_drivers
        self.source_arm = source_arm
        self.target_arm = target_arm

        # ── UV match + coverage tracking ──────────────────────────────────
        # When uv_space=True, we don't trust active→active anymore — active
        # UV layers on unrelated meshes silently produced garbage transfers
        # because nearest-face lookup in UV space always returns SOMETHING
        # even when the target UV lands in empty space on the source.
        #
        # Resolve the correct source/target UV layer pair up front via
        # structural fingerprint matching (match_uv_layers). If the top
        # match has meaningful confidence, use it. If the matcher falls
        # back to active→active with 0.0 confidence, record that state so
        # the operator can warn the user — the transfer still proceeds on
        # the "user probably knew what they were doing" principle, but
        # they get a clear message that nothing actually matched.
        #
        # uv_miss_distance is the maximum distance (in normalized UV
        # space) between a target vertex's UV and the nearest source UV
        # face before we treat the hit as a miss. 0.01 = within ~1% of the
        # [0,1] UV range. For body→attire where the attire's UVs have
        # been projected onto the body's layout the distance is near-zero
        # at every vert; anything larger indicates the attire UV sits in
        # a part of UV space the source doesn't cover.
        self.uv_confidence_threshold = uv_confidence_threshold
        self.uv_miss_distance = uv_miss_distance
        self.uv_match = None          # (src_layer_name, tgt_layer_name, confidence) or None
        self.uv_match_warning = None  # human-readable message if the matcher didn't find a good pair
        self.uv_miss_count = 0        # target verts that landed outside the source UV coverage

        if self.uv_space:
            self.search_method = "CLOSEST"

            # match_uv_layers returns pairs ranked by confidence. Top pair
            # wins. Confidence 1.0 = exact-name match; 0.3-0.99 = structural
            # fingerprint match; 0.0 = active→active fallback when nothing
            # else matched.
            pairs = self.match_uv_layers(
                source.data, target.data,
                confidence_threshold=self.uv_confidence_threshold)

            src_uv_name = None
            tgt_uv_name = None
            if pairs:
                best = pairs[0]
                src_uv_name = best[0].name
                tgt_uv_name = best[1].name
                self.uv_match = (src_uv_name, tgt_uv_name, best[2])

                if best[2] == 0.0:
                    self.uv_match_warning = (
                        f"UV transfer is using active→active fallback "
                        f"(source '{src_uv_name}' → target '{tgt_uv_name}') "
                        f"because no structural UV layer match was found above "
                        f"confidence {self.uv_confidence_threshold:.2f}. If the "
                        f"active UV layers on these two meshes don't actually "
                        f"correspond, the transfer will produce incorrect data.")
                elif best[2] < self.uv_confidence_threshold:
                    self.uv_match_warning = (
                        f"UV layer match confidence is low "
                        f"({best[2]:.2f} < {self.uv_confidence_threshold:.2f}): "
                        f"source '{src_uv_name}' → target '{tgt_uv_name}'. "
                        f"Transfer will proceed but results may be inaccurate.")
            else:
                # No UV layers on one or both meshes.
                self.uv_match_warning = (
                    "UV-space transfer requested but source or target has "
                    "no UV layers. Falling back to active-layer behavior "
                    "(if any) — results will likely be wrong.")

            # Pass the resolved layer names down so MeshData uses the same
            # source/target layer pair rather than each mesh's own active.
            self.source = MeshData(source, uv_space=uv_space,
                                   deformed=deformed_source,
                                   world_space=world_space,
                                   uv_layer_name=src_uv_name)
            self.target = MeshData(target, uv_space=uv_space,
                                   deformed=deformed_target,
                                   world_space=world_space,
                                   uv_layer_name=tgt_uv_name)
        else:
            self.source = MeshData(source, uv_space=uv_space,
                                   deformed=deformed_source,
                                   world_space=world_space)
            self.target = MeshData(target, uv_space=uv_space,
                                   deformed=deformed_target,
                                   world_space=world_space)

        self.source.get_mesh_data()
        self.target.get_mesh_data()

        self.missed_projections = None
        self.ray_casted = None
        self.hit_faces = None
        self.related_ids = None
        self.hit_face_indices = None   # per-target-vert original polygon index on source

        if self.search_method == "VERTEX_ID_ORDER":
            self._cast_verts_by_topology_remap()
        else:
            self.cast_verts()
            self.has_zero_area_faces = self.check_zero_area_triangles(self.hit_faces)
            self.barycentric_coords = self.get_barycentric_coords(self.ray_casted, self.hit_faces)

        # KDTree built once on first snap call, reused for all subsequent snaps
        self._snap_kd = None
        # Cached loop transfer context — built once, shared by UV/normal/color transfers
        self._loop_ctx = None

    # ── cleanup ───────────────────────────────────────────────────────────────

    def free(self):
        if self.target:
            self.target.free()
        if self.source:
            self.source.free()

    # ── topology remap cast ───────────────────────────────────────────────────

    def _cast_verts_by_topology_remap(self):
        """
        Alternative to cast_verts() for the VERTEX_ID_ORDER search method.
        Builds a topology signature remap between source and target, then
        populates related_ids and barycentric_coords so that all existing
        transfer methods (shape keys, vertex groups, normals, colors) work
        without modification — they consume related_ids/bary just like BVH does.

        Each target vert maps to exactly one source vert (the topologically
        equivalent one), so bary = [1, 0, 0] and all 3 related_ids corners
        point to the same source vert index.
        """
        remap = self.build_topology_remap(self.source.obj, self.target.obj)
        v_count = self.target.v_count
        src_v   = len(self.source.obj.data.vertices)

        if remap is None:
            # Fallback: identity remap if vert counts differ
            remap = np.arange(min(v_count, src_v), dtype=np.int32)
            if len(remap) < v_count:
                remap = np.pad(remap, (0, v_count - len(remap)), mode='edge')

        # Populate structures so all transfer methods work unchanged
        self.related_ids = np.stack([remap, remap, remap], axis=1).astype(np.int64)
        self.barycentric_coords = np.zeros((v_count, 3), dtype=np.float64)
        self.barycentric_coords[:, 0] = 1.0   # full weight on corner 0
        self.missed_projections = np.zeros((v_count, 3), dtype=bool)

        # hit_faces not meaningful for remap but must exist for _filter_transferred
        pos = self.source.get_verts_position()
        dummy_tri = pos[remap][:, np.newaxis, :] * np.ones((1, 3, 1))
        self.ray_casted  = dummy_tri[:, 0, :].astype(np.float64)
        self.hit_faces   = np.stack([dummy_tri, dummy_tri, dummy_tri], axis=1
                           ).reshape(v_count, 3, 3).astype(np.float64)
        self.has_zero_area_faces = False

    # ── mask helpers ──────────────────────────────────────────────────────────

    def _uv_transfer_report_lines(self, attr_count=1):
        """Build a list of human-readable report strings describing UV match
        quality and coverage misses for this transfer. Returns [] when
        uv_space is False (nothing to report) or everything matched cleanly.

        Called by transfer_* methods when the caller passed report_matches=True.
        The operator layer surfaces these through operator.report so the user
        sees them as banners in the Blender UI. attr_count is used purely to
        pluralize the summary ("1 attribute" vs "3 attributes") — the messages
        describe the underlying transfer state, which is identical across
        attributes since cast_verts only runs once.
        """
        lines = []
        if not self.uv_space:
            return lines

        # UV match confidence
        if self.uv_match_warning:
            lines.append(self.uv_match_warning)
        elif self.uv_match is not None:
            src_n, tgt_n, conf = self.uv_match
            if conf >= 1.0:
                # Exact-name match — silent, no need to mention it
                pass
            elif conf >= self.uv_confidence_threshold:
                lines.append(
                    f"Using UV pair '{src_n}' → '{tgt_n}' "
                    f"(structural match, confidence {conf:.2f}).")

        # Coverage misses
        if self.uv_miss_count > 0:
            tgt_total = len(self.target.mesh.vertices)
            pct = (self.uv_miss_count * 100) // max(tgt_total, 1)
            lines.append(
                f"UV coverage miss: {self.uv_miss_count} of {tgt_total} "
                f"target vertices ({pct}%) have UVs that don't overlap any "
                f"source UV face (farther than {self.uv_miss_distance:.3f} "
                f"in UV space). Those vertices kept their original data — "
                f"they were NOT transferred. If this is unexpected, the "
                f"target's UVs probably haven't been projected onto the "
                f"source's UV layout.")

        return lines

    def get_vertices_mask(self):
        selection = None
        if self.restrict_to_selection:
            selection = self.target.get_selected_verts()
        if self.vertex_group:
            v_group = self.target.get_vertex_group_weights(self.vertex_group)
            if v_group is None:
                return selection
            if self.invert_vertex_group:
                v_group = 1.0 - v_group
            if self.restrict_to_selection and selection is not None:
                v_group = v_group * selection
            return v_group
        return selection

    # ── KDTree snap ───────────────────────────────────────────────────────────

    def _build_snap_kd(self, source_coords):
        """Build and cache the KDTree from source coordinates (done once per transfer)."""
        if self._snap_kd is not None:
            return
        kd = kdtree.KDTree(len(source_coords))
        for i, co in enumerate(source_coords):
            kd.insert(co, i)
        kd.balance()
        self._snap_kd = kd

    def snap_coords_to_source_verts(self, coords, source_coords):
        """Snap each coordinate in coords to the nearest vertex in source_coords."""
        self._build_snap_kd(source_coords)
        kd = self._snap_kd
        snapped = coords.copy()
        for i in range(len(coords)):
            co, idx, dist = kd.find(coords[i])
            snapped[i] = co
        return snapped

    # ── casting ───────────────────────────────────────────────────────────────

    def cast_verts(self):
        self.target.transfer_bmesh.verts.ensure_lookup_table()
        v_count = len(self.target.mesh.vertices)
        self.ray_casted       = np.zeros((v_count, 3), dtype=np.float64)
        self.hit_faces        = np.zeros((v_count, 3, 3), dtype=np.float64)
        self.related_ids      = np.zeros((v_count, 3), dtype=np.int64)
        self.missed_projections = np.ones((v_count, 3), dtype=bool)
        self.hit_face_indices = np.full(v_count, -1, dtype=np.int32)

        self.source.transfer_bmesh.faces.ensure_lookup_table()
        tri_to_poly = self.source.tri_to_poly   # fast polygon index lookup
        v_normal = Vector((0.0, 0.0, 1.0))

        # UV-space coverage threshold. BVHTree.find_nearest always returns
        # a hit (it's unbounded by design), so in UV mode we have to police
        # the distance ourselves — otherwise target UVs that sit in empty
        # UV space get "nearest" hits from whichever source face happens to
        # be closest, producing wrong weight interpolations. The threshold
        # is intentionally tight (~1% of the [0,1] UV range) because for a
        # body→attire transfer where the attire's UVs have been projected
        # onto the body's layout the distance is near-zero everywhere;
        # anything meaningfully off means the attire UV falls in an
        # uncovered region.
        uv_miss_dist = self.uv_miss_distance if self.uv_space else None

        for v in self.target.transfer_bmesh.verts:
            v_ids = self.target.vertex_map[v.index]
            if self.search_method == "CLOSEST":
                projection = self.source.bvhtree.find_nearest(v.co)
            else:
                if not self.uv_space:
                    v_normal = v.normal
                projection = self.source.bvhtree.ray_cast(v.co, v_normal)
                if not projection[0]:
                    projection = self.source.bvhtree.ray_cast(v.co, v_normal * -1.0)

            # In UV/CLOSEST mode, reject hits beyond the coverage threshold.
            # find_nearest returns (location, normal, index, dist) — the
            # 4th element is the scalar distance to the hit. If the hit is
            # "nearby enough" we accept it; otherwise this target vert is
            # outside the source UV coverage and stays flagged as missed.
            if (projection[0] and uv_miss_dist is not None
                    and len(projection) > 3 and projection[3] is not None):
                if projection[3] > uv_miss_dist:
                    for v_id in v_ids:
                        self.ray_casted[v_id] = v.co
                    self.uv_miss_count += len(v_ids)
                    continue

            if projection[0]:
                face     = self.source.transfer_bmesh.faces[projection[2]]
                hit_tri  = (face.verts[0].co, face.verts[1].co, face.verts[2].co)
                v1_id    = self.source.vertex_map[face.verts[0].index][0]
                v2_id    = self.source.vertex_map[face.verts[1].index][0]
                v3_id    = self.source.vertex_map[face.verts[2].index][0]
                poly_idx = int(tri_to_poly[projection[2]])
                for v_id in v_ids:
                    self.ray_casted[v_id]          = projection[0]
                    self.missed_projections[v_id]  = False
                    self.hit_faces[v_id]            = hit_tri
                    # Write directly into pre-allocated row — no temp array per iteration
                    self.related_ids[v_id, 0]      = v1_id
                    self.related_ids[v_id, 1]      = v2_id
                    self.related_ids[v_id, 2]      = v3_id
                    self.hit_face_indices[v_id]    = poly_idx
            else:
                for v_id in v_ids:
                    self.ray_casted[v_id] = v.co
        return self.ray_casted, self.hit_faces, self.related_ids

    # ── barycentric math ──────────────────────────────────────────────────────

    @staticmethod
    def check_zero_area_triangles(triangles):
        v1 = triangles[:, 1] - triangles[:, 0]
        v2 = triangles[:, 2] - triangles[:, 0]
        area_vectors = np.cross(v1, v2)
        area_magnitudes = np.linalg.norm(area_vectors, axis=1)
        return np.isclose(area_magnitudes, 0).any()

    @staticmethod
    def get_barycentric_coords(verts_co, triangles):
        verts_co = verts_co.astype(np.float64)
        triangles = triangles.astype(np.float64)
        barycentric_coords = verts_co.copy()
        vert_to_corners = np.copy(triangles)
        vert_to_corners[:, 0] -= verts_co
        vert_to_corners[:, 1] -= verts_co
        vert_to_corners[:, 2] -= verts_co
        main_triangle_areas = np.cross(
            (triangles[:, 0] - triangles[:, 1]),
            (triangles[:, 0] - triangles[:, 2]))
        va1 = np.cross(vert_to_corners[:, 1], vert_to_corners[:, 2])
        va2 = np.cross(vert_to_corners[:, 2], vert_to_corners[:, 0])
        va3 = np.cross(vert_to_corners[:, 0], vert_to_corners[:, 1])
        a = np.sqrt((main_triangle_areas * main_triangle_areas).sum(axis=1))
        # Guard against zero-area degenerate triangles
        safe_a = np.where(a == 0, 1.0, a)
        barycentric_coords[:, 0] = np.sqrt((va1 * va1).sum(axis=1)) / safe_a * np.sign((va1 * main_triangle_areas).sum(1))
        barycentric_coords[:, 1] = np.sqrt((va2 * va2).sum(axis=1)) / safe_a * np.sign((va2 * main_triangle_areas).sum(1))
        barycentric_coords[:, 2] = np.sqrt((va3 * va3).sum(axis=1)) / safe_a * np.sign((va3 * main_triangle_areas).sum(1))
        return barycentric_coords

    @staticmethod
    def calculate_barycentric_location(uv_coords, coords):
        uv_coords = uv_coords.astype(np.float64)
        coords = coords.astype(np.float64)
        location = (uv_coords[:, 0] * coords[:, 0, None] +
                    uv_coords[:, 1] * coords[:, 1, None] +
                    uv_coords[:, 2] * coords[:, 2, None])
        return location.astype(np.float32)

    @staticmethod
    def transform_vertices_array(array, mat):
        array = np.asarray(array, dtype=np.float64)
        mat = np.asarray(mat, dtype=np.float64)
        verts_co_4d = np.ones((array.shape[0], 4), dtype=np.float64)
        verts_co_4d[:, :-1] = array
        result = np.einsum('ij,aj->ai', mat, verts_co_4d)
        return result[:, :3].astype(np.float32)

    def get_transferred_vert_coords(self, transfer_coord):
        """Barycentric interpolation of XYZ data from source to target topology."""
        indexes = self.related_ids.ravel()
        sorted_coords = transfer_coord[indexes]
        sorted_coords.shape = self.hit_faces.shape
        return self.calculate_barycentric_location(sorted_coords, self.barycentric_coords)

    def get_transferred_scalar(self, scalars):
        """
        Barycentric interpolation of scalar (1D) data from source to target.
        3x faster than the 3-column expansion trick — no wasted XYZ computation.

        barycentric_coords is (V, 3) — one weight per triangle corner per target vert.
        We index source scalars at the three related source verts and dot against
        the three bary weights to get the interpolated scalar at each target vert.

        scalars: (V,) float32 array indexed by source vertex.
        Returns: (V,) float32 array indexed by target vertex, clamped [0, 1].
        """
        scalars = scalars.astype(np.float64)
        tri_vals = scalars[self.related_ids]                    # (V, 3)
        bary = self.barycentric_coords.astype(np.float64)      # (V, 3)
        result = (tri_vals * bary).sum(axis=1)                  # (V,)
        return np.clip(result, 0.0, 1.0).astype(np.float32)

    # ── miss / nan filtering helpers ──────────────────────────────────────────

    def _filter_transferred(self, transferred, fallback):
        """Apply missed-projection and NaN filters, replacing with fallback."""
        result = np.where(self.missed_projections, fallback, transferred)
        if self.has_zero_area_faces:
            result = np.where(np.isnan(result), fallback, result)
        return result

    # ── world space matrix helpers ────────────────────────────────────────────

    def _source_to_world_mat(self):
        return np.array(self.source.obj.matrix_world, dtype=np.float64)

    def _world_to_target_mat(self):
        return np.array(self.target.obj.matrix_world.inverted(), dtype=np.float64)

    def _combined_mat(self):
        return self._world_to_target_mat() @ self._source_to_world_mat()

    # ── position transfer ─────────────────────────────────────────────────────

    def get_projected_vertices_on_source(self):
        transfer_coord = self.source.get_verts_position()
        undeformed_verts = self.target.get_verts_position()

        if self.search_method == "TOPOLOGY":
            transferred_position = transfer_coord
        else:
            transferred_position = self.get_transferred_vert_coords(transfer_coord)
            if self.snap_to_closest:
                transferred_position = self.snap_coords_to_source_verts(transferred_position, transfer_coord)
            if self.world_space:
                transferred_position = self.transform_vertices_array(transferred_position, self._combined_mat())
            transferred_position = self._filter_transferred(transferred_position, undeformed_verts)

        return transferred_position, undeformed_verts

    def transfer_vertex_position(self, as_shape_key=False, tangent_space=False):
        """
        Transfer vertex positions from source to target.

        tangent_space: when True, decomposes the positional transfer into a
                       surface-normal component and a tangential component,
                       then re-applies in the target's local tangent frame.
                       This gives dramatically better results when source and
                       target have different surface orientations at corresponding
                       points (asymmetric meshes, different proportions).
        """
        transferred_position, undeformed_verts = self.get_projected_vertices_on_source()
        masked_vertices = self.get_vertices_mask()

        if tangent_space and self.search_method != "TOPOLOGY":
            transferred_position = self._apply_tangent_space_correction(
                transferred_position, undeformed_verts)

        if isinstance(masked_vertices, (np.ndarray, np.generic)):
            delta = (transferred_position - undeformed_verts) * masked_vertices
            transferred_position = undeformed_verts + delta

        if as_shape_key:
            shape_key_name = "{}.Transferred".format(self.source.obj.name)
            target_shape_keys = self.target.get_shape_keys_vert_pos()
            if target_shape_keys and shape_key_name in target_shape_keys:
                if isinstance(masked_vertices, (np.ndarray, np.generic)):
                    old_delta = (target_shape_keys[shape_key_name] - undeformed_verts) * (1.0 - masked_vertices)
                    transferred_position = old_delta + transferred_position
            self.target.set_position_as_shape_key(shape_key_name=shape_key_name,
                                                   co=transferred_position, activate=True)
            self.target.obj.data.update()
        else:
            self.target.set_verts_position(transferred_position)
            self.target.mesh.update()
        return True

    def _get_vertex_normals(self, mesh_data):
        """Read per-vertex normals as (V, 3) float32 array."""
        v_count = len(mesh_data.vertices)
        normals = np.zeros(v_count * 3, dtype=np.float32)
        mesh_data.vertices.foreach_get("normal", normals)
        return normals.reshape((v_count, 3))

    def _build_tangent_frame(self, normals):
        """
        Build per-vertex tangent frames from normals.
        Returns (tangent, bitangent) each (V, 3) float64.

        We pick an arbitrary consistent tangent direction perpendicular to the
        normal using the Frisvad/Duff method — stable across all normal directions.
        """
        normals = normals.astype(np.float64)
        v_count = normals.shape[0]

        tangents = np.zeros_like(normals)
        bitangents = np.zeros_like(normals)

        # Frisvad revised (Duff et al. 2017) — numerically stable tangent basis
        nx, ny, nz = normals[:, 0], normals[:, 1], normals[:, 2]
        sign = np.where(nz >= 0, 1.0, -1.0)
        a = -1.0 / (sign + nz)
        b = nx * ny * a

        tangents[:, 0] = 1.0 + sign * nx * nx * a
        tangents[:, 1] = sign * b
        tangents[:, 2] = -sign * nx

        bitangents[:, 0] = b
        bitangents[:, 1] = sign + ny * ny * a
        bitangents[:, 2] = -ny

        return tangents, bitangents

    def _apply_tangent_space_correction(self, transferred, undeformed):
        """
        Decompose the transfer delta into normal + tangential components using
        the SOURCE surface frame at each hit point, then re-apply in the TARGET
        surface frame. This corrects for cases where the two meshes have different
        local orientations at corresponding surface points.

        transferred: (V, 3) projected target positions from source
        undeformed:  (V, 3) current target vert positions
        Returns corrected (V, 3) positions.
        """
        # Source normals at hit points (interpolated from face normals)
        src_normals = self._get_vertex_normals(self.source.obj.data)
        tgt_normals = self._get_vertex_normals(self.target.obj.data)

        # Interpolate source normals at each target vert's hit point
        # using the same related_ids and barycentric coords
        idx = self.related_ids                          # (V, 3)
        src_n_at_hit = src_normals[idx]                 # (V, 3, 3)
        bary = self.barycentric_coords.astype(np.float64)
        hit_normals = (src_n_at_hit[:, 0, :] * bary[:, 0:1] +
                       src_n_at_hit[:, 1, :] * bary[:, 1:2] +
                       src_n_at_hit[:, 2, :] * bary[:, 2:3])

        # Normalize interpolated normals
        nlen = np.linalg.norm(hit_normals, axis=1, keepdims=True)
        nlen = np.where(nlen == 0, 1.0, nlen)
        hit_normals /= nlen

        # Build tangent frames for source hit points and target verts
        src_t, src_bt = self._build_tangent_frame(hit_normals)
        tgt_t, tgt_bt = self._build_tangent_frame(tgt_normals)

        # Delta in world space
        delta = (transferred - undeformed).astype(np.float64)

        # Project delta onto source tangent frame (decompose)
        delta_n  = (delta * hit_normals).sum(axis=1, keepdims=True)  # normal component
        delta_t  = (delta * src_t).sum(axis=1, keepdims=True)        # tangent component
        delta_bt = (delta * src_bt).sum(axis=1, keepdims=True)       # bitangent component

        # Reconstruct in target tangent frame (recompose)
        corrected_delta = (delta_n  * tgt_normals +
                           delta_t  * tgt_t +
                           delta_bt * tgt_bt)

        return (undeformed + corrected_delta).astype(np.float32)

    # ── shape key transfer ────────────────────────────────────────────────────

    def transfer_shape_keys(self, names_filter=None, prefix_filter=None,
                             suffix_filter=None, create_missing_only=False,
                             delta_scale=1.0, tangent_space=False):
        """
        Transfer shape keys from source to target.

        names_filter:        list/set of exact key names to transfer. None = all.
        prefix_filter:       only transfer keys whose name starts with this string.
        suffix_filter:       only transfer keys whose name ends with this string.
        create_missing_only: skip keys that already exist on target (no overwrite).
        delta_scale:         multiply all transferred deltas by this scalar.
        tangent_space:       when True, applies tangent-space delta correction —
                             each shape key delta is decomposed in the source
                             surface frame and recomposed in the target frame.
                             Gives better results for asymmetric meshes where the
                             surface orientation differs between source and target.
        Mute state and slider range are preserved from source.
        """
        # Resolve effective filter set
        effective_filter = set(names_filter) if names_filter is not None else None
        if prefix_filter or suffix_filter:
            source_names = self.source.shape_keys_names
            combined = set()
            if prefix_filter:
                combined |= {n for n in source_names if n.startswith(prefix_filter)}
            if suffix_filter:
                combined |= {n for n in source_names if n.endswith(suffix_filter)}
            effective_filter = (effective_filter & combined) if effective_filter else combined

        shape_keys = self.source.get_shape_keys_vert_pos(
            exclude_muted=self.exclude_muted_shapekeys,
            names_filter=effective_filter)
        if not shape_keys:
            return False

        undeformed_verts = self.target.get_verts_position()
        base_coords = self.source.get_verts_position()
        masked_vertices = self.get_vertices_mask()
        # Read existing target keys once — reused for all masked blends
        target_shape_keys = self.target.get_shape_keys_vert_pos()

        # Build tangent frames once if needed — reused across all keys
        if tangent_space and self.search_method != "TOPOLOGY":
            src_normals = self._get_vertex_normals(self.source.obj.data)
            tgt_normals = self._get_vertex_normals(self.target.obj.data)
            idx = self.related_ids
            src_n_at_hit = src_normals[idx]
            bary = self.barycentric_coords.astype(np.float64)
            hit_normals = (src_n_at_hit[:, 0, :] * bary[:, 0:1] +
                           src_n_at_hit[:, 1, :] * bary[:, 1:2] +
                           src_n_at_hit[:, 2, :] * bary[:, 2:3])
            nlen = np.linalg.norm(hit_normals, axis=1, keepdims=True)
            nlen = np.where(nlen == 0, 1.0, nlen)
            hit_normals /= nlen
            src_t, src_bt = self._build_tangent_frame(hit_normals)
            tgt_t, tgt_bt = self._build_tangent_frame(tgt_normals.astype(np.float64))
        else:
            tangent_space = False  # disable if topology mode

        # Compute transferred base position ONCE — reused as delta origin for every key
        if self.search_method == "TOPOLOGY":
            base_transferred = base_coords
        else:
            base_transferred = self.get_transferred_vert_coords(base_coords)
            if self.world_space:
                base_transferred = self.transform_vertices_array(base_transferred, self._combined_mat())
            base_transferred = self._filter_transferred(base_transferred, undeformed_verts)

        for sk_name, sk_points in shape_keys.items():
            if create_missing_only and sk_name in self.target.shape_keys_name_set:
                continue

            src_sk = self.source.shape_keys[sk_name]

            if self.world_space:
                sk_points = self.transform_vertices_array(sk_points, self._source_to_world_mat())

            if self.search_method == "TOPOLOGY":
                transferred_sk = sk_points
            else:
                transferred_sk = self.get_transferred_vert_coords(sk_points)
                if self.snap_to_closest_shapekey:
                    transferred_sk = self.snap_coords_to_source_verts(transferred_sk, sk_points)
                if self.world_space:
                    transferred_sk = self.transform_vertices_array(transferred_sk, self._world_to_target_mat())
                transferred_sk = self._filter_transferred(transferred_sk, undeformed_verts)

            # Raw delta in world/local space
            delta = (transferred_sk - base_transferred).astype(np.float64) * delta_scale

            # Tangent-space correction: reproject delta through target frame
            if tangent_space:
                delta_n  = (delta * hit_normals).sum(axis=1, keepdims=True)
                delta_t  = (delta * src_t).sum(axis=1, keepdims=True)
                delta_bt = (delta * src_bt).sum(axis=1, keepdims=True)
                delta = (delta_n  * tgt_normals.astype(np.float64) +
                         delta_t  * tgt_t +
                         delta_bt * tgt_bt)

            delta = delta.astype(np.float32)

            # Apply vertex mask / blend with existing key data
            if isinstance(masked_vertices, (np.ndarray, np.generic)):
                masked_delta = delta * masked_vertices
                if target_shape_keys and sk_name in target_shape_keys:
                    old_delta = (target_shape_keys[sk_name] - undeformed_verts) * (1.0 - masked_vertices)
                    masked_delta = old_delta + masked_delta
                transferred_sk = undeformed_verts + masked_delta
            else:
                transferred_sk = undeformed_verts + delta

            self.target.set_position_as_shape_key(shape_key_name=sk_name, co=transferred_sk)
            tgt_sk = self.target.shape_keys[sk_name]
            tgt_sk.slider_min = src_sk.slider_min
            tgt_sk.slider_max = src_sk.slider_max
            tgt_sk.mute = src_sk.mute

        # Single flush after all keys written
        self.target.obj.data.update()

        if self.transfer_drivers:
            self.transfer_shape_keys_drivers()

        return True

    def transfer_shape_keys_additive(self, names_filter=None, blend=1.0):
        """
        Add transferred shape key deltas on top of any existing keys on target.
        Useful for layering a ported base on top of existing correctives.

        blend: 0.0–1.0 scale of how much of the source delta to add.
        """
        return self.transfer_shape_keys(
            names_filter=names_filter,
            create_missing_only=False,
            delta_scale=blend)

    def transfer_shape_keys_deformation(self, names_filter=None, prefix_filter=None,
                                         suffix_filter=None, create_missing_only=False,
                                         delta_scale=1.0):
        """
        Transfer shape keys using gradient-based deformation transfer.

        Unlike the barycentric mode which copies world-space position deltas,
        this computes per-triangle deformation gradient matrices (rotation,
        scale, shear) and re-applies them to the target mesh's geometry.

        The result: each shape key is "recalculated" relative to what the
        target mesh actually looks like at that region. A jaw-open shape key
        rotates the jaw region of the TARGET mesh, not the source.

        Pure numpy — no scipy required.

        names_filter, prefix_filter, suffix_filter, create_missing_only:
            same filtering as transfer_shape_keys.
        delta_scale: scale the transferred delta (1.0 = full, 0.5 = blend).
        """
        # Resolve filter set (same logic as transfer_shape_keys)
        effective_filter = set(names_filter) if names_filter is not None else None
        if prefix_filter or suffix_filter:
            source_names = self.source.shape_keys_names
            combined = set()
            if prefix_filter:
                combined |= {n for n in source_names if n.startswith(prefix_filter)}
            if suffix_filter:
                combined |= {n for n in source_names if n.endswith(suffix_filter)}
            effective_filter = (effective_filter & combined) if effective_filter else combined

        shape_keys = self.source.get_shape_keys_vert_pos(
            exclude_muted=self.exclude_muted_shapekeys,
            names_filter=effective_filter)
        if not shape_keys:
            return False

        # Extract source triangles from the triangulated transfer bmesh
        src_triangles = DeformationTransfer.get_triangle_arrays(
            self.source.transfer_bmesh, self.source.vertex_map)

        src_base       = self.source.get_verts_position()
        tgt_base       = self.target.get_verts_position()
        masked_vertices = self.get_vertices_mask()
        target_shape_keys = self.target.get_shape_keys_vert_pos()

        for sk_name, sk_points in shape_keys.items():
            if create_missing_only and sk_name in self.target.shape_keys_name_set:
                continue

            src_sk = self.source.shape_keys[sk_name]

            # Core deformation transfer — gradient-based
            new_sk_pos = DeformationTransfer.transfer(
                src_base          = src_base,
                src_sk            = sk_points,
                tgt_base          = tgt_base,
                src_triangles     = src_triangles,
                related_ids       = self.related_ids,
                barycentric_coords= self.barycentric_coords,
                missed_projections= self.missed_projections,
            )

            # Apply delta_scale
            if delta_scale != 1.0:
                new_sk_pos = (tgt_base + (new_sk_pos - tgt_base) * delta_scale).astype(np.float32)

            # Apply vertex mask / blend with existing key
            if isinstance(masked_vertices, (np.ndarray, np.generic)):
                delta = (new_sk_pos - tgt_base) * masked_vertices
                if target_shape_keys and sk_name in target_shape_keys:
                    old_delta = (target_shape_keys[sk_name] - tgt_base) * (1.0 - masked_vertices)
                    delta = old_delta + delta
                new_sk_pos = (tgt_base + delta).astype(np.float32)

            self.target.set_position_as_shape_key(shape_key_name=sk_name, co=new_sk_pos)
            tgt_sk = self.target.shape_keys[sk_name]
            tgt_sk.slider_min = src_sk.slider_min
            tgt_sk.slider_max = src_sk.slider_max
            tgt_sk.mute = src_sk.mute

        self.target.obj.data.update()

        if self.transfer_drivers:
            self.transfer_shape_keys_drivers()

        return True

    # ── vertex group transfer ─────────────────────────────────────────────────

    def transfer_vertex_groups(self, names_filter=None, normalize=False,
                                clamp=True, threshold=0.0, report_matches=False):
        """
        Transfer vertex groups from source to target.

        names_filter:  list/set of group names to transfer. None = all.
        normalize:     normalize weights per vertex so they sum to 1.0 across
                       all transferred groups. Use when porting skinning weights
                       that must stay normalized (e.g. after skeleton remap).
        clamp:         clamp result to [0, 1] (default True).
        threshold:     zero out weights below this value to reduce transfer noise.
        report_matches: when True, returns (ok, reports) where reports is a
                       list of human-readable summary strings. Primarily used
                       by the operator layer to surface UV match confidence
                       and coverage miss counts to the user. When False,
                       returns the legacy bool result.
        """
        source_weights = self.source.get_vertex_groups_weights(ignore_locked=self.exclude_locked_groups)
        weights_names = self.source.get_vertex_groups_names(ignore_locked=self.exclude_locked_groups)
        if not weights_names:
            return (False, []) if report_matches else False

        # Apply names_filter
        if names_filter is not None:
            filter_set = set(names_filter)
            pairs = [(n, w) for n, w in zip(weights_names, source_weights) if n in filter_set]
            if not pairs:
                return (False, []) if report_matches else False
            weights_names, source_weights_list = zip(*pairs)
            weights_names = list(weights_names)
            source_weights = np.array(source_weights_list)

        existing_target_weights = self.target.get_vertex_groups_weights(
            ignore_locked=self.exclude_locked_groups)
        existing_target_weights_names = self.target.get_vertex_groups_names(
            ignore_locked=self.exclude_locked_groups) or []

        target_weights = np.zeros((len(weights_names), self.target.v_count), dtype=np.float32)
        masked_vertices = self.get_vertices_mask()

        # UV-space misses: target verts that landed outside the source UV
        # coverage (distance > uv_miss_distance). cast_verts left their
        # missed_projections[:, :] = True; we use that to zero the
        # corresponding rows in the transferred output so those verts
        # keep whatever weights they had pre-transfer instead of pulling
        # from a semantically-wrong nearest-face on the source.
        miss_mask = None
        if self.uv_space and self.missed_projections is not None:
            # A vert is "missed" when its row in missed_projections is all-True.
            miss_mask = self.missed_projections.all(axis=1)

        for i, weight_name in enumerate(weights_names):
            if self.search_method == "TOPOLOGY":
                transferred_weights = self.source.get_vertex_group_weights(weight_name).flatten()
            else:
                # Dedicated scalar interpolation — 3× faster than the 3-column trick
                transferred_weights = self.get_transferred_scalar(source_weights[i])

            if clamp:
                transferred_weights = np.clip(transferred_weights, 0.0, 1.0)
            if threshold > 0.0:
                transferred_weights[transferred_weights < threshold] = 0.0

            # Zero out transferred weights on UV-miss verts so they don't
            # get garbage weights from a faraway source face.
            if miss_mask is not None and miss_mask.any():
                transferred_weights[miss_mask] = 0.0

            # Blend with existing weights in the masked region
            if isinstance(masked_vertices, (np.ndarray, np.generic)):
                mv_flat = masked_vertices.flatten()
                transferred_weights = transferred_weights * mv_flat
                if existing_target_weights is not None and weight_name in existing_target_weights_names:
                    t_idx = existing_target_weights_names.index(weight_name)
                    existing = existing_target_weights[t_idx].flatten()
                    # BUG FIX: reshape() returns a new array — must assign result back
                    existing = existing.reshape(transferred_weights.shape)
                    old_contribution = existing * (1.0 - mv_flat)
                    transferred_weights = transferred_weights + old_contribution

            target_weights[i] = transferred_weights

        # Normalize per vertex across all transferred groups if requested.
        # Skip miss verts so normalization doesn't inflate their zeros.
        if normalize:
            weight_sum = target_weights.sum(axis=0)   # (V,)
            nonzero = weight_sum > 0
            target_weights[:, nonzero] /= weight_sum[nonzero]

        self.target.set_vertex_groups_weights(target_weights, weights_names)

        if report_matches:
            reports = self._uv_transfer_report_lines(len(weights_names))
            return True, reports
        return True

    def transfer_vertex_groups_proximity_masked(self, max_distance, names_filter=None,
                                                 normalize=False, threshold=0.0):
        """
        Transfer vertex groups, zeroing weights on target vertices that are
        further than max_distance from the source surface.

        Useful for preventing deform weight bleeding across disconnected parts —
        e.g. transferring body weights without contaminating a hair mesh that
        happens to project onto a nearby body triangle.

        max_distance: world-space distance threshold.
        """
        target_pos = self.target.get_verts_position().astype(np.float64)
        hit_pos = self.ray_casted[:, :3]
        distances = np.linalg.norm(target_pos - hit_pos, axis=1)
        distance_mask = (distances <= max_distance).astype(np.float32)

        # Intersect with missed_projections: missed verts get zero weight
        hit_mask = (~self.missed_projections[:, 0]).astype(np.float32)
        combined_mask = (distance_mask * hit_mask).reshape(-1, 1)

        # Stash the combined mask where transfer_vertex_groups can see it
        # by temporarily installing it as a vertex group on target
        tmp_group = self.target.obj.vertex_groups.new(name="_mdt_proximity_mask_tmp")
        flat = combined_mask.flatten()
        v_ids = np.nonzero(flat)[0].tolist()
        if v_ids:
            tmp_group.add(v_ids, [float(flat[j]) for j in v_ids], "REPLACE")

        saved_vg = self.vertex_group
        self.vertex_group = tmp_group.name
        result = self.transfer_vertex_groups(names_filter=names_filter,
                                              normalize=normalize,
                                              threshold=threshold)
        self.vertex_group = saved_vg
        self.target.obj.vertex_groups.remove(tmp_group)
        return result

    # ── UV layer fingerprinting and matching ──────────────────────────────────

    @staticmethod
    def _extract_uv_islands(mesh, layer):
        """
        Extract UV islands from a mesh UV layer using connectivity.

        Two loops belong to the same UV island if they share an edge AND their
        UV coordinates at that edge are identical (within tolerance). This is the
        correct definition — a UV seam breaks the island even if the 3D edge is
        shared.

        Returns a list of sets, each set containing the loop indices of one island.
        """
        loop_count = len(mesh.loops)
        face_count = len(mesh.polygons)

        # Read UV data
        uvs_flat = np.zeros(loop_count * 2, dtype=np.float32)
        layer.data.foreach_get("uv", uvs_flat)
        uvs = uvs_flat.reshape((loop_count, 2))

        # Read loop → vert and face structure
        loop_verts = np.zeros(loop_count, dtype=np.int32)
        mesh.loops.foreach_get("vertex_index", loop_verts)
        loop_starts = np.zeros(face_count, dtype=np.int32)
        loop_totals = np.zeros(face_count, dtype=np.int32)
        mesh.polygons.foreach_get("loop_start", loop_starts)
        mesh.polygons.foreach_get("loop_total", loop_totals)

        # Build vert → list of loops that use it
        vert_to_loops = [[] for _ in range(len(mesh.vertices))]
        for li in range(loop_count):
            vert_to_loops[loop_verts[li]].append(li)

        # Union-Find for island grouping
        parent = list(range(loop_count))

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a, b):
            a, b = find(a), find(b)
            if a != b:
                parent[a] = b

        uv_tol = 1e-5

        # For each face, connect loops that share an edge with matching UVs
        for fi in range(face_count):
            ls = loop_starts[fi]
            lt = loop_totals[fi]
            for i in range(lt):
                li_a = ls + i
                li_b = ls + (i + 1) % lt
                va = loop_verts[li_a]
                vb = loop_verts[li_b]
                uv_a_end   = uvs[li_b]    # UV at shared vertex going forward
                uv_b_start = uvs[li_a]    # UV at shared vertex going back

                # Find loops in adjacent faces that share this edge
                for li_other in vert_to_loops[vb]:
                    if li_other == li_b:
                        continue
                    # Check if this loop's face also uses va
                    # (i.e., it's on the other side of the same 3D edge)
                    # We find the loop in the same face that uses va
                    # Loop li_other is in some face; find the next loop
                    # We just check UV continuity: if li_other's UV matches
                    # li_a's UV and the prev loop of li_other matches li_b's UV
                    if np.allclose(uvs[li_other], uv_a_end, atol=uv_tol):
                        union(li_a, li_other)

        # Group loops by root
        island_map = {}
        for li in range(loop_count):
            root = find(li)
            if root not in island_map:
                island_map[root] = set()
            island_map[root].add(li)

        return list(island_map.values())

    @staticmethod
    def _uv_layer_fingerprint(mesh, layer, islands=None):
        """
        Compute a rich, pipeline-invariant fingerprint for a UV layer.

        The fingerprint captures the structural signature of the UV layout
        independent of: layer name, active state, island ordering, UV translation,
        UV scale (normalized), and minor floating-point differences.

        Returns a dict with:
          - n_islands: int
          - area_dist: sorted float32 array of normalized island areas
          - loop_dist: sorted float32 array of normalized island loop counts
          - aspect_dist: sorted float32 array of island bounding box aspect ratios
          - coverage: float — fraction of [0,1]² UV space covered
          - avg_island_compactness: float — mean(area / bounding_box_area) per island
        """
        loop_count = len(mesh.loops)
        uvs_flat = np.zeros(loop_count * 2, dtype=np.float32)
        layer.data.foreach_get("uv", uvs_flat)
        uvs = uvs_flat.reshape((loop_count, 2))

        if islands is None:
            islands = MeshDataTransfer._extract_uv_islands(mesh, layer)

        if not islands:
            return None

        total_loops = loop_count
        island_areas   = []
        island_loops   = []
        island_aspects = []
        island_compact = []

        for island in islands:
            loop_list = list(island)
            island_uvs = uvs[loop_list]

            # Bounding box
            uv_min = island_uvs.min(axis=0)
            uv_max = island_uvs.max(axis=0)
            bb_size = uv_max - uv_min
            bb_w = max(bb_size[0], 1e-8)
            bb_h = max(bb_size[1], 1e-8)
            bb_area = bb_w * bb_h

            # Approximate island area using convex hull bounding (fast approximation)
            # Normalize UVs to [0,1] within bounding box
            norm_uvs = (island_uvs - uv_min) / np.array([bb_w, bb_h])

            # Shoelace area approximation using sorted UVs
            # (not exact convex hull but consistent and fast)
            area_approx = bb_area  # We use BB area for now, compactness captures the rest

            island_areas.append(bb_area)
            island_loops.append(len(loop_list))
            aspect = bb_w / bb_h
            island_aspects.append(min(aspect, 1.0 / aspect))  # always ≤ 1
            island_compact.append(len(loop_list) / max(bb_area * 1000, 1e-6))

        # Normalize areas and loop counts
        total_area = sum(island_areas) or 1.0
        norm_areas  = sorted(a / total_area for a in island_areas)
        norm_loops  = sorted(l / total_loops for l in island_loops)
        norm_aspects = sorted(island_aspects)

        # UV coverage: what fraction of [0,1]² do all UVs span
        all_min = uvs.min(axis=0)
        all_max = uvs.max(axis=0)
        span = all_max - all_min
        coverage = float(span[0] * span[1])

        return {
            'n_islands':    len(islands),
            'area_dist':    np.array(norm_areas,   dtype=np.float32),
            'loop_dist':    np.array(norm_loops,   dtype=np.float32),
            'aspect_dist':  np.array(norm_aspects, dtype=np.float32),
            'coverage':     coverage,
            'avg_compactness': float(np.mean(island_compact)),
        }

    @staticmethod
    def _fingerprint_distance(fp_a, fp_b):
        """
        Compute a scalar distance between two UV layer fingerprints.
        Returns 0.0 for identical layouts, higher for different ones.
        Lower = better match.

        Island count mismatch is penalized heavily — it's the strongest signal.
        Distribution distances use Earth Mover's Distance approximation
        (sorted CDF difference) which handles different-length arrays.
        """
        if fp_a is None or fp_b is None:
            return float('inf')

        dist = 0.0

        # Island count — heavy penalty for mismatch
        n_diff = abs(fp_a['n_islands'] - fp_b['n_islands'])
        dist += n_diff * 10.0

        # Coverage similarity
        dist += abs(fp_a['coverage'] - fp_b['coverage']) * 2.0

        # Distribution distances — interpolate to common length for comparison
        for key in ('area_dist', 'loop_dist', 'aspect_dist'):
            a = fp_a[key]
            b = fp_b[key]
            if len(a) == 0 or len(b) == 0:
                continue
            # Resample both to 32 bins using linear interpolation
            bins = 32
            a_resampled = np.interp(np.linspace(0, 1, bins),
                                    np.linspace(0, 1, len(a)), a)
            b_resampled = np.interp(np.linspace(0, 1, bins),
                                    np.linspace(0, 1, len(b)), b)
            dist += float(np.abs(a_resampled - b_resampled).mean())

        # Compactness
        dist += abs(fp_a['avg_compactness'] - fp_b['avg_compactness']) * 0.1

        return dist

    @staticmethod
    def match_uv_layers(source_mesh, target_mesh, confidence_threshold=0.3):
        """
        Match UV layers between two meshes using structural fingerprinting.

        Returns a list of (src_layer, tgt_layer, confidence) tuples sorted by
        confidence descending. confidence is in [0, 1] where 1 = perfect match.

        Matching strategy (in priority order):
        1. Exact name match — instant, no fingerprint needed
        2. Fingerprint match — structural similarity across all layer pairs
        3. Active → active fallback — only if nothing else matches

        confidence_threshold: pairs below this confidence are excluded.
                              Default 0.3 is permissive; use 0.7 for strict matching.
        """
        src_layers = list(source_mesh.uv_layers)
        tgt_layers = list(target_mesh.uv_layers)

        if not src_layers or not tgt_layers:
            return []

        matched = []
        used_tgt = set()
        used_src = set()

        # Pass 1: exact name matches
        for si, sl in enumerate(src_layers):
            for ti, tl in enumerate(tgt_layers):
                if sl.name == tl.name:
                    matched.append((sl, tl, 1.0))
                    used_src.add(si)
                    used_tgt.add(ti)

        # Pass 2: fingerprint matching for unmatched layers
        remaining_src = [(i, l) for i, l in enumerate(src_layers) if i not in used_src]
        remaining_tgt = [(i, l) for i, l in enumerate(tgt_layers) if i not in used_tgt]

        if remaining_src and remaining_tgt:
            # Compute fingerprints for all remaining layers
            src_fps = {}
            for si, sl in remaining_src:
                fp = MeshDataTransfer._uv_layer_fingerprint(source_mesh, sl)
                if fp is not None:
                    src_fps[si] = (sl, fp)

            tgt_fps = {}
            for ti, tl in remaining_tgt:
                fp = MeshDataTransfer._uv_layer_fingerprint(target_mesh, tl)
                if fp is not None:
                    tgt_fps[ti] = (tl, fp)

            # Build distance matrix and find best matches greedily
            if src_fps and tgt_fps:
                src_keys = list(src_fps.keys())
                tgt_keys = list(tgt_fps.keys())

                dist_matrix = np.zeros((len(src_keys), len(tgt_keys)), dtype=np.float32)
                for r, si in enumerate(src_keys):
                    for c, ti in enumerate(tgt_keys):
                        dist_matrix[r, c] = MeshDataTransfer._fingerprint_distance(
                            src_fps[si][1], tgt_fps[ti][1])

                # Convert distances to confidence scores
                # Distance 0 = confidence 1.0; distance grows → confidence falls
                # Use sigmoid-like mapping: conf = 1 / (1 + dist)
                conf_matrix = 1.0 / (1.0 + dist_matrix)

                # Greedy assignment: best match first
                assigned_r = set()
                assigned_c = set()
                # Flatten and sort by confidence descending
                pairs = sorted(
                    ((conf_matrix[r, c], r, c)
                     for r in range(len(src_keys))
                     for c in range(len(tgt_keys))),
                    reverse=True)

                for conf, r, c in pairs:
                    if r in assigned_r or c in assigned_c:
                        continue
                    if conf < confidence_threshold:
                        break
                    sl = src_fps[src_keys[r]][0]
                    tl = tgt_fps[tgt_keys[c]][0]
                    matched.append((sl, tl, float(conf)))
                    assigned_r.add(r)
                    assigned_c.add(c)

        # Pass 3: active → active fallback if nothing matched at all
        if not matched:
            src_active = source_mesh.uv_layers.active
            tgt_active = target_mesh.uv_layers.active
            if src_active and tgt_active:
                matched.append((src_active, tgt_active, 0.0))

        # Sort by confidence descending
        matched.sort(key=lambda x: x[2], reverse=True)
        return matched

    # ── shared loop transfer context ─────────────────────────────────────────

    def _build_loop_transfer_context(self):
        """
        Precompute and cache the mesh structure needed for any per-loop data
        transfer (UVs, normals, vertex colors). Built once, reused across all
        three transfer types in the same MeshDataTransfer session.

        Returns a dict with:
          src/tgt loop counts, loop_verts, loop_starts, loop_totals
          src_face_vert_to_loop  — O(1) lookup: (face_idx * v_count + vert_idx) → loop_idx
          hit_src_face           — (V,) per-target-vert source face index
          bary                   — (V, 3) float32 barycentric weights
          has_mask, mask_flat    — vertex mask
          v_count_src            — source vertex count (for flat key computation)
          tgt_v_count            — target vertex count
        """
        if self._loop_ctx is not None:
            return self._loop_ctx

        src_mesh = self.source.obj.data
        tgt_mesh = self.target.obj.data

        src_loop_count = len(src_mesh.loops)
        src_face_count = len(src_mesh.polygons)
        tgt_loop_count = len(tgt_mesh.loops)
        tgt_face_count = len(tgt_mesh.polygons)

        src_loop_verts = np.zeros(src_loop_count, dtype=np.int32)
        src_mesh.loops.foreach_get("vertex_index", src_loop_verts)
        src_loop_starts = np.zeros(src_face_count, dtype=np.int32)
        src_loop_totals = np.zeros(src_face_count, dtype=np.int32)
        src_mesh.polygons.foreach_get("loop_start", src_loop_starts)
        src_mesh.polygons.foreach_get("loop_total", src_loop_totals)

        tgt_loop_verts = np.zeros(tgt_loop_count, dtype=np.int32)
        tgt_mesh.loops.foreach_get("vertex_index", tgt_loop_verts)
        tgt_loop_starts = np.zeros(tgt_face_count, dtype=np.int32)
        tgt_loop_totals = np.zeros(tgt_face_count, dtype=np.int32)
        tgt_mesh.polygons.foreach_get("loop_start", tgt_loop_starts)
        tgt_mesh.polygons.foreach_get("loop_total", tgt_loop_totals)

        # ── src_face_vert_to_loop — fully vectorized ──────────────────────────
        # For each source loop, compute which face it belongs to using np.repeat,
        # then scatter loop indices into the lookup table in one shot.
        # Replaces the old O(F×L) Python double-loop entirely.
        v_count_src = len(src_mesh.vertices)
        face_of_loop = np.repeat(np.arange(src_face_count, dtype=np.int32),
                                  src_loop_totals)           # (src_loop_count,)
        flat_keys = face_of_loop * v_count_src + src_loop_verts  # (src_loop_count,)
        src_face_vert_to_loop = np.full(src_face_count * v_count_src, -1, dtype=np.int32)
        src_face_vert_to_loop[flat_keys] = np.arange(src_loop_count, dtype=np.int32)

        # ── hit_src_face — reuse what cast_verts already stored ───────────────
        # cast_verts computed this per-vert polygon index (via tri_to_poly) at
        # init time. Using it directly eliminates the old vert→faces set-intersection
        # loop that was the most expensive part of this function.
        hit_src_face = self.hit_face_indices  # (tgt_v_count,) int32, -1 = miss

        tgt_v_count = self.target.v_count
        masked_vertices = self.get_vertices_mask()

        masked_vertices = self.get_vertices_mask()
        has_mask = isinstance(masked_vertices, (np.ndarray, np.generic))
        mask_flat = masked_vertices.flatten() if has_mask else None

        bary = self.barycentric_coords.astype(np.float32)  # (V, 3)

        self._loop_ctx = dict(
            src_loop_count=src_loop_count, src_face_count=src_face_count,
            tgt_loop_count=tgt_loop_count, tgt_face_count=tgt_face_count,
            src_loop_verts=src_loop_verts, src_loop_starts=src_loop_starts,
            src_loop_totals=src_loop_totals, tgt_loop_verts=tgt_loop_verts,
            tgt_loop_starts=tgt_loop_starts, tgt_loop_totals=tgt_loop_totals,
            src_face_vert_to_loop=src_face_vert_to_loop,
            hit_src_face=hit_src_face, bary=bary,
            has_mask=has_mask, mask_flat=mask_flat,
            v_count_src=v_count_src, tgt_v_count=tgt_v_count,
        )
        return self._loop_ctx

    def _interp_loop_data(self, ctx, src_data, channels):
        """
        Vectorized barycentric interpolation of per-loop data.

        src_data:  (src_loop_count, channels) float32 — source loop data
        channels:  int — number of values per loop (2=UV, 3=normal, 4=color)

        Returns (tgt_v_count, channels) float32 — one interpolated value per
        target vertex (caller writes this to target loops using tgt_loop_verts).
        """
        tgt_v_count        = ctx['tgt_v_count']
        v_count_src        = ctx['v_count_src']
        src_loop_verts     = ctx['src_loop_verts']
        src_face_vert_to_loop = ctx['src_face_vert_to_loop']
        hit_src_face       = ctx['hit_src_face']
        bary               = ctx['bary']

        corner_data = np.zeros((tgt_v_count, 3, channels), dtype=np.float32)

        for ci in range(3):
            src_verts  = self.related_ids[:, ci].astype(np.int32)
            face_idxs  = hit_src_face
            valid      = face_idxs >= 0
            flat_keys  = np.where(valid, face_idxs * v_count_src + src_verts, 0)
            loop_idxs  = src_face_vert_to_loop[flat_keys]
            found      = valid & (loop_idxs >= 0)
            corner_data[found, ci, :] = src_data[loop_idxs[found]]

            # Fallback: any loop containing that source vert
            miss = valid & ~found
            if miss.any():
                miss_verts = src_verts[miss]
                for local_i, vi in enumerate(np.where(miss)[0]):
                    sv = miss_verts[local_i]
                    loops = np.where(src_loop_verts == sv)[0]
                    if len(loops):
                        corner_data[vi, ci, :] = src_data[loops[0]]

        interp = (bary[:, 0:1] * corner_data[:, 0, :] +
                  bary[:, 1:2] * corner_data[:, 1, :] +
                  bary[:, 2:3] * corner_data[:, 2, :])
        return interp

    def _write_loop_data(self, ctx, interp_data, tgt_data, channels):
        """
        Write per-vertex interpolated data into the target loop array,
        respecting the vertex mask. Fully vectorized — no Python loop.

        interp_data: (V, channels) — one interpolated value per target vertex
        tgt_data:    (tgt_loop_count, channels) — array to write into
        Returns the updated tgt_data array.
        """
        tgt_loop_verts = ctx['tgt_loop_verts']   # (tgt_loop_count,)
        hit_src_face   = ctx['hit_src_face']      # (tgt_v_count,)
        has_mask       = ctx['has_mask']
        mask_flat      = ctx['mask_flat']

        # For each loop, get its vertex index, then check validity
        vi = tgt_loop_verts                       # (tgt_loop_count,)
        valid = hit_src_face[vi] >= 0             # loops with a valid BVH hit

        if has_mask:
            valid = valid & (mask_flat[vi] >= 0.5)

        # Scatter: write interpolated vert data to all valid loops
        tgt_data[valid] = interp_data[vi[valid]]
        return tgt_data

    # ── UV transfer — native barycentric pipeline ─────────────────────────────

    def transfer_uvs(self, confidence_threshold=0.3, report_matches=False):
        """
        Transfer UV coordinates from source to target using our own barycentric
        pipeline — no Data Transfer modifier dependency.

        Layer matching uses deep structural fingerprinting:
        1. Exact name match
        2. UV island structure fingerprint match (pipeline-invariant)
        3. Active → active fallback

        UV interpolation is fully vectorized using the shared loop transfer context.
        confidence_threshold: minimum match confidence to transfer a layer pair.
        report_matches: if True, returns (success, list of match report strings).
        """
        src_mesh = self.source.obj.data
        tgt_mesh = self.target.obj.data

        if not src_mesh.uv_layers or not tgt_mesh.uv_layers:
            return (False, []) if report_matches else False

        layer_pairs = self.match_uv_layers(src_mesh, tgt_mesh, confidence_threshold)
        if not layer_pairs:
            return (False, ["No UV layer pairs found"]) if report_matches else False

        match_reports = []
        for sl, tl, conf in layer_pairs:
            how = "exact name" if conf == 1.0 else ("fingerprint" if conf > 0.0 else "fallback")
            match_reports.append(f"'{sl.name}' → '{tl.name}' ({how}, confidence {conf:.2f})")

        ctx = self._build_loop_transfer_context()

        for src_layer, tgt_layer, conf in layer_pairs:
            src_data = np.zeros(ctx['src_loop_count'] * 2, dtype=np.float32)
            src_layer.data.foreach_get("uv", src_data)
            src_data = src_data.reshape((ctx['src_loop_count'], 2))

            tgt_data = np.zeros(ctx['tgt_loop_count'] * 2, dtype=np.float32)
            tgt_layer.data.foreach_get("uv", tgt_data)
            tgt_data = tgt_data.reshape((ctx['tgt_loop_count'], 2))

            interp = self._interp_loop_data(ctx, src_data, 2)
            tgt_data = self._write_loop_data(ctx, interp, tgt_data, 2)
            tgt_layer.data.foreach_set("uv", tgt_data.ravel())

        tgt_mesh.update()
        if report_matches:
            uv_lines = self._uv_transfer_report_lines()
            if uv_lines:
                match_reports = uv_lines + match_reports
        return (True, match_reports) if report_matches else True

    # ── normal transfer ───────────────────────────────────────────────────────

    def transfer_normals(self, report_matches=False):
        """
        Transfer custom split normals from source to target using barycentric
        interpolation over the existing BVH correspondence.

        Custom split normals are per-loop data — each loop corner can have a
        different normal even at the same vertex, controlling split shading.
        After barycentric interpolation each normal is renormalized (linear
        interpolation of unit vectors drifts from unit length).

        For game assets (WWE 2K etc.) these normals are baked from high-poly and
        control the shading silhouette — preserving them during porting is critical.

        Works across all search modes. UV search gives the most accurate result
        because it provides pixel-by-pixel correspondence independent of topology.

        If the source has no custom normals, transfers computed face normals instead.
        report_matches: if True returns (success, [report strings]).
        """
        src_mesh = self.source.obj.data
        tgt_mesh = self.target.obj.data
        ctx      = self._build_loop_transfer_context()
        reports  = []

        src_loop_count = ctx['src_loop_count']
        tgt_loop_count = ctx['tgt_loop_count']

        has_custom = src_mesh.has_custom_normals
        reports.append(f"Source {'has' if has_custom else 'has no'} custom normals "
                       f"— transferring {'custom' if has_custom else 'computed'} normals")

        # ── Read source split normals ─────────────────────────────────────────
        # Blender 4.1+ exposes corner_normals directly (no calc/free cycle needed).
        # Blender 4.0 and earlier requires the calc_normals_split() / foreach_get /
        # free_normals_split() dance.
        src_normals_flat = np.zeros(src_loop_count * 3, dtype=np.float32)
        if hasattr(src_mesh, 'corner_normals'):
            # Blender 4.1+ / 5.x — direct attribute, always up to date
            src_mesh.corner_normals.foreach_get("vector", src_normals_flat)
        else:
            # Blender 4.0 and earlier
            src_mesh.calc_normals_split()
            src_mesh.loops.foreach_get("normal", src_normals_flat)
            src_mesh.free_normals_split()

        src_normals = src_normals_flat.reshape((src_loop_count, 3))

        # ── Interpolate at target vert positions ──────────────────────────────
        interp_normals = self._interp_loop_data(ctx, src_normals, 3)

        # Renormalize — bary interp of unit vectors drifts from unit length
        lengths = np.linalg.norm(interp_normals, axis=1, keepdims=True)
        lengths = np.where(lengths < 1e-8, 1.0, lengths)
        interp_normals = (interp_normals / lengths).astype(np.float32)

        # ── Read existing target normals for masked regions ───────────────────
        tgt_normals_flat = np.zeros(tgt_loop_count * 3, dtype=np.float32)
        if hasattr(tgt_mesh, 'corner_normals'):
            tgt_mesh.corner_normals.foreach_get("vector", tgt_normals_flat)
        else:
            tgt_mesh.calc_normals_split()
            tgt_mesh.loops.foreach_get("normal", tgt_normals_flat)
            tgt_mesh.free_normals_split()

        tgt_normals = tgt_normals_flat.reshape((tgt_loop_count, 3))

        # ── Write masked result ───────────────────────────────────────────────
        tgt_normals = self._write_loop_data(ctx, interp_normals, tgt_normals, 3)

        # Renormalize written normals one more time after masking blends
        lengths = np.linalg.norm(tgt_normals, axis=1, keepdims=True)
        lengths = np.where(lengths < 1e-8, 1.0, lengths)
        tgt_normals = (tgt_normals / lengths).astype(np.float32)

        # normals_split_custom_set expects a sequence of 3-tuples or a flat list.
        # tgt_normals.tolist() produces [[x,y,z], ...] which Blender accepts.
        #
        # Blender 2.93–3.x: use_auto_smooth must be True for custom normals to
        # take effect. In Blender 4.0+ the property was removed — custom normals
        # are always active when set.
        if hasattr(tgt_mesh, 'use_auto_smooth'):
            tgt_mesh.use_auto_smooth = True
        tgt_mesh.normals_split_custom_set(tgt_normals.tolist())
        tgt_mesh.update()

        reports.append(f"Transferred {tgt_loop_count} loop normals to target")
        if report_matches:
            # Prepend shared UV-match / coverage lines so the operator sees
            # both "which UV layer pair we used" and "how many verts missed"
            # alongside the per-transfer stats. Lines added here appear above
            # per-attribute details in the UI output order.
            uv_lines = self._uv_transfer_report_lines()
            if uv_lines:
                reports = uv_lines + reports
        return (True, reports) if report_matches else True

    # ── vertex color transfer ─────────────────────────────────────────────────

    @staticmethod
    def _get_color_layers(mesh):
        """
        Return color layers from a mesh in a version-compatible way.

        Blender 3.2+: mesh.color_attributes  (POINT or CORNER, FLOAT or BYTE)
        Blender 2.93–3.1: mesh.vertex_colors  (always CORNER, always BYTE_COLOR)

        Returns a list of (layer_obj, domain, data_type) tuples so callers
        don't need to branch on the API version.
        """
        if hasattr(mesh, 'color_attributes') and mesh.color_attributes:
            return [(a, a.domain, a.data_type) for a in mesh.color_attributes]
        if hasattr(mesh, 'vertex_colors') and mesh.vertex_colors:
            # Legacy API: MeshLoopColorLayer — always per-loop, byte color
            return [(vc, 'CORNER', 'BYTE_COLOR') for vc in mesh.vertex_colors]
        return []

    @staticmethod
    def _get_active_color_layer(mesh):
        """Return the active color layer object (version-compatible)."""
        if hasattr(mesh, 'color_attributes') and mesh.color_attributes:
            return mesh.color_attributes.active
        if hasattr(mesh, 'vertex_colors') and mesh.vertex_colors:
            return mesh.vertex_colors.active
        return None

    @staticmethod
    def _match_color_attributes(src_mesh, tgt_mesh):
        """
        Match color layers between source and target meshes.

        Priority:
        1. Exact name match
        2. (domain, data_type) structural match — distinguishes e.g. AO vs diffuse
        3. Active → active fallback

        Compatible with both color_attributes (Blender 3.2+) and the legacy
        vertex_colors API (Blender 2.93–3.1).

        Returns list of (src_layer, tgt_layer) tuples where each layer has
        .name and .data with a foreach_get/set("color") interface.
        """
        src_layers = MeshDataTransfer._get_color_layers(src_mesh)
        tgt_layers = MeshDataTransfer._get_color_layers(tgt_mesh)
        if not src_layers or not tgt_layers:
            return []

        matched  = []
        used_tgt = set()

        # Pass 1: exact name match
        for sa, sd, sdt in src_layers:
            for ti, (ta, td, tdt) in enumerate(tgt_layers):
                if sa.name == ta.name and ti not in used_tgt:
                    matched.append((sa, ta, sd, sdt))
                    used_tgt.add(ti)
                    break

        # Pass 2: domain + data_type structural match
        matched_src_names = {m[0].name for m in matched}
        for sa, sd, sdt in src_layers:
            if sa.name in matched_src_names:
                continue
            for ti, (ta, td, tdt) in enumerate(tgt_layers):
                if ti not in used_tgt and sd == td and sdt == tdt:
                    matched.append((sa, ta, sd, sdt))
                    used_tgt.add(ti)
                    break

        # Pass 3: active → active fallback
        if not matched:
            sa = MeshDataTransfer._get_active_color_layer(src_mesh)
            ta = MeshDataTransfer._get_active_color_layer(tgt_mesh)
            if sa and ta:
                # Determine domain/data_type from what API is available
                sd  = getattr(sa, 'domain',    'CORNER')
                sdt = getattr(sa, 'data_type', 'BYTE_COLOR')
                matched.append((sa, ta, sd, sdt))

        return matched

    def transfer_vertex_colors(self, report_matches=False):
        """
        Transfer vertex color attributes from source to target.

        Compatible with:
        - Blender 2.93–3.1: legacy mesh.vertex_colors (CORNER, BYTE_COLOR)
        - Blender 3.2–5.x:  mesh.color_attributes (POINT or CORNER, FLOAT or BYTE)

        CORNER domain: uses the shared loop interpolation pipeline (same as UVs
        and normals), giving barycentric-accurate per-corner color transfer.
        POINT domain: direct per-vertex barycentric interpolation.

        Matching: exact name → (domain, data_type) structural → active fallback.
        report_matches: if True returns (success, [report strings]).
        """
        src_mesh = self.source.obj.data
        tgt_mesh = self.target.obj.data

        src_layers = self._get_color_layers(src_mesh)
        tgt_layers = self._get_color_layers(tgt_mesh)
        if not src_layers:
            msg = "Source has no color layers"
            return (False, [msg]) if report_matches else False
        if not tgt_layers:
            msg = "Target has no color layers"
            return (False, [msg]) if report_matches else False

        attr_pairs = self._match_color_attributes(src_mesh, tgt_mesh)
        if not attr_pairs:
            msg = "No matching color layers found"
            return (False, [msg]) if report_matches else False

        ctx = self._build_loop_transfer_context()
        reports = []

        bary        = ctx['bary']
        has_mask    = ctx['has_mask']
        mask_flat   = ctx['mask_flat']
        tgt_v_count = ctx['tgt_v_count']

        for src_attr, tgt_attr, domain, data_type in attr_pairs:
            channels = 4   # RGBA — both old and new APIs give 4 floats via foreach_get
            how = "name" if src_attr.name == tgt_attr.name else "structural"
            reports.append(
                f"'{src_attr.name}' → '{tgt_attr.name}' "
                f"({domain}, {data_type}, matched by {how})")

            if domain == 'CORNER':
                src_lc = ctx['src_loop_count']
                tgt_lc = ctx['tgt_loop_count']

                src_flat = np.zeros(src_lc * channels, dtype=np.float32)
                src_attr.data.foreach_get("color", src_flat)
                src_data = src_flat.reshape((src_lc, channels))

                tgt_flat = np.zeros(tgt_lc * channels, dtype=np.float32)
                tgt_attr.data.foreach_get("color", tgt_flat)
                tgt_data = tgt_flat.reshape((tgt_lc, channels))

                interp   = self._interp_loop_data(ctx, src_data, channels)
                interp   = np.clip(interp, 0.0, 1.0)
                tgt_data = self._write_loop_data(ctx, interp, tgt_data, channels)
                tgt_attr.data.foreach_set("color", tgt_data.ravel())

            else:  # POINT domain (color_attributes 3.2+ only)
                src_vc = len(src_mesh.vertices)
                src_flat = np.zeros(src_vc * channels, dtype=np.float32)
                src_attr.data.foreach_get("color", src_flat)
                src_colors = src_flat.reshape((src_vc, channels))

                tgt_flat = np.zeros(tgt_v_count * channels, dtype=np.float32)
                tgt_attr.data.foreach_get("color", tgt_flat)
                tgt_colors = tgt_flat.reshape((tgt_v_count, channels))

                idx    = self.related_ids.astype(np.int32)
                interp = (bary[:, 0:1] * src_colors[idx[:, 0]] +
                          bary[:, 1:2] * src_colors[idx[:, 1]] +
                          bary[:, 2:3] * src_colors[idx[:, 2]])
                interp = np.clip(interp, 0.0, 1.0)

                if has_mask:
                    mv         = mask_flat.reshape(-1, 1)
                    tgt_colors = tgt_colors * (1.0 - mv) + interp * mv
                else:
                    tgt_colors = interp

                tgt_attr.data.foreach_set("color", tgt_colors.ravel())

        tgt_mesh.update()
        if report_matches:
            uv_lines = self._uv_transfer_report_lines()
            if uv_lines:
                reports = uv_lines + reports
        return (True, reports) if report_matches else True

    # ── topology reorder matching ─────────────────────────────────────────────

    @staticmethod
    def build_topology_remap(source_obj, target_obj):
        """
        Build a vertex index remap array for meshes that have identical topology
        but different vertex ordering — e.g. after export/import through different
        pipelines, or meshes processed by different tools.

        The approach:
        1. For each vertex, compute a geometric signature: the sorted set of
           edge-neighbor distances. This is topology-invariant and order-invariant.
        2. Build a KDTree on the source signatures.
        3. For each target vertex, find the source vertex whose signature matches.

        Returns: int32 array of shape (target_V,) where result[i] = source vert
                 index that corresponds to target vert i.
                 Returns None if meshes have different vert counts.

        Use transfer_with_topology_remap() to apply this to a full data transfer.
        """
        src_mesh = source_obj.data
        tgt_mesh = target_obj.data

        src_v = len(src_mesh.vertices)
        tgt_v = len(tgt_mesh.vertices)
        if src_v != tgt_v:
            return None

        def _build_signatures(mesh):
            v_count = len(mesh.vertices)
            # Read all vertex positions
            pos = np.zeros(v_count * 3, dtype=np.float64)
            mesh.vertices.foreach_get("co", pos)
            pos = pos.reshape((v_count, 3))

            # Read edge connectivity
            e_count = len(mesh.edges)
            edges = np.zeros(e_count * 2, dtype=np.int32)
            mesh.edges.foreach_get("vertices", edges)
            edges = edges.reshape((e_count, 2))

            # For each vertex: collect distances to all edge-connected neighbours
            # Sort them so the signature is order-invariant
            neighbour_dists = [[] for _ in range(v_count)]
            v0 = edges[:, 0]
            v1 = edges[:, 1]
            diffs = pos[v1] - pos[v0]
            dists = np.linalg.norm(diffs, axis=1)
            for i, (a, b, d) in enumerate(zip(v0, v1, dists)):
                neighbour_dists[a].append(d)
                neighbour_dists[b].append(d)

            # Pad signatures to fixed length for KDTree (max 16 neighbours)
            # Sorted ascending so KDTree distance is meaningful
            max_n = 16
            sigs = np.zeros((v_count, max_n), dtype=np.float64)
            for vi in range(v_count):
                nd = sorted(neighbour_dists[vi])[:max_n]
                sigs[vi, :len(nd)] = nd

            return sigs

        src_sigs = _build_signatures(src_mesh)
        tgt_sigs = _build_signatures(tgt_mesh)

        # Build KDTree on source signatures
        kd = kdtree.KDTree(src_v)
        for i, sig in enumerate(src_sigs):
            kd.insert(sig[:3], i)  # Use first 3 dims (edge dist sig) as 3D point
        kd.balance()

        # For each target vert, find matching source vert
        remap = np.zeros(tgt_v, dtype=np.int32)
        for ti in range(tgt_v):
            sig = tgt_sigs[ti, :3]
            _, src_idx, _ = kd.find(sig)
            remap[ti] = src_idx

        return remap

    def transfer_with_topology_remap(self, remap, attribute='VERTEX_GROUPS',
                                      normalize=False, threshold=0.01,
                                      delta_scale=1.0):
        """
        Transfer data using a pre-built topology remap (from build_topology_remap).
        Bypasses BVH entirely — pure index remap, much faster for reordered meshes.

        attribute: 'VERTEX_GROUPS', 'SHAPE_KEYS', or 'SHAPE'
        """
        if remap is None:
            return False

        if attribute == 'VERTEX_GROUPS':
            src_weights = self.source.get_vertex_groups_weights()
            group_names = self.source.get_vertex_groups_names()
            if src_weights is None or not group_names:
                return False
            # Remap: for each target vert i, take source vert remap[i]
            remapped = src_weights[:, remap]  # (G, V)
            if threshold > 0.0:
                remapped[remapped < threshold] = 0.0
            if normalize:
                weight_sum = remapped.sum(axis=0)
                nonzero = weight_sum > 0
                remapped[:, nonzero] /= weight_sum[nonzero]
            self.target.set_vertex_groups_weights(remapped, group_names)
            return True

        elif attribute == 'SHAPE':
            src_pos = self.source.get_verts_position()
            remapped = src_pos[remap]  # (V, 3)
            self.target.set_verts_position(remapped)
            return True

        elif attribute == 'SHAPE_KEYS':
            src_keys = self.source.get_shape_keys_vert_pos()
            if not src_keys:
                return False
            src_base = self.source.get_verts_position()
            tgt_base = self.target.get_verts_position()
            for sk_name, sk_pos in src_keys.items():
                remapped_sk = sk_pos[remap]
                remapped_base = src_base[remap]
                delta = (remapped_sk - remapped_base) * delta_scale
                final = tgt_base + delta
                self.target.set_position_as_shape_key(shape_key_name=sk_name, co=final)
                src_sk = self.source.shape_keys[sk_name]
                tgt_sk = self.target.shape_keys[sk_name]
                tgt_sk.slider_min = src_sk.slider_min
                tgt_sk.slider_max = src_sk.slider_max
                tgt_sk.mute = src_sk.mute
            self.target.obj.data.update()
            return True

        return False

    # ── driver transfer ───────────────────────────────────────────────────────

    @staticmethod
    def copy_f_curve(source, target):
        for mod in target.modifiers:
            target.modifiers.remove(mod)
        for mod in source.modifiers:
            copy = target.modifiers.new(mod.type)
            for prop in mod.bl_rna.properties:
                if not prop.is_readonly:
                    setattr(copy, prop.identifier, getattr(mod, prop.identifier))
        target.extrapolation = source.extrapolation
        target_keyframe_points = target.keyframe_points
        source_keyframe_points = source.keyframe_points
        target_keyframe_points.add(len(source_keyframe_points))
        for sk, tk in zip(source_keyframe_points, target_keyframe_points):
            tk.co = sk.co
            tk.interpolation = sk.interpolation
            tk.handle_left = sk.handle_left
            tk.handle_left_type = sk.handle_left_type
            tk.handle_right = sk.handle_right
            tk.handle_right_type = sk.handle_right_type

    def transfer_shape_keys_drivers(self):
        source_f_curves = self.source.shape_keys_drivers
        target_shape_keys_names = self.target.shape_keys_names
        for source_f_curve in source_f_curves:
            source_driver = source_f_curve.driver
            source_shape_key = '['.join(source_f_curve.data_path.split('[')[1:])
            source_shape_key = "]".join(source_shape_key.split("]")[:-1])[1:-1]
            source_shape_key = codecs.decode(source_shape_key, 'unicode_escape')
            if source_shape_key not in target_shape_keys_names:
                continue
            source_channel = source_f_curve.data_path.split(".")[-1]
            target_f_curve = self.target.shape_keys[source_shape_key].driver_add(source_channel)
            self.copy_f_curve(source_f_curve, target_f_curve)
            target_driver = target_f_curve.driver
            target_driver.type = source_driver.type
            for source_var in source_driver.variables:
                target_var = target_driver.variables.new()
                target_var.name = source_var.name
                target_var.type = source_var.type
                for i, source_var_target in source_var.targets.items():
                    target_var_target = target_var.targets[i]
                    src_id = source_var_target.id
                    if src_id == self.source.mesh.shape_keys:
                        src_id = self.target.mesh.shape_keys
                    if src_id == self.source_arm and self.target_arm:
                        src_id = self.target_arm
                    target_var_target.id_type = source_var_target.id_type
                    target_var_target.id = src_id
                    target_var_target.data_path = source_var_target.data_path
                    target_var_target.transform_type = source_var_target.transform_type
                    target_var_target.bone_target = source_var_target.bone_target
                    target_var_target.rotation_mode = source_var_target.rotation_mode
                    target_var_target.transform_space = source_var_target.transform_space
            target_driver.expression = source_driver.expression
        return True

    # ── debug ─────────────────────────────────────────────────────────────────

    @staticmethod
    def create_debug_mesh(obj, co, name):
        copy = obj.data.copy()
        new_obj = bpy.data.objects.new(name, copy)
        bpy.context.scene.collection.objects.link(new_obj)
        copy.vertices.foreach_set("co", co.ravel())
        obj.data.update()
        return new_obj
