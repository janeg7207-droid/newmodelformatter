import bpy
from bpy.types import PropertyGroup
from bpy.props import PointerProperty
from .operators import TransferShapeKeyDrivers, TransferMeshData, MapTopology, StoreShapeKeyReference, RecalculateShapeKeys

bl_info = {
    "name": "MeshDataTransfer",
    "author": "Maurizio Memoli",
    "description": "Transfer shape, UVs, normals, colors, shape keys, and vertex groups between "
                   "meshes via surface projection — closest, raycast, topology, or UV space. "
                   "Compatible with Blender 2.93–5.x.",
    "blender": (2, 93, 0),
    "version": (2, 5, 0),
    "location": "Properties > Object Data > Mesh Data Transfer",
    "category": "Mesh",
}


# ─────────────────────────────────────────────────────────────────────────────
# Poll helpers
# ─────────────────────────────────────────────────────────────────────────────

def _poll_mesh(self, obj):
    return obj != bpy.context.active_object and obj.type == 'MESH'

def _poll_armature(self, obj):
    return obj != bpy.context.active_object and obj.type == 'ARMATURE'

def _update_search_method(self, context):
    """Prevent UV search + UV transfer combination (meaningless)."""
    if self.search_method == 'UVS' and self.attributes_to_transfer == 'UVS':
        self.search_method = 'CLOSEST'


# ─────────────────────────────────────────────────────────────────────────────
# Property group
# ─────────────────────────────────────────────────────────────────────────────

class MeshDataSettings(PropertyGroup):

    # ── source ────────────────────────────────────────────────────────────────
    mesh_source: bpy.props.PointerProperty(
        name="Source Mesh",
        description="Mesh to transfer data from",
        type=bpy.types.Object,
        poll=_poll_mesh,
    )

    mesh_object_space: bpy.props.EnumProperty(
        name="Space",
        description="Coordinate space for the transfer",
        items=[
            ('LOCAL', 'Local', "Use local object space — meshes must be co-located", 'OBJECT_ORIGIN', 1),
            ('WORLD', 'World', "Use world space — works across differently placed objects", 'WORLD', 2),
        ],
        default='LOCAL',
    )

    transfer_modified_source: bpy.props.BoolProperty(
        name="Use Deformed Source",
        description="Sample the source mesh after modifiers and shape keys are applied",
        default=False,
    )

    # ── search method ─────────────────────────────────────────────────────────
    search_method: bpy.props.EnumProperty(
        name="Search Method",
        items=[
            ('CLOSEST',         'Closest',      "Nearest point on surface — best for same-body weight transfer",       'ARROW_LEFTRIGHT', 1),
            ('RAYCAST',         'Raycast',      "Bidirectional normal projection — best for shape transfer",           'PROP_PROJECTED',  2),
            ('TOPOLOGY',        'Vertex ID',    "1:1 vertex index match — requires identical vertex count",            'MESH_DATA',       3),
            ('UVS',             'Active UV',    "UV-space projection — best for same UV layout, different topo",       'UV_DATA',         4),
            ('VERTEX_ID_ORDER', 'Vert Order', "Smart topology remap for same-topology meshes with different vert order", 'SORTALPHA', 5),
        ],
        default='CLOSEST',
        update=_update_search_method,
    )

    # ── what to transfer ──────────────────────────────────────────────────────
    attributes_to_transfer: bpy.props.EnumProperty(
        name="Transfer",
        items=[
            ('SHAPE',         'Shape',         "Transfer vertex positions",                    'MOD_DATA_TRANSFER', 1),
            ('UVS',           'UVs',           "Transfer UV coordinates",                      'UV_DATA',           2),
            ('SHAPE_KEYS',    'Shape Keys',    "Transfer all shape keys",                      'SHAPEKEY_DATA',     3),
            ('VERTEX_GROUPS', 'Vertex Groups', "Transfer vertex group weights",                'GROUP_VERTEX',      4),
            ('NORMALS',       'Normals',       "Transfer custom split normals",                'SNAP_NORMAL',       5),
            ('VERTEX_COLORS', 'Colors',        "Transfer vertex color attributes (RGBA)",      'COLOR',             6),
        ],
        default='SHAPE',
        update=_update_search_method,
    )

    # ── mask / filter ─────────────────────────────────────────────────────────
    vertex_group_filter: bpy.props.StringProperty(
        name="Mask Group",
        description="Restrict transfer to vertices in this group (on target)",
    )
    invert_vertex_group_filter: bpy.props.BoolProperty(
        name="Invert Mask",
        description="Invert the vertex group mask",
        default=False,
    )
    transfer_edit_selection: bpy.props.BoolProperty(
        name="Selection Only",
        description="Only transfer to vertices selected in edit mode",
        default=False,
    )

    # ── shape options ─────────────────────────────────────────────────────────
    snap_to_closest_shape: bpy.props.BoolProperty(
        name="Snap to Closest Vertex",
        description="After projection, snap each transferred position to the nearest source vertex",
        default=False,
    )
    transfer_shape_as_key: bpy.props.BoolProperty(
        name="As Shape Key",
        description="Store the transferred shape as a shape key instead of applying directly",
        default=False,
    )
    shape_tangent_space: bpy.props.BoolProperty(
        name="Tangent Space",
        description="Decompose the positional delta in source surface frame and recompose in target "
                    "frame. Gives better results when source and target have different local "
                    "surface orientations at corresponding points",
        default=False,
    )

    # ── shape key options ─────────────────────────────────────────────────────
    snap_to_closest_shapekey: bpy.props.BoolProperty(
        name="Snap Shape Keys",
        description="Snap transferred shape key positions to nearest source vertex",
        default=False,
    )
    exclude_muted_shapekeys: bpy.props.BoolProperty(
        name="Skip Muted",
        description="Do not transfer shape keys that are muted on the source",
        default=False,
    )
    sk_prefix_filter: bpy.props.StringProperty(
        name="Prefix Filter",
        description="Only transfer shape keys whose name starts with this string (e.g. 'AU_' for FACS keys)",
    )
    sk_suffix_filter: bpy.props.StringProperty(
        name="Suffix Filter",
        description="Only transfer shape keys whose name ends with this string",
    )
    sk_create_missing_only: bpy.props.BoolProperty(
        name="Create Missing Only",
        description="Skip shape keys that already exist on the target — only add new ones",
        default=False,
    )
    sk_delta_scale: bpy.props.FloatProperty(
        name="Delta Scale",
        description="Scale all transferred deltas by this factor. "
                    "1.0 = full transfer, 0.5 = blend halfway, 0.0 = no change",
        default=1.0,
        min=0.0,
        max=2.0,
        step=10,
    )
    sk_use_deformation_transfer: bpy.props.BoolProperty(
        name="Deformation Transfer",
        description="Use gradient-based deformation transfer instead of barycentric interpolation. "
                    "Recalculates each shape key relative to the target mesh's actual surface "
                    "geometry — more accurate for meshes with different proportions. "
                    "Pure numpy, no additional dependencies needed",
        default=False,
    )
    sk_tangent_space: bpy.props.BoolProperty(
        name="Tangent Space",
        description="Decompose each shape key delta in the source surface frame and recompose in "
                    "the target frame. Substantially improves results for FACS/corrective shapes "
                    "on meshes with different local surface orientations",
        default=False,
    )

    # ── vertex group options ──────────────────────────────────────────────────
    exclude_locked_groups: bpy.props.BoolProperty(
        name="Skip Locked",
        description="Do not transfer vertex groups that are locked on the source",
        default=False,
    )
    vg_normalize: bpy.props.BoolProperty(
        name="Normalize",
        description="After transfer, normalize weights per vertex so they sum to 1.0. "
                    "Essential when porting skinning weights to a new skeleton",
        default=True,
    )
    vg_threshold: bpy.props.FloatProperty(
        name="Threshold",
        description="Zero out weights below this value to reduce noise from barycentric interpolation",
        default=0.01,
        min=0.0,
        max=0.5,
        step=1,
        precision=3,
    )

    # ── rigging helpers ───────────────────────────────────────────────────────
    arm_source: bpy.props.PointerProperty(
        name="Source Armature",
        description="Armature the source mesh is bound to (for driver transfer remapping)",
        type=bpy.types.Object,
        poll=_poll_armature,
    )
    arm_target: bpy.props.PointerProperty(
        name="Target Armature",
        description="Armature the target mesh is bound to",
        type=bpy.types.Object,
        poll=_poll_armature,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Panel
# ─────────────────────────────────────────────────────────────────────────────

class DATA_PT_mesh_data_transfer(bpy.types.Panel):
    bl_label = "Mesh Data Transfer"
    bl_idname = "MESH_PT_mesh_data_transfer"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'data'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'

    # ── internal helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _source_has_uvs(context):
        obj = context.active_object
        src = obj.mesh_data_transfer_object.mesh_source
        if not src:
            return False
        return bool(src.data.uv_layers.active) and bool(obj.data.uv_layers.active)

    @staticmethod
    def _vert_counts_match(context):
        obj = context.active_object
        src = obj.mesh_data_transfer_object.mesh_source
        if not src:
            return False
        return len(src.data.vertices) == len(obj.data.vertices)

    # ── draw ──────────────────────────────────────────────────────────────────

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        props = obj.mesh_data_transfer_object
        attr = props.attributes_to_transfer

        main = layout.box()

        # ── Search method ──────────────────────────────────────────────────
        search_box = main.box()
        search_box.label(text="Search Method", icon='VIEWZOOM')
        row = search_box.row(align=True)

        for item in props.bl_rna.properties['search_method'].enum_items_static:
            ident = item.identifier
            sub = row.row(align=True)
            if ident == 'TOPOLOGY':
                sub.enabled = self._vert_counts_match(context)
                sub.prop_enum(props, 'search_method', ident, text="Vertex ID")
            elif ident == 'VERTEX_ID_ORDER':
                sub.enabled = self._vert_counts_match(context)
                sub.prop_enum(props, 'search_method', ident, text="Vert Order")
            elif ident == 'UVS':
                sub.enabled = self._source_has_uvs(context) and attr != 'UVS'
                sub.prop_enum(props, 'search_method', ident)
            else:
                sub.prop_enum(props, 'search_method', ident)

        if props.search_method == 'UVS':
            search_box.label(text="UV space: ideal for same-UV layout transfer",
                             icon='INFO')
        elif props.search_method == 'VERTEX_ID_ORDER':
            search_box.label(text="Topology remap: same mesh, different vert order",
                             icon='INFO')

        # ── Attribute to transfer ──────────────────────────────────────────
        attr_box = main.box()
        attr_box.label(text="Attribute to Transfer", icon='MOD_DATA_TRANSFER')
        # 3-column grid so 6 items fit cleanly without overflow
        grid = attr_box.grid_flow(row_major=True, columns=3,
                                   even_columns=True, align=True)
        for item in props.bl_rna.properties['attributes_to_transfer'].enum_items_static:
            grid.prop_enum(props, 'attributes_to_transfer', item.identifier)

        # ── Contextual options per attribute ───────────────────────────────
        # Only show the Advanced section when there are actual options for this attribute
        has_opts = attr in ('SHAPE', 'SHAPE_KEYS', 'VERTEX_GROUPS', 'NORMALS', 'VERTEX_COLORS')
        if has_opts:
            opts_box = attr_box.box()
            opts_box.label(text="Advanced", icon='SETTINGS')
            opts = opts_box.column(align=True)
        else:
            opts = attr_box.column(align=True)

        if attr == 'SHAPE':
            row = opts.row(align=True)
            snap_icon = 'SNAP_ON' if props.snap_to_closest_shape else 'SNAP_OFF'
            row.prop(props, 'snap_to_closest_shape', text="Snap to Closest", icon=snap_icon, toggle=True)
            key_icon = 'SHAPEKEY_DATA'
            row.prop(props, 'transfer_shape_as_key', text="As Shape Key", icon=key_icon, toggle=True)
            ts_icon = 'SNAP_NORMAL' if props.shape_tangent_space else 'SNAP_NORMAL'
            row.prop(props, 'shape_tangent_space', text="Tangent Space", icon=ts_icon, toggle=True)
            if props.shape_tangent_space:
                opts.label(text="Delta corrected through surface tangent frames", icon='INFO')

        elif attr == 'SHAPE_KEYS':
            row = opts.row(align=True)
            snap_icon = 'SNAP_ON' if props.snap_to_closest_shapekey else 'SNAP_OFF'
            row.prop(props, 'snap_to_closest_shapekey', text="Snap", icon=snap_icon, toggle=True)
            mute_icon = 'HIDE_ON' if props.exclude_muted_shapekeys else 'HIDE_OFF'
            row.prop(props, 'exclude_muted_shapekeys', text="Skip Muted", icon=mute_icon, toggle=True)
            missing_icon = 'ADD' if props.sk_create_missing_only else 'FILE_REFRESH'
            row.prop(props, 'sk_create_missing_only', text="New Only", icon=missing_icon, toggle=True)

            opts.separator(factor=0.5)

            # Transfer mode: Barycentric vs Deformation Gradient
            mode_row = opts.row(align=True)
            mode_row.prop(props, 'sk_use_deformation_transfer',
                          text="Deformation Transfer", icon='DRIVER_TRANSFORM', toggle=True)
            if not props.sk_use_deformation_transfer:
                ts_icon = 'SNAP_NORMAL'
                mode_row.prop(props, 'sk_tangent_space', text="Tangent", icon=ts_icon, toggle=True)

            if props.sk_use_deformation_transfer:
                opts.label(text="Gradient-based: recalculates keys relative to target surface",
                           icon='INFO')
            opts.separator(factor=0.5)
            opts.prop(props, 'sk_delta_scale', slider=True)

            opts.separator(factor=0.5)
            filter_row = opts.row(align=True)
            filter_row.prop(props, 'sk_prefix_filter', icon='FILTER')
            filter_row.prop(props, 'sk_suffix_filter', icon='FILTER')
            if props.sk_prefix_filter or props.sk_suffix_filter:
                opts.label(text="Filtering active — only matching keys transferred", icon='INFO')

        elif attr == 'NORMALS':
            opts.label(text="Transfers custom split normals (shading normals)", icon='INFO')
            opts.label(text="UV search mode gives the most accurate result", icon='INFO')

        elif attr == 'VERTEX_COLORS':
            opts.label(text="Transfers all matched RGBA color attributes", icon='INFO')
            opts.label(text="Matched by name, then by domain + data type", icon='INFO')

        elif attr == 'VERTEX_GROUPS':
            row = opts.row(align=True)
            lock_icon = 'LOCKED' if props.exclude_locked_groups else 'UNLOCKED'
            row.prop(props, 'exclude_locked_groups', text="Skip Locked", icon=lock_icon, toggle=True)
            norm_icon = 'SNAP_NORMAL'
            row.prop(props, 'vg_normalize', text="Normalize", icon=norm_icon, toggle=True)

            opts.separator(factor=0.5)
            opts.prop(props, 'vg_threshold', slider=True)

            if props.vg_normalize:
                opts.label(text="Weights will sum to 1.0 per vertex after transfer", icon='INFO')

        # ── Source picker ──────────────────────────────────────────────────
        src_box = main.box()
        src_box.label(text="Source", icon='OBJECT_DATA')
        src_row = src_box.row(align=True)
        src_row.prop_search(props, 'mesh_source', context.scene, 'objects', text="")
        src_row.prop(props, 'mesh_object_space', text="", icon='WORLD', toggle=True)
        src_row.prop(props, 'transfer_modified_source', text="", icon='MOD_MESHDEFORM', toggle=True)

        if not props.mesh_source:
            src_box.label(text="Select a source mesh", icon='ERROR')

        # ── Mask ──────────────────────────────────────────────────────────
        mask_box = main.box()
        mask_box.label(text="Mask", icon='MOD_MASK')
        mask_row = mask_box.row(align=True)
        mask_row.prop_search(props, 'vertex_group_filter', obj, 'vertex_groups', text="")
        inv_icon = 'ARROW_LEFTRIGHT'
        mask_row.prop(props, 'invert_vertex_group_filter', text="", icon=inv_icon, toggle=True)

        # ── Transfer button ────────────────────────────────────────────────
        action_box = main.box()
        action_row = action_box.row(align=True)
        sel_icon = 'RESTRICT_SELECT_OFF' if props.transfer_edit_selection else 'RESTRICT_SELECT_ON'
        action_row.prop(props, 'transfer_edit_selection', text="", icon=sel_icon, toggle=True)
        action_row.operator('object.transfer_mesh_data',
                            text="Transfer Mesh Data",
                            icon='MOD_DATA_TRANSFER')

        # ── Rigging Helpers (collapsible) ──────────────────────────────────
        if bpy.app.version >= (4, 1, 0):
            header, panel = main.panel("mdt_rigging_helpers", default_closed=True)
            if header is not None:
                header.label(text="Rigging Helpers", icon='ARMATURE_DATA')
            if panel is not None:
                self._draw_rigging(panel, props)
        else:
            # Blender < 4.1: manual collapsible
            box = main.box()
            row = box.row()
            row.prop(obj, 'mdt_rigging_expanded',
                     icon='TRIA_DOWN' if obj.mdt_rigging_expanded else 'TRIA_RIGHT',
                     icon_only=True, emboss=False)
            row.label(text="Rigging Helpers", icon='ARMATURE_DATA')
            if obj.mdt_rigging_expanded:
                self._draw_rigging(box, props)

    def _draw_rigging(self, layout, props):
        layout.prop_search(props, 'arm_source', bpy.context.scene, 'objects',
                           text="Source Arm")
        layout.prop_search(props, 'arm_target', bpy.context.scene, 'objects',
                           text="Target Arm")
        layout.separator(factor=0.5)
        layout.operator('object.transfer_shape_key_drivers',
                        text="Transfer SK Drivers", icon='DRIVER')

        layout.separator(factor=0.8)
        layout.label(text="Recalculate Shape Keys", icon='SHAPEKEY_DATA')
        col = layout.column(align=True)
        col.operator('object.mdt_store_sk_reference',
                     text="Store Base Reference", icon='PINNED')
        col.operator('object.mdt_recalculate_shape_keys',
                     text="Recalculate to Base", icon='FILE_REFRESH')
        col.label(text="Store reference BEFORE editing base mesh", icon='INFO')


# ─────────────────────────────────────────────────────────────────────────────
# Registration
# ─────────────────────────────────────────────────────────────────────────────

classes = (
    MeshDataSettings,
    DATA_PT_mesh_data_transfer,
    TransferMeshData,
    TransferShapeKeyDrivers,
    MapTopology,
    StoreShapeKeyReference,
    RecalculateShapeKeys,
)


# register/unregister are per-class defensive: machines that ALSO run the
# standalone MeshDataTransfer addon register the same bl_idnames — Blender
# hands the idname to whichever copy registers last (auto-unregistering the
# other), so this module's class objects can end up unregistered through no
# fault of ours. An unguarded unregister then raised "missing bl_rna" and
# wedged addon_utils.enable's unregister-first path for the WHOLE addon.

def register():
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except Exception as e:
            print(f"[MeshDataTransfer] Failed to register {cls.__name__}: {e}")
    try:
        bpy.types.Object.mesh_data_transfer_object = PointerProperty(type=MeshDataSettings)
        # Fallback collapsible state for Blender < 4.1
        bpy.types.Object.mdt_rigging_expanded = bpy.props.BoolProperty(default=False)
    except Exception as e:
        print(f"[MeshDataTransfer] Failed to register object properties: {e}")


def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as e:
            print(f"[MeshDataTransfer] Failed to unregister {cls.__name__}: {e}")
    for prop in ("mesh_data_transfer_object", "mdt_rigging_expanded"):
        try:
            delattr(bpy.types.Object, prop)
        except Exception as e:
            print(f"[MeshDataTransfer] Failed to delete Object.{prop}: {e}")


if __name__ == "__main__":
    register()
