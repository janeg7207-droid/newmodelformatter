"""2K26 Material Export — per-material UI panel + custom-property registration.

This module owns two panels:

  * The Material Properties sub-panel that lets the user override the
    2K26 shader template/alpha/attire-scope/params per material. The
    properties live on bpy.types.Material as custom properties so they
    survive .blend save/load and roundtrips. Inference defaults (shown
    as a greyed-out "Auto" label) are computed live from the slot name
    via material_inference.infer_template().

  * The "2K26 Materials" overview panel in the 3D View sidebar
    (N-panel > MDL Tools, in Physics Swap's former slot): one row per
    material across the selected meshes — template dropdown + alpha
    toggle inline, the resolved auto-inference for review, and a
    "Set All Templates" batch operator. Same underlying material
    properties; this is a batch-visibility front-end, not new state.

Public API:
    register()    -> register the panel classes + five bpy.types.Material props
    unregister()  -> reverse of register()
    _self_test()  -> bench check, prints PASS / FAIL; safe outside Blender
"""

from functools import lru_cache

import bpy
from bpy.props import StringProperty, BoolProperty
try:
    from bpy.props import EnumProperty
except ImportError:  # lightweight test stubs created before this property existed
    EnumProperty = StringProperty
from bpy.types import Panel

from .material_inference import infer_template
from ...Link.log import derror


@lru_cache(maxsize=512)
def _cached_infer(name, is_environment=False):
    """Memoized infer_template for panel draw() paths.

    infer_template is pure (name -> tuple), but panel draws run on every
    UI redraw and the overview panel calls it once per material row —
    caching turns dozens of regex passes per redraw into dict hits.
    """
    return infer_template(name, is_environment=is_environment)


_TEMPLATE_CHOICES = (
    ("__AUTO__", "Auto from Slot + Export Path", "Character and arena-aware inference"),
    ("yCh_head::Normal", "Character - Head", "Standard basemodel head"),
    ("yCh_skin::Normal", "Character - Body / Skin", "Standard basemodel body"),
    ("yCh_eye::Normal", "Character - Eye", "Left or right eye"),
    ("yCh_head::Caruncle", "Character - Eye Caruncle", "Inner eye tissue"),
    ("yCh_eyeOv::Eyelash", "Character - Eyelash", "Eyelash overlay"),
    ("yCh_Teeth::Normal", "Character - Teeth", "Teeth material"),
    ("yCh_Teeth::Mouthbag", "Character - Mouthbag", "Mouth interior"),
    ("yCh_gear::Normal", "Attire - Standard Gear", "Clothing and accessories"),
    ("yCh_hair::NewHair_ColorChanging", "Character - Strand Hair", "Standard color-changing hair"),
    ("yCh_fur::Default", "Character / Attire - Fur", "Fur payload"),
    ("yCh_hairMesh::Default", "Character - Hair Mesh", "Mesh hair payload"),
    ("yCh_shellFur::Default", "Character / Attire - Shell Fur", "Shell-fur payload"),
    ("yPBR::t_BRDF", "Arena / Prop - Standard PBR", "General environment material"),
    ("yIllumination::t_Illumination", "Arena - Illumination", "Emissive arena material"),
    ("yIllumination::t_IlluminationMask", "Arena - Illumination Mask", "Masked emissive material"),
    ("yGlass::t_Translucency", "Arena / Prop - Glass", "Refractive glass"),
    ("yGlass::t_NewGlassNoRefract", "Arena / Prop - Glass (No Refraction)", "Non-refractive glass"),
    ("speedTree::Default", "Arena - Foliage / SpeedTree", "Trees and foliage"),
    ("Water::t_Water", "Arena - Water", "Water surface"),
    ("__CUSTOM__", "Custom Shader::Type", "Use the advanced text field below"),
)


# ═══════════════════════════════════════════════════════════════════════════
#  UI Panel
# ═══════════════════════════════════════════════════════════════════════════

class VC_2K26_MaterialPanel(Panel):
    bl_label = "2K26 Material Export"
    bl_idname = "MATERIAL_PT_vc_2k26_export"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "material"

    @classmethod
    def poll(cls, context):
        return context.material is not None

    def draw(self, context):
        mat = context.material
        layout = self.layout

        # Inference is purely informational — never written into the
        # custom props automatically. The user's override (when set)
        # wins downstream in write_materials_for_export.
        try:
            shader_byte, shader_name, type_name, is_alpha = _cached_infer(mat.name)
            inferred = f"{shader_name}::{type_name}"
        except Exception as e:
            inferred = "<inference failed>"
            is_alpha = False
            derror(f"[2K26 MatPanel] infer_template('{mat.name}') failed: {e}")

        # Same name, arena/prop context (export dialog Presets = Arena /
        # Prop / Weapon, or a save path under an Arena/Props/Weapons
        # folder). Shown only when it differs so character-only users
        # never see the extra line.
        env_inferred = None
        try:
            _b, env_shader, env_type, _a = _cached_infer(
                mat.name, is_environment=True)
            env_inferred = f"{env_shader}::{env_type}"
        except Exception as e:
            derror(f"[2K26 MatPanel] environment infer_template"
                   f"('{mat.name}') failed: {e}")

        col = layout.column()
        col.label(text=f"Auto (character): {inferred}", icon='INFO')
        if env_inferred and env_inferred != inferred:
            col.label(text=f"Auto (arena/prop): {env_inferred}", icon='WORLD')
        if is_alpha:
            col.label(text="(alpha variant)", icon='IMAGE_ALPHA')

        col.separator()
        col.prop(mat, "vc_2k26_template_choice", text="Export Template")
        choice = getattr(mat, "vc_2k26_template_choice", "__AUTO__")
        legacy = getattr(mat, "vc_2k26_template", "")
        if choice == "__CUSTOM__" or (choice == "__AUTO__" and legacy):
            col.prop(mat, "vc_2k26_template", text="Custom Shader::Type")
        col.prop(mat, "vc_2k26_alpha", text="Force Alpha Variant")
        col.prop(mat, "vc_2k26_attire_scope", text="Attire Scope")
        col.prop(mat, "vc_2k26_params", text="Extra Params (JSON)")


# ═══════════════════════════════════════════════════════════════════════════
#  3D-View sidebar overview (N-panel > MDL Tools)
# ═══════════════════════════════════════════════════════════════════════════

# Row cap for the overview: a 200-prop arena selection would otherwise
# produce an unusably tall panel and a slow redraw (draw() runs on every
# UI tick). Users narrow the selection to see the rest.
_MAX_OVERVIEW_ROWS = 40


def _selected_mesh_objects(context):
    """Selected mesh objects, falling back to the active mesh object."""
    objs = [o for o in (getattr(context, "selected_objects", None) or [])
            if o.type == 'MESH']
    if not objs:
        active = getattr(context, "active_object", None)
        if active is not None and active.type == 'MESH':
            objs = [active]
    return objs


def _iter_object_materials(obj):
    """Yield each unique material on obj's slots, in slot order."""
    seen = set()
    for slot in obj.material_slots:
        mat = slot.material
        if mat is None or mat.name in seen:
            continue
        seen.add(mat.name)
        yield mat


def _make_template_prop():
    """Build the batch operator's template EnumProperty.

    Wrapped so a stub-bpy import (self-tests outside Blender) degrades to
    a plain annotation value instead of a TypeError at class-body time.
    """
    try:
        return EnumProperty(
            name="Template",
            description="2K26 export template to assign",
            items=_TEMPLATE_CHOICES,
            default="__AUTO__",
        )
    except Exception:
        return None


class VCMODEL_OT_SetAll2K26Templates(bpy.types.Operator):
    """Set the 2K26 export template on every material of the selected meshes"""
    bl_idname = "vcmodel.set_all_2k26_templates"
    bl_label = "Set All 2K26 Templates"
    bl_options = {'REGISTER', 'UNDO'}

    template: _make_template_prop()

    @classmethod
    def poll(cls, context):
        return bool(_selected_mesh_objects(context))

    def execute(self, context):
        count = 0
        seen = set()
        for obj in _selected_mesh_objects(context):
            for mat in _iter_object_materials(obj):
                if mat.name in seen:
                    continue
                seen.add(mat.name)
                try:
                    mat.vc_2k26_template_choice = self.template
                    count += 1
                except Exception as e:
                    derror(f"[2K26 Materials] could not set template on "
                           f"'{mat.name}': {e}")
        self.report({'INFO'}, f"Set 2K26 template on {count} material(s)")
        return {'FINISHED'}


class VCMODEL_PT_MaterialsOverview(Panel):
    """Batch view of every 2K26 material template across the selection.

    Sits in Physics Swap's former 'MDL Tools' slot (bl_order 25). Rows
    edit the same bpy.types.Material custom properties as the Material
    Properties sub-panel — this is just the all-at-once front-end.
    """
    bl_label = "2K26 Materials"
    bl_idname = "VCMODEL_PT_MaterialsOverview"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'MDL Tools'
    bl_order = 25

    def draw_header(self, context):
        self.layout.label(text="", icon='MATERIAL')

    def draw(self, context):
        layout = self.layout
        objs = _selected_mesh_objects(context)
        if not objs:
            layout.label(text="Select mesh objects to list materials",
                         icon='INFO')
            return

        layout.operator_menu_enum(
            "vcmodel.set_all_2k26_templates", "template",
            text="Set All Templates", icon='MATERIAL')
        layout.separator(factor=0.4)

        rows = 0
        for obj in objs:
            mats = list(_iter_object_materials(obj))
            if not mats:
                continue
            col = layout.column(align=True)
            col.label(text=obj.name, icon='MESH_DATA')
            for mat in mats:
                if rows >= _MAX_OVERVIEW_ROWS:
                    layout.label(
                        text="More materials not shown — narrow the "
                             "selection", icon='COLLAPSEMENU')
                    return
                rows += 1
                self._draw_material_row(col, mat)
            layout.separator(factor=0.2)

    @staticmethod
    def _draw_material_row(col, mat):
        split = col.split(factor=0.38, align=True)
        split.label(text=mat.name)
        ctl = split.row(align=True)
        ctl.prop(mat, "vc_2k26_template_choice", text="")
        ctl.prop(mat, "vc_2k26_alpha", text="", icon='IMAGE_ALPHA',
                 toggle=True)

        # On Auto, show what the export will actually resolve to: an
        # importer-stamped legacy tag wins over name inference (mirrors
        # material_export._resolve_template's precedence).
        choice = getattr(mat, "vc_2k26_template_choice", "__AUTO__")
        if choice != "__AUTO__":
            return
        legacy = getattr(mat, "vc_2k26_template", "")
        if legacy:
            resolved = f"{legacy} (stamped)"
        else:
            try:
                _b, shader_name, type_name, _a = _cached_infer(mat.name)
                resolved = f"{shader_name}::{type_name}"
            except Exception:
                return
        sub = col.row()
        sub.active = False
        sub.label(text=f"      → {resolved}")


# ═══════════════════════════════════════════════════════════════════════════
#  Register / Unregister
# ═══════════════════════════════════════════════════════════════════════════

_CLASSES = (
    VC_2K26_MaterialPanel,
    VCMODEL_OT_SetAll2K26Templates,
    VCMODEL_PT_MaterialsOverview,
)


def _register_material_props():
    """Attach the five 2K26 custom properties to bpy.types.Material.

    Split out so _self_test can call it from a stub-Blender environment.
    """
    bpy.types.Material.vc_2k26_template_choice = EnumProperty(
        name="2K26 Export Template",
        description="Curated character, attire, and arena material template",
        items=_TEMPLATE_CHOICES,
        default="__AUTO__",
    )
    bpy.types.Material.vc_2k26_template = StringProperty(
        name="2K26 Template",
        description="Shader::Type (e.g. yCh_gear::Normal). Empty = auto-infer from slot name.",
        default="",
    )
    bpy.types.Material.vc_2k26_alpha = BoolProperty(
        name="Alpha Variant",
        description="Use alpha-blend variant of the template (for transparent gear, eyelashes, hair)",
        default=False,
    )
    bpy.types.Material.vc_2k26_attire_scope = StringProperty(
        name="Attire Scope",
        description="Override folder suffix (e.g. 'casual'). Empty = default Materials/ folder.",
        default="",
    )
    bpy.types.Material.vc_2k26_params = StringProperty(
        name="Param Overrides",
        description="JSON dict of per-template parameter overrides. Leave empty to use template defaults.",
        default="{}",
    )


def _unregister_material_props():
    for prop_name in ("vc_2k26_template_choice", "vc_2k26_template", "vc_2k26_alpha",
                      "vc_2k26_attire_scope", "vc_2k26_params"):
        if hasattr(bpy.types.Material, prop_name):
            try:
                delattr(bpy.types.Material, prop_name)
            except Exception as e:
                derror(f"[2K26 MatPanel] Failed to delete {prop_name}: {e}")


def register():
    for cls in _CLASSES:
        try:
            bpy.utils.register_class(cls)
        except Exception as e:
            derror(f"[2K26 MatPanel] Failed to register {cls.__name__}: {e}")
    _register_material_props()


def unregister():
    _unregister_material_props()
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as e:
            derror(f"[2K26 MatPanel] Failed to unregister {cls.__name__}: {e}")


# ═══════════════════════════════════════════════════════════════════════════
#  Self-test
# ═══════════════════════════════════════════════════════════════════════════

def _self_test():
    """Verify the five custom properties register on bpy.types.Material. Runnable in
    Blender or a stub-bpy CPython process (descriptors attach as bare attributes).
    """
    print("[2K26 MatPanel] self-test starting...")

    expected = ("vc_2k26_template_choice", "vc_2k26_template", "vc_2k26_alpha",
                "vc_2k26_attire_scope", "vc_2k26_params")

    # Reaching here means bpy is available in some form (real Blender, fake-bpy, or
    # the test stub) — a headless `import bpy` would already have failed at module top.
    try:
        _register_material_props()
    except Exception as e:
        print(f"[2K26 MatPanel] FAIL: _register_material_props raised: {e}")
        return False

    missing = [p for p in expected if not hasattr(bpy.types.Material, p)]
    if missing:
        print(f"[2K26 MatPanel] FAIL: missing props after register: {missing}")
        return False

    print("[2K26 MatPanel] PASS: all five custom properties registered.")
    return True


if __name__ == "__main__":
    _self_test()
