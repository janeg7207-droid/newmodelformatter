import bpy
import bmesh
from mathutils import Vector, kdtree
import json
import os
import time
import numpy as np
from ...Link.log import dlog, derror

# ═══════════════════════════════════════════════════════════════════════════
#  FLAGS PERSISTENCE
# ═══════════════════════════════════════════════════════════════════════════

flags_file_path = os.path.join(bpy.utils.user_resource('CONFIG'), "stored_flags.json")
stored_flags = {}

def save_flags_to_file():
    with open(flags_file_path, 'w') as file:
        json.dump(stored_flags, file, indent=4)

def load_flags_from_file():
    global stored_flags
    if os.path.exists(flags_file_path):
        try:
            with open(flags_file_path, 'r') as file:
                stored_flags = json.load(file)
        except (OSError, json.JSONDecodeError):
            # Corrupt/unreadable file — start clean (UI shows "(No Presets)").
            # Silent: runs at register time, don't spam the console.
            stored_flags = {}
    # Always rebuild the items cache (even on the empty path, so the placeholder
    # exists for the first UI draw).
    _rebuild_flag_enum_items_cache()


# ═══════════════════════════════════════════════════════════════════════════
#  SCENE FLAG LOGIC
# ═══════════════════════════════════════════════════════════════════════════

def update_appearance_flag(self, context):
    if self.entrance_only:     setattr(self, "appearance_flag", 129)
    elif self.ring_only:       setattr(self, "appearance_flag", 130)
    elif self.all_scenes:      setattr(self, "appearance_flag", 128)
    elif self.other:           setattr(self, "appearance_flag", self.other_value)

def isolateValue(self, context, type):
    if not self.update: return None
    for prop_name in dir(self):
        prop = getattr(self, prop_name)
        if isinstance(prop, bool) and prop_name != type: setattr(self, prop_name, False)
        if isinstance(prop, bool) and prop_name == type: setattr(self, type, True)

def update_model_name_string(self, context, type):
    obj = bpy.context.view_layer.objects.active
    if not obj or obj.type != 'MESH': return
    meshName = obj.name.replace("!", "").replace("$", "")
    if self.ring_only:      obj.name = meshName + "$"
    if self.entrance_only:  obj.name = meshName + "!"
    if self.all_scenes:     obj.name = meshName

def update_values(self, context, type):
    if self.update: return None
    self.update = True
    isolateValue(self, context, type)
    update_appearance_flag(self, context)
    update_model_name_string(self, context, type)
    self.update = False

def update_custom_value(self, context):
    update_values(self, context, "other")
    setattr(self, "appearance_flag", self.other_value)

# ─── flag_options EnumProperty items cache ────────────────────────────────
# Dynamic EnumProperty callbacks have a documented gotcha: Python MUST keep a
# reference to the returned strings or Blender crashes. Building a fresh tuple list
# per call let the (id,name,desc) strings get GC'd; the next redraw dereferenced
# freed memory translating the stored int back to a label → pyrna_enum_to_py warning
# + EXCEPTION_ACCESS_VIOLATION. A module-level cache, rebuilt IN PLACE (same list
# object — Blender may hold a pointer to it) on every stored_flags change, fixes it.
_flag_enum_items_cache = [("__none__", "(No Presets)", "Save a flag preset first")]


def _rebuild_flag_enum_items_cache():
    """Refresh _flag_enum_items_cache from stored_flags in place.

    Must be called after any mutation to stored_flags (load/store/remove).
    The list is mutated — not replaced — so Blender-side pointers into
    the Python object remain valid.
    """
    _flag_enum_items_cache.clear()
    for desc in stored_flags.keys():
        _flag_enum_items_cache.append((desc, desc, ""))
    if not _flag_enum_items_cache:
        # Dynamic callbacks MUST return >=1 item — an empty list falls back to value 0,
        # which matches no enum and spams pyrna_enum_to_py per redraw per mesh.
        _flag_enum_items_cache.append(
            ("__none__", "(No Presets)", "Save a flag preset first"))


def get_enum_items(self, context):
    # Return the cached list directly, not a copy (see _flag_enum_items_cache).
    # Callers must not mutate it.
    return _flag_enum_items_cache


# ═══════════════════════════════════════════════════════════════════════════
#  PROPERTY GROUPS
# ═══════════════════════════════════════════════════════════════════════════

class MDLProperties(bpy.types.PropertyGroup):
    """Extended scene-flag properties — overrides the base group with preset support."""
    def update_bool_properties(self):
        self.entrance_only = (self.appearance_flag == 129)
        self.ring_only     = (self.appearance_flag == 130)
        self.all_scenes    = (self.appearance_flag == 128)
        self.other         = (self.appearance_flag == 131)

    update: bpy.props.BoolProperty(name="Appearance Flag", default=False)
    appearance_flag: bpy.props.IntProperty(name="Appearance Flag", default=128)
    sub_flag: bpy.props.IntProperty(name="Sub Flag", default=-1)
    other_value: bpy.props.IntProperty(default=0, update=update_custom_value)
    entrance_only: bpy.props.BoolProperty(name="Entrance Only", default=False,
        update=lambda self, context: update_values(self, context, "entrance_only"))
    ring_only: bpy.props.BoolProperty(name="Ring Only", default=False,
        update=lambda self, context: update_values(self, context, "ring_only"))
    all_scenes: bpy.props.BoolProperty(name="All Scenes", default=False,
        update=lambda self, context: update_values(self, context, "all_scenes"))
    other: bpy.props.BoolProperty(name="Other", default=False,
        update=lambda self, context: update_values(self, context, "other"))
    title: bpy.props.StringProperty(name="Title", default="")
    flag_options: bpy.props.EnumProperty(name="Stored Flags",
        description="Select a stored flag configuration", items=get_enum_items)
    show_flag_management: bpy.props.BoolProperty(name="Show Flag Management", default=False)

    def store_current_flags(self, context, title):
        obj = context.object
        if obj and obj.type == 'MESH':
            stored_flags[title] = {
                "appearance_flag": self.appearance_flag, "sub_flag": self.sub_flag,
                "other_value": self.other_value, "entrance_only": self.entrance_only,
                "ring_only": self.ring_only, "all_scenes": self.all_scenes, "other": self.other}
            save_flags_to_file(); _rebuild_flag_enum_items_cache()

    def apply_stored_flags(self, context, title):
        obj = context.object
        if obj and obj.type == 'MESH' and title in stored_flags:
            flags = stored_flags[title]
            self.appearance_flag = flags["appearance_flag"]; self.sub_flag = flags["sub_flag"]
            self.other_value = flags["other_value"]; self.entrance_only = flags["entrance_only"]
            self.ring_only = flags["ring_only"]; self.all_scenes = flags["all_scenes"]
            self.other = flags["other"]

    # NOTE: don't write `self["flag_options"] = [tuples]` — flag_options is an
    # EnumProperty whose stored value is a single int/identifier, not item tuples;
    # writing a list corrupts its state (contributed to pyrna_enum_to_py warnings).
    # Preset-list refresh lives in _rebuild_flag_enum_items_cache().


class HPLMaskObjectCollection(bpy.types.PropertyGroup):
    use_object: bpy.props.BoolProperty(name="Use", description="Use this object for HPL masking", default=True)
    name: bpy.props.StringProperty(name="Name", default="")

class HPLOptionsProperties(bpy.types.PropertyGroup):
    expand_hpl_options: bpy.props.BoolProperty(name="Expand HPL Options", default=False)


# ═══════════════════════════════════════════════════════════════════════════
#  OPERATORS
# ═══════════════════════════════════════════════════════════════════════════

class STORE_OT_FlagsOperator(bpy.types.Operator):
    bl_idname = "mdl.store_flags"
    bl_label = "Store Preset"
    bl_description = "Save the current flag configuration as a named preset"
    def execute(self, context):
        context.object.mdl_properties.store_current_flags(context, context.object.mdl_properties.title)
        return {'FINISHED'}

class APPLY_OT_FlagsOperator(bpy.types.Operator):
    bl_idname = "mdl.apply_flags"
    bl_label = "Apply"
    bl_description = "Apply the selected flag preset to the active object"
    def execute(self, context):
        context.object.mdl_properties.apply_stored_flags(context, context.object.mdl_properties.flag_options)
        return {'FINISHED'}

class REMOVE_OT_FlagsOperator(bpy.types.Operator):
    bl_idname = "mdl.remove_flags"
    bl_label = "Remove"
    bl_description = "Delete the selected flag preset"
    def execute(self, context):
        selected_flag = context.object.mdl_properties.flag_options
        if selected_flag in stored_flags:
            del stored_flags[selected_flag]; save_flags_to_file()
            _rebuild_flag_enum_items_cache()
        return {'FINISHED'}

class TransferWeightsOperator(bpy.types.Operator):
    bl_idname = "object.transfer_weights_operator"
    bl_label = "Transfer Weights"
    bl_description = "Transfer vertex weights from the active object to all other selected objects"
    def execute(self, context):
        selected_objects = bpy.context.selected_objects
        if len(selected_objects) < 2:
            self.report({'ERROR'}, "Please select at least two objects."); return {'CANCELLED'}
        source_object = bpy.context.active_object
        method = getattr(context.scene, 'mdl_weight_search_method', 'AUTO')
        for target_object in [obj for obj in selected_objects if obj != source_object]:
            if method == 'AUTO':
                ok = transfer_weights_blender_native(source_object, target_object)
                if ok:
                    cleanup_vertex_weights(target_object, normalize=True, threshold=0.01)
                    parent_to_armature(source_object, [target_object])
            else:
                ok = transfer_weights_mdt(source_object, target_object, search_method=method)
                if ok:
                    parent_to_armature(source_object, [target_object])
        return {'FINISHED'}

class HeatSeekRiggingOperator(bpy.types.Operator):
    bl_idname = "object.heat_seek_rigging_operator"
    bl_label = "Heat Seek Rigging"
    bl_description = "Auto-rig all unweighted meshes using the active object as source"
    def execute(self, context):
        source_object = context.active_object
        if source_object is None or source_object.type != 'MESH':
            self.report({'ERROR'}, "Please select a mesh object as the source."); return {'CANCELLED'}
        method = getattr(context.scene, 'mdl_weight_search_method', 'AUTO')
        destination_objects = [obj for obj in bpy.data.objects
                                if obj.type == 'MESH' and not obj.vertex_groups
                                and obj != source_object]
        heat_seek_rigging(source_object, destination_objects, search_method=method)
        return {'FINISHED'}

class OBJECT_OT_AddToHPLMask(bpy.types.Operator):
    bl_idname = "object.add_to_hpl_mask"
    bl_label = "Add Selected"
    bl_description = "Add selected meshes to the HPL masking list"
    def execute(self, context):
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not selected_objects:
            self.report({'WARNING'}, "No mesh objects selected"); return {'CANCELLED'}
        for obj in selected_objects:
            if not any(item.name == obj.name for item in context.scene.hpl_mask_objects):
                item = context.scene.hpl_mask_objects.add(); item.name = obj.name
        return {'FINISHED'}

class OBJECT_OT_RemoveFromHPLMask(bpy.types.Operator):
    bl_idname = "object.remove_from_hpl_mask"
    bl_label = "Remove Selected"
    bl_description = "Remove selected objects from the HPL masking list"
    def execute(self, context):
        selected_objects = context.selected_objects
        if not selected_objects:
            self.report({'WARNING'}, "No objects selected"); return {'CANCELLED'}
        to_remove = [i for i, item in enumerate(context.scene.hpl_mask_objects) if item.name in [obj.name for obj in selected_objects]]
        for i in sorted(to_remove, reverse=True): context.scene.hpl_mask_objects.remove(i)
        return {'FINISHED'}

class OBJECT_OT_RemoveSpecificHPLObject(bpy.types.Operator):
    bl_idname = "object.remove_specific_hpl_object"
    bl_label = "Remove"
    bl_description = "Remove this object from the HPL masking list"
    index: bpy.props.IntProperty()
    def execute(self, context):
        context.scene.hpl_mask_objects.remove(self.index); return {'FINISHED'}

class SetObjectsToCenterOfMassOperator(bpy.types.Operator):
    bl_idname = "object.set_objects_to_center_of_mass"
    bl_label = "Set Objects to Center of Mass"
    def execute(self, context): return {'FINISHED'}

class OBJECT_OT_ApplyHPLFromAttire(bpy.types.Operator):
    """Apply HPL masking data from a loaded attire onto baseModel meshes"""
    bl_idname = "object.apply_hpl_from_attire"
    bl_label = "Apply HPL to BaseModel"
    bl_description = "Read HPL masking from the loaded attire and create HPL_Ring / HPL_Entrance vertex groups on M_Head and M_Body"
    def execute(self, context):
        from ...Serialize.hpl_roundtrip import (extract_hpl_data, apply_hpl_to_basemodel, find_basemodel_meshes)
        base_meshes = find_basemodel_meshes()
        if not base_meshes:
            self.report({'ERROR'}, "No M_Head or M_Body found. Import the baseModel first.")
            return {'CANCELLED'}
        hpl_data, source_desc = extract_hpl_data()
        if not hpl_data:
            self.report({'ERROR'}, "No HPL found in any loaded attire. Make sure an attire MCD is imported.")
            return {'CANCELLED'}
        success, message = apply_hpl_to_basemodel(hpl_data)
        if success:
            self.report({'INFO'}, f"{message} (from {source_desc})")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, message)
            return {'CANCELLED'}

class OBJECT_OT_GenerateEmptyHPL(bpy.types.Operator):
    """Create empty HPL vertex groups on M_Head and M_Body so export generates a zero-mask HPL"""
    bl_idname = "object.generate_empty_hpl"
    bl_label = "Generate Empty HPL"
    bl_description = "Creates HPL_Ring and HPL_Entrance vertex groups with no vertices on the active baseModel's M_Head and M_Body, and removes any leftover HPL_ groups from other meshes"
    def execute(self, context):
        # Same disambiguation the export read uses, so this and the export agree on
        # WHICH baseModel — else empty groups land on every M_Body/M_Head datablock
        # (stale duplicates included) and a populated leftover leaks into export.
        from ...Serialize.hpl_roundtrip import find_basemodel_meshes
        basemodel = find_basemodel_meshes()
        target_objs = list(basemodel.values())

        if not target_objs:
            self.report({'ERROR'}, "No M_Head or M_Body baseModel found in scene")
            return {'CANCELLED'}

        created = []
        for obj in target_objs:
            for vg_name in ('HPL_Ring', 'HPL_Entrance'):
                vg = obj.vertex_groups.get(vg_name)
                if vg:
                    obj.vertex_groups.remove(vg)
                obj.vertex_groups.new(name=vg_name)
            mesh_label = obj.data.name
            if '.' in mesh_label:
                mesh_label = mesh_label.rsplit('.', 1)[0]
            created.append(f"{mesh_label} ({obj.name})")

        # Sweep stray HPL_Ring/HPL_Entrance groups off other meshes. Export ignores
        # them anyway, but this keeps the vertex-group panel honest ("Generate Empty
        # HPL == no HPL anywhere") so a stale duplicate doesn't confuse the user.
        target_ids = {id(o) for o in target_objs}
        swept = []
        for obj in bpy.data.objects:
            if obj.type != 'MESH' or id(obj) in target_ids:
                continue
            removed_any = False
            for vg_name in ('HPL_Ring', 'HPL_Entrance'):
                vg = obj.vertex_groups.get(vg_name)
                if vg:
                    obj.vertex_groups.remove(vg)
                    removed_any = True
            if removed_any:
                swept.append(obj.name)

        # Force a view-layer update so the panel and any subsequent
        # export read see the post-operation state immediately.
        try:
            context.view_layer.update()
        except Exception:
            pass

        msg = f"Empty HPL groups created on {', '.join(created)}"
        if swept:
            msg += f" (cleaned stale HPL groups from {len(swept)} other mesh{'es' if len(swept) != 1 else ''})"
        self.report({'INFO'}, msg)
        return {'FINISHED'}

class AutoHPLMaskBooleanOperator(bpy.types.Operator):
    """Generate HPL mask using boolean intersection and proximity"""
    bl_idname = "object.auto_hpl_mask_boolean_operator"
    bl_label = "Generate HPL Mask"
    def execute(self, context):
        if context.mode != 'OBJECT' and context.view_layer.objects.active:
            try: bpy.ops.object.mode_set(mode='OBJECT')
            except: pass
        selected_objects = context.selected_objects
        # Resolve body/head candidates, two-pass: (1) find_basemodel_meshes (clean
        # imports, split-by-material renames, visibility filter); (2) a widened scan
        # for EVERY visible piece — split-by-material makes N M_Body chunks but the
        # resolver returns only the top one, and HPL Mask needs them all.
        body_objs = []
        seen_ids = set()
        try:
            from ...Serialize.hpl_roundtrip import find_basemodel_meshes
            for obj in find_basemodel_meshes().values():
                if obj.type == 'MESH' and id(obj) not in seen_ids:
                    body_objs.append(obj); seen_ids.add(id(obj))
        except Exception as e:
            dlog(f"[HPL Mask] find_basemodel_meshes raised: {e} — using name fallback only")
        # Widened scan — any one of three signals suffices: object-name (case-insensitive,
        # catches 'body:skinned' and canonical M_Body), data.name root (multi-piece bodies
        # sharing M_Body data), or a body:/head: material name.
        for obj in context.visible_objects:
            if obj.type != 'MESH' or id(obj) in seen_ids:
                continue
            data_root = obj.data.name
            if '.' in data_root:
                data_root = data_root.rsplit('.', 1)[0]
            obj_name_low = obj.name.lower()
            mat_signal = any(
                slot.material
                and slot.material.name.lower().startswith(('body:', 'head:'))
                for slot in obj.material_slots
            )
            if (data_root in ('M_Head', 'M_Body')
                    or obj_name_low.startswith(('body', 'head', 'm_body', 'm_head'))
                    or mat_signal):
                body_objs.append(obj); seen_ids.add(id(obj))
        dlog(f"[HPL Mask] Operator start — visible objects: {len(context.visible_objects)}, "
              f"selected: {len(selected_objects)}, body/head candidates found: {len(body_objs)} "
              f"({[o.name for o in body_objs]})")
        if not body_objs:
            self.report({'ERROR'}, "No body or head objects found."); return {'CANCELLED'}
        use_solidify_helper = len(context.scene.hpl_mask_objects) > 0
        dlog(f"[HPL Mask] Solidify helper list has {len(context.scene.hpl_mask_objects)} "
              f"entries -> using {'helper' if use_solidify_helper else 'selection'} mode")
        if use_solidify_helper:
            clothing_candidates = [bpy.data.objects.get(item.name) for item in context.scene.hpl_mask_objects if item.use_object]
            clothing_candidates = [obj for obj in clothing_candidates if obj and obj.type == 'MESH']
            solidify_objs = [obj for obj in clothing_candidates if obj not in body_objs]
            clothing_objs = [obj for obj in selected_objects if obj.type == 'MESH' and obj not in body_objs] if selected_objects else solidify_objs
            if not clothing_objs:
                self.report({'ERROR'}, "Select clothing or add to Solidify Helper."); return {'CANCELLED'}
            original_active = context.view_layer.objects.active
            original_selected = list(context.selected_objects)
            original_mode = context.mode
            try:
                applied_modifiers = apply_solidify_to_clothing(context, body_objs, clothing_objs)
                if all(obj.type == 'MESH' for obj in body_objs + clothing_objs):
                    boolean_intersect_and_select(body_objs, clothing_objs, proximity_threshold=context.scene.proximity_threshold, create_entrance=context.scene.create_entrance, create_ring=context.scene.create_ring)
                else: self.report({'ERROR'}, "All objects must be meshes."); return {'CANCELLED'}
                remove_solidify_modifiers(applied_modifiers)
                self.report({'INFO'}, "HPL masking completed")
            except Exception as e:
                self.report({'ERROR'}, f"Error: {str(e)}"); import traceback; traceback.print_exc(); return {'CANCELLED'}
            finally:
                try:
                    if context.active_object and context.active_object.mode != 'OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
                    bpy.ops.object.select_all(action='DESELECT')
                    for obj in original_selected:
                        if obj and obj.name in bpy.data.objects: obj.select_set(True)
                    if original_active and original_active.name in bpy.data.objects: context.view_layer.objects.active = original_active
                    if original_mode == 'EDIT_MESH' and context.active_object:
                        try: bpy.ops.object.mode_set(mode='EDIT')
                        except: pass
                except: pass
        else:
            clothing_objs = [obj for obj in selected_objects if obj.type == 'MESH' and obj not in body_objs]
            if not clothing_objs:
                self.report({'ERROR'}, "Select at least one clothing object."); return {'CANCELLED'}
            if all(obj.type == 'MESH' for obj in body_objs + clothing_objs):
                boolean_intersect_and_select(body_objs, clothing_objs, proximity_threshold=context.scene.proximity_threshold, create_entrance=context.scene.create_entrance, create_ring=context.scene.create_ring)
            else: self.report({'ERROR'}, "All objects must be meshes."); return {'CANCELLED'}
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════════
#  UTILITY FUNCTIONS  (unchanged from original)
# ═══════════════════════════════════════════════════════════════════════════

def apply_solidify_to_clothing(context, body_objects, clothing_objects):
    scene = context.scene; applied_modifiers = []; wm = context.window_manager
    wm.progress_begin(0, len(clothing_objects))
    try:
        for i, obj in enumerate(clothing_objects):
            wm.progress_update(i)
            if context.view_layer.objects.active: bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT'); context.view_layer.objects.active = obj
            mod = next((m for m in obj.modifiers if m.type == 'SOLIDIFY'), None)
            if not mod: mod = obj.modifiers.new(name="HPL_Solidify", type='SOLIDIFY'); applied_modifiers.append((obj, mod.name))
            mod.thickness = scene.hpl_solidify_thickness; mod.offset = scene.hpl_solidify_offset
            if hasattr(mod, 'thickness_clamp'):
                mod.thickness_clamp = {'FIXED': 0.0, 'EVEN': 1.0, 'MINIMUM': 2.0}.get(scene.hpl_solidify_thickness_mode, 0.0)
            if hasattr(mod, 'merge_threshold'): mod.merge_threshold = scene.hpl_solidify_merge_value
            elif hasattr(mod, 'threshold'): mod.threshold = scene.hpl_solidify_merge_value
            if hasattr(mod, 'use_rim'): mod.use_rim = scene.hpl_solidify_fill
            if hasattr(mod, 'use_rim_only'): mod.use_rim_only = scene.hpl_solidify_only_rim
            if hasattr(mod, 'solidify_mode'): mod.solidify_mode = scene.hpl_solidify_mode
            if hasattr(mod, 'boundary_mode') and mod.boundary_mode in {'NONE', 'FILL', 'ROUND'}: mod.boundary_mode = 'NONE'
    finally: wm.progress_end()
    return applied_modifiers

def remove_solidify_modifiers(applied_modifiers):
    for obj, mod_name in applied_modifiers:
        if obj.name in bpy.data.objects and mod_name in obj.modifiers: obj.modifiers.remove(obj.modifiers[mod_name])

def remove_shape_keys(obj):
    # obj.shape_key_clear() = shape_key_remove(all=True) without the operator
    # dispatcher (no active-object context, no depsgraph tick / viewport refresh).
    # Available since 2.75; callers reassign active right after, so the operator's
    # active-object side-effect wasn't relied on.
    if obj and obj.data.shape_keys:
        try:
            obj.shape_key_clear()
        except Exception:
            # Defensive fallback if the data API refuses (shouldn't happen).
            try:
                key_blocks = obj.data.shape_keys.key_blocks
                while key_blocks:
                    obj.shape_key_remove(key_blocks[0])
            except Exception:
                pass

def boolean_intersect_and_select(body_objs, clothing_objs, proximity_threshold=0.0, create_entrance=True, create_ring=True):
    """Determine which body vertices are covered by clothing.

    A per-body KDTree over the original verts (built once) drives both passes, so
    every candidate resolves straight to a body vertex INDEX (no coordinate-equality).

    Two passes:
      1. BOOLEAN INTERSECT — per (body, clothing): duplicate both, run a real
         BOOLEAN/INTERSECT on the duplicate body, resolve each surviving vert to its
         nearest original body vert (within a coincidence epsilon). Duplicates' shape
         keys are stripped first so the modifier sees clean topology.
      2. PROXIMITY (when proximity_threshold > 0) — each clothing vert whose nearest
         body vert is within threshold AND whose normal points toward it includes
         that body vert.
    Collected indices → HPL_Entrance / HPL_Ring groups on each body.

    Why KDTree-nearest, not float equality: an earlier BVH-ray rewrite under-reached
    (0.05 ray < solidify thickness → empty masks), and the restored boolean core
    matched with EXACT float equality — but Blender's EXACT solver (default since 2.90)
    re-emits via exact-arithmetic and converts back to float32, so passthrough verts
    drift a few ULPs on 4.x and matches were silently dropped. Nearest-within-epsilon
    fixes it and drops a redundant coord-set + full-body rescan.

    The final viewport-selection uses bmesh.from_edit_mesh + direct .select (the
    vertex_group_set_active + vertex_group_select ops chain silently breaks on 4.0+).
    """
    start_time = time.time()

    wm = bpy.context.window_manager
    total_steps = max(1, len(body_objs) * max(1, len(clothing_objs)) * 2)
    wm.progress_begin(0, total_steps)
    progress_counter = 0

    try:
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass

        # Coincidence epsilon for mapping a boolean-result vert back to its ORIGINAL
        # body vert (see docstring: EXACT solver float32 drift ~1e-4). Stays far below
        # body vertex spacing (~0.05+), so genuinely-new cut-boundary verts are still
        # excluded ("interior verts only").
        COINCIDENCE_EPS = 1e-3

        # Per-body KDTree over the ORIGINAL local-space verts + the matched-index set.
        # Both passes resolve coords → indices through it; keyed by body_obj so a
        # multi-piece body doesn't cross-contaminate.
        body_kd = {}
        body_index_set = {b: set() for b in body_objs}
        vg_entrance = {}
        vg_ring = {}
        for body_obj in body_objs:
            bm_kd = bmesh.new()
            bm_kd.from_mesh(body_obj.data)
            bm_kd.verts.ensure_lookup_table()
            kd = kdtree.KDTree(len(bm_kd.verts))
            for i, v in enumerate(bm_kd.verts):
                kd.insert(v.co, i)
            kd.balance()
            body_kd[body_obj] = kd
            bm_kd.free()
            vg_entrance[body_obj] = (body_obj.vertex_groups.get("HPL_Entrance")
                                     or body_obj.vertex_groups.new(name="HPL_Entrance"))
            vg_ring[body_obj] = (body_obj.vertex_groups.get("HPL_Ring")
                                 or body_obj.vertex_groups.new(name="HPL_Ring"))

        def collect_intersected_coords(body_obj, clothing_obj):
            """Duplicate body + clothing, boolean-intersect, harvest verts.
               Returns the set of (x, y, z) tuples that landed inside the
               clothing volume in body-local coordinates."""
            body_has_sk     = body_obj.data.shape_keys is not None
            clothing_has_sk = clothing_obj.data.shape_keys is not None
            if body_has_sk or clothing_has_sk:
                dlog(f"[HPL Mask] shape keys present on "
                     f"{body_obj.name}/{clothing_obj.name} — duplicates will be stripped")

            # Duplicate body
            bpy.ops.object.select_all(action='DESELECT')
            body_obj.select_set(True)
            bpy.context.view_layer.objects.active = body_obj
            bpy.ops.object.duplicate()
            temp_body = bpy.context.selected_objects[0]

            # Duplicate clothing
            bpy.ops.object.select_all(action='DESELECT')
            clothing_obj.select_set(True)
            bpy.context.view_layer.objects.active = clothing_obj
            bpy.ops.object.duplicate()
            temp_clothing = bpy.context.selected_objects[0]

            # Strip shape keys from the duplicates — the boolean modifier
            # doesn't handle them and Blender will error or produce garbage.
            if body_has_sk:     remove_shape_keys(temp_body)
            if clothing_has_sk: remove_shape_keys(temp_clothing)

            # Boolean INTERSECT
            bpy.context.view_layer.objects.active = temp_body
            mod = temp_body.modifiers.new(name='HPL_Boolean', type='BOOLEAN')
            mod.operation = 'INTERSECT'
            if hasattr(mod, 'use_self'):
                mod.use_self = True
            mod.object = temp_clothing

            try:
                bpy.ops.object.modifier_apply(modifier=mod.name)
                bm = bmesh.new()
                bm.from_mesh(temp_body.data)
                bm.verts.ensure_lookup_table()
                kd = body_kd[body_obj]
                idx_set = body_index_set[body_obj]
                for v in bm.verts:
                    # Nearest original body vert: interior passthrough lands within
                    # COINCIDENCE_EPS; new cut-boundary verts sit farther and are skipped.
                    _co, index, dist = kd.find(v.co)
                    if dist <= COINCIDENCE_EPS:
                        idx_set.add(index)
                bm.free()
            except Exception as e:
                derror(f"[HPL Mask] Boolean intersect failed for "
                       f"{body_obj.name} ∩ {clothing_obj.name}: {e}")

            # Clean up duplicates
            if temp_body.name in bpy.data.objects:
                bpy.data.objects.remove(temp_body, do_unlink=True)
            if temp_clothing.name in bpy.data.objects:
                bpy.data.objects.remove(temp_clothing, do_unlink=True)

        # Pass 1: boolean intersect every (body, clothing) pair.
        for clothing_obj in clothing_objs:
            for body_obj in body_objs:
                dlog(f"[HPL Mask] boolean intersect: {body_obj.name} ∩ {clothing_obj.name}")
                collect_intersected_coords(body_obj, clothing_obj)
                progress_counter += 1
                wm.progress_update(progress_counter)

        # Pass 2: proximity via the per-body KDTree (no rebuild). Each clothing vert's
        # nearest body vert, if within threshold AND its normal points toward it, is
        # included (kd.find returns the index directly).
        for body_obj in body_objs:
            kd = body_kd[body_obj]
            idx_set = body_index_set[body_obj]

            for clothing_obj in clothing_objs:
                if proximity_threshold > 0:
                    bm_cloth = bmesh.new()
                    bm_cloth.from_mesh(clothing_obj.data)
                    bm_cloth.verts.ensure_lookup_table()

                    # Batched NumPy path for large clothing (>5000 verts).
                    if len(bm_cloth.verts) > 5000:
                        cloth_co  = np.array([v.co[:]     for v in bm_cloth.verts])
                        cloth_nrm = np.array([v.normal[:] for v in bm_cloth.verts])
                        for i in range(len(cloth_co)):
                            co, index, dist = kd.find(Vector(cloth_co[i]))
                            if dist <= proximity_threshold:
                                direction = (co - Vector(cloth_co[i])).normalized()
                                if direction.dot(Vector(cloth_nrm[i])) > 0:
                                    idx_set.add(index)
                    else:
                        for vc in bm_cloth.verts:
                            co, index, dist = kd.find(vc.co)
                            if dist <= proximity_threshold:
                                direction = (co - vc.co).normalized()
                                if direction.dot(vc.normal) > 0:
                                    idx_set.add(index)
                    bm_cloth.free()

                progress_counter += 1
                wm.progress_update(progress_counter)

            # The index set is the answer (both passes resolved to indices via KDTree).
            final_indices = list(body_index_set[body_obj])
            dlog(f"[HPL Mask] {body_obj.name}: {len(final_indices)} verts masked "
                 f"(of {len(body_obj.data.vertices)} total)")
            if final_indices:
                if create_entrance:
                    vg_entrance[body_obj].add(final_indices, 1.0, 'ADD')
                if create_ring:
                    vg_ring[body_obj].add(final_indices, 1.0, 'ADD')

    except Exception as e:
        derror(f"[HPL Mask] boolean_intersect_and_select error: {e}")
        import traceback; traceback.print_exc()
    finally:
        wm.progress_end()

    # Viewport-selection visualization (4.0+/5.x safe). The vertex_group_set_active +
    # vertex_group_select ops chain silently broke on 4.0+ (groups created fine, but
    # the user saw an empty selection and assumed nothing happened). Direct bmesh
    # .select writes are stable 2.93→5.1.
    for body_obj in body_objs:
        if body_obj.name not in bpy.data.objects:
            continue

        target_indices = set()
        vg_e = body_obj.vertex_groups.get("HPL_Entrance")
        vg_r = body_obj.vertex_groups.get("HPL_Ring")
        for vg in ((vg_e,) if create_entrance else ()) + \
                  ((vg_r,) if create_ring else ()):
            if vg is None:
                continue
            for v in body_obj.data.vertices:
                for g in v.groups:
                    if g.group == vg.index:
                        target_indices.add(v.index)
                        break

        if not target_indices:
            continue

        bpy.context.view_layer.objects.active = body_obj
        try:
            bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            if create_entrance and vg_e is not None:
                body_obj.vertex_groups.active_index = vg_e.index
            continue

        import bmesh as _bmesh
        bm = _bmesh.from_edit_mesh(body_obj.data)
        for v in bm.verts:  v.select = False
        for e in bm.edges:  e.select = False
        for f in bm.faces:  f.select = False
        bm.verts.ensure_lookup_table()
        for vi in target_indices:
            if vi < len(bm.verts):
                bm.verts[vi].select = True
        bm.select_flush(True)
        _bmesh.update_edit_mesh(body_obj.data)

        if create_entrance and vg_e is not None:
            body_obj.vertex_groups.active_index = vg_e.index
        elif create_ring and vg_r is not None:
            body_obj.vertex_groups.active_index = vg_r.index

    dlog(f"[HPL Mask] Total processing time: {time.time() - start_time:.2f}s")

def transfer_weights_blender_native(source, target):
    """
    Transfer vertex groups using Blender's DATA_TRANSFER modifier.
    Reliable baseline — handles operator context and object transforms
    the same way Blender always has. Used as the first pass in the hybrid
    pipeline before cleanup_vertex_weights runs.
    """
    if bpy.context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    # Ensure target has the same group names as source
    existing = {vg.name for vg in target.vertex_groups}
    for vg in source.vertex_groups:
        if vg.name not in existing:
            target.vertex_groups.new(name=vg.name)

    mod = target.modifiers.new(name="_mdt_wt_tmp", type='DATA_TRANSFER')
    mod.object = source
    mod.use_vert_data = True
    mod.data_types_verts = {'VGROUP_WEIGHTS'}
    mod.vert_mapping = 'POLYINTERP_NEAREST'
    mod.layers_vgroup_select_src = 'ALL'
    mod.layers_vgroup_select_dst = 'NAME'
    mod.use_object_transform = True

    bpy.context.view_layer.objects.active = target
    try:
        bpy.ops.object.modifier_apply(modifier=mod.name)
        return True
    except Exception as e:
        derror(f"[MDL] DATA_TRANSFER failed on {target.name}: {e}")
        target.modifiers.remove(mod)
        return False


def cleanup_vertex_weights(obj, normalize=True, threshold=0.01):
    """Post-process weights after a native transfer: zero sub-threshold weights
    (ghost <1% influences across 60+ groups cause deform artifacts) and normalize
    per vertex to sum 1.0 (drift stretches basemodel characters). Pure numpy.
    """
    mesh   = obj.data
    groups = obj.vertex_groups
    if not groups:
        return

    v_count = len(mesh.vertices)
    g_count = len(groups)

    # Read weights into a (V,G) float32 array. v.groups has no nested foreach_get, so
    # this loops per-vertex but collects into flat buffers (one vectorized scatter
    # below) rather than per-element 2D fancy-index writes (~25% faster).
    v_indices_list = []
    g_indices_list = []
    weight_values = []
    for v in mesh.vertices:
        vi = v.index
        for elem in v.groups:
            gi = elem.group
            if gi < g_count:
                v_indices_list.append(vi)
                g_indices_list.append(gi)
                weight_values.append(elem.weight)

    weights = np.zeros((v_count, g_count), dtype=np.float32)
    if v_indices_list:
        vi_arr = np.asarray(v_indices_list, dtype=np.int64)
        gi_arr = np.asarray(g_indices_list, dtype=np.int64)
        w_arr = np.asarray(weight_values, dtype=np.float32)
        # Single vectorized scatter — equivalent to per-element assignment.
        weights[vi_arr, gi_arr] = w_arr

    # Threshold — zero out anything below cutoff
    if threshold > 0:
        weights[weights < threshold] = 0.0

    # Normalize per vertex across all groups
    if normalize:
        row_sums = weights.sum(axis=1, keepdims=True)   # (V, 1)
        nonzero  = row_sums[:, 0] > 1e-6
        weights[nonzero] /= row_sums[nonzero]

    # Write back per group, bucketed by weight: VertexGroup.add takes an index list for
    # a single float, collapsing one-call-per-vertex into one per unique weight (~100x
    # fewer calls; threshold+normalize produce many repeats). Same state via 'REPLACE'.
    for gi, vg in enumerate(groups):
        col   = weights[:, gi]
        has_w = col > 0
        no_w  = ~has_w
        if no_w.any():
            vg.remove(np.where(no_w)[0].tolist())
        if not has_w.any():
            continue
        keep_idx = np.where(has_w)[0]
        keep_w = col[keep_idx]
        # Bucket by unique weight value.
        unique_w, inverse = np.unique(keep_w, return_inverse=True)
        for k in range(len(unique_w)):
            idx_list = keep_idx[inverse == k].tolist()
            vg.add([int(i) for i in idx_list], float(unique_w[k]), 'REPLACE')


def TransferObjWeights(source, target):
    """
    Hybrid weight transfer:
    1. Blender native DATA_TRANSFER for reliable surface projection + parenting context
    2. numpy cleanup pass for normalization and threshold (fixes basemodel drift/ghost weights)
    """
    ok = transfer_weights_blender_native(source, target)
    if ok:
        cleanup_vertex_weights(target, normalize=True, threshold=0.01)


def transfer_weights_mdt(source, target, normalize=True, threshold=0.01,
                          max_distance=None, search_method='AUTO'):
    """
    MeshDataTransfer-based weight transfer. Used when the user explicitly
    picks a search method other than Auto-native, or calls it directly.

    search_method: 'AUTO'    — UV if both meshes have active UVs, else CLOSEST
                   'CLOSEST' — always nearest point on surface
                   'UVS'     — UV space (head/body stay separate, no join needed)
                   'RAYCAST' — bidirectional normal projection
    """
    from .MeshDataTransfer.mesh_data_transfer import MeshDataTransfer

    has_uvs = (source.data.uv_layers.active is not None and
               target.data.uv_layers.active is not None)

    if search_method == 'AUTO':
        method   = 'UVS' if has_uvs else 'CLOSEST'
        uv_space = has_uvs
    elif search_method == 'UVS':
        method   = 'UVS'
        uv_space = True
    else:
        method   = search_method
        uv_space = False

    try:
        transfer = MeshDataTransfer(
            source=source, target=target,
            search_method=method,
            uv_space=uv_space,
            world_space=not uv_space,
        )
        if max_distance is not None:
            transfer.transfer_vertex_groups_proximity_masked(
                max_distance=max_distance, normalize=normalize, threshold=threshold)
        else:
            transfer.transfer_vertex_groups(normalize=normalize, threshold=threshold)
        transfer.free()
        return True
    except Exception as e:
        dlog(f"[MDL] transfer_weights_mdt {source.name} → {target.name}: {e}")
        import traceback; traceback.print_exc()
        return False


def _is_floating_prop(obj, source):
    """
    Detect floating props relative to a body-sized source.
    Disabled when source is itself a small prop (belt strap etc.)
    to prevent proximity masking from misfiring prop-to-prop.
    """
    try:
        sv = source.dimensions
        ov = obj.dimensions
        src_vol = abs(sv.x * sv.y * sv.z)
        obj_vol = abs(ov.x * ov.y * ov.z)
        if src_vol < 0.05:          # source is itself a small prop — skip
            return False
        return obj_vol / src_vol < 0.15
    except Exception:
        return False


def find_armature_modifier(obj):
    """Find armature driving obj — checks modifier then direct parent."""
    for mod in obj.modifiers:
        if mod.type == 'ARMATURE' and mod.object:
            return mod.object
    if obj.parent and obj.parent.type == 'ARMATURE':
        return obj.parent
    return None

def remove_armature_modifiers(objects):
    for obj in objects:
        for mod in [m for m in obj.modifiers if m.type == 'ARMATURE']:
            obj.modifiers.remove(mod)

def parent_to_armature(source, destination):
    """
    Parent destination objects to the armature that drives source,
    preserving each child's world transform — equivalent to
    Ctrl+P → 'Object (Keep Transform)'.
    """
    from mathutils import Matrix
    arm = find_armature_modifier(source)
    if not arm:
        dlog(f"[MDL] parent_to_armature: no armature on '{source.name}' — skipping")
        return
    remove_armature_modifiers(destination)
    for obj in destination:
        old_world = obj.matrix_world.copy()
        obj.parent = arm
        obj.matrix_parent_inverse = arm.matrix_world.inverted() @ old_world @ obj.matrix_basis.inverted()
        obj.modifiers.new(name="Armature", type='ARMATURE').object = arm
    bpy.context.view_layer.update()

def heat_seek_rigging(source, destination_objects, search_method='AUTO'):
    """
    Auto-rig unweighted meshes from source.

    search_method 'AUTO' (default): uses Blender's native DATA_TRANSFER for
    the projection + parenting, then numpy cleanup for normalization/threshold.
    Other methods ('CLOSEST', 'UVS', 'RAYCAST'): routes through MeshDataTransfer
    directly, which enables UV-space transfer (head/body without joining) but
    uses our custom parenting path.
    """
    valid = [obj for obj in destination_objects
             if obj.type == 'MESH' and not obj.vertex_groups and obj != source]
    wm = bpy.context.window_manager
    wm.progress_begin(0, len(valid))
    try:
        for i, obj in enumerate(valid):
            wm.progress_update(i)
            try:
                if search_method == 'AUTO':
                    # Reliable hybrid: native transfer + numpy cleanup
                    ok = transfer_weights_blender_native(source, obj)
                    if ok:
                        cleanup_vertex_weights(obj, normalize=True, threshold=0.01)
                        parent_to_armature(source, [obj])
                        dlog(f"[MDL] HeatSeek: {obj.name} ← {len(obj.vertex_groups)} groups [native+cleanup]")
                    else:
                        derror(f"[MDL] HeatSeek: {obj.name} — native transfer failed")
                else:
                    # MDT path for explicit UV/Closest/Raycast selection
                    ok = transfer_weights_mdt(
                        source, obj,
                        normalize=True, threshold=0.01,
                        search_method=search_method,
                    )
                    if ok:
                        parent_to_armature(source, [obj])
                        dlog(f"[MDL] HeatSeek: {obj.name} ← {len(obj.vertex_groups)} groups [{search_method}]")
                    else:
                        derror(f"[MDL] HeatSeek: {obj.name} — MDT transfer failed")
            except Exception as e:
                dlog(f"[MDL] HeatSeek: {obj.name} — {e}")
                import traceback; traceback.print_exc()
    finally:
        wm.progress_end()


# ═══════════════════════════════════════════════════════════════════════════
#  PANELS — MAXIMUM BEAUTIFICATION
# ═══════════════════════════════════════════════════════════════════════════

class MDLPanel(bpy.types.Panel):
    """Scene Flags — overrides the base panel with modernized layout + presets"""
    bl_label = "Scene Flags"
    bl_idname = "OBJECT_PT_MDLPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'MDL Tools'
    bl_order = 0  # Force to very top

    def draw_header(self, context):
        self.layout.label(text="", icon='SCENE_DATA')

    def draw(self, context):
        layout = self.layout
        obj = context.object
        if obj is None or not hasattr(obj, "mdl_properties"):
            layout.label(text="Select a mesh object", icon='INFO')
            return
        props = obj.mdl_properties

        # ── Appearance badge ──
        header = layout.row(align=True)
        header.label(text="Appearance:", icon='RESTRICT_RENDER_OFF')
        badge = header.row(align=True)
        badge.alignment = 'RIGHT'
        badge.enabled = False
        badge.scale_x = 1.2
        badge.prop(props, "appearance_flag", text="")

        layout.separator(factor=0.5)

        # ── Visibility (2×2 toggle grid with taller buttons) ──
        box = layout.box()
        col = box.column(align=True)

        row = col.row(align=True)
        row.scale_y = 1.3
        row.prop(props, "ring_only",     text="Ring Only",     toggle=True, icon='MESH_CIRCLE')
        row.prop(props, "entrance_only", text="Entrance Only", toggle=True, icon='EXPORT')

        row = col.row(align=True)
        row.scale_y = 1.3
        row.prop(props, "all_scenes",    text="All Scenes",    toggle=True, icon='WORLD')
        row.prop(props, "other",         text="Custom",        toggle=True, icon='PREFERENCES')

        layout.separator(factor=0.5)

        # ── Custom value + Sub flag (side by side, boxed) ──
        row = layout.row(align=True)
        col_l = row.column(align=True)
        col_l.label(text="Custom Value:", icon='GHOST_ENABLED')
        col_l.prop(props, "other_value", text="")
        col_r = row.column(align=True)
        col_r.label(text="Sub Flag:", icon='BOOKMARKS')
        col_r.prop(props, "sub_flag", text="")

        layout.separator(factor=0.6)

        # ── Presets (collapsible) ──
        box = layout.box()
        row = box.row(align=True)
        row.prop(props, "show_flag_management",
                 icon="TRIA_DOWN" if props.show_flag_management else "TRIA_RIGHT",
                 emboss=False, text="")
        row.label(text="Presets", icon='PRESET')

        if props.show_flag_management:
            box.separator(factor=0.3)
            box.prop(props, "title", text="", icon='TEXT')

            row = box.row(align=True)
            row.scale_y = 1.2
            row.operator("mdl.store_flags", text="Save Preset", icon='FILE_NEW')

            box.separator(factor=0.5)
            box.prop(props, "flag_options", text="")

            row = box.row(align=True)
            row.scale_y = 1.1
            row.operator("mdl.apply_flags",  text="Apply",  icon='CHECKMARK')
            row.operator("mdl.remove_flags", text="Delete", icon='TRASH')


class VIEW3D_PT_ModelFunctions(bpy.types.Panel):
    """Model Functions — container for Character Utilities and HPL Masking"""
    bl_label = "Model Functions"
    bl_idname = "VIEW3D_PT_ModelFunctions"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'MDL Tools'
    bl_order = 10

    def draw_header(self, context):
        self.layout.label(text="", icon='TOOL_SETTINGS')

    def draw(self, context):
        pass


class VIEW3D_PT_CharUtilsPanel(bpy.types.Panel):
    """Character Utilities — skeleton, rigging, and APs"""
    bl_label = "Character Utilities"
    bl_idname = "VIEW3D_PT_CharUtilsPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'MDL Tools'
    bl_parent_id = "VIEW3D_PT_ModelFunctions"

    def draw(self, context):
        layout = self.layout

        # ── Weight Transfer Search Method ──────────────────────────────────
        box = layout.box()
        box.label(text="Search Method", icon='VIEWZOOM')
        row = box.row(align=True)
        for item in context.scene.bl_rna.properties['mdl_weight_search_method'].enum_items_static:
            row.prop_enum(context.scene, 'mdl_weight_search_method', item.identifier)

        method = getattr(context.scene, 'mdl_weight_search_method', 'AUTO')
        if method == 'AUTO':
            box.label(text="UV when available — head/body transfer separately", icon='INFO')
        elif method == 'UVS':
            box.label(text="UV space — no join needed for head and body", icon='INFO')
        elif method == 'RAYCAST':
            box.label(text="Normal projection — good for layered meshes", icon='INFO')

        layout.separator(factor=0.3)

        # ── Transfer / Heat Seek buttons ───────────────────────────────────
        row = layout.row(align=True)
        row.scale_y = 1.4
        row.operator("object.transfer_weights_operator",  text="Transfer Weights", icon='MOD_DATA_TRANSFER')
        row.operator("object.heat_seek_rigging_operator", text="Heat Seek Rig",    icon='LIGHT_SUN')

        layout.separator(factor=0.3)

        # ── Skeleton / APs ────────────────────────────────────────────────
        row = layout.row(align=True)
        row.scale_y = 1.4
        op_full = row.operator("object.retarget_skeleton_operator",
                                text="Align Skeleton",  icon='ARMATURE_DATA')
        op_full.hair_only = False
        row.operator("object.generate_vc_char_aps",
                      text="Generate APs",      icon='EMPTY_ARROWS')

        # GtPt anchor generator — drops the 13 vanilla eye/mouth/teeth anchors; the
        # export resolver snaps each to the nearest vertex on its target mesh.
        row = layout.row(align=True)
        row.scale_y = 1.2
        row.operator("object.generate_vc_char_gtpts",
                      text="Generate GtPts",    icon='EMPTY_AXIS')

        # Hair-only mode: pulls just J_Hair + descendants (port an attire's hair
        # physics chain onto a clean baseModel without the source's full bone table).
        row = layout.row(align=True)
        row.scale_y = 1.2
        op_hair = row.operator("object.retarget_skeleton_operator",
                                text="Align Skeleton (Hair Only)",
                                icon='STRANDS')
        op_hair.hair_only = True


# ── HPL panel status cache ──────────────────────────────────────────────────
# Panel draw() runs on every UI redraw (mouse move over the sidebar). The HPL
# round-trip status is expensive to compute — a collection scan with
# os.path.exists per stamped source, a full-scene basemodel classification,
# and worst of all an O(total_verts × groups) vertex-group membership count
# over M_Head/M_Body (tens of thousands of verts). Computing that per redraw
# made the whole 3D View sidebar stutter on heavy scenes. The status only
# changes on user edits, so a short TTL cache keeps the panel live while
# bounding the cost to once per _HPL_STATUS_TTL seconds. Only plain display
# data (strings/bools) is cached — never bpy object references, which would
# dangle across undo/redo.
_HPL_STATUS_TTL = 2.0
_hpl_status_cache = {"t": 0.0, "data": None}


def _compute_hpl_panel_status():
    from ...Serialize.hpl_roundtrip import (
        find_attire_hpl_sidecar, scene_has_hpl_edits, find_basemodel_meshes)
    sidecar_path, col_name = find_attire_hpl_sidecar()
    has_edits = scene_has_hpl_edits()
    base_meshes = find_basemodel_meshes()
    group_lines = []
    if has_edits and base_meshes:
        for mesh_key, obj in base_meshes.items():
            for vg_name in ('HPL_Ring', 'HPL_Entrance'):
                vg = obj.vertex_groups.get(vg_name)
                if vg:
                    vg_idx = vg.index
                    count = sum(1 for v in obj.data.vertices
                                if any(g.group == vg_idx for g in v.groups))
                    group_lines.append(f"  {mesh_key}  {vg_name}: {count}")
    return {
        "has_sidecar": bool(sidecar_path),
        "col_name": col_name or "",
        "has_edits": has_edits,
        "has_base": bool(base_meshes),
        "group_lines": group_lines,
    }


def _hpl_panel_status():
    now = time.monotonic()
    if (_hpl_status_cache["data"] is None
            or now - _hpl_status_cache["t"] > _HPL_STATUS_TTL):
        _hpl_status_cache["data"] = _compute_hpl_panel_status()
        _hpl_status_cache["t"] = now
    return _hpl_status_cache["data"]


class VIEW3D_PT_HPLMaskingPanel(bpy.types.Panel):
    """HPL Masking — visibility mask generation and management"""
    bl_label = "HPL Masking"
    bl_idname = "VIEW3D_PT_HPLMaskingPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'MDL Tools'
    bl_parent_id = "VIEW3D_PT_ModelFunctions"

    def draw(self, context):
        layout = self.layout

        # ── HPL Round-Trip Detection (TTL-cached — see _hpl_panel_status) ──
        try:
            status = _hpl_panel_status()
            has_edits = status["has_edits"]

            if status["has_sidecar"]:
                box = layout.box()
                row = box.row(align=True)
                row.label(text="Masking Detected", icon='CHECKMARK')
                sub = row.row(); sub.alignment = 'RIGHT'
                sub.label(text=status["col_name"], icon='COLLECTION_COLOR_04')

                if has_edits and status["has_base"]:
                    col = box.column(align=True)
                    for line in status["group_lines"]:
                        col.label(text=line, icon='VERTEXSEL')
                    box.label(text="Updates on export", icon='FILE_REFRESH')

                row = box.row(align=True); row.scale_y = 1.2
                row.operator("object.apply_hpl_from_attire", 
                    text="Re-apply from Attire" if has_edits else "Apply HPL to BaseModel", 
                    icon='LOOP_BACK' if has_edits else 'IMPORT')

                layout.separator(factor=0.5)
            elif has_edits and status["has_base"]:
                # No attire source found but HPL groups exist — show refresh option
                box = layout.box()
                box.label(text="HPL groups present (no attire source)", icon='INFO')
                box.label(text="Updates on export", icon='FILE_REFRESH')
                layout.separator(factor=0.5)
        except Exception:
            pass

        # ── Generate HPL Mask (hero button) ──
        row = layout.row(align=True)
        row.scale_y = 1.5
        row.operator("object.auto_hpl_mask_boolean_operator", text="Generate HPL Mask", icon='MOD_MASK')

        row = layout.row(align=True)
        row.scale_y = 1.2
        row.operator("object.generate_empty_hpl", text="Generate Empty HPL", icon='GHOST_ENABLED')

        if len(context.scene.hpl_mask_objects) > 0:
            r = layout.row(); r.alignment = 'CENTER'
            r.label(text="Using Solidify Helper", icon='INFO')

        layout.separator(factor=0.5)

        # ── Vertex Groups (toggle pills) ──
        box = layout.box()
        box.label(text="Vertex Group Options:", icon='GROUP_VERTEX')

        row = box.row(align=True)
        row.scale_y = 1.2
        row.prop(context.scene, "create_entrance", text="Entrance", toggle=True, icon='SELECT_SET')
        row.prop(context.scene, "create_ring",     text="Ring",     toggle=True, icon='MESH_CIRCLE')

        box.separator(factor=0.3)
        row = box.row(align=True)
        row.label(text="Proximity:", icon='DRIVER_DISTANCE')
        row.prop(context.scene, "proximity_threshold", text="")

        layout.separator(factor=0.5)

        # ── Solidify Helper (collapsible) ──
        box = layout.box()
        hpl_props = context.scene.hpl_options_props
        row = box.row(align=True)
        row.prop(hpl_props, "expand_hpl_options",
                 icon="TRIA_DOWN" if hpl_props.expand_hpl_options else "TRIA_RIGHT",
                 emboss=False, text="")
        row.label(text="Solidify Helper", icon='MOD_SOLIDIFY')

        if hpl_props.expand_hpl_options:
            box.separator(factor=0.3)

            # Add/Remove
            row = box.row(align=True)
            row.scale_y = 1.1
            row.operator("object.add_to_hpl_mask",      text="Add",    icon='ADD')
            row.operator("object.remove_from_hpl_mask",  text="Remove", icon='REMOVE')

            # Object list
            if len(context.scene.hpl_mask_objects) == 0:
                box.separator(factor=0.3)
                box.label(text="No objects added", icon='GHOST_DISABLED')
            else:
                inner = box.box()
                for i, item in enumerate(context.scene.hpl_mask_objects):
                    obj = bpy.data.objects.get(item.name)
                    if obj:
                        row = inner.row(align=True)
                        row.prop(item, "use_object", text="")
                        row.label(text=obj.name, icon='OUTLINER_OB_MESH')
                        op = row.operator("object.remove_specific_hpl_object", text="", icon='X')
                        op.index = i

            box.separator(factor=0.5)

            # Solidify settings
            sb = box.box()
            sb.label(text="Solidify Settings", icon='MODIFIER')
            sb.separator(factor=0.2)

            row = sb.row(align=True)
            row.prop(context.scene, "hpl_solidify_thickness_mode", text="")
            row.prop(context.scene, "hpl_solidify_mode", text="")

            sb.separator(factor=0.3)
            split = sb.split(factor=0.5, align=True)
            split.column(align=True).prop(context.scene, "hpl_solidify_thickness", text="Thick")
            split.column(align=True).prop(context.scene, "hpl_solidify_offset", text="Offset")

            sb.separator(factor=0.2)
            sb.prop(context.scene, "hpl_solidify_merge_value", text="Merge Threshold")

            sb.separator(factor=0.2)
            row = sb.row(align=True)
            row.scale_y = 1.1
            row.prop(context.scene, "hpl_solidify_fill",     text="Fill",     toggle=True)
            row.prop(context.scene, "hpl_solidify_only_rim", text="Only Rim", toggle=True)


# ═══════════════════════════════════════════════════════════════════════════
#  REGISTRATION
# ═══════════════════════════════════════════════════════════════════════════

classes = [
    MDLProperties, MDLPanel,
    STORE_OT_FlagsOperator, APPLY_OT_FlagsOperator, REMOVE_OT_FlagsOperator,
    HPLOptionsProperties, HPLMaskObjectCollection,
    OBJECT_OT_AddToHPLMask, OBJECT_OT_RemoveFromHPLMask, OBJECT_OT_RemoveSpecificHPLObject,
    OBJECT_OT_ApplyHPLFromAttire, OBJECT_OT_GenerateEmptyHPL, AutoHPLMaskBooleanOperator,
    TransferWeightsOperator, HeatSeekRiggingOperator, SetObjectsToCenterOfMassOperator,
    VIEW3D_PT_ModelFunctions, VIEW3D_PT_CharUtilsPanel, VIEW3D_PT_HPLMaskingPanel,
]

def register_streamline_tools():
    # Warm up stored_flags + its enum-items cache BEFORE registering the PropertyGroup:
    # the UI can query the flag_options callback the instant the PointerProperty attaches,
    # and an unbuilt cache hits the empty-items path that starts the warning/crash sequence.
    load_flags_from_file()

    for cls in classes:
        try: bpy.utils.register_class(cls)
        except Exception as e: print(f"Failed to register {cls.__name__}: {e}")
    bpy.types.Object.mdl_properties = bpy.props.PointerProperty(type=MDLProperties)
    bpy.types.Scene.hpl_options_props = bpy.props.PointerProperty(type=HPLOptionsProperties)
    bpy.types.Scene.create_entrance = bpy.props.BoolProperty(name="create_entrance", description="Create the HPL_Entrance vertex group", default=True)
    bpy.types.Scene.create_ring = bpy.props.BoolProperty(name="create_ring", description="Create the HPL_Ring vertex group", default=True)
    bpy.types.Scene.proximity_threshold = bpy.props.FloatProperty(name="proximity_threshold", description="Proximity threshold", default=0.0, min=0.0, max=1.0)
    bpy.types.Scene.hpl_mask_objects = bpy.props.CollectionProperty(type=HPLMaskObjectCollection)
    bpy.types.Scene.hpl_solidify_thickness = bpy.props.FloatProperty(name="Thickness", default=3.0, min=0.0)
    bpy.types.Scene.hpl_solidify_offset = bpy.props.FloatProperty(name="Offset", default=-1.0)
    bpy.types.Scene.hpl_solidify_thickness_mode = bpy.props.EnumProperty(name="Thickness Mode",
        items=[('FIXED', "Fixed", "Uniform"), ('EVEN', "Even", "Even sides"), ('MINIMUM', "Minimum", "Min distance")], default='FIXED')
    bpy.types.Scene.hpl_solidify_merge_value = bpy.props.FloatProperty(name="Merge Value", default=0.0001, min=0.0)
    bpy.types.Scene.hpl_solidify_mode = bpy.props.EnumProperty(name="Mode",
        items=[('EXTRUDE', "Simple", "Extrude"), ('NON_MANIFOLD', "Complex", "Manifold")], default='EXTRUDE')
    bpy.types.Scene.hpl_solidify_fill = bpy.props.BoolProperty(name="Fill", default=True)
    bpy.types.Scene.hpl_solidify_only_rim = bpy.props.BoolProperty(name="Only Rim", default=False)
    bpy.types.Scene.hpl_solidify_factor = bpy.props.FloatProperty(name="Factor", default=0.0, min=0.0)
    bpy.types.Scene.hpl_solidify_flat_faces = bpy.props.BoolProperty(name="Flat Faces", default=False)
    bpy.types.Scene.mdl_weight_search_method = bpy.props.EnumProperty(
        name="Search Method",
        description="How target vertices are matched to source surface for weight transfer",
        items=[
            ('AUTO',    'Auto',    "Use UV space if both meshes have active UVs, otherwise Closest. "
                                   "Head and body transfer independently — no join needed",
             'SHADERFX', 1),
            ('CLOSEST', 'Closest', "Nearest point on source surface. Fastest, works without UVs",
             'ARROW_LEFTRIGHT', 2),
            ('UVS',     'UV',      "Match by UV coordinate. Most accurate for same-UV-layout meshes. "
                                   "Head and body stay separate",
             'UV_DATA', 3),
            ('RAYCAST', 'Raycast', "Bidirectional normal projection. Good for layered meshes",
             'PROP_PROJECTED', 4),
        ],
        default='AUTO',
    )

def unregister_streamline_tools():
    for prop in ["hpl_mask_objects", "hpl_solidify_thickness", "hpl_solidify_offset",
                 "hpl_solidify_thickness_mode", "hpl_solidify_merge_value", "hpl_solidify_mode",
                 "hpl_solidify_fill", "hpl_solidify_only_rim", "hpl_solidify_factor",
                 "hpl_solidify_flat_faces", "create_entrance", "create_ring", "proximity_threshold",
                 "mdl_weight_search_method"]:
        if hasattr(bpy.types.Scene, prop): delattr(bpy.types.Scene, prop)
    if hasattr(bpy.types.Object, "mdl_properties"): del bpy.types.Object.mdl_properties
    if hasattr(bpy.types.Scene, "hpl_options_props"): del bpy.types.Scene.hpl_options_props
    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except Exception as e: print(f"Failed to unregister {cls.__name__}: {e}")

if __name__ == "__main__":
    register_streamline_tools()
