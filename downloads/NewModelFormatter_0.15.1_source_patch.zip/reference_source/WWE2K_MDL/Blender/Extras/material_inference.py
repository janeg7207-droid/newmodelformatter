"""Slot-name -> 2K26 shader template inference.

Derived from materiallink.cpp MODEL_PRESET_MAP. Given a raw Blender
material/slot name (e.g. "body", "eye_l", "jacket:Skinned",
"glasses_ALPHA"), this module returns the appropriate 2K26 shader byte,
shader name, type name, and an alpha-variant flag.

Public API:
    infer_template(slot_name, *, is_attire=False, is_environment=False)
        -> (shader_byte, shader_name, type_name, is_alpha)
    normalize_slot_name(slot_name)   -> canonical lowercased family name
    is_basemodel_slot(slot_name)     -> True if face/body/eyes/teeth/hair
    get_jmtl_filename(material_name) -> on-disk .jmtl filename
    is_software_default_name(name)   -> True if name looks like a
        default from Maya / Blender / 3ds Max (e.g. "lambert1",
        "Material.001", "01 - Default"). Used by the exporter to warn
        the user before writing a bogus slot to disk.

Attire-context routing for hair: both basemodel and attire hair_ALPHA /
combinations_ALPHA use byte 0x16 (yCh_hair / NewHair_ColorChanging) in vanilla 2K26
(verified against 649 shipped attire JMTLs). The is_attire kwarg is wired through
anyway so callers pass the context they have, leaving room to diverge later.
"""

from __future__ import annotations  # PEP 563: stringize annotations so the

# tuple[...] / str | None return hints below don't evaluate at import time —
# keeps this module importable on Blender 2.9x's Python 3.7/3.9 (the addon's
# __init__ imports it eagerly via material_export_panel; an import-time
# TypeError here de-registers the WHOLE addon, including the export operator).
import re


# --- Constants ----------------------------------------------------------------

# Gear fallback (also used for all attire pieces and unknown slots).
_GEAR = (0x15, "yCh_gear", "Normal")

# Slot family -> (shader_byte, shader_name, type_name).
# Keys are the *normalized* family names produced by normalize_slot_name().
SLOT_FAMILY_TABLE = {
    "head":         (0x17, "yCh_head",  "Normal"),
    "body":         (0x19, "yCh_skin",  "Normal"),
    "z_body":       (0x19, "yCh_skin",  "Normal"),
    "eye":          (0x12, "yCh_eye",   "Normal"),
    "eye_caruncle": (0x13, "yCh_head",  "Caruncle"),
    "eyelash":      (0x14, "yCh_eyeOv", "Eyelash"),
    "teeth":        (0x1A, "yCh_Teeth", "Normal"),
    "mouthbag":     (0x1A, "yCh_Teeth", "Mouthbag"),
    "hair":         (0x16, "yCh_hair",  "NewHair_ColorChanging"),
    "combinations": (0x16, "yCh_hair",  "NewHair_ColorChanging"),
    "fur":           (0x1B, "yCh_fur", "Default"),
    "hairmesh":      (0x1C, "yCh_hairMesh", "Default"),
    "shellfur":      (0x1D, "yCh_shellFur", "Default"),
    "npc":          (0x01, "yPBR",      "t_BRDF"),
}

# Arena / prop routing for the payload layouts verified by the runtime reader.
# Movie and hologram stay editor-only until their nested tables are complete.
_ENVIRONMENT_RULES = (
    (("water", "pool", "fountain"), (0x07, "Water", "t_Water")),
    (("tree", "plant", "grass", "foliage", "bush", "leaf"),
     (0x06, "speedTree", "Default")),
    (("glass", "window", "windshield"), (0x03, "yGlass", "t_Translucency")),
    (("light", "glow", "led", "neon", "illum", "emissive"),
     (0x02, "yIllumination", "t_Illumination")),
)

# Basemodel slots (everything else is attire).
BASEMODEL_FAMILIES = frozenset({
    "head", "body", "z_body",
    "eye", "eye_caruncle", "eyelash",
    "teeth", "mouthbag",
    "hair", "combinations", "fur", "hairmesh", "shellfur",
})

# Recognized attire family stems. Anything containing one of these tokens (or
# matching the *_acce_* / a_acce / h_acce / u_acce patterns) is treated as
# gear. The table is for documentation / is_basemodel_slot() — infer_template
# falls back to gear regardless.
ATTIRE_FAMILIES = frozenset({
    "jacket", "bottoms", "tops", "tights", "underwear", "brassiere",
    "shoes", "kickpads", "socks", "belt", "glasses", "cap", "mask",
    "kneepad", "elbowpad", "wrist", "wristband",
    "a_acce", "h_acce", "h_other", "u_acce", "pierce", "outfit", "ula",
})

# Alpha suffix patterns. Note the _APLHA typo seen in sample data, plus the
# CAS-style single-letter _A suffix.
_ALPHA_SUFFIXES = ("_alpha", "_aplha", "_a")


# ─── Software-default material names ────────────────────────────────────────
# Unrenamed Maya/Max/Blender default material names leak into export and produce
# bogus .jmtl entries (e.g. "lambert1.jmtl") that can crash the loader. The exporter
# WARNs (not fails) so the user can rename first. Matching is case-insensitive on the
# cleaned name (post .001 + :Skinned strip), accepting numeric suffixes on Maya stems.

# Maya defaults (lambert1 ships with every fresh scene; others from duplicated nodes).
_MAYA_DEFAULT_STEMS = ("lambert", "blinn", "phong", "phonge", "particle")

# 3ds Max defaults. "01 - Default" uses a literal " - " separator; trailing digits
# on the leading number are accepted.
_MAX_DEFAULT_LITERALS = frozenset({
    "01 - default", "02 - default", "03 - default", "04 - default",
    "05 - default", "06 - default", "07 - default", "08 - default",
    "09 - default", "10 - default",
    "standard", "standard1", "standard2",
    "physicalmaterial", "physical material",
})

# Generic / cross-tool defaults. Blender's ``Material`` is the bare
# starting point; the ``.001`` duplicate suffix is stripped before this
# check so ``Material.001`` collapses to ``Material``.
_GENERIC_DEFAULT_LITERALS = frozenset({
    "material", "defaultmat", "default_obj", "default obj",
    "defaultmaterial", "default material", "none",
})


# --- Normalization ------------------------------------------------------------

def _strip_skinned(name: str) -> str:
    """Strip a trailing :Skinned / Skinned suffix (any case) plus trailing : / ws."""
    s = name.strip()
    # ":Skinned" / ":skinned" / ":SKINNED" etc.
    s = re.sub(r":\s*skinned\s*$", "", s, flags=re.IGNORECASE)
    # Bare trailing "Skinned" (no colon) — only strip when it follows something.
    s = re.sub(r"(?<=.)skinned\s*$", "", s, flags=re.IGNORECASE)
    # Dangling trailing colon / whitespace.
    s = s.rstrip(": \t\r\n")
    return s


def _detect_and_strip_alpha(name: str) -> tuple[str, bool]:
    """Return (name_without_alpha_suffix, is_alpha)."""
    low = name.lower()
    for suf in _ALPHA_SUFFIXES:
        if low.endswith(suf) and len(name) > len(suf):
            # Guard: don't strip "_a" if it would leave an empty / single-char stem
            # that wasn't really an alpha marker.
            stem = name[: -len(suf)]
            if suf == "_a":
                # "_A" alpha marker is upper-case in the samples (e.g. "jacket_A").
                # Be conservative: only treat as alpha if the original suffix was
                # upper-case ("_A"), not lower-case "_a" (which could be a real
                # slot like "bra"... but no slot legitimately ends in "_a" in
                # the sample data).
                if name[-2:] != "_A":
                    continue
            return stem, True
    return name, False


def _strip_lr(name: str) -> str:
    """Strip trailing _L / _R / _l / _r side markers."""
    return re.sub(r"_[LlRr]$", "", name)


def _strip_leading_lr(name: str) -> str:
    """Strip leading l_ / r_ / L_ / R_ side markers (e.g. l_kneepad -> kneepad)."""
    return re.sub(r"^[LlRr]_", "", name)


def _strip_digits(name: str) -> str:
    """Strip trailing variant indices: '_1', '_2', or bare trailing digits."""
    # First strip '_<digits>'
    s = re.sub(r"_\d+$", "", name)
    # Then strip any remaining bare trailing digits (e.g. "bottoms2" -> "bottoms").
    s = re.sub(r"\d+$", "", s)
    return s


def normalize_slot_name(slot_name: str) -> str:
    """Strip suffixes and return the lowercased canonical slot family name.

    Order matters: strip :Skinned first, then alpha, then L/R, then digits.
    """
    if not slot_name:
        return ""

    s = _strip_skinned(slot_name)
    s, _ = _detect_and_strip_alpha(s)
    s = _strip_lr(s)
    s = _strip_digits(s)
    # Leading L/R is a side marker (l_kneepad) — strip after trailing markers
    # so we don't accidentally turn "l_a_acce_1" into "_acce" weirdly.
    s = _strip_leading_lr(s)
    return s.lower().strip("_")


# --- Family classification ----------------------------------------------------

def _family_for(normalized: str) -> str | None:
    """Map a normalized slot name to a known family key, or None for fallback.

    Recognizes:
      - exact matches in SLOT_FAMILY_TABLE
      - eye variants: eye, eye_caruncle, eyelash
      - hair / combinations
      - the *_acce_* attire pattern (returns 'attire')
    """
    if not normalized:
        return None

    # Exact match in the family table.
    if normalized in SLOT_FAMILY_TABLE:
        return normalized

    # Eye family disambiguation. After normalization "eye_l" -> "eye", but
    # "eye_caruncle" stays "eye_caruncle" because "caruncle" isn't a digit/LR
    # token. Still, guard explicitly.
    if normalized.startswith("eye"):
        if "caruncle" in normalized:
            return "eye_caruncle"
        if normalized == "eyelash" or normalized.startswith("eyelash"):
            return "eyelash"
        return "eye"

    # Hair/fur variants (combinations is an alpha-hair sibling).
    if normalized.startswith("hairmesh") or normalized.startswith("hair_mesh"):
        return "hairmesh"
    if normalized == "hair" or normalized.startswith("hair_"):
        return "hair"
    if normalized.startswith("combination"):
        return "combinations"
    if normalized.startswith("shellfur") or normalized.startswith("shell_fur"):
        return "shellfur"
    if normalized == "fur" or normalized.startswith("fur_"):
        return "fur"

    # Teeth / mouthbag.
    if normalized.startswith("teeth"):
        return "teeth"
    if normalized.startswith("mouthbag"):
        return "mouthbag"

    # Body / head.
    if normalized == "body" or normalized.startswith("body_"):
        return "body"
    if normalized == "z_body" or normalized.startswith("z_body"):
        return "z_body"
    if normalized == "head" or normalized.startswith("head_"):
        return "head"

    # NPC marker.
    if normalized == "npc" or normalized.startswith("npc_"):
        return "npc"

    # Attire detection (returns sentinel so caller knows it's gear).
    for stem in ATTIRE_FAMILIES:
        if stem in normalized:
            return "_attire"

    return None


# --- Public API ---------------------------------------------------------------

def infer_template(
    slot_name: str,
    *,
    is_attire: bool = False,
    is_environment: bool = False,
) -> tuple[int, str, str, bool]:
    """Infer the 2K26 shader template from a Blender slot/material name.

    Returns (shader_byte, shader_name, type_name, is_alpha_variant).
    Unknown character slots fall back to gear (0x15 / yCh_gear / Normal).
    Unknown environment slots fall back to yPBR (0x01 / yPBR / t_BRDF).

    slot_name: raw Blender name; :Skinned, _ALPHA/_APLHA (typo), side markers, and
    numeric indices are stripped during lookup.
    is_attire: currently a no-op for every family (attire hair == basemodel hair,
    0x16, n=649) — wired through for future divergence without changing call sites.
    """
    if not slot_name:
        b, sh, t = (0x01, "yPBR", "t_BRDF") if is_environment else _GEAR
        return (b, sh, t, False)

    # Detect alpha on the raw name (after :Skinned stripping) so we can flag it
    # even when the family lookup uses the stripped form.
    pre = _strip_skinned(slot_name)
    _, is_alpha = _detect_and_strip_alpha(pre)

    normalized = normalize_slot_name(slot_name)
    if is_environment:
        for tokens, template in _ENVIRONMENT_RULES:
            if any(token in normalized for token in tokens):
                b, sh, t = template
                return (b, sh, t, is_alpha)
        return (0x01, "yPBR", "t_BRDF", is_alpha)

    family = _family_for(normalized)

    if family is None or family == "_attire":
        b, sh, t = _GEAR
        return (b, sh, t, is_alpha)

    # Attire-context hair routing: no-op today (attire hair == basemodel hair, 0x16,
    # n=649). Explicit so it's obvious where to diverge if a patch changes it.
    if is_attire and family in ("hair", "combinations"):
        b, sh, t = SLOT_FAMILY_TABLE[family]
        return (b, sh, t, is_alpha)

    b, sh, t = SLOT_FAMILY_TABLE[family]
    return (b, sh, t, is_alpha)


def is_software_default_name(name: str) -> bool:
    """True if `name` looks like a 3D-software default: Maya (lambert1/blinn2/...),
    Blender (Material, Material.001 — .001 stripped first), 3ds Max (01 - Default,
    Standard, PhysicalMaterial). Case-insensitive, equality-based (so standard_jacket
    won't match). Used by the exporter to warn before writing an unroutable .jmtl.
    """
    if not name:
        return False

    # Strip Blender's ``.001`` duplicate suffix so ``Material.005`` is
    # caught the same as ``Material``.
    stripped = re.sub(r"\.\d{3,}$", "", name).strip()
    if not stripped:
        return False

    low = stripped.lower()

    # Maya numeric defaults: lambert1, blinn2, phong, particle1, etc.
    # Match ``<stem>`` or ``<stem><digits>``.
    for stem in _MAYA_DEFAULT_STEMS:
        if low == stem:
            return True
        if low.startswith(stem) and low[len(stem):].isdigit():
            return True

    # Max + generic literal defaults.
    if low in _MAX_DEFAULT_LITERALS:
        return True
    if low in _GENERIC_DEFAULT_LITERALS:
        return True

    return False


def is_basemodel_slot(slot_name: str) -> bool:
    """True if the slot is a basemodel slot (face/body/eyes/teeth/hair)."""
    normalized = normalize_slot_name(slot_name)
    family = _family_for(normalized)
    if family is None or family == "_attire":
        return False
    return family in BASEMODEL_FAMILIES


def get_jmtl_filename(material_name: str) -> str:
    """Return the on-disk .jmtl filename for a material.

    Strips :Skinned but preserves _ALPHA / numeric / L-R suffixes, since the
    samples show those baked into the filename (e.g. 'glasses_ALPHA.jmtl').
    """
    if not material_name:
        return ".jmtl"
    s = _strip_skinned(material_name)
    return f"{s}.jmtl"


# --- Self-test ----------------------------------------------------------------

def _self_test() -> bool:
    """Exercise sample slot names and report PASS/FAIL."""
    cases = [
        # (input, expected (byte, shader, type, is_alpha))
        ("body",            (0x19, "yCh_skin",  "Normal", False)),
        ("body:Skinned",    (0x19, "yCh_skin",  "Normal", False)),
        ("z_body",          (0x19, "yCh_skin",  "Normal", False)),
        ("head",            (0x17, "yCh_head",  "Normal", False)),
        ("eye_l",           (0x12, "yCh_eye",   "Normal", False)),
        ("eye_r",           (0x12, "yCh_eye",   "Normal", False)),
        ("eye_caruncle",    (0x13, "yCh_head",  "Caruncle", False)),
        ("eyelash",         (0x14, "yCh_eye",   "Eyelash", False)),
        ("teeth",           (0x1A, "yCh_Teeth", "Normal", False)),
        ("mouthbag",        (0x1A, "yCh_Teeth", "Normal", False)),
        ("hair",            (0x16, "yCh_hair",  "NewHair_ColorChanging", False)),
        ("hair_ALPHA",      (0x16, "yCh_hair",  "NewHair_ColorChanging", True)),
        ("combinations",    (0x16, "yCh_hair",  "NewHair_ColorChanging", False)),
        ("combinations_ALPHA", (0x16, "yCh_hair", "NewHair_ColorChanging", True)),
        ("jacket",          (0x15, "yCh_gear",  "Normal", False)),
        ("jacket:Skinned",  (0x15, "yCh_gear",  "Normal", False)),
        ("glasses_ALPHA",   (0x15, "yCh_gear",  "Normal", True)),
        ("glasses_APLHA",   (0x15, "yCh_gear",  "Normal", True)),  # typo
        ("bottoms1",        (0x15, "yCh_gear",  "Normal", False)),
        ("bottoms2",        (0x15, "yCh_gear",  "Normal", False)),
        ("l_kneepad",       (0x15, "yCh_gear",  "Normal", False)),
        ("r_kneepad",       (0x15, "yCh_gear",  "Normal", False)),
        ("l_a_acce_1",      (0x15, "yCh_gear",  "Normal", False)),
        ("h_acce",          (0x15, "yCh_gear",  "Normal", False)),
        ("tights",          (0x15, "yCh_gear",  "Normal", False)),
        ("kickpads",        (0x15, "yCh_gear",  "Normal", False)),
        ("wristband_l",     (0x15, "yCh_gear",  "Normal", False)),
        ("brassiere",       (0x15, "yCh_gear",  "Normal", False)),
        ("npc",             (0x01, "yPBR",      "t_BRDF", False)),
        ("<unknown_blob>",  (0x15, "yCh_gear",  "Normal", False)),
        ("",                (0x15, "yCh_gear",  "Normal", False)),
        # Software-default leaks fall back to gear (the warning is
        # the exporter's responsibility, not the inferer's).
        ("lambert1",        (0x15, "yCh_gear",  "Normal", False)),
        ("Material",        (0x15, "yCh_gear",  "Normal", False)),
    ]

    fails = []
    print("[material_inference] self-test")
    print("=" * 72)
    for raw, expected in cases:
        got = infer_template(raw)
        ok = got == expected
        flag = "OK  " if ok else "FAIL"
        print(f"  {flag}  {raw!r:30s} -> {got}  (expected {expected})")
        if not ok:
            fails.append((raw, expected, got))

    # ── Attire-context routing for hair (byte stays 0x16 either way, n=649) ──
    print("-" * 72)
    attire_cases = [
        # (input, is_attire, expected)
        ("hair_ALPHA", False, (0x16, "yCh_hair", "NewHair_ColorChanging", True)),
        ("hair_ALPHA", True,  (0x16, "yCh_hair", "NewHair_ColorChanging", True)),
        ("combinations_ALPHA", False, (0x16, "yCh_hair", "NewHair_ColorChanging", True)),
        ("combinations_ALPHA", True,  (0x16, "yCh_hair", "NewHair_ColorChanging", True)),
        ("jacket", True,  (0x15, "yCh_gear", "Normal", False)),
        ("body",   True,  (0x19, "yCh_skin", "Normal", False)),
    ]
    for raw, attire, expected in attire_cases:
        got = infer_template(raw, is_attire=attire)
        ok = got == expected
        flag = "OK  " if ok else "FAIL"
        print(f"  {flag}  {raw!r:25s} is_attire={attire!r:5} -> {got}")
        if not ok:
            fails.append((f"{raw} (is_attire={attire})", expected, got))

    # ── Software-default detection ─────────────────────────────────
    print("-" * 72)
    default_cases = [
        # (input, expected_is_default)
        ("lambert1",         True),
        ("Lambert1",         True),
        ("LAMBERT2",         True),
        ("lambert",          True),
        ("blinn3",           True),
        ("phong",            True),
        ("Material",         True),
        ("material",         True),
        ("Material.001",     True),
        ("Material.042",     True),
        ("defaultMat",       True),
        ("Default_OBJ",      True),
        ("01 - Default",     True),
        ("02 - DEFAULT",     True),
        ("Standard",         True),
        ("Standard1",        True),
        ("PhysicalMaterial", True),
        # Real slot names — must NOT be flagged.
        ("body",             False),
        ("head",             False),
        ("jacket",           False),
        ("hair_ALPHA",       False),
        ("standard_jacket",  False),  # don't substring-match
        ("lambert_custom",   False),  # not pure stem+digits
        ("",                 False),
    ]
    for raw, expected in default_cases:
        got = is_software_default_name(raw)
        ok = got == expected
        flag = "OK  " if ok else "FAIL"
        print(f"  {flag}  is_software_default_name({raw!r:22s}) -> {got} (exp {expected})")
        if not ok:
            fails.append((f"is_software_default_name({raw!r})", expected, got))

    # Spot-check the helpers too.
    print("-" * 72)
    helper_cases = [
        ("body:Skinned",       True,  "body.jmtl"),
        ("eye_l",              True,  "eye_l.jmtl"),
        ("glasses_ALPHA",      False, "glasses_ALPHA.jmtl"),
        ("jacket:Skinned",     False, "jacket.jmtl"),
        ("l_kneepad",          False, "l_kneepad.jmtl"),
        ("hair",               True,  "hair.jmtl"),
    ]
    for raw, expect_basemodel, expect_fname in helper_cases:
        got_bm = is_basemodel_slot(raw)
        got_fn = get_jmtl_filename(raw)
        ok = (got_bm == expect_basemodel) and (got_fn == expect_fname)
        flag = "OK  " if ok else "FAIL"
        print(f"  {flag}  {raw!r:30s} basemodel={got_bm} (exp {expect_basemodel}), "
              f"jmtl={got_fn!r} (exp {expect_fname!r})")
        if not ok:
            fails.append((raw, (expect_basemodel, expect_fname), (got_bm, got_fn)))

    print("=" * 72)
    if fails:
        print(f"[material_inference] FAIL: {len(fails)} mismatch(es)")
        for raw, exp, got in fails:
            print(f"   {raw!r}: expected {exp}, got {got}")
        return False
    total = len(cases) + len(helper_cases) + len(attire_cases) + len(default_cases)
    print(f"[material_inference] PASS: {total} cases")
    return True


if __name__ == "__main__":
    import sys
    sys.exit(0 if _self_test() else 1)
