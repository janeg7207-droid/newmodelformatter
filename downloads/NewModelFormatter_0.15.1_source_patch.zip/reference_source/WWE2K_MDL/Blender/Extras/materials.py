import bpy
import json
import os
from ...Link.log import dlog, dwarn


# ─── 2K26 metadata-stamp caches + opt-out ───────────────────────────────────
# The setup_material() stamper runs once per face-group (~30-40 materials/character
# on a Default_Attire import), each doing: find_jmtl_for_material (listdir + isfile
# probes), a disk read, and a FlatBuffer parse. All materials in one import share
# model_path, so the caches below collapse the per-import cost to one directory scan:
#   _JMTL_PATH_CACHE   -> {model_path: {lookup_name: full_jmtl_path}}, built once per
#                         model_path; subsequent stamps are dict lookups.
#   _JMTL_PARSED_CACHE -> {(jmtl_path, mtime): metadata}; re-import skips read+parse,
#                         mtime-keyed so .jmtl edits auto-invalidate.
# Module-level, addon-lifetime, negligible footprint.
# Opt-out: WWE2K_MDL_SKIP_METADATA=1 in the env skips the whole pass (batch arena
# imports that don't need round-trip).

# Read once at import (Blender doesn't re-import addons across files).
_ENABLE_METADATA_STAMPING = os.environ.get("WWE2K_MDL_SKIP_METADATA", "0") != "1"

# {model_path: {lookup_name: full_jmtl_path}} — populated lazily.
_JMTL_PATH_CACHE: dict = {}

# {(jmtl_path, mtime_ns): metadata_dict_or_None} — parsed metadata reuse.
_JMTL_PARSED_CACHE: dict = {}

# {filepath: bool} — _is_loadable_dds verdict. The header sniff is a pure function
# of file bytes, and one texture is referenced by many face groups, so memoizing
# collapses repeated 132-byte header reads to one per unique path.
_DDS_LOADABLE_CACHE: dict = {}

# {filepath: temp_fixed_path | False} — dwCaps-repaired DDS temp copies. 2K26 game DDS
# ship a non-standard dwCaps that Blender 5.x's strict loader rejects; the repair writes
# a corrected temp copy once per source path (see _dds_caps_fixed_copy).
_DDS_CAPS_FIXED_CACHE: dict = {}


def _clear_metadata_caches() -> None:
    """Drop all metadata-stamp caches. Exposed for tests and diagnostics."""
    _JMTL_PATH_CACHE.clear()
    _JMTL_PARSED_CACHE.clear()
    _DDS_LOADABLE_CACHE.clear()


def _build_jmtl_path_index(model_path: str) -> dict:
    """Scan once for every <name>.jmtl reachable from `model_path`.
    Returns {lowercased_lookup_name: full_jmtl_path}.

    Scans <model_dir>/, <model_dir>/Materials*/ (basemodel Materials/ AND attire
    Materials_<scope>/), and each sibling's Materials*/ (one level). Replaces ~38
    parent-dir listings + ~138 isfile probes per attire import with one scan.
    """
    index: dict = {}
    try:
        model_dir = os.path.dirname(model_path)
        if not model_dir:
            return index

        def _scan_dir_for_jmtls(folder: str) -> None:
            """Add every .jmtl in `folder` to the index, keyed by lowercase stem."""
            try:
                with os.scandir(folder) as it:
                    for entry in it:
                        try:
                            if not entry.is_file():
                                continue
                        except OSError:
                            continue
                        name = entry.name
                        if not name.lower().endswith(".jmtl"):
                            continue
                        stem = name[:-5]  # strip ".jmtl"
                        key = stem.lower()
                        # First scanned wins (model_dir > Materials*/ > siblings),
                        # preserving the resolver's search order so attire-scope JMTLs
                        # aren't shadowed by basemodel ones (siblings scanned last).
                        if key not in index:
                            index[key] = entry.path
            except OSError:
                return

        def _scan_for_materials_subdirs(folder: str) -> None:
            """Walk `folder` for any Materials*/ subdir and index its .jmtls."""
            try:
                with os.scandir(folder) as it:
                    for entry in it:
                        try:
                            if not entry.is_dir():
                                continue
                        except OSError:
                            continue
                        if entry.name.lower().startswith("materials"):
                            _scan_dir_for_jmtls(entry.path)
            except OSError:
                return

        # Model's own folder + any Materials*/ underneath it.
        _scan_dir_for_jmtls(model_dir)
        _scan_for_materials_subdirs(model_dir)

        # Sibling folders' Materials*/ subdirs at the same level under
        # the character root.
        parent_dir = os.path.dirname(model_dir)
        if parent_dir and parent_dir != model_dir:
            try:
                with os.scandir(parent_dir) as it:
                    for entry in it:
                        try:
                            if not entry.is_dir():
                                continue
                        except OSError:
                            continue
                        if entry.path == model_dir:
                            continue
                        _scan_for_materials_subdirs(entry.path)
            except OSError:
                pass
    except Exception:
        # Index-building must never crash the import; an empty index makes
        # _stamp_2k26_metadata bail cleanly.
        pass
    return index


def _resolve_jmtl_cached(model_path: str, material_name: str):
    """Cached counterpart to jmtl_resolver.find_jmtl_for_material. Builds a lazy
    per-model_path name→path index for O(1) lookup; mirrors the resolver's fallback
    (full name, then colon-stripped). Returns the path or None.
    """
    index = _JMTL_PATH_CACHE.get(model_path)
    if index is None:
        index = _build_jmtl_path_index(model_path)
        _JMTL_PATH_CACHE[model_path] = index

    if not material_name:
        return None
    key = material_name.lower()
    p = index.get(key)
    if p is not None:
        return p
    if ":" in key:
        prefix = key.split(":", 1)[0]
        return index.get(prefix)
    return None


def _read_jmtl_metadata_cached(jmtl_path: str):
    """Read + parse a JMTL, cached on (path, mtime_ns) so .jmtl edits auto-reparse.
    Returns the metadata dict or None (mirrors extract_full_material_metadata).
    """
    try:
        st = os.stat(jmtl_path)
    except OSError:
        return None
    key = (jmtl_path, st.st_mtime_ns)
    if key in _JMTL_PARSED_CACHE:
        return _JMTL_PARSED_CACHE[key]

    try:
        with open(jmtl_path, "rb") as f:
            data = f.read()
    except OSError as e:
        dwarn(f"[MDL Addon] Could not read JMTL '{jmtl_path}': {e}")
        return None

    try:
        from .jmtl_resolver import extract_full_material_metadata
        meta = extract_full_material_metadata(data)
    except Exception as e:
        dwarn(f"[MDL Addon] JMTL metadata extraction crashed for '{jmtl_path}': {e}")
        meta = None

    _JMTL_PARSED_CACHE[key] = meta
    return meta


def get_file_from_id(texture_id, model_path, find_path="/Textures/"):
    model_folder = os.path.dirname(model_path)
    file_path = model_folder + find_path + texture_id + ".dds"

    if os.path.exists(file_path):
        return file_path
    return None


def _find_principled_bsdf(node_tree):
    """Return the Principled BSDF node in a node tree, or None.

    Replaces the brittle `nodes["Principled BSDF"]` string lookup: non-English
    locales translate the display name (KeyError → half-built tree), and a
    user-customized scene default can omit the BSDF entirely. Matching on
    node.type == 'BSDF_PRINCIPLED' (the internal id) is locale/version-stable.
    """
    if not node_tree:
        return None
    for node in node_tree.nodes:
        if node.type == 'BSDF_PRINCIPLED':
            return node
    return None


# Pixel formats Blender 4.x's DDS loader can't decode — skip bpy.data.images.load
# entirely, else it emits an `IMB_load_image_from_memory: unknown file-format` line
# on stderr (C++ code, unsuppressable from Python) and returns a 0×0 placeholder we'd
# scrub anyway. Pre-flighting avoids both. Source: Blender tracker issue 101405
# (BC7/BC6H/BC4/BC5), open as of Apr 2026.
_BLENDER_UNSUPPORTED_DDS = {"BC7", "BC6H", "BC4", "BC5"}


def _is_loadable_dds(filepath):
    """Return False if the DDS is in a format Blender 4.x can't decode. True for any
    non-DDS or unparseable header (let bpy.data.images.load detect the type).

    Reads only the first 132 bytes (DDS header + DXT10). Sniffs:
      [0:4] magic 'DDS '; [84:88] dwFourCC; [128:132] dxgiFormat if FourCC=='DX10'.
    Unhandled: ATI1/BC4U/BC4S→BC4, ATI2/BC5U/BC5S→BC5; DX10 dxgi 79-84→BC4/5,
    94-96→BC6H, 97-99→BC7.
    """
    if not filepath.lower().endswith(".dds"):
        return True
    cached = _DDS_LOADABLE_CACHE.get(filepath)
    if cached is not None:
        return cached
    verdict = _sniff_dds_loadable(filepath)
    _DDS_LOADABLE_CACHE[filepath] = verdict
    return verdict


def _sniff_dds_loadable(filepath):
    """Uncached DDS header sniff — see _is_loadable_dds for the format notes."""
    try:
        with open(filepath, "rb") as f:
            header = f.read(132)
    except OSError:
        return True
    if len(header) < 128 or header[:4] != b"DDS ":
        return True

    # BC4 + BC6H stay undecodable. BC5/ATI2 (2-channel _flow/_normal) loads on EVERY
    # version tested (2.93+). BC7 decodes only on Blender 4.1+ (verified: 2.93/3.3 return
    # 0x0, 4.1->5.1 load the dwCaps-patched file) — gate on version so old Blender still
    # skips it cleanly instead of emitting the unsuppressable stderr error.
    _bc7_ok = bpy.app.version >= (4, 1, 0)
    fourcc = header[84:88]
    if fourcc in (b"ATI1", b"BC4U", b"BC4S"):          # BC4 — undecodable
        return False
    if fourcc in (b"ATI2", b"BC5U", b"BC5S"):          # BC5 — loads on all versions
        return True
    if fourcc == b"DX10":
        if len(header) < 132:
            return True  # truncated DXT10 header — let Blender try
        dxgi = int.from_bytes(header[128:132], "little")
        if 79 <= dxgi <= 84:                            # BC4
            return False
        if 94 <= dxgi <= 96:                            # BC6H
            return False
        if 97 <= dxgi <= 99:                            # BC7 — Blender 4.1+ only
            return _bc7_ok
    return True


def _dds_caps_fixed_copy(filepath):
    """2K26 game DDS frequently ship dwCaps WITHOUT DDSCAPS_TEXTURE (0x1000) — a header
    quirk Blender 4.x tolerated but Blender 5.x's stricter loader rejects as 'unknown
    file-format', so the texture silently fails to load. Detect that case and return a
    path to a temp copy with dwCaps repaired (cached per source path). Returns None when
    the file loads fine as-is (load the original).

    Only the 4-byte dwCaps field at offset 108 is touched — setting DDSCAPS_TEXTURE
    (+ COMPLEX|MIPMAP when a mip chain is present). Pixel data is untouched and the
    original game file is never modified.
    """
    cached = _DDS_CAPS_FIXED_CACHE.get(filepath)
    if cached is not None:
        return cached or None
    result = False
    try:
        if filepath.lower().endswith(".dds"):
            data = bytearray(open(filepath, "rb").read())
            if len(data) >= 128 and data[:4] == b"DDS ":
                caps = int.from_bytes(data[108:112], "little")
                if not (caps & 0x1000):  # DDSCAPS_TEXTURE missing -> Blender 5.x rejects
                    mips = int.from_bytes(data[28:32], "little")
                    newcaps = 0x1000
                    if mips and mips > 1:
                        newcaps |= 0x8 | 0x400000  # COMPLEX | MIPMAP
                    data[108:112] = newcaps.to_bytes(4, "little")
                    import tempfile, hashlib
                    key = hashlib.md5(filepath.encode("utf-8", "replace")).hexdigest()[:16]
                    tmp = os.path.join(tempfile.gettempdir(), "wwe2k_ddsfix_" + key + ".dds")
                    if not os.path.exists(tmp):
                        with open(tmp, "wb") as f:
                            f.write(data)
                    result = tmp
    except OSError:
        result = False
    _DDS_CAPS_FIXED_CACHE[filepath] = result
    return result or None


def _load_image_safely(filepath):
    """Load an image with a pre-flight format check + post-load validity check.

    Pre-flight: skip undecodable DDS (BC7/BC6H/BC4/BC5) without calling
    bpy.data.images.load (avoids the unsuppressable stderr line + a 0×0 placeholder).
    Post-load: images.load does NOT raise on unreadable files — it creates a 0×0,
    no-pixel datablock. Assigning that to a ShaderNodeTexImage is API-valid, but the
    next preview-rasterizer pass dereferences uninitialized memory and crashes the
    app ("first blender crash, happened when I selected a material and added a node").
    So we check dimensions and scrub any 0×0 placeholder before returning.
    """
    if not _is_loadable_dds(filepath):
        return None

    # 2K26 game DDS often ship a non-standard dwCaps (no DDSCAPS_TEXTURE), which
    # Blender 5.x's strict DDS loader rejects even for plain DXT1/DXT5 — the texture
    # silently fails to load. Load a dwCaps-repaired temp copy when needed so it loads
    # (and the unsuppressable stderr "unknown file-format" line never fires).
    load_path = _dds_caps_fixed_copy(filepath) or filepath

    try:
        img = bpy.data.images.load(load_path, check_existing=True)
    except Exception as e:
        # bpy.data.images.load is documented non-throwing, but defensive
        # against future API tightening and against OS-level read errors.
        dwarn(f"[MDL Addon] Image load failed for '{filepath}': {e}")
        return None

    if img is None:
        return None

    if load_path != filepath:
        # Name it after the ORIGINAL file (not the temp copy) so the UI + material read
        # cleanly; the datablock still points at the repaired temp for this session.
        try:
            img.name = os.path.basename(filepath)
        except Exception:
            pass

    # Reading .size forces dimension resolution from the header (broken files report
    # 0,0). Wrapped — some 4.x builds raise on .size for an unresolved image.
    try:
        w, h = img.size
    except Exception:
        try:
            bpy.data.images.remove(img)
        except Exception:
            pass
        return None

    if w == 0 or h == 0:
        # Remove the 0×0 placeholder so nothing (esp. the caller's
        # ShaderNodeTexImage.image assignment) can reference it and crash the preview.
        try:
            bpy.data.images.remove(img)
        except Exception:
            pass
        return None

    return img


def _stamp_hair_roundtrip_params(mat, meta) -> None:
    """Preserve hair's nested-table discriminators in export override JSON.

    ``vc_2k26_template`` identifies byte 0x16, but it cannot distinguish its
    three incompatible inner table layouts. The optional type-1/type-2 length
    byte is likewise not represented by the Blender shader graph. Store those
    source values in the same JSON override channel the exporter already reads.
    NPC texture refs are included because their inner-table hashes otherwise
    disappear when the referenced DDS is unavailable during import.

    The helper is intentionally best-effort: malformed pre-existing JSON is
    replaced by the recoverable source metadata, and assignment failures are
    ignored so metadata stamping can never abort model import.
    """
    try:
        hair_type = meta.get("hair_type")
        if hair_type not in (1, 2, 3):
            return

        raw = mat.get("vc_2k26_params", "")
        merged = {}
        if isinstance(raw, dict):
            merged.update(raw)
        elif isinstance(raw, str) and raw.strip():
            try:
                decoded = json.loads(raw)
                if isinstance(decoded, dict):
                    merged.update(decoded)
            except (TypeError, ValueError):
                pass

        # Source discriminators win over stale material properties. This is
        # called during import, where the on-disk JMTL is authoritative.
        merged["hairType"] = int(hair_type)
        hair_length = meta.get("hair_length")
        if hair_type in (1, 2) and hair_length is not None:
            merged["hairLength"] = int(hair_length) & 0xFF
        else:
            # A reused Blender material must not carry a type-1/2 length byte
            # into NPC hair, whose inner field 0 is an f32.
            merged.pop("hairLength", None)

        if hair_type == 3:
            if meta.get("normal_map_hash") is not None:
                merged["nrMap@ref"] = int(meta["normal_map_hash"])
            if meta.get("color_map_hash") is not None:
                merged["colorMap@ref"] = int(meta["color_map_hash"])

        mat["vc_2k26_params"] = json.dumps(
            merged, sort_keys=True, separators=(",", ":")
        )
    except Exception:
        # Metadata is an import aid, never a reason to fail model loading.
        return


def _stamp_2k26_metadata(mat, model_path, material_name):
    """Stamp 2K26 shader/template metadata onto `mat` as custom properties for
    export round-trip. Best-effort (guarded): a missing/unparseable JMTL just leaves
    the props off, and the export side falls back to name-based template inference.

    Properties (when available):
      mat["vc_2k26_template"]        str  "<shader>::<type>" (e.g. "yCh_skin::Normal")
      mat["vc_2k26_alpha"]           bool default False
      mat["vc_2k26_color_map_hash"]  int  u64 FNV1a, only when JMTL had one
      mat["vc_2k26_normal_map_hash"] int  u64 FNV1a, only when JMTL had one
      mat["vc_2k26_shader_byte"]     int  raw byte (e.g. 0x19)
      mat["vc_2k26_attire_scope"]    str  ""/"<scope>" — Materials_<scope>/ folder
      mat["vc_2k26_params"]          str  hair variant/ref JSON for round-trip

    The u64 colorMap/normalMap hashes exceed int32, but Blender's IDProperty bridge
    preserves full 64-bit values as a "long" when the Python int is wide (2.83+), so
    we assign the raw int directly. See module-top for the cache + opt-out details.
    """
    if not _ENABLE_METADATA_STAMPING:
        return

    if mat is None:
        return

    # Default alpha False ("use template default" on export; matches every shipped
    # 2K26 material — the JMTL alpha hint isn't currently extracted).
    try:
        mat["vc_2k26_alpha"] = False
    except Exception:
        # Basic property assignment failed (e.g. mocked mat in a self-test) — bail.
        return

    try:
        jmtl_path = _resolve_jmtl_cached(model_path, material_name)
    except Exception:
        jmtl_path = None

    if not jmtl_path:
        # No JMTL → 2K22-2K25 (no metadata) or a 2K26 with a missing JMTL; export
        # falls back to name-based inference either way.
        return

    # Attire scope from the JMTL's parent dir: basemodel uses Materials/, attire
    # slots use Materials_<scope>/ (e.g. Materials_casual/); "" = default scope.
    attire_scope = ""
    try:
        parent_name = os.path.basename(os.path.dirname(jmtl_path))
        if parent_name.lower().startswith("materials_"):
            attire_scope = parent_name[len("materials_"):]
    except Exception:
        attire_scope = ""

    try:
        mat["vc_2k26_attire_scope"] = attire_scope
    except Exception:
        pass

    # Read + parse the JMTL (cached on path+mtime).
    meta = _read_jmtl_metadata_cached(jmtl_path)

    if meta is None:
        # File exists but isn't a parseable JMTL — keep the alpha+scope partial stamp;
        # export infers the rest from the name.
        dlog(f"[MDL Addon] JMTL metadata unavailable for '{jmtl_path}' (not a parseable Mate FlatBuffer)")
        return

    # Stamp each available field; per-field try/except so one failure doesn't lose
    # the others.
    for key, val in (
        ("vc_2k26_shader_byte", int(meta["shader_byte"])),
        ("vc_2k26_template",
         f'{meta["shader_name"]}::{meta["type_name"]}'),
    ):
        try:
            mat[key] = val
        except Exception:
            pass

    if meta.get("color_map_hash") is not None:
        try:
            mat["vc_2k26_color_map_hash"] = int(meta["color_map_hash"])
        except Exception:
            pass
    if meta.get("normal_map_hash") is not None:
        try:
            mat["vc_2k26_normal_map_hash"] = int(meta["normal_map_hash"])
        except Exception:
            pass

    _stamp_hair_roundtrip_params(mat, meta)

    dlog(
        f"[MDL Addon] Stamped 2K26 metadata: {material_name} -> "
        f"shader=0x{meta['shader_byte']:02x} "
        f"template={meta['shader_name']}::{meta['type_name']} "
        f"scope={attire_scope or '(default)'}"
    )


# ─── secondary-map resolution (by Textures-folder naming: <stem>_<suffix>.dds) ──────
def _textures_dir(model_path):
    return os.path.join(os.path.dirname(model_path), "Textures")


def _list_textures(textures_dir):
    """Case-insensitive {lowercase_name: real_name} of the Textures folder, or {}."""
    try:
        return {e.lower(): e for e in os.listdir(textures_dir)}
    except OSError:
        return {}


def _find_dds(entries, textures_dir, stem, suffixes):
    """First existing <stem>_<suffix>.dds (case-insensitive) for any suffix, or None."""
    if not stem or not entries:
        return None
    for suf in suffixes:
        real = entries.get((stem + "_" + suf + ".dds").lower())
        if real:
            return os.path.join(textures_dir, real)
    return None


def _stem_from_color(color_path):
    """'.../head_color.dds' -> 'head' (strip the trailing _color, case-insensitive)."""
    base = os.path.splitext(os.path.basename(color_path))[0]
    return base[:-6] if base.lower().endswith("_color") else base


def _material_stem(material_name):
    """Texture stem for a hair-like material: strip ':Skinned'/trailing colon AND a
    trailing '_ALPHA' (2K26 appends it to alpha-cutout slots; the texture file omits it),
    keeping the variant index ('hair_ALPHA:skinned' -> 'hair', 'hair2' -> 'hair2',
    'combinations_ALPHA' -> 'combinations')."""
    s = (material_name or "").split(":")[0].strip()
    if s.lower().endswith("_alpha"):
        s = s[:-6]
    return s


def _dds_has_alpha(path):
    """Cheap header sniff: does this DDS color map carry a real alpha channel? DXT2/3/4/5
    (BC2/BC3) and BC7 do; DXT1 (BC1) / BC5 do not. Used to wire color.alpha -> BSDF Alpha
    (cutout) for meshes whose transparency lives in the color map's alpha (chainmail tops,
    mesh fabric). Gating on format keeps opaque DXT1 colors (skin / most attire) opaque."""
    try:
        h = open(path, "rb").read(132)
    except OSError:
        return False
    if len(h) < 88 or h[:4] != b"DDS ":
        return False
    fourcc = h[84:88]
    if fourcc in (b"DXT2", b"DXT3", b"DXT4", b"DXT5"):
        return True
    if fourcc == b"DX10" and len(h) >= 132:
        if int.from_bytes(h[128:132], "little") in (98, 99):   # BC7 UNORM / UNORM_SRGB
            return True
    return False


# ─── version-safe shader-node helpers (verified 2.93 -> 5.1) ────────────────────────
def _make_separate_color(nt):
    """Separate-RGB(/Color) node; outputs[0/1/2] = R/G/B, input = inputs[0]. Neither id is
    universal: ShaderNodeSeparateColor was added in 3.3, ShaderNodeSeparateRGB removed in
    5.1 — pick by VERSION, not try/except (a caught nodes.new() of an unknown type still
    prints Blender's 'Node type ... undefined' line to the console)."""
    if bpy.app.version >= (3, 3, 0):
        return nt.nodes.new('ShaderNodeSeparateColor')
    return nt.nodes.new('ShaderNodeSeparateRGB')


def _make_combine_color(nt):
    """Combine-RGB(/Color) node; inputs[0/1/2] = R/G/B, output = outputs[0]. Mirror of
    _make_separate_color: CombineColor added in 3.3, CombineRGB removed in 5.1."""
    if bpy.app.version >= (3, 3, 0):
        return nt.nodes.new('ShaderNodeCombineColor')
    return nt.nodes.new('ShaderNodeCombineRGB')


def _active_color_name(mesh):
    """Resolve the mesh's active color-attribute NAME across 2.93->5.1 (no single attr
    works on all eras)."""
    attrs = getattr(mesh, "attributes", None)
    if attrs is not None and hasattr(attrs, "active_color_name"):   # 4.x/5.x
        n = attrs.active_color_name
        if n:
            return n
    ca = getattr(mesh, "color_attributes", None)                    # 3.3+
    if ca is not None:
        try:
            if ca.active_color is not None:
                return ca.active_color.name
        except Exception:
            pass
        if len(ca) > 0:
            return ca[0].name
    vc = getattr(mesh, "vertex_colors", None)                       # 2.9x legacy
    if vc is not None:
        try:
            if vc.active is not None:
                return vc.active.name
        except Exception:
            pass
        if len(vc) > 0:
            return vc[0].name
    return ""


def _make_color_attribute_node(nt, mesh):
    """ShaderNodeVertexColor bound to the mesh's active color layer by explicit name
    (exists 2.93->5.1; the empty-name sentinel follows render-active which can diverge
    on 3.x)."""
    n = nt.nodes.new('ShaderNodeVertexColor')
    name = _active_color_name(mesh)
    if name:
        try:
            n.layer_name = name
        except Exception:
            pass
    return n


def _set_material_alpha(mat, mode='BLEND'):
    """Make `mat` render transparent on every Blender 2.93->5.1.
    mode 'BLEND' = true alpha (soft, e.g. eyelashes); 'CLIP' = alpha test (cutout, e.g.
    hair cards — avoids the EEVEE blend-sort 'see-through' on overlapping cards over the
    scalp). blend_method drives <=4.1 EEVEE + Cycles; surface_render_method is what 4.2+
    EEVEE-Next obeys (DITHERED for cutout, BLENDED for true alpha); shadow_method gone 4.3."""
    clip = (mode == 'CLIP')
    if hasattr(mat, "blend_method"):
        mat.blend_method = 'CLIP' if clip else 'BLEND'
    if hasattr(mat, "shadow_method"):
        mat.shadow_method = 'CLIP' if clip else 'HASHED'
    if hasattr(mat, "surface_render_method"):
        mat.surface_render_method = 'DITHERED' if clip else 'BLENDED'


def _attach_normal_map(nt, bsdf, nrm_path):
    """2K26 _nrm is a PACKED map (verified across the corpus): R,G = tangent normal X,Y
    (Z reconstructed), B = ROUGHNESS, A = METALLIC mask. Split it: (R,G) -> Normal Map ->
    BSDF Normal; B -> BSDF Roughness; A -> BSDF Metallic. Feeding the raw RGB straight into
    the Normal Map node (the old behaviour) misread the roughness as the normal's Z -> the
    chrome / 'wet drip' artifact + a uniform sheen."""
    nrm = _load_image_safely(nrm_path)
    if nrm is None:
        return
    try:
        nrm.colorspace_settings.name = 'Non-Color'
    except Exception:
        pass
    ntex = nt.nodes.new('ShaderNodeTexImage')
    ntex.image = nrm
    ntex.location = (-1250, -250)
    sep = _make_separate_color(nt)
    sep.location = (-980, -250)
    nt.links.new(sep.inputs[0], ntex.outputs['Color'])
    # Normal from R,G only — recombine (R, G, 1.0) so B (roughness) never reaches the
    # normal. 2K26 normals are gentle (std ~0.05), so forcing Z=up is visually identical
    # to reconstructing Z = sqrt(1 - x^2 - y^2).
    comb = _make_combine_color(nt)
    comb.location = (-700, -200)
    nt.links.new(comb.inputs[0], sep.outputs[0])   # R -> normal X
    nt.links.new(comb.inputs[1], sep.outputs[1])   # G -> normal Y
    try:
        comb.inputs[2].default_value = 1.0          # B -> "up"
    except Exception:
        pass
    nmap = nt.nodes.new('ShaderNodeNormalMap')
    nmap.location = (-460, -300)
    nt.links.new(nmap.inputs['Color'], comb.outputs[0])
    n_in = bsdf.inputs.get('Normal')
    if n_in is not None:
        nt.links.new(n_in, nmap.outputs['Normal'])
    # Roughness from the BLUE channel (dark drips -> glossy/wet paint, light skin -> matte).
    r_in = bsdf.inputs.get('Roughness')
    if r_in is not None:
        nt.links.new(r_in, sep.outputs[2])          # B -> roughness
    # Metallic from the ALPHA channel (chainmail / metal links). Most _nrm carry a const-0
    # alpha -> Metallic 0 (non-metal), so this is self-protecting: only maps that actually
    # paint alpha read as metal. Gate on the header so a BC5/DXT1 _nrm (no alpha plane ->
    # Image 'Alpha' defaults to 1.0) can't force the whole mesh to chrome.
    if _dds_has_alpha(nrm_path):
        m_in = bsdf.inputs.get('Metallic')
        if m_in is not None:
            nt.links.new(m_in, ntex.outputs['Alpha'])   # A -> metallic


def setup_material(mat, source_group, model_path, mesh=None):
    """Build a shader-type-aware Blender node graph for a 2K26 material.

    Forks on the detected shader (material_inference) + the on-disk texture set:
      * HAIR (rai+flow suffix pair, or shader 0x16): base color is PROCEDURAL -> driven
        by the mesh's vertex color; the _rai map's GREEN channel is the strand alpha
        (verified across the corpus). vertex color -> Base Color, rai.G -> Alpha, blend.
      * EYELASH (0x14) / alpha shaders: the color map carries its own (DXT5) alpha.
        color -> Base Color, color.Alpha -> Alpha, blend.
      * head/body/eye/teeth/attire: color -> Base Color (+ _nrm normal map when present
        and Blender can decode it).
    Returns True if a texture/graph was built (caller switches the viewport to material
    preview), False to leave a plain image-less slot.
    """
    # --- shader type (defensive; None on any failure) ---
    shader_byte = None
    is_alpha = False
    try:
        from .material_inference import infer_template
        shader_byte, _sname, _tname, is_alpha = infer_template(source_group.material)
    except Exception:
        shader_byte, is_alpha = None, False

    # --- resolve the primary color map (2K22-25 .mtls id, then 2K26 .jmtl hash) ---
    diffuse_map = None
    if source_group.diffuse_id:
        diffuse_map = get_file_from_id(source_group.diffuse_id, model_path)
    if not diffuse_map:
        try:
            from .jmtl_resolver import resolve_diffuse_path
            diffuse_map = resolve_diffuse_path(model_path, source_group.material)
        except Exception:
            diffuse_map = None

    # --- stamp 2K26 metadata regardless of texture (export needs the shader byte/hashes) ---
    try:
        _stamp_2k26_metadata(mat, model_path, source_group.material)
    except Exception as e:
        dwarn(f"[MDL Addon] 2K26 metadata stamp failed for "
              f"'{source_group.material}': {e}")

    # --- locate the Textures dir + sibling maps by stem ---
    tex_dir = _textures_dir(model_path)
    entries = _list_textures(tex_dir)
    stem = _stem_from_color(diffuse_map) if diffuse_map else _material_stem(source_group.material)
    rai_map  = _find_dds(entries, tex_dir, stem, ("rai",))
    flow_map = _find_dds(entries, tex_dir, stem, ("flow",))   # noqa: F841 (future: anisotropy)
    nrm_map  = _find_dds(entries, tex_dir, stem, ("nrm", "normal"))

    # Hair = the _rai/_flow suffix pair (catches named cards: joe/potato/hair2), or 0x16.
    is_hair = (shader_byte == 0x16) or bool(rai_map and flow_map)

    if not diffuse_map and not (is_hair and rai_map):
        return False  # nothing to build

    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = _find_principled_bsdf(nt)
    if bsdf is None:
        return False
    base_in = bsdf.inputs.get('Base Color')
    alpha_in = bsdf.inputs.get('Alpha')

    # ── HAIR: vertex-color base + rai.GREEN alpha ──
    if is_hair:
        if base_in is not None and mesh is not None:
            vcol = _make_color_attribute_node(nt, mesh)
            vcol.location = (-600, 300)
            nt.links.new(base_in, vcol.outputs['Color'])
        if rai_map is not None:
            rimg = _load_image_safely(rai_map)
            if rimg is not None:
                try:
                    rimg.colorspace_settings.name = 'Non-Color'
                except Exception:
                    pass
                rt = nt.nodes.new('ShaderNodeTexImage')
                rt.image = rimg
                rt.location = (-1050, -60)
                sep = _make_separate_color(nt)
                sep.location = (-680, -40)
                nt.links.new(sep.inputs[0], rt.outputs['Color'])
                # 2K26 rai packs R = roughness, G = alpha (strand coverage), B = irradiance.
                if alpha_in is not None:
                    nt.links.new(alpha_in, sep.outputs[1])   # G -> Alpha (strand cutout)
                    # CLIP (alpha test): overlapping hair cards over the scalp blend-sort
                    # badly in EEVEE and read 'see-through'. Cutout keeps strands solid.
                    _set_material_alpha(mat, 'CLIP')
                rough_in = bsdf.inputs.get('Roughness')
                if rough_in is not None:
                    nt.links.new(rough_in, sep.outputs[0])   # R -> Roughness
        return True

    # ── non-hair: needs the color map ──
    if not diffuse_map:
        return False
    img = _load_image_safely(diffuse_map)
    if img is None:
        return False
    try:
        img.colorspace_settings.name = 'sRGB'
    except Exception:
        pass
    tex = nt.nodes.new('ShaderNodeTexImage')
    tex.image = img
    tex.location = (-700, 300)
    if base_in is not None:
        nt.links.new(base_in, tex.outputs['Color'])

    # eyelash (0x14) / alpha shaders: the color map's own alpha = soft transparency
    if (shader_byte == 0x14 or is_alpha) and alpha_in is not None:
        nt.links.new(alpha_in, tex.outputs['Alpha'])
        _set_material_alpha(mat, 'BLEND')
    # other meshes whose cutout lives in the color map's alpha (chainmail tops, mesh
    # fabric, etc.) -> alpha-test cutout. _dds_has_alpha gates on the DXT5/BC7 format so
    # opaque DXT1 colors (skin / most attire) stay fully opaque.
    elif alpha_in is not None and _dds_has_alpha(diffuse_map):
        nt.links.new(alpha_in, tex.outputs['Alpha'])
        _set_material_alpha(mat, 'CLIP')

    # normal map (BC7 — _is_loadable_dds gates it to Blender 4.1+; BC5 on all)
    if nrm_map is not None:
        _attach_normal_map(nt, bsdf, nrm_map)

    return True


def setMaterials(obj, groups, model_path, load_textures=True):
    """Build material slots + face-group assignments for the mesh.

    `load_textures=False` skips the DDS load inside setup_material but still creates
    the slots + face-group ranges (model structure, not appearance) — honors the
    Python-side "Load Material Textures" checkbox (the DLL flag handles C++). Default
    True preserves legacy behavior.
    """
    toggle_matcap = False

    for index, group in enumerate(groups):
        # `or` coerces a None/empty label to a placeholder — materials.new(None)
        # raises TypeError (an early file can leave a face-group label null).
        # No-op for valid files (real non-empty material names).
        mat = bpy.data.materials.new(name=group.material or "Material")

        # Order matters: append the material BEFORE writing face.material_index.
        # 4.2+ bounds-checks material_index (geometry-nodes attribute unification),
        # so an OOB value corrupts attribute storage and crashes (now or next
        # depsgraph eval). The old ordering wrote `index` while the slot count was
        # still `index` — OOB by one every iteration; pre-4.2 didn't validate, so it
        # only crashed 4.2/4.3.
        obj.data.materials.append(mat)

        # Face groups are contiguous (getMaterialFaceGroup returns a face_begin/
        # face_end range), so slice O(group_size) instead of the old full-polygon
        # scan (O(total_polys * groups) — real cost on arena imports).
        # Clamp the DLL range to the actual polygon count: a malformed file (or a
        # range whose triangles were stripped as degenerate) can leave face_end
        # past the polygon count or face_begin negative — a raw Python slice would
        # then index from the end and silently mis-assign material_index. Clamping
        # is a strict no-op for valid in-range contiguous ranges.
        npoly = len(obj.data.polygons)
        fb = max(0, min(group.face_begin, npoly))
        fe = max(fb, min(group.face_end, npoly))
        for face in obj.data.polygons[fb:fe]:
            face.material_index = index

        # Skip texture resolve + load when off — the slot keeps its name + face range
        # for the user to wire later.
        if not load_textures:
            continue

        # If any material is textured, switch the viewport to material mode.
        # Pass the mesh so the hair branch can bind the active vertex-color attribute.
        if (setup_material(mat, group, model_path, obj.data)):
            toggle_matcap = True

    if (toggle_matcap):
        try:
            bpy.context.space_data.shading.light = 'MATCAP'
            bpy.context.space_data.shading.color_type = 'TEXTURE'
        except (AttributeError, TypeError):
            # Headless / non-3D-view context — skip the viewport tweak.
            pass

    return


# --- Self-test ----------------------------------------------------------------

class _MockMaterial:
    """Minimal stand-in for bpy.types.Material — supports `name` and the
    `mat[key] = value` / `mat[key]` custom-property idiom that
    `_stamp_2k26_metadata` uses. Lets us exercise the stamper outside
    Blender."""

    __slots__ = ("name", "_props")

    def __init__(self, name):
        self.name = name
        self._props = {}

    def __setitem__(self, key, value):
        self._props[key] = value

    def __getitem__(self, key):
        return self._props[key]

    def __contains__(self, key):
        return key in self._props

    def get(self, key, default=None):
        return self._props.get(key, default)


def _self_test() -> bool:
    """Exercise the 2K26 metadata extractor + stamper against a sample JMTL
    (Characters/100_The_Rock_2017/BaseModel/Materials/body.jmtl) and print PASS/FAIL:
    expected shader byte 0x19 yCh_skin Normal + all vc_2k26_* props on the mock.
    """
    # Maintainer self-test fixtures. Point WWE2K_MDL_SAMPLE_CHARS at a local
    # Characters/ folder to run this; it is never exercised by the shipped
    # addon (guarded by __main__ below).
    _chars = os.environ.get("WWE2K_MDL_SAMPLE_CHARS", "")
    sample_jmtl = os.path.join(
        _chars, "100_The_Rock_2017", "BaseModel", "Materials", "body.jmtl")
    sample_model = os.path.join(
        _chars, "100_The_Rock_2017", "BaseModel", "baseModel.model")

    print("[materials._self_test] sample:", sample_jmtl)

    if not os.path.isfile(sample_jmtl):
        print("[materials._self_test] FAIL: sample JMTL not present "
              "on this machine — cannot run end-to-end check.")
        return False

    try:
        from .jmtl_resolver import extract_full_material_metadata
    except Exception:
        # Allow `python -m materials` style invocation outside the
        # package by falling back to a direct import.
        try:
            from jmtl_resolver import extract_full_material_metadata
        except Exception as e:
            print(f"[materials._self_test] FAIL: could not import "
                  f"extract_full_material_metadata: {e}")
            return False

    # Read + parse the sample.
    with open(sample_jmtl, "rb") as f:
        data = f.read()
    meta = extract_full_material_metadata(data)

    print("[materials._self_test] extracted metadata:", meta)

    if meta is None:
        print("[materials._self_test] FAIL: extractor returned None.")
        return False

    # body.jmtl on a basemodel character should always be 0x19 yCh_skin
    # — verified by direct vtable inspection of the sample at write
    # time. If a future game patch reshuffles the shader byte map we
    # want this test to flag it loudly.
    expected_byte = 0x19
    if meta["shader_byte"] != expected_byte:
        print(f"[materials._self_test] FAIL: shader_byte was "
              f"0x{meta['shader_byte']:02x}, expected 0x{expected_byte:02x}")
        return False
    if meta["shader_name"] != "yCh_skin" or meta["type_name"] != "Normal":
        print(f"[materials._self_test] FAIL: template name mismatch: "
              f"{meta['shader_name']}::{meta['type_name']}")
        return False
    if meta["color_map_hash"] is None:
        print("[materials._self_test] FAIL: color_map_hash was None — "
              "body shader is supposed to bind a colorMap.")
        return False

    # Exercise the stamper end-to-end against a mock material. We can't
    # rely on the bpy.types.Material type here — the mock supports the
    # same getitem/setitem protocol that ID custom properties use, which
    # is all _stamp_2k26_metadata actually touches.
    mock = _MockMaterial(name="body")
    try:
        _stamp_2k26_metadata(mock, sample_model, "body:Skinned")
    except Exception as e:
        print(f"[materials._self_test] FAIL: stamper raised: {e}")
        return False

    required = {
        "vc_2k26_alpha":          False,
        "vc_2k26_shader_byte":    expected_byte,
        "vc_2k26_template":       "yCh_skin::Normal",
        "vc_2k26_attire_scope":   "",
    }
    for k, expected in required.items():
        got = mock.get(k, "<missing>")
        if got != expected:
            print(f"[materials._self_test] FAIL: mock[{k!r}] was "
                  f"{got!r}, expected {expected!r}")
            return False

    if "vc_2k26_color_map_hash" not in mock:
        print("[materials._self_test] FAIL: vc_2k26_color_map_hash not stamped")
        return False

    print("[materials._self_test] mock material after stamp:", mock._props)
    print("[materials._self_test] PASS")
    return True


if __name__ == "__main__":
    import sys
    sys.exit(0 if _self_test() else 1)
