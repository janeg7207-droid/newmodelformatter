import bpy
import re
from bpy.props import StringProperty, EnumProperty, PointerProperty
from bpy.types import Panel, Operator, PropertyGroup
from ...Link.log import derror


HIERARCHY_CHAIN = ["J_Root", "J_Hips", "J_Spine1", "J_Spine2", "J_Neck", "J_Head", "J_Hair"]


# ═══════════════════════════════════════════════════════════════════════════
#  UTILITY FUNCTIONS (unchanged)
# ═══════════════════════════════════════════════════════════════════════════

def get_meshes_from_collection(collection):
    if not collection:
        return []
    meshes = []
    for obj in collection.objects:
        if obj.type == 'MESH':
            meshes.append(obj)
    for child_col in collection.children:
        meshes.extend(get_meshes_from_collection(child_col))
    return meshes


def get_armatures_for_meshes(meshes):
    armatures = set()
    mesh_to_armature = {}
    for mesh in meshes:
        for modifier in mesh.modifiers:
            if modifier.type == 'ARMATURE' and modifier.object:
                armatures.add(modifier.object)
                mesh_to_armature[mesh] = modifier.object
                break
    return list(armatures), mesh_to_armature


def is_valid_name(name):
    if not name or len(name) < 2:
        return False
    try:
        return sum(1 for c in name if c.isascii() and c.isprintable()) >= len(name) * 0.8
    except (TypeError, AttributeError):
        return False


def get_mesh_data_items(self, context):
    props = context.scene.hair_slot_props
    items = [('NONE', '-- Select --', 'No mesh selected')]
    if not props.target_collection:
        return items
    meshes = get_meshes_from_collection(props.target_collection)
    seen = set()
    for mesh in meshes:
        if mesh.data and mesh.data.name not in seen:
            data_name = mesh.data.name
            if is_valid_name(data_name):
                seen.add(data_name)
                items.append((data_name, data_name, f"Data: {data_name} (obj: {mesh.name})"))
    return items


def find_mesh_by_data_prefix(meshes, prefix):
    for mesh in meshes:
        if mesh.data and is_valid_name(mesh.data.name):
            name_upper = mesh.data.name.upper()
            if name_upper.startswith(f'{prefix}_') and 'HAIR' in name_upper:
                return mesh.data.name
    for mesh in meshes:
        if mesh.data and is_valid_name(mesh.data.name):
            if mesh.data.name.upper().startswith(f'{prefix}_'):
                return mesh.data.name
    return 'NONE'


def update_collection(self, context):
    props = context.scene.hair_slot_props
    if not props.target_collection:
        props.detection_status = "No collection"
        return
    meshes = get_meshes_from_collection(props.target_collection)
    if not meshes:
        props.detection_status = "No meshes"
        return
    props.m_mesh = find_mesh_by_data_prefix(meshes, 'M')
    props.s_mesh = find_mesh_by_data_prefix(meshes, 'S')
    m_status = "found" if props.m_mesh != 'NONE' else "missing"
    s_status = "found" if props.s_mesh != 'NONE' else "missing"
    props.detection_status = f"M_: {m_status}  S_: {s_status}"


# ═══════════════════════════════════════════════════════════════════════════
#  PROPERTIES
# ═══════════════════════════════════════════════════════════════════════════

class HairSlotProperties(PropertyGroup):
    target_collection: PointerProperty(
        name="Collection", type=bpy.types.Collection, update=update_collection)
    m_mesh: EnumProperty(
        name="M_ Data", description="Visible mesh data (M_Hair)",
        items=get_mesh_data_items)
    s_mesh: EnumProperty(
        name="S_ Data", description="Physics driver mesh data (S_Hair)",
        items=get_mesh_data_items)
    search_prefix: StringProperty(name="Prefix", default="hair")
    replace_letter: EnumProperty(
        name="Letter",
        items=[(f"LETTER_{chr(i)}", chr(i), "") for i in range(65, 91)],
        default="LETTER_A")
    slot_number: EnumProperty(
        name="Slot",
        items=[(str(i), str(i), "") for i in range(1, 21)],
        default="1")
    detection_status: StringProperty(name="Status", default="")


# ═══════════════════════════════════════════════════════════════════════════
#  OPERATORS (logic unchanged)
# ═══════════════════════════════════════════════════════════════════════════

def rename_bones(context, props):
    meshes = get_meshes_from_collection(props.target_collection)
    armatures, mesh_to_armature = get_armatures_for_meshes(meshes)
    if not armatures:
        return 0
    prefix = props.search_prefix
    new_letter = props.replace_letter.split('_')[1].lower()
    pattern1 = re.compile(f"^({re.escape(prefix)}_)([a-zA-Z])(.*)$", re.IGNORECASE)
    pattern2 = re.compile(f"^(J_{re.escape(prefix)}_)([a-zA-Z])$", re.IGNORECASE)
    original_active = context.view_layer.objects.active
    total = 0
    for armature in armatures:
        bpy.context.view_layer.objects.active = armature
        bpy.ops.object.mode_set(mode='EDIT')
        renames = []
        for bone in armature.data.edit_bones:
            match = pattern1.match(bone.name)
            if match:
                new_name = f"{match.group(1)}{new_letter}{match.group(3)}"
                renames.append((bone.name, new_name))
                continue
            match = pattern2.match(bone.name)
            if match:
                new_name = f"{match.group(1)}{new_letter}"
                renames.append((bone.name, new_name))
        renames.sort(key=lambda x: len(x[0]), reverse=True)
        meshes_for_arm = [m for m, a in mesh_to_armature.items() if a == armature]
        for old_name, new_name in renames:
            bone = armature.data.edit_bones.get(old_name)
            if bone:
                for mesh in meshes_for_arm:
                    if old_name in mesh.vertex_groups:
                        mesh.vertex_groups[old_name].name = new_name
                bone.name = new_name
                total += 1
        bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.view_layer.objects.active = original_active
    return total


def rename_mesh_data(data_name, prefix, slot_num):
    if data_name == 'NONE':
        return None
    data = bpy.data.meshes.get(data_name)
    if not data:
        return None
    old_name = data.name
    match = re.match(rf'^{prefix}_(\w+?)(\d*)$', old_name, re.IGNORECASE)
    if match:
        base = match.group(1)
    else:
        return None
    new_name = f"{prefix}_{base}" if slot_num == 1 else f"{prefix}_{base}{slot_num}"
    if old_name != new_name:
        data.name = new_name
        return (old_name, new_name)
    return None


class HAIRSLOT_OT_refresh(Operator):
    """Refresh auto-detection of M_ and S_ meshes"""
    bl_idname = "hair_slot.refresh"
    bl_label = "Refresh"
    bl_options = {'REGISTER'}

    def execute(self, context):
        props = context.scene.hair_slot_props
        if not props.target_collection:
            self.report({'ERROR'}, "Select a collection first")
            return {'CANCELLED'}
        update_collection(props, context)
        self.report({'INFO'}, f"M_: {props.m_mesh} | S_: {props.s_mesh}")
        return {'FINISHED'}


class HAIRSLOT_OT_update_all(Operator):
    """Rename bones and mesh data for the target slot"""
    bl_idname = "hair_slot.update_all"
    bl_label = "Update All"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.hair_slot_props
        if not props.target_collection:
            self.report({'ERROR'}, "Select a collection first")
            return {'CANCELLED'}
        if props.m_mesh == 'NONE' and props.s_mesh == 'NONE':
            self.report({'ERROR'}, "No mesh data selected")
            return {'CANCELLED'}
        if props.m_mesh != 'NONE' and not bpy.data.meshes.get(props.m_mesh):
            self.report({'ERROR'}, f"Mesh data '{props.m_mesh}' not found")
            return {'CANCELLED'}
        if props.s_mesh != 'NONE' and not bpy.data.meshes.get(props.s_mesh):
            self.report({'ERROR'}, f"Mesh data '{props.s_mesh}' not found")
            return {'CANCELLED'}
        slot = int(props.slot_number)
        results = []
        bone_count = rename_bones(context, props)
        if bone_count > 0:
            results.append(f"{bone_count} bones")
        m_result = rename_mesh_data(props.m_mesh, "M", slot)
        if m_result:
            results.append(f"{m_result[0]} → {m_result[1]}")
        s_result = rename_mesh_data(props.s_mesh, "S", slot)
        if s_result:
            results.append(f"{s_result[0]} → {s_result[1]}")
        if results:
            self.report({'INFO'}, f"Updated: {', '.join(results)}")
        else:
            self.report({'WARNING'}, "Nothing changed")
        return {'FINISHED'}


class HAIRSLOT_OT_separate_skeleton(Operator):
    """Separate hair bones into new skeleton using Blender's native separate"""
    bl_idname = "hair_slot.separate_skeleton"
    bl_label = "Separate Skeleton"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.hair_slot_props
        if not props.target_collection:
            self.report({'ERROR'}, "Select a collection first")
            return {'CANCELLED'}
        meshes = get_meshes_from_collection(props.target_collection)
        armatures, _ = get_armatures_for_meshes(meshes)
        if not armatures:
            self.report({'ERROR'}, "No armature found in collection")
            return {'CANCELLED'}
        source_armature = armatures[0]
        prefix = props.search_prefix
        letter = props.replace_letter.split('_')[1].lower()
        pattern1 = re.compile(f"^{re.escape(prefix)}_{re.escape(letter)}", re.IGNORECASE)
        pattern2 = re.compile(f"^J_{re.escape(prefix)}_{re.escape(letter)}$", re.IGNORECASE)
        original_active = context.view_layer.objects.active
        context.view_layer.objects.active = source_armature
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bones_to_select = []
        for bone in source_armature.data.edit_bones:
            if bone.name in HIERARCHY_CHAIN:
                bones_to_select.append(bone.name)
            elif pattern1.match(bone.name):
                bones_to_select.append(bone.name)
            elif pattern2.match(bone.name):
                bones_to_select.append(bone.name)
        if not bones_to_select:
            bpy.ops.object.mode_set(mode='OBJECT')
            self.report({'ERROR'}, f"No bones found matching '{prefix}_{letter}'")
            return {'CANCELLED'}
        for bone_name in bones_to_select:
            bone = source_armature.data.edit_bones.get(bone_name)
            if bone:
                bone.select = True
                bone.select_head = True
                bone.select_tail = True
        bpy.ops.armature.separate()
        bpy.ops.object.mode_set(mode='OBJECT')
        new_armature = context.active_object
        if new_armature and new_armature != source_armature:
            slot = int(props.slot_number)
            new_armature.name = f"Hair_Slot{slot}_Skeleton"
            new_armature.data.name = f"Hair_Slot{slot}_Skeleton"
        context.view_layer.objects.active = original_active
        self.report({'INFO'}, f"Separated {len(bones_to_select)} bones into new armature")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════════
#  PANEL — MODERNIZED
# ═══════════════════════════════════════════════════════════════════════════

class VIEW3D_PT_HairSlotPanel(Panel):
    """Hair Slot Renamer Panel"""
    bl_label = "Hair Slot Renamer"
    bl_idname = "VIEW3D_PT_HairSlotPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'MDL Tools'
    bl_order = 40
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        self.layout.label(text="", icon='PARTICLE_DATA')

    def draw(self, context):
        layout = self.layout
        props = context.scene.hair_slot_props

        # ── Collection selector ──
        box = layout.box()
        row = box.row(align=True)
        row.label(text="Collection", icon='OUTLINER_COLLECTION')
        sub = row.row(align=True)
        sub.alignment = 'RIGHT'
        sub.operator("hair_slot.refresh", icon='FILE_REFRESH', text="")
        box.prop(props, "target_collection", text="")

        # ── Target Slot ──
        layout.separator(factor=0.3)
        row = layout.row(align=True)
        row.label(text="Target Slot:", icon='SEQUENCE')
        row.prop(props, "slot_number", text="")

        # ── Bones section ──
        layout.separator(factor=0.3)
        box = layout.box()
        box.label(text="Bone Renaming", icon='BONE_DATA')

        row = box.row(align=True)
        row.prop(props, "search_prefix", text="Prefix")
        row.prop(props, "replace_letter", text="")

        letter = props.replace_letter.split('_')[1].lower()

        # Preview mappings in a compact sub-box
        preview = box.box()
        col = preview.column(align=True)
        col.scale_y = 0.9
        col.label(text=f"{props.search_prefix}_b  →  {props.search_prefix}_{letter}",
                  icon='FORWARD')
        col.label(text=f"J_{props.search_prefix}_b  →  J_{props.search_prefix}_{letter}",
                  icon='FORWARD')

        # ── Mesh Data section ──
        layout.separator(factor=0.3)
        box = layout.box()
        box.label(text="Mesh Data", icon='MESH_DATA')

        # M_ row
        row = box.row(align=True)
        row.label(text="M_:", icon='OUTLINER_OB_MESH')
        row.prop(props, "m_mesh", text="")
        sub = row.row(align=True)
        sub.scale_x = 0.3
        sub.label(icon='CHECKMARK' if props.m_mesh != 'NONE' else 'X')

        # S_ row
        row = box.row(align=True)
        row.label(text="S_:", icon='OUTLINER_OB_MESH')
        row.prop(props, "s_mesh", text="")
        sub = row.row(align=True)
        sub.scale_x = 0.3
        sub.label(icon='CHECKMARK' if props.s_mesh != 'NONE' else 'X')

        # Preview
        slot = int(props.slot_number)
        preview = box.box()
        preview.label(text="Preview", icon='HIDE_OFF')

        has_preview = False
        col = preview.column(align=True)
        col.scale_y = 0.9

        if props.m_mesh != 'NONE':
            match = re.match(r'^M_(\w+?)(\d*)$', props.m_mesh, re.IGNORECASE)
            if match:
                base = match.group(1)
                new_m = f"M_{base}" if slot == 1 else f"M_{base}{slot}"
                col.label(text=f"{props.m_mesh}  →  {new_m}", icon='FORWARD')
                has_preview = True

        if props.s_mesh != 'NONE':
            match = re.match(r'^S_(\w+?)(\d*)$', props.s_mesh, re.IGNORECASE)
            if match:
                base = match.group(1)
                new_s = f"S_{base}" if slot == 1 else f"S_{base}{slot}"
                col.label(text=f"{props.s_mesh}  →  {new_s}", icon='FORWARD')
                has_preview = True

        if not has_preview:
            col.label(text="No mesh data selected", icon='ERROR')

        # ── Update All button (primary action) ──
        layout.separator(factor=0.5)
        row = layout.row(align=True)
        row.scale_y = 1.4
        row.enabled = (
            (props.m_mesh != 'NONE' or props.s_mesh != 'NONE')
            and props.target_collection is not None)
        row.operator("hair_slot.update_all", icon='FILE_REFRESH')

        # ── Skeleton Separation ──
        layout.separator(factor=0.5)
        box = layout.box()
        box.label(text="Skeleton Separation", icon='ARMATURE_DATA')

        col = box.column(align=True)
        col.scale_y = 0.9
        col.label(text=f"Extracts J_{props.search_prefix}_{letter}", icon='FORWARD')
        col.label(text=f"and all {props.search_prefix}_{letter}* bones", icon='DOT')

        row = box.row(align=True)
        row.scale_y = 1.2
        row.enabled = props.target_collection is not None
        row.operator("hair_slot.separate_skeleton", icon='MOD_ARMATURE')


# ═══════════════════════════════════════════════════════════════════════════
#  REGISTRATION
# ═══════════════════════════════════════════════════════════════════════════

hair_slot_classes = [
    HairSlotProperties,
    HAIRSLOT_OT_refresh,
    HAIRSLOT_OT_update_all,
    HAIRSLOT_OT_separate_skeleton,
    VIEW3D_PT_HairSlotPanel,
]


def register_hair_slot_renamer():
    for cls in hair_slot_classes:
        try:
            bpy.utils.register_class(cls)
        except Exception as e:
            derror(f"[MDL Addon] Failed to register {cls.__name__}: {e}")
    bpy.types.Scene.hair_slot_props = PointerProperty(type=HairSlotProperties)


def unregister_hair_slot_renamer():
    for cls in reversed(hair_slot_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as e:
            derror(f"[MDL Addon] Failed to unregister {cls.__name__}: {e}")
    if hasattr(bpy.types.Scene, "hair_slot_props"):
        del bpy.types.Scene.hair_slot_props


if __name__ == "__main__":
    register_hair_slot_renamer()
