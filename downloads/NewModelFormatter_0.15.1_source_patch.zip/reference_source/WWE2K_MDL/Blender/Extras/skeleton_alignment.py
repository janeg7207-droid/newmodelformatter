import bpy
from .model_points_gen import VCAutoGenCharAPs
from ...Link.log import dlog

def check_parenting( base_armature ):
    base_bones = {bone.name: bone for bone in base_armature.data.edit_bones}

    if ("J_Root" in base_bones and "J_Hips" in base_bones):
        base_bone = base_bones["J_Hips"]
        base_bone.parent = base_bones["J_Root"]

def alignArmature(target_armature, base_armature, hair_only=False):

    bpy.context.view_layer.objects.active = base_armature
    bpy.ops.object.mode_set(mode='EDIT')

    # Which bones to pull: default = every target edit_bone; hair-only walks just
    # J_Hair + descendants (avoids merging an entire 511+-bone 2K25 attire skeleton
    # into a clean 2K26 baseModel when only the hair physics chain is needed).
    if hair_only:
        target_bones = _collect_subtree_bfs(target_armature, "J_Hair")
        if not target_bones:
            dlog("[Rig Align] hair_only requested but no 'J_Hair' bone "
                  f"found on target armature '{target_armature.name}'. "
                  "Nothing to align.")
            return
        dlog(f"[Rig Align] hair_only mode: pulling {len(target_bones)} "
              f"bones from 'J_Hair' subtree.")
    else:
        target_bones = list(target_armature.data.edit_bones)

    for target_bone in target_bones:
        base_bones = {bone.name: bone for bone in base_armature.data.edit_bones}

        # Check if the base armature already has a bone with the same name
        if target_bone.name in base_bones:
            continue  # Skip this bone, as it already exists in the base armature

        # If the base armature does not have this bone, add it
        new_bone = base_armature.data.edit_bones.new(target_bone.name)
        targetMatrix = target_bone.matrix

        new_bone.head = target_bone.head
        new_bone.tail = target_bone.tail
        # print ("BONE: " , new_bone.name)

        # If the target bone has a parent bone, find or create the corresponding parent bone in the base armature
        if target_bone.parent:
            parent_name = target_bone.parent.name
            if parent_name in base_bones:
                new_bone.parent = base_bones[parent_name]

        new_bone.matrix = targetMatrix
        # print( "Target Matrix: ", targetMatrix)
        # print( "New Bone Matrix: ", new_bone.matrix)


def _collect_subtree_bfs(armature, root_name):
    """Return [root_bone, ...all descendants] from the named root bone in
    BFS order so parents always appear before their children. The BFS order
    guarantees that when alignArmature feeds this list into base_bones one
    at a time, every bone's parent is already present by the time we look
    it up — so the parent-link step at the bottom of the loop succeeds for
    the entire subtree, not just for direct children of bones the base
    already had.

    Returns an empty list if root_name isn't on the armature, so callers
    can detect "no J_Hair to pull" without crashing.
    """
    edit_bones = armature.data.edit_bones
    root = edit_bones.get(root_name)
    if root is None:
        return []

    out = []
    queue = [root]
    while queue:
        b = queue.pop(0)
        out.append(b)
        # children iteration order is implementation-defined; fine for BFS
        # since we just need parent-before-child guarantee, not stable order
        for child in b.children:
            queue.append(child)
    return out



def evaluateTargetBaseArmatures( armature_1, armature_2 ):
    # Check if either armature has a bone named "J_Hair"
    arm1_has_jhair = "J_Hair" in armature_1.data.bones
    arm2_has_jhair = "J_Hair" in armature_2.data.bones

    if arm1_has_jhair and not arm2_has_jhair:
        target_armature = armature_1
        base_armature = armature_2
    elif arm2_has_jhair and not arm1_has_jhair:
        target_armature = armature_2
        base_armature = armature_1
    else:
        # If both armatures have "J_Hair", compare the number of bones in each
        if len(armature_1.data.bones) > len(armature_2.data.bones):
            target_armature = armature_1
            base_armature = armature_2
        else:
            target_armature = armature_2
            base_armature = armature_1
    
    return target_armature, base_armature

def hairNodeTotal( skel ):
    hairBones = 0
    for bone in skel.edit_bones:
        if bone.name == "J_Hair":
            hairBones+=1
    return hairBones


def filterSelection(objSel):
    outSel = []
    for obj in objSel:
        if obj.type == 'ARMATURE':
            outSel.append(obj)
    return outSel

def run_alignment(hair_only=False):
    userSelection = filterSelection( bpy.context.selected_objects )

    if ( len(userSelection) != 2 ):
        raise TypeError( "Select TWO skeletons to align armatures.")
        return

    baseSkeleton , targetSkeleton = evaluateTargetBaseArmatures( userSelection[0], userSelection[1] )
    alignArmature( baseSkeleton, targetSkeleton, hair_only=hair_only )
    check_parenting( targetSkeleton )
    bpy.ops.object.mode_set(mode='OBJECT')

    mode_label = "hair-only" if hair_only else "full"
    dlog(f"[Rig Align] Target Skeleton: {targetSkeleton.name} "
          f"Base Skeleton: {baseSkeleton.name} (mode: {mode_label})")


# NOTE: The user-visible button for this operator is wired up in
# Blender/Extras/streamline4_1.py inside the VIEW3D_PT_ModelFunctions
# panel. There used to be a RetargetSkeletonPanel class here too, but it
# was never registered — keeping it would just be dead code that misleads
# anyone searching for where the UI lives. If you want to add or move the
# button, edit streamline4_1.py.

class RetargetSkeletonOperator(bpy.types.Operator):
    bl_idname = "object.retarget_skeleton_operator"
    bl_label = "Align Skeleton"
    bl_description = "Adjusts both selected skeleton hierarchies to add or adjust missing joints/bones"

    hair_only: bpy.props.BoolProperty(
        name="Hair Only",
        description="Pull only the J_Hair subtree (hair physics chain) from "
                    "the target armature instead of merging every bone. "
                    "Use when porting an attire's hair onto a clean baseModel.",
        default=False,
    )

    def execute(self, context):
        run_alignment(hair_only=self.hair_only)
        return {'FINISHED'}

def register_rig_alignment_utility():
    bpy.utils.register_class(RetargetSkeletonOperator)

def unregister_rig_alignment_utility():
    bpy.utils.unregister_class(RetargetSkeletonOperator)