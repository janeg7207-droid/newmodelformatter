import bpy
import re
from ..SkinModel.skinmodel import vCSkinMesh
from .blender_utils import *
from . import perf
from ..Link.log import dlog, dwarn


def getMeshSelection():
    """Return the currently selected MESH objects (excludes armatures, etc).
    Public API — imported by name in model_points_gen / blender_points; keep stable.
    """
    selection_objs = bpy.context.selected_objects
    selection = []

    for obj in selection_objs:
        if obj.type == 'MESH':
            selection.append(obj)

    return selection


def _find_armature_modifier(obj):
    """Return the first ARMATURE modifier on obj, or None."""
    for mod in obj.modifiers:
        if mod.type == 'ARMATURE':
            return mod
    return None


def _parent_armature(obj):
    """Return obj's direct armature parent if it is one, else None."""
    p = obj.parent
    if p and p.type == 'ARMATURE':
        return p
    return None


def _classify_armature(armature_obj):
    """Fingerprint an armature as '2K25'/'2K26'/'unknown' via game-exclusive bone
    sets.
    """
    if armature_obj is None:
        return 'unknown'
    # Lazy import — avoids circular import at module load.
    from ..Serialize.skeleton_remap import BONES_ONLY_IN_25, BONES_ONLY_IN_26, RENAME_25_TO_26

    bone_names = {b.name for b in armature_obj.data.bones}

    # Exclude rename targets from the 2K26 set: a partially-renamed 2K25 armature can
    # carry H_Bicep_L_1 etc. without actually being 2K26.
    rename_targets = set(RENAME_25_TO_26.values())
    exclusive_26 = BONES_ONLY_IN_26 - rename_targets

    has_25 = bool(bone_names & BONES_ONLY_IN_25)
    has_26 = bool(bone_names & exclusive_26)

    if has_25 and not has_26:
        return '2K25'
    if has_26 and not has_25:
        return '2K26'
    # Both or neither: inconclusive → unknown (don't block the user).
    return 'unknown'


def _compile_target_to_version(compile_target):
    """Map the export enum to a version tag comparable with _classify_armature."""
    return {
        'option_vcexport_26': '2K26',
        'option_vcexport_25': '2K25',
        'option_vcexport_24': '2K24',
    }.get(compile_target, 'unknown')


def _find_scene_armature_for_version(version_tag):
    """Return the first armature in the scene that classifies as `version_tag`,
    or None. Used to point the user at the right armature when they've bound
    meshes to the wrong one."""
    for obj in bpy.data.objects:
        if obj.type != 'ARMATURE':
            continue
        if _classify_armature(obj) == version_tag:
            return obj
    return None


def reconcile_armature_binding(mesh_objects, compile_target=None, operator=None):
    """Audit and repair armature bindings on the mesh selection before export.

    1. HYGIENE (auto-repair) of unambiguous half-bound states that silently drop
       skinning: parented but no ARMATURE modifier → add one; modifier with
       .object=None and a parent armature → fill from parent.

    2. CROSS-VERSION AUTO-REDIRECT (when compile_target is given): detect a mesh
       still bound to the SOURCE game's armature while exporting for a DIFFERENT
       game — the "old skeleton comes back after export" leak (imported 2K25, built
       a 2K26 armature beside it, forgot to reparent / switch the modifier object).
       If a correct-version armature exists in the scene, AUTO-REDIRECT the mesh
       (parent + modifier) to it and warn; else continue with a warning. This fixes
       the BONE TABLE only, not VERTEX GROUPS — groups still naming old-game bones
       (H_Bicep_L vs H_Bicep_L_1) deform wrong until a weight transfer runs.

    Args:
        compile_target: export enum (e.g. "option_vcexport_26"); None = hygiene only.
        operator: optional Operator — routes messages through self.report (UI banner).
    Returns: always True ("never block the export"; kept for a future stricter mode).
    """
    def _warn(msg):
        # Surface via the UI banner (operator.report); the console line was noise.
        if operator is not None:
            try:
                operator.report({'WARNING'}, msg)
            except Exception:
                pass

    # ── Pass 1: hygiene repair ─────────────────────────────────────────────
    stats = {'auto_bound': 0, 'auto_linked': 0,
             'unbindable': 0, 'conflict': 0, 'ok': 0}

    for obj in mesh_objects:
        if obj.type != 'MESH':
            continue

        arm_mod = _find_armature_modifier(obj)
        parent_arm = _parent_armature(obj)

        if arm_mod is None:
            if parent_arm is not None:
                new_mod = obj.modifiers.new(name="Armature", type='ARMATURE')
                new_mod.object = parent_arm
                stats['auto_bound'] += 1
                dlog(f"[MDL Addon] Auto-bind: added missing ARMATURE modifier "
                      f"on '{obj.name}' -> '{parent_arm.name}'")
            # else: intentionally static geometry, leave alone
            continue

        if arm_mod.object is None:
            if parent_arm is not None:
                arm_mod.object = parent_arm
                stats['auto_linked'] += 1
                dlog(f"[MDL Addon] Auto-link: filled empty ARMATURE modifier "
                      f"on '{obj.name}' -> '{parent_arm.name}'")
            else:
                stats['unbindable'] += 1
                _warn(f"'{obj.name}' has an ARMATURE modifier with no object "
                      f"and no armature parent. Weights will NOT be exported "
                      f"for this mesh. Fix: set the modifier's Object field, "
                      f"or parent the mesh to the armature.")
            continue

        if parent_arm is not None and parent_arm is not arm_mod.object:
            # Parent and modifier point at DIFFERENT armatures (porting: one binding
            # updated, not the other). Pick whichever the mesh is actually WEIGHTED
            # against, in order of authority:
            #   1. VERTEX-GROUP OVERLAP — count vertex groups naming a bone on each
            #      candidate; more matches wins (decisive: weights that don't match
            #      bone names can't deform that mesh).
            #   2. VERSION CLASSIFIER — fingerprint 2K25 vs 2K26 and match the target.
            #   3. PARENT WINS — last resort (reparenting is deliberate; modifier.object
            #      is the usual stale leftover).
            chose = None
            chose_reason = None

            # --- Tier 1: vertex-group overlap ---
            vg_names = {vg.name for vg in obj.vertex_groups}
            if vg_names:
                parent_bones = {b.name for b in parent_arm.data.bones}
                mod_bones = {b.name for b in arm_mod.object.data.bones}
                p_matches = len(vg_names & parent_bones)
                m_matches = len(vg_names & mod_bones)
                # Require a meaningful gap: winner has >=2x the loser AND an absolute
                # lead of >=3 (2-vs-3 isn't decisive, 2-vs-20 is).
                if (p_matches or m_matches) and \
                   abs(p_matches - m_matches) >= 3 and \
                   max(p_matches, m_matches) >= 2 * max(1, min(p_matches, m_matches)):
                    if p_matches > m_matches:
                        chose = parent_arm
                        chose_reason = (f"parent '{parent_arm.name}' matches "
                                        f"{p_matches} of {len(vg_names)} vertex "
                                        f"groups vs modifier '{arm_mod.object.name}' "
                                        f"matching {m_matches} — weights are "
                                        f"keyed to the parent's bone names")
                    else:
                        chose = arm_mod.object
                        chose_reason = (f"modifier '{arm_mod.object.name}' matches "
                                        f"{m_matches} of {len(vg_names)} vertex "
                                        f"groups vs parent '{parent_arm.name}' "
                                        f"matching {p_matches} — weights are "
                                        f"keyed to the modifier's bone names")

            # --- Tier 2: version classifier ---
            if chose is None and compile_target is not None:
                tv = _compile_target_to_version(compile_target)
                if tv not in ('unknown', '2K24'):
                    pv = _classify_armature(parent_arm)
                    mv = _classify_armature(arm_mod.object)
                    if pv == tv and mv != tv:
                        chose = parent_arm
                        chose_reason = f"parent '{parent_arm.name}' is a {pv} skeleton (matches {tv} export target)"
                    elif mv == tv and pv != tv:
                        chose = arm_mod.object
                        chose_reason = f"modifier '{arm_mod.object.name}' is a {mv} skeleton (matches {tv} export target)"

            # --- Tier 3: parent wins ---
            if chose is None:
                chose = parent_arm
                chose_reason = (f"could not identify a winning binding by "
                                f"vertex-group overlap or version fingerprint "
                                f"— using the parent '{parent_arm.name}' since "
                                f"re-parenting is a deliberate action and the "
                                f"modifier is usually the stale leftover from "
                                f"the original import")

            prev_parent_name = parent_arm.name
            prev_mod_name = arm_mod.object.name
            # Sync both sides to the chosen armature.
            if obj.parent is not chose:
                obj.parent = chose
                obj.matrix_parent_inverse.identity()
            if arm_mod.object is not chose:
                arm_mod.object = chose
            stats['conflict'] += 1
            _warn(f"'{obj.name}' had its parent ('{prev_parent_name}') "
                  f"and ARMATURE modifier ('{prev_mod_name}') pointing at "
                  f"different armatures. Resolved: {chose_reason}. Both "
                  f"are now bound to '{chose.name}'. If this is wrong, "
                  f"fix the Object field of the mesh's ARMATURE modifier "
                  f"and re-export.")
        else:
            stats['ok'] += 1

    # ── Pass 2: cross-version guard ────────────────────────────────────────
    if compile_target is None:
        return True  # hygiene-only mode

    target_version = _compile_target_to_version(compile_target)
    if target_version in ('unknown', '2K24'):
        # 2K24 uses a different format entirely; skip version guard.
        return True

    # Build the set of distinct armatures actually driving the selection AFTER
    # hygiene pass (so auto-bound/auto-linked meshes are included).
    bound_armatures = {}  # id -> (armature_obj, [mesh names bound to it])
    for obj in mesh_objects:
        if obj.type != 'MESH':
            continue
        arm_mod = _find_armature_modifier(obj)
        arm = arm_mod.object if (arm_mod and arm_mod.object) else _parent_armature(obj)
        if arm is None:
            continue
        key = id(arm)
        if key not in bound_armatures:
            bound_armatures[key] = (arm, [])
        bound_armatures[key][1].append(obj.name)

    if not bound_armatures:
        # Nothing is bound to any armature — pure static geometry export.
        # That's fine; no version to check.
        return True

    # Check each bound armature against the target version.
    mismatches = []  # list of (armature_obj, armature_version, mesh_names)
    for arm, mesh_names in bound_armatures.values():
        arm_version = _classify_armature(arm)
        if arm_version == 'unknown':
            continue  # custom / partial skeleton; can't assert, let it through
        if arm_version != target_version:
            mismatches.append((arm, arm_version, mesh_names))

    if mismatches:
        # Find the right-version armature in the scene. If one exists, we can
        # auto-redirect the mesh(es) to it so the export goes out with the
        # correct bone table. If it doesn't, we can't safely fix things —
        # warn and let the export continue with the mismatched binding (user
        # said they'd rather have incorrect weights than a blocked export).
        correct_arm = _find_scene_armature_for_version(target_version)

        if correct_arm is None:
            # No right-version armature — let the export proceed but warn why weights
            # may be wrong.
            for arm, arm_version, mesh_names in mismatches:
                short = ", ".join(mesh_names[:5])
                more = f" (+{len(mesh_names)-5} more)" if len(mesh_names) > 5 else ""
                _warn(f"Cross-version skeleton: exporting as {target_version} "
                      f"but mesh(es) [{short}{more}] are bound to "
                      f"'{arm.name}' which is a {arm_version} skeleton. No "
                      f"{target_version} armature exists in the scene to "
                      f"redirect to. Export will continue but in-game "
                      f"deformations will be wrong until you build a "
                      f"{target_version} skeleton and rebind.")
            return True

        # Auto-redirect parent + modifier to the correct-version armature. Vertex
        # groups keyed to old-game bone names become orphans (weights exist, no bone
        # resolves) — the accepted tradeoff: export goes out, deforms may be wrong
        # until re-rigged / weight-transferred.
        total_redirected = 0
        for arm, arm_version, mesh_names in mismatches:
            for obj in mesh_objects:
                if obj.type != 'MESH' or obj.name not in mesh_names:
                    continue
                # Reparent without inverse (preserves world transform; matches the
                # attire-remap path).
                if obj.parent is arm:
                    obj.parent = correct_arm
                    obj.matrix_parent_inverse.identity()
                # Re-run the modifier lookup (may have been auto-added in pass 1).
                arm_mod = _find_armature_modifier(obj)
                if arm_mod is not None and arm_mod.object is arm:
                    arm_mod.object = correct_arm
                total_redirected += 1

            short = ", ".join(mesh_names[:5])
            more = f" (+{len(mesh_names)-5} more)" if len(mesh_names) > 5 else ""
            _warn(f"Cross-version skeleton auto-redirected: mesh(es) "
                  f"[{short}{more}] were bound to '{arm.name}' ({arm_version}) "
                  f"but you are exporting as {target_version}. Rebound to "
                  f"'{correct_arm.name}' ({target_version}) so the export "
                  f"uses the correct bone table. NOTE: if vertex groups on "
                  f"these meshes still reference {arm_version}-only bone "
                  f"names (e.g. H_Bicep_L vs H_Bicep_L_1), in-game "
                  f"deformations will be wrong until you run a proper "
                  f"weight transfer against the {target_version} skeleton.")

        dlog(f"[MDL Addon] Auto-redirect: moved {total_redirected} mesh(es) "
              f"onto '{correct_arm.name}'.")
        # Fall through to the success path so the export proceeds with the
        # freshly-rebound state. No return False.

    # ── Pass 3: collection sync (now a no-op) ──
    # This used to MOVE meshes into their bound armature's collection after pass 2's
    # redirect, so collection-resolved lookups (companion files, HPL source, panels)
    # tracked the new binding. Wrong direction: the import collection is the
    # authoritative record of WHERE THE MESH CAME FROM (which source MCD owns its
    # companions, sub-streams, HPL). Moving it severed that — an attire resolved its
    # source to baseModel.mcd instead of ###_Attire.mcd and its gear physics
    # (HCYW/HYWA/OYWA/OCYW sub-streams) silently failed to transfer ("attire on the
    # floor"). Now source identity stays with the import collection; a nonsensical
    # collection is caught downstream by the source-MCD sanity check.

    if stats['auto_bound'] or stats['auto_linked'] or stats['conflict'] or stats['unbindable']:
        dlog(f"[MDL Addon] Armature reconciliation: "
              f"{stats['auto_bound']} auto-bound, "
              f"{stats['auto_linked']} auto-linked, "
              f"{stats['conflict']} conflict(s), "
              f"{stats['unbindable']} unbindable, "
              f"{stats['ok']} already ok")
    return True


def getBaseName(obj):
    name = obj.name
    name = name.replace( "!","")
    name = name.replace( "$","")
    if ( "." in  name ):
        name = name.split(".")[0]
    
    # Case correction: M_ and S_ prefixed names need uppercase after prefix
    if len(name) > 2 and name[1] == '_' and name[0] in ('M', 'm', 'S', 's'):
        name = name[0].upper() + '_' + name[2].upper() + name[3:]
    
    return name

def makeSkinMeshRaw(obj, preserve_tangents=False):
    """Build skin mesh from raw Blender data — DLL handles triangulation + UV splitting."""
    skinmesh = vCSkinMesh()
    skinmesh.name           = getBaseName(obj)
    skinmesh.mesh_name      = getBaseName(obj.data)
    # Multi-material face groups (None for single-material meshes -> default path).
    # Read in polygon order so the triangle ranges line up with the raw polygons the
    # DLL fan-triangulates below; serializer emits the index buffer group-by-group.
    skinmesh.face_groups    = getMaterialFaceGroups(obj)
    skinmesh.vertices       = getRawMeshPositions(obj)
    skinmesh.face_sizes, skinmesh.index_list = getRawMeshPolygons(obj)
    skinmesh.loop_uv_sets, skinmesh.num_loops = getRawLoopUVs(obj)
    skinmesh.loop_normals, _ = getRawLoopNormals(obj)
    # Per-loop carried-tangent preservation on the DLL-preprocess path (opt-in
    # EXPERIMENTAL). ON: feed vanilla per-loop tangents (getRawLoopTangents applies
    # world transform + handedness + unedited hash gate → edited mesh returns None,
    # falls back to MikkT). splitUvSeams() moves them per-vertex parallel to loop
    # normals; reorderSplitToVanilla routes by each split's origVert source index
    # (a clean bijection) NOT position — so co-located seam clones (different tangent
    # frames / flipped handedness) no longer swap onto the wrong WDF vertex (the old
    # position match was the "explode" cause). OFF (default): None → DLL regenerates
    # MikkTSpace (known-good; turning the toggle OFF is never the broken part).
    if preserve_tangents:
        skinmesh.loop_tangents, _ = getRawLoopTangents(obj)
        # Per-loop vanilla PackedTBN words — the octahedral lane WDF reads. Same
        # unedited hash gate; carried opaquely (per-vertex serializer gate decides
        # keep-vs-reencode).
        skinmesh.loop_packedtbn, _ = getRawLoopPackedTBN(obj)
    else:
        skinmesh.loop_tangents  = None
        skinmesh.loop_packedtbn = None
    skinmesh.vertex_normals = None
    skinmesh.texcoords      = None
    skinmesh.vertex_colors  = getVertexColors(obj)
    skinmesh.vertex_color_maps = getAllVertexColors(obj)  # ALL maps, not just the first
    skinmesh.skin           = getMeshSkin(obj)
    skinmesh.blendshapes    = getShapeKeys(obj)
    skinmesh.scene_flag     = getGameSceneFlag(obj)
    skinmesh.motion_flag    = getGameMotionFlag(obj)
    
    import json
    if "vcmodel_vertex_remap" in obj:
        _remap = json.loads(obj["vcmodel_vertex_remap"])
        # Only carry the remap when it still matches the current vertex count. An edited
        # custom mesh can hold a STALE remap from its donor import (wrong length); feeding
        # it to the DLL split would duplicate meaningless render->welded indices onto the
        # seam clones (wrong HPL/CTG placement). On a length mismatch -> drop it -> the DLL
        # emits an identity remap (matches the legacy size-mismatch outcome). Vanilla
        # meshes match exactly so this is a no-op for them (byte-exact round-trips intact).
        if len(_remap) == len(obj.data.vertices):
            skinmesh.vertex_remap = _remap
        else:
            dwarn(f"[MDL Addon] '{skinmesh.name}': stored vertex remap length "
                  f"{len(_remap)} != {len(obj.data.vertices)} verts (edited mesh) — "
                  f"dropping stale remap.")

    skinmesh.use_dll_preprocess = True
    return skinmesh

def makeSkinMesh(obj):
    # Build skin mesh from scene object
    skinmesh = vCSkinMesh()
    skinmesh.name           = getBaseName(obj)
    skinmesh.mesh_name      = getBaseName(obj.data)
    # Multi-material face groups (None for single-material meshes -> default path).
    # getMeshFaces emits triangles in polygon order (mesh already triangulated on
    # this path), so the captured triangle ranges line up with index_list.
    skinmesh.face_groups    = getMaterialFaceGroups(obj)
    skinmesh.index_list     = getMeshFaces(obj)
    skinmesh.vertices       = getMeshVertices(obj)
    skinmesh.vertex_normals = getVertexNorms(obj)
    skinmesh.vertex_tangents = getVertexTangents(obj)  # None unless unedited (hash gate)
    skinmesh.texcoords      = getTexCoords(obj)
    skinmesh.vertex_colors  = getVertexColors(obj)
    skinmesh.vertex_color_maps = getAllVertexColors(obj)  # ALL maps, not just the first
    skinmesh.skin           = getMeshSkin(obj)
    skinmesh.blendshapes    = getShapeKeys(obj)
    skinmesh.scene_flag     = getGameSceneFlag(obj)
    skinmesh.motion_flag    = getGameMotionFlag(obj)
    
    # Read stored vertex remap for export (HPL ordering + CTG)
    import json
    if "vcmodel_vertex_remap" in obj:
        skinmesh.vertex_remap = json.loads(obj["vcmodel_vertex_remap"])
    
    skinmesh.use_dll_preprocess = False
    return skinmesh

def getSceneColliderGeometry():
    """Scan bpy.data.objects for collider-reference meshes regardless of selection.
    Returns {mesh_name: (verts, tris)} as physics-patcher collider input.

    The patcher binds closest-triangle against M_Head/M_Body/M_Combinations. On a
    baseModel export those are selected and supplied normally; on an ATTIRE export
    the user loads head/body for reference but keeps them OUT of selection (selecting
    would wrongly pull them into the attire MCD's MDL section — they belong to
    baseModel.mcd). Without this scan the patcher sees no colliders and writes
    placeholders. Returns world-space Vectors + 3-tuple tris (the _get_collider
    scene_meshes fallback shape).
    """
    targets = {'M_Head', 'M_Body', 'M_Combinations'}
    out = {}
    try:
        from mathutils import Vector  # noqa: F401 — sanity-check Blender ctx
    except ImportError:
        return out

    for obj in bpy.data.objects:
        if obj.type != 'MESH' or obj.data is None:
            continue
        data_name = getBaseName(obj.data)
        if data_name not in targets:
            continue
        if data_name in out:
            continue  # first-found wins; scenes occasionally have duplicates
        if not obj.data.polygons:
            continue

        # World-space positions (like getMeshVertices) so geometry matches the
        # render meshes' coordinate system. Fast path: foreach_get('co') + numpy
        # matmul, output kept as list-of-3-tuples so the tri list still indexes.
        verts = None
        if perf._enabled():
            try:
                verts = perf.fast_get_mesh_vertices_world(obj)
            except Exception as e:
                dlog(f"[MDL Addon] getSceneColliderGeometry fast path skipped "
                     f"on '{obj.name}' ({e}); using slow path.")
                verts = None
        if verts is None:
            verts = [obj.matrix_world @ v.co for v in obj.data.vertices]

        # Triangulate (M_Head/M_Body are pure tris in vanilla, but fan-triangulate
        # quads/ngons defensively in case the scene was touched).
        tris = []
        for poly in obj.data.polygons:
            v_idx = list(poly.vertices)
            if len(v_idx) == 3:
                tris.append(tuple(v_idx))
            elif len(v_idx) == 4:
                tris.append((v_idx[0], v_idx[1], v_idx[2]))
                tris.append((v_idx[0], v_idx[2], v_idx[3]))
            elif len(v_idx) > 4:
                for k in range(1, len(v_idx) - 1):
                    tris.append((v_idx[0], v_idx[k], v_idx[k+1]))

        if verts and tris:
            out[data_name] = (verts, tris)
    return out


def getSceneMeshes(preserve_normals=False, preserve_tangents=False):
    # Collect all user selection targets
    obj_selection = getMeshSelection()
    if ( len( obj_selection ) == 0 ):
        dwarn( "\n[MDL Addon] Please select an object to save file." )
        return None

    # Filter out polygon-less meshes (vertex-only, physics drivers, empty cages):
    # setMeshData with a zero-length index list is UB (zero-triangle MCD entries
    # crash the game on some builds, silently skip on others). Drop + report them.
    filtered_selection = []
    dropped = []
    for obj in obj_selection:
        if len(obj.data.polygons) == 0:
            dropped.append(obj.name)
        else:
            filtered_selection.append(obj)

    if dropped:
        names = ", ".join(dropped[:5])
        more = f" (+{len(dropped)-5} more)" if len(dropped) > 5 else ""
        dwarn(f"[MDL Addon] Skipping {len(dropped)} mesh(es) with no "
              f"polygons: [{names}{more}]. These are vertex-only meshes "
              f"and cannot be exported as geometry. If you need one of "
              f"these exported, add at least one triangle to it.")

    if not filtered_selection:
        dwarn("[MDL Addon] No exportable meshes in selection after "
              "filtering empty geometry.")
        return None

    obj_selection = filtered_selection

    if preserve_normals:
        # Per-mesh path selection for "Preserve Custom Normals":
        #   PYTHON path (format_game_uv_seams_preserve_normals) for:
        #     (a) shape-keyed meshes — shape keys must travel through Blender's own
        #         triangulation so base+delta stay in sync.
        #     (b) ngon-bearing meshes — the DLL fan-splits ngons from vertex 0, which
        #         on concave boundaries cross-hatches the interior; the Python pre-pass
        #         uses EAR_CLIP (in-boundary), leaving all faces tris so the DLL's
        #         triangulate is a no-op.
        #   DLL path (makeSkinMeshRaw) for everything else (tri/quad-only, no shape
        #     keys): characters/belts/attire/accessories — the verified best-fidelity
        #     route for per-loop normals, must not regress (ECW belt established it).
        dlog("[MDL Addon] Preserve Custom Normals enabled")
        setBlenderMode('OBJECT')

        def _has_ngons(obj):
            return any(len(f.vertices) > 4 for f in obj.data.polygons)

        meshes_python = []
        meshes_dll = []
        for obj in obj_selection:
            has_shapekeys = obj.data.shape_keys and len(obj.data.shape_keys.key_blocks) > 1
            if has_shapekeys or _has_ngons(obj):
                meshes_python.append(obj)
            else:
                meshes_dll.append(obj)

        if meshes_python:
            dlog(f"[MDL Addon]   Python path (shape keys or ngons): "
                 f"{[o.name for o in meshes_python]}")
            for obj in meshes_python:
                format_game_uv_seams_preserve_normals(obj)
            setBlenderMode('OBJECT')

        if meshes_dll:
            dlog(f"[MDL Addon]   DLL path (tri/quad-only, no shape keys): "
                 f"{[o.name for o in meshes_dll]}")
    dll_autoroute = set()   # mesh names to route through the DLL preprocess (default path)
    if not preserve_normals:
        # Legacy path: Python-side triangulation + UV seam split + normal retarget.
        #
        # EXCEPTION — a WELDED multi-material mesh (a custom FBX import shares verts
        # across UV islands at the material boundaries) hits the multi-facegroup
        # seam-split SKIP in format_game_uv_seams, which leaves it un-split; the
        # per-vertex UV read (getUvChannelMap, last-loop-wins) then collapses every UV
        # island to one arbitrary loop's UV -> the 'mangled UVs' the user reported on
        # custom meshes. Route ONLY those meshes through the DLL preprocess instead
        # (per-LOOP split, facegroup-aware) — the SAME path Preserve Custom Normals
        # uses, proven UV-correct on these meshes. Gate = multi-facegroup AND welded
        # AND no shape keys, so vanilla meshes (split at import, no welded UV seams) and
        # single-material meshes (the Python seam split already handles them) NEVER
        # trigger it: zero change to every existing round-trip. A mesh that is already
        # broken (scrambled) today can only be improved, never regressed.
        def _obj_has_ngons(o):
            return any(len(f.vertices) > 4 for f in o.data.polygons)

        routed = []
        skipped_sk = []   # welded multi-material meshes excluded ONLY for shape keys
        for obj in obj_selection:
            has_sk = obj.data.shape_keys and len(obj.data.shape_keys.key_blocks) > 1
            if has_multiple_facegroups(obj) and mesh_has_welded_uv_seams(obj):
                if has_sk:
                    skipped_sk.append(obj.name)
                else:
                    routed.append(obj)
        dll_autoroute = {o.name for o in routed}

        if dll_autoroute:
            dwarn(f"[MDL Addon] Routing {len(dll_autoroute)} welded multi-material "
                  f"mesh(es) through the DLL UV-split to avoid per-vertex UV scramble: "
                  f"{sorted(dll_autoroute)}. (These are custom/FBX meshes; the result "
                  f"matches the Preserve Custom Normals path.)")

        # A welded multi-material mesh excluded ONLY because it carries shape keys stays
        # on the legacy path (the DLL split's interaction with blendshapes is unvalidated)
        # and its UV islands may still scramble — warn so the user isn't left guessing.
        # Warning only; no behavior change (these scrambled before this fix too).
        if skipped_sk:
            dwarn(f"[MDL Addon] {len(skipped_sk)} welded multi-material mesh(es) carry "
                  f"shape keys and cannot use the DLL UV-split — their UV islands may "
                  f"scramble on export: {sorted(skipped_sk)}. Workaround: export with "
                  f"'Preserve Custom Normals' ON, or split UV seams manually first.")

        # Routed meshes skip format_game_objects (raw polygons go straight to the DLL).
        # An ngon among them would be vertex-0 fan-triangulated by the DLL, which
        # cross-hatches a CONCAVE ngon's interior. EAR_CLIP-triangulate those first
        # (format_game_uv_seams_preserve_normals: in-boundary triangulate, then it skips
        # the seam split on multi-facegroup and returns) so the DLL triangulate is a
        # no-op — exactly the prep the Preserve Custom Normals path does for ngon meshes.
        # Tri/quad routed meshes are untouched (byte-identical to before).
        ngon_routed = [o for o in routed if _obj_has_ngons(o)]
        if ngon_routed:
            for obj in ngon_routed:
                format_game_uv_seams_preserve_normals(obj)
            setBlenderMode('OBJECT')

        legacy = [o for o in obj_selection if o.name not in dll_autoroute]
        format_game_objects(legacy)
        # makeSkinMeshRaw reads raw loop data in OBJECT mode; ensure we are there even
        # if every selected mesh was auto-routed (format_game_objects got an empty list).
        setBlenderMode('OBJECT')

    models = []
    for obj in obj_selection:
        has_shapekeys = obj.data.shape_keys and len(obj.data.shape_keys.key_blocks) > 1
        if preserve_normals and not has_shapekeys:
            skinmesh = makeSkinMeshRaw(obj, preserve_tangents=preserve_tangents)
        elif obj.name in dll_autoroute:
            # default-path auto-route: per-loop DLL split (no tangent preservation —
            # default path regenerates MikkTSpace, the known-good behavior).
            skinmesh = makeSkinMeshRaw(obj, preserve_tangents=False)
        else:
            skinmesh = makeSkinMesh(obj)
        models.append(skinmesh)

    return models

def getSceneArmature():
    selection = getMeshSelection()
    # No depsgraph update needed — we only walk obj.modifiers + armature.data.bones.
    for obj in selection:
        if (has_armature_modifier(obj)):
            # Armature from modifier (more reliable than obj.parent).
            armature = None
            for mod in obj.modifiers:
                if mod.type == 'ARMATURE' and mod.object:
                    armature = mod.object
                    break
            if not armature and obj.parent and hasattr(obj.parent, 'data') and hasattr(obj.parent.data, 'bones'):
                armature = obj.parent
            
            if not armature:
                continue
            
            target_rig = vCSkeleton()
            for bone in armature.data.bones:
                target_rig.bones.append( getRigBone(bone) )

            return target_rig
    
    return None
