import bpy
import re
from .blender_save import *
from ..SkinModel.skinmodel_ap import vCAttachPoint

def get_model_aps_collection():
    selection = getMeshSelection()
    # No depsgraph update needed — we only walk obj.parent + collection membership.
    for obj in selection:
        if (has_armature_modifier(obj)):
            try:
                parent_collection = obj.parent.users_collection[0]
            except (AttributeError, IndexError):
                # AttributeError: obj.parent is None (mesh not parented)
                # IndexError: parent is not linked to any collection
                return None

            # Iterate over the child objects of the collection
            for child in parent_collection.children:
                if (child.name.startswith("Model APs")):
                    return child, obj.parent
    
    return None, None

def get_armature_constraint(obj):
    for constraint in obj.constraints:
        if constraint.type == 'ARMATURE':
            return constraint
    return None

def get_constraint_target(armature, constraint):
    if (len(constraint.targets) == 0):
        return None

    bone_target = constraint.targets[0].subtarget

    for index, bone in enumerate(armature.data.bones): # Check if target is a valid bone in model armature
        if bone.name == bone_target:
            return index
    return None

def getPoint(model_armature, scene_obj):
    pattern = r'^ap_(\d+)-(\d+)-(\d+)$'  # Regex pattern to match "ap_<digits>-<digits>-<digits>"
    obj_name = scene_obj.name.split(".")[0]
    match = re.match(pattern, obj_name)
    if not match: return None
    
    point_constraint = get_armature_constraint(scene_obj)
    if point_constraint is None: return None
    bone_index       = get_constraint_target(model_armature, point_constraint)
    # Use `is None` — bone index 0 is the root bone and is perfectly valid.
    # `if (not bone_index)` evaluates 0 as False, silently dropping the
    # root bone's attachment point on every export.
    if bone_index is None: return None
    
    point       = vCAttachPoint()
    point.id_a  = int(match.group(1))
    point.id_b  = int(match.group(2))
    point.flag  = int(match.group(3))
    point.joint = bone_index
    point.bone_id = model_armature.data.bones[bone_index].name
    
    # Explicitly convert coordinates to float
    point.co    = [float(scene_obj.location.x), float(scene_obj.location.y), float(scene_obj.location.z)]
    
    return point

def getSceneAttachPoints():
    model_aps_col, armature_obj = get_model_aps_collection()
    if (not model_aps_col): return None

    attach_point_objs = []
    for child in model_aps_col.objects:
        point_struct = getPoint(armature_obj, child)

        if (point_struct):
            attach_point_objs.append(point_struct)

    # print(f"Found {len(attach_point_objs)} total attach points.")
    return attach_point_objs