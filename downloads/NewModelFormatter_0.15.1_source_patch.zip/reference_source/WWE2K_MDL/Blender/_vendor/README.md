# Vendored Third-Party Libraries

This directory contains third-party Python packages bundled directly with the
WWE2K_MDL Blender addon so end users do not need to run `pip install` to use
the addon. Nothing in this directory should be modified by hand — treat the
contents as read-only mirrors of their upstream sources.

## flatbuffers 24.3.25

- **Upstream**: <https://github.com/google/flatbuffers> (tag `v24.3.25`)
- **PyPI**:     <https://pypi.org/project/flatbuffers/24.3.25/>
- **License**:  Apache License 2.0
- **License file**: `flatbuffers/LICENSE`
  (downloaded from `https://raw.githubusercontent.com/google/flatbuffers/v24.3.25/LICENSE`)

### Why vendored

The addon's `.jmtl` writer (`Serialize/jmtl_writer.py`) needs FlatBuffers at
runtime. Requiring users to pip-install into Blender's bundled Python is a
common support headache, so we ship our own copy.

### Import path

From any module inside the addon, import via a package-relative path so we
always pick up the vendored copy (never an unrelated system install):

```python
# From Serialize/jmtl_writer.py (or anything else at addon top level):
from .Blender._vendor import flatbuffers

# From a module inside Blender/Extras/:
from .._vendor import flatbuffers

# From a module inside Blender/ itself:
from ._vendor import flatbuffers
```

### How to update

1. `pip install --upgrade flatbuffers` into any Python on this machine.
2. Find the installed package:
   `python -c "import flatbuffers, os; print(os.path.dirname(flatbuffers.__file__))"`
3. Delete the existing `Blender/_vendor/flatbuffers/` directory.
4. `cp -r <site-packages>/flatbuffers Blender/_vendor/`
5. Delete the copied `__pycache__/` directory.
6. Download the matching `LICENSE` from
   `https://raw.githubusercontent.com/google/flatbuffers/v<NEW_VERSION>/LICENSE`
   into `Blender/_vendor/flatbuffers/LICENSE`.
7. Update the version number at the top of this file.
8. Re-run the smoke test (build a tiny FlatBuffer via the vendored import) to
   confirm nothing regressed.
