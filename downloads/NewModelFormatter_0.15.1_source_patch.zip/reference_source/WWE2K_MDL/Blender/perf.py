"""Vectorized fast paths for the import/export hot loops.

Each function mirrors a slow-path counterpart in blender_mesh.py / blender_utils.py
and produces the SAME output for valid input. Structure: PREP (pure numpy, no RNA
mutation) then COMMIT (foreach_set / vertex_group.add). A PREP exception makes the
caller fall back with no scene state touched; COMMIT exceptions are rare (numpy
validates up front) and propagate rather than being swallowed.

Why: Blender's per-RNA-call overhead grew 4.x→5.x and hurts on character meshes
(50-100k verts × UV layers × 30+ shape keys × 50 bones); foreach_get/set cross the
C boundary in one trip instead of millions.

Numerically equivalent to the slow paths:
  * setVertexGroups: bucket-by-weight == per-call .add() on an empty group.
  * setMeshNormals scrub: same finite + zero-length tests, vectorized.
  * getVertexNorms / getUvChannelMap: fancy-index scatter == last-loop-wins.
  * Shape keys: basis-copy + indexed overwrite == the per-vertex write loop, same
    skipped-index counters.
  * fast_get_yobj_weights: top-N-by-weight + per-vertex sum-to-1, one resolved-name
    dict instead of repeated list.index().
  * fast_get_mesh_vertices_world: list-of-3-tuples (matches the comprehension),
    distinct from fast_get_mesh_vertices's flat list for the DLL.
"""

import bpy
import numpy as np


def _enabled():
    """Gate fast paths to Blender 3.0+. foreach_get/set work since 2.93, but pre-3.0
    has subtle attribute-handling inconsistencies (corner_normals, color domain) not
    worth re-validating.
    """
    return bpy.app.version >= (3, 0, 0)


# ── IMPORT ────────────────────────────────────────────────────────────

def fast_set_tex_coords(mesh, uv_maps):
    """Per-vertex UV maps → per-loop UV layer via scatter on loop_vert_index.

    Slow path counterpart: blender_mesh.setTexCoords. Walks every face,
    every loop, writes uv_layer.data[loop_idx].uv = map[vert_idx].

    Returns the number of UV channels that could NOT be created (Blender hard-
    caps UV layers at 8; uv_layers.new() returns None past the cap). 0 for
    well-formed meshes.
    """
    if uv_maps is None:
        return 0

    # PREP: validate every input array before touching the scene.
    arrays = []
    for vert_uvs in uv_maps:
        a = np.asarray(vert_uvs, dtype=np.float32)
        if a.ndim == 1:
            # Flat (u0,v0,u1,v1,...) — reshape to (N, 2).
            a = a.reshape(-1, 2)
        if a.ndim != 2 or a.shape[1] != 2:
            raise ValueError(f"unexpected UV shape {a.shape}")
        arrays.append(a)

    n_loops = len(mesh.loops)
    if n_loops == 0:
        return 0

    loop_vert_idx = np.empty(n_loops, dtype=np.int32)
    mesh.loops.foreach_get('vertex_index', loop_vert_idx)

    # OOB clamp — defensive against UV arrays shorter than vertex count
    # (DLL/Blender drift). Out-of-range loops get UV (0,0); they would
    # have raised IndexError on the slow path's `map[vert_idx]`.
    n_verts = len(mesh.vertices)

    # COMMIT: create layer + write per channel.
    skipped = 0
    for index, uv_array in enumerate(arrays):
        channel_name = f"{mesh.name}_UV{index}"
        uv_layer = mesh.uv_layers.new(name=channel_name)
        if uv_layer is None:
            # Blender hard-caps UV layers at 8 (MAX_MTFACE); new() returns None
            # past the cap. A file from an early/unfinished exporter can carry
            # more channels than Blender can hold — skip the surplus rather than
            # crash on None.data.foreach_set. No-op for valid meshes (<=8 sets).
            skipped += 1
            continue

        # If the per-vertex array is shorter than n_verts, pad; if
        # longer, truncate. Slow path would IndexError on shorter — we
        # prefer to pad with (0,0) to keep the import alive.
        rows = uv_array.shape[0]
        if rows < n_verts:
            padded = np.zeros((n_verts, 2), dtype=np.float32)
            padded[:rows] = uv_array
            uv_array = padded

        # Clamp loop_vert_idx against array length so the gather never
        # reads OOB. Still a no-op on healthy meshes.
        safe_idx = np.clip(loop_vert_idx, 0, uv_array.shape[0] - 1)
        flat = uv_array[safe_idx].ravel()
        uv_layer.data.foreach_set('uv', flat)

    return skipped


def fast_set_vertex_groups(obj, vertex_skin):
    """Bulk-add weights via bucket-by-weight.

    Slow path counterpart: blender_mesh.setVertexGroups. Game weights
    are 8-bit unorm coming from the DLL → ≤256 unique values per group
    in practice. One vertex_group.add(idx_list, weight, 'REPLACE') per
    bucket replaces N=verts*bones single-element .add() calls.

    REPLACE vs ADD: the group is freshly created (empty) so on the
    first write REPLACE and ADD produce the same final state. REPLACE
    is the canonical bulk-add op and slightly cheaper internally.

    Returns total_oob count for the caller's warning text.
    """
    if vertex_skin.groups is None:
        return 0

    num_verts = len(obj.data.vertices)
    total_oob = 0

    weights_list = vertex_skin.weights
    for i, group in enumerate(vertex_skin.groups):
        # Stop if the weight-row list is shorter than the group-name list (a
        # malformed/half-written skin sub-stream); indexing weights[i] by the
        # group counter would IndexError. No-op when the lists agree.
        if weights_list is None or i >= len(weights_list):
            break
        vertex_group = obj.vertex_groups.new(name=group)
        weights = weights_list[i]
        n = len(weights) if weights is not None else 0
        if n == 0:
            continue

        # Match slow-path OOB accounting: it `break`s on the first
        # index >= num_verts and counts the suffix as OOB.
        if n > num_verts:
            total_oob += n - num_verts
            n = num_verts

        arr = np.asarray(weights[:n], dtype=np.float32)
        nonzero_mask = arr != 0.0
        if not nonzero_mask.any():
            continue

        nonzero_indices = np.nonzero(nonzero_mask)[0]
        nonzero_weights = arr[nonzero_indices]

        # Bucket by exact weight value. np.unique returns sorted
        # uniques + an inverse mapping that tells us which bucket each
        # entry belongs to.
        unique_w, inverse = np.unique(nonzero_weights, return_inverse=True)
        for k in range(len(unique_w)):
            idx_list = nonzero_indices[inverse == k].tolist()
            vertex_group.add(idx_list, float(unique_w[k]), 'REPLACE')

    return total_oob


def fast_scrub_normals(normals, num_verts):
    """Vectorized scrub of non-finite + zero-length normals to (0,0,1).

    Slow path counterpart: the Python validation loop in setMeshNormals.
    Returns (scrubbed_list_of_tuples, scrubbed_count).
    """
    arr = np.zeros((num_verts, 3), dtype=np.float64)
    # Safe element-wise read — handles mathutils.Vector / tuples / lists
    # uniformly. The slow path tolerates entries shorter than 3 by
    # zero-padding ('if len(n) > 0' / 'if len(n) > 1' guards); we match
    # that explicitly here so both paths agree on degenerate inputs.
    for i, n in enumerate(normals):
        ln = len(n)
        if ln > 0: arr[i, 0] = float(n[0])
        if ln > 1: arr[i, 1] = float(n[1])
        if ln > 2: arr[i, 2] = float(n[2])

    finite_mask = np.isfinite(arr).all(axis=1)
    length_sq = (arr * arr).sum(axis=1)
    bad = (~finite_mask) | (length_sq < 1e-12)
    scrubbed = int(bad.sum())
    if scrubbed:
        arr[bad] = (0.0, 0.0, 1.0)

    return arr.tolist(), scrubbed


def fast_add_color_map(mesh, layer, color_map, attr_name='color'):
    """Per-vertex color list → per-loop color attribute via scatter.

    Slow path counterpart: blender_mesh.addColorMap. Walks every poly,
    every loop, writes layer.data[i].color = color_map[vert_index].

    `attr_name` selects which RNA property we write to. Caller resolves to
    'color_srgb' for BYTE_COLOR on 3.5+ to keep byte-identity with the MCD
    floats (symmetric with the export-side read), or 'color' otherwise.
    """
    n_loops = len(mesh.loops)
    if n_loops == 0:
        return

    color_array = np.asarray(color_map, dtype=np.float32)
    if color_array.ndim == 1:
        color_array = color_array.reshape(-1, 4)
    if color_array.ndim != 2:
        raise ValueError(f"unexpected color shape {color_array.shape}")
    # Pad RGB → RGBA if needed (defensive — DLL already returns RGBA).
    if color_array.shape[1] == 3:
        ones = np.ones((color_array.shape[0], 1), dtype=np.float32)
        color_array = np.hstack([color_array, ones])
    elif color_array.shape[1] != 4:
        raise ValueError(f"unexpected color channel count {color_array.shape[1]}")

    loop_vert_idx = np.empty(n_loops, dtype=np.int32)
    mesh.loops.foreach_get('vertex_index', loop_vert_idx)

    # Defensive clamp matching fast_set_tex_coords' philosophy.
    safe_idx = np.clip(loop_vert_idx, 0, color_array.shape[0] - 1)
    flat = color_array[safe_idx].ravel()
    try:
        layer.data.foreach_set(attr_name, flat)
    except (TypeError, RuntimeError):
        # Same fallback as fast_read_corner_colors — if a build exposes
        # color_srgb on the element but not through foreach_set, drop to
        # 'color' and accept the legacy round-trip semantics.
        layer.data.foreach_set('color', flat)


def fast_apply_blendshape(obj, shape, sk_block, basis_co, num_verts,
                          work_buf=None, last_touched=None):
    """Apply one shape-key morph via foreach_set.

    Slow path counterpart: setBlendShapes' inner loop (writes sk.data[i].co per
    entry in shape.indices).

    PERF NOTE (v2.3.1): the old fast path did basis_co.copy() per shape — 288 KB ×
    871 shapes ≈ 251 MB memcpy/GC per import even though sparse FACS shapes morph
    ~5-10% of verts (strictly more work than v1.9.6's per-index write; the import
    regression). Fix: caller passes a shared `work_buf` (one copy total) + the
    PREVIOUS call's `last_touched`; we reset only those indices to basis, mutate in
    place, foreach_set, and return the touched indices. Identical end state, ~50×
    less memory traffic. Back-compat: omitting work_buf/last_touched = legacy copy.

    Args:
        basis_co: float32 (num_verts*3,) basis coords, computed once and reused.
        work_buf: optional shared float32 buffer (num_verts*3), mutated in-place;
                  caller inits as basis_co.copy() once before the loop.
        last_touched: optional int64 vertex indices written by the PREVIOUS call
                      (None first call), reset back to basis before new morphs.
    Returns (per_shape_skipped, touched_indices); pass touched_indices as
    last_touched next iteration.
    """
    verts = shape.verts
    verts_len = len(verts) if verts is not None else 0

    # Empty-shape fast exit: sk_block.data is already at basis (just added via
    # shape_key_add), so skip foreach_set. But still scrub the PREVIOUS shape's
    # deltas from the shared work_buf — otherwise they survive (the next shape only
    # resets _EMPTY_INDICES) and leak into the next morph. Keeps work_buf == basis.
    if verts_len == 0:
        if (work_buf is not None and last_touched is not None
                and last_touched.size > 0):
            co_view = work_buf.reshape(-1, 3)
            basis_view = basis_co.reshape(-1, 3)
            co_view[last_touched] = basis_view[last_touched]
        return 0, _EMPTY_INDICES

    max_vert_index = (verts_len // 3) - 1

    indices = np.asarray(shape.indices, dtype=np.int64)
    valid = (indices >= 0) & (indices < num_verts) & (indices <= max_vert_index)
    valid_indices = indices[valid]
    skipped = int((~valid).sum())

    # Buffer strategy: shared work_buf is the fast route; local-copy is the
    # back-compat fallback for callers not passing work_buf/last_touched.
    if work_buf is not None:
        co = work_buf
        # Reset PREVIOUS touches to basis (~2.4 KB for a sparse shape vs 288 KB copy).
        if last_touched is not None and last_touched.size > 0:
            co_view = co.reshape(-1, 3)
            basis_view = basis_co.reshape(-1, 3)
            co_view[last_touched] = basis_view[last_touched]
    else:
        co = basis_co.copy()

    if valid_indices.size > 0:
        verts_flat = np.asarray(verts, dtype=np.float32)
        idx3 = valid_indices * 3
        co_view = co.reshape(-1, 3)
        co_view[valid_indices, 0] = verts_flat[idx3]
        co_view[valid_indices, 1] = verts_flat[idx3 + 1]
        co_view[valid_indices, 2] = verts_flat[idx3 + 2]

    sk_block.data.foreach_set('co', co)
    return skipped, valid_indices


# Reusable empty-indices sentinel for fast_apply_blendshape's empty-shape case —
# module-scope so we don't allocate per call (~30-60% of FACS slots are unmorphed).
_EMPTY_INDICES = np.empty(0, dtype=np.int64)


def read_basis_co(sk_basis_data, num_verts):
    """Read basis-shape coords once for reuse across all shape keys."""
    basis = np.empty(num_verts * 3, dtype=np.float32)
    sk_basis_data.foreach_get('co', basis)
    return basis


# ── EXPORT ────────────────────────────────────────────────────────────

def fast_get_mesh_vertices(obj):
    """World-space vertex coords as a flat list.

    Slow path counterpart: blender_utils.getMeshVertices. The Raw export
    path's getRawMeshPositions already does this — same approach here.
    """
    mesh = obj.data
    n = len(mesh.vertices)
    if n == 0:
        return []
    coords = np.empty(n * 3, dtype=np.float32)
    mesh.vertices.foreach_get('co', coords)
    mat = np.array(obj.matrix_world, dtype=np.float32)[:3, :3]
    loc = np.array(obj.matrix_world.translation, dtype=np.float32)
    out = coords.reshape(-1, 3) @ mat.T + loc
    return out.flatten().tolist()


def fast_get_mesh_faces(obj):
    """Flat triangle index list + non-tri count.

    Slow path counterpart: blender_utils.getMeshFaces. Tri-only filter
    preserved exactly — non-tri faces are skipped and counted, the
    caller emits the same warning text on count > 0.
    """
    mesh = obj.data
    n_polys = len(mesh.polygons)
    if n_polys == 0:
        return [], 0

    loop_total = np.empty(n_polys, dtype=np.int32)
    mesh.polygons.foreach_get('loop_total', loop_total)

    n_loops = len(mesh.loops)
    if n_loops == 0:
        return [], int((loop_total != 3).sum())

    loop_start = np.empty(n_polys, dtype=np.int32)
    mesh.polygons.foreach_get('loop_start', loop_start)
    loop_verts = np.empty(n_loops, dtype=np.int32)
    mesh.loops.foreach_get('vertex_index', loop_verts)

    tri_mask = loop_total == 3
    non_tri_count = int((~tri_mask).sum())

    tri_starts = loop_start[tri_mask]
    if tri_starts.size == 0:
        return [], non_tri_count

    indices = np.stack([
        loop_verts[tri_starts],
        loop_verts[tri_starts + 1],
        loop_verts[tri_starts + 2]
    ], axis=1).ravel()

    return indices.tolist(), non_tri_count


def fast_get_vertex_norms(obj):
    """Per-vertex world-space normals as a flat list.

    Slow path counterpart: blender_utils.getVertexNorms. Same semantics:
      1. Zero-init.
      2. For each loop, write loop.normal into the loop's vertex slot
         (last-loop-wins for shared verts).
      3. For untouched verts, fall back to the vertex's own normal.
      4. Apply matrix_world rotation (3x3 part — w=0 on slow path
         means translation is ignored).
      5. Scrub non-finite + zero-length to (0,0,1) and renormalize.
    """
    import math
    mesh = obj.data
    n_verts = len(mesh.vertices)
    if n_verts == 0:
        return []
    n_loops = len(mesh.loops)

    out = np.zeros((n_verts, 3), dtype=np.float64)
    touched = np.zeros(n_verts, dtype=bool)

    if n_loops > 0:
        ln = np.empty(n_loops * 3, dtype=np.float32)
        mesh.loops.foreach_get('normal', ln)
        ln = ln.astype(np.float64).reshape(-1, 3)

        loop_vi = np.empty(n_loops, dtype=np.int32)
        mesh.loops.foreach_get('vertex_index', loop_vi)

        valid = (loop_vi >= 0) & (loop_vi < n_verts)
        vi = loop_vi[valid]
        # Fancy-index assignment writes in order → last-write-wins for repeated
        # indices, matching the Python loop's per-vertex overwrite.
        out[vi] = ln[valid]
        touched[vi] = True

    # Fill untouched verts from vertex normals.
    not_touched = np.nonzero(~touched)[0]
    if not_touched.size > 0:
        vn = np.empty(n_verts * 3, dtype=np.float32)
        mesh.vertices.foreach_get('normal', vn)
        vn = vn.astype(np.float64).reshape(-1, 3)
        out[not_touched] = vn[not_touched]

    # Apply matrix transform (3x3 part).
    mat = np.array(obj.matrix_world, dtype=np.float64)[:3, :3]
    out = out @ mat.T

    # Scrub + renormalize.
    bad = ~np.isfinite(out).all(axis=1)
    if bad.any():
        out[bad] = (0.0, 0.0, 1.0)
    length_sq = (out * out).sum(axis=1, keepdims=True)
    zero_mask = (length_sq < 1e-12).flatten()
    if zero_mask.any():
        out[zero_mask] = (0.0, 0.0, 1.0)
        length_sq[zero_mask] = 1.0
    out = out / np.sqrt(length_sq)

    return out.flatten().tolist()


def fast_get_uv_channel_map(mesh, size, uv_layer):
    """Per-loop UV → per-vertex (last-loop-wins). Returns flat list of
    length size*2. Slow path counterpart: blender_utils.getUvChannelMap.
    """
    n_loops = len(mesh.loops)
    if n_loops == 0 or size == 0:
        return [0.0] * (size * 2)

    uvs = np.empty(n_loops * 2, dtype=np.float32)
    uv_layer.data.foreach_get('uv', uvs)
    uvs = uvs.reshape(-1, 2)

    loop_vi = np.empty(n_loops, dtype=np.int32)
    mesh.loops.foreach_get('vertex_index', loop_vi)

    out = np.zeros((size, 2), dtype=np.float32)
    valid = (loop_vi >= 0) & (loop_vi < size)
    out[loop_vi[valid]] = uvs[valid]

    return out.flatten().tolist()


def fast_read_corner_colors(mesh, size, color_layer, attr_name='color'):
    """Per-loop corner colors → per-vertex list of [r,g,b,a].

    Slow path counterpart: the per-poly per-loop read inside
    blender_utils.getVertexColors. Returns the colors-by-vertex list
    verbatim — the caller hands these straight to the DLL with no
    conversion (1:1 export).

    `attr_name` selects which RNA property we read from each color element.
    Caller (blender_utils._color_io_attr_name) picks 'color_srgb' for
    BYTE_COLOR on 3.5+ to get byte-identity with painted/displayed values,
    or 'color' otherwise. See that helper's docstring for the full rationale.
    """
    n_loops = len(mesh.loops)
    if n_loops == 0 or size == 0:
        return [[0.0, 0.0, 0.0, 0.0] for _ in range(size)]

    colors = np.empty(n_loops * 4, dtype=np.float32)
    try:
        color_layer.data.foreach_get(attr_name, colors)
    except (TypeError, RuntimeError):
        # Defensive: if attr_name was 'color_srgb' on an intermediate Blender
        # build that exposes the attr on the element but rejects it through
        # foreach_get, fall back to plain 'color'. Worst case we lose the
        # byte-identity property and revert to the legacy darken-on-paint
        # behavior — same as before the fix shipped, never worse.
        color_layer.data.foreach_get('color', colors)
    colors = colors.reshape(-1, 4)

    loop_vi = np.empty(n_loops, dtype=np.int32)
    mesh.loops.foreach_get('vertex_index', loop_vi)

    out = np.zeros((size, 4), dtype=np.float32)
    valid = (loop_vi >= 0) & (loop_vi < size)
    out[loop_vi[valid]] = colors[valid]

    return out.tolist()


def fast_get_vertex_weights(obj, skin, obj_groups, unresolved_groups):
    """Vectorize the per-vertex top-N weight pack used during skin export.

    Slow path: getVertexSkin's per-vertex getVertexWeights loop, dominated not by
    math but by per-element dict lookups/function calls (getBoneIndex + GtPt prefix
    check) — 30k verts × 8+ influences = 240k+ resolutions over the same few names.
    Here: pre-resolve group_idx -> (bone_idx, is_gtpt) ONCE, then the inner loop is a
    table lookup + the same math (~40% fewer Python instructions). We do NOT numpy
    the deform-layer read — vertices[i].groups has no foreach_get, so the savings are
    purely in the per-element work.

    Semantics MUST match getVertexWeights: skip <=0 weights, out-of-range indices,
    and GTPT_VG_PREFIX groups; case-sensitive then case-insensitive bone resolution;
    top-N by stable sort; renormalize only when truncated OR |sum-1.0| > 2/255
    (preserves vanilla quantization noise); update the three skin counters; add
    unresolved names to unresolved_groups.
    """
    from ..SkinModel.skinmodel_gp import GTPT_VG_PREFIX

    # Pre-resolve every vertex_group index. bone_lookup[i] = bone_index (>=0), or a
    # distinct negative sentinel for cheap branching:
    #   -1 = real group, no matching bone (unresolved)
    #   -2 = GtPt anchor group (silently skipped, NOT unresolved)
    GTPT_SENTINEL = -2
    NO_BONE_SENTINEL = -1
    bones_index = getattr(skin, 'bones_index', None) or {}
    bones_index_lower = getattr(skin, 'bones_index_lower', None) or {}

    bone_lookup = [NO_BONE_SENTINEL] * len(obj_groups)
    for gi, gname in enumerate(obj_groups):
        if gname.startswith(GTPT_VG_PREFIX):
            bone_lookup[gi] = GTPT_SENTINEL
            continue
        bi = bones_index.get(gname)
        if bi is None:
            bi = bones_index_lower.get(gname.lower(), NO_BONE_SENTINEL)
        bone_lookup[gi] = bi

    n_groups = len(obj_groups)
    weights_per_vertex = skin.weights_per_vertex
    blendweights = skin.blendweights
    blendindices = skin.blendindices
    renorm_threshold = 2.0 / 255.0

    correct = 0
    missing = 0
    unweighted = 0

    for vertex in obj.data.vertices:
        # Collect resolved nonzero influences. Inline the per-element work
        # (no function call per group); mirror getVertexWeights' had_any_weight
        # tracking so the counter semantics match exactly.
        influences = []
        had_any_weight = False
        for elem in vertex.groups:
            w = elem.weight
            if w <= 0.0:
                continue
            gi = elem.group
            if gi < 0 or gi >= n_groups:
                continue
            bi = bone_lookup[gi]
            if bi == GTPT_SENTINEL:
                # Anchor group — doesn't count toward had_any_weight (the slow path's
                # GtPt filter runs before that flag is set).
                continue
            had_any_weight = True
            if bi == NO_BONE_SENTINEL:
                unresolved_groups.add(obj_groups[gi])
                continue
            influences.append((w, bi))

        if not influences:
            if had_any_weight:
                missing += 1
            else:
                unweighted += 1
            continue

        correct += 1

        truncated = False
        if len(influences) > weights_per_vertex:
            influences.sort(key=lambda p: p[0], reverse=True)
            influences = influences[:weights_per_vertex]
            truncated = True

        total = 0.0
        for w, _ in influences:
            total += w
        if total > 0.0:
            if truncated or abs(total - 1.0) > renorm_threshold:
                inv = 1.0 / total
                for i, (w, b) in enumerate(influences):
                    influences[i] = (w * inv, b)

        table_index = vertex.index * weights_per_vertex
        for slot, (w, b) in enumerate(influences):
            blendweights[table_index + slot] = w
            blendindices[table_index + slot] = b

    # Single-shot stat update — cheaper than per-vertex attribute writes.
    skin.verts_correctly_weighted += correct
    skin.verts_weighted_to_missing_bones += missing
    skin.unweighted_verts += unweighted


def fast_get_yobj_weights(obj, bone_name_list, weight_padding_index, max_inf_cap=4):
    """Top-N-by-weight per-vertex bone influences for the YOBJ exporter.

    Slow path: the double loop in Yukes/exporter_blender.collect_meshes_from_blender
    (one pass for max_inf, one to fill the arrays) — the slowest part of YOBJ export.
    v.groups has no foreach_get so we still iterate per-vertex, but collapse the
    per-element work to one dict lookup + a final partial-sort.

    Not shared with fast_get_vertex_weights: the MCD path writes flat
    skin.blendweights/.blendindices under GtPt filtering + counters; YOBJ writes a
    (vc, max_inf) pair, uses WEIGHT_PADDING_INDEX for unused slots, normalizes sums
    to 1.0 at the end, and has no GtPt filter.

    Args:
        bone_name_list: ordered YOBJ bone names ([b.name for b in bones]).
        weight_padding_index: unused-slot sentinel (WEIGHT_PADDING_INDEX,
            0xFFFFFFFF in current builds).
        max_inf_cap: per-vertex influence cap (YOBJ never exceeds 4; a caller knob).
    Returns (bone_indices_arr uint32, bone_weights_arr float32, max_inf), shaped
    (vc, max_inf); (None, None, 0) if no usable influences (preserves the caller's
    "skip weights" branch).
    """
    mesh = obj.data
    vc = len(mesh.vertices)
    if vc == 0:
        return None, None, 0

    # Resolve vg_index -> bone_index ONCE. The slow path rebuilt this on
    # every iteration via list.index() during max_inf discovery.
    bone_index_by_name = {name: i for i, name in enumerate(bone_name_list)}
    vg_to_bone = {}
    for vg in obj.vertex_groups:
        bi = bone_index_by_name.get(vg.name)
        if bi is not None:
            vg_to_bone[vg.index] = bi

    if not vg_to_bone:
        return None, None, 0

    # Single pass: collect resolved (bone_idx, weight) per vertex, track
    # global max influence count. Skipping the slow path's separate
    # max_inf discovery loop already cuts the work in half.
    per_vertex = [None] * vc
    max_inf = 0
    for v in mesh.vertices:
        infl = []
        for elem in v.groups:
            bi = vg_to_bone.get(elem.group)
            if bi is None:
                continue
            w = elem.weight
            if w > 0.0:
                infl.append((bi, w))
        if infl:
            per_vertex[v.index] = infl
            if len(infl) > max_inf:
                max_inf = len(infl)

    if max_inf == 0:
        return None, None, 0

    max_inf = max(1, min(max_inf, max_inf_cap))

    bone_indices_arr = np.full((vc, max_inf), weight_padding_index, dtype=np.uint32)
    bone_weights_arr = np.zeros((vc, max_inf), dtype=np.float32)

    for vidx, infl in enumerate(per_vertex):
        if not infl:
            continue
        # Top-N by weight (stable sort matches Python's list.sort).
        if len(infl) > max_inf:
            infl = sorted(infl, key=lambda p: p[1], reverse=True)[:max_inf]
        for slot, (bi, w) in enumerate(infl):
            bone_indices_arr[vidx, slot] = bi
            bone_weights_arr[vidx, slot] = w

    # Per-vertex normalize — match the slow-path post-step exactly.
    sums = bone_weights_arr.sum(axis=1, keepdims=True)
    sums[sums == 0] = 1.0
    bone_weights_arr = bone_weights_arr / sums

    return bone_indices_arr, bone_weights_arr, max_inf


def fast_get_mesh_vertices_world(obj):
    """World-space vertex coords as a list of mathutils.Vector-equivalent
    3-tuples — matches the per-vertex output shape of a list comprehension
    `[obj.matrix_world @ v.co for v in obj.data.vertices]`.

    Slow path counterpart: the `[matrix_world @ v.co for v in vertices]`
    pattern in blender_save.getSceneColliderGeometry. The triangle-list
    construction next to that call already operates on indices into this
    list, so we preserve list-of-3-tuples semantics rather than returning
    a flat list (which is what fast_get_mesh_vertices does for the DLL
    consumer). Returns an empty list for empty meshes.
    """
    mesh = obj.data
    n = len(mesh.vertices)
    if n == 0:
        return []
    coords = np.empty(n * 3, dtype=np.float64)
    mesh.vertices.foreach_get('co', coords)
    mat = np.array(obj.matrix_world, dtype=np.float64)[:3, :3]
    loc = np.array(obj.matrix_world.translation, dtype=np.float64)
    out = coords.reshape(-1, 3) @ mat.T + loc
    return out.tolist()


def fast_get_blendshape_verts(obj, shape_key):
    """World-space shape-key vertex coords as a flat list.

    Slow path counterpart: blender_utils.getBlendShape's per-vert
    matrix_world @ vert.co list comprehension.
    """
    n = len(shape_key.data)
    if n == 0:
        return []
    co = np.empty(n * 3, dtype=np.float32)
    shape_key.data.foreach_get('co', co)
    mat = np.array(obj.matrix_world, dtype=np.float32)[:3, :3]
    loc = np.array(obj.matrix_world.translation, dtype=np.float32)
    out = co.reshape(-1, 3) @ mat.T + loc
    return out.flatten().tolist()
