import bpy
from mathutils import Vector
from math import radians

def createRigJoint(armature, bones, joint):
    if joint.name == None:
        return

    # Define bone's tail to access it's transform
    bbone = armature.edit_bones.new( joint.name )
    bbone.tail = Vector((0.0, 1.0, 0.0))
    bbone.matrix = joint.matrix

    # Link hierarchy. Bound-check the parent index: getBoneParentIndex only maps
    # -1 -> None, so a malformed file with a stale/garbage parent index >= numBones
    # would IndexError on bones[joint.parent] and abort the whole import. An
    # out-of-range parent simply becomes a root bone. No-op for valid files.
    if joint.parent is not None and 0 <= joint.parent < len(bones):
        parent_joint = bones[joint.parent]
        if parent_joint.scene_bone is not None:
            bbone.parent = parent_joint.scene_bone

    # Set minimum length to prevent culling
    if( bbone.length < .00000001 ):        
        bbone.length = bbone.length + .0001  

    # Update and link blender bone to 'vCRigJoint'
    bones[joint.id].scene_bone = bbone
    return

def loadSkeleton(collection, skeleton):
    # Create an armature object in the scene    
    armature = bpy.data.armatures.new("Skeleton")
    armature.display_type = "WIRE"
    obj = bpy.data.objects.new("Skeleton", armature)

    # Link + activate the new armature so edit-bone ops hit the right data.
    collection.objects.link(obj)
    bpy.context.view_layer.objects.active = obj

    # Enter EDIT explicitly via mode_set (deterministic): editmode_toggle is a no-op
    # if something else is already in edit mode, silently breaking the bone loop.
    # Restore is ALWAYS OBJECT — the old code restored whatever mode the previously-
    # selected object had, which fails on an armature (only OBJECT/EDIT/POSE) and
    # stranded the user in EDIT. OBJECT is the safe importer end state.
    bpy.ops.object.mode_set(mode='EDIT')
    try:
        for joint in skeleton.bones:
            createRigJoint(armature, skeleton.bones, joint)
    finally:
        # Always restore OBJECT, even on a raised bone loop — staying in EDIT after
        # an importer failure blocks subsequent operator calls.
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except RuntimeError:
            # Can fail if the active object changed mid-flight; swallow so we don't
            # mask the original exception.
            pass
    return obj

def build_sphere(name, collection, translate=Vector(), scale=Vector((1, 1, 1))):
    # Create a new empty object
    empty_obj = bpy.data.objects.new(name, None)
    empty_obj.empty_display_type = 'SPHERE'

    # Set the location of the empty sphere
    empty_obj.location = translate
    empty_obj.scale = scale
    collection.objects.link(empty_obj)

    return empty_obj

def add_sphere_constraint(armature, sphere_obj, target_index):
    # Direct constraint API, not bpy.ops.object.constraint_add: the operator sets
    # active object, mutates selection, and queues a viewport refresh (scene-size-
    # scaling work) once per AP (~190 on a default character). Identical result.
    constraint = sphere_obj.constraints.new(type='ARMATURE')
    target     = constraint.targets.new()
    target.target    = armature
    target.subtarget = armature.data.bones[target_index].name
    return

def find_bone_index(armature, target):
    for i, bone in enumerate(armature.data.bones):
        if (bone.name == target):
            return i
    
    return None

def load_attachment_points(collection, root_node, armature_obj, points):
    if (not points): 
        return
    
    skeleton = armature_obj.data
    num_bones = len(skeleton.bones)

    for point in points:
        # point.joint is a signed c_int — a malformed file can yield a negative
        # index that passes the upper-bound check, then bones[negative] binds the
        # constraint to the wrong bone (or IndexErrors). Require a valid range.
        if (0 <= point.joint < num_bones):
            translate = Vector(point.co)
            obj = build_sphere( f"ap_{point.id_a}-{point.id_b}-{point.flag}", collection, translate )
            obj.parent = root_node
            add_sphere_constraint(armature_obj, obj, point.joint)
            
    return



