import bpy, bmesh
from ..SkinModel.skinrig import vCRigJoint, vCSkeleton
from ..SkinModel.skinmesh_blendshapes import vCMeshShape
import mathutils
from mathutils import Vector
from ..Link.log import dlog, dwarn, derror
from . import perf


# ── Vertex color compatibility shim ──
# Blender 3.2 added `color_attributes` and deprecated `vertex_colors`; 5.0 REMOVED
# the `vertex_colors` alias (direct use throws AttributeError). These helpers use
# the new API when available, falling back to legacy on pre-3.2. Both create
# per-loop (CORNER) BYTE_COLOR data, matching the game's on-disk layout.

def _get_color_layer_collection(mesh):
    """Return the color-layer collection: modern `color_attributes` (3.2+),
    falling back to the legacy `vertex_colors` alias on older Blender."""
    if hasattr(mesh, 'color_attributes'):
        return mesh.color_attributes
    return mesh.vertex_colors  # pre-3.2


def _color_io_attr_name(layer):
    """Pick the right RNA property for read/write on this color layer.

    3.5+ exposes 'color' (scene-linear) and 'color_srgb' (sRGB display) per
    color element. For BYTE_COLOR the byte storage IS the sRGB value, so reading
    'color' decodes byte→linear (DARKER than painted), while 'color_srgb' returns
    byte/255 byte-identity with paint mode + the picker. Paint mode and texture→
    vertex-color converters write display bytes (no linear→sRGB step), so reading
    them via 'color' gives the "goes in darker" symptom; vanilla data survives
    because its decode/re-encode is symmetric, only user bytes break.
    FLOAT_COLOR storage is already linear → 'color' is correct there.
    Returns 'color' on pre-3.5 (no 'color_srgb'); hasattr-probed for intermediates.
    """
    if getattr(layer, 'data_type', 'BYTE_COLOR') != 'BYTE_COLOR':
        return 'color'
    try:
        if len(layer.data) > 0 and hasattr(layer.data[0], 'color_srgb'):
            return 'color_srgb'
    except Exception:
        pass
    return 'color'


def get_first_vertex_color_layer(mesh):
    """Return the export-target per-corner color layer on `mesh`, or None.

    3.2+ (color_attributes) selection:
      1. Prefer active_color if CORNER-domain — what every other tool respects
         (paint mode edits it, the render reads it, new-layer tools set it active).
      2. Else first CORNER in iteration order. Single-layer meshes always satisfy
         step 1, so this only fires on legacy data with active_color unset or
         pointing at a POINT layer.
    Why active beats first-CORNER: the old "first CORNER" rule wrote OUR import
    layer when a converter plugin had added a second painted CORNER layer, so the
    user's paint never reached the file ("export discoloured my hair").
    Pre-3.2 `vertex_colors` is single per-corner with no active concept → [0].
    """
    coll = _get_color_layer_collection(mesh)
    if coll is None or len(coll) == 0:
        return None
    if hasattr(mesh, 'color_attributes'):
        # Respect active_color if CORNER-domain. getattr + hasattr domain check
        # guard against API drift (some versions exposed active_color as an int).
        active = getattr(mesh.color_attributes, 'active_color', None)
        if active is not None and hasattr(active, 'domain') and active.domain == 'CORNER':
            return active
        # Fall back to first CORNER in iteration order.
        for layer in coll:
            if getattr(layer, 'domain', 'CORNER') == 'CORNER':
                return layer
        return None
    return coll[0]


def add_vertex_color_layer(mesh, name):
    """Create a new per-corner BYTE_COLOR layer (matching the legacy
    vertex_colors shape) and return it. Works 2.93 through 5.1.
    """
    if hasattr(mesh, 'color_attributes'):
        # 3.2+ — CORNER + BYTE_COLOR matches the old vertex_colors.new().
        try:
            return mesh.color_attributes.new(name=name, type='BYTE_COLOR', domain='CORNER')
        except Exception:
            # Some versions rejected keyword-only args; try positional.
            try:
                return mesh.color_attributes.new(name, 'BYTE_COLOR', 'CORNER')
            except Exception:
                pass
    # Legacy fallback (pre-3.2). Blender hard-caps color layers at 8; past the
    # cap .new() raises or returns None. A file from an early/unfinished exporter
    # can carry more color maps than Blender can hold — return None so the caller
    # skips the surplus instead of crashing. No-op for valid files (<=8 maps).
    try:
        return mesh.vertex_colors.new(name=name)
    except Exception:
        return None


# ── Tangent-preservation fingerprint (WDF safety) ──
# WDF stores barycentric deltas in TANGENT space; regenerated tangents drift and
# break the binding, so the importer captures vanilla tangents (VC_TANGENT /
# VC_TANGENT_SIGN POINT attrs). Those are valid only while the mesh is unchanged.
# computeTbnHash() gates it: a positions+topology fingerprint computed identically
# at import (stored on the object) and export (compared). Match => unedited =>
# feed captured tangents; mismatch/missing => regenerate.
# Hashes RAW float32 position bytes: co is float32 in mesh + .blend and read back
# via foreach_get, so an unedited mesh round-trips BIT-EXACT (makeSkinMeshRaw reads
# co with no reprocessing). Any real edit perturbs the bytes → safe regeneration.
# (A quantized variant was unnecessary and unreliable near quantum boundaries.)

def computeTbnHash(mesh):
    """Return a hex fingerprint of `mesh`'s geometry + topology, or None.

    Hashes vertex count, loop count, raw float32 vertex positions, and per-loop
    vertex indices. Read positions/topology straight off the BASE mesh (never a
    depsgraph-evaluated copy) so import and export agree on an unedited mesh.
    """
    import numpy as np, hashlib
    try:
        num_verts = len(mesh.vertices)
        num_loops = len(mesh.loops)
        if num_verts == 0:
            return None
        co = np.empty(num_verts * 3, dtype=np.float32)
        mesh.vertices.foreach_get('co', co)
        li = np.empty(num_loops, dtype=np.int32)
        if num_loops:
            mesh.loops.foreach_get('vertex_index', li)
        h = hashlib.blake2b(digest_size=16)
        h.update(np.int64(num_verts).tobytes())
        h.update(np.int64(num_loops).tobytes())
        h.update(np.ascontiguousarray(co, dtype=np.float32).tobytes())
        h.update(np.ascontiguousarray(li, dtype=np.int32).tobytes())
        return h.hexdigest()
    except Exception as e:
        dlog(f"[MDL Addon] computeTbnHash failed: {e}")
        return None


class CVertexSkin():
    @staticmethod
    def get_vertex_limit():
        # Defines total weights allowed per mesh vertex
        return 8

    def __set_bones(self, obj):
        # Authoritative armature = the ARMATURE modifier's object (Blender uses it
        # at render time; the exporter must match). Fall back to the parent only
        # if no modifier is present (very old .blends).
        armature_obj = None
        for mod in obj.modifiers:
            if mod.type == 'ARMATURE' and mod.object and mod.object.data:
                armature_obj = mod.object
                break
        if armature_obj is None and obj.parent and obj.parent.data and hasattr(obj.parent.data, 'bones'):
            armature_obj = obj.parent

        if armature_obj is not None:
            self.bones = [bone.name for bone in armature_obj.data.bones]
        else:
            self.bones = []

        # Lookup tables: exact match (common) + a case-insensitive table that
        # silently auto-fixes vertex-group/bone case mismatches (e.g. 'h_thigh_l'
        # vs 'H_Thigh_L'). Without it those weights drop on export → unexplained
        # spike-at-origin in-game.
        self.bones_index = {b: i for i, b in enumerate(self.bones)}
        self.bones_index_lower = {b.lower(): i for i, b in enumerate(self.bones)}
        return

    def prepopulate_skin(self, source_object):
        # Prepopulates skin with empty index/skin values
        num_vertices = len(source_object.data.vertices)

        self.blendindices = [0]   * (num_vertices * self.weights_per_vertex)
        self.blendweights = [0.0] * (num_vertices * self.weights_per_vertex)
        self.__set_bones(source_object)
        return

    def __init__(self):
        self.blendindices = []
        self.blendweights = []
        self.bones = None
        self.weights_per_vertex = None

        # Bone-name lookup caches (built in __set_bones; O(1) + case-insensitive).
        self.bones_index = {}
        self.bones_index_lower = {}

        # Per-mesh deform-validation counters. getVertexWeights updates them per
        # vertex; getVertexSkin reads them to build the Blender UI messages.
        self.total_verts = 0
        self.verts_correctly_weighted = 0      # had >=1 resolvable nonzero weight
        self.verts_weighted_to_missing_bones = 0  # had weights, none resolved to a bone
        self.unweighted_verts = 0              # no nonzero vertex group weights at all

        # (severity, message) tuples; severity 'ERROR'/'WARNING' per operator.report.
        # saveSkinModel surfaces each as a UI banner (not buried in the console).
        self.validation_warnings = []

def setBlenderMode(target_mode, select_obj=None):
    if (select_obj):
        bpy.context.view_layer.objects.active = select_obj

    # bpy.context.mode returns edit modes prefixed ('EDIT_MESH'/'EDIT_ARMATURE'/...)
    # while the arg is 'EDIT', so a direct compare never matched — the early-return
    # was dead and every call issued a mode_set, hundreds of redundant depsgraph-
    # triggering switches on a 200+-prop arena export. Normalizing the EDIT_ prefix
    # here roughly halved arena export time.
    current = bpy.context.mode
    if current == target_mode:
        return
    if target_mode == 'EDIT' and current.startswith('EDIT_'):
        return

    # Switch to the target mode
    bpy.ops.object.mode_set(mode=target_mode)
    return

def getEditMesh(obj):
    setBlenderMode('EDIT', obj)
    bm = bmesh.from_edit_mesh(obj.data)
    return bm

def has_armature_modifier(obj):
    return any(mod.type == 'ARMATURE' for mod in obj.modifiers)

def markMeshSeamsFromUVs():
    # Mark seams from UV islands — bmesh approach for Blender 5.0 compat
    # (bpy.ops.uv.select_all poll fails without UV editor context in 5.0)
    obj = bpy.context.active_object
    bm = bmesh.from_edit_mesh(obj.data)
    uv_layer = bm.loops.layers.uv.active
    if not uv_layer:
        return
    
    for edge in bm.edges:
        if len(edge.link_loops) != 2:
            continue
        # Get UV coords on both sides of the edge
        loop_a = edge.link_loops[0]
        loop_b = edge.link_loops[1]
        # Find the matching loops on the other face
        loop_a_next = loop_a.link_loop_next if loop_a.link_loop_next.vert == edge.other_vert(loop_a.vert) else loop_a.link_loop_prev
        loop_b_next = loop_b.link_loop_next if loop_b.link_loop_next.vert == edge.other_vert(loop_b.vert) else loop_b.link_loop_prev
        
        uv_a0 = loop_a[uv_layer].uv
        uv_a1 = loop_a_next[uv_layer].uv
        uv_b0 = loop_b[uv_layer].uv
        uv_b1 = loop_b_next[uv_layer].uv
        
        # Edge is a seam if UV coords don't match across faces
        threshold = 0.0001
        match_0 = (abs(uv_a0.x - uv_b1.x) < threshold and abs(uv_a0.y - uv_b1.y) < threshold)
        match_1 = (abs(uv_a1.x - uv_b0.x) < threshold and abs(uv_a1.y - uv_b0.y) < threshold)
        
        if not (match_0 and match_1):
            edge.seam = True
    
    bmesh.update_edit_mesh(obj.data)
    return

def triangulate_mesh(bm):
    # ngon_method='EAR_CLIP' is REQUIRED: the default 'BEAUTY' edge-flips to
    # maximize aspect ratio without enforcing polygon-containment, so on highly
    # concave ngons (arena WWE-logo cutouts, truss cross-bracing) it emits tris
    # whose bodies cross the boundary — interior fills with cross-hatching while
    # the outline survives (the reported arena-export symptom; wrestlemania_42.obj
    # 23-gon logo faces are highly concave). EAR_CLIP clips convex corners along
    # the perimeter, never crossing the boundary; throughput diff is negligible here.
    # quad_method stays 'BEAUTY' — for quads the diagonal only affects shading
    # (both diagonals lie inside; concave "dart" quads are vanishingly rare).
    bmesh.ops.triangulate(bm, faces=bm.faces[:], ngon_method='EAR_CLIP')
    return

def isTriangulated(obj):
    for face in obj.data.polygons:
        if len( face.vertices ) != 3:
            return False
        
    return True


def has_multiple_facegroups(obj):
    """True if the mesh's faces use more than one material slot.

    Why it matters: the DLL's export facegroup dispatch routes faces by per-face
    material index and relies on shared verts at facegroup boundaries to keep
    bone-binding coherent. If the addon pre-splits those boundary verts (the UV-
    seam pass does, since UV islands and material boundaries coincide on attire),
    each clone lands on the wrong side and binds to the OTHER facegroup's bones —
    in-game symptom is multi-facegroup garments (vests/jackets) clipping through
    the body. So on multi-facegroup meshes, callers skip the Python seam split
    (leaving DLL native dispatch) but still triangulate (which the DLL needs).

    Detected by ACTUALLY USED material indices, not slot count: extra
    material_slots can exist unassigned (benign editor/import state), so
    len(material_slots) would false-positive. Early-out on the second distinct
    index — no need to walk every face for a binary answer.
    """
    if not obj.data.polygons:
        return False
    first = obj.data.polygons[0].material_index
    for poly in obj.data.polygons:
        if poly.material_index != first:
            return True
    return False


def mesh_has_welded_uv_seams(obj):
    """True if any vertex carries more than one distinct loop-UV (in ANY layer) — i.e.
    the mesh shares vertices across UV islands ('welded', the normal state of a freshly
    FBX-imported custom mesh). Such a vertex cannot be represented by the per-vertex UV
    export read (getUvChannelMap is last-loop-wins) without a UV-seam split first; on a
    MULTI-material mesh that split is skipped (format_game_uv_seams leaves DLL native
    dispatch to separate boundaries), so the per-vertex read collapses every UV island
    to one arbitrary loop's UV — the 'mangled UVs' symptom on custom meshes.

    Vanilla game meshes are imported already-split (exactly one UV per vertex per layer)
    so this returns False for them — the gate that keeps the default-path auto-route
    (getSceneMeshes) from ever touching a vanilla round-trip. Fast numpy; quantized to
    1/4096 to ignore float noise; per-layer early-out on the first welded layer."""
    me = getattr(obj, 'data', None)
    if me is None or len(me.polygons) == 0 or len(me.uv_layers) == 0:
        return False
    import numpy as np
    nloop = len(me.loops)
    if nloop == 0:
        return False
    lvi = np.empty(nloop, np.int32); me.loops.foreach_get('vertex_index', lvi)
    lvi64 = lvi.astype(np.int64)
    verts_used = np.unique(lvi64).size
    for uvl in me.uv_layers:
        a = np.empty(nloop * 2, np.float32); uvl.data.foreach_get('uv', a)
        q = np.round(a.reshape(-1, 2) * 4096.0).astype(np.int64)
        pair = np.stack([lvi64, q[:, 0], q[:, 1]], axis=1)
        if np.unique(pair, axis=0).shape[0] > verts_used:
            return True   # some vertex has >1 distinct UV in this layer -> welded seam
    return False


def unpack_values(packed_values):
    unpacked_values = []

    for value in packed_values:
        for ele in value:
            unpacked_values.append(ele)

    return unpacked_values

def getMeshVertices(obj):
    # Fast path — foreach_get + numpy matmul (like getRawMeshPositions).
    if perf._enabled():
        try:
            return perf.fast_get_mesh_vertices(obj)
        except Exception as e:
            dlog(f"[MDL Addon] getMeshVertices fast path skipped ({e}); using slow path.")

    # unpack all verts relative to world space
    coords = [position for vert in obj.data.vertices for position in obj.matrix_world @ vert.co]
    return coords

def getMeshFaces(obj):
    """Collect triangle vertex indices for export.

    setMeshData reads the index list as a flat tri array (3 indices each). A non-
    tri polygon slipping through (shouldn't — format_game_uv_seams triangulates —
    but possible on a vertex-only mesh or a post-format join) shifts every
    subsequent triangle by one index → silent corruption / game crash on load.
    Defensive: emit only 3-vertex faces, warn (naming the mesh) on any other.
    """
    index_list = []
    non_tri_count = 0

    # Fast path — vectorized tri-only filter (same warning + shape as slow path).
    fast_done = False
    if perf._enabled():
        try:
            index_list, non_tri_count = perf.fast_get_mesh_faces(obj)
            fast_done = True
        except Exception as e:
            dlog(f"[MDL Addon] getMeshFaces fast path skipped ({e}); using slow path.")

    if not fast_done:
        for f in obj.data.polygons:
            if len(f.vertices) == 3:
                for vertex in f.vertices:
                    index_list.append(obj.data.vertices[vertex].index)
            else:
                non_tri_count += 1

    if non_tri_count > 0:
        # No crash here, but the mesh exports with missing faces — and non-tris
        # slipping past upstream triangulation are the "game crashes on load" path.
        dwarn(f"[MDL Addon] Warning: '{obj.name}' had {non_tri_count} "
              f"non-triangular face(s) skipped during export. Triangulate "
              f"the mesh (Ctrl+T in Edit mode) and re-export to avoid "
              f"missing geometry in-game.")

    return index_list

def getVertexNorms(obj):
    """Read per-vertex normals for export.

    Strategy:
      1. Zero-init (NOT list(range(...)), which left integer garbage in untouched
         slots → tiny denormals the DLL's tangent reconstruction read as near-zero
         → NaN → game crash on skinning; the prime 4.3-export crash candidate,
         since 4.3 bmesh ops leave more orphan verts than 5.1).
      2. Transform each loop normal to world space, write per-vertex (last-loop-
         wins for shared verts; the DLL re-derives smoothing from its own data).
      3. Untouched verts fall back to the vertex's own transformed normal (rare;
         arena props, vertex-only physics meshes).
      4. Final renormalize sweep — matrix_world on scaled objects yields non-unit
         normals; re-unify so the DLL packs clean data.
    """
    import math

    # Fast path — foreach_get loop normals + numpy scatter (last-loop-wins), one
    # matmul for the world transform, vectorized scrub matching the slow path.
    if perf._enabled():
        try:
            return perf.fast_get_vertex_norms(obj)
        except Exception as e:
            dlog(f"[MDL Addon] getVertexNorms fast path skipped ({e}); using slow path.")

    numVerts = len(obj.data.vertices)
    if numVerts == 0:
        return []

    # Zero-init, NOT list(range(...)).
    normals = [0.0] * (numVerts * 3)
    touched = [False] * numVerts

    for loop in obj.data.loops:
        vi = loop.vertex_index
        if vi < 0 or vi >= numVerts:
            # Defensive — guard against a stale loop index from a mesh edit op.
            continue
        normal_local = loop.normal.to_4d()
        normal_local.w = 0
        normal_local = (obj.matrix_world @ normal_local).to_3d()

        index = vi * 3
        normals[index]     = normal_local.x
        normals[index + 1] = normal_local.y
        normals[index + 2] = normal_local.z
        touched[vi] = True

    # Fill verts no loop referenced with their own transformed normal (matters on
    # vertex-only meshes and where a bmesh op left orphans).
    for vi in range(numVerts):
        if touched[vi]:
            continue
        vnorm = obj.data.vertices[vi].normal
        n4 = vnorm.to_4d()
        n4.w = 0
        wn = (obj.matrix_world @ n4).to_3d()
        index = vi * 3
        normals[index]     = wn.x
        normals[index + 1] = wn.y
        normals[index + 2] = wn.z

    # Final renormalize sweep — handles non-uniform scale and guarantees the DLL
    # never sees a zero-length/non-finite normal (NaN propagation → game crash).
    safe_x, safe_y, safe_z = 0.0, 0.0, 1.0  # +Z fallback
    for vi in range(numVerts):
        idx = vi * 3
        x, y, z = normals[idx], normals[idx + 1], normals[idx + 2]
        if not (math.isfinite(x) and math.isfinite(y) and math.isfinite(z)):
            normals[idx], normals[idx+1], normals[idx+2] = safe_x, safe_y, safe_z
            continue
        length_sq = x*x + y*y + z*z
        if length_sq < 1e-12:
            normals[idx], normals[idx+1], normals[idx+2] = safe_x, safe_y, safe_z
            continue
        inv_len = 1.0 / math.sqrt(length_sq)
        normals[idx]     = x * inv_len
        normals[idx + 1] = y * inv_len
        normals[idx + 2] = z * inv_len

    return normals

def _readCarriedTangents(obj):
    """Shared core for the two export tangent readers.

    Returns (N,4) float32 [x,y,z,w] of captured vanilla tangents in the SAME world
    frame the exporter uses for positions/normals (matrix_world rot/scale), w
    flipped if that transform mirrors (det<0). Returns None ("regenerate") unless
    ALL hold:
        * VC_TANGENT (FLOAT_VECTOR, POINT) present, length == vertex count
        * VC_TBN_HASH present AND == freshly recomputed geometry+topology hash
          (mesh UNEDITED)
    The hash gate makes this safe: any edit trips it and falls back to MikkTSpace
    rather than feeding stale tangents.
    """
    import numpy as np

    mesh = obj.data
    num_verts = len(mesh.vertices)
    if num_verts == 0:
        return None
    if not hasattr(mesh, "attributes"):
        # No generic attributes API at all (shouldn't happen on supported Blender).
        # Reading an existing attribute is realloc-free, so it is safe on every version
        # where import captured one (2.93+); only a missing API returns None here.
        return None

    a_xyz = mesh.attributes.get("VC_TANGENT")
    if a_xyz is None or getattr(a_xyz, 'domain', None) != 'POINT':
        return None
    if len(a_xyz.data) != num_verts:
        return None

    # Edit gate: stored fingerprint must match the current geometry.
    stored = obj.get("VC_TBN_HASH", None)
    if not stored:
        return None
    if computeTbnHash(mesh) != stored:
        dlog(f"[MDL Addon] '{obj.name}': geometry changed since import — "
             f"regenerating tangents (WDF binding may need a refresh).")
        return None

    xyz = np.empty(num_verts * 3, dtype=np.float32)
    a_xyz.data.foreach_get('vector', xyz)
    xyz = xyz.reshape(num_verts, 3)

    a_w = mesh.attributes.get("VC_TANGENT_SIGN")
    if a_w is not None and len(a_w.data) == num_verts:
        w = np.empty(num_verts, dtype=np.float32)
        a_w.data.foreach_get('value', w)
    else:
        w = np.ones(num_verts, dtype=np.float32)
    w = np.sign(w)
    w[w == 0] = 1.0

    # Same world transform as positions/normals; the 3x3 == matrix_world @ vec4(w=0).
    mat3 = np.array(obj.matrix_world.to_3x3(), dtype=np.float64)
    out_xyz = (xyz.astype(np.float64) @ mat3.T)

    # Renormalize (guards scale + non-finite); a no-op within snorm quantization
    # on a clean rotation, so byte-exactness holds.
    lengths = np.linalg.norm(out_xyz, axis=1, keepdims=True)
    bad = (~np.isfinite(lengths[:, 0])) | (lengths[:, 0] < 1e-12)
    lengths[lengths < 1e-12] = 1.0
    out_xyz = out_xyz / lengths
    if np.any(bad):
        out_xyz[bad] = (0.0, 0.0, 1.0)  # +Z fallback, matches getVertexNorms

    # Handedness flips under a mirroring (det<0) transform to keep the bitangent
    # w*cross(n,t) consistent. det>0 (the WDF case) => no-op.
    if np.linalg.det(mat3) < 0.0:
        w = -w

    out = np.empty((num_verts, 4), dtype=np.float32)
    out[:, :3] = out_xyz.astype(np.float32)
    out[:, 3]  = w
    return out

def getVertexTangents(obj):
    """Per-vertex carried tangents for the LEGACY export path (makeSkinMesh).

    Returns a flat stride-4 python list [x,y,z,w, ...] (num_verts*4) ready for
    cmesh.set_tangents, or None to let the DLL regenerate. See
    _readCarriedTangents for the preservation gate.
    """
    out = _readCarriedTangents(obj)
    if out is None:
        return None
    return out.reshape(-1).tolist()

def getUvChannelMap(bmesh, size, uv_layer):
    # Fast path — foreach_get per-loop UVs + scatter to per-vertex
    # (last-loop-wins). Same flat list shape on output.
    if perf._enabled():
        try:
            return perf.fast_get_uv_channel_map(bmesh, size, uv_layer)
        except Exception as e:
            dlog(f"[MDL Addon] getUvChannelMap fast path skipped ({e}); using slow path.")

    model_uvs = [ [0,0] ] * size

    for face in bmesh.polygons:
        for vert_idx, loop_idx in zip(face.vertices, face.loop_indices):
            uv_coords = uv_layer.data[loop_idx].uv
            model_uvs[vert_idx] = ( uv_coords.x , uv_coords.y )
    
    # Unpack for target cmesh (optional) ...
    model_uvs = unpack_values(model_uvs)
    return model_uvs

def getTexCoords(obj):
    uv_sets     = obj.data.uv_layers
    uv_maps     = []
    total_verts = len(obj.data.vertices)
    
    for layer in uv_sets:
        map = getUvChannelMap(obj.data, total_verts, layer)
        uv_maps.append( map )

    return uv_maps

def _strip_blender_dup_suffix(name):
    """Strip Blender's ".001".."999" de-dup suffix to recover the canonical game
    material name. Game material slot names (eye_r:skinned, glasses_ALPHA:skinned,
    lambert1, belt_*) contain no '.', so a trailing ".<digits>" is always Blender's
    dedup, never part of the name."""
    if not name:
        return name
    import re
    return re.sub(r'\.\d+$', '', name)


def getMaterialFaceGroups(obj):
    """Return contiguous per-material face-group ranges for a MULTI-material mesh as
    a list of (material_name, faceBegin_tris, numTriangles) in polygon order — the
    exact layout the serializer's writeMaterialGroupBuffer emits (it walks
    mesh->triangles[faceBegin .. faceBegin+numTriangles) group by group and writes
    faceBegin*3 / numTriangles*3 as index offsets).

    Returns None for 0/1-material meshes so the single-material set_name_info path
    (the common case) is left completely unchanged. This re-lands the eye_r /
    _ALPHA second-material drop the audit found: the DLL's setMeshData creates ONE
    default group from set_name_info, so every material past the first was silently
    dropped (basemodel right-eye, glasses opaque lens, _ALPHA cutouts).

    TRIANGLE UNITS: a run's numTriangles = sum over its polygons of (loop_count - 2),
    exact on BOTH export paths — the legacy path is pre-triangulated (1 tri/poly)
    and the DLL-preprocess path fan-triangulates each n-gon into n-2 triangles in
    polygon order. splitUvSeams / reorderSplitToVanilla permute vertex INDICES,
    never triangle ORDER, so these ranges stay aligned to mesh->triangles even when
    the render layout is restored (or, on a count mismatch, isn't).
    """
    me = getattr(obj, 'data', None)
    if me is None:
        return None
    mats = me.materials
    polys = me.polygons
    if mats is None or len(mats) < 2 or len(polys) == 0:
        return None

    def _mat_name(i):
        if 0 <= i < len(mats) and mats[i] is not None:
            return _strip_blender_dup_suffix(mats[i].name)
        return None

    groups = []
    cur_idx = None
    cur_name = None
    cur_begin = 0     # triangle offset of the current run
    cur_count = 0     # triangles accumulated in the current run
    tri_cursor = 0    # running triangle offset across all polys

    for poly in polys:
        ntri = len(poly.vertices) - 2
        if ntri < 1:
            ntri = 1  # degenerate-poly guard; keep the cursor monotonic
        mi = poly.material_index
        if mi != cur_idx:
            if cur_idx is not None and cur_count > 0:
                groups.append((cur_name, cur_begin, cur_count))
            cur_idx = mi
            cur_name = _mat_name(mi)
            cur_begin = tri_cursor
            cur_count = 0
        cur_count += ntri
        tri_cursor += ntri
    if cur_idx is not None and cur_count > 0:
        groups.append((cur_name, cur_begin, cur_count))

    # Only override the default path when >=2 DISTINCT materials are actually used
    # by faces — a lone material (even split across runs) keeps set_name_info.
    used_names = {g[0] for g in groups if g[0]}
    if len(used_names) < 2:
        return None

    # A run with an empty slot (name None) would drop that triangle range from the
    # index buffer (missing geometry). Fail safe to the single-material path rather
    # than emit a hole.
    if any(g[0] is None for g in groups):
        return None

    return groups


def getVertexColors(obj):
    total_verts = len(obj.data.vertices)

    # Earlier versions hard-skipped M_Head/M_Body/M_Teeth, blaming spurious empty
    # color layers for black shading. Wrong diagnosis — the real cause was stale
    # vcmodel_vertex_remap / sidecar string-table entries from prior broken exports
    # (fixed separately). The skip blocked legitimate streams (M_Body cpv/pores,
    # M_Teeth teeth_SSS) from round-tripping. Now export whatever CORNER layer is
    # present regardless of name; None if none (safe no-op in add_vertex_colors).
    color_layer = get_first_vertex_color_layer(obj.data)
    if color_layer is None:
        return None

    # RNA property to read: 'color_srgb' for BYTE_COLOR on 3.5+ (byte-identity with
    # painted values), 'color' for FLOAT_COLOR / older. See _color_io_attr_name.
    color_attr = _color_io_attr_name(color_layer)

    # Fast path — foreach_get + scatter; same [r,g,b,a]-per-vertex shape as slow.
    colors = None
    if perf._enabled():
        try:
            colors = perf.fast_read_corner_colors(
                obj.data, total_verts, color_layer, attr_name=color_attr)
        except Exception as e:
            dlog(f"[MDL Addon] getVertexColors fast read skipped ({e}); using slow path.")
            colors = None

    if colors is None:
        colors = [ [0,0,0,0] ] * total_verts
        for poly in obj.data.polygons:
            # l_ix IS the loop's global index in color_layer.data. A manual counter
            # only works while loops run in poly-traversal order; after some bmesh
            # ops it doesn't, pulling colors from wrong loops (matches getUvChannelMap).
            for v_ix, l_ix in zip(poly.vertices, poly.loop_indices):
                colors[v_ix] = getattr(color_layer.data[l_ix], color_attr)

    # 1:1 export: hand the DLL exactly what the creator painted. Earlier builds ran
    # a per-vertex HSL→RGB "rescue" on hair (heuristic R<0.15 ∧ G>0.3 ∧ B>0.05),
    # which was the random red/green hair-streak bug — a few boundary verts (AO/
    # quantization drift) crossed the trigger window and rotated to orange/red while
    # the rest stayed brown, intermittently (only visible once a model had enough
    # boundary verts). Removed entirely; convert HSL-picker values in Blender first.
    colors = unpack_values(colors)
    return colors


def getAllVertexColors(obj):
    """Return EVERY vertex-color map as a list of flat per-vertex color arrays — one
    per CORNER-domain color attribute, in attribute (= import/DLL-map) order. The
    DLL's addMeshColorMap appends one channel per call, so build() emits each in
    order, restoring 2K26 meshes that ship >1 map (M_Body cpv+pores, M_Teeth
    teeth_SSS, hair up to 6) which the single-layer getVertexColors path silently
    dropped past the first. Returns None when the mesh carries no color layer, so the
    single-/no-color behavior is unchanged.

    Order rationale: import's setMeshColors creates one CORNER layer per DLL color
    map in map order; Blender appends new attributes, so color_attributes iteration
    order == DLL map order == the order we re-emit. Restricted to CORNER (the only
    domain import creates and the only one the per-loop→per-vertex scatter handles)."""
    me = obj.data
    total_verts = len(me.vertices)
    layers = _get_color_layer_collection(me)
    if not layers or len(layers) == 0:
        return None

    out = []
    for layer in layers:
        if getattr(layer, 'domain', 'CORNER') != 'CORNER':
            continue  # import only ever makes CORNER color maps
        color_attr = _color_io_attr_name(layer)
        colors = None
        if perf._enabled():
            try:
                colors = perf.fast_read_corner_colors(
                    me, total_verts, layer, attr_name=color_attr)
            except Exception as e:
                dlog(f"[MDL Addon] getAllVertexColors fast read skipped ({e}); slow path.")
                colors = None
        if colors is None:
            colors = [[0, 0, 0, 0]] * total_verts
            for poly in me.polygons:
                for v_ix, l_ix in zip(poly.vertices, poly.loop_indices):
                    colors[v_ix] = getattr(layer.data[l_ix], color_attr)
        out.append(unpack_values(colors))
    return out if out else None


def cache_vertex_normals(obj, mesh):
    vertex_cache = {}
    vertex_normals = {}

    # Iterate over all faces in the mesh
    for face in mesh.faces:
        for vert, loop in zip(face.verts, face.loops):
            # Round to 5 dp to match boundary verts across meshes (head/body neck
            # boundary drifts slightly after bmesh ops).
            vertex_coords = (round(vert.co.x, 5), round(vert.co.y, 5), round(vert.co.z, 5))
            normal = vert.normal.copy()

            if vertex_coords not in vertex_normals:
                vertex_normals[vertex_coords] = []

            vertex_normals[vertex_coords].append(normal)

    # Calculate average normals for each vertex
    for vertex_coords, normals in vertex_normals.items():
        average_normal = sum(normals, Vector()) / len(normals)
        vertex_cache[vertex_coords] = average_normal

    return vertex_cache

def get_transferred_split_normals(mesh, vertex_cache):
    if (not vertex_cache): return

    split_normals = [Vector((0, 0, 1))] * len(mesh.vertices)

    for loop in mesh.loops:
        vertex = mesh.vertices[ loop.vertex_index ]
        coord = (round(vertex.co.x, 5), round(vertex.co.y, 5), round(vertex.co.z, 5))
        if coord in vertex_cache:
            split_normals[loop.vertex_index] = vertex_cache[coord]
        
    return split_normals

def split_mesh_edges(obj, bm, vertex_cache):
    dlog(f"[Mesh Format] Target Mesh requires a uv split")
    if (not vertex_cache):
        vertex_cache = cache_vertex_normals(obj, bm)

    target_edges = [e for e in bm.edges if e.seam]
    bmesh.ops.split_edges(bm, edges=target_edges)
    return vertex_cache

def check_uv_seams(obj, bm, vertex_cache):
    # Skip meshes with no UV layers (physics drivers, etc.)
    if not bm.loops.layers.uv.active:
        return vertex_cache
    
    # Unmark old seams
    for edge in bm.edges:
        edge.seam = False
    
    # Try and mark all uv seams
    markMeshSeamsFromUVs()
    
    # Check if any seams are marked
    for e in bm.edges:
        if e.seam: return split_mesh_edges(obj, bm, vertex_cache)
    return vertex_cache


def propagate_vertex_remap_after_split(obj, pre_split_vert_count):
    """After triangulation + UV edge splits, new vertices may have been created.
    New vertices are clones of existing ones (same position), so they inherit
    the same remap value."""
    import json, numpy as np

    post_split_vert_count = len(obj.data.vertices)
    if post_split_vert_count == pre_split_vert_count:
        return
    if "vcmodel_vertex_remap" not in obj:
        return

    try:
        old_remap = json.loads(obj["vcmodel_vertex_remap"])
    except Exception:
        return

    if not old_remap or len(old_remap) != pre_split_vert_count:
        return

    dlog(f"[Mesh Format] Propagating vertex remap: {pre_split_vert_count} → {post_split_vert_count} verts")

    all_n = post_split_vert_count
    all_coords = np.empty(all_n * 3, dtype=np.float32)
    obj.data.vertices.foreach_get('co', all_coords)
    all_coords = all_coords.reshape((all_n, 3))

    def to_key(xyz):
        return (round(float(xyz[0]), 5), round(float(xyz[1]), 5), round(float(xyz[2]), 5))

    pos_to_remap = {}
    for i in range(pre_split_vert_count):
        k = to_key(all_coords[i])
        if k not in pos_to_remap:
            pos_to_remap[k] = old_remap[i]

    new_remap = list(old_remap)
    for i in range(pre_split_vert_count, post_split_vert_count):
        k = to_key(all_coords[i])
        new_remap.append(pos_to_remap.get(k, i))

    obj["vcmodel_vertex_remap"] = json.dumps(new_remap)
    dlog(f"[Mesh Format] Remap propagated: {post_split_vert_count - pre_split_vert_count} new verts mapped")


def snapshot_pre_split_topology(obj, edit_bm):
    """Capture vertex-group + face-topology state to map every post-split clone
    vertex back to its unambiguous pre-split source.

    Call AFTER triangulation on edit_bm but BEFORE bmesh.ops.split_edges. Then:
      - face count is final (split_edges only re-points loops, so face indices
        are stable through the split)
      - vertex indices are still pre-split → obj.data.vertices is the canonical
        pre-split membership
      - the bmesh face→vert relationship matches the post-split loop slots.
    Returns {'vert_groups','face_verts'}. The split data sources are deliberate:
    vert_groups from obj.data (deform CustomData layer, what both bmesh + export
    read), face topology from the bmesh (freshest post-triangulate view —
    obj.data.polygons isn't updated yet here).
    """
    # Per source-vert: (group_idx, weight) for nonzero weights only (drops bulk
    # storage and avoids re-filtering per clone in propagation).
    vert_groups = {}
    for v in obj.data.vertices:
        gs = [(e.group, e.weight) for e in v.groups if e.weight > 0.0]
        if gs:
            vert_groups[v.index] = gs

    # Per-face: ordered tuple of pre-split vert indices. ORDER matters —
    # propagation indexes by loop position to resolve each clone's source.
    face_verts = [tuple(v.index for v in f.verts) for f in edit_bm.faces]

    return {'vert_groups': vert_groups, 'face_verts': face_verts}


def propagate_vertex_groups_after_split(obj, pre_split_vert_count, snapshot=None):
    """Post-hoc safety net for vertex group propagation.

    Primary propagation happens in bmesh space inside split_mesh_edges (BMVert
    identity + deform layer directly) — the only correct path on cloth-physics
    meshes (snake-skin tearing), since bmesh↔obj.data.polygons face-index alignment
    isn't a documented invariant. This runs after that and after update_edit_mesh
    commits, as verify+repair: happy path finds every clone already matching the
    snapshot (skipped_match, no-op); failure path clear-and-rewrites via the
    vertex_groups API to the same end state.

    With snapshot: face-topology lookup — for each clone find a face using it in
    obj.data.polygons, look up that face in snapshot.face_verts, read the source
    at that loop slot. Matches the bmesh-space result when well-aligned (typical),
    and finds values already correct when not.
    snapshot=None: legacy position-key lookup — less accurate on coincident verts,
    kept for callers not yet wired to capture a snapshot.
    """
    post_split_vert_count = len(obj.data.vertices)
    if post_split_vert_count == pre_split_vert_count:
        return  # no split happened, nothing to propagate

    if snapshot is None:
        return _propagate_groups_positional_fallback(obj, pre_split_vert_count)

    vert_groups_snapshot = snapshot.get('vert_groups') or {}
    face_verts_snapshot = snapshot.get('face_verts') or []

    if not face_verts_snapshot:
        # Empty snapshot — fall back rather than silently no-op.
        return _propagate_groups_positional_fallback(obj, pre_split_vert_count)

    # clone_idx -> (face_idx, loop_pos) for the FIRST face referencing each clone.
    # By the split_edges invariant every referencing face resolves to the same
    # source, so first hit suffices (clones appear in 4-6 faces on body meshes).
    clone_origin = {}
    polygons = obj.data.polygons
    snap_len = len(face_verts_snapshot)
    for fidx in range(len(polygons)):
        if fidx >= snap_len:
            # Face count grew beyond snapshot (shouldn't happen) — guard vs IndexError.
            break
        for loop_pos, vidx in enumerate(polygons[fidx].vertices):
            if vidx >= pre_split_vert_count and vidx not in clone_origin:
                clone_origin[vidx] = (fidx, loop_pos)

    if not clone_origin:
        return

    # Cache vertex_groups as a list once: obj.vertex_groups[] indexing is O(N) in
    # RNA, so a plain list amortizes the propagation loop.
    vg_by_index = list(obj.vertex_groups)
    vg_count = len(vg_by_index)

    # uint8 unorm quantization step — drift within this (~1/255 from float storage)
    # is round-trip noise, not a meaningful diff.
    weight_eps = 2.0 / 255.0

    propagated = 0
    cleared = 0
    skipped_match = 0

    for clone_idx, (fidx, loop_pos) in clone_origin.items():
        pre_face = face_verts_snapshot[fidx]
        if loop_pos >= len(pre_face):
            continue
        src_idx = pre_face[loop_pos]

        # Defensive: a >= pre_split index here means the snapshot was captured
        # post-split (wrong time). Skip rather than propagate from a clone.
        if src_idx >= pre_split_vert_count:
            continue

        src_groups = vert_groups_snapshot.get(src_idx)

        # Read the clone's memberships ONCE (.groups iteration is expensive).
        clone_v = obj.data.vertices[clone_idx]
        current = {e.group: e.weight for e in clone_v.groups if e.weight > 0.0}

        if not src_groups:
            # Source had no nonzero weights: clear any partial weights split_edges
            # left so the export sees a clean unweighted vert (which the validator
            # can flag) rather than a half-weighted one that spike-deforms in-game.
            if current:
                for vg in vg_by_index:
                    try:
                        vg.remove([clone_idx])
                    except Exception:
                        pass
                cleared += 1
            continue

        canonical = {gi: w for gi, w in src_groups if 0 <= gi < vg_count}
        if not canonical:
            continue

        # Skip rewrite when the clone already matches canonical within quantization
        # noise (the common case where split_edges propagated the deform layer).
        if (set(canonical) == set(current)
                and all(abs(canonical[g] - current[g]) <= weight_eps
                        for g in canonical)):
            skipped_match += 1
            continue

        # Clear and rewrite — cheaper than per-membership diffing (vg.remove() is
        # one CustomData op per group).
        for vg in vg_by_index:
            try:
                vg.remove([clone_idx])
            except Exception:
                pass
        for gi, w in canonical.items():
            vg_by_index[gi].add([clone_idx], w, 'REPLACE')
        propagated += 1

    if propagated or cleared:
        dlog(
            f"[Mesh Format] Vertex group propagation on '{obj.name}': "
            f"{propagated} clone(s) rewritten via face-topology, "
            f"{cleared} unweighted clone(s) cleaned, "
            f"{skipped_match} already-correct clone(s) preserved "
            f"({pre_split_vert_count} -> {post_split_vert_count} verts)."
        )


def _propagate_groups_positional_fallback(obj, pre_split_vert_count):
    """Legacy positional-key propagation. Safety net ONLY for callers that don't
    pass a snapshot — the face-topology path is strictly more correct; new code
    should always provide the snapshot.
    """
    import numpy as np

    post_split_vert_count = len(obj.data.vertices)
    if post_split_vert_count == pre_split_vert_count:
        return

    all_coords = np.empty(post_split_vert_count * 3, dtype=np.float32)
    obj.data.vertices.foreach_get('co', all_coords)
    all_coords = all_coords.reshape((post_split_vert_count, 3))

    def to_key(xyz):
        return (round(float(xyz[0]), 5),
                round(float(xyz[1]), 5),
                round(float(xyz[2]), 5))

    pos_to_source = {}
    for i in range(pre_split_vert_count):
        k = to_key(all_coords[i])
        if k not in pos_to_source:
            pos_to_source[k] = i

    source_memberships = {}
    for src_idx in set(pos_to_source.values()):
        v = obj.data.vertices[src_idx]
        mems = [(e.group, e.weight) for e in v.groups if e.weight > 0.0]
        if mems:
            source_memberships[src_idx] = mems

    vg_count = len(obj.vertex_groups)
    propagated = 0
    for i in range(pre_split_vert_count, post_split_vert_count):
        v = obj.data.vertices[i]
        if any(e.weight > 0.0 for e in v.groups):
            continue
        k = to_key(all_coords[i])
        src_idx = pos_to_source.get(k)
        if src_idx is None:
            continue
        mems = source_memberships.get(src_idx)
        if not mems:
            continue
        for group_idx, weight in mems:
            if 0 <= group_idx < vg_count:
                obj.vertex_groups[group_idx].add([i], weight, 'REPLACE')
        propagated += 1

    if propagated:
        dlog(f"[Mesh Format] Propagated vertex groups to {propagated} "
             f"split-clone verts on '{obj.name}' (positional fallback, "
             f"{pre_split_vert_count} -> {post_split_vert_count} verts).")


def format_game_uv_seams(obj):
    # Skip vertex-only meshes (no faces/UVs to process)
    if len(obj.data.polygons) == 0:
        dlog(f"[Mesh Format] Skipping vertex-only mesh '{obj.name}' - no faces")
        return
    
    # Split all mesh UV seam
    if ( bpy.app.version < (4,1,0) ):
        obj.data.calc_normals_split()

    mesh = obj.data

    # Capture pre-split vertex count for remap propagation
    pre_split_vert_count = len(mesh.vertices)

    edit_mesh = getEditMesh(obj)
    vertex_cache = None

    # Vertex cache to remap normals skewed by triangulation / UV-seam splits.
    # On 4.0+ the cache is computed-but-never-applied (the else-branch just drops
    # to OBJECT mode), so building it is dead work — skipped to save a per-vertex
    # dict-build across every arena mesh. Pre-4.0 still needs it because bmesh ops
    # don't preserve corner normals reliably there.
    needs_triangulate = not isTriangulated(obj)
    build_cache = needs_triangulate and bpy.app.version < (4, 0, 0)

    if needs_triangulate:
        dlog("[Mesh Format] Mesh is not trianglulated")
        if build_cache:
            vertex_cache = cache_vertex_normals(obj, edit_mesh)
        triangulate_mesh(edit_mesh)

    # Multi-facegroup gate: on multi-material meshes (vests/jackets — the through-
    # body clipping case) the DLL's facegroup dispatch separates UV seams natively.
    # Pre-splitting fights it (boundary clones bind to the wrong side and detach),
    # so skip the seam split; triangulation already ran (all the DLL needs). No
    # propagation needed — no clones created.
    if has_multiple_facegroups(obj):
        dlog(
            f"[Mesh Format] Skipping UV-seam split on '{obj.name}' — "
            f"multi-facegroup mesh; DLL handles seam separation via "
            f"per-material dispatch."
        )
        bmesh.update_edit_mesh(mesh)
        setBlenderMode('OBJECT')
        return

    # Snapshot pre-split state here — after triangulation finalizes face count/order,
    # before check_uv_seams fires split_edges. propagate_vertex_groups_after_split
    # uses it to map clones to sources via shared face-loop slots, the only method
    # robust to coincident verts with different weights (head/body neck-seam).
    pre_split_snapshot = snapshot_pre_split_topology(obj, edit_mesh)

    vertex_cache = check_uv_seams(obj, edit_mesh, vertex_cache)
    bmesh.update_edit_mesh(mesh)

    if (vertex_cache):
        # 4+ split_edges/triangulate preserve custom CORNER normals natively (each
        # loop keeps its pre-split normal, including both sides of a UV seam). The
        # pre-4.0 fallback re-applies per-VERTEX averaged normals, which flattens
        # per-corner differences and distorts sharp-shaded meshes (chainmail, braids,
        # tiled patterns) — the distortion only "self-fixes" on a second round-trip
        # because the flattened normals become self-consistent (diagnostic, not a fix).
        if bpy.app.version < (4, 0, 0):
            dlog("[Mesh Format] Retargeting normals (pre-4.0 fallback)...")
            setBlenderMode('OBJECT')
            split_normals = get_transferred_split_normals(mesh, vertex_cache)
            mesh.use_auto_smooth = True
            mesh.normals_split_custom_set_from_vertices(split_normals)
        else:
            # 4+: corner normals already preserved; just commit to object mode.
            setBlenderMode('OBJECT')

    # Propagate vertex remap for any edge-split-created vertices.
    setBlenderMode('OBJECT')
    propagate_vertex_remap_after_split(obj, pre_split_vert_count)
    # And propagate vertex group memberships — without this, split-clone verts whose
    # deform data didn't survive the Python-side read export all-zero and collapse
    # to origin (body meshes worst-hit, most clones from UV islands).
    propagate_vertex_groups_after_split(
        obj, pre_split_vert_count, snapshot=pre_split_snapshot)
    return


def format_game_objects(objs):
    # Split edit/object context operations to avoid redundant context switching.
    for obj in objs:
        format_game_uv_seams(obj)

    # Recompute split normals on pre-4.1 (4.1+ keeps them current). The old edge-
    # split modifier path was removed — gated off and redundant with the seam-split
    # in format_game_uv_seams (which doesn't leave a modifier to clean up).
    setBlenderMode('OBJECT')
    if bpy.app.version < (4, 1, 0):
        for obj in objs:
            obj.data.calc_normals_split()
    return

def getBoneIndex(name, skin):
    """Resolve a vertex group name to a bone index on the skin's armature, or -1.

    Match order: (1) exact via cached name->index dict; (2) case-insensitive via
    the lowercase dict — a silent auto-fix for vertex-group/bone case mismatches
    (imported assets, renamed bones), without which the weights drop on export and
    the mesh spikes to origin with no explanation. Both dicts come from
    CVertexSkin.__set_bones; the getattr defaults keep legacy callers safe.
    """
    bi = getattr(skin, 'bones_index', None)
    if bi:
        i = bi.get(name)
        if i is not None:
            return i
        return skin.bones_index_lower.get(name.lower(), -1)
    # Legacy fallback — linear scan, case-sensitive only.
    try:
        return skin.bones.index(name)
    except ValueError:
        return -1

def getVertexWeights(vertex, skin, groups, unresolved_groups):
    """Pack the top-N influences BY WEIGHT into the skin arrays, recording per-
    vertex resolution stats for diagnostics.

    Non-destructive top-N by weight:
      1. Collect every resolvable nonzero influence.
      2. If > N, stable-sort descending and keep first N (ties preserve order).
      3. Renormalize the survivors to sum 1: the DLL writes uint8 unorm (weight*255),
         so a truncated vert summing 0.92 deforms deflated; renormalized quantizes
         cleanly.
      4. Pack into blendweights/blendindices (slot order is irrelevant — the shader
         sums slot_i*weight_i).

    GtPt anchor groups (VC_GTPT__*) are filtered before bone resolution: they pin
    each GtPt record to its source vertex (for the export resolver after a caruncle
    merge); letting them through would flood unresolved_groups and risk stealing
    weight. GTPT_VG_PREFIX is the single source of truth (skinmodel_gp.py).

    Background: Blender iterates vertex.groups in add-order, not weight-order;
    heat-seek/surface-deform rigs produce 15-20 tiny influences, so real 0.8 bones
    often sat past slot 8 and got dropped by a first-N pack. An older version ran
    vertex_group_limit_total (correct top-N but destructively mutated the scene every
    export); selecting here on the in-memory copy keeps the scene untouched.

    Stats→UI: each call bumps one counter (verts_correctly_weighted /
    verts_weighted_to_missing_bones / unweighted_verts) that getVertexSkin reads to
    build messages; unresolved_groups (caller-owned) collects names of missing bones
    so the warning can name examples ('H_Thigh_L') rather than just a count.
    """
    from ..SkinModel.skinmodel_gp import GTPT_VG_PREFIX

    table_index = (vertex.index * skin.weights_per_vertex)

    # Collect resolvable nonzero influences; track whether ANY nonzero weight was
    # seen so we can tell "unrigged" from "rigged to wrong bones".
    influences = []
    had_any_weight = False
    for elem in vertex.groups:
        if elem.weight <= 0.0:
            continue
        # Defensive: heavily edited/joined meshes can carry orphaned group indices.
        if elem.group < 0 or elem.group >= len(groups):
            continue
        group_name = groups[elem.group]
        # Skip GtPt anchor groups — metadata, not skinning (see docstring).
        if group_name.startswith(GTPT_VG_PREFIX):
            continue
        had_any_weight = True
        bone_index = getBoneIndex(group_name, skin)
        if bone_index == -1:
            unresolved_groups.add(group_name)
            continue
        influences.append((elem.weight, bone_index))

    if not influences:
        if had_any_weight:
            skin.verts_weighted_to_missing_bones += 1
        else:
            skin.unweighted_verts += 1
        return

    skin.verts_correctly_weighted += 1

    # Top-N by weight (only when we actually have more than fits).
    truncated = False
    if len(influences) > skin.weights_per_vertex:
        influences.sort(key=lambda p: p[0], reverse=True)
        influences = influences[:skin.weights_per_vertex]
        truncated = True

    # Renormalize ONLY when truncation dropped weight, or the sum is far from 1.0.
    # Round-trip safety: vanilla weights are uint8 unorm, so imported floats sum to
    # e.g. 0.99608 or 1.00392 purely from quantization. A blind renormalize shifts
    # every weight ~0.4% to force exact 1.0, visibly moving the cloth-sim bind pose
    # on physics meshes — the vanilla weights ARE right (the game handles the noise
    # sum internally), so first export must not touch them.
    # Threshold 2/255 (~0.008) = one full unorm step either side: inside is noise,
    # outside is a real imbalance to fix (e.g. heat-seek weights that don't sum clean).
    total = sum(w for w, _ in influences)
    if total > 0.0:
        needs_renorm = truncated or abs(total - 1.0) > (2.0 / 255.0)
        if needs_renorm:
            inv = 1.0 / total
            for i, (w, b) in enumerate(influences):
                influences[i] = (w * inv, b)

    for slot, (weight, bone_index) in enumerate(influences):
        skin.blendweights[table_index + slot] = weight
        skin.blendindices[table_index + slot] = bone_index
    return


def _build_weight_validation_warnings(skin, obj, unresolved_groups):
    """Turn per-vertex stats into plain-language UI messages.

    Returns (severity, message) tuples; saveSkinModel surfaces each via
    operator.report as a UI banner. Language is modder-facing (names the mesh,
    the in-game symptom, the Blender fix). Silent auto-fixes (top-N, renormalize,
    case-insensitive matching) produce no message — nothing the user can act on.
    """
    warnings = []
    total = skin.total_verts
    if total == 0:
        return warnings

    good = skin.verts_correctly_weighted
    missing_bone = skin.verts_weighted_to_missing_bones
    unweighted = skin.unweighted_verts

    # CASE 1: every weight points to a missing bone ("wrong armature bound" — mesh
    # never rebound to the wrestler's). In-game: whole mesh collapses to origin.
    if good == 0 and missing_bone > 0:
        sample = ", ".join(f"'{g}'" for g in sorted(unresolved_groups)[:3])
        more = " and others" if len(unresolved_groups) > 3 else ""
        warnings.append((
            'ERROR',
            f"'{obj.name}': All vertex weights point to bones that don't "
            f"exist on this mesh's armature (missing bones include {sample}"
            f"{more}). The whole mesh will collapse to the origin in-game. "
            f"Fix: in the Properties panel, go to Modifiers and make sure "
            f"the Armature modifier's Object is set to the wrestler's "
            f"armature, then go to Object Properties -> Relations and set "
            f"Parent to the same armature. If that doesn't fix it, re-run "
            f"Transfer Weights from the wrestler's body mesh."
        ))

    # CASE 2: armature modifier but no weights at all (attire imported unrigged, or
    # Transfer Weights wrote nothing). In-game: mesh freezes at origin.
    elif good == 0 and unweighted == total:
        warnings.append((
            'ERROR',
            f"'{obj.name}' is bound to an armature but has no weights on "
            f"any vertex. The mesh will freeze at the origin in-game. "
            f"Fix: select the wrestler's body mesh, then shift-select "
            f"'{obj.name}', then use Object -> Data Transfer -> Transfer "
            f"Vertex Group Data -> Vertex Group(s). Make sure 'Create "
            f"Data' is enabled in the operator panel (bottom-left F9 "
            f"popover) so missing groups get created on the target."
        ))

    # CASE 3: partial breakage — some verts deform to origin. 1% threshold skips
    # noisy single-vert warnings while catching real breaks (a broken arm = thousands).
    elif missing_bone > 0 or unweighted > 0:
        broken = missing_bone + unweighted
        pct = (broken * 100) // total
        if pct >= 1 or broken >= 50:
            if missing_bone > 0 and unweighted > 0:
                detail = (f"{missing_bone} vertices are weighted to bones "
                          f"missing from the armature and {unweighted} "
                          f"vertices have no weights at all")
            elif missing_bone > 0:
                sample = ", ".join(f"'{g}'" for g in sorted(unresolved_groups)[:3])
                more = " and others" if len(unresolved_groups) > 3 else ""
                detail = (f"{missing_bone} vertices are weighted to bones "
                          f"missing from the armature (missing: {sample}"
                          f"{more})")
            else:
                detail = f"{unweighted} vertices have no weights assigned"
            warnings.append((
                'WARNING',
                f"'{obj.name}': {broken} of {total} vertices ({pct}%) will "
                f"deform to the origin in-game. {detail}. Fix: select the "
                f"wrestler's body mesh, shift-select '{obj.name}', and "
                f"run Object -> Data Transfer -> Transfer Vertex Group "
                f"Data -> Vertex Group(s) with 'Create Data' enabled."
            ))

    return warnings


def getVertexSkin(obj, weight_limit):
    skin = CVertexSkin()
    skin.weights_per_vertex = weight_limit
    skin.prepopulate_skin(obj)
    skin.total_verts = len(obj.data.vertices)

    obj_groups = [group.name for group in obj.vertex_groups]
    unresolved_groups = set()

    # Fast path — pre-resolve group_idx -> bone_idx once, then top-N pack with
    # inlined per-element work (avoids per-vertex getBoneIndex + GtPt startswith).
    # Same counters/renormalization/reporting — see perf.fast_get_vertex_weights.
    fast_done = False
    if perf._enabled():
        try:
            perf.fast_get_vertex_weights(obj, skin, obj_groups, unresolved_groups)
            fast_done = True
        except Exception as e:
            dlog(f"[MDL Addon] getVertexSkin fast path skipped ({e}); using slow path.")

    if not fast_done:
        for vertex in obj.data.vertices:
            getVertexWeights(vertex, skin, obj_groups, unresolved_groups)

    # Build UI warnings; saveSkinModel surfaces them via operator.report as banners.
    skin.validation_warnings = _build_weight_validation_warnings(
        skin, obj, unresolved_groups)
    return skin

def getMeshSkin(obj):
    if not has_armature_modifier(obj):
        return None

    # Game format = WEIGHT_8 (8 influences/vertex) — fixed on-disk layout, passed
    # literally. getVertexSkin packs top-N by weight + renormalizes non-destructively,
    # replacing the old destructive vertex_group_limit_total operator.
    return getVertexSkin(obj, 8)

def unpack_matrices(matrix):
    matrices = []
    for row in matrix:
        for value in row:
            matrices.append(value)
    return matrices
        
def getRigBone(bone):
    joint = vCRigJoint()
    joint.name   = bone.name
    joint.parent = bone.parent.name if bone.parent else None
    joint.matrix = bone.matrix_local
    
    if (bone.parent):
        joint.matrix = bone.parent.matrix_local.inverted() @ joint.matrix

    # matrix must be unpacked for cmesh library usage
    joint.matrix = unpack_matrices(joint.matrix)
    return joint

def getBlendShape(obj, shape_key):
    blendshape = vCMeshShape()
    blendshape.name  = shape_key.name

    # Fast path — foreach_get + numpy matmul (slow path's per-vert matrix_world @
    # vert.co is brutal on facial rigs: 30+ shapes × 30k verts).
    if perf._enabled():
        try:
            blendshape.verts = perf.fast_get_blendshape_verts(obj, shape_key)
            return blendshape
        except Exception as e:
            dlog(f"[MDL Addon] getBlendShape fast path skipped ({e}); using slow path.")

    blendshape.verts = [axis for vert in shape_key.data for axis in obj.matrix_world @ vert.co]
    return blendshape

def getShapeKeys(obj):
    if not obj.data.shape_keys: 
        return None
    
    mesh = obj.data
    num_shapes = len( mesh.shape_keys.key_blocks )
    shapes = [None] * num_shapes

    for index, key in enumerate(mesh.shape_keys.key_blocks):
        if key.name != "Basis":
            shapes[index] = getBlendShape(obj, key)
    
    return shapes


def getGameSceneFlag(obj):
    return obj.mdl_properties.appearance_flag

def getGameMotionFlag(obj):
    return obj.mdl_properties.sub_flag


# ── DLL preprocessing path — Raw readers for Preserve Custom Normals ──
# These read UNMODIFIED meshes (pre-triangulation), so foreach_get is safe.

def getRawMeshPositions(obj):
    """Read vertex positions in world space."""
    import numpy as np
    mesh = obj.data
    n = len(mesh.vertices)
    coords = np.empty(n * 3, dtype=np.float32)
    mesh.vertices.foreach_get('co', coords)
    
    mat = np.array(obj.matrix_world, dtype=np.float32)[:3, :3]
    loc = np.array(obj.matrix_world.translation, dtype=np.float32)
    verts = coords.reshape((n, 3))
    transformed = verts @ mat.T + loc
    return transformed.flatten().tolist()


def getRawMeshPolygons(obj):
    """Read polygon face sizes + flat index list. Supports tris/quads/ngons."""
    import numpy as np
    mesh = obj.data
    num_polys = len(mesh.polygons)
    num_loops = len(mesh.loops)

    face_sizes = np.empty(num_polys, dtype=np.int32)
    mesh.polygons.foreach_get('loop_total', face_sizes)

    loop_verts = np.empty(num_loops, dtype=np.int32)
    mesh.loops.foreach_get('vertex_index', loop_verts)

    # A stale loop index from a mesh edit op would index out of the vertex
    # buffer inside the DLL preprocess (same guard family as getRawLoopTangents
    # / getVertexNorms). Drop the inconsistent read here and let the caller
    # fall back rather than hand the DLL an OOB index list.
    num_verts = len(mesh.vertices)
    if num_loops and (int(loop_verts.max()) >= num_verts or int(loop_verts.min()) < 0):
        print(f"[MDL Addon] getRawMeshPolygons: stale loop table on '{obj.name}' "
              f"(vertex index {int(loop_verts.max())} of {num_verts}); clamping.")
        loop_verts = np.clip(loop_verts, 0, max(num_verts - 1, 0))
    if int(face_sizes.sum()) != num_loops:
        print(f"[MDL Addon] getRawMeshPolygons: face sizes sum "
              f"{int(face_sizes.sum())} != loop count {num_loops} on '{obj.name}'.")

    return face_sizes.tolist(), loop_verts.tolist()


def getRawLoopUVs(obj):
    """Read per-loop UVs from all UV layers."""
    import numpy as np
    mesh = obj.data
    num_loops = len(mesh.loops)
    uv_sets = []
    
    for layer in mesh.uv_layers:
        uvs = np.empty(num_loops * 2, dtype=np.float32)
        layer.data.foreach_get('uv', uvs)
        uv_sets.append(uvs.tolist())
    
    return uv_sets, num_loops


def _has_sim_twin(obj):
    """True if obj is an M_<X> render mesh that has a matching S_<X> sim mesh in the
    scene (e.g. M_Jacket <-> S_Jacket). The S_ sim mesh drives the M_ render mesh by
    render-vertex INDEX, so the M_ mesh's UV-seam split MUST reproduce vanilla's exact
    render-vertex count/order or the binding misaligns and the mesh shatters in-game.
    These are the ONLY meshes the normal-jitter collapse below touches; skinned meshes
    and the user's hand-edited (weighted-normal) meshes have no S_ twin and pass through
    with their exact per-loop normals untouched."""
    import bpy
    try:
        nm = obj.data.name.split('.')[0]
    except Exception:
        return False
    if not nm.startswith('M_') or len(nm) <= 2:
        return False
    # Case-fold the suffix so a case-mismatched sim twin is still recognized
    # (e.g. M_Hair <-> S_hair, seen on 1229_Giulia). Additive: the exact-match
    # jacket pairs (M_Jacket <-> S_Jacket) still match, so the proven fix is
    # unchanged; this only ADDS the case-insensitive twins the old strict compare
    # missed. (Longest-prefix variant matching — M_Jacket_withBelt -> S_Jacket —
    # is intentionally NOT done here: that binding is unconfirmed in-game, and the
    # unedited-mesh case is already covered by the non-sim clnor collapse above.)
    twin = ('S_' + nm[2:]).lower()
    for o in bpy.data.objects:
        if o.type == 'MESH' and o.data is not None and o.data.name.split('.')[0].lower() == twin:
            return True
    return False


def _is_unedited_mesh(obj):
    """True if obj's geometry/topology is byte-unchanged since import — the SAME
    VC_TBN_HASH gate the shipped PackedTBN / tangent byte-preserve uses. Any
    geometry edit trips it. That byte-preserve already runs behind this gate
    without disturbing the user's Weighted-Normal workflow, so collapsing clnor
    jitter behind the same gate inherits the same safety."""
    try:
        stored = obj.get("VC_TBN_HASH", None)
        if not stored:
            return False
        return computeTbnHash(obj.data) == stored
    except Exception:
        return False


def _collapse_clnor_jitter(normals_flat, mesh, num_loops, cos_thresh=0.99985, force=False):
    """Kill sub-quantum Blender clnor jitter that over-splits UNEDITED non-sim
    meshes (M_Teeth/M_Tights/M_Cap +1/+2 phantom verts) and thereby defeats the
    PackedTBN byte-preserve. For each vertex, if ALL of its loop normals sit within
    acos(cos_thresh) (~1deg) of their mean, set them to that mean; a vertex whose
    loops span MORE than that (a genuine hard edge / weighted-normal corner) is
    LEFT UNTOUCHED — so a real edge can never be smoothed. cos_thresh=0.99985 (~1deg)
    sits far above the clnor jitter (<0.03deg at the 1/2048 quantum) and far below
    any real hard edge. For an unedited vanilla mesh every same-vertex loop spread
    IS jitter (vanilla stores hard edges as SEPARATE render verts, i.e. separate
    Blender vertices), so this restores the exact vanilla render-vertex count.

    force=True collapses EVERY vertex (not just sub-cos_thresh ones) to its loop
    mean. On UNEDITED geometry a within-vertex loop-normal spread can ONLY be a
    fan-partition solver artifact: a native distinct-index zero-area "stitch" tri
    (coincident-position render verts the index-only degenerate filter lets through)
    strands one loop on its own smoothing fan ~39deg off — e.g. 119_Andre M_Body
    vert 3319, the lone +1 over-split in the 535-char corpus. The ~1deg cos_thresh
    misses that 39deg artifact, so the unedited path uses force=True to make the
    vanilla render-count exact. Safe because genuine hard edges / weighted-normal
    corners live on SEPARATE Blender vertices (import is 1:1 with the file, never
    welds), so no real edge can be on a single vertex to be smoothed.
    Returns the (possibly modified) flat float32 normals array."""
    import numpy as np
    n = normals_flat.reshape(num_loops, 3).astype(np.float64)
    ln = np.linalg.norm(n, axis=1, keepdims=True)
    ln[ln == 0] = 1.0
    n = n / ln
    vi = np.empty(num_loops, dtype=np.int32)
    mesh.loops.foreach_get('vertex_index', vi)
    nv = len(mesh.vertices)
    acc = np.zeros((nv, 3), dtype=np.float64)
    np.add.at(acc, vi, n)
    mn = np.linalg.norm(acc, axis=1, keepdims=True)
    mn[mn == 0] = 1.0
    vmean = acc / mn                                    # per-vertex mean (unit)
    dots = np.einsum('ij,ij->i', n, vmean[vi])          # cos(loop, its vertex mean)
    minc = np.full(nv, 2.0, dtype=np.float64)
    np.minimum.at(minc, vi, dots)                       # worst loop deviation / vertex
    if force:
        collapse_v = np.ones(nv, dtype=bool)            # collapse EVERY vertex (fan-partition artifact)
    else:
        collapse_v = minc >= cos_thresh                 # all loops tight => pure jitter
    loop_mask = collapse_v[vi]
    out = n.copy()
    out[loop_mask] = vmean[vi][loop_mask]
    return np.ascontiguousarray(out.reshape(-1), dtype=np.float32)


def getRawLoopNormals(obj):
    """Read per-loop (split) normals.

    Version compat: pre-4.1 calc_normals_split() populates loops[i].normal; 4.1+
    REMOVED it and corner_normals may be empty until evaluated. loops[i].normal is
    reliable on 4.1+ and pre-4.1 (after the split calc), so it's the primary path;
    drop to vertex normals only if loop normal data is genuinely absent.
    """
    import numpy as np
    mesh = obj.data
    num_loops = len(mesh.loops)
    
    if num_loops == 0:
        return None, 0
    
    normals = np.empty(num_loops * 3, dtype=np.float32)

    # Pre-4.1 needs an explicit split-normal calc; 4.1+ removed the API and keeps
    # loops[i].normal up to date automatically.
    if hasattr(mesh, 'calc_normals_split'):
        try:
            mesh.calc_normals_split()
        except Exception:
            pass

    # Prefer corner_normals when populated (4.1+ canonical path).
    read_ok = False
    if hasattr(mesh, 'corner_normals') and len(mesh.corner_normals) > 0:
        try:
            mesh.corner_normals.foreach_get('vector', normals)
            read_ok = True
        except Exception:
            read_ok = False

    # Fallback: loops[i].normal. Works 2.93 through 5.1.
    if not read_ok:
        try:
            mesh.loops.foreach_get('normal', normals)
            # Probe a sample, not just loop 0: a valid loop 0 with zero-length
            # later loops (unevaluated 4.1+ mesh after bmesh edits) would pass a
            # single-loop check then export garbage. If a non-negligible fraction
            # is zero-length, drop to the vertex-normal scatter (losing some split
            # info beats writing half-garbage and crashing the game).
            if num_loops > 0:
                # Probe up to 256 loops for speed on huge arena meshes.
                sample = min(num_loops, 256)
                length_sq = (normals[0:sample*3:3] ** 2 +
                             normals[1:sample*3:3] ** 2 +
                             normals[2:sample*3:3] ** 2)
                bad_ratio = float(np.count_nonzero(length_sq < 1e-8)) / float(sample)
                if bad_ratio > 0.01:  # >1% zero-length means the read failed
                    read_ok = False
                else:
                    read_ok = True
            else:
                read_ok = True
        except Exception:
            read_ok = False

    if not read_ok:
        # Last resort: scatter vertex normals over loops. Loses split-normal
        # information (hard edges become smooth) but is the only option on
        # meshes that have neither corner_normals nor evaluated loop normals.
        vert_normals = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
        mesh.vertices.foreach_get('normal', vert_normals)
        vert_normals = vert_normals.reshape((-1, 3))
        loop_vert_indices = np.empty(num_loops, dtype=np.int32)
        mesh.loops.foreach_get('vertex_index', loop_vert_indices)
        normals = vert_normals[loop_vert_indices].flatten()
    
    # ── SIM-TWIN NORMAL-JITTER COLLAPSE (the jacket-explosion fix) ──
    # An M_<X> mesh driven by an S_<X> sim mesh must export its render-vertex layout
    # EXACTLY as vanilla. Blender's int16 clnor storage re-projects a vertex's single
    # normal into divergent corner-normals; when two corners straddle the DLL's 1/2048
    # quantum the DLL's splitUvSeams forges a phantom extra vertex -> count != vanilla ->
    # reorderSplitToVanilla bails -> the buffer ships in triangle order -> the sim binding
    # (by render index) lands on the wrong vertex -> the mesh shatters in-game.
    # Each render vertex is 1:1 with the file (import never welds), so all of a vertex's
    # loops share one UV; averaging their normals to a single per-vertex value removes the
    # sub-quantum jitter so the split reproduces the vanilla count and the binding holds.
    # GATED to sim-twin meshes ONLY: skinned meshes and hand-edited (weighted-normal)
    # meshes have no S_ twin and skip this entirely -> their exact normals are preserved.
    if _has_sim_twin(obj):
        try:
            _nrm = normals.reshape(num_loops, 3).astype(np.float64)
            _vi = np.empty(num_loops, dtype=np.int32)
            mesh.loops.foreach_get('vertex_index', _vi)
            _nv = len(mesh.vertices)
            _acc = np.zeros((_nv, 3), dtype=np.float64)
            np.add.at(_acc, _vi, _nrm)
            _cnt = np.bincount(_vi, minlength=_nv).astype(np.float64).reshape(_nv, 1)
            _cnt[_cnt == 0] = 1.0
            _vn = _acc / _cnt
            _ln = np.linalg.norm(_vn, axis=1, keepdims=True)
            _ln[_ln == 0] = 1.0
            _vn = _vn / _ln
            normals = np.ascontiguousarray(_vn[_vi].reshape(-1), dtype=np.float32)
        except Exception:
            pass
    elif _is_unedited_mesh(obj):
        # ── NON-SIM CLNOR-JITTER COLLAPSE (P6, UNEDITED meshes only) ──
        # Same clnor jitter as the sim-twin case, but on meshes with NO S_ twin
        # (M_Teeth/M_Tights/M_Cap/M_Head etc.). The over-split is in-game harmless
        # there (no sim cage binds by index) BUT it bumps the vertex count +1/+2,
        # which DEFEATS the PackedTBN byte-preserve -> normals get re-encoded
        # instead of round-tripping byte-for-byte. Gated to UNEDITED geometry (same
        # VC_TBN_HASH gate the byte-preserve uses). force=True collapses EVERY
        # vertex (not just sub-1deg jitter): on unedited geometry a within-vertex
        # normal spread can ONLY be a fan-partition solver artifact from a native
        # zero-area stitch tri (the +1 over-split on 119_Andre M_Body vert 3319 that
        # the ~1deg threshold missed) — real hard edges live on separate vertices.
        try:
            # force=True (collapse the fan-partition OVER-SPLIT artifact) is a
            # guaranteed byte no-op ONLY where the PackedTBN byte-preserve re-emits
            # the captured vanilla TBN — i.e. VC_PACKEDTBN present (2K26-class): the
            # collapsed value drives only the vertex-count/UV-split reproduction, and
            # the output TBN bytes are the captured ones. On a tangent-capturing game
            # WITHOUT a PackedTBN lane (e.g. 2K24: VC_TBN_HASH is set so we reach this
            # branch, but there is no byte-preserve) a force collapse would ENCODE the
            # changed normal, so fall back to the tight sub-1deg jitter collapse there
            # (prior behavior) — no regression off the 2K26 PackedTBN path.
            _force = mesh.attributes.get("VC_PACKEDTBN") is not None
            normals = _collapse_clnor_jitter(normals, mesh, num_loops, force=_force)
        except Exception:
            pass

    mat = np.array(obj.matrix_world, dtype=np.float32)[:3, :3]
    norms = normals.reshape((num_loops, 3))
    transformed = norms @ mat.T

    # Replace non-finite with +Z before normalization: NaN/inf propagates through
    # the DLL's tangent reconstruction → game crash at skinning (same guard as
    # getVertexNorms/getMeshNormals).
    bad_mask = ~np.isfinite(transformed).all(axis=1)
    if np.any(bad_mask):
        transformed[bad_mask] = [0.0, 0.0, 1.0]

    lengths = np.linalg.norm(transformed, axis=1, keepdims=True)
    # Same for zero-length: replace the row entirely.
    zero_mask = (lengths < 1e-6).flatten()
    if np.any(zero_mask):
        transformed[zero_mask] = [0.0, 0.0, 1.0]
        lengths[zero_mask] = 1.0

    transformed /= lengths

    return transformed.flatten().tolist(), num_loops


def getRawLoopTangents(obj):
    """Per-loop carried tangents for the DLL-PREPROCESS export path
    (makeSkinMeshRaw). Returns (flat_stride4_list, num_loops) or (None, n).

    Blender has no per-corner tangent storage, but doesn't need one: each MCD vert
    carries one tangent and UV seams are already split into distinct verts at
    import, so gathering each loop's tangent from its vertex is exact (proof TEST B).
    _readCarriedTangents already applied the world transform + handedness + unedited
    hash gate; we only scatter per-vertex → per-loop. The DLL's splitUvSeams() then
    moves these into the per-vertex tangent buffer parallel to loop normals.
    """
    import numpy as np
    mesh = obj.data
    num_loops = len(mesh.loops)
    if num_loops == 0:
        return None, 0

    carried = _readCarriedTangents(obj)     # (N,4) world frame, or None
    if carried is None:
        return None, num_loops

    loop_vi = np.empty(num_loops, dtype=np.int32)
    mesh.loops.foreach_get('vertex_index', loop_vi)
    # Defensive: a stale loop index would index out of the carried array.
    if num_loops and (loop_vi.min() < 0 or loop_vi.max() >= carried.shape[0]):
        dwarn(f"[MDL Addon] '{obj.name}': loop vertex index out of range — "
              f"regenerating tangents.")
        return None, num_loops

    loop_t = carried[loop_vi]               # (num_loops, 4)
    return loop_t.reshape(-1).astype(np.float32).tolist(), num_loops


def _readCarriedPackedTBN(obj):
    """Read the per-vertex VC_PACKEDTBN words captured at import, gated on the mesh
    being UNEDITED (positions+topology). Returns (N,) uint32 or None ("regenerate").

    Parallel to _readCarriedTangents but with NO world transform: the word is an
    OPAQUE pre-encoded value in vanilla game space, ridden through byte-for-byte.
    Gate (all required): VC_PACKEDTBN (INT, POINT) present, length == vertex count;
    VC_TBN_HASH present AND == freshly recomputed geometry+topology hash. The INT
    attribute holds the uint32 reinterpreted as int32 at import; reversed here.

    Hash is positions+topology ONLY: a pure NORMAL/TANGENT edit must not trip it —
    the DLL's per-vertex serializer gate catches those, re-encoding only touched
    verts, so tripping the whole mesh would needlessly discard byte-exactness.
    """
    import numpy as np

    mesh = obj.data
    num_verts = len(mesh.vertices)
    if num_verts == 0:
        return None
    if not hasattr(mesh, "attributes"):
        # Reading an existing attribute is realloc-free (safe on 2.93+); only a missing
        # attributes API returns None here.
        return None

    a_w = mesh.attributes.get("VC_PACKEDTBN")
    if a_w is None or getattr(a_w, 'domain', None) != 'POINT':
        return None
    if len(a_w.data) != num_verts:
        return None

    # Edit gate: stored fingerprint must match the current geometry.
    stored = obj.get("VC_TBN_HASH", None)
    if not stored:
        return None
    if computeTbnHash(mesh) != stored:
        dlog(f"[MDL Addon] '{obj.name}': geometry changed since import — "
             f"regenerating PackedTBN.")
        return None

    i32 = np.empty(num_verts, dtype=np.int32)
    a_w.data.foreach_get('value', i32)
    return i32.view(np.uint32).copy()


def getRawLoopPackedTBN(obj):
    """Per-loop carried PackedTBN words for the DLL-PREPROCESS export path
    (makeSkinMeshRaw). Returns (loop_words_list, num_loops) or (None, n).

    Mirrors getRawLoopTangents for the opaque octahedral TBN word lane, but the
    word is NOT transformed — a pre-encoded 32-bit value in vanilla GAME/LOCAL
    space, ridden unchanged: setLoopPackedTBN (no axis swap) → splitUvSeams
    (per-vertex parallel to loop normals) → reorderSplitToVanilla (vanilla render
    order) → per-vertex serializer gate (decode-compares each word vs re-derived
    N/T; emits byte-for-byte only where unedited, else re-encodes).

    _readCarriedPackedTBN already applied the VC_TBN_HASH unedited gate; we only
    scatter per-vertex → per-loop. Returns a plain list (not ndarray) so the
    wrapper's `if not words:` guard stays unambiguous.
    """
    import numpy as np
    mesh = obj.data
    num_loops = len(mesh.loops)
    if num_loops == 0:
        return None, 0

    carried = _readCarriedPackedTBN(obj)    # (N,) uint32, or None
    if carried is None:
        return None, num_loops

    loop_vi = np.empty(num_loops, dtype=np.int32)
    mesh.loops.foreach_get('vertex_index', loop_vi)
    # Defensive: a stale loop index would index out of the carried array.
    if num_loops and (loop_vi.min() < 0 or loop_vi.max() >= carried.shape[0]):
        dwarn(f"[MDL Addon] '{obj.name}': loop vertex index out of range — "
              f"regenerating PackedTBN.")
        return None, num_loops

    loop_w = carried[loop_vi]               # (num_loops,) uint32
    return loop_w.astype(np.uint32).tolist(), num_loops


def format_game_uv_seams_preserve_normals(obj):
    """Triangulate + UV-split without normal retargeting.
    
    Blender 4+ preserves custom split normals through bmesh ops natively.
    Shape keys stay in sync because Blender updates them during triangulation.
    """
    if len(obj.data.polygons) == 0:
        return
    
    if bpy.app.version < (4, 1, 0):
        obj.data.calc_normals_split()

    mesh = obj.data
    pre_split_vert_count = len(mesh.vertices)
    edit_mesh = getEditMesh(obj)

    if not isTriangulated(obj):
        triangulate_mesh(edit_mesh)

    # Multi-facegroup gate — same reasoning as format_game_uv_seams: leave UV seams
    # untouched on multi-material attire so the DLL's facegroup dispatch routes
    # boundary verts. Triangulation already ran (the only prep the DLL needs).
    if has_multiple_facegroups(obj):
        dlog(
            f"[Mesh Format] Skipping UV-seam split on '{obj.name}' — "
            f"multi-facegroup mesh; DLL handles seam separation via "
            f"per-material dispatch."
        )
        bmesh.update_edit_mesh(mesh)
        setBlenderMode('OBJECT')
        return

    # Snapshot pre-split state before split_edges (in check_uv_seams) — drives the
    # face-topology resolution so multi-source-at-position cases (head/body neck-
    # seam) resolve to the right source rather than first-writer-wins.
    pre_split_snapshot = snapshot_pre_split_topology(obj, edit_mesh)

    check_uv_seams(obj, edit_mesh, None)
    bmesh.update_edit_mesh(mesh)
    setBlenderMode('OBJECT')

    # Propagate per-object data to split-clone verts (mirrors format_game_uv_seams)
    # so both export modes get consistent vertex-group + remap coverage.
    propagate_vertex_remap_after_split(obj, pre_split_vert_count)
    propagate_vertex_groups_after_split(
        obj, pre_split_vert_count, snapshot=pre_split_snapshot)
