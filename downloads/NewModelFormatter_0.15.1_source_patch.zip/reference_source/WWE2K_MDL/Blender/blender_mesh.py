import bpy
import numpy as np
from math import radians
from .Extras.materials import setMaterials
from .blender_utils import add_vertex_color_layer, computeTbnHash
from . import perf
from ..Link.log import dlog, dwarn

def setMeshSmoothing(bmesh):
    """Mark every face as smooth-shaded.

    4.1+: the 'sharp_face' bool face attribute drives shading (False = smooth).
    polygons.use_smooth=True does NOT clear it, so a stale sharp_face (e.g. from
    a prior validate()) leaves the mesh flat-shaded and fights our custom split
    normals. Delete the attribute entirely — absence == smooth.
    Pre-4.1 has no sharp_face attribute; fall back to the per-polygon property.
    """
    if bpy.app.version >= (4, 1, 0):
        attrs = bmesh.attributes
        sf = attrs.get("sharp_face")
        if sf is not None:
            # Zero then remove: some 4.1–4.3 builds raised on remove() with
            # unsynced data; overwriting with zeros first avoids that.
            try:
                n = len(bmesh.polygons)
                if n:
                    sf.data.foreach_set("value", [False] * n)
            except Exception:
                pass
            try:
                attrs.remove(sf)
            except Exception:
                pass
        return

    # Pre-4.1 legacy fallback.
    for f in bmesh.polygons:
        f.use_smooth = True
    return

def setMeshGameFlags(obj, scene_flag, motion_flag): # populate ui panel flags
    if (scene_flag == 130):
        obj.mdl_properties.ring_only = True
    elif (scene_flag == 129):
        obj.mdl_properties.entrance_only = True
    elif (scene_flag == 128):
        obj.mdl_properties.all_scenes = True
    else:
        obj.mdl_properties.other_value = scene_flag

    obj.mdl_properties.appearance_flag = scene_flag
    obj.mdl_properties.sub_flag = motion_flag
    return

def setTexCoords(bmesh, uv_maps):
    if (uv_maps == None):
        return

    # Fast path — bulk per-loop scatter via foreach_set. ~20-50x faster
    # than the per-loop write below on large meshes; identical output
    # for valid input. Falls through to the slow path on any prep
    # exception (caught BEFORE any RNA writes happen, so no partial
    # state is left behind).
    if perf._enabled():
        try:
            skipped = perf.fast_set_tex_coords(bmesh, uv_maps)
            if skipped:
                dwarn(f"[MDL Addon] '{bmesh.name}': {len(uv_maps)} UV sets exceed "
                      f"Blender's 8-layer cap; dropped {skipped} surplus channel(s).")
            return
        except Exception as e:
            dlog(f"[MDL Addon] setTexCoords fast path skipped ({e}); using slow path.")

    # Iterate and create unique channels per given map array
    skipped = 0
    for index, map in enumerate(uv_maps):
        channel_name = (bmesh.name + "_UV" + str(index))
        uv_layer = bmesh.uv_layers.new(name=channel_name)
        if uv_layer is None:
            # Blender HARD-CAPS UV layers at 8 (MAX_MTFACE); uv_layers.new()
            # returns None past the cap. A file from an early/unfinished exporter
            # can carry >8 texcoord sets — the game tolerates it but Blender
            # cannot hold the surplus. Skip it rather than crash on None.data.
            # Strict no-op for valid files (<=8 UV sets never return None).
            skipped += 1
            continue

        # Specify uv coords for each mesh vertex
        for face in bmesh.polygons:
            for vert_idx, loop_idx in zip(face.vertices, face.loop_indices):
                uv_layer.data[loop_idx].uv = map[vert_idx]
    if skipped:
        dwarn(f"[MDL Addon] '{bmesh.name}': {len(uv_maps)} UV sets exceed "
              f"Blender's 8-layer cap; dropped {skipped} surplus channel(s).")
    return

def setMeshNormals(bmesh, normals):
    # Pre-4.1 required use_auto_smooth=True AND create_normals_split() for custom
    # split normals. 4.1 REMOVED both APIs — split normals are now an implicit
    # attribute, honored automatically as long as per-poly use_smooth is set
    # (setMeshSmoothing). normals_split_custom_set_from_vertices still works on 4.1+.
    if ( bpy.app.version < (4,1,0)):
        bmesh.use_auto_smooth = True
        bmesh.create_normals_split()

    # initialize custom split normal dataset
    setMeshSmoothing(bmesh)

    # Defensive guards for the Blender 4.x import-crash path.
    # normals_split_custom_set_from_vertices on 4.0–4.3 is STRICT where 3.x/5.x
    # clamp silently (why the bug only surfaced on 4.x): length mismatch asserts
    # hard, zero-length normals trip an internal assertion, non-finite always
    # crashes. We scrub offending entries to +Z rather than abort the whole mesh.
    if normals is None or len(normals) == 0:
        return bmesh.update()

    num_verts = len(bmesh.vertices)
    if len(normals) != num_verts:
        # DLL/Blender vertex-count disagreement (should be impossible — same
        # num_items drives both lists). Skip custom normals; use face normals.
        dwarn(f"[MDL Addon] Warning: normal count ({len(normals)}) does not "
              f"match vertex count ({num_verts}) on mesh '{bmesh.name}'. "
              f"Skipping custom normals.")
        return bmesh.update()

    # Scrub zero-length and non-finite entries. Fast path vectorizes the
    # validation in numpy (non-finite OR length_sq < 1e-12 → +Z); same scrub
    # rules and scrubbed-count as the slow Python loop below.
    clean_normals = None
    scrubbed = 0
    if perf._enabled():
        try:
            clean_normals, scrubbed = perf.fast_scrub_normals(normals, num_verts)
        except Exception as e:
            dlog(f"[MDL Addon] setMeshNormals fast scrub skipped ({e}); using slow path.")
            clean_normals = None

    if clean_normals is None:
        # Slow path — iterate once, in place.
        import math
        safe_default = (0.0, 0.0, 1.0)
        clean_normals = []
        for n in normals:
            # n is a mathutils.Vector
            x = float(n[0]) if len(n) > 0 else 0.0
            y = float(n[1]) if len(n) > 1 else 0.0
            z = float(n[2]) if len(n) > 2 else 0.0
            if not (math.isfinite(x) and math.isfinite(y) and math.isfinite(z)):
                clean_normals.append(safe_default)
                scrubbed += 1
                continue
            length_sq = x*x + y*y + z*z
            if length_sq < 1e-12:
                clean_normals.append(safe_default)
                scrubbed += 1
                continue
            clean_normals.append((x, y, z))

    if scrubbed:
        # Non-fatal — mesh loads, some verts may shade flat.
        dwarn(f"[MDL Addon] Note: replaced {scrubbed} invalid normal(s) "
              f"with +Z default on mesh '{bmesh.name}'.")

    # Blender < 4.3: normals_split_custom_set_from_vertices assumes UNIT-LENGTH
    # input. EVERY pre-4.3 build mis-encodes non-unit normals -> drift up to
    # ~7-9deg on shared/seam verts -> faceted/wrinkled SOLID-viewport shading
    # (the depsgraph render and loop.normal readback look fine, which is why it
    # hid). Measured affected on 2.93, 3.3, 4.1, 4.2 (all ~7-9deg pre-fix);
    # clean on 4.3/4.4/4.5/5.0/5.1. Older-game models (2K20-2K25; .mdl + .mcd)
    # carry quantized normals slightly off-unit (~0.99-1.004) so they trip it;
    # 2K26 normals are already unit and don't. Blender fixed it in 4.3
    # (normalizes internally). We pre-normalize to match — STRICT no-op on
    # 4.3+/5.x (they normalize anyway, validated round-trips untouched) and on
    # already-unit input (2K26). The export reads the stored (Blender-normalized)
    # normals, so this changes no round-trip on any version.
    if bpy.app.version < (4, 3, 0):
        na = np.asarray(clean_normals, dtype=np.float32).reshape(-1, 3)
        ln = np.sqrt((na * na).sum(axis=1))
        ln[ln == 0.0] = 1.0          # already-scrubbed +Z stays unit; guard anyway
        clean_normals = (na / ln[:, None]).tolist()

    # On 4.x the assertion path can surface as a Python RuntimeError (not a
    # segfault) for some mesh states; catch it so the mesh still loads with
    # face-computed normals instead of crashing Blender.
    try:
        bmesh.normals_split_custom_set_from_vertices(clean_normals)
    except (RuntimeError, ValueError) as e:
        dwarn(f"[MDL Addon] Warning: normals_split_custom_set_from_vertices "
              f"failed on mesh '{bmesh.name}': {e}. Using computed normals.")

    return bmesh.update()

def setMeshTangents(bmesh, tangents):
    """Capture imported vanilla tangents as per-vertex POINT attributes so the
    exporter can feed them back byte-for-byte on an unedited mesh.

    WHY: WDF (wrap-deform) stores its barycentric deltas in TANGENT space; if
    MikkTSpace regenerates tangents they drift (up to 133deg) and the binding
    silently breaks. Blender has no "custom tangent" concept (unlike split
    normals), so stash vanilla values and re-apply at export (gated by
    computeTbnHash so edits regenerate).

    `tangents` is (N,4) float32 [x,y,z,w] in GAME/LOCAL coords (no axis swap),
    w = bitangent handedness. loadSkinMesh builds the mesh 1:1 from the MCD
    buffer so the POINT domain lines up per-vertex (also drives the DLL-preprocess
    export which gathers per-loop by vertex index). Two stock attributes (dodging
    FLOAT_COLOR color-management ambiguity):
        VC_TANGENT       FLOAT_VECTOR (xyz)  POINT
        VC_TANGENT_SIGN  FLOAT        (w)    POINT
    """
    # IMPORTANT: loadSkinMesh calls this BEFORE setMeshNormals. On pre-4.1 Blender
    # (2.93/3.x), adding this POINT attribute AFTER create_normals_split has built the
    # legacy custom-split-normal CustomData layer hard-crashes the realloc; created first
    # (on the fresh mesh) it is safe on every version (verified 2.93/3.3/4.1/4.2/5.1).
    # So the capture runs on all versions — do NOT move the call after setMeshNormals.
    if not hasattr(bmesh, "attributes"):
        return
    if tangents is None:
        return
    num_verts = len(bmesh.vertices)
    if num_verts == 0:
        return
    if len(tangents) != num_verts:
        dwarn(f"[MDL Addon] Tangent count ({len(tangents)}) != vertex count "
              f"({num_verts}) on '{bmesh.name}'; skipping tangent capture.")
        return

    arr = np.ascontiguousarray(tangents, dtype=np.float32)
    xyz = np.ascontiguousarray(arr[:, :3], dtype=np.float32).ravel()
    w   = np.ascontiguousarray(arr[:, 3],  dtype=np.float32).ravel()

    # Drop any stale layers first so a re-import overwrites cleanly.
    for nm in ("VC_TANGENT", "VC_TANGENT_SIGN"):
        existing = bmesh.attributes.get(nm)
        if existing is not None:
            try:
                bmesh.attributes.remove(existing)
            except Exception:
                pass

    # Interleave create+write: each attributes.new() can REALLOCATE the CustomData
    # array, invalidating the Python ref returned by an earlier .new(). On 2.9x that
    # stale pointer hard-crashes — so write each attribute's data BEFORE creating the
    # next. (4.1+ tolerates the old create-both-then-write order; interleaving is
    # order-correct on every version.)
    try:
        a_xyz = bmesh.attributes.new(name="VC_TANGENT", type='FLOAT_VECTOR', domain='POINT')
        a_xyz.data.foreach_set('vector', xyz)
        a_w   = bmesh.attributes.new(name="VC_TANGENT_SIGN", type='FLOAT', domain='POINT')
        a_w.data.foreach_set('value', w)
    except Exception as e:
        dwarn(f"[MDL Addon] Could not create tangent attributes on "
              f"'{bmesh.name}': {e}. Tangents will regenerate on export.")
        return
    return

def setMeshPackedTBN(bmesh, words):
    """Capture the imported vanilla PackedTBN octahedral words as a per-vertex
    POINT attribute so the exporter can feed them back byte-for-byte on an unedited
    mesh (DLL's per-vertex serializer gate decides keep-vs-reencode).

    `words` is (N,) uint32, one OPAQUE oct-TBN word per vertex in vanilla render
    order (NO axis swap, NO decode). loadSkinMesh builds the mesh 1:1 from the MCD
    buffer so the POINT domain lines up per-vertex (same as VC_TANGENT).

    Stored as INT: Blender has no uint32 attr type, so reinterpret uint32→int32
    (lossless reversible bit cast — words >= 2^31 read back negative and flip back
    on export). Named VC_PACKEDTBN to sit alongside VC_TANGENT/VC_TANGENT_SIGN.
    """
    # IMPORTANT: loadSkinMesh calls this BEFORE setMeshNormals — see setMeshTangents.
    # Creating this POINT attribute on the fresh mesh (before create_normals_split's
    # legacy layer exists) is safe on every version; adding it after hard-crashes pre-4.1.
    if not hasattr(bmesh, "attributes"):
        return
    if words is None:
        return
    num_verts = len(bmesh.vertices)
    if num_verts == 0:
        return
    if len(words) != num_verts:
        dwarn(f"[MDL Addon] PackedTBN word count ({len(words)}) != vertex count "
              f"({num_verts}) on '{bmesh.name}'; skipping PackedTBN capture.")
        return

    # uint32 -> int32 lossless bit reinterpret for Blender's INT attribute.
    as_i32 = np.ascontiguousarray(words, dtype=np.uint32).view(np.int32)

    # Drop any stale layer first so a re-import overwrites cleanly.
    existing = bmesh.attributes.get("VC_PACKEDTBN")
    if existing is not None:
        try:
            bmesh.attributes.remove(existing)
        except Exception:
            pass

    try:
        a_w = bmesh.attributes.new(name="VC_PACKEDTBN", type='INT', domain='POINT')
    except Exception as e:
        dwarn(f"[MDL Addon] Could not create PackedTBN attribute on "
              f"'{bmesh.name}': {e}. PackedTBN will regenerate on export.")
        return

    a_w.data.foreach_set('value', as_i32)
    return

def setVertexGroups(obj, vertex_skin):
    """Assign DLL-supplied per-bone weights to Blender vertex groups.

    vertex_group.add() with an out-of-range vertex index does NOT raise on 3.x /
    early 4.x — it silently corrupts adjacent memory, and the depsgraph eval
    crashes Blender 3-4s later (5.x raises IndexError). Fix: clamp iteration to
    the mesh's actual vertex count.
    """
    # Check if the mesh has valid skin groups
    if vertex_skin.groups == None:
        return
    
    num_verts = len(obj.data.vertices)
    total_oob = 0

    # Fast path — bucket weights by exact value, one .add() per bucket instead of
    # per (vert, bone). Game weights are 8-bit unorm (<=256 unique values/group),
    # collapsing ~1.5M calls on a character mesh to a few hundred. Same final
    # state since the group is freshly created (REPLACE on empty == ADD).
    fast_done = False
    if perf._enabled():
        try:
            total_oob = perf.fast_set_vertex_groups(obj, vertex_skin)
            fast_done = True
        except Exception as e:
            dlog(f"[MDL Addon] setVertexGroups fast path skipped ({e}); using slow path.")

    if not fast_done:
        # Slow path — preserved as the safety net.
        weights_list = vertex_skin.weights
        for i, group in enumerate(vertex_skin.groups):
            # A malformed file can desync the group-name list from the weight-row
            # list (half-written skin sub-stream); indexing weights[i] by the group
            # counter would IndexError. Stop at the shorter list. No-op when the
            # lists agree (valid files).
            if weights_list is None or i >= len(weights_list):
                break
            vertex_group = obj.vertex_groups.new(name=group)
            vertex_weights = weights_list[i]

            for index, weight in enumerate(vertex_weights):
                if index >= num_verts:
                    total_oob += len(vertex_weights) - index
                    break
                if (weight != 0.0):
                    vertex_group.add([index], weight, 'ADD')

    if total_oob:
        dwarn(f"[MDL Addon] Warning: '{obj.name}' skipped {total_oob} "
              f"out-of-range weight entries (DLL weight count exceeds "
              f"mesh vertex count {num_verts}). Mesh loaded safely.")
                
    return

def addColorMap(bmesh, layer, color_map):
    # Defensive: a None layer means add_vertex_color_layer hit Blender's 8-layer
    # color cap (early/unfinished-exporter file with surplus color maps). Skip it
    # rather than crash on None.data. No-op for valid files (layer is never None).
    if layer is None:
        return
    # RNA property to write: BYTE_COLOR on 3.5+ uses 'color_srgb' so stored bytes
    # are byte-identity with the MCD floats (symmetric with getVertexColors's
    # export-side read). FLOAT_COLOR / older Blender stays 'color'. Without this,
    # import would linear→sRGB-encode and store BRIGHTER bytes than vanilla, which
    # darkens on export decode → asymmetric round-trip ("goes in darker").
    from .blender_utils import _color_io_attr_name
    color_attr = _color_io_attr_name(layer)

    # Fast path — bulk per-loop color write via foreach_set. Same
    # scatter as the slow path (per-loop color = color_map[vert]).
    if perf._enabled():
        try:
            perf.fast_add_color_map(bmesh, layer, color_map, attr_name=color_attr)
            return
        except Exception as e:
            dlog(f"[MDL Addon] addColorMap fast path skipped ({e}); using slow path.")

    for poly in bmesh.polygons:
        # Use the loop's actual global index (loop_indices), not a manual counter
        # that assumes poly-traversal loop ordering (matches the export-side fix).
        for v_ix, l_ix in zip(poly.vertices, poly.loop_indices):
            setattr(layer.data[l_ix], color_attr, color_map[v_ix])
    return
                
def setMeshColors(bmesh, vertex_colors):
    # add_vertex_color_layer creates a per-corner BYTE_COLOR attribute that
    # matches the legacy vertex_colors.new() shape. Works 2.93 through 5.1.
    skipped = 0
    for label, map in zip(vertex_colors.labels, vertex_colors.maps):
        color_layer = add_vertex_color_layer(bmesh, label)
        if color_layer is None:
            # Blender hard-caps color layers at 8; surplus maps from an
            # early/unfinished-exporter file can't be held. Skip rather than
            # crash. No-op for valid files (<=8 color maps never return None).
            skipped += 1
            continue
        addColorMap(bmesh, color_layer, map)
    if skipped:
        dwarn(f"[MDL Addon] '{bmesh.name}': {len(vertex_colors.maps)} color maps "
              f"exceed Blender's 8-layer cap; dropped {skipped} surplus map(s).")
    return

def unpackVertex(verts, index):
    pos = (index*3)
    return  [ verts[pos], verts[pos+1], verts[pos+2] ]

def setBlendShapes(obj, blendshapes):
    """Build shape keys from DLL-supplied (indices, verts) data.

    Defense-in-depth: the DLL hands back MCD-relative vertex indices and a flat
    xyz vert array; both are range-checked against the mesh's ACTUAL post-creation
    vertex count before indexed writes to sk.data. Writing sk.data[i].co with
    i >= len(sk.data) does NOT raise on 3.x / early 4.x — it lands past the array
    in memory and the next depsgraph eval crashes Blender ("crashes a few seconds
    after the model loads"; 5.x catches OOB and raises). On healthy data the
    checks are free; on DLL/Blender index drift we skip the bad entry.
    """
    if (len(blendshapes) == 0): return

    mesh = obj.data
    num_verts = len(mesh.vertices)
    if num_verts == 0:
        return

    sk_basis = obj.shape_key_add( name="Basis", from_mix=False )
    sk_basis.interpolation = 'KEY_LINEAR'
    obj.data.shape_keys.use_relative = True

    total_skipped = 0

    # Fast path — read basis once, share one working buffer across all shapes
    # (v2.3.1: eliminates the per-shape basis_co.copy() that churned 250+ MB on
    # 2K26 facial rigs). Sparse FACS shapes do ~2-3 KB of in-place index resets
    # instead of a 288 KB full copy per shape; the per-shape foreach_set collapses
    # ~1M slow-path RNA writes to one C-side buffer copy each.
    # `sk.value = 0.0` reset is gated to Blender 5+ (pre-5 already defaults to 0.0).
    fast_done = False
    needs_value_reset = bpy.app.version >= (5, 0, 0)
    if perf._enabled():
        try:
            basis_co = perf.read_basis_co(sk_basis.data, num_verts)
            # Shared working buffer — one allocation total, mutated in
            # place across every shape via fast_apply_blendshape.
            work_buf = basis_co.copy()
            last_touched = None
            for shape in blendshapes:
                sk = obj.shape_key_add(name=shape.name, from_mix=False)
                if needs_value_reset:
                    sk.value = 0.0  # Blender 5 defaults to 1.0; pre-5 already 0.0
                per_shape_skipped, last_touched = perf.fast_apply_blendshape(
                    obj, shape, sk, basis_co, num_verts,
                    work_buf=work_buf, last_touched=last_touched)
                if per_shape_skipped:
                    total_skipped += per_shape_skipped
                    dwarn(f"[MDL Addon] Shape key '{shape.name}' on mesh "
                          f"'{mesh.name}': skipped {per_shape_skipped} "
                          f"out-of-range morph indices (mesh has "
                          f"{num_verts} verts).")
            fast_done = True
        except Exception as e:
            dlog(f"[MDL Addon] setBlendShapes fast path skipped ({e}); using slow path.")

    if not fast_done:
        for shape in blendshapes:
            sk = obj.shape_key_add( name=shape.name, from_mix=False )
            if needs_value_reset:
                sk.value = 0.0  # Blender 5 defaults to 1.0; pre-5 already 0.0

            verts = shape.verts
            verts_len = len(verts) if verts is not None else 0
            # We read verts at offset index*3 .. index*3+2, so the largest
            # addressable vertex index is (verts_len // 3) - 1.
            max_vert_index = (verts_len // 3) - 1 if verts_len else -1

            per_shape_skipped = 0
            for index in shape.indices:
                # Guard the shape-key data write: index must fit in sk.data.
                # sk.data is sized to match mesh.vertices, so num_verts is the
                # authoritative bound.
                if index < 0 or index >= num_verts:
                    per_shape_skipped += 1
                    continue
                # Guard the verts read: index must fit in shape.verts too.
                if index > max_vert_index:
                    per_shape_skipped += 1
                    continue
                sk.data[index].co = unpackVertex(verts, index)

            if per_shape_skipped:
                total_skipped += per_shape_skipped
                dwarn(f"[MDL Addon] Shape key '{shape.name}' on mesh "
                      f"'{mesh.name}': skipped {per_shape_skipped} "
                      f"out-of-range morph indices (mesh has {num_verts} verts).")

    if total_skipped:
        # Aggregate warning so a mesh with many bad shapes doesn't spam.
        dwarn(f"[MDL Addon] {total_skipped} shape-key morph offsets "
              f"skipped on mesh '{mesh.name}' due to index drift. "
              f"The mesh loaded without crashing; affected shape keys "
              f"may be missing deformation on some vertices.")

    obj.data.update()
    return

def loadSkinMesh(skinmesh, settings, model_path):
    # Get user scene load settings
    USE_SHAPE_KEYS      = settings[ "import_shape_keys" ]
    # "Load Material Textures" checkbox. When False, skip bpy.data.images.load but
    # still build material slots + face-group assignments (model structure, needed
    # for a clean round-trip). Default True for legacy callers.
    LOAD_TEXTURES       = settings.get( "load_textures", True )

    # ── Face validation ──
    # Scrub degenerate/out-of-range faces: repeated vert indices (e.g. (5,5,7)) or
    # indices past the vertex array create undefined edge topology that crashes the
    # depsgraph evaluator 3-4s after import on Blender 4.x.
    # v2.3.1: skinmesh.vertices/index_list are now ndarrays — use `is not None` +
    # `len() > 0` (bare truthiness is ambiguous).
    num_verts = len(skinmesh.vertices) if skinmesh.vertices is not None else 0
    clean_faces = skinmesh.index_list
    degenerate_count = 0

    if clean_faces is not None and len(clean_faces) > 0 and num_verts > 0:
        keep_mask = np.ones(len(clean_faces), dtype=bool)
        # Vectorized: drop faces with a duplicate or out-of-range vert index (same
        # semantics as the old per-face loop).
        f = np.asarray(clean_faces, dtype=np.int32)
        dup = (f[:, 0] == f[:, 1]) | (f[:, 1] == f[:, 2]) | (f[:, 0] == f[:, 2])
        oob = (f < 0).any(axis=1) | (f >= num_verts).any(axis=1)
        bad = dup | oob
        if bad.any():
            degenerate_count = int(bad.sum())
            keep_mask = ~bad
            clean_faces = f[keep_mask]
            dwarn(f"[MDL Addon] Warning: stripped {degenerate_count} degenerate/"
                  f"out-of-range face(s) from mesh '{skinmesh.mesh_name}'.")

    # Normalize empty-faces sentinel — getIndexList returns None for LOD0-only
    # 2K26 meshes (MBfD packing, see below). After this, clean_faces is an (T,3)
    # int32 ndarray or empty — never None.
    if clean_faces is None:
        clean_faces = np.empty((0, 3), dtype=np.int32)
    n_faces = len(clean_faces)

    # ── Direct mesh construction (replaces from_pydata) ──
    # from_pydata writes per-element (~10x slower) than the direct vertices.add()
    # + foreach_set + loops/polygons path; numpy ndarrays are already prepared
    # upstream. Restoring from_pydata's free side-effects:
    #   * edge derivation → mesh.update(calc_edges=True) below.
    #   * loop_start/loop_total → arange(0,n*3,3) / full(n,3); all faces are tris
    #     by construction (validated above; the MDL stream emits tris only).
    #   * normals/UVs/material_index aren't set by from_pydata either — downstream
    #     setMeshNormals/setTexCoords/setMaterials handle them the same way.
    # `or` coerces a None/empty name to a placeholder: bpy.data.meshes.new(None)
    # raises TypeError (a malformed file can leave the name sub-stream null).
    # No-op for valid files, which always carry a real mesh name.
    new_mesh = bpy.data.meshes.new(skinmesh.mesh_name or "Mesh")

    if num_verts > 0:
        new_mesh.vertices.add(num_verts)
        # skinmesh.vertices is (N,3) float32 from getMeshVerts; ravel is a view.
        new_mesh.vertices.foreach_set(
            'co', np.ascontiguousarray(skinmesh.vertices, dtype=np.float32).ravel())

    # Gate face construction on verts EXISTING. The degenerate/OOB face filter
    # above is skipped when num_verts == 0, so a malformed file that wrote faces
    # but an empty vertex buffer would scatter vertex_index pointers into a mesh
    # with no vertices/loops — the depsgraph dereferences them and hard-crashes a
    # few seconds after import. Loading the mesh empty is correct (no verts = no
    # surface). Strict no-op for valid files (faces always come with verts).
    if n_faces > 0 and num_verts == 0:
        dwarn(f"[MDL Addon] '{skinmesh.mesh_name}': {n_faces} face(s) but 0 "
              f"vertices (malformed/empty vertex buffer); loading mesh empty.")
        n_faces = 0
    if n_faces > 0:
        new_mesh.loops.add(n_faces * 3)
        new_mesh.loops.foreach_set(
            'vertex_index',
            np.ascontiguousarray(clean_faces, dtype=np.int32).ravel())
        new_mesh.polygons.add(n_faces)
        new_mesh.polygons.foreach_set(
            'loop_start',
            np.arange(0, n_faces * 3, 3, dtype=np.int32))
        new_mesh.polygons.foreach_set(
            'loop_total',
            np.full(n_faces, 3, dtype=np.int32))

    # calc_edges=True derives mesh.edges from the polygon loops (same set
    # from_pydata produced); required by edge-walking consumers (HPL round-trip).
    # Also, Blender 4.0–4.3 won't fully init CustomData layer flags for the custom
    # normal attribute until update() runs — calling split-normals on an unprepared
    # 4.x mesh triggered the "Blender 4 crash on import" bug. Harmless on 3.x/5.x.
    #
    # validate(verbose=False) was REMOVED from here:
    #   (a) On 4.1+ it can ADD a 'sharp_face' attribute that silently flat-shades
    #       the mesh under our custom split normals → 4.x depsgraph crash.
    #   (b) On any version it may trim topology (orphan verts, dup edges); shape
    #       keys then reference MCD-relative indices that no longer line up, and
    #       the writes land in stale memory on 3.x/early 4.x → depsgraph detonates.
    # DLL topology is already triangulated/well-formed; the pass did nothing useful.
    new_mesh.update(calc_edges=True)

    new_object = bpy.data.objects.new( skinmesh.name or "Object" , new_mesh ) # Create object container (None-name safe)

    # Set mesh attributes
    # VC_TANGENT / VC_PACKEDTBN are captured BEFORE setMeshNormals on purpose: on
    # pre-4.1 Blender, adding a POINT attribute AFTER create_normals_split has built the
    # legacy custom-split-normal CustomData layer hard-crashes the realloc. Creating them
    # on the fresh mesh first is safe on every version (verified 2.93/3.3/4.1/4.2/5.1),
    # so the WDF tangent-frame preservation now works on old Blender too. Do not reorder.
    setMeshTangents  (new_mesh,    skinmesh.vertex_tangents)
    setMeshPackedTBN (new_mesh,    skinmesh.original_packedtbn)
    setMeshNormals   (new_mesh,    skinmesh.vertex_normals)
    setTexCoords     (new_mesh,    skinmesh.texcoords)
    setVertexGroups  (new_object,  skinmesh.skin)
    setMeshColors    (new_mesh,    skinmesh.vertex_colors)
    setMeshGameFlags (new_object,  skinmesh.scene_flag, skinmesh.motion_flag)
    setMaterials     (new_object , skinmesh.material_groups, model_path, load_textures=LOAD_TEXTURES)

    if (USE_SHAPE_KEYS):
        setBlendShapes  (new_object,  skinmesh.blendshapes)
    
    # Fingerprint geometry+topology so export can detect edits. Only meaningful
    # when tangents were captured; otherwise unset (export regenerates anyway).
    if skinmesh.vertex_tangents is not None:
        h = computeTbnHash(new_mesh)
        if h is not None:
            new_object["VC_TBN_HASH"] = h

    # Store vertex remap for HPL masking (MCD→Blender index mapping)
    if skinmesh.vertex_remap:
        import json
        new_object["vcmodel_vertex_remap"] = json.dumps(skinmesh.vertex_remap)
    
    # Tag meshes that had vertex colors (export uses this to decide which meshes get colors)
    if skinmesh.vertex_colors and len(skinmesh.vertex_colors.maps) > 0:
        new_object["vcmodel_has_vertex_colors"] = True
    
    return new_object

