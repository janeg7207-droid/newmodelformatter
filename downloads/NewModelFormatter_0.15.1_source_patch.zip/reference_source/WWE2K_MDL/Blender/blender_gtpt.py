"""GtPt anchor scene representation (import side).

Builds the Blender data structures modders see/edit: a SPHERE empty per record
under VC_GtPt_Anchors (viewport-visible, AtPt-style), plus a per-record vertex
group pinning the anchor to its source vertex.

Round-trip pairing:
  - The empty stores identity (name, group, slot, source vertex index, position)
    as custom props — the selectable/inspectable visual affordance.
  - The vertex group VC_GTPT__{slot:03d}__{name} (single vertex, weight 1.0) is the
    DURABLE anchor: survives mesh edits, welds, decimation, and the M_Head_Caruncle
    → M_Head merge this system exists for. The export resolver reads it first,
    falling back to the empty's nearest-vertex resolution only if the group is gone.

Anchor groups are prefixed VC_GTPT__ (canonical helper in skinmodel_gp.py);
getVertexWeights filters this prefix before bone resolution, so they never enter
the skinning path despite sharing the mesh with real deform groups.
"""

import bpy
from mathutils import Vector
from ..SkinModel.skinmodel_gp import gtpt_vertex_group_name
from ..Serialize.gtpt_resolver import (
    GROUP_MERGE_FALLBACKS,
    canonical_mesh_name_from_str,
)
from ..Link.log import dlog, dwarn, derror


GTPT_COLLECTION_NAME = "VC_GtPt_Anchors"


def _get_or_create_collection(name, parent):
    """Get the named collection or create it under `parent`. Idempotent."""
    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
        parent.children.link(coll)
        return coll
    # Existing collection — ensure it's linked under `parent` (leave any other
    # links alone; Blender supports multi-parent collections).
    if name not in [c.name for c in parent.children]:
        try:
            parent.children.link(coll)
        except RuntimeError:
            pass  # Already linked via another path; harmless.
    return coll


def _canonical_mesh_name(obj):
    """Extract the canonical M_* identifier from a mesh object.

    Import puts the canonical name (M_Head, M_Head_Caruncle, ...) on the mesh
    DATABLOCK, not the object (loadSkinMesh: meshes.new(mesh_name) vs
    objects.new(name)). Thin wrapper around canonical_mesh_name_from_str
    (gtpt_resolver.py) so import/generator/export share name normalization.
    """
    if obj is None or obj.data is None:
        return None
    return canonical_mesh_name_from_str(obj.data.name)


def _find_mesh_by_name(target_name, root_collection):
    """Find a mesh object whose canonical M_* identifier matches target_name.

    Resolves via _canonical_mesh_name (datablock name, suffix-stripped + case-
    corrected) — same path the export side uses, so resolution is symmetric.
    Falls back to obj.name for datablock-renamed objects (rare; cheap guard).
    """
    if not target_name:
        return None

    # Walk only the model's root collection, not the whole scene — multiple model
    # imports must not cross-bind anchors onto each other's meshes.
    def walk(coll):
        for obj in coll.objects:
            yield obj
        for child in coll.children:
            yield from walk(child)

    candidates = [obj for obj in walk(root_collection) if obj.type == 'MESH']

    # Primary: canonical M_* identifier from mesh datablock.
    for obj in candidates:
        if _canonical_mesh_name(obj) == target_name:
            return obj

    # Fallback: object name match (datablock-rename edge cases).
    for obj in candidates:
        if obj.name == target_name:
            return obj

    return None


def _vertex_world_position(mesh_obj, vertex_index, world_matrix_override=None):
    """World-space position of a vertex on `mesh_obj`. None if out of range.
    `world_matrix_override` lets the caller pass a manual matrix when
    mesh_obj.matrix_world is stale (right after parenting, pre-depsgraph-tick).
    """
    if mesh_obj is None or mesh_obj.type != 'MESH':
        return None
    verts = mesh_obj.data.vertices
    if vertex_index < 0 or vertex_index >= len(verts):
        return None
    local = verts[vertex_index].co
    if world_matrix_override is not None:
        return world_matrix_override @ local
    return mesh_obj.matrix_world @ local


def _create_anchor_empty(name, location, collection):
    """Create a SPHERE empty at `location` under `collection`. AtPt-style visible
    spheres for viewport selection; hide_render True (authoring-time metadata only).
    """
    empty = bpy.data.objects.new(name, None)
    empty.empty_display_type = 'SPHERE'
    empty.empty_display_size = 0.4
    empty.location = location if location is not None else Vector((0.0, 0.0, 0.0))
    collection.objects.link(empty)
    empty.hide_render = True
    return empty


def _attach_vertex_group(mesh_obj, group_name, vertex_index):
    """Create or refresh the per-record anchor vertex group.

    Idempotent — re-importing the same model replaces any existing
    group of this name without leaving stale weights on other verts.
    """
    if mesh_obj is None or mesh_obj.type != 'MESH':
        return None
    if vertex_index < 0 or vertex_index >= len(mesh_obj.data.vertices):
        return None

    # Remove any same-named group from a prior import to avoid stale weights
    # from a different source vertex.
    existing = mesh_obj.vertex_groups.get(group_name)
    if existing is not None:
        mesh_obj.vertex_groups.remove(existing)

    vg = mesh_obj.vertex_groups.new(name=group_name)
    vg.add([vertex_index], 1.0, 'REPLACE')
    return vg


def _compute_object_world_matrix(obj):
    """Build obj.matrix_world manually from location/rotation/scale.

    Replaces a view_layer.update() that forced a full-scene depsgraph eval per
    import (the dominant cost of a 2nd/3rd basemodel import) just to refresh
    matrix_world after parenting. Equivalent to Matrix.LocRotScale (3.0+) but built
    from primitives for 2.93+ compat.
    """
    from mathutils import Matrix
    loc_m   = Matrix.Translation(obj.location)
    rot_m   = obj.rotation_euler.to_matrix().to_4x4()
    scale_m = Matrix.Diagonal(obj.scale.to_4d())
    return loc_m @ rot_m @ scale_m


def setup_gtpt_anchors(model, parent_collection, armature_obj=None):
    """Build the full anchor scene representation for a freshly imported model.

    Called from loadSkinModel after meshes are linked; no-ops when the model has no
    GtPt data. `armature_obj` (the just-built parent) lets us compute mesh world
    matrices from its transform instead of the stale-after-parenting matrix_world,
    avoiding a view_layer.update() that scales with scene size.
    """
    points = getattr(model, 'goto_points', None)
    if not points:
        # No GtPt records — but a head mesh in the scene renders dark eyes without
        # anchors, so warn (non-blocking) to run Generate Character GtPts. Quiet for
        # models that don't need GtPt (body parts, props).
        try:
            head_present = any(
                obj.type == 'MESH' and obj.data is not None
                and _canonical_mesh_name(obj) in ('M_Head', 'M_Head_Caruncle')
                for obj in parent_collection.all_objects
            )
        except Exception:
            head_present = False
        if head_present:
            dwarn("[MDL Addon] GtPt: This model has no GtPt anchors. "
                  "Click Generate Character GtPts before export to "
                  "avoid dark eyes in-game.")
        return

    # Each mesh was parented with no matrix_parent_inverse, so its world matrix
    # equals the armature's — derive that manually. (Per-mesh transforms before
    # this point would break the assumption; the depsgraph route below is the net.)
    mesh_world_override = None
    if armature_obj is not None:
        try:
            mesh_world_override = _compute_object_world_matrix(armature_obj)
        except Exception:
            mesh_world_override = None

    if mesh_world_override is None:
        # Fallback (no armature passed, or matrix build failed): force a depsgraph
        # eval so the matrix_world read below sees the new parenting.
        try:
            import bpy
            bpy.context.view_layer.update()
        except Exception:
            pass

    anchor_col = _get_or_create_collection(GTPT_COLLECTION_NAME, parent_collection)

    created = 0
    skipped_unresolved = 0
    skipped_missing_mesh = 0
    skipped_bad_vertex = 0

    for p in points:
        # Unresolved string = the source TEXT table had no entry at the recorded
        # index; can't place an anchor without its mesh/name.
        if not p.name or not p.group_name:
            skipped_unresolved += 1
            continue

        # Resolve target mesh. If group_name isn't in the scene (typical when a prior
        # export merged caruncle into M_Head), apply the export resolver's merge-
        # fallback — else every caruncle anchor on a re-imported merged head lands at
        # origin. The empty's gtpt_group prop keeps the original name for un-merge.
        target_mesh = _find_mesh_by_name(p.group_name, parent_collection)
        target_group_for_anchor = p.group_name
        if target_mesh is None:
            fallback_name = GROUP_MERGE_FALLBACKS.get(p.group_name)
            if fallback_name:
                target_mesh = _find_mesh_by_name(fallback_name, parent_collection)
                if target_mesh is not None:
                    target_group_for_anchor = fallback_name

        if target_mesh is None:
            # Group resolved but the mesh isn't in the scene and no fallback applied
            # (partial import / user-deleted mesh). Still create the empty so the
            # record round-trips; only the vertex-group binding is missing.
            skipped_missing_mesh += 1

        world_pos = _vertex_world_position(target_mesh, p.vertex_index,
                                           world_matrix_override=mesh_world_override)
        if target_mesh is not None and world_pos is None:
            skipped_bad_vertex += 1
            # Don't bail — create the empty at origin so identity survives; the
            # resolver warns about the missing position at export.

        empty_name = f"gtpt_{p.slot:03d}_{p.name}"
        empty = _create_anchor_empty(
            empty_name,
            world_pos if world_pos is not None else Vector((0.0, 0.0, 0.0)),
            anchor_col,
        )

        # Custom props read by the export resolver; gtpt_ prefix for property-panel
        # clarity and to avoid colliding with other addon-stamped props.
        empty["gtpt_name"]            = p.name
        empty["gtpt_group"]           = target_group_for_anchor
        empty["gtpt_slot"]            = int(p.slot)
        empty["gtpt_source_vertex"]   = int(p.vertex_index)
        if world_pos is not None:
            empty["gtpt_source_position"] = [float(world_pos.x),
                                             float(world_pos.y),
                                             float(world_pos.z)]

        # Vertex group — the durable anchor that survives mesh edits.
        if target_mesh is not None and world_pos is not None:
            vg_name = gtpt_vertex_group_name(p.slot, p.name)
            _attach_vertex_group(target_mesh, vg_name, p.vertex_index)

        created += 1

    # Single summary line with the skip-reason breakdown (dlog → silent unless
    # verbose; the counters are diagnostic, not user-facing).
    dlog(f"[MDL Addon] GtPt: created {created} anchor(s) under "
         f"'{GTPT_COLLECTION_NAME}' (skipped: unresolved={skipped_unresolved}, "
         f"missing_mesh={skipped_missing_mesh}, bad_vertex={skipped_bad_vertex})")
