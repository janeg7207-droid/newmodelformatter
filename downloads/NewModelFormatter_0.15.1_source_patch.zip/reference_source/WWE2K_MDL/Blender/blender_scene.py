import bpy
import os
from .blender_mesh import *
from .blender_skeleton import *
from ..Link.log import dlog, dwarn

def getNewSceneCollection(name, link_to_scene=True):
    collection = bpy.data.collections.new(name)
    if (link_to_scene):
        bpy.context.scene.collection.children.link(collection)
    return collection

def _strip_unused_vertex_groups(piece):
    """Remove vertex groups with zero weighted vertices on `piece`.

    Blender's separate-by-material copies the full vertex-group table to every
    piece regardless of what its verts reference, leaving empty group shells (a
    split M_EYE leaves both eye_l and eye_r carrying J_Eye_L+J_Eye_R+J_Head+...).

    The removal MUST be two-phase: (1) walk the table while indices are stable,
    collecting groups to remove; (2) call vgs.remove() in a separate pass. A naive
    one-pass loop has a silent bug — vg.index is recomputed against the live
    collection, so after the first remove() every later snapshot index shifts down
    one, fails the keep-check, and gets wrongly removed. Symptom: pieces whose USED
    set lacked index 0 lost ALL groups; pieces with 0 kept exactly the index-0
    group (often J_Root, not the eye bone) → "eye_r has a group, eye_l has none,
    and it's the wrong one".
    """
    vgs = piece.vertex_groups
    if not vgs:
        return 0

    # Phase 1 — collect used group indices. Strict > 0 (a painted-then-subtracted
    # exact-0 weight signals the user dropped this vert from the group).
    used_indices = set()
    for v in piece.data.vertices:
        for g in v.groups:
            if g.weight > 0.0:
                used_indices.add(g.group)

    # Phase 2 — build the removal list with indices still stable (complete BEFORE
    # any remove() so every vg.index resolves against the untouched collection).
    to_remove = [vg for vg in vgs if vg.index not in used_indices]

    # Phase 3 — remove by VertexGroup object (not index), so identity survives
    # the index shifts during the loop.
    for vg in to_remove:
        vgs.remove(vg)

    return len(to_remove)


def splitAllMaterialGroups(obj):
    """Separate `obj` into one piece per material and tidy each piece.

    Back-end for the Import panel's "Split Material Groups" toggle. Each piece is
    named after its active material; two cleanups run AFTER the rename:
      * drop zero-polygon pieces (overlapping source material face ranges leave an
        invisible empty shell),
      * strip vertex groups with no weighted verts ("eye_l carries J_Eye_R as an
        empty shell" — separate copies the full group table regardless of use).

    An earlier rewrite also stripped Blender's .NNN suffix and removed unused
    material slots; both reverted — the .NNN strip caused "both pieces same name"
    regressions, and material_slot_remove needs the piece ACTIVE (the 4.x
    temp_override doesn't set active_object, so it removed slots from the wrong obj).
    """
    # Single-material mesh: separate is a no-op but still costs a mode round-trip
    # and can dirty selection. Return cleanly.
    if len(obj.data.materials) < 2:
        return [obj]

    # Route mode switches through setBlenderMode (early-returns in target mode,
    # handling the 'EDIT_MESH' prefix) to avoid redundant depsgraph evals — roughly
    # halves mode_set traffic on 200+-prop arena imports. try/finally so a raise
    # between the two mode_set calls doesn't strand the user in EDIT mode.
    from .blender_utils import setBlenderMode
    setBlenderMode('EDIT', obj)
    try:
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.separate(type='MATERIAL')
    finally:
        setBlenderMode('OBJECT')

    # Rename each piece to its active material name. Snapshot the selection (the
    # live collection re-evaluates on access); guard active_material None (the old
    # code raised AttributeError and aborted the rename mid-pass).
    for o in list(bpy.context.selected_objects):
        if o.active_material and o.active_material.name:
            o.name = o.active_material.name

    # Collect all pieces for cleanup; obj may or may not be selected, so include
    # it explicitly and dedupe by identity.
    pieces = list(bpy.context.selected_objects)
    if obj not in pieces:
        pieces.append(obj)

    # Drop zero-polygon pieces (overlapping source material face ranges leave an
    # invisible empty shell — remove rather than clutter the outliner).
    kept = []
    dropped_names = []
    for o in pieces:
        if len(o.data.polygons) == 0:
            dropped_names.append(o.name)
            mesh_data = o.data
            bpy.data.objects.remove(o, do_unlink=True)
            if mesh_data.users == 0:
                try:
                    bpy.data.meshes.remove(mesh_data)
                except Exception:
                    pass
        else:
            kept.append(o)

    if dropped_names:
        dwarn(f"[MDL Addon] splitAllMaterialGroups: dropped {len(dropped_names)} "
              f"empty piece(s) from '{obj.name}' after separate — likely "
              f"overlapping material face ranges in the source: "
              f"{dropped_names}")

    # Strip unused vertex groups per kept piece (no more J_Eye_R shell on eye_l).
    for piece in kept:
        vg_removed = _strip_unused_vertex_groups(piece)
        if vg_removed:
            dlog(f"[MDL Addon] splitAllMaterialGroups: '{piece.name}' "
                 f"stripped {vg_removed} unused vertex group(s)")

    # Match historical behavior: deselect the active object.
    if bpy.context.active_object:
        bpy.context.active_object.select_set(False)

    return kept

def setup_points(model, parent, armature):
    if not model.has_skeleton():
        return
    
    ap_col = getNewSceneCollection("Model APs", False)
    parent.children.link(ap_col)

    root = build_sphere("ap_root", ap_col)
    root.hide_set(True)
    
    load_attachment_points(ap_col, root, armature, model.attach_points)
    return

def loadSkinModel(model, parent, args, model_path):
    # construct skeleton
    armature_obj = None
    if model.has_skeleton():
        armature_obj = loadSkeleton(parent, model.getSkeleton() )
        armature_obj.rotation_euler[0] = radians(-90) # Flip default axis

    # check mesh array size
    if model.getNumMeshes() == 0:
        return

    # construct all child meshes
    for mesh in model.getMeshes():
        # Skip meshes with no triangle data. 2K26 MBfD packs all 6 LOD levels
        # (4 base × 6 = 24 entries for M_00.mcd) but the loader's lodCap=1 fills
        # triangles only for LOD0 (m_meshes[0..3]); without this, meshes 4..23
        # import as empty point clouds.
        # v2.3.1: index_list is an ndarray — explicit None+len() (bare truthiness ambiguous).
        if mesh.index_list is None or len(mesh.index_list) == 0:
            continue
        object = loadSkinMesh(mesh, args, model_path)
        parent.objects.link(object)

        if ( model.has_skeleton() ): # Link to skeleton if model has armature
            object.parent   = armature_obj
            modifier        = object.modifiers.new(type='ARMATURE', name="Armature")
            modifier.object = armature_obj
        else:
            object.rotation_euler[0] = radians(-90) # Flip default axis

        if args["split_material_groups"]:
            splitAllMaterialGroups(object)

    # Attach points + GtPt anchors are AUXILIARY: the meshes are already built and
    # linked above. Isolate both in try/except so a malformed/half-written points
    # or GtPt table from an early-exporter file can never abort the whole import
    # and cost the user their recovered meshes. No-op for valid files.
    if args["load_attachment_points"] and model.attach_points:
        try:
            setup_points(model, parent, armature_obj)
        except Exception as e:
            dwarn(f"[MDL Addon] Attachment points skipped (malformed table): {e}")

    # GtPt anchors. Independent of attach-points — a model can have
    # one without the other. Gated on the import-side option so users
    # who don't care about eye-shading anchors don't get unexpected
    # collections in their scene.
    if args.get("load_goto_points", True) and getattr(model, 'goto_points', None):
        try:
            from .blender_gtpt import setup_gtpt_anchors
            setup_gtpt_anchors(model, parent,
                               armature_obj if model.has_skeleton() else None)
        except Exception as e:
            dwarn(f"[MDL Addon] GtPt anchors skipped (malformed table): {e}")

    # NOTE: the v2.2.0 "per-mesh origin shift to visual center" pass was removed.
    # It set a per-mesh mesh_obj.location, breaking v2.1's identity-matrix_world
    # invariant; on export the float32 matmul computed translation+vert.co per mesh,
    # and head's vs body's independently-rounded translation drifted ~1 ULP at the
    # neck → non-byte-identical seam (visible in-game gap) and "almost right" morphs.
    # The scaling-pivot issue it targeted is better fixed at the scaling op (or a
    # one-time Origin > Origin to Geometry) than on every import.

    return


class vCBlenderScene():
    
    def __frame(self):
        # Frame the viewport + set render defaults. view3d.view_all needs a VIEW_3D
        # area context; File-menu imports don't guarantee one active, so locate it
        # manually. Override API: 2.93–3.1 dict-form only; 3.2+ temp_override
        # preferred; 4.0+ dict-form REMOVED (raises TypeError) → temp_override.
        try:
            bpy.ops.view3d.view_all()
            bpy.context.space_data.shading.show_object_outline = False
            bpy.context.space_data.clip_start = 10.0
            bpy.context.space_data.clip_end   = 50000.0
            return
        except Exception:
            pass

        # Fallback: find a VIEW_3D area and retry with an override.
        target_area = None
        target_region = None
        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type != 'VIEW_3D':
                    continue
                for region in area.regions:
                    if region.type == 'WINDOW':
                        target_area = area
                        target_region = region
                        break
                if target_area:
                    break
            if target_area:
                break

        if not target_area:
            return

        try:
            if hasattr(bpy.context, 'temp_override'):
                # 3.2+ path
                with bpy.context.temp_override(area=target_area, region=target_region):
                    bpy.ops.view3d.view_all()
                    target_area.spaces.active.shading.show_object_outline = False
                    target_area.spaces.active.clip_start = 10.0
                    target_area.spaces.active.clip_end = 50000.0
            else:
                # 2.93 – 3.1 dict-override path
                override = {'area': target_area, 'region': target_region}
                bpy.ops.view3d.view_all(override)
                target_area.spaces.active.shading.show_object_outline = False
                target_area.spaces.active.clip_start = 10.0
                target_area.spaces.active.clip_end = 50000.0
        except Exception:
            # Non-fatal: camera framing is a convenience, not required for
            # the model to load.
            pass
        return
    
    def build(self):
        # build unique collection for models in specified list
        for model in self.models:
            collection = getNewSceneCollection(self.scene_name)
            self.collections.append(collection)

            # Load model to blender scene context
            loadSkinModel(model, collection, self.__import_args, self.model_path)
        
        # Frame only on the first import of a session: view3d.view_all iterates
        # every visible object (scales with already-imported wrestlers) and yanks
        # the camera off what the user is looking at. The scene flag resets on
        # .blend reopen, which is the right scope.
        scene = bpy.context.scene
        if not scene.get("vc_addon_session_framed"):
            self.__frame()
            scene["vc_addon_session_framed"] = True
        return

    def set_load_args(self, args):
        self.__import_args = args
        return
    
    def set_name(self, path):
        self.model_path = path
        self.scene_name = os.path.basename(path).split(".")[0]
        return
    
    def __init__(self, model_list):
        self.scene_name = ""
        self.model_path = ""
        self.collections = []
        self.__import_args = []
        self.models = model_list

