"""Vanilla harvest: index 2K26 vanilla character JMTLs to provide per-character defaults.

Why this module exists
──────────────────────
The orchestrator already has two layers of per-character data:

  1. ``material_presets.json`` — ONE generic Default template per shader, with
     scalar / color / float defaults.
  2. XXX placeholder substitution — rewrites texture-ref strings to
     ``<slot>_<suffix>`` and recomputes the @ref FNV hash so the texture path
     is character-specific.

What's missing is per-character NON-TEXTURE parameter values. Triple H 2018's
body might ship with ``g_AOcolor = (0.31, 0.13, 0.12)`` (his actual skin tone),
while the generic template ships ``(0.45, 0.17, 0.16)``. Without vanilla
harvest, every character renders with the same baked AO tint regardless of
skin tone, and per-character spec / rough tweaks the vanilla artists baked in
disappear on re-export.

Solution
────────
Walk the vanilla sample corpus (~512 characters / ~26 000 .jmtls extracted
at ``%TEMP%/wwe2k_audit/chars/Characters``), parse each .jmtl per its known
shader byte, and harvest every populated non-texture slot value into a lookup
table keyed by (character_id, shader_byte, slot_idx).

The orchestrator then calls :func:`get_vanilla_basis` BEFORE applying user
overrides / XXX substitution; the returned ``{slot_idx: value}`` dict beats
the generic template but loses to user overrides and bound textures.

Three-stage lookup:
  1. EXACT character match — folder name == character_id.
  2. FUZZY match — strip leading digits / trailing ``_<year>``, find any
     character folder containing the stem. Sort by numeric-id proximity.
  3. FALLBACK — median (floats) / mode (discrete) across ALL sampled
     characters for that (shader, slot).

Caches and lazy loading
───────────────────────
The first call to :func:`get_vanilla_basis` triggers the full corpus walk
(~26k file parses, single-digit seconds in CPython). Subsequent calls are
O(1) dict lookups. The index lives in module-level globals; call
:func:`clear_cache` from tests to force a re-harvest.

If the sample root doesn't exist, the index degrades gracefully to an empty
dict — every lookup then returns ``{}`` and the orchestrator falls through
to the generic template, exactly as if this module wasn't installed.

Performance: on a 512-character corpus, first harvest is ~3-8 s. The index
holds roughly N_chars * avg_jmtls_per_char * avg_slots_per_jmtl entries —
about 200 k tuples on the full set, ~30-50 MB Python overhead. We do NOT
persist to disk in this pass; the cost is paid once per Blender session.
"""

from __future__ import annotations

import os
import re
import struct
import time
from collections import Counter, defaultdict
from statistics import median


# ─── Sample-data location ───────────────────────────────────────────────────

# The vanilla-corpus overlay is a maintainer-side authoring aid: it harvests
# per-shader defaults from a local folder of vanilla character .jmtls. End
# users never have that corpus, so the default root is empty and the overlay
# degrades to a no-op (see _ensure_indexed: a missing root installs an empty
# index and get_vanilla_basis returns {}). To enable it, point the
# WWE2K_MDL_VANILLA_SAMPLES env var at a Characters/ folder before launching
# Blender.
_DEFAULT_SAMPLE_ROOT = os.environ.get("WWE2K_MDL_VANILLA_SAMPLES_DEFAULT", "")


def _get_sample_root() -> str:
    return os.environ.get("WWE2K_MDL_VANILLA_SAMPLES", _DEFAULT_SAMPLE_ROOT)


# ─── Per-shader slot-type / param-key tables ────────────────────────────────
#
# These mirror the per-shader writers in ``jmtl_writer.py``. Each entry is a
# tuple of (param_key, kind), where ``kind`` is one of:
#
#   "u64"   — texture-ref hash. SKIPPED during harvest (the orchestrator's
#             XXX substitution handles textures per-character; a vanilla
#             hash from a different character would collide).
#   "bool"  — u8 0/1 boolean.
#   "u8"    — bare u8 (e.g. gear variant).
#   "u16"   — bare u16 (e.g. hair hairType).
#   "f32"   — IEEE 754 float.
#   "color" — 3-channel u8 RGB child (sub-table). Stored back into params
#             as three float keys ``<base>R/G/B`` each in 0..1.
#   "uv"    — 2-channel f32 UV child. Stored as ``<base>U/V``.
#   "glow4" — 4-channel f32 child (HDR R/G/B/A). Stored as
#             ``<base>R/G/B/A``.
#   "rgba"  — 4-channel u8 child (R/G/B/A in 0..1 floats).
#   "skip"  — slot intentionally unused (gap in the field-index sequence).
#
# ``never`` flags mark u64 slots vanilla NEVER populates (matches the
# orchestrator's _strip_never_populate). We do not harvest those either —
# they'd just contribute zero-coverage noise to the fallback index.
#
# Slot-index → key/kind. Order matches the writer's ``StartObject`` slot
# enumeration so the orchestrator's reverse lookup (slot_idx → param_key)
# stays in sync.

_SLOT_TABLE: dict[int, list[tuple[int, str, str]]] = {
    # 0x12 yCh_eye — eye_l / eye_r. 20 fields.
    0x12: [
        (0,  "colorMap@ref",            "u64"),
        (1,  "EyeInsideTex@ref",        "u64"),  # never
        (2,  "EyeMaskTex@ref",          "u64"),  # never
        (3,  "nrMap@ref",               "u64"),
        (4,  "caustic",                 "f32"),
        (5,  "g_eyeRoughness",          "f32"),
        (6,  "g_fFresnel",              "f32"),
        (7,  "g_pupilLns",              "f32"),
        (8,  "g_pupilPar",              "f32"),
        (9,  "g_refraction",            "bool"),
        (10, "g_specIntensity",         "f32"),
        (11, "g_eyeWetness",            "f32"),
        (12, "eyeLidShadowDarkness",    "f32"),
        (13, "eyeLidShadowFallOff",     "f32"),
        (14, "eyeShadowConeSharpness",  "f32"),
        (15, "eyeShadowConeBgLevel",    "f32"),
        (16, "eyeShadowHorizontalFit",  "f32"),
        (17, "eyeShadowLidZBias",       "f32"),
        (18, "eyeShadowVerticalBias",   "f32"),
        (19, "eyeShadowVerticalFit",    "f32"),
    ],
    # 0x13 yCh_caruncle. 13 fields.
    0x13: [
        (0,  "colorMap@ref",         "u64"),
        (1,  "nrMap@ref",            "u64"),   # never
        (2,  "g_mPixMsk@ref",        "u64"),
        (3,  "detailzoneMap@ref",    "u64"),
        (4,  "flushMap@ref",         "u64"),   # never
        (5,  "subSurfaceAOMap@ref",  "u64"),
        (6,  "g_specIntensity",      "f32"),
        (7,  "roughContrast",        "f32"),
        (8,  "g_AOcolor",            "color"),
        (9,  "normalIntensity",      "f32"),
        (10, "roughIntens",          "f32"),
        (11, "g_detailMap",          "uv"),
        (12, "exposure",             "f32"),
    ],
    # 0x14 yCh_eyeOv / Eyelash. 1 field.
    0x14: [
        (0, "colorMap@ref", "u64"),
    ],
    # 0x15 yCh_gear. 22 fields.
    0x15: [
        (0,  "variant",          "u8"),
        # 1, 2 unused
        (3,  "standardLit",      "bool"),
        (4,  "clothSheen",       "color"),
        (5,  "clothSheenRough",  "f32"),
        # 6, 7 unused
        (8,  "standardLighting", "bool"),
        (9,  "colorMap@ref",     "u64"),
        (10, "exposure",         "f32"),
        (11, "glow",             "rgba"),   # gear's glow is u8 rgba (not f32!)
        (12, "nrMap@ref",        "u64"),
        (13, "g_mPixMsk@ref",    "u64"),
        (14, "PbrUvScroll",      "uv"),
        (15, "irradiance",       "color"),
        (16, "irradianceMin",    "f32"),
        (17, "microDetail",      "bool"),
        (18, "shadowObjBias",    "f32"),
        (19, "g_specIntensity",  "f32"),
        (20, "teethFresnel",     "f32"),
        (21, "teethWetness",     "f32"),
    ],
    # 0x17 yCh_head. 23 fields.
    0x17: [
        (0,  "detailzoneMap@ref",  "u64"),  # never
        (1,  "colorMap@ref",       "u64"),
        (2,  "facepaint@ref",      "u64"),  # never
        (3,  "g_facepaintNrm@ref", "u64"),  # never
        (4,  "flushMap@ref",       "u64"),  # never
        (5,  "nrMap@ref",          "u64"),
        (6,  "g_mPixMsk@ref",      "u64"),
        (7,  "translucencyMap@ref", "u64"), # never
        (8,  "wrinkleMap@ref",     "u64"),
        (9,  "g_AOcolor",          "color"),
        (10, "bruiseEnable",       "bool"),
        (11, "UseWrinkles",        "bool"),
        (12, "g_detailMap",        "uv"),
        (13, "g_detailStr",        "f32"),
        (14, "g_hzSmooth",         "f32"),
        (15, "g_liquidLevel",      "f32"),
        (16, "g_liquidUVRatio",    "f32"),
        (17, "g_nostrilAO",        "f32"),
        (18, "oilyParam",          "f32"),
        (19, "g_poreColor",        "f32"),
        (20, "g_specIntensity",    "f32"),
        (21, "exposure",           "f32"),
        (22, "glow",               "glow4"),
    ],
    # 0x18 yCh_head / SkinFull. 28 fields.
    0x18: [
        (0,  "colorMap@ref",       "u64"),
        (1,  "detailzoneMap@ref",  "u64"),  # never
        (2,  "facepaint@ref",      "u64"),  # never
        (3,  "g_facepaintNrm@ref", "u64"),  # never
        (4,  "flushMap@ref",       "u64"),  # never
        (5,  "nrMap@ref",          "u64"),
        (6,  "g_mPixMsk@ref",      "u64"),
        (7,  "wrinkleMap@ref",     "u64"),
        (8,  "g_AOcolor",          "color"),
        (9,  "bruiseEnable",       "bool"),
        (10, "UseWrinkles",        "bool"),
        (11, "g_detailMap",        "uv"),
        (12, "g_detailStr",        "f32"),
        (13, "g_hzSmooth",         "f32"),
        (14, "g_liquidLevel",      "f32"),
        (15, "g_liquidUVRatio",    "f32"),
        (16, "g_nostrilAO",        "f32"),
        (17, "oilyParam",          "f32"),
        (18, "g_poreColor",        "f32"),
        (19, "g_specIntensity",    "f32"),
        (20, "eyeLidShadowDarkness",   "f32"),
        (21, "eyeLidShadowFallOff",    "f32"),
        (22, "eyeShadowConeSharpness", "f32"),
        (23, "eyeShadowConeBgLevel",   "f32"),
        (24, "eyeShadowHorizontalFit", "f32"),
        (25, "eyeShadowLidZBias",      "f32"),
        (26, "eyeShadowVerticalBias",  "f32"),
        (27, "eyeShadowVerticalFit",   "f32"),
    ],
    # 0x19 yCh_skin / Normal — body. 19 fields.
    0x19: [
        (0,  "colorMap@ref",       "u64"),
        (1,  "nrMap@ref",          "u64"),
        (2,  "muscleMap@ref",      "u64"),   # never
        (3,  "detailzoneMap@ref",  "u64"),   # never
        (4,  "translucencyMap@ref","u64"),   # never
        (5,  "g_mPixMsk@ref",      "u64"),
        (6,  "g_AOcolor",          "color"),
        (7,  "bruiseEnable",       "bool"),
        (8,  "UseMuscles",         "bool"),
        (9,  "g_detailMap",        "uv"),
        (10, "g_detailStr",        "f32"),
        (11, "g_hzSmooth",         "f32"),
        (12, "g_liquidLevel",      "f32"),
        (13, "g_liquidUVRatio",    "f32"),
        (14, "oilyParam",          "f32"),
        (15, "g_poreColor",        "f32"),
        (16, "g_specIntensity",    "f32"),
        (17, "exposure",           "f32"),
        (18, "glow",               "glow4"),
    ],
    # 0x1A yCh_Teeth. 9 fields.
    0x1A: [
        (0, "colorMap@ref",         "u64"),
        (1, "nrMap@ref",            "u64"),
        (2, "translucencyMap@ref",  "u64"),  # never
        (3, "occlusionMap@ref",     "u64"),  # never
        (4, "g_mPixMsk@ref",        "u64"),  # never
        (5, "g_teethAOFactor",      "f32"),
        (6, "irradiance",           "color"),
        (7, "g_teethWetness",       "f32"),
        (8, "g_wetRoughness",       "f32"),
    ],
    # 0x16 yCh_hair OUTER. 12 fields. (Inner table not harvested in this
    # pass — the two-tier descent + variant dispatch is complex enough that
    # we keep hair to the generic template until a follow-up pass; the
    # invisible-hair fix already handles texture refs.)
    0x16: [
        (0,  "hairType",         "u16"),
        # 1 is uoffset inner — skipped
        (2,  "flowMap@ref",      "u64"),
        (3,  "g_hairAlbedo",     "f32"),
        (4,  "g_mPixMsk@ref",    "u64"),
        (5,  "g_comboMap@ref",   "u64"),
        (6,  "g_rootColor",      "color"),
        (7,  "g_shineBoost",     "f32"),
        (8,  "g_fSpecFresnel",   "f32"),
        (9,  "g_fSpecLevel",     "f32"),
        (10, "g_fSpecRough",     "f32"),
        (11, "g_tipColor",       "color"),
    ],
}


def slot_idx_to_param_key(shader_byte: int, slot_idx: int) -> str | None:
    """Inverse lookup: slot_idx → primary param key the writer expects.

    For child slots (color/uv/glow4/rgba) returns the BASE key — caller is
    expected to expand to ``<base>R/G/B``, ``<base>U/V``, etc. itself; for
    scalar slots returns the exact key.
    """
    spec = _SLOT_TABLE.get(int(shader_byte))
    if not spec:
        return None
    for idx, key, _kind in spec:
        if idx == slot_idx:
            return key
    return None


def _expand_value_to_params(shader_byte: int, slot_idx: int, value):
    """Given a harvested slot value, return ``{param_key: scalar}`` updates.

    Children expand: color → {<base>R, <base>G, <base>B}; uv → {<base>U,
    <base>V}; glow4 → {<base>R, <base>G, <base>B, <base>A}; rgba → same
    keys as glow4 (still 4 components — 0..1 floats either way).
    """
    spec = _SLOT_TABLE.get(int(shader_byte))
    if not spec:
        return {}
    key = None
    kind = None
    for idx, k, kn in spec:
        if idx == slot_idx:
            key, kind = k, kn
            break
    if key is None:
        return {}
    if kind in ("bool", "u8", "u16", "f32"):
        return {key: value}
    if kind == "color":
        if not isinstance(value, (tuple, list)):
            return {}
        if len(value) == 0:
            # Empty-child sentinel — caller has no R/G/B to overlay.
            # The writer's child builder will still emit a present-but-
            # empty child via the policy's always_global path with a
            # default tuple.
            return {}
        if len(value) != 3:
            return {}
        return {f"{key}R": value[0], f"{key}G": value[1], f"{key}B": value[2]}
    if kind == "uv":
        if not isinstance(value, (tuple, list)):
            return {}
        if len(value) == 0:
            return {}
        if len(value) != 2:
            return {}
        return {f"{key}U": value[0], f"{key}V": value[1]}
    if kind in ("glow4", "rgba"):
        if not isinstance(value, (tuple, list)):
            return {}
        if len(value) == 0:
            return {}
        if len(value) != 4:
            return {}
        return {
            f"{key}R": value[0], f"{key}G": value[1],
            f"{key}B": value[2], f"{key}A": value[3],
        }
    # u64 falls through — we never harvest these.
    return {}


# ─── Minimal FlatBuffer reader (independent of jmtl_resolver) ───────────────
#
# We use a local reader so the harvest doesn't depend on the resolver being
# importable in every context (the resolver lives under Blender.Extras and
# the test harness sometimes runs without that subpackage on path). The
# wire format is well-documented; we mirror the resolver's _Fb/_VTable
# semantics exactly.


def _u16(buf, p):
    return struct.unpack_from("<H", buf, p)[0]


def _i32(buf, p):
    return struct.unpack_from("<i", buf, p)[0]


def _u32(buf, p):
    return struct.unpack_from("<I", buf, p)[0]


def _u64(buf, p):
    return struct.unpack_from("<Q", buf, p)[0]


def _f32(buf, p):
    return struct.unpack_from("<f", buf, p)[0]


def _u8(buf, p):
    return buf[p]


def _read_vtable_offsets(buf, table_pos):
    """Return (table_pos, [offsets]) or None on malformed vtable."""
    try:
        n = len(buf)
        if table_pos < 0 or table_pos + 4 > n:
            return None
        soff = _i32(buf, table_pos)
        vp = table_pos - soff
        if vp < 0 or vp + 4 > n:
            return None
        vt_size = _u16(buf, vp)
        tbl_size = _u16(buf, vp + 2)
        if vt_size < 4 or vt_size > 500 or tbl_size > 1000:
            return None
        n_off = (vt_size - 4) // 2
        if vp + 4 + n_off * 2 > n:
            return None
        offsets = list(struct.unpack_from(f"<{n_off}H", buf, vp + 4))
        return offsets
    except Exception:
        return None


def _read_child_color(buf, child_pos):
    """Read a 3×u8 color child → tuple of 3 floats in 0..1 (or partial)."""
    offs = _read_vtable_offsets(buf, child_pos)
    if not offs:
        return None
    out = []
    for i in range(3):
        if i < len(offs) and offs[i] != 0:
            try:
                out.append(_u8(buf, child_pos + offs[i]) / 255.0)
            except Exception:
                out.append(0.0)
        else:
            out.append(0.0)
    return tuple(out)


def _read_child_uv(buf, child_pos):
    """Read a 2×f32 UV child → tuple of 2 floats."""
    offs = _read_vtable_offsets(buf, child_pos)
    if not offs:
        return None
    out = []
    for i in range(2):
        if i < len(offs) and offs[i] != 0:
            try:
                out.append(_f32(buf, child_pos + offs[i]))
            except Exception:
                out.append(0.0)
        else:
            out.append(0.0)
    return tuple(out)


def _read_child_glow4(buf, child_pos):
    """Read a 4×f32 glow child → tuple of 4 floats."""
    offs = _read_vtable_offsets(buf, child_pos)
    if not offs:
        return None
    out = []
    for i in range(4):
        if i < len(offs) and offs[i] != 0:
            try:
                out.append(_f32(buf, child_pos + offs[i]))
            except Exception:
                out.append(0.0)
        else:
            out.append(0.0)
    return tuple(out)


def _read_child_rgba(buf, child_pos):
    """Read a 4×u8 rgba child → tuple of 4 floats in 0..1."""
    offs = _read_vtable_offsets(buf, child_pos)
    if not offs:
        return None
    out = []
    for i in range(4):
        if i < len(offs) and offs[i] != 0:
            try:
                out.append(_u8(buf, child_pos + offs[i]) / 255.0)
            except Exception:
                out.append(0.0)
        else:
            out.append(0.0)
    return tuple(out)


def _parse_jmtl(buf: bytes, *, include_u64: bool = False):
    """Parse a .jmtl payload → (shader_byte, {slot_idx: value}, {slot_idx: u64} | None).

    By default (``include_u64=False``) skips u64 ref slots and returns the
    third tuple element as ``None`` — preserves the legacy behaviour for
    the harvest pass that feeds non-texture overlays.

    When ``include_u64=True``, ALSO harvests u64 texture-ref slots into a
    separate dict (third return value). The harvest's u64 dict is used by
    the per-(shader, slot) classification pass to decide which slots are
    GLOBAL (universal hash across all chars) vs PER-CHARACTER (varies),
    plus to derive the NEVER_POPULATE set empirically.

    We keep u64s in a separate map (rather than commingling with the
    typed values) so the existing ``_expand_value_to_params`` path —
    which expects color/uv tuples or scalars — doesn't have to deal
    with raw hash integers leaking through.

    Returns (None, {}, None) on any structural failure — vanilla harvest
    must NEVER raise; a partial corpus is better than no corpus.
    """
    try:
        if not buf or len(buf) < 8:
            return None, {}, None
        # 'Mate' file identifier at offset 4 — same as jmtl_resolver.
        if buf[4:8] != b"Mate":
            return None, {}, None
        root_pos = _i32(buf, 0)
        root_offs = _read_vtable_offsets(buf, root_pos)
        if not root_offs:
            return None, {}, None
        # Root vtable: slot 1 = u8 shader_byte, slot 2 = uoffset payload.
        if len(root_offs) < 2 or root_offs[1] == 0:
            return None, {}, None
        shader_byte = _u8(buf, root_pos + root_offs[1])
        spec = _SLOT_TABLE.get(shader_byte)
        if spec is None:
            return shader_byte, {}, None
        if len(root_offs) < 3 or root_offs[2] == 0:
            return shader_byte, {}, None
        pay_uoff_pos = root_pos + root_offs[2]
        pay_uoff = _u32(buf, pay_uoff_pos)
        payload_pos = pay_uoff_pos + pay_uoff
        pay_offs = _read_vtable_offsets(buf, payload_pos)
        if not pay_offs:
            return shader_byte, {}, None

        out = {}
        u64_out: dict | None = {} if include_u64 else None
        for slot_idx, _key, kind in spec:
            if slot_idx >= len(pay_offs):
                break
            off = pay_offs[slot_idx]
            if off == 0:
                continue
            field_pos = payload_pos + off
            try:
                if kind == "u64":
                    # u64 ref slots are harvested into a dedicated map
                    # (only when include_u64=True) so the
                    # global-vs-per-character classifier can run later.
                    # Skipped from the typed `out` either way — texture
                    # refs do not flow through _expand_value_to_params.
                    if include_u64:
                        try:
                            u64_out[slot_idx] = int(_u64(buf, field_pos))
                        except Exception:
                            pass
                    continue
                if kind == "bool":
                    val = bool(_u8(buf, field_pos))
                    out[slot_idx] = val
                elif kind == "u8":
                    out[slot_idx] = int(_u8(buf, field_pos))
                elif kind == "u16":
                    out[slot_idx] = int(_u16(buf, field_pos))
                elif kind == "f32":
                    out[slot_idx] = float(_f32(buf, field_pos))
                elif kind == "color":
                    # Child sub-table — follow uoffset. Even when the
                    # child's vtable is empty (vanilla often ships
                    # zero-field glow/clothSheen/PbrUvScroll children
                    # for slot-presence-only signalling), we record an
                    # empty-tuple sentinel so the slot-population
                    # accumulator sees this slot as populated. The
                    # typed-value distribution then can detect that
                    # "always empty" pattern as a global value.
                    child_pos = field_pos + _u32(buf, field_pos)
                    v = _read_child_color(buf, child_pos)
                    if v is None:
                        v = ()  # empty child = present, no content
                    out[slot_idx] = v
                elif kind == "uv":
                    child_pos = field_pos + _u32(buf, field_pos)
                    v = _read_child_uv(buf, child_pos)
                    if v is None:
                        v = ()
                    out[slot_idx] = v
                elif kind == "glow4":
                    child_pos = field_pos + _u32(buf, field_pos)
                    v = _read_child_glow4(buf, child_pos)
                    if v is None:
                        v = ()
                    out[slot_idx] = v
                elif kind == "rgba":
                    child_pos = field_pos + _u32(buf, field_pos)
                    v = _read_child_rgba(buf, child_pos)
                    if v is None:
                        v = ()
                    out[slot_idx] = v
            except Exception:
                # Single bad field → skip; the rest of the .jmtl is still useful.
                continue
        return shader_byte, out, u64_out
    except Exception:
        return None, {}, None


# ─── Index caches ───────────────────────────────────────────────────────────

# Per-character per-shader per-slot → value. Keyed (character_id, shader, slot).
_INDEX_CACHE: dict[tuple[str, int, int], object] | None = None
# Per-shader per-slot fallback (median for numeric, mode for discrete).
_FALLBACK_CACHE: dict[tuple[int, int], object] | None = None
# Sorted list of available character ids (folder names under sample root).
_CHARACTER_LIST: list[str] | None = None
# Index build stats — populated on first build, surfaced by tests/diagnostics.
_INDEX_STATS: dict = {}
# Per (shader, slot) → harvested u64 ref hash if and only if 80%+ of vanilla
# samples agree on the same hash AND we have at least 5 samples. Otherwise
# the key is ABSENT (which signals "per-character — use XXX substitution").
# Populated alongside _INDEX_CACHE on first harvest. None means "not built".
_GLOBAL_HASH_CACHE: dict[tuple[int, int], int] | None = None
# Per shader_byte → set of slot_idx values that NO vanilla sample populates
# at all (zero of N populated). Mirrors and supersedes the orchestrator's
# hand-curated _NEVER_POPULATE_U64 — when the harvest is available, the
# orchestrator should use this empirically-derived set instead.
_NEVER_POPULATE_CACHE: dict[int, set] | None = None
# Per (shader, slot) → (n_with_hash, top_hash, top_count) — diagnostic
# triple kept around so callers can introspect the classifier's decision.
_GLOBAL_HASH_STATS: dict[tuple[int, int], tuple[int, int, int]] | None = None
# Per (shader, slot) → number of files that populated this slot (regardless
# of value-type). Feeds the emission policy's population-fraction calculation.
_SLOT_POPULATION_CACHE: dict[tuple[int, int], int] | None = None
# Per (shader, slot) → Counter of typed values (non-u64 slots only). Used
# by the emission policy to detect "always emit same value" (color/uv/scalar
# slots where every vanilla character ships the same defaults).
_TYPED_VALUE_DIST_CACHE: dict[tuple[int, int], Counter] | None = None
# Per shader_byte → {slot_idx: policy_dict}. Computed lazily on first
# call to get_emission_policy. Populated from the population/value
# distribution caches.
_EMISSION_POLICY_CACHE: dict[int, dict] | None = None

# Tunable thresholds for the global-vs-per-character classifier. Exposed
# as module constants so a follow-up pass (or a unit test) can sweep them.
_GLOBAL_HASH_MIN_FRACTION = 0.80  # >= 80% of samples must agree
_GLOBAL_HASH_MIN_SAMPLES = 5      # don't classify on <5 datapoints
# Tunable thresholds for the EMISSION POLICY classifier (per-slot).
# A slot is "always populated" if its population fraction is >= this.
_EMISSION_ALWAYS_FRACTION = 0.80
# A slot is "always_global" if at least this fraction of POPULATED samples
# carry the exact same typed value (vs. always_per_char where values vary).
_EMISSION_GLOBAL_VALUE_FRACTION = 0.80


def _dlog(msg: str) -> None:
    """Lightweight diagnostic print. Mirrors other modules' debug logging.

    Routed through print() so it shows up in Blender's system console
    without requiring the logging machinery to be configured. The first
    harvest produces one line; everything else is silent.
    """
    print(f"[VanillaBasis] {msg}")


def _harvest_one_jmtl(
    char_id, jmtl_path, per_char, fallback_samples,
    u64_samples=None, file_counts=None,
    slot_population=None, typed_value_dist=None,
):
    """Parse one .jmtl and accumulate its values into the index halves.

    Three accumulators (the last two optional):

      * ``per_char`` and ``fallback_samples`` — typed (non-u64) slot
        values for the AOcolor / detailMap / float / bool overlay.
      * ``u64_samples`` — per (shader, slot) list of harvested u64 hashes
        for the global-vs-per-character classifier. ``None`` to skip the
        u64 harvest entirely (back-compat with callers that only want the
        typed overlay).
      * ``file_counts`` — per shader_byte total file count, so the
        NEVER_POPULATE derivation knows the denominator. Required when
        ``u64_samples`` is provided; ignored otherwise.

    Returns 1 if the file parsed cleanly (added at least a shader byte to
    the file_counts denominator), 0 if the file was unreadable / malformed.
    Returning 1 even for "no slot populated" lets the never-populate
    classifier see the file in its denominator.
    """
    try:
        with open(jmtl_path, "rb") as fh:
            buf = fh.read()
    except OSError:
        return 0  # unreadable — skip silently
    include_u64 = u64_samples is not None
    shader_byte, slots, u64_slots = _parse_jmtl(buf, include_u64=include_u64)
    if shader_byte is None:
        return 0
    # Count even empty parses so NEVER_POPULATE has the right denominator
    # (a shader-byte-only file still tells us "this shader exists in vanilla
    # but populates 0 slots in this sample").
    if file_counts is not None:
        file_counts[shader_byte] = file_counts.get(shader_byte, 0) + 1
    for slot_idx, value in slots.items():
        per_char[(char_id, shader_byte, slot_idx)] = value
        fallback_samples[(shader_byte, slot_idx)].append(value)
        # Population + typed value distribution feed the emission policy
        # classifier. Population is counted once per (shader, slot) per
        # file that populated it; typed_value_dist accumulates a Counter
        # of the actual value (tuples are hashable so colors/UVs work).
        if slot_population is not None:
            slot_population[(shader_byte, slot_idx)] = (
                slot_population.get((shader_byte, slot_idx), 0) + 1
            )
        if typed_value_dist is not None:
            try:
                # Tuples (color/uv/glow/rgba) and primitives are all
                # hashable; bool/int/float go through fine. We round
                # floats to 6 decimals to merge near-identical values
                # (artist rounding noise vs. true distinct defaults).
                if isinstance(value, float):
                    key = round(value, 6)
                elif isinstance(value, tuple):
                    key = tuple(
                        round(x, 6) if isinstance(x, float) else x
                        for x in value
                    )
                else:
                    key = value
                typed_value_dist.setdefault(
                    (shader_byte, slot_idx), Counter()
                )[key] += 1
            except Exception:
                pass
    if include_u64 and u64_slots:
        for slot_idx, u in u64_slots.items():
            # Skip the null sentinel — it represents "no texture bound",
            # which is conceptually different from "this is the global
            # texture". A slot dominated by null sentinels means "the
            # game treats this as optional"; the orchestrator would
            # neither benefit from forcing the null nor learn anything
            # useful by classifying it as global.
            if u == 0 or u == 0xFFFFFFFFFFFFFFFF:
                continue
            u64_samples.setdefault((shader_byte, slot_idx), []).append(u)
            # u64s also count for the slot-population tally so the
            # emission policy sees them.
            if slot_population is not None:
                slot_population[(shader_byte, slot_idx)] = (
                    slot_population.get((shader_byte, slot_idx), 0) + 1
                )
    return 1


def _build_fallback(samples: dict[tuple[int, int], list]) -> dict[tuple[int, int], object]:
    """Reduce per-(shader, slot) value lists to a single representative.

    Strategy:
      * Single-scalar floats → median (robust to outliers).
      * Tuples of floats (color/uv/glow) → per-component median.
      * Discrete (bool/int/u16) → mode (most common value).
    """
    out: dict[tuple[int, int], object] = {}
    for key, values in samples.items():
        if not values:
            continue
        first = values[0]
        try:
            if isinstance(first, bool):
                # bool BEFORE int (bool is a subclass of int in Python).
                # Mode (most common True/False).
                out[key] = Counter(values).most_common(1)[0][0]
            elif isinstance(first, int):
                out[key] = Counter(values).most_common(1)[0][0]
            elif isinstance(first, float):
                out[key] = float(median(values))
            elif isinstance(first, tuple):
                # Empty tuples represent "child slot present but no
                # populated fields" — vanilla often emits these for the
                # body/head glow slots. Fall back to the first non-empty
                # tuple's width so we can still take per-component
                # medians; if every sample is empty, return an empty tuple.
                non_empty = [v for v in values if isinstance(v, tuple) and v]
                if not non_empty:
                    out[key] = ()
                    continue
                n = len(non_empty[0])
                cols = [[] for _ in range(n)]
                for v in non_empty:
                    if len(v) == n:
                        for i, x in enumerate(v):
                            try:
                                cols[i].append(float(x))
                            except (TypeError, ValueError):
                                pass
                if all(cols):
                    out[key] = tuple(float(median(c)) for c in cols)
            else:
                out[key] = first
        except Exception:
            # Statistical reduction failed — fall back to first sampled value.
            out[key] = first
    return out


def _build_global_hash_index(
    u64_samples: dict, file_counts: dict
) -> tuple[dict, dict, dict]:
    """Classify each (shader, slot) as GLOBAL or PER-CHARACTER from harvested u64s.

    Returns three dicts:

      * ``global_hash`` — per (shader, slot) → u64 hash IFF the most-common
        non-null hash represents ≥ ``_GLOBAL_HASH_MIN_FRACTION`` of samples
        AND we have ≥ ``_GLOBAL_HASH_MIN_SAMPLES`` populated samples for
        this (shader, slot). Otherwise the key is absent — the orchestrator
        then falls back to XXX substitution for per-character textures.
      * ``never_populate`` — per shader_byte → set of slot indices that
        NO vanilla sample populates (0 of the file_counts[shader] samples
        had a non-null u64 for this slot). The orchestrator strips these
        belt-and-suspenders, mirroring the writer's NEVER_POPULATE guard.
      * ``stats`` — diagnostic per (shader, slot) → (n_with_hash,
        top_hash, top_count) for printing the classification table.

    The classifier intentionally ONLY considers slots from ``_SLOT_TABLE``
    — that's the universe of slots the orchestrator can act on. A slot
    not in the spec is invisible to the rest of the pipeline.
    """
    global_hash: dict[tuple[int, int], int] = {}
    never_populate: dict[int, set] = {}
    stats: dict[tuple[int, int], tuple[int, int, int]] = {}

    # Collect every (shader, u64_slot) we know about from the spec so the
    # NEVER_POPULATE derivation also covers slots that ZERO files populated.
    expected: dict[int, list[int]] = {}
    for shader_byte, spec in _SLOT_TABLE.items():
        u64_indices = [idx for idx, _k, kind in spec if kind == "u64"]
        if u64_indices:
            expected[shader_byte] = u64_indices

    for shader_byte, slot_indices in expected.items():
        n_files = file_counts.get(shader_byte, 0)
        per_shader_never: set = set()
        for slot_idx in slot_indices:
            samples = u64_samples.get((shader_byte, slot_idx), [])
            n_with_hash = len(samples)
            # NEVER_POPULATE: zero non-null hashes across ALL files of this
            # shader. We need at least a few files of the shader to make
            # this assertion meaningful — a shader with 0 vanilla files
            # would otherwise classify every slot as never-populate, which
            # is misleading rather than informative.
            if n_files >= _GLOBAL_HASH_MIN_SAMPLES and n_with_hash == 0:
                per_shader_never.add(slot_idx)
                stats[(shader_byte, slot_idx)] = (0, 0, 0)
                continue
            if n_with_hash < _GLOBAL_HASH_MIN_SAMPLES:
                # Too few samples to classify either way; the orchestrator
                # falls through to its existing XXX path.
                if n_with_hash:
                    top_hash, top_count = Counter(samples).most_common(1)[0]
                    stats[(shader_byte, slot_idx)] = (n_with_hash, top_hash, top_count)
                continue
            top_hash, top_count = Counter(samples).most_common(1)[0]
            stats[(shader_byte, slot_idx)] = (n_with_hash, top_hash, top_count)
            fraction = top_count / float(n_with_hash)
            if fraction >= _GLOBAL_HASH_MIN_FRACTION:
                global_hash[(shader_byte, slot_idx)] = top_hash
        if per_shader_never:
            never_populate[shader_byte] = per_shader_never
    return global_hash, never_populate, stats


def _ensure_indexed() -> None:
    """Build the index if not already built. Idempotent and lazy."""
    global _INDEX_CACHE, _FALLBACK_CACHE, _CHARACTER_LIST, _INDEX_STATS
    global _GLOBAL_HASH_CACHE, _NEVER_POPULATE_CACHE, _GLOBAL_HASH_STATS
    global _SLOT_POPULATION_CACHE, _TYPED_VALUE_DIST_CACHE
    global _EMISSION_POLICY_CACHE
    if _INDEX_CACHE is not None:
        return

    sample_root = _get_sample_root()
    per_char: dict[tuple[str, int, int], object] = {}
    fallback_samples: dict[tuple[int, int], list] = defaultdict(list)
    # u64 samples and per-shader file counts feed the global-vs-per-char
    # classifier. We collect them in the same pass to keep the harvest
    # to a single disk walk.
    u64_samples: dict[tuple[int, int], list[int]] = {}
    file_counts: dict[int, int] = {}
    # Per-slot population + typed value distribution feed the emission
    # policy classifier. slot_population counts how many of file_counts[shader]
    # populated each slot; typed_value_dist tracks the actual value
    # distribution for non-u64 slots (so we can detect "always same value"
    # vs "always varies").
    slot_population: dict[tuple[int, int], int] = {}
    typed_value_dist: dict[tuple[int, int], Counter] = {}
    chars: list[str] = []
    n_jmtls = 0
    t0 = time.time()

    try:
        char_dirs = sorted(
            d for d in os.listdir(sample_root)
            if os.path.isdir(os.path.join(sample_root, d))
        )
    except OSError:
        # Sample root missing — install an empty index so subsequent calls
        # are still O(1) and return {}. Common in CI / fresh installs.
        _INDEX_CACHE = {}
        _FALLBACK_CACHE = {}
        _CHARACTER_LIST = []
        _GLOBAL_HASH_CACHE = {}
        _NEVER_POPULATE_CACHE = {}
        _GLOBAL_HASH_STATS = {}
        _SLOT_POPULATION_CACHE = {}
        _TYPED_VALUE_DIST_CACHE = {}
        _EMISSION_POLICY_CACHE = {}
        _INDEX_STATS = {
            "n_chars": 0, "n_jmtls": 0, "elapsed": 0.0,
            "sample_root": sample_root, "available": False,
        }
        _dlog(f"sample root not present: {sample_root!r}; index is empty")
        return

    for char_dir in char_dirs:
        char_path = os.path.join(sample_root, char_dir)
        # Each character folder contains scope subdirs (BaseModel, *_Attire),
        # each with a Materials/ subdir of .jmtls.
        had_any = False
        try:
            scope_dirs = os.listdir(char_path)
        except OSError:
            continue
        for scope in scope_dirs:
            mats_dir = os.path.join(char_path, scope, "Materials")
            if not os.path.isdir(mats_dir):
                continue
            try:
                entries = os.listdir(mats_dir)
            except OSError:
                continue
            for fname in entries:
                if not fname.endswith(".jmtl"):
                    continue
                jpath = os.path.join(mats_dir, fname)
                n_jmtls += _harvest_one_jmtl(
                    char_dir, jpath, per_char, fallback_samples,
                    u64_samples=u64_samples, file_counts=file_counts,
                    slot_population=slot_population,
                    typed_value_dist=typed_value_dist,
                )
                had_any = True
        if had_any:
            chars.append(char_dir)

    _FALLBACK_CACHE = _build_fallback(fallback_samples)
    _INDEX_CACHE = per_char
    _CHARACTER_LIST = chars

    # Run the u64 classifier on the aggregated samples — produces the
    # global-hash dict the orchestrator uses to short-circuit XXX
    # substitution for universal textures (teeth's colorMap, etc.) and
    # the NEVER_POPULATE map the orchestrator strips belt-and-suspenders.
    gh, np_, ghstats = _build_global_hash_index(u64_samples, file_counts)
    _GLOBAL_HASH_CACHE = gh
    _NEVER_POPULATE_CACHE = np_
    _GLOBAL_HASH_STATS = ghstats
    _SLOT_POPULATION_CACHE = slot_population
    _TYPED_VALUE_DIST_CACHE = typed_value_dist
    # Emission policies are computed lazily on first get_emission_policy call
    # to keep first-harvest cost low. Initialize the cache so callers can
    # check "have we built any policies yet" with `is None`.
    _EMISSION_POLICY_CACHE = {}

    elapsed = time.time() - t0
    _INDEX_STATS = {
        "n_chars": len(chars),
        "n_jmtls": n_jmtls,
        "elapsed": elapsed,
        "sample_root": sample_root,
        "available": True,
        "n_fallback_keys": len(_FALLBACK_CACHE),
        "n_index_entries": len(_INDEX_CACHE),
        "n_global_hashes": len(_GLOBAL_HASH_CACHE),
        "n_never_populate_shaders": len(_NEVER_POPULATE_CACHE),
        "file_counts": dict(file_counts),
    }
    _dlog(
        f"indexed {len(chars)} characters / {n_jmtls} jmtls "
        f"({len(_INDEX_CACHE)} slot values, {len(_FALLBACK_CACHE)} fallback "
        f"keys, {len(_GLOBAL_HASH_CACHE)} global-hash slots) in {elapsed:.2f}s"
    )


# ─── Fuzzy match ────────────────────────────────────────────────────────────

# Stem extraction: strip leading "<digits>_" id prefix and trailing
# "_<4digit year>" tag. ``358_Triple_H_2018`` → ``Triple_H``. ``1025_Cody_Rhodes``
# → ``Cody_Rhodes``. Conservative — if the input doesn't match, we return
# the input unchanged.
_LEADING_ID = re.compile(r"^\d+_")
_TRAILING_YEAR = re.compile(r"_\d{4}$")
_LEADING_ID_CAPTURE = re.compile(r"^(\d+)_(.*)$")


def _extract_id_and_stem(character_id: str) -> tuple[int | None, str]:
    """Return (numeric_id, stem). numeric_id None if no leading digits."""
    if not character_id:
        return None, ""
    m = _LEADING_ID_CAPTURE.match(character_id)
    if m:
        try:
            nid = int(m.group(1))
        except ValueError:
            nid = None
        rest = m.group(2)
    else:
        nid = None
        rest = character_id
    rest = _TRAILING_YEAR.sub("", rest)
    return nid, rest


def _fuzzy_candidates(character_id: str, available: list[str]) -> list[str]:
    """Return available character ids that share the stripped stem.

    Sorted by:
      1. numeric-id proximity (smaller |a.id - b.id| first), then
      2. alphabetical (stable tiebreaker).

    Empty list if no other character shares the stem.
    """
    target_id, target_stem = _extract_id_and_stem(character_id)
    if not target_stem:
        return []
    stem_lower = target_stem.lower()

    def score(cand):
        cid, _ = _extract_id_and_stem(cand)
        if cid is None or target_id is None:
            return (10**9, cand.lower())
        return (abs(cid - target_id), cand.lower())

    matches = []
    for cand in available:
        if cand == character_id:
            continue
        _cid, cstem = _extract_id_and_stem(cand)
        if cstem.lower() == stem_lower:
            matches.append(cand)
        elif stem_lower in cand.lower():
            # Looser substring match — caught e.g. ``Triple_H_2018`` against
            # an oddly-named ``X_Triple_H_Special`` folder. Still scored
            # by id distance.
            matches.append(cand)
    matches.sort(key=score)
    return matches


# ─── Public API ─────────────────────────────────────────────────────────────


def get_vanilla_basis(character_id: str, shader_byte: int) -> dict:
    """Return ``{param_key: value}`` of vanilla-harvested params for this character + shader.

    Lookup order:
      1. Exact character match — folder name == ``character_id``.
      2. Fuzzy match — same stem (Triple_H → 102_Triple_H_2019).
         Best numeric-id-distance wins.
      3. Fallback — median (floats) / mode (discrete) across all sampled
         characters for this shader.

    Empty dict if no data is available (degraded sample root, unknown
    shader, etc.). The caller (material_export.write_materials_for_export)
    falls through to the generic template in that case.

    Returns a dict of FLAT param keys (``g_AOcolorR``, ``g_specIntensity``,
    ``g_detailMapU``, …) — the same keys the writer's per-shader functions
    look up. Child sub-tables are expanded so the orchestrator never has
    to know about color/uv/glow tuples; it just does
    ``params[key] = vanilla_value``.
    """
    _ensure_indexed()
    spec = _SLOT_TABLE.get(int(shader_byte))
    if not spec:
        return {}

    # Stage 1: exact character match.
    if _INDEX_CACHE:
        slots_for_char = {
            (s, i): v for (c, s, i), v in _INDEX_CACHE.items()
            if c == character_id and s == shader_byte
        }
        if slots_for_char:
            return _slots_to_param_dict(shader_byte, slots_for_char)

    # Stage 2: fuzzy.
    if _CHARACTER_LIST:
        for cand in _fuzzy_candidates(character_id, _CHARACTER_LIST):
            slots_for_cand = {
                (s, i): v for (c, s, i), v in _INDEX_CACHE.items()
                if c == cand and s == shader_byte
            }
            if slots_for_cand:
                return _slots_to_param_dict(shader_byte, slots_for_cand)

    # Stage 3: fallback (median/mode across all samples).
    if _FALLBACK_CACHE:
        fallback_slots = {
            (shader_byte, i): v for (s, i), v in _FALLBACK_CACHE.items()
            if s == shader_byte
        }
        if fallback_slots:
            return _slots_to_param_dict(shader_byte, fallback_slots)

    return {}


def _slots_to_param_dict(shader_byte: int, slots: dict) -> dict:
    """Expand a ``{(shader, slot_idx): value}`` map into flat param keys.

    Slot tuples come in either as ``(s, i)`` (fallback case) or just as
    ``(s, i)`` after the comprehension above — we accept any 2-tuple
    whose first element is the shader byte and second is the slot index.
    """
    out = {}
    for key, value in slots.items():
        # Normalize key — both lookup paths produce (shader, slot_idx).
        slot_idx = key[1]
        updates = _expand_value_to_params(shader_byte, slot_idx, value)
        out.update(updates)
    return out


def get_vanilla_basis_raw(character_id: str, shader_byte: int) -> tuple[dict, str]:
    """Diagnostic variant: return (params, tier) where tier is which lookup hit.

    ``tier`` is one of ``"exact"``, ``"fuzzy:<matched_id>"``, ``"fallback"``,
    or ``"none"``. Used by the test suite to verify the three-stage cascade
    works as documented.
    """
    _ensure_indexed()
    spec = _SLOT_TABLE.get(int(shader_byte))
    if not spec:
        return {}, "none"

    if _INDEX_CACHE:
        slots_for_char = {
            (s, i): v for (c, s, i), v in _INDEX_CACHE.items()
            if c == character_id and s == shader_byte
        }
        if slots_for_char:
            return _slots_to_param_dict(shader_byte, slots_for_char), "exact"

    if _CHARACTER_LIST:
        for cand in _fuzzy_candidates(character_id, _CHARACTER_LIST):
            slots_for_cand = {
                (s, i): v for (c, s, i), v in _INDEX_CACHE.items()
                if c == cand and s == shader_byte
            }
            if slots_for_cand:
                return (
                    _slots_to_param_dict(shader_byte, slots_for_cand),
                    f"fuzzy:{cand}",
                )

    if _FALLBACK_CACHE:
        fallback_slots = {
            (shader_byte, i): v for (s, i), v in _FALLBACK_CACHE.items()
            if s == shader_byte
        }
        if fallback_slots:
            return (
                _slots_to_param_dict(shader_byte, fallback_slots),
                "fallback",
            )

    return {}, "none"


def list_available_characters() -> list[str]:
    """Return the list of character ids the index successfully harvested."""
    _ensure_indexed()
    return list(_CHARACTER_LIST or [])


def index_stats() -> dict:
    """Return last-build stats (counts, elapsed seconds, sample root used)."""
    _ensure_indexed()
    return dict(_INDEX_STATS)


def clear_cache() -> None:
    """Drop all cached state. Next lookup re-harvests from disk.

    Tests call this to force a re-index against a different sample root
    (set ``WWE2K_MDL_VANILLA_SAMPLES`` env var, then ``clear_cache()``).
    """
    global _INDEX_CACHE, _FALLBACK_CACHE, _CHARACTER_LIST, _INDEX_STATS
    global _GLOBAL_HASH_CACHE, _NEVER_POPULATE_CACHE, _GLOBAL_HASH_STATS
    global _SLOT_POPULATION_CACHE, _TYPED_VALUE_DIST_CACHE
    global _EMISSION_POLICY_CACHE
    _INDEX_CACHE = None
    _FALLBACK_CACHE = None
    _CHARACTER_LIST = None
    _INDEX_STATS = {}
    _GLOBAL_HASH_CACHE = None
    _NEVER_POPULATE_CACHE = None
    _GLOBAL_HASH_STATS = None
    _SLOT_POPULATION_CACHE = None
    _TYPED_VALUE_DIST_CACHE = None
    _EMISSION_POLICY_CACHE = None


# ─── Global-hash & never-populate APIs ──────────────────────────────────────


_STATIC_GLOBAL_TEXTURE_HASHES = {
    (0x12, 3): 0xEFBC052176B84E95,  # eye normal
    (0x1A, 0): 0x7357EEB9075DF170,  # teeth color
    (0x1A, 1): 0xBA65216DD64F5C78,  # teeth normal
}


def get_global_texture_hash(shader_byte: int, slot_idx: int) -> int | None:
    """Return a globally-shared texture hash if this (shader, slot) uses one
    universally across vanilla characters. Returns ``None`` if the slot is
    per-character (caller should use XXX substitution instead).

    "Universally" means: in the harvested vanilla corpus, at least
    ``_GLOBAL_HASH_MIN_FRACTION`` (default 80%) of populated samples for
    this (shader, slot) carry the SAME u64 hash, AND we have at least
    ``_GLOBAL_HASH_MIN_SAMPLES`` (default 5) populated samples to draw
    that conclusion from.

    The canonical motivating case is the teeth shader (0x1A) where every
    vanilla character ships colorMap@ref = 0x7357EEB9075DF170 and
    nrMap@ref = 0xBA65216DD64F5C78 — the engine uses a single shared
    teeth texture pair for every wrestler. The orchestrator's XXX
    substitution would compute a per-character hash like
    ``FNV("Characters/<char>/<scope>/Textures/teeth_color.tex")`` that
    points at nothing the engine packs.

    Returns the harvested u64 hash on match, ``None`` on miss. Safe to
    call when sample corpus is unavailable (returns ``None`` then too).
    """
    _ensure_indexed()
    key = (int(shader_byte), int(slot_idx))
    if _GLOBAL_HASH_CACHE is not None:
        harvested = _GLOBAL_HASH_CACHE.get(key)
        if harvested is not None:
            return harvested
    file_counts = _INDEX_STATS.get("file_counts") or {}
    has_samples = sum(int(v) for v in file_counts.values()) > 0
    if not _INDEX_STATS.get("available", False) or not has_samples:
        return _STATIC_GLOBAL_TEXTURE_HASHES.get(key)
    return None


def get_never_populate(shader_byte: int) -> set:
    """Return the empirically-derived NEVER_POPULATE u64 slot set for a shader.

    A slot is "never populated" iff ZERO vanilla samples populate it with
    a non-null hash (the null sentinel 0xFFFFFFFFFFFFFFFF is treated as
    "not populated" for this purpose, matching writer semantics) AND
    we have at least ``_GLOBAL_HASH_MIN_SAMPLES`` files of that shader
    to draw the conclusion from.

    Returns a NEW set on each call (caller-mutation safe). Empty set
    when no vanilla data is available — the orchestrator should fall
    through to its own hand-curated table in that case, which mirrors
    the writer's ``_NEVER_POPULATE_U64``.

    This is the empirical complement of the writer's hardcoded
    ``_NEVER_POPULATE_U64`` — once both are populated we expect them to
    agree on the major culprits (body/head/eye/teeth) and may diverge
    on shaders the writer hasn't covered yet (caruncle, skinFull). The
    orchestrator unions them, so any new discovery on the data side
    automatically protects the writer.
    """
    _ensure_indexed()
    if _NEVER_POPULATE_CACHE is None:
        return set()
    return set(_NEVER_POPULATE_CACHE.get(int(shader_byte), set()))


def slot_to_param_keys(shader_byte: int, slot_idx: int) -> list[str]:
    """Return all known param keys that resolve to a given (shader, slot).

    Canonical key first (the one the writer's runtime expects per the
    2K26 reader naming), legacy alias(es) second. Used by the orchestrator
    to inject a harvested global hash under the correct key so the writer
    picks it up — and to detect user overrides ("did the user already set
    THIS slot under ANY of its known names?").

    Mirrors ``jmtl_writer._LEGACY_FIELD_ALIASES`` for the keys we know
    about. Kept here (not imported) to avoid a circular import — the
    writer doesn't depend on vanilla_basis and we don't want to flip
    that.

    Empty list when the shader / slot is unknown.
    """
    spec = _SLOT_TABLE.get(int(shader_byte))
    if not spec:
        return []
    canonical = None
    for idx, key, _kind in spec:
        if idx == int(slot_idx):
            canonical = key
            break
    if canonical is None:
        return []
    # Aliases: must stay in sync with jmtl_writer._LEGACY_FIELD_ALIASES.
    # We hard-code the small known set rather than importing the writer
    # to avoid the (currently nonexistent) circular dep. Add entries
    # here when the writer adds an alias.
    aliases_for_canonical = {
        "nrMap@ref":    ["g_nrmMap@ref"],     # head 0x17, skin 0x19,
                                              # skinFull 0x18, teeth 0x1A
        "colorMap@ref": ["g_mEyeOvlPrm@ref"], # eyelash 0x14
    }
    out = [canonical]
    out.extend(aliases_for_canonical.get(canonical, []))
    return out


def global_hash_stats() -> dict:
    """Diagnostic: return the raw (n_with_hash, top_hash, top_count) per
    (shader, slot) tuple. Used by the per-shader classification table
    printer in tests / docs. Empty dict before first harvest.
    """
    _ensure_indexed()
    return dict(_GLOBAL_HASH_STATS or {})


# ─── Emission policy (the data-driven writer's source of truth) ────────────
#
# The writer rewrite (jmtl_writer.py, 2026-05) replaces hand-curated
# per-slot "required/never_populate/engine_default" tables with a single
# emission policy derived from the vanilla corpus. For each (shader_byte,
# slot_idx), the policy answers: "should we ALWAYS emit this slot, only
# emit it when the caller provides a value, or never emit it?"
#
# Classification rules (per slot):
#
#   never           — 0% of vanilla samples populate this slot. Skip the
#                     Prepend* call entirely.
#   always_global   — ≥80% of populated samples carry the SAME value
#                     (u64: same hash; scalar/color/uv/glow: same numeric).
#                     Emit that value as the engine default.
#   always_per_char — ≥80% populate this slot but with DIFFERENT values.
#                     Emit the caller-supplied value or, for u64 slots, the
#                     null sentinel so the runtime engages its template
#                     default; for scalar slots, fall back to the FB-side
#                     default.
#   sometimes       — <80% populate. Emit ONLY when the caller provides a
#                     value; otherwise skip the slot.
#
# These thresholds are derived from the visible vanilla shipping behaviour
# — teeth's slot 6 (irradiance child) is populated by 100% of samples with
# the same RGB tint, so it's always_global; gear's slot 9 (colorMap@ref)
# is populated by ~99% of samples but with different per-character hashes,
# so it's always_per_char. The 80% threshold gives wiggle room for the
# odd corrupted sample without misclassifying.
#
# The policy is cached per-shader on first access; subsequent calls are
# O(1) dict lookups. Cache invalidation tracks the index lifecycle.


def _classify_policy_value_type(shader_byte: int, slot_idx: int) -> str:
    """Map a (shader, slot) to a coarse value type for the writer.

    Returns one of "u64", "f32", "color", "uv", "glow4", "rgba", "bool",
    "u8", "u16", or "unknown" — the writer picks the right Prepend*
    based on this.
    """
    spec = _SLOT_TABLE.get(int(shader_byte))
    if not spec:
        return "unknown"
    for idx, _key, kind in spec:
        if idx == slot_idx:
            return kind
    return "unknown"


def _build_emission_policy(shader_byte: int) -> dict:
    """Compute the per-slot emission policy for one shader.

    Returns ``{slot_idx: {"rule": ..., "global_value": ..., "value_type": ...,
    "sample_count": int, "total_samples": int}}`` for every slot in the
    shader's _SLOT_TABLE spec. Slots NOT in the spec (gaps / unused) are
    omitted from the result.

    Empty dict if the harvest is unavailable or the shader has no spec.
    """
    spec = _SLOT_TABLE.get(int(shader_byte))
    if not spec:
        return {}
    total = 0
    if _INDEX_STATS.get("file_counts"):
        total = int(_INDEX_STATS["file_counts"].get(int(shader_byte), 0))
    if total <= 0:
        return {}
    pop = _SLOT_POPULATION_CACHE or {}
    typed_dist = _TYPED_VALUE_DIST_CACHE or {}
    out: dict[int, dict] = {}
    for slot_idx, key, kind in spec:
        sample_count = int(pop.get((int(shader_byte), slot_idx), 0))
        entry = {
            "rule": "sometimes",
            "global_value": None,
            "value_type": kind,
            "sample_count": sample_count,
            "total_samples": total,
            "canonical_key": key,
        }
        # If we have zero population samples and we ALSO have enough files
        # of this shader to trust the count, classify as never.
        if total >= _GLOBAL_HASH_MIN_SAMPLES and sample_count == 0:
            entry["rule"] = "never"
            out[slot_idx] = entry
            continue
        # If population fraction crosses the always-emit threshold, decide
        # global vs per-char by value-distribution agreement.
        if total > 0 and sample_count / total >= _EMISSION_ALWAYS_FRACTION:
            if kind == "u64":
                # Reuse the existing global-hash classifier — it already
                # applies the 80%/5-sample thresholds.
                gh = (_GLOBAL_HASH_CACHE or {}).get(
                    (int(shader_byte), slot_idx)
                )
                if gh is not None:
                    entry["rule"] = "always_global"
                    entry["global_value"] = int(gh)
                else:
                    entry["rule"] = "always_per_char"
            else:
                # Typed slot: count value distribution.
                dist = typed_dist.get((int(shader_byte), slot_idx))
                if dist and sample_count >= _GLOBAL_HASH_MIN_SAMPLES:
                    top_value, top_count = dist.most_common(1)[0]
                    fraction = top_count / float(sample_count)
                    if fraction >= _EMISSION_GLOBAL_VALUE_FRACTION:
                        entry["rule"] = "always_global"
                        entry["global_value"] = top_value
                    else:
                        entry["rule"] = "always_per_char"
                else:
                    # Not enough samples to call the value distribution —
                    # classify as always_per_char so the writer at least
                    # emits the slot when params is populated.
                    entry["rule"] = "always_per_char"
        # Else leaves rule="sometimes".
        out[slot_idx] = entry
    return out


def get_emission_policy(shader_byte: int) -> dict[int, dict]:
    """Return per-slot emission policy derived from the vanilla corpus.

    Returns a dict ``{slot_idx: policy_dict}`` where each ``policy_dict``
    contains:

      * ``rule`` — one of:
          - ``"always_global"``: ≥80% of populated samples agree on a
            single value. Emit ``global_value`` unconditionally.
          - ``"always_per_char"``: ≥80% of samples populate this slot but
            values vary. Emit caller-supplied value or null sentinel/FB
            default.
          - ``"sometimes"``: <80% of samples populate this slot. Emit
            ONLY when caller provides a non-null value.
          - ``"never"``: 0 of N samples populate. Skip the slot entirely.
      * ``global_value`` — for ``always_global``, the value to emit.
        ``None`` otherwise.
      * ``value_type`` — coarse kind ("u64", "f32", "color", "uv", "glow4",
        "rgba", "bool", "u8", "u16") so the writer picks the right
        Prepend* call.
      * ``sample_count`` — number of vanilla samples that populated this
        slot (out of ``total_samples``).
      * ``total_samples`` — total vanilla samples seen for this shader.
      * ``canonical_key`` — the modern (2K26) param key the writer
        expects in ``params`` for this slot.

    Slots not present in the shader's spec are omitted from the result.
    Empty dict if the harvest is unavailable (degraded sample root).

    Result is cached per-shader; subsequent calls are O(1) dict lookups.
    """
    global _EMISSION_POLICY_CACHE
    _ensure_indexed()
    if _EMISSION_POLICY_CACHE is None:
        _EMISSION_POLICY_CACHE = {}
    sb = int(shader_byte)
    if sb not in _EMISSION_POLICY_CACHE:
        _EMISSION_POLICY_CACHE[sb] = _build_emission_policy(sb)
    return _EMISSION_POLICY_CACHE[sb]


def emission_policy_summary(shader_byte: int) -> str:
    """Render a one-line-per-slot summary of the emission policy.

    Useful for diagnostic prints in tests / docs. Example:

        0x1A yCh_Teeth:
          slot 0 colorMap@ref         u64    always_global  953/953 (0x7357EEB9...)
          slot 1 nrMap@ref            u64    always_global  953/953 (0xBA65216D...)
          slot 6 irradiance           color  always_global  953/953 (0.7,0.5,0.4)
          slot 5 g_teethAOFactor      f32    sometimes        12/953
          slot 7 g_teethWetness       f32    sometimes        15/953
          ...

    Returns empty string if no policy could be derived.
    """
    pol = get_emission_policy(shader_byte)
    if not pol:
        return f"0x{int(shader_byte):02X}: (no policy — corpus unavailable)"
    lines = [f"0x{int(shader_byte):02X}:"]
    for slot_idx in sorted(pol.keys()):
        e = pol[slot_idx]
        rule = e["rule"]
        key = e["canonical_key"]
        kind = e["value_type"]
        n = e["sample_count"]
        N = e["total_samples"]
        if rule == "always_global" and e["global_value"] is not None:
            gv = e["global_value"]
            if isinstance(gv, int) and kind == "u64":
                tail = f" (0x{gv:016X})"
            else:
                tail = f" ({gv})"
        else:
            tail = ""
        lines.append(
            f"  slot {slot_idx:2d} {key:24s} {kind:6s} {rule:16s} {n}/{N}{tail}"
        )
    return "\n".join(lines)
