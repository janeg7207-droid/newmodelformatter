from ..Link.wrapper import cmesh, cmodellib
import os
import struct
import ctypes
from ..Link.log import dlog, derror


def _read_ctg_envelope_from_mcd(mcd_path):
    """Extract the CTG sub-stream from a 2K26 source MCD file.

    Returns the envelope as bytes ready to pass to replaceOrAddSubStreamByTag,
    or None when the source has no embedded CTG (e.g. a 2K25 source where
    CTG lives as a .ctg sidecar — that path is handled by
    companion_upgrade.py instead).

    Why file-side instead of via the loaded source cmodel:
      The DLL parses its own sub-stream blobs internally and
      getRawSubStreamData's exact return-format wrt envelope vs.
      content-only is something we'd have to determine empirically to
      use reliably. Reading the bytes straight off disk is unambiguous —
      we know the on-wire MCD container layout, we know the envelope
      shape (4-byte size, 4-byte outer tag, size bytes of content),
      and replaceOrAddSubStreamByTag accepts that envelope verbatim.

    MCD container walk:
      [0..3]  magic 'MCD!'
      [4..7]  u32 version
      [8..]   sub-streams, each:
                [4 bytes] u32 size = byte length of (inner_tag + content)
                [4 bytes] outer tag (e.g. CTG!, MDL!, GtPt — varies)
                [size bytes] content, starts with the inner tag
              Sub-streams are 4-byte aligned between each other.

    The envelope we return is the full (size_field + outer_tag + content)
    span, identical to how companion_upgrade.py and physics_swap build
    blobs from sidecar files. Empirically verified against the BaseModel
    reference MCD (CTG envelope at offset 0x08, total 0x13e8e bytes).
    """
    try:
        with open(mcd_path, 'rb') as f:
            data = f.read()
    except OSError:
        return None

    if len(data) < 12 or data[:4] != b'MCD!':
        return None

    pos = 8
    while pos + 8 <= len(data):
        size = struct.unpack_from('<I', data, pos)[0]
        # Defensive size sanity-check — anything outside this range is
        # either a stray u32 read mid-padding or a corrupt header. Either
        # way we bail rather than slice past the end of the buffer.
        if size == 0 or size > 100_000_000:
            return None

        tag = data[pos + 4: pos + 8]
        if tag == b'CTG!':
            envelope_end = pos + 8 + size
            if envelope_end > len(data):
                return None
            return data[pos:envelope_end]

        # Advance to the next sub-stream. Total bytes consumed by this
        # sub-stream = size_field (4) + outer_tag (4) + content (size).
        pos += 8 + size
        # 4-byte alignment between sub-streams
        while pos % 4 != 0:
            pos += 1

    return None


def _parse_text_block(data):
    """Parse a TEXT sub-stream's string table.
    
    Layout: [TEXT(4)][size(4)][count(4)][offsets(4×count)][string buffer]
    Each offset in the offsets table is a byte position into the string
    buffer where a null-terminated string starts.
    
    Returns a list of strings indexed by string-table position, or None
    if the file has no TEXT block or the layout is malformed.
    """
    i = data.find(b'TEXT')
    if i < 0:
        return None
    try:
        size = struct.unpack_from('<I', data, i+4)[0]
        count = struct.unpack_from('<I', data, i+8)[0]
    except struct.error:
        return None
    offsets_start = i + 12
    buf_start = offsets_start + count * 4
    block_end = i + 8 + size
    if buf_start > len(data) or block_end > len(data) or buf_start > block_end:
        return None
    string_buf = data[buf_start:block_end]
    strings = []
    for k in range(count):
        off = struct.unpack_from('<I', data, offsets_start + k*4)[0]
        if 0 <= off < len(string_buf):
            end = string_buf.find(b'\x00', off)
            if end < 0:
                end = len(string_buf)
            strings.append(string_buf[off:end].decode('latin-1', errors='replace'))
        else:
            strings.append('')
    return strings


def _build_gtpt_records_for_dest(source_path, saved_path):
    """Semantically remap source's GtPt records to dest's layout.

    GtPt records are 4×int16 tuples (name_id, group_id, ordinal,
    vertex_index) where name_id and group_id are string-table indices
    and vertex_index is into the mesh referenced by group_id. Source's
    integer values are stale relative to dest's regenerated string table
    and Blender's possibly-reordered mesh vertices, so a byte-passthrough
    re-introduces the dark-eye bug.

    Resolution per field:
      name_id, group_id  — translate via source_strs[idx] → dest_strs.index(name)
      ordinal            — passthrough (slot ordering is character-independent)
      vertex_index       — DLL-load both models, get source's vertex
                           world position, find nearest vertex in dest's
                           same-named mesh, use that index

    Returns (records_bytes, log_lines). The records_bytes is None on
    fatal failure (no TEXT block, no GtPt in source, IO error). On
    per-record issues (mesh missing from one side, OOB index, DLL-load
    failure) the record falls back to source values so the engine has
    the right record count.
    """
    log = []
    try:
        with open(source_path, 'rb') as f:
            src_bytes = f.read()
        with open(saved_path, 'rb') as f:
            dst_bytes = f.read()
    except OSError as e:
        return None, [f'IO error: {e}']

    src_strs = _parse_text_block(src_bytes)
    dst_strs = _parse_text_block(dst_bytes)
    if src_strs is None or dst_strs is None:
        return None, ['missing TEXT block']

    src_gp = src_bytes.find(b'GtPt')
    if src_gp < 0:
        return None, ['source has no GtPt block']
    try:
        n = struct.unpack_from('<I', src_bytes, src_gp + 8)[0]
    except struct.error:
        return None, ['source GtPt count read failed']

    dst_str_lookup = {s: i for i, s in enumerate(dst_strs)}

    # Load both models via DLL for vertex data. Wrapped in try/finally so
    # the file handles always get released even on error paths.
    from ..Link.wrapper import ExternalLibary, cmodellib
    module = ExternalLibary()

    src_file = ctypes.c_void_p()
    dst_file = ctypes.c_void_p()
    src_model = None
    dst_model = None

    try:
        try:
            src_model = module.load_model(source_path.encode('utf-8'),
                                          ctypes.byref(src_file), False)
        except Exception:
            pass
        try:
            dst_model = module.load_model(saved_path.encode('utf-8'),
                                          ctypes.byref(dst_file), False)
        except Exception:
            pass

        # Build mesh-name → mesh-index lookups for both files.
        def build_mesh_index(model):
            d = {}
            if not model:
                return d
            try:
                num = cmodellib.getNumMeshes(model)
                for i in range(num):
                    name_b = cmodellib.getMeshName(model, i)
                    if name_b:
                        d[name_b.decode('latin-1', errors='replace')] = i
            except Exception:
                pass
            return d

        src_mesh_idx = build_mesh_index(src_model)
        dst_mesh_idx = build_mesh_index(dst_model)

        # Per-mesh vertex caches — copy ctypes float arrays into Python
        # tuples once per mesh so we don't pay the FFI cost per coord
        # access during the nearest-vertex inner loop.
        src_verts_cache = {}
        dst_verts_cache = {}

        def get_verts(model, mesh_idx, cache):
            if mesh_idx in cache:
                return cache[mesh_idx]
            try:
                num = cmodellib.getNumVerts(model, mesh_idx)
                ptr = cmodellib.getVertexData(model, mesh_idx)
                if not ptr or num <= 0:
                    cache[mesh_idx] = []
                    return cache[mesh_idx]
                # Bulk-copy via ctypes.string_at to avoid 3*N FFI hops
                buf = ctypes.string_at(ptr, num * 3 * 4)
                flats = struct.unpack(f'<{num*3}f', buf)
                verts = [(flats[i*3], flats[i*3+1], flats[i*3+2]) for i in range(num)]
                cache[mesh_idx] = verts
                return verts
            except Exception:
                cache[mesh_idx] = []
                return []

        out = bytearray()
        for k in range(n):
            try:
                # u16 fields — signed '<hhhh' misreads any index >32767 as
                # negative, which then fails the `0 <= a` / `0 <= d` guards
                # below and silently drops the record's remap.
                a, b, c, d = struct.unpack_from('<HHHH', src_bytes,
                                                src_gp + 12 + k*8)
            except struct.error:
                return None, [f'GtPt record {k} read failed']

            s_name = src_strs[a] if 0 <= a < len(src_strs) else None
            s_group = src_strs[b] if 0 <= b < len(src_strs) else None

            new_a = dst_str_lookup.get(s_name) if s_name else None
            if new_a is None:
                # name_id has no _ag_ slot in dest — record can't be
                # rebound. Fall back to source bytes so the engine
                # still gets the right record count.
                out += struct.pack('<HHHH', a, b, c, d)
                continue

            # group_id and vertex_index resolve together. The string
            # remap may fail if the mesh got merged AND the DLL didn't
            # preserve the original mesh name in the table; in that
            # case we still recover both fields by finding which dest
            # mesh actually holds the anchor's source world-position.
            new_b = dst_str_lookup.get(s_group) if s_group else None
            new_d = d
            same_mesh_in_dest = s_group and s_group in dst_mesh_idx

            if s_group and s_group in src_mesh_idx:
                src_verts = get_verts(src_model, src_mesh_idx[s_group], src_verts_cache)
                if 0 <= d < len(src_verts):
                    sx, sy, sz = src_verts[d]

                    if same_mesh_in_dest and new_b is not None:
                        # Standard case — same-named mesh present in
                        # both. Nearest-vertex within it.
                        dst_verts = get_verts(dst_model, dst_mesh_idx[s_group], dst_verts_cache)
                        if dst_verts:
                            best_i = 0
                            best_dsq = float('inf')
                            for i, (x, y, z) in enumerate(dst_verts):
                                dx = x - sx
                                dy = y - sy
                                dz = z - sz
                                dsq = dx*dx + dy*dy + dz*dz
                                if dsq < best_dsq:
                                    best_dsq = dsq
                                    best_i = i
                            new_d = best_i
                    else:
                        # Mesh merged into another in dest — common
                        # case: M_Head_Caruncle welded into M_Head.
                        # Search all dest meshes for the closest
                        # vertex to source's anchor position. The
                        # winning mesh's name becomes the new
                        # group_id, regardless of whether the original
                        # mesh's string is still in dest's TEXT block.
                        best_mesh = None
                        best_i = -1
                        best_dsq = float('inf')
                        for mesh_name, mesh_idx in dst_mesh_idx.items():
                            verts = get_verts(dst_model, mesh_idx, dst_verts_cache)
                            for i, (x, y, z) in enumerate(verts):
                                dx = x - sx
                                dy = y - sy
                                dz = z - sz
                                dsq = dx*dx + dy*dy + dz*dz
                                if dsq < best_dsq:
                                    best_dsq = dsq
                                    best_i = i
                                    best_mesh = mesh_name
                        if best_mesh and best_mesh in dst_str_lookup:
                            new_d = best_i
                            new_b = dst_str_lookup[best_mesh]

            if new_b is None:
                # Couldn't resolve group_id even after cross-mesh
                # search (unusual — would mean dest has no meshes or
                # no mesh-name strings at all). Fall back.
                out += struct.pack('<HHHH', a, b, c, d)
                continue

            new_fields = (new_a, new_b, c, new_d)
            if any(v < 0 or v > 0xFFFF for v in new_fields):
                # Remapped index exceeded u16 (e.g. nearest-vertex landed
                # past 65535 in a huge dest mesh). Keep the in-range source
                # bytes rather than crash the whole patch.
                log.append(f'GtPt record {k}: remapped index out of u16 '
                           f'range {new_fields} — kept source bytes')
                out += struct.pack('<HHHH', a, b, c, d)
            else:
                out += struct.pack('<HHHH', *new_fields)

        return bytes(out), log

    finally:
        try:
            if src_file:
                module.release_model_file(src_file)
        except Exception:
            pass
        try:
            if dst_file:
                module.release_model_file(dst_file)
        except Exception:
            pass


def _build_gtpt_records_from_resolver(resolver_records, saved_path):
    """Translate resolver-produced GtPtRecord objects into the byte format
    the existing _patch_gtpt_records_in_file accepts.

    Resolver records carry resolved STRINGS (anchor name, group/mesh name)
    plus slot and vertex_index integers. The saved file has its final
    string table laid out by the DLL's generateStringTable() — we look
    up our strings against that final table to get authoritative indices,
    then pack the record bytes exactly the way createGtPtBuffer does.

    Why this is needed:
      The earlier attempt pushed records DLL-side via addGotoPoint
      pre-save, but generateStringTable() runs during serialize() and
      rebuilds the table from canonical sources — any indices we
      computed pre-save were stale by the time the save finished.
      Going post-save means we read indices that match what's actually
      in the file.

    Returns (records_bytes, log_lines). records_bytes is None on fatal
    failure; per-record issues fall through to status='dropped' and the
    record is omitted (record count then mismatches and the patcher
    refuses to apply — which is the right safety behavior, since a
    short patch would re-introduce the dark-eye bug).
    """
    log = []
    if not resolver_records:
        return None, ['no resolver records']

    try:
        with open(saved_path, 'rb') as f:
            dst_bytes = f.read()
    except OSError as e:
        return None, [f'IO error reading saved file: {e}']

    dst_strs = _parse_text_block(dst_bytes)
    if dst_strs is None:
        return None, ['saved file has no parseable TEXT block']

    dst_str_lookup = {s: i for i, s in enumerate(dst_strs)}

    out = bytearray()
    skipped = 0
    for r in resolver_records:
        if r.status == 'dropped':
            skipped += 1
            continue
        n0 = dst_str_lookup.get(r.name)
        n1 = dst_str_lookup.get(r.group_name)
        if n0 is None or n1 is None:
            log.append(f"resolver record '{r.name}' on '{r.group_name}': "
                       f"string(s) not found in saved TEXT table — dropped")
            skipped += 1
            continue
        # GtPt fields are unsigned 16-bit (matching physics_patcher's
        # &0xFFFF treatment of the same vertex_index field). The old signed
        # '<hhhh' raised struct.error for any index >32767 — common on
        # high-detail merged heads — which the caller's broad except then
        # swallowed, silently dropping the ENTIRE GtPt patch (dark eyes).
        # Pack unsigned; drop only the individual out-of-range record.
        fields = (int(n0), int(n1), int(r.slot), int(r.vertex_index))
        if any(v < 0 or v > 0xFFFF for v in fields):
            log.append(f"resolver record '{r.name}' on '{r.group_name}': "
                       f"index out of u16 range {fields} — dropped")
            skipped += 1
            continue
        out += struct.pack('<HHHH', *fields)

    if skipped:
        log.append(f"{skipped} record(s) skipped — patch will not apply "
                   f"due to record-count mismatch with saved GtPt block")

    return bytes(out), log


def _is_source_gtpt_valid(source_path):
    """Sanity-check source's GtPt records for structural integrity.

    Returns:
      True  — records exist, are well-formed, and group_id resolves to
              plausible mesh names (M_Head, M_Teeth, M_Head_Caruncle,
              M_Tongue, etc.). The remap can run safely.
      False — at least one record's group_id resolves to an _ag_NNNN
              slot identifier or empty string. This indicates the source
              was previously roundtripped through a DLL that compacted
              the string table without rewriting GtPt — record integers
              still point at "the position where M_Head_Caruncle used
              to be," but that position now holds an _ag_NNNN string.
              The (mesh, vertex) pairs are unrecoverable from the file
              alone. Caller should skip transferGotoPoints so the export
              ships without a GtPt block at all (2K25-shape) — eyes
              render lit but without iris highlights, which is strictly
              better than dark eyes from writing nonsense records.
      True  — also returned if source has no GtPt block (nothing to
              validate; safe to proceed).

    The validation is heuristic but reliable for the corruption pattern
    that actually occurs in practice. It does not require a DLL load
    of the source — pure byte-level read.
    """
    try:
        with open(source_path, 'rb') as f:
            data = f.read()
    except OSError:
        return False

    strs = _parse_text_block(data)
    if strs is None:
        return False

    gp = data.find(b'GtPt')
    if gp < 0:
        return True  # No GtPt to validate; let normal flow proceed.

    try:
        n = struct.unpack_from('<I', data, gp + 8)[0]
    except struct.error:
        return False

    if n == 0:
        return True

    for k in range(n):
        try:
            _, b, _, _ = struct.unpack_from('<HHHH', data, gp + 12 + k*8)
        except struct.error:
            return False
        if not (0 <= b < len(strs)):
            return False
        s_group = strs[b]
        # group_id must point at a mesh name — _ag_NNNN strings are
        # slot identifiers used for name_id only, never group_id.
        if not s_group or s_group.startswith('_ag_'):
            return False

    return True




def _strip_ctg_substream_from_file(saved_path):
    """Remove the CTG! substream from a saved MCD file, in place.

    Defense in depth for the attire-export CTG bleed. The DLL's
    saveModelToFile CTG generator is opt-in (generate_ctg, default off)
    and only ever covers M_Head/M_Body, so it cannot emit CTG for an
    attire. The remaining bleed risk is a CTG passed through verbatim
    from a mis-tagged source — so even with the Python-side build-time
    injection and the 25→26 companion embedding both gated/removed for
    attires, a CTG block could still reach an attire file. This function
    scans the saved file for the leading CTG! envelope, splices it out
    (including any alignment padding between the CTG envelope and the next
    substream header), and rewrites the file.

    Substream envelope layout (from physics_patcher.py:60-72):
        [u32 ver=4][u32 payload_size][4-byte tag][payload]   — 12B header
    The CTG! envelope when present is the first substream after the
    'MCD!' 4-byte file magic at offset 0x00.

    Why we don't just trust the stored size: the broken 146_Attire.mcd
    fixture has CTG sz=82234 but the next substream header actually
    starts 2 bytes later than (header + sz) would predict — there's
    an alignment pad between the CTG envelope and the MDL! that
    follows. Naively stripping `header + sz` bytes leaves those 2
    padding bytes in place and shifts all downstream substream offsets
    by 2, corrupting the file. We scan forward up to 64 bytes past the
    nominal envelope end for a recognizable next-substream header
    pattern `[ver=4][next_tag in known set]`, and include any
    intervening padding in the strip.

    Returns True iff a CTG envelope was found and removed.

    Bounded operation:
      - Only touches the file IF a CTG! envelope is found AT offset 0x04
        (the basemodel-format slot). A CTG anywhere else in the file
        is left alone (we don't expect it but won't blindly modify).
      - File size shrinks by exactly the bytes removed.
      - All downstream substream tags / payloads remain byte-identical
        and at their new positions.
    """
    KNOWN_NEXT_TAGS = {b'MDL!', b'HCYW', b'HYWA', b'OCYW', b'OYWA',
                       b'HPL!', b'WDF!', b'TXR!', b'BMP!', b'MAT!',
                       b'TBL!', b'HST!'}
    try:
        with open(saved_path, 'rb') as f:
            data = f.read()
    except OSError:
        return False
    if len(data) < 16 or data[:4] != b'MCD!':
        return False
    # Substream header at offset 0x04: [u32 ver][u32 sz][4-byte tag]
    ver = struct.unpack_from('<I', data, 0x04)[0]
    sz  = struct.unpack_from('<I', data, 0x08)[0]
    tag = data[0x0C:0x10]
    if ver != 4 or tag != b'CTG!':
        return False  # No leading CTG! — nothing to strip
    nominal_end = 0x04 + 12 + sz
    if nominal_end > len(data):
        return False  # malformed — refuse to touch
    # Scan forward up to 64 bytes for the next valid substream header
    # `[ver=4][u32 size][4-byte known tag]`. This handles alignment
    # padding between the CTG envelope and the next substream.
    real_end = nominal_end
    for probe in range(0, 64, 2):
        if nominal_end + probe + 12 > len(data):
            break
        p_ver = struct.unpack_from('<I', data, nominal_end + probe)[0]
        p_tag = data[nominal_end + probe + 8 : nominal_end + probe + 12]
        if p_ver == 4 and p_tag in KNOWN_NEXT_TAGS:
            real_end = nominal_end + probe
            break
    stripped = data[:0x04] + data[real_end:]
    try:
        with open(saved_path, 'wb') as f:
            f.write(stripped)
    except OSError:
        return False
    return True


def _patch_gtpt_records_in_file(saved_path, records):
    """Splice GtPt records into the saved file in place.

    Bounded byte overwrite at the records offset only — anchor data, the
    GtPt header itself, and surrounding sub-streams are untouched. No-ops
    cleanly when the saved file has no GtPt block (attire exports) or
    when the GtPt size in saved file doesn't match the record count.

    Returns True iff a patch was actually applied.
    """
    if not records:
        return False

    try:
        with open(saved_path, 'rb') as f:
            data = f.read()
    except OSError:
        return False

    i = data.find(b'GtPt')
    if i < 0 or i + 12 > len(data):
        return False

    size = struct.unpack_from('<I', data, i + 4)[0]
    record_count = struct.unpack_from('<I', data, i + 8)[0]
    expected = record_count * 8
    if size != 4 + expected or expected != len(records):
        return False
    if i + 12 + expected > len(data):
        return False

    try:
        with open(saved_path, 'r+b') as f:
            f.seek(i + 12)
            f.write(records)
    except OSError:
        return False

    return True


def _inject_gtpt_block_in_file(saved_path, records, record_count):
    """Splice a fresh GtPt block into a saved file that doesn't have one.

    Used when scene anchors exist (resolver records) but no GtPt block
    was written — the Generate-from-file workflow where the picked source
    is an anchor donor only, not an export source.

    Locates MDL! envelope via the unique 'MDL!MDL!' signature, finds
    MTL! within the MDL payload (canonical layout: GtPt sits before
    MTL!), splices [GtPt][size_u32][count_u32][records] before MTL!,
    and updates the MDL envelope size word.

    Empirically verified working in v1.9.49 — eyes rendered correctly
    in-game with one minor right-eye shading asymmetry that traces to
    anchor position resolution, not to the inject step itself.

    Returns True iff a block was inserted.
    """
    if not records or record_count <= 0 or len(records) != record_count * 8:
        return False

    try:
        with open(saved_path, 'rb') as f:
            data = bytearray(f.read())
    except OSError:
        return False

    if b'GtPt' in data:
        return False  # patcher should handle existing block, not us

    # MDL!MDL! signature: outer-tag + inner-tag pair the DLL writes
    # for the MDL sub-stream. Same trick as wrapper.py:detect_mcd_version.
    mdlmdl = data.find(b'MDL!MDL!', 12)
    if mdlmdl < 0:
        return False

    # Envelope size word lives 4 bytes before the signature.
    mdl_size_offset = mdlmdl - 4
    if mdl_size_offset < 0:
        return False
    mdl_size = struct.unpack_from('<I', data, mdl_size_offset)[0]
    if mdl_size == 0 or mdl_size > 100_000_000:
        return False
    mdl_content_end = mdlmdl + 4 + mdl_size

    insert_at = data.find(b'MTL!', mdlmdl, mdl_content_end)
    if insert_at < 0:
        return False

    block = (b'GtPt'
             + struct.pack('<I', 4 + record_count * 8)
             + struct.pack('<I', record_count)
             + records)

    new_data = data[:insert_at] + block + data[insert_at:]
    struct.pack_into('<I', new_data, mdl_size_offset, mdl_size + len(block))

    try:
        with open(saved_path, 'wb') as f:
            f.write(new_data)
    except OSError:
        return False

    return True




def _find_source_mcd():
    """Find the source MCD path stamped on any collection containing a selected
    mesh. Returns the path or None.

    Both attire and baseModel sources are returned. The caller (build()) is
    responsible for deciding which sub-stream transfers apply — CTG must be
    skipped for baseModel sources because the envelope is keyed by mesh
    string indices that don't survive caruncle-into-head merges, while GtPt
    is bone-index/coordinate data and is safe across mesh-merge cases.
    """
    import bpy

    for obj in bpy.context.selected_objects:
        if obj.type != 'MESH':
            continue
        for col in bpy.data.collections:
            if obj.name not in col.objects:
                continue
            path = col.get("vcmodel_source_path")
            if path and os.path.exists(path):
                return path

    # No selected-mesh collection was stamped. Fall back to scanning ALL
    # collections — handy for re-export workflows where the user has
    # juggled selection outside the originally stamped collection.
    for col in bpy.data.collections:
        path = col.get("vcmodel_source_path")
        if path and os.path.exists(path):
            return path

    return None



def _is_basemodel_source(path):
    """True if the source MCD is a baseModel rather than attire.

    baseModel sources must skip CTG transfer at export time. The CTG envelope
    contains TOBJ/RCTG/DUPS vertex permutation tables keyed by mesh string
    indices. Modders routinely join M_Head_Caruncle into M_Head as part of
    the standard 26 head-rig workflow — the export-side string table the DLL
    generates from the post-merge mesh set then has different indices than
    the source baseModel's pre-merge table. Re-injecting the source CTG
    points the eye-shading attribute group at the wrong entries → dark eyes.

    GtPt transfer remains safe for baseModel because GtPt is per-character
    body-anchor data keyed by bone indices and coordinates, not mesh strings.
    """
    return 'basemodel' in os.path.basename(path).lower()

class CModelSerializer():

    @staticmethod
    def to_cmodel(skinmeshes, compile_target=None, export_gtpts=True,
                  is_basemodel_export=False):
        cmodel = CModelSerializer()
        cmodel.set_meshes(skinmeshes)
        # `export_gtpts` is the "Include GtPt Anchors" UI toggle. When False,
        # build() suppresses transferGotoPoints so the file ships without a GtPt
        # block; the post-save patcher short-circuits on the same flag and the
        # _ag_ attribute-group block is suppressed DLL-side via
        # setSkipAttributeGroups. The GtPt sub-stream and _ag_ string block
        # always move together — each without the other dangles lookups.
        #
        # `is_basemodel_export` gates CTG injection in build(). CTG is
        # basemodel-only; injecting source CTG into an attire pulls an 80+KB
        # block into the attire's MDL! slot at offset 0xC, shifting all
        # downstream substreams (see build() for the full rationale). Caller
        # passes True when M_Head / M_Body are in the user's selection.
        cmodel.export_gtpts = bool(export_gtpts)
        cmodel.is_basemodel_export = bool(is_basemodel_export)
        cmodel.build(compile_target=compile_target)
        return cmodel

    def build(self, compile_target=None):
        # Warnings collected during build for the operator layer to surface
        # via operator.report. Not all build paths have an operator handle,
        # so the serializer just stashes them here and lets the caller drain.
        if not hasattr(self, 'export_warnings'):
            self.export_warnings = []
        # Link all child mesh data to new cmodel
        for mesh_idx, mesh in enumerate(self.meshes):
            cskinmesh = cmesh.new()
            cskinmesh.set_name_info(mesh.mesh_name, mesh.name)
            
            use_dll = getattr(mesh, 'use_dll_preprocess', False)
            vertex_remap = getattr(mesh, 'vertex_remap', None)
            
            if use_dll:
                # DLL preprocessing path (Preserve Custom Normals)
                cskinmesh.set_positions_raw(mesh.vertices)
                cskinmesh.set_polygons(mesh.face_sizes, mesh.index_list)
                
                if getattr(mesh, 'loop_uv_sets', None):
                    for uv_set in mesh.loop_uv_sets:
                        cskinmesh.add_loop_uv_map(uv_set, mesh.num_loops)
                
                if getattr(mesh, 'loop_normals', None):
                    cskinmesh.set_loop_normals(mesh.loop_normals, mesh.num_loops)

                # Carried vanilla tangents (WDF preservation). Only populated
                # when the mesh is unedited (hash gate in getRawLoopTangents);
                # otherwise None here and the DLL regenerates via MikkTSpace.
                # MUST precede prepare_for_export so splitUvSeams moves these
                # into the per-vertex tangent buffer (parallel to loop normals)
                # and the serializer's keep-verbatim guard fires.
                if getattr(mesh, 'loop_tangents', None):
                    cskinmesh.set_loop_tangents(mesh.loop_tangents, mesh.num_loops)

                # Carried vanilla PackedTBN octahedral words — the lane WDF
                # reads. Same gate/ordering rationale as loop_tangents: only
                # populated for an unedited mesh (hash gate in
                # getRawLoopPackedTBN), and MUST precede prepare_for_export so
                # splitUvSeams carries the words per-vertex and
                # reorderSplitToVanilla permutes them to vanilla render order
                # before the per-vertex serializer gate emits the unedited ones
                # byte-for-byte.
                if getattr(mesh, 'loop_packedtbn', None):
                    cskinmesh.set_loop_packedtbn(mesh.loop_packedtbn, mesh.num_loops)

                # Emit ALL vertex-color maps (cpv+pores, teeth_SSS, hair up to 6),
                # not just the first — addMeshColorMap appends one channel per call.
                # vertex_color_maps is the full ordered list (import/DLL-map order);
                # fall back to the single legacy field when it wasn't populated.
                _cmaps = getattr(mesh, 'vertex_color_maps', None)
                if _cmaps:
                    for _cmap in _cmaps:
                        cskinmesh.add_vertex_colors(_cmap)
                else:
                    cskinmesh.add_vertex_colors(mesh.vertex_colors)
                cskinmesh.set_skin_data(mesh.skin)
                cskinmesh.set_blendshapes(mesh.blendshapes)
                cskinmesh.set_model_game_flags(mesh.scene_flag, mesh.motion_flag)
                
                # Vertex remap MUST be sent before prepare_for_export on
                # the DLL path — see explanation below. Matches the
                # "all setMesh* before prepare" ordering of every other
                # data channel (positions, polygons, UVs, normals,
                # colors, skin, blendshapes, game flags).
                cskinmesh.set_vertex_remap(vertex_remap)
                
                # prepare_for_export runs the DLL-side triangulate + UV-seam
                # split, creating clone verts at [N..M'-1] and propagating
                # per-vert data (skin, shape-keys, vertex remap) to the clones —
                # but only for data present when it fires. Setting the remap
                # AFTER this gave a pre-split-length remap to a post-split DLL:
                # clone indices got no remap entries, so the file's vertex layout
                # only half-matched. Symptom: preserve_normals=ON + remap=ON put
                # HPL masks on the wrong vertices (the Python HPL generator
                # computes MCD indices from the same pre-split remap). The
                # Python-preprocess path is immune (it propagates the remap
                # Blender-side via propagate_vertex_remap_after_split).
                cskinmesh.prepare_for_export()
            else:
                # Legacy path (pre-processed by Blender — remap was
                # already extended by propagate_vertex_remap_after_split
                # during format_game_uv_seams, so it's post-split-sized
                # and can be sent at any point before saveModelToFile).
                cskinmesh.set_data(mesh.vertices, mesh.index_list)
                cskinmesh.set_normals(mesh.vertex_normals)
                # Carried vanilla tangents (WDF preservation). None unless the
                # mesh is unedited (hash gate in getVertexTangents); the DLL's
                # keep-verbatim guard then writes them byte-for-byte instead of
                # regenerating drifted MikkTSpace tangents.
                if getattr(mesh, 'vertex_tangents', None):
                    cskinmesh.set_tangents(mesh.vertex_tangents)
                # Emit ALL vertex-color maps (cpv+pores, teeth_SSS, hair up to 6),
                # not just the first — addMeshColorMap appends one channel per call.
                # vertex_color_maps is the full ordered list (import/DLL-map order);
                # fall back to the single legacy field when it wasn't populated.
                _cmaps = getattr(mesh, 'vertex_color_maps', None)
                if _cmaps:
                    for _cmap in _cmaps:
                        cskinmesh.add_vertex_colors(_cmap)
                else:
                    cskinmesh.add_vertex_colors(mesh.vertex_colors)
                cskinmesh.set_skin_data(mesh.skin)
                cskinmesh.set_blendshapes(mesh.blendshapes)
                cskinmesh.set_model_game_flags(mesh.scene_flag, mesh.motion_flag)
                
                for map in mesh.texcoords:
                    cskinmesh.add_uv_channel(map)
                
                cskinmesh.set_vertex_remap(vertex_remap)

            # Multi-material face groups (e.g. M_EYE = eye_r:skinned + eye_l:skinned;
            # glasses = glasses + glasses_ALPHA). setMeshData/set_polygons created ONE
            # default group from set_name_info, dropping every material past the first
            # (basemodel right-eye, opaque lens, _ALPHA cutouts). Re-emit the captured
            # per-material ranges so the MTL! buffer + TEXT material table carry all of
            # them. Applied AFTER prepare_for_export (DLL path) / set_data (legacy path)
            # so the triangle ranges align to the final mesh->triangles, and AFTER any
            # split (which permutes vertex indices, not triangle order). None for
            # single-material meshes -> default set_name_info path untouched.
            face_groups = getattr(mesh, 'face_groups', None)
            if face_groups and cmesh.has_face_group_api():
                cskinmesh.clear_face_groups()
                for (mtl_name, face_begin, num_tris) in face_groups:
                    cskinmesh.add_face_group(mtl_name, face_begin, num_tris)

            self.__add_cmesh(cskinmesh)

        # Sub-stream transfers from the source MCD.
        #
        # Two sub-streams need explicit Python-side preservation because
        # saveModelToFile doesn't reproduce them through a load→modify→save:
        #
        #   GtPt (Goto Points): per-character body-anchor data inside the MDL
        #     stream of baseModel MCDs, with no Blender-side representation.
        #     Transferred from the source's loaded cmodel via the DLL helper.
        #     Attire MCDs don't carry GtPt (the call is a no-op there).
        #
        #   CTG (vertex remap tables): TOBJ/RCTG/DUPS vertex permutation tables.
        #     The DLL scrambles/regenerates CTG on save when source's parsed CTG
        #     isn't carried forward, so we re-inject the source envelope file-side
        #     via the idempotent replaceOrAddSubStreamByTag. The extractor
        #     returns None for 2K25 sources where CTG is a .ctg sidecar —
        #     companion_upgrade.py handles those.
        #
        # Every OTHER sub-stream (HPL, HCYW, HYWA, OYWA, OCYW, HST) is left to
        # the DLL or to scene-driven generators (HPL round-trip, physics swap).
        #
        # Restricted to 2K26: transferGotoPoints isn't in the legacy 2K22-2K25
        # DLL, and embedded-sub-stream CTG is 2K26-only (sidecar on older).
        if compile_target == "option_vcexport_26":
            source_path = _find_source_mcd()
            if source_path:
                # CTG passthrough — basemodel-only.
                #
                # CTG (TOBJ/RCTG/DUPS vertex permutation tables) is a
                # basemodel-format substream at offset 0xC of the saved MCD.
                # Vanilla 2K26 ATTIRES carry ZERO CTG (confirmed: MDL! is the
                # first substream, no CTG! anywhere). Injecting a CTG envelope
                # on attire export shifts everything else (MDL!, HCYW, HYWA,
                # HPL!, OCYW, OYWA, WDF!) ~82KB back from where the game expects
                # it, and basemodel mesh/material slot names (body:skinned,
                # head:skinned, M_Body, M_Head, ...) leak into the saved TEXT
                # block via CTG's TOBJ entries — the attire becomes structurally
                # a basemodel (wrong slots, wrong remaps, broken physics).
                #
                # saveModelToFile prefers writing source's CTG verbatim from
                # rawStreams over its generateCTG fallback, but dest rawStreams
                # is empty unless we inject. Reading the envelope from source
                # MCD bytes and pushing it via replaceOrAddSubStreamByTag takes
                # the passthrough branch — but only for basemodel exports.
                # The DLL-side pushAttributeGroupBlock fix (always emit the
                # M_Head_Caruncle string regardless of mesh existence) keeps the
                # export string table layout fixed so source CTG indices stay
                # valid across the caruncle-merge.
                if getattr(self, 'is_basemodel_export', False):
                    try:
                        ctg_envelope = _read_ctg_envelope_from_mcd(source_path)
                        if ctg_envelope:
                            cmodellib.replaceOrAddSubStreamByTag(
                                self.__model, ctg_envelope, len(ctg_envelope))
                    except Exception as e:
                        derror(f"[MDL Addon] CTG transfer error: {e}")

                # Sub-stream + bone-metadata transfers via DLL. saveModelToFile
                # passes through whatever exists in dest's rawStreams, but those
                # are empty on a fresh cmodel. Five transfer functions populate
                # them:
                #
                #   transferRawSubStreams — source's post-MDL blobs
                #     (HCYW/HYWA/OCYW/OYWA/WDF); missing entirely without this.
                #   transferHstData — HST! bone metadata for jig/retarget
                #     bookkeeping; not regenerable from skeleton state alone.
                #   transferGotoPoints — body-anchor records → dest m_gtpoints.
                #   transferStringTable — source's full TEXT block, used as
                #     origTable for fallback recovery of canonical names
                #     (material eye_r:skinned/lambert1/belt_APs, UV UVChannel_1,
                #     color cpv, case-locking). Without it the export loses ~10
                #     canonical entries → index drift → dark eyes.
                #   transferMaterialTable — source's full material list for the
                #     originalMats loop; catches materials with no face-group
                #     assignments (lambert1, belt_*).
                try:
                    from ..Link.wrapper import ExternalLibary, detect_mcd_version
                    module = ExternalLibary()
                    src_file = ctypes.c_void_p()
                    src_model = module.load_model(
                        source_path.encode('utf-8'),
                        ctypes.byref(src_file),
                        False,
                    )
                    if src_model and src_file:
                        # Source-version gate for the raw sub-stream + HST!
                        # transfers. transferRawSubStreams bulk-copies source's
                        # post-MDL blobs (HCYW/HYWA/OCYW/OYWA/WDF) and
                        # transferHstData copies HST! bone metadata — both are
                        # 2K26 (v0x2F) binary layouts. Copying them verbatim out
                        # of a 2K25/older source into a 2K26 export embeds
                        # incompatible blobs → structurally-broken file. Only
                        # transfer when the source is 2K26. Version 0 means
                        # undetectable (older DLL with no getModelFileVersion
                        # export AND a header detect_mcd_version can't parse) —
                        # proceed as before so we don't regress files that
                        # currently round-trip fine.
                        src_version = module.getModelFileVersion(src_file)
                        if not src_version:
                            src_version = detect_mcd_version(source_path)
                        src_is_2k26 = src_version in (0, 0x2F)
                        try:
                            if src_is_2k26:
                                cmodellib.transferRawSubStreams(src_model, self.__model)
                                cmodellib.transferHstData(src_model, self.__model)
                            else:
                                dlog(f"[MDL Addon] Source MDL v0x{src_version:02x} "
                                     f"is not 2K26 (0x2F) — skipping "
                                     f"transferRawSubStreams / transferHstData to "
                                     f"avoid embedding cross-version sub-stream "
                                     f"blobs in the 2K26 export.")
                            # GtPt safety net. Source GtPt records get silently
                            # corrupted when the source MCD was round-tripped
                            # through a DLL that compacted the string table
                            # without rewriting records — group_id then points at
                            # an _ag_NNNN slot identifier instead of a mesh name,
                            # and transferring + remapping them yields dark eyes.
                            # _is_source_gtpt_valid detects this pre-save; on a
                            # bad source we skip the transfer so createGtPtBuffer
                            # early-outs on empty m_gtpoints and the export ships
                            # without GtPt (lit eyes, no iris highlights — strictly
                            # better than dark; user re-imports a clean baseModel
                            # to recover).
                            if getattr(self, 'export_gtpts', True) and _is_source_gtpt_valid(source_path):
                                cmodellib.transferGotoPoints(src_model, self.__model)
                            elif not getattr(self, 'export_gtpts', True):
                                dlog(f"[MDL Addon] No-AO mode (Include GtPt "
                                     f"Anchors off): skipping transferGotoPoints "
                                     f"— GtPt block will not be written.")
                            else:
                                derror(f"[MDL Addon] Source GtPt records are "
                                       f"structurally invalid (group_id resolves "
                                       f"to _ag_NNNN slot identifier instead of a "
                                       f"mesh name). This usually means the source "
                                       f"file was previously exported through an "
                                       f"older DLL build that compacted the string "
                                       f"table. Skipping GtPt transfer — eyes will "
                                       f"render lit but without iris highlights / "
                                       f"caruncle shadow falloff. To restore full "
                                       f"eye detail, re-import from a clean vanilla "
                                       f"baseModel for {os.path.basename(source_path)}.")
                            # String + material table transfers — basemodel only.
                            #
                            # transferStringTable/transferMaterialTable copy
                            # source's full original TEXT block + material list
                            # into dest, used by generateStringTable as origTable
                            # for fallback recovery of canonical names not in
                            # dest's mesh set.
                            #
                            # BASEMODEL: required — without it the export loses
                            # ~10 canonical entries (eye_r:skinned, lambert1,
                            # belt_APs) → cascading sub-stream index drift → dark
                            # eyes (eye_r:skinned material lookup fails).
                            #
                            # ATTIRE: HARMFUL — the "sticky pollution" bug. If the
                            # attire was ever round-tripped through a buggy build
                            # (CTG bleed, ungated GtPt resolver), its polluted
                            # string table holds basemodel slots; copying them
                            # forward means the next round-trip sees the same
                            # pollution as "source" and it never washes out.
                            # Skipping forces a fresh TEXT block from the export's
                            # actual mesh content; attires don't need the
                            # basemodel-specific (eye/body/head) recovery fallback.
                            # STRING TABLE IS ALWAYS FRESH — never copy the source's
                            # TEXT block / material list into the export (transferString
                            # Table/transferMaterialTable seed the DLL's origTable recovery
                            # and RETAIN stale source entries that never wash out). Disabled
                            # for ALL exports per the user's standing directive: fresh-only.
                            dlog("[MDL Addon] string table: FRESH-ONLY for all exports "
                                 "(transferStringTable/transferMaterialTable disabled)")
                            # SpeedTree (.speedtree) wrapper round-trip. No-op for
                            # MCD imports (source has no SPDT header). For SpeedTree
                            # imports, ferries the captured 40-byte SPDT file header
                            # so the writer emits a proper .speedtree file instead
                            # of falling through to MCD output.
                            cmodellib.transferSpdtHeader(src_model, self.__model)
                            # Multi-LOD round-trip preservation. Required for vanilla
                            # 2K26 wrestler/crowd MCDs (4 / 6 LODs) — without this,
                            # the writer falls back to cloning LOD0 across N slots
                            # and the source's distinct LOD1+ geometry is lost on
                            # save. No-op for single-LOD content (belts).
                            cmodellib.transferLodCaptures(src_model, self.__model)
                        finally:
                            # Always release the source file, even if any of
                            # the transfer* calls above raised. Previously
                            # release_model_file sat at the tail of the if-
                            # block, so an exception during transfer would
                            # leak the file handle (the outer except just
                            # logged the error and moved on).
                            module.release_model_file(src_file)
                except Exception as e:
                    derror(f"[MDL Addon] Sub-stream transfer error: {e}")
        return
    
    def set_skeleton(self, armature):
        if (armature == None): 
            return
        
        for index, bone in enumerate(armature.bones):
            cmodellib.addBoneToModel(self.__model, bone.name, bone.matrix, index, bone.parent)
        return
    
    def set_attach_points(self, points):
        if (not points):
            return
        
        for point in points:
            cmodellib.addPointToModel(self.__model, point.joint, point.id_a, point.id_b, point.flag, point.co)
        return
    
    def set_meshes(self, mesh_list):
        self.meshes = mesh_list
        return
    
    def free(self):
        cmodellib.free_cskinmodel(self.__model)
        self.__model = None
        return 
    
    def get_model_ptr(self):
        return self.__model
    
    def save_to_file(self, path, compile_target, use_shape_keys=True, use_calculate_tangents=True, generate_mtls=False, num_lods=2, use_vertex_remap=False, generate_ctg=False):
        if (path == None):
            return False

        # Crowd/audience exports: GENERATE per-mesh D3D12 MeshletBuffer data so
        # edited and newly-added crowd meshes render through the game's mandatory
        # mesh-shader path (without it, crowd geometry doesn't draw). Auto-detected
        # from the source MCD (Audience/ tree) or crowd-LOD mesh names, which
        # survive editing. No-op for wrestlers/attires (they carry no meshlets).
        try:
            if self._is_crowd_export(dest_path=path):
                cmodellib.setGenerateMeshlets(self.__model, 1)
                num_lods = 6  # vanilla crowd ships 6 LOD levels; match the count so
                              # the game's distance-LOD switch doesn't index past the end
                dlog("[MDL Addon] Crowd export: generating D3D12 meshlets (6 LODs) for the mesh-shader path.")
        except Exception as e:
            derror(f"[MDL Addon] setGenerateMeshlets failed: {e}")

        result = cmodellib.saveModelToFile(self.__model, path, compile_target, use_shape_keys, use_calculate_tangents, generate_mtls, num_lods, use_vertex_remap, generate_ctg)

        # SpeedTree (.speedtree) extension fix. When the source was a .speedtree, the
        # writer correctly emits a SPDT-wrapped file (40-byte header verbatim + inner
        # MDL chunk) BUT the DLL forces a ".mcd" extension on it — so an otherwise
        # valid SpeedTree asset lands as "<name>.mcd" and the game won't load it as a
        # tree. Rename it back to .speedtree. STRICTLY gated on hasSpdtHeader() (the
        # model actually carries a captured SPDT header => the writer wrote SPDT
        # content), so normal MCD/attire/belt/crowd exports are NEVER touched. No DLL
        # change — cannot affect any other mesh's export. Graceful: hasSpdtHeader is
        # 0/False on a DLL lacking the export, so the rename simply doesn't fire.
        try:
            if result and cmodellib.hasSpdtHeader(self.__model):
                stem = os.path.splitext(path)[0]
                written = stem + ".mcd"            # what the DLL actually wrote
                target = stem + ".speedtree"       # what a SpeedTree asset must be
                if os.path.exists(written) and os.path.abspath(written) != os.path.abspath(target):
                    os.replace(written, target)
                    dlog(f"[MDL Addon] SpeedTree export: corrected extension -> {os.path.basename(target)}")
        except Exception as e:
            derror(f"[MDL Addon] SpeedTree extension fix failed: {e}")

        return result

    def _is_crowd_export(self, dest_path=None):
        """True when this export is a crowd/audience model (needs generated
        meshlets). Signals, OR'd (most-reliable first):

          1. The export DESTINATION is under an Audience/ tree. This is the
             primary signal because the user always saves crowd mods into
             .../Audience/<Person>/ — and it survives the two ways the other
             signals silently fail: a moved/renamed/temp source MCD makes
             _find_source_mcd() return None (it requires os.path.exists), and
             editing/adding/renaming meshes drops the C0_/L0_ name prefix.
             When detection fails the writer falls back to the preservation
             path, which re-emits the captured vanilla LODs verbatim and
             SILENTLY DROPS any added/edited geometry (the model exports
             byte-identical to vanilla) — so a robust trigger is essential
             for the add-mesh workflow.
          2. The stamped source MCD lives under an Audience/ tree.
          3. Any mesh carries a crowd LOD-level name prefix (C0_/L0_..L5_)."""
        try:
            if dest_path and 'audience' in str(dest_path).replace('\\', '/').lower():
                return True
        except Exception:
            pass
        try:
            src = _find_source_mcd()
            if src and 'audience' in src.replace('\\', '/').lower():
                return True
        except Exception:
            pass
        prefixes = ("C0_", "L0_", "L1_", "L2_", "L3_", "L4_", "L5_")
        for m in getattr(self, 'meshes', []) or []:
            nm = (getattr(m, 'name', '') or '')
            if nm.startswith(prefixes):
                return True
        return False

    def set_use_lod_captures(self, enabled):
        """Opt this model into the writer's preserve-LOD1+ path. Required
        for crowd exports (the cloning path renders crowd models invisible
        in-game). Wrestlers and belts must NOT enable this — their
        workflow relies on cloning so sculpt/edit changes are visible at
        every LOD distance."""
        cmodellib.setUseLodCaptures(self.__model, enabled)
    
    def __add_cmesh(self, cmesh):
        mesh_p = cmesh.get_cstruct()
        return cmodellib.addMeshToModel(self.__model, mesh_p)
    
    def __get_cmodel_p(self):
        return cmodellib.getNewSkinModel()

    def __init__(self):
        self.__model       = self.__get_cmodel_p()
        self.meshes        = []





