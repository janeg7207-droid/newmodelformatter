"""
Orchestrator for WWE 2K26 material export.

Why this module exists
──────────────────────
2K26 materials are split across two file types instead of the single
binary 2K22-2K25 ``.mtls``:

  * ``<model_dir>/<name>.mtls`` — slim wrapper that just lists material
    names in slot order. Per-material data lives elsewhere.
  * ``<model_dir>/Materials/<material>.jmtl`` — one JSFB FlatBuffer per
    material with shader byte, parameter block, texture-hash bindings.

Saving a 2K26 model from Blender therefore needs both: an updated .mtls
that matches the mesh slot order, and a fresh .jmtl for every material
with the textures the user has wired into the node tree. This module is
the glue that walks the Blender material list, picks a template, pulls
texture filepaths out of the Principled BSDF node tree, hashes them
into the engine's u64 colorMap@ref convention, and dispatches to the
two writers.

It deliberately does NOT:

  * Reimplement the JSFB FlatBuffer encoder (lives in
    ``Serialize.jmtl_writer``).
  * Carry hardcoded default parameter values per shader (lives in
    ``Serialize.material_templates``).
  * Encode the .mtls list wrapper (lives in ``Serialize.mtls_writer``).
  * Decide which shader template a slot maps to (lives in
    ``Blender.Extras.material_inference``).

The split keeps each piece independently testable. The orchestrator's
sole job is to wire them together against the live Blender material
list and write the resulting bytes to the correct filesystem paths.

Robustness contract
───────────────────
Material export is a side-effect of model export; we cannot let a bad
node tree, a missing texture file, or even a writer bug abort the
whole save. Every per-material operation is wrapped — failures are
collected into the returned ``errors`` list and the next material is
attempted. The caller's ``.mcd`` write succeeds even if every single
JMTL fails. Worst case: the user opens the model in-game with default
materials and reapplies textures via MaterialEditor.

Filename matching for the .mtls wrapper
───────────────────────────────────────
The 2K26 game pack has inconsistent casing for the .mtls file across
characters — ``baseModel.mtls``, ``BaseModel.mtls``, ``Attire.mtls``,
``358_Attire.mtls`` all appear in shipped content. To preserve the
user's source casing (so re-saving doesn't break engine references
that look up the .mtls by exact filename), we scan the model directory
for any existing ``*.mtls`` and prefer its exact name if a single
match exists. Falls back to canonical defaults when no match is found
or when an attire scope override is in play.
"""

import json
import os
import re


# ─── Lazy imports ───────────────────────────────────────────────────────────
#
# Every sibling-module import is deferred to its call site so: (1) the addon
# enables even if a dep is missing; (2) the self-test can inject mocks via
# sys.modules; (3) import errors surface as an `errors` string rather than
# killing the whole save.


def _import_jmtl_writer():
    from .jmtl_writer import write_jmtl  # noqa: WPS433
    return write_jmtl


def _import_mtls_writer():
    from .mtls_writer import write_mtls  # noqa: WPS433
    return write_mtls


def _import_material_templates():
    from . import material_templates  # noqa: WPS433
    return material_templates


def _import_material_inference():
    # material_inference lives in Blender/Extras/ — three packages up.
    from ..Blender.Extras import material_inference  # noqa: WPS433
    return material_inference


def _import_jmtl_resolver():
    from ..Blender.Extras import jmtl_resolver  # noqa: WPS433
    return jmtl_resolver


def _import_vanilla_basis():
    """Lazy-load the vanilla harvest index.

    Same lazy-import discipline as the other sibling modules: harvest is
    purely additive — if it fails to import (older addon checkout, sample
    corpus missing, etc.) the orchestrator must still produce valid
    material output via the generic-template path.
    """
    from . import vanilla_basis  # noqa: WPS433
    return vanilla_basis


# ─── Constants ──────────────────────────────────────────────────────────────

# Shader byte for the gear/cloth shader (yCh_gear). The only character
# shader that has an alpha-blended variant we treat specially (variant
# byte 1 instead of 0). Sourced from Serialize.jmtl_writer's enum;
# duplicated here as a constant to avoid importing the whole writer just
# for an int comparison.
_SHADER_GEAR = 0x15

# Legacy-to-modern param key aliases (mirrors jmtl_writer._LEGACY_FIELD_ALIASES).
# Resolved by _resolve_legacy_aliases BEFORE passing to write_jmtl, so the
# writer no longer needs the per-shader _resolve_aliased calls. The writer
# keeps its alias bridge for backward compat with direct callers.
_LEGACY_ALIAS_MAP = {
    "nrMap@ref":    "g_nrmMap@ref",
    "colorMap@ref": "g_mEyeOvlPrm@ref",
}


# Presets contain the entire historical inline-MTLS vocabulary.  A JMTL
# template default is not the same thing as an explicitly-authored field:
# shipped 2K26 JMTLs deliberately leave many schema slots absent.  Passing the
# whole preset through made every optional value look caller-supplied and
# inflated otherwise-valid character materials with unrelated fields.
_SAFE_IMPLICIT_TEMPLATE_KEYS = {
    0x01: {"colorMap", "colorMap@ref", "g_nrmMap", "g_nrmMap@ref"},
    0x02: {
        "colorMap", "colorMap@ref", "g_nrmMap", "g_nrmMap@ref",
        "sampIllumMap1", "sampIllumMap1@ref",
    },
    0x12: {"colorMap", "colorMap@ref", "g_nrmMap", "g_nrmMap@ref"},
    0x13: {
        "colorMap", "colorMap@ref", "subSurfaceAOMap",
        "subSurfaceAOMap@ref", "g_AOcolorR", "g_AOcolorG",
        "g_AOcolorB", "g_detailMapU", "g_detailMapV", "exposure",
    },
    0x14: {"g_mEyeOvlPrm", "g_mEyeOvlPrm@ref", "colorMap", "colorMap@ref"},
    0x15: {
        "colorMap", "colorMap@ref", "g_nrmMap", "g_nrmMap@ref",
        "clothSheenR", "clothSheenG", "clothSheenB", "glow",
        "PbrUvScrollX", "PbrUvScrollY", "irradianceR", "irradianceG",
        "irradianceB", "microDetail", "g_specIntensity",
    },
    0x16: {
        "hairType", "flowMap", "flowMap@ref", "g_mPixMsk",
        "g_mPixMsk@ref", "g_comboMap", "g_comboMap@ref",
        "g_rootColorR", "g_rootColorG", "g_rootColorB",
        "g_tipColorR", "g_tipColorG", "g_tipColorB",
        "g_hairVariation", "g_noiseUScale", "g_noiseVScale",
        "primeIntensity", "rimIntensity", "secondIntensity",
        "primeShift", "primeWidth", "secondShift", "secondWidth",
        "rimShift", "rimWidth", "primeSat", "secondBright",
        "secondSat", "rimBright",
    },
    0x17: {
        "colorMap", "colorMap@ref", "g_nrmMap", "g_nrmMap@ref",
        "g_AOcolorR", "g_AOcolorG", "g_AOcolorB",
        "g_detailMapU", "g_detailMapV", "g_poreColor", "glow",
    },
    0x18: {
        "colorMap", "colorMap@ref", "g_nrmMap", "g_nrmMap@ref",
        "g_AOcolorR", "g_AOcolorG", "g_AOcolorB",
        "g_detailMapU", "g_detailMapV",
    },
    0x19: {
        "colorMap", "colorMap@ref", "g_nrmMap", "g_nrmMap@ref",
        "g_AOcolorR", "g_AOcolorG", "g_AOcolorB",
        "g_detailMapU", "g_detailMapV", "g_poreColor", "glow",
    },
    0x1A: {
        "colorMap", "colorMap@ref", "g_nrmMap", "g_nrmMap@ref",
        "irradianceR", "irradianceG", "irradianceB",
    },
    0x1B: {
        "nrMap", "nrMap@ref", "colorMap", "colorMap@ref",
        "shellFurMap", "shellFurMap@ref", "shellFurDir",
        "shellFurDir@ref",
    },
    0x1C: {
        "g_fRoughness", "g_hairR", "g_hairTRT", "g_hairTT",
        "g_nrmMap", "g_nrmMap@ref", "colorMap", "colorMap@ref",
    },
    0x1D: {
        "nrMap", "nrMap@ref", "colorMap", "colorMap@ref",
        "shellFurMap", "shellFurMap@ref", "shellFurDir",
        "shellFurDir@ref",
    },
}


def _prune_implicit_template_defaults(shader_byte, params):
    """Return only the safe shipped baseline from a broad preset dict.

    User JSON and node bindings are applied after this pass, so optional
    fields remain fully authorable; they simply are not emitted by accident.
    """
    allowed = _SAFE_IMPLICIT_TEMPLATE_KEYS.get(int(shader_byte))
    if allowed is None:
        return dict(params or {})
    return {k: v for k, v in (params or {}).items() if k in allowed}


def _resolve_legacy_aliases(params):
    """Bridge legacy preset keys (g_nrmMap@ref) → modern keys (nrMap@ref).

    Mutates ``params`` in place. For each (modern, legacy) pair in
    _LEGACY_ALIAS_MAP, if params has the legacy key set but the modern
    key absent (or null), copy the legacy value into the modern slot.
    The legacy key is left in place so introspection downstream still
    sees both. The writer's data-driven dispatcher reads the modern key.
    """
    for modern, legacy in _LEGACY_ALIAS_MAP.items():
        if modern in params and params[modern] is not None:
            continue
        if legacy in params and params[legacy] is not None:
            params[modern] = params[legacy]


def _sync_substituted_legacy_aliases(params, mat):
    """Refresh canonical ref keys after placeholder substitution.

    Legacy presets still name the character normal binding
    ``g_nrmMap@ref`` while the V6 JMTL writer consumes ``nrMap@ref``.
    ``_resolve_legacy_aliases`` creates that canonical key before the
    placeholder pass, but the pass then recomputes only the legacy hash for
    the current character/attire path.  Without this second synchronization
    the writer serializes the stale preset hash instead of the freshly
    resolved texture hash.

    Explicit ``vc_2k26_params`` refs have already been bridged before
    substitution and must not be replaced here.  A later normalized Blender
    node binding can still overwrite the canonical key as intended.
    """
    explicit_refs = _user_set_ref_keys(mat)
    for modern, legacy in _LEGACY_ALIAS_MAP.items():
        if modern in explicit_refs or legacy in explicit_refs:
            continue
        if legacy in params and params[legacy] is not None:
            params[modern] = params[legacy]

# Map of Principled BSDF socket names → JMTL field names. 2K26 renamed
# the legacy ``g_nrmMap`` slot to plain ``nrMap`` across all character
# shaders — keep the new name here. Other sockets (Roughness, Metallic,
# Specular) don't have universal JMTL counterparts; most templates either
# bake those parameters statically or pack them into an ORM map under a
# template-specific field name, so we map only the two consistent cases.
# Per-template overrides via ``vc_2k26_params`` on the Blender material
# remain the escape hatch for unusual templates.
_SOCKET_TO_JMTL_FIELD = {
    "Base Color": "colorMap@ref",
    "Normal":     "nrMap@ref",   # connects via Normal Map node's Color in
}


def _normalize_texture_bindings(shader_byte, bindings):
    """Translate universal Blender sockets to a shader's actual ref key."""
    out = dict(bindings or {})
    normal_hash = out.get("nrMap@ref")
    if normal_hash is None:
        return out
    target = None
    if int(shader_byte) in (0x01, 0x02, 0x03, 0x1C):
        target = "g_nrmMap@ref"
    elif int(shader_byte) == 0x07:
        target = "normalMap@ref"
    if target:
        out[target] = normal_hash
        out.pop("nrMap@ref", None)
    return out


def _is_environment_export_path(save_path):
    """Recognize arena/prop/weapon exports without changing the public API."""
    parts = {
        part.lower()
        for part in re.split(r"[\\/]+", os.path.abspath(save_path or ""))
        if part
    }
    return bool(parts.intersection({"arena", "arenas", "prop", "props",
                                    "weapon", "weapons"}))

# Characters disallowed in an attire-scope token. Scope becomes a folder
# suffix and a filename suffix; allowing path separators, leading dots,
# or other shell-special chars opens directory traversal and breaks the
# strict 2K26 naming convention (Materials_<scope>/, Attire_<scope>.mtls).
_VALID_SCOPE_RE = re.compile(r"^[A-Za-z0-9_\-]+$")


# ─── Helpers ────────────────────────────────────────────────────────────────

def _sanitize_material_name(raw_name):
    """Strip Blender's ``.001`` duplicate suffix and any ``:variant`` tag.

    Blender automatically appends ``.001``, ``.002`` etc. to material
    names on duplication; these collide with the engine's strict slot
    naming and would produce ``head.001.jmtl`` files the loader can't
    find. We strip the suffix here AND the colon variant the importer
    sometimes attaches (``head:Skinned``) — the .jmtl on disk and the
    name listed in .mtls both use the bare slot name.

    Returns the cleaned name. Empty/None input falls through to a
    safe placeholder so the export doesn't produce a zero-length
    filename downstream.
    """
    if not raw_name:
        return "material"
    name = raw_name
    # Strip ":variant" suffix (case-insensitive — Blender preserves
    # whatever case the import emitted, which is often ``:Skinned`` but
    # occasionally lowercase from manual rename).
    if ":" in name:
        name = name.split(":", 1)[0]
    # Strip trailing ``.NNN`` duplicate marker.
    m = re.match(r"^(.*?)(\.\d{3,})$", name)
    if m:
        name = m.group(1)
    return name or "material"


class _PlaceholderMaterial:
    """Minimal stand-in for a Blender material that doesn't exist in the scene.

    Used when the DLL-canonical material list contains a slot for which we
    can't locate a matching ``bpy.types.Material`` (rare — usually means
    the user renamed in Blender after a previous export, or the slot name
    was added in the DLL by a transferred material table). The orchestrator
    still wants a .jmtl on disk for that slot or the engine will fail to
    resolve it; this placeholder makes the per-material loop's template
    resolution + override-application paths run cleanly against ``None``
    custom-prop reads and an absent node tree (so texture binding is
    skipped and template defaults flow through unmodified).

    Implements the same shape ``_resolve_template`` /
    ``_extract_texture_bindings`` / ``_apply_user_overrides`` consume:
      * ``.name``          — for inference + log lines
      * ``.get(key, dflt)`` — always returns dflt (no overrides)
      * ``.keys()``        — empty iterable
      * ``.node_tree``     — None (skips texture binding)
    """
    __slots__ = ("name", "node_tree")

    def __init__(self, name):
        self.name = name
        self.node_tree = None

    def get(self, key, default=None):
        return default

    def keys(self):
        return ()

    def __contains__(self, key):
        return False


def _validate_scope(scope, errors):
    """Return a sanitized scope string, or empty string if invalid.

    Pushes a human-readable error onto ``errors`` if rejected. Empty
    input is valid and returns empty (= no scope override).
    """
    if not scope:
        return ""
    if not _VALID_SCOPE_RE.match(scope):
        errors.append(
            f"Invalid attire_scope '{scope}': only alphanumeric, "
            f"underscore, and hyphen are allowed. Ignoring scope."
        )
        return ""
    return scope


def _derive_attire_scope_from_materials(ordered_materials, warnings):
    """Derive the export's attire scope from per-material custom props.

    The importer stamps ``vc_2k26_attire_scope`` onto each material when
    its source .jmtl lived in a ``Materials_<scope>/`` folder, and the
    2K26 material panel exposes the same property for editing. Until
    this helper existed the exporter only honored a scene-level key
    that nothing ever wrote — the stamped/edited per-material value was
    silently dropped and re-exports always landed in ``Materials/``.

    Consensus rule: collect every non-empty scope across the materials;
    exactly one distinct value → use it (round-trips the imported
    layout). Zero → no scope (fresh builds). More than one → ambiguous
    (materials mixed in from different attire variants); warn and fall
    back to no scope rather than guess, since a wrong folder suffix is
    harder to notice than a default one.
    """
    scopes = {}
    for slot_name, mat in ordered_materials or []:
        if mat is None:
            continue
        raw = _get_mat_attr(mat, "vc_2k26_attire_scope", "")
        scope = str(raw).strip() if raw else ""
        if scope:
            scopes.setdefault(scope, []).append(
                slot_name or getattr(mat, "name", "?")
            )
    if not scopes:
        return ""
    if len(scopes) > 1:
        listing = "; ".join(
            f"'{scope}' ({', '.join(sorted(names))})"
            for scope, names in sorted(scopes.items())
        )
        warnings.append(
            f"Materials disagree on vc_2k26_attire_scope — {listing}. "
            f"Ignoring all of them; set the scope on every material (or "
            f"clear it) to resolve. Writing to the default Materials/ "
            f"folder."
        )
        return ""
    return next(iter(scopes))


def _parse_template_tag(tag):
    """Parse a ``vc_2k26_template`` string into (shader, type, alias).

    Format: ``<shader>::<type>[::<alias>]`` (e.g. ``yCh_gear::Normal``
    or ``yCh_head::Default::HeadV2``). The two-part form is the common
    case; alias defaults to ``"Default"`` when absent. Returns None on
    malformed input so the caller can fall back to inference.
    """
    if not tag or not isinstance(tag, str):
        return None
    parts = tag.split("::")
    if len(parts) < 2:
        return None
    shader = parts[0].strip()
    type_ = parts[1].strip()
    alias = parts[2].strip() if len(parts) >= 3 and parts[2].strip() else "Default"
    if not shader or not type_:
        return None
    return shader, type_, alias


def _get_mat_attr(mat, key, default=None):
    """Read a custom property off a Blender material, tolerating mocks.

    Real Blender materials expose custom props via ``mat.get(key, default)``;
    our self-test uses a dataclass with the same shape. Both work with a
    plain ``.get`` call — this helper exists only to centralize the
    fallback semantics so a missing ``.get`` (e.g. an unexpected mock
    shape) returns the default instead of raising AttributeError.
    """
    try:
        return mat.get(key, default)
    except Exception:
        return default


def _extract_texture_bindings(mat, save_path, warnings, errors):
    """Walk a material's node tree; return {jmtl_field: u64_hash}.

    For each known Principled BSDF input socket with a connected image
    chain, resolve the image's filepath, compute its mod-root-relative
    .tex FNV1a-64 hash, and key the result by the JMTL field name. The
    Normal socket is special-cased — it usually connects through a
    Normal Map node, so we follow one extra hop to find the image.

    Returns an empty dict for:
      * Materials with ``node_tree is None`` (default Principled BSDF
        only, no nodes added). Caller falls back to template defaults
        and gets a warning logged. This is a legitimate state for
        placeholder materials and should not be treated as an error.
      * Materials with a node tree but no Principled BSDF. Same
        fallback semantics — warning, not error.
      * Image nodes with missing files on disk. We skip the binding
        (so the template default field value is preserved) and log a
        warning so the user knows to relocate the texture.

    Errors (return key absent, push to errors list) are reserved for
    structural problems — exceptions from accessing node properties,
    malformed paths that can't be relativized, etc.
    """
    bindings = {}
    if mat.node_tree is None:
        warnings.append(
            f"Material '{mat.name}': no node tree; using template defaults"
        )
        return bindings

    # Find the Principled BSDF — use the .type identifier rather than the
    # display name, which is locale-dependent (German/French/Japanese
    # Blender translate "Principled BSDF" and break a name lookup).
    bsdf = None
    try:
        for node in mat.node_tree.nodes:
            if getattr(node, "type", None) == "BSDF_PRINCIPLED":
                bsdf = node
                break
    except Exception as e:
        errors.append(f"Material '{mat.name}': node tree walk failed: {e}")
        return bindings

    if bsdf is None:
        warnings.append(
            f"Material '{mat.name}': no Principled BSDF; using template defaults"
        )
        return bindings

    # Resolve mod root once per material — cheap, but the resolver call
    # also covers the no-mod-root case (returns None and our hash falls
    # back to the model-dir-relative path, matching the loader fallback).
    try:
        resolver = _import_jmtl_resolver()
        mod_root = resolver._detect_mod_root(save_path)
        fnv = resolver._fnv1a_64_lower
    except Exception as e:
        errors.append(
            f"Material '{mat.name}': jmtl_resolver unavailable, "
            f"texture hashes will be skipped: {e}"
        )
        return bindings

    for socket_name, jmtl_field in _SOCKET_TO_JMTL_FIELD.items():
        try:
            socket = bsdf.inputs.get(socket_name) if hasattr(bsdf.inputs, "get") else None
            if socket is None:
                # Fall back to index lookup for mocks that expose inputs
                # as a plain dict.
                try:
                    socket = bsdf.inputs[socket_name]
                except (KeyError, TypeError):
                    socket = None
            if socket is None or not getattr(socket, "is_linked", False):
                continue
            # Follow the link to the source node. For Base Color this is
            # usually an Image Texture; for Normal it's a Normal Map node
            # whose Color input is the actual image.
            link = socket.links[0] if socket.links else None
            if link is None:
                continue
            src = link.from_node
            image_node = src
            if getattr(src, "type", None) == "NORMAL_MAP":
                # One hop further — Normal Map's Color input.
                color_in = src.inputs.get("Color") if hasattr(src.inputs, "get") else src.inputs["Color"]
                if color_in and color_in.is_linked and color_in.links:
                    image_node = color_in.links[0].from_node
                else:
                    continue
            if getattr(image_node, "type", None) != "TEX_IMAGE":
                continue
            img = getattr(image_node, "image", None)
            if img is None:
                continue
            filepath = getattr(img, "filepath", "") or ""
            if not filepath:
                warnings.append(
                    f"Material '{mat.name}' socket '{socket_name}': "
                    f"image node has no filepath; skipping"
                )
                continue
            # Resolve relative to mod root. If the file isn't on disk we
            # still produce a hash (the engine looks up by hash, not by
            # presence of the source asset) but warn — common cause is
            # the user packed a texture that was deleted from disk.
            abs_path = bpy_resolve_path(filepath)
            if abs_path and not os.path.exists(abs_path):
                warnings.append(
                    f"Material '{mat.name}' socket '{socket_name}': "
                    f"file not found on disk: {abs_path}"
                )
            tex_path = _texpath_for_hashing(abs_path or filepath, mod_root)
            if tex_path is None:
                # Couldn't relativize — fall through, template default wins.
                warnings.append(
                    f"Material '{mat.name}' socket '{socket_name}': "
                    f"could not derive mod-root-relative path"
                )
                continue
            bindings[jmtl_field] = fnv(tex_path)
        except Exception as e:
            errors.append(
                f"Material '{mat.name}' socket '{socket_name}': "
                f"binding extraction failed: {e}"
            )
            continue

    return bindings


def bpy_resolve_path(filepath):
    """Return an absolute filesystem path for a Blender image filepath.

    Blender stores image paths as ``//relative/path.dds`` (with leading
    ``//`` meaning "relative to the .blend file"). We try to resolve via
    bpy.path.abspath when bpy is available; otherwise we strip the ``//``
    prefix and treat the rest as a plain relative path. The fallback
    matters for the self-test, which runs without bpy.
    """
    if not filepath:
        return filepath
    try:
        import bpy  # noqa: WPS433
        return bpy.path.abspath(filepath)
    except Exception:
        if filepath.startswith("//"):
            return filepath[2:]
        return filepath


def _texpath_for_hashing(abs_path, mod_root):
    """Convert an absolute .dds path to the engine-expected .tex rel-path.

    The engine hashes the lowercase forward-slashed relative path with
    ``.tex`` extension, anchored at the mod root. Returns the path string
    ready to feed into ``_fnv1a_64_lower``, or None if we can't compute
    a meaningful rel-path.
    """
    if not abs_path:
        return None
    try:
        if mod_root:
            rel = os.path.relpath(abs_path, mod_root)
        else:
            # No mod root resolved — fall back to the file's basename
            # under an implicit Textures/ directory. The hash won't match
            # the engine's baked value, but the engine's runtime lookup
            # also falls back on the stem index, so consistency between
            # write and read sides is what matters.
            rel = os.path.join("Textures", os.path.basename(abs_path))
        rel = rel.replace("\\", "/")
        # Swap whatever extension we have for .tex. If there's no extension,
        # append .tex unconditionally.
        root, _ext = os.path.splitext(rel)
        return root + ".tex"
    except (ValueError, TypeError):
        return None


def _call_infer(inference, name, *, is_attire, is_environment=False):
    """Invoke ``infer_template`` with ``is_attire`` if the impl accepts it.

    The orchestrator's self-test injects a mock that historically only
    accepted ``(slot_name)``. Real material_inference.infer_template
    now takes ``(slot_name, *, is_attire=False)``. We try the new
    signature first and fall back on TypeError so existing test mocks
    keep working without modification.
    """
    try:
        return inference.infer_template(
            name, is_attire=is_attire, is_environment=is_environment
        )
    except TypeError:
        try:
            return inference.infer_template(name, is_attire=is_attire)
        except TypeError:
            return inference.infer_template(name)


def _warn_software_default_names(material_names, inference, warnings):
    """Push a WARNING for every cleaned name that looks like a 3D-tool default.

    Catches names like ``lambert1`` (Maya), ``Material.001`` (Blender),
    ``01 - Default`` (3ds Max) that leak through unrenamed. These
    names produce .jmtl files the engine cannot route to a slot and
    have been observed crashing the loader. We warn but do NOT skip
    the write — the user may have a legitimate reason to keep the
    name, or they may want to fix it offline and re-export. The
    warning lists the exact name plus the suggested action.

    Tolerates the inference module being unavailable or missing the
    ``is_software_default_name`` symbol (e.g. when a stub is injected
    by the self-test) — in that case the pass is silently skipped so
    we never block an export over a missing helper.
    """
    if inference is None:
        return
    is_default = getattr(inference, "is_software_default_name", None)
    if not callable(is_default):
        return
    for name in material_names:
        try:
            if is_default(name):
                warnings.append(
                    f"Material '{name}' looks like a software default "
                    f"(Maya/Blender/Max). Rename to the engine slot name "
                    f"(jacket, shoes, hair, etc.) for proper material "
                    f"assignment, or this material may cause an engine crash."
                )
        except Exception:
            # A buggy is_default impl must never abort the export.
            continue


def _normalize_ordered_materials(ordered_materials, inference, warnings):
    """Stable-dedupe MTLS rows and drop software-default placeholders."""
    is_default = getattr(inference, "is_software_default_name", None)
    out = []
    seen = set()
    for slot_name, mat in list(ordered_materials or []):
        clean = _sanitize_material_name(
            slot_name or getattr(mat, "name", None)
        )
        try:
            default_name = bool(callable(is_default) and is_default(clean))
        except Exception:
            default_name = False
        if default_name:
            warnings.append(
                f"Skipped software-default material '{clean}' from MTLS/JMTL output"
            )
            continue
        key = clean.casefold()
        if key in seen:
            warnings.append(
                f"Collapsed duplicate material slot '{clean}' to one MTLS entry"
            )
            continue
        seen.add(key)
        out.append((clean, mat))
    return out


def _resolve_template(mat, errors, *, is_attire=False, is_environment=False):
    """Return (shader_byte, params_dict, is_alpha) for a material.

    Honors the user's explicit ``vc_2k26_template`` override first;
    falls back to slot-name inference. The ``is_attire`` kwarg is
    forwarded to ``infer_template`` so attire-context routing rules
    apply (currently a no-op for every family — see
    material_inference.infer_template docstring — but plumbed so a
    future divergence is a one-line change). Errors are accumulated
    when neither path produces a usable template — caller will skip
    the material entirely in that case (returning None for
    shader_byte).
    """
    templates = _import_material_templates()
    inference = _import_material_inference()

    legacy_tag = _get_mat_attr(mat, "vc_2k26_template", "")
    choice = _get_mat_attr(mat, "vc_2k26_template_choice", "__AUTO__")
    if choice and choice not in ("__AUTO__", "__CUSTOM__"):
        explicit_tag = choice
    else:
        explicit_tag = legacy_tag
    parsed = _parse_template_tag(explicit_tag)
    explicit_alpha = bool(_get_mat_attr(mat, "vc_2k26_alpha", False))

    if parsed is not None:
        shader, type_, alias = parsed
        tmpl = templates.get_template(shader, type_, alias)
        if tmpl is None:
            errors.append(
                f"Material '{mat.name}': template '{explicit_tag}' not "
                f"found in registry; falling back to inference"
            )
            parsed = None  # trigger inference fallthrough

    if parsed is None:
        try:
            shader_byte, shader_name, type_name, inferred_alpha = _call_infer(
                inference, mat.name, is_attire=is_attire,
                is_environment=is_environment,
            )
        except Exception as e:
            errors.append(
                f"Material '{mat.name}': template inference failed: {e}"
            )
            return None, None, False
        is_alpha = explicit_alpha or bool(inferred_alpha)
        params = templates.get_template(shader_name, type_name, "Default")
        if params is None:
            params = templates.get_default_params(shader_byte)
        return shader_byte, dict(params or {}), is_alpha

    # Explicit-template path: tmpl is the resolved dict. We still need
    # the shader_byte — pull it from the template dict if present,
    # otherwise from the registry's get_default_params side channel.
    tmpl_dict = tmpl
    byte_resolver = getattr(templates, "get_shader_byte", None)
    shader_byte = byte_resolver(shader, type_) if callable(byte_resolver) else None
    if shader_byte is None:
        errors.append(
            f"Material '{mat.name}': template '{explicit_tag}' is present "
            f"but its shader is not supported for export; falling back to inference"
        )
        try:
            shader_byte, shader_name, type_name, inferred_alpha = _call_infer(
                inference, mat.name, is_attire=is_attire,
                is_environment=is_environment,
            )
        except Exception:
            return None, None, False
        params = templates.get_template(shader_name, type_name, "Default")
        if params is None:
            params = templates.get_default_params(shader_byte)
        return (
            shader_byte, dict(params or {}),
            explicit_alpha or bool(inferred_alpha),
        )
    # Mix template fields over the shader defaults so any field absent
    # from the template inherits the default.
    params = dict(templates.get_default_params(shader_byte) or {})
    params.update({k: v for k, v in tmpl_dict.items() if not k.startswith("__")})
    if shader_byte == 0x03:
        params["has_refraction"] = "norefract" not in type_.lower()
    return shader_byte, params, explicit_alpha


# ─── XXX placeholder substitution ──────────────────────────────────────────
#
# material_presets.json ships "XXX_<suffix>" placeholder strings (e.g.
# "flowMap": "XXX_flow") plus a pre-computed @ref FNV1a-64 hash of that literal.
# The runtime (materiallink.cpp:190-192 updateMaterialMap) rewrites the XXX_
# prefix to the material SLOT NAME (the .jmtl basename — "hair", "body", not the
# character id; verified against a Cody Rhodes hair_ALPHA whose flowMap@ref
# matched FNV1a of ".../Textures/hair_flow.tex").
#
# But the runtime updates only the STRING fields, not the parallel @ref hash
# storage — so an unbound texture's hash stays at the placeholder (was invisible
# hair in 2K26). This helper runs at EXPORT time doing the same string
# substitution AND recomputing the @ref to match, so the .jmtl ships coherent.
#
# Conservatism: ONLY substitute strings starting with XXX_. Global whitelist
# textures (materiallink.cpp:187 isWhitelistedMap — eye_color, head_translucency)
# and already-substituted / hand-edited strings won't start with XXX_ and are
# left alone.
_XXX_PREFIX = "XXX_"


def _extract_model_id(save_path):
    """Walk up ``save_path`` to find the model_id (character ID) directory.

    The expected save_path tree is::

        <mod_root>/Characters/<model_id>/<scope>/<file>.mcd

    Where ``<scope>`` is one of ``BaseModel``, ``Default_Attire``,
    ``<id>_Attire``, ``<id>_Default_Attire``, or any custom attire folder.
    The ``<model_id>`` is the directory ABOVE that scope.

    Strategy: split the path on the first ``Characters/`` segment (case-
    insensitive) and take the next path component. This handles both
    forward and back slashes via normpath.

    Returns the model_id string (preserving its original case as found
    in the path), or ``None`` if we can't identify it. Caller falls
    through to a no-substitution path on None.

    Example::

        save_path = "C:/.../Characters/1025_Cody_Rhodes/1025_Default_Attire/Attire.mcd"
        -> returns "1025_Cody_Rhodes"
    """
    if not save_path:
        return None
    try:
        normalized = os.path.normpath(save_path).replace("\\", "/")
        parts = normalized.split("/")
        # Walk left-to-right; the first 'Characters' segment marks the boundary.
        for i, part in enumerate(parts):
            if part.lower() == "characters" and i + 1 < len(parts):
                return parts[i + 1]
    except Exception:
        return None
    return None


def _rel_root_from_save_path(save_path):
    """Compute the engine-relative root for textures of a given .mcd save path.

    Returns the path STRING (forward-slashed) from the first known game
    folder (``Characters``, ``Arena``, etc.) down to and including the
    save's *containing directory*. Texture paths are then formed as
    ``<rel_root>/Textures/<texname>.tex``.

    Mirrors ``jmtl_resolver._detect_mod_root`` logic but returns the
    "everything from Characters/ downward, minus the file" portion rather
    than "everything strictly above Characters/".

    Example::

        save_path = "C:/.../Characters/1025_Cody_Rhodes/1025_Default_Attire/Attire.mcd"
        -> returns "Characters/1025_Cody_Rhodes/1025_Default_Attire"

    Returns None if no known game-folder boundary is found in the path.
    """
    if not save_path:
        return None
    # Mirror the same _GAME_FOLDERS set the resolver uses. Duplicated here
    # to keep this helper standalone (resolver isn't imported at module
    # load time — see _import_jmtl_resolver lazy-import).
    game_folders = (
        "characters", "arena", "props", "weapons", "ui", "audio",
        "belts", "crowds", "effects", "lighting", "movies", "rings",
        "textures", "shaders", "models", "materiallibrary",
    )
    try:
        normalized = os.path.normpath(save_path).replace("\\", "/")
        folder = os.path.dirname(normalized)
        parts = folder.split("/")
        for i, part in enumerate(parts):
            if part.lower() in game_folders:
                return "/".join(parts[i:])
    except Exception:
        return None
    return None


def _substitute_template_placeholders(params, slot_name, save_path, warnings=None):
    """Replace ``XXX_<suffix>`` strings with ``<slot>_<suffix>`` and recompute @ref.

    Iterates over every key in ``params``. Three cases are recognized
    (added 2026-05 for the eyelash bug — see Case 2/3 below):

      Case 1 — ``XXX_<suffix>`` placeholder (legacy preset):
        Substitute: ``"XXX_flow"`` -> ``"<slot_name>_flow"``.

      Case 2 — ``<slot_name>_<suffix>`` pre-substituted string (e.g. the
        eyelash preset ships ``g_mEyeOvlPrm = 'eyelash_color'`` with the
        slot name already baked in). Keep the string as-is but RECOMPUTE
        the @ref hash against the current character's texture path so it
        no longer points at whoever's character the JSON was authored
        against.

      Case 3 — value matches ``slot_name`` exactly. Same as Case 2: keep
        verbatim, recompute hash. Covers single-token texture names that
        happen to equal the slot.

    In all three cases:

      1. Compute the virtual texture path:
         ``"<rel_root>/Textures/<final_string>.tex"`` (lowercased during
         hashing).
      2. Compute FNV1a-64 of that path lowercased.
      3. Write back BOTH the (possibly-substituted) string AND the new
         hash:
            params[key] = final_string
            params[key + "@ref"] = new_hash

    Strings matching none of the three cases are left untouched (global engine
    textures like ``eye_color`` that shouldn't be character-specific). ``@ref``
    keys are written but never sourced — the source is always the string key.

    Returns a NEW dict (input not mutated). On internal failure (mod-root,
    hash import) returns an unchanged shallow copy — keeping the template's
    self-consistent hash beats writing a wrong one.

    Args:
        params: dict of {key: value} from template defaults + user
            overrides. Not mutated.
        slot_name: the cleaned material slot name (e.g. ``"hair"``,
            ``"body"``, ``"shoes"``). Lowercased internally to match
            the engine's lowercase texture-path convention.
        save_path: absolute path to the .mcd being written. Used to
            derive the texture rel_root.
        warnings: optional list to append diagnostic messages to.

    Returns:
        A new params dict with placeholders substituted. Always a dict
        — never None.
    """
    if not isinstance(params, dict) or not params:
        return dict(params or {})

    # Take a shallow copy first; downstream callers expect the function
    # to be non-mutating (matches the _apply_user_overrides convention
    # of "build a new dict and reassign").
    out = dict(params)

    if not slot_name:
        return out

    # Lazy-import the resolver's FNV impl. If unavailable, fall back to a
    # local implementation so this helper still works in isolated tests
    # (and matches the resolver's hash exactly — same FNV1a-64 lowercase
    # algorithm).
    try:
        resolver = _import_jmtl_resolver()
        fnv = resolver._fnv1a_64_lower
    except Exception:
        def fnv(s):
            h = 0xCBF29CE484222325
            for ch in s.lower():
                h ^= ord(ch) & 0xFF
                h = (h * 0x100000001B3) & 0xFFFFFFFFFFFFFFFF
            return h

    rel_root = _rel_root_from_save_path(save_path)
    slot_lc = str(slot_name).lower()

    # We have to iterate over a list copy of keys because we may add
    # ``<key>@ref`` entries during the loop.
    for key in list(out.keys()):
        v = out[key]
        if not isinstance(v, str):
            continue
        # Skip @ref keys directly — their value will be (re)written below
        # via the matching string key. We never source a substitution from
        # the @ref side.
        if key.endswith("@ref"):
            continue

        # Decide what the final texture-name string should be. Three cases:
        substituted = None  # set to the FINAL string we hash + write back
        if v.startswith(_XXX_PREFIX):
            # Case 1: classic XXX_<suffix> placeholder. Rewrite prefix.
            suffix = v[len(_XXX_PREFIX):]   # e.g. "flow", "rai", "root"
            substituted = f"{slot_lc}_{suffix}"
        elif v.startswith(f"{slot_lc}_"):
            # Case 2: already begins with the slot name — preset has been
            # pre-substituted for some other character (or shipped that way,
            # e.g. yCh_eyeOv/Eyelash ``g_mEyeOvlPrm = 'eyelash_color'``).
            # Keep the name verbatim but recompute the hash against THIS
            # character's texture path. Without this the JSON's precomputed
            # hash leaks across characters and produces invisible eyelashes.
            substituted = v
        elif v == slot_lc:
            # Case 3: value equals the slot name exactly (single-token
            # texture). Same recompute-for-this-character rationale.
            substituted = v
        else:
            # Anything else (e.g. "eye_color", a global engine texture) is
            # intentionally left alone — those are NOT character-specific.
            continue

        # Build the texture rel-path. rel_root may be None if save_path
        # didn't yield a known game-folder boundary — fall back to a
        # bare Textures/<name>.tex so at least the hash is computable
        # (engine-side fallback may still resolve via stem index).
        if rel_root:
            tex_path = f"{rel_root}/Textures/{substituted}.tex"
        else:
            tex_path = f"Textures/{substituted}.tex"
            if warnings is not None:
                warnings.append(
                    f"_substitute_template_placeholders: no mod-root for "
                    f"'{save_path}', using bare 'Textures/{substituted}.tex' "
                    f"for hash"
                )
        try:
            new_hash = fnv(tex_path)
        except Exception as e:
            if warnings is not None:
                warnings.append(
                    f"_substitute_template_placeholders: hash failed for "
                    f"'{tex_path}': {e}"
                )
            continue
        out[key] = substituted
        out[f"{key}@ref"] = new_hash

    return out


def _strip_never_populate(shader_byte, params):
    """Drop ``@ref`` keys whose slot is in the shader's NEVER_POPULATE set.

    The writer enforces never-populate independently — but the orchestrator
    has its own substitution pass (``_substitute_template_placeholders``)
    that rewrites ``XXX_<suffix>`` strings into character-specific texture
    paths and recomputes the FNV1a-64 hash. For NEVER_POPULATE slots that
    work is wasted (and the resulting hash is meaningless), and worse, the
    @ref value sitting in params could confuse a future caller that
    introspects the dict.

    Belt-and-suspenders for the Triple H 2018 basemodel crash: even if a
    future writer change accidentally honoured the slot, the orchestrator
    has already dropped the bad hash before the writer ever sees it.

    Slot → field-name mapping is derived from jmtl_writer's per-shader
    writers; the canonical name table is below. Both the ``@ref`` key and
    its sibling string key are stripped (so the JMTL doesn't end up with
    a dangling string referring to a deleted hash).

    Returns the SAME dict (mutated in place) for convenience — matches
    the in-place style of ``_apply_user_overrides``.
    """
    # Slot-index → ref-field-name table per shader. Mirrors
    # jmtl_writer._NEVER_POPULATE_U64 (kept here separately to avoid
    # importing writer internals at module load — orchestrator can run
    # against mocks in the self-test where writer internals aren't
    # available).
    _NAMES = {
        0x19: {  # yCh_skin (body)
            2: "muscleMap", 3: "detailzoneMap", 4: "translucencyMap",
        },
        0x17: {  # yCh_head
            0: "detailzoneMap", 2: "facepaint", 3: "g_facepaintNrm",
            4: "flushMap", 7: "translucencyMap",
        },
        0x18: {  # yCh_skinFull
            1: "detailzoneMap", 2: "facepaint", 3: "g_facepaintNrm",
            4: "flushMap",
        },
        0x13: {  # yCh_caruncle
            1: "nrMap", 4: "flushMap",
        },
        0x12: {  # yCh_eye
            1: "EyeInsideTex", 2: "EyeMaskTex",
        },
        0x1A: {  # yCh_Teeth
            2: "translucencyMap", 3: "occlusionMap", 4: "g_mPixMsk",
        },
    }
    table = _NAMES.get(int(shader_byte))
    if not table:
        return params
    for _slot, base in table.items():
        # Drop the placeholder string field too — leaving "muscleMap":
        # "XXX_muscle" in params is harmless to the writer (it only
        # looks at @ref keys) but it shows up in serialized debug dumps
        # and any future serializer that walks the dict would emit
        # corrupted state.
        params.pop(base, None)
        params.pop(f"{base}@ref", None)
    return params


def _user_param_keys(mat):
    """Return every key explicitly supplied through ``vc_2k26_params``."""
    raw = _get_mat_attr(mat, "vc_2k26_params", "")
    if not raw:
        return set()
    decoded = raw
    if isinstance(raw, str):
        try:
            decoded = json.loads(raw)
        except (TypeError, ValueError):
            return set()
    if not isinstance(decoded, dict):
        return set()
    return {k for k in decoded.keys() if isinstance(k, str)}


def _user_set_ref_keys(mat):
    """Return the set of ``*@ref`` keys the user EXPLICITLY set on the material.

    Used by ``_apply_global_texture_hashes`` to skip slots the user has
    already overridden — we never want a harvested global hash to clobber
    a user's intent (e.g. they bound a custom teeth texture and we'd
    otherwise force the universal teeth hash back over it).

    Reads from the material's ``vc_2k26_params`` JSON / dict; everything
    else (Blender node tree, template defaults) is NOT considered "user
    set" for this purpose — those land in params downstream via different
    paths and the global-hash injection runs BEFORE them.
    """
    return {k for k in _user_param_keys(mat) if k.endswith("@ref")}


_SCHEMA_TEXTURE_STEMS = {
    # Eye left/right share one color texture and the engine-global normal.
    0x12: {"colorMap@ref": "eye_color"},
    # Caruncle uses the head color + head normal/subsurface source.  Deriving
    # these from the slot name would incorrectly generate eye_caruncle_color.
    0x13: {
        "colorMap@ref": "head_color",
        "subSurfaceAOMap@ref": "head_nrm",
    },
    0x14: {"colorMap@ref": "eyelash_color"},
}


def _apply_schema_texture_defaults(shader_byte, params, mat, save_path, warnings):
    """Install character-shader texture refs whose stem is not the slot name.

    These are generation defaults, not preserved input.  They make a fresh
    eye/caruncle/eyelash material point at the same canonical texture layout as
    shipped 2K26 basemodels.  Explicit JSON or a later Blender node binding
    still wins.
    """
    mapping = _SCHEMA_TEXTURE_STEMS.get(int(shader_byte))
    if not mapping:
        return
    explicit = _user_param_keys(mat)
    try:
        resolver = _import_jmtl_resolver()
        fnv = resolver._fnv1a_64_lower
    except Exception:
        def fnv(value):
            h = 0xCBF29CE484222325
            for ch in value.lower():
                h ^= ord(ch) & 0xFF
                h = (h * 0x100000001B3) & 0xFFFFFFFFFFFFFFFF
            return h
    rel_root = _rel_root_from_save_path(save_path)
    for ref_key, stem in mapping.items():
        base_key = ref_key[:-4] if ref_key.endswith("@ref") else ref_key
        if ref_key in explicit or base_key in explicit:
            continue
        tex_path = (
            f"{rel_root}/Textures/{stem}.tex" if rel_root
            else f"Textures/{stem}.tex"
        )
        params.pop(base_key, None)
        params[ref_key] = int(fnv(tex_path))
        if not rel_root:
            warnings.append(
                f"No game-folder root found for '{save_path}'; hashed "
                f"schema texture as '{tex_path}'"
            )


def _apply_global_texture_hashes(
    shader_byte, params, mat, warnings,
):
    """Inject vanilla-harvested global texture hashes into params (in place).

    For each (shader, slot) where the vanilla corpus shows ≥80% of
    characters agree on a single u64 hash AND we have ≥5 samples, write
    that hash under the slot's CANONICAL param key (e.g. ``nrMap@ref``)
    so the per-shader writer picks it up. Skips slots where the user has
    explicitly set ANY of the slot's known key aliases — user intent
    always wins over data-driven defaults.

    Belt-and-suspenders for the teeth-comes-in-black bug: vanilla teeth
    ship colorMap@ref = 0x7357EEB9075DF170 on every single character. Our
    pre-fix flow would XXX-substitute to a per-character path that points
    at no real texture in the engine pack; this pass installs the global
    hash first so the substitution loop sees no XXX_* left to rewrite for
    that slot.

    Order matters: this runs AFTER ``_apply_user_overrides`` (so the user
    can opt out by setting the @ref themselves) and BEFORE
    ``_substitute_template_placeholders`` (so the substitution loop's
    Case 1 XXX rewrite doesn't paint over the global hash).

    Safe to call when vanilla_basis isn't importable — returns immediately
    with a single warning if the import fails.
    """
    try:
        vb_mod = _import_vanilla_basis()
    except Exception as e:
        warnings.append(
            f"global texture hash injection unavailable for shader "
            f"0x{shader_byte:02X}: {e}"
        )
        return
    try:
        user_refs = _user_set_ref_keys(mat)
        # Walk every slot the vanilla spec knows about for this shader.
        # _SLOT_TABLE drives the enumeration so we don't accidentally
        # skip a slot that the writer has but the classifier hasn't seen
        # populated samples for (in which case get_global_texture_hash
        # returns None and we no-op for that slot).
        slot_table = getattr(vb_mod, "_SLOT_TABLE", {})
        spec = slot_table.get(int(shader_byte), [])
        for slot_idx, _key, _kind in spec:
            try:
                global_hash = vb_mod.get_global_texture_hash(
                    shader_byte, slot_idx
                )
            except Exception:
                global_hash = None
            # Resolve all the user-facing keys that map to this slot.
            try:
                slot_keys = vb_mod.slot_to_param_keys(shader_byte, slot_idx)
            except Exception:
                slot_keys = []
            if not slot_keys:
                continue
            user_overrode = any(k in user_refs for k in slot_keys)
            # Three states: (A) user set @ref → keep it; (B) global hash → install
            # under the canonical key; (C) neither → leave for the XXX rewrite.
            # A and B both drop the XXX_ string so the substitution loop (which
            # sources from string keys) can't overwrite the @ref.
            if not user_overrode and global_hash is None:
                continue
            for k in slot_keys:
                if k.endswith("@ref"):
                    base = k[:-len("@ref")]
                    v_str = params.get(base)
                    if isinstance(v_str, str) and v_str.startswith("XXX_"):
                        params.pop(base, None)
            if user_overrode:
                # State A: leave the user's @ref alone.
                continue
            # State B: install the global hash under the CANONICAL key.
            # The alias keys are tolerated by the writer via
            # _resolve_aliased; setting the modern key directly keeps
            # the params-dict shape consistent for downstream readers.
            params[slot_keys[0]] = int(global_hash)
    except Exception as e:
        # Defensive: any per-shader failure must NOT abort the export.
        warnings.append(
            f"global texture hash injection partial failure for "
            f"shader 0x{shader_byte:02X}: {e}"
        )


def _strip_data_driven_never_populate(shader_byte, params, warnings):
    """Strip @ref keys whose slot is in the empirically-derived NEVER_POPULATE set.

    Complements ``_strip_never_populate`` (which uses the hand-curated
    table mirrored from the writer). The vanilla harvest provides a
    second NEVER_POPULATE set derived from the actual corpus — if both
    agree, the duplicate strip is a no-op; if the harvest finds new
    never-populate slots the writer hasn't covered yet, this pass
    catches them before they reach the substitution loop.

    The two passes union — anything in EITHER set gets stripped. We
    can't push the harvested set down into the writer without a
    cross-module dependency, but stripping at the orchestrator layer
    is sufficient because the writer's own enforcement is the final
    safety net.

    Safe no-op when the harvest is unavailable.
    """
    try:
        vb_mod = _import_vanilla_basis()
        derived = vb_mod.get_never_populate(int(shader_byte))
    except Exception:
        return params
    if not derived:
        return params
    slot_table = getattr(vb_mod, "_SLOT_TABLE", {})
    spec = slot_table.get(int(shader_byte), [])
    # Build slot_idx → (base_key) for every u64 slot in the spec.
    for slot_idx, key, kind in spec:
        if kind != "u64":
            continue
        if slot_idx not in derived:
            continue
        # key is "<base>@ref" by convention; strip both the @ref hash
        # and the matching string field (the XXX placeholder).
        if key.endswith("@ref"):
            base = key[:-len("@ref")]
        else:
            base = key
        params.pop(base, None)
        params.pop(f"{base}@ref", None)
        # Also strip any alias forms (e.g. g_nrmMap@ref) so a preset
        # that ships under the legacy name doesn't sneak through.
        try:
            aliases = vb_mod.slot_to_param_keys(shader_byte, slot_idx)
        except Exception:
            aliases = []
        for alias_key in aliases:
            if alias_key.endswith("@ref"):
                alias_base = alias_key[:-len("@ref")]
            else:
                alias_base = alias_key
            params.pop(alias_base, None)
            params.pop(f"{alias_base}@ref", None)
    return params


def _apply_user_overrides(params, mat, errors):
    """Overlay JSON ``vc_2k26_params`` overrides onto the params dict.

    User-supplied per-material JSON wins over template defaults but loses
    to texture-binding hashes (applied later). Malformed JSON is logged
    as an error and silently ignored — the user gets the template
    defaults so the export still produces valid materials.
    """
    raw = _get_mat_attr(mat, "vc_2k26_params", "")
    if not raw:
        return
    if isinstance(raw, dict):
        params.update(raw)
        return
    try:
        decoded = json.loads(raw)
    except (TypeError, ValueError) as e:
        errors.append(
            f"Material '{mat.name}': invalid vc_2k26_params JSON: {e}"
        )
        return
    if not isinstance(decoded, dict):
        errors.append(
            f"Material '{mat.name}': vc_2k26_params must be a JSON object"
        )
        return
    params.update(decoded)


def _pick_mtls_filename(model_dir, is_basemodel, attire_scope,
                        is_environment=False, save_path=None):
    """Decide the .mtls filename to write.

    Strategy:
      1. If ``attire_scope`` is set, use the canonical scoped name
         (``baseModel_<scope>.mtls`` or ``Attire_<scope>.mtls``). Scope
         overrides preserve their own naming convention; we never
         pattern-match an existing scoped file.
      2. Otherwise, scan ``model_dir`` for an existing .mtls and prefer
         its exact name (preserves user casing — shipped 2K26 uses
         ``baseModel.mtls``, ``BaseModel.mtls``, ``Attire.mtls`` and
         ``<id>_Attire.mtls`` interchangeably).
      3. Fall back to canonical defaults if nothing matches.

    The pattern match looks for files that LOOK LIKE the right kind
    (contains 'basemodel' for basemodel exports, ends in 'attire' for
    attire exports — both case-insensitive). We accept the first match
    in directory order rather than guessing among multiple, because a
    directory with multiple .mtls files is unusual and the user can
    always pin via attire_scope if they want explicit control.

    Environment exports (arena/prop/weapon) don't follow the
    baseModel/Attire convention: reuse the name of a lone existing
    .mtls (round-trip), else name it after the model file itself
    (``stage.mcd`` → ``stage.mtls``). ``Attire.mtls`` next to an arena
    .mcd was the old, wrong fallback.
    """
    if attire_scope:
        if is_basemodel:
            return f"baseModel_{attire_scope}.mtls"
        return f"Attire_{attire_scope}.mtls"

    # Pattern match existing .mtls in the directory.
    try:
        entries = os.listdir(model_dir)
    except OSError:
        entries = []
    mtls_files = [e for e in entries if e.lower().endswith(".mtls")]

    if is_environment:
        if len(mtls_files) == 1:
            return mtls_files[0]
        stem = os.path.splitext(os.path.basename(save_path or ""))[0]
        return f"{stem or 'model'}.mtls"

    if is_basemodel:
        for entry in mtls_files:
            if "basemodel" in entry.lower():
                return entry
        return "baseModel.mtls"
    # Attire — accept either "attire" or "<id>_attire" (former is
    # the common case for stripped exports, latter for shipped content).
    for entry in mtls_files:
        lower = entry.lower()
        if lower.endswith("attire.mtls"):
            return entry
    return "Attire.mtls"


def _materials_subdir(attire_scope):
    """Return the per-export Materials folder name."""
    if attire_scope:
        return f"Materials_{attire_scope}"
    return "Materials"


# ─── Public API ─────────────────────────────────────────────────────────────

def write_materials_for_export(
    ordered_materials=None,
    save_path=None,
    is_basemodel=None,
    attire_scope="",
    overwrite=True,
    *,
    is_environment=None,
    blender_materials=None,  # DEPRECATED — see backward-compat block below
):
    """Generate .mtls + per-material .jmtl files alongside a saved .mcd.

    See module docstring for the rationale on the split layout.

    Parameters
    ----------
    ordered_materials : list[tuple[str, Optional[bpy.types.Material]]]
        Ordered list of ``(slot_name, bpy_material_or_None)`` tuples — one
        per engine-side material slot, in DLL-CANONICAL order (the same
        order the .mcd's material table writes them, which is what the
        engine pairs face groups against). ``slot_name`` is the cleaned
        engine name (``:Skinned`` / ``.001`` etc. already stripped) and
        is used VERBATIM for the .mtls entry and .jmtl filename. The
        Blender material (if present) supplies textures + custom-prop
        overrides; if ``None``, template defaults are written so the
        slot renders with the engine-default look for its inferred shader.

        The caller is responsible for producing this list from the
        DLL after ``save_to_file`` returns — see
        ``Link/interface_save.py::_collect_materials_in_dll_order``.
    save_path : str
        Full path of the .mcd being saved (e.g.
        ``C:/.../Characters/100_Foo/BaseModel/baseModel.mcd``). Used to
        derive both the .mtls write location (same dir) and the mod root
        for texture-hash relativization.
    is_basemodel : bool
        True for a basemodel export, False for an attire export.
        Controls the default .mtls filename.
    attire_scope : str
        Optional scope token. Non-empty values produce
        ``Materials_<scope>/`` + ``<base>_<scope>.mtls`` so multiple
        scoped material sets can coexist in one folder (used for
        per-attire-variant overrides).
    overwrite : bool
        If False, skip materials whose .jmtl already exists on disk
        (warning logged). The .mtls itself is always written — it's
        cheap to regenerate and the per-slot ordering is the whole
        reason we're here.

    Other Parameters
    ----------------
    is_environment : bool or None
        Explicit arena/prop/weapon context for template inference.
        ``None`` (the default) keeps the historical auto-detection:
        the export is treated as an environment when ``save_path``
        contains a folder named Arena(s)/Prop(s)/Weapon(s). ``True``
        forces arena-style inference (water/glass/illumination/foliage
        tokens, yPBR fallback) regardless of the path; ``False``
        forces character-style inference even under an Arena/ folder.
        Wired from the export dialog's "Preset Context" selector.
    blender_materials : list, DEPRECATED
        Old signature: a flat list of ``bpy.types.Material`` ordered by
        Blender's per-mesh slot walk. This produces .mtls slot indices
        that do NOT agree with the .mcd's material table (the DLL's
        face-group iteration), which causes mis-textured face groups
        in-game (the Triple H 2018 basemodel symptom). New code MUST
        pass ``ordered_materials`` from the DLL query. Old call sites
        that still pass ``blender_materials`` get a warning and the
        list is converted to ``(mat.name, mat)`` tuples; ordering is
        whatever Blender's slot walk produced and therefore may be
        wrong relative to the in-game .mcd. Will be removed in a future
        cleanup pass.

    Returns
    -------
    dict with keys:
        mtls_path : str (empty if .mtls write failed)
        jmtl_paths : list[str]
        warnings : list[str]
        errors : list[str]
        materials_written : int
        materials_skipped : int

    Never raises. Per-material failures are isolated; a single bad
    material does not abort the others. The caller treats a non-empty
    errors list as a hint to surface a notification to the user, but
    the model save still completes.
    """
    warnings = []
    errors = []
    jmtl_paths = []
    materials_written = 0
    materials_skipped = 0

    # ── Backward-compat: convert deprecated blender_materials arg ─────
    # Old call sites passed a flat list of bpy.types.Material in Blender
    # slot order. That order DISAGREES with the .mcd's material table
    # order written by the DLL, so the .mtls slot indices end up paired
    # against the wrong face groups in-game (Triple H 2018 wrong-textures
    # bug). Convert to the new (name, mat) tuple shape so the rest of
    # this function operates on one schema, but emit a loud warning so
    # the caller knows they're using the broken ordering.
    if ordered_materials is None and blender_materials is not None:
        warnings.append(
            "DEPRECATED: write_materials_for_export called with "
            "blender_materials= (Blender slot-walk order). The .mtls "
            "slot indices produced this way do NOT agree with the "
            ".mcd's material table; in-game face groups will pair "
            "against the wrong materials. Switch the call site to "
            "ordered_materials= sourced from the DLL after save_to_file."
        )
        ordered_materials = [
            (_sanitize_material_name(getattr(m, "name", None)), m)
            for m in blender_materials
        ]
    elif ordered_materials is None:
        # Neither kwarg supplied — caller bug. Treat as empty so we still
        # return a well-formed result dict instead of crashing.
        errors.append(
            "write_materials_for_export: no ordered_materials (or "
            "deprecated blender_materials) supplied; nothing to write"
        )
        ordered_materials = []

    attire_scope = _validate_scope(attire_scope, errors)

    # No caller-supplied scope → honor the per-material property the
    # importer stamps (and the material panel edits). See the helper
    # docstring for the consensus rule.
    if not attire_scope:
        derived_scope = _derive_attire_scope_from_materials(
            ordered_materials, warnings
        )
        if derived_scope:
            derived_scope = _validate_scope(derived_scope, errors)
        if derived_scope:
            attire_scope = derived_scope
            warnings.append(
                f"Attire scope '{attire_scope}' derived from the materials' "
                f"vc_2k26_attire_scope property; writing to "
                f"Materials_{attire_scope}/"
            )

    model_dir = os.path.dirname(os.path.abspath(save_path))
    materials_dir = os.path.join(model_dir, _materials_subdir(attire_scope))

    # Ensure target directory exists. ``exist_ok=True`` is the only
    # version-safe way to do this across Python 3.x — predates anything
    # Blender 2.93+ ships.
    try:
        os.makedirs(materials_dir, exist_ok=True)
    except OSError as e:
        errors.append(
            f"Could not create materials directory '{materials_dir}': {e}"
        )
        return {
            "mtls_path": "",
            "jmtl_paths": [],
            "warnings": warnings,
            "errors": errors,
            "materials_written": 0,
            "materials_skipped": 0,
        }

    # Lazy-import the writers/templates/inference modules once so an
    # ImportError surfaces as a single error rather than once per material.
    try:
        write_jmtl = _import_jmtl_writer()
    except Exception as e:
        errors.append(f"jmtl_writer unavailable: {e}")
        write_jmtl = None
    try:
        write_mtls = _import_mtls_writer()
    except Exception as e:
        errors.append(f"mtls_writer unavailable: {e}")
        write_mtls = None
    try:
        inference = _import_material_inference()
    except Exception as e:
        errors.append(f"material_inference unavailable: {e}")
        inference = None

    # V6 MTLS stores one entry per unique engine material name. Normalize
    # even when the caller came through the deprecated Blender-slot path.
    ordered_materials = _normalize_ordered_materials(
        ordered_materials, inference, warnings,
    )

    # ── Pre-pass: scan slot names for software defaults ────────────────
    # Warn early — before we open any files — so the user sees the
    # message clearly in the export log even if a later per-material
    # failure scrolls past the loop output. The DLL-canonical slot name
    # is already cleaned of ``.001`` / ``:Skinned`` so we can scan as-is.
    _cleaned_for_scan = [slot for slot, _ in ordered_materials]
    _warn_software_default_names(_cleaned_for_scan, inference, warnings)

    # ── Per-material loop ──────────────────────────────────────────────
    material_names_for_mtls = []

    # File-write dedup: when the DLL lists a slot name twice (two mouthbag
    # meshes), the .mtls mirrors both but only ONE .jmtl is written (both
    # reference it). materials_written still increments and jmtl_paths records
    # the path twice, preserving the slot-to-file mapping.
    written_jmtl_basenames = set()

    # is_attire is the inverse of is_basemodel; forwarded to template resolution
    # for attire-context routing rules.
    is_attire_export = not is_basemodel
    # Explicit caller context wins; None keeps the path-based heuristic.
    is_environment_export = (
        _is_environment_export_path(save_path)
        if is_environment is None
        else bool(is_environment)
    )

    for slot_name, mat in ordered_materials:
        try:
            # Use the DLL-provided slot name verbatim — the material table is
            # ground truth for what the engine pairs face-group material_index
            # against. Re-sanitizing off the Blender name was the old bug (wrote
            # mouthbag.001 that didn't match the .mcd).
            clean_name = slot_name or _sanitize_material_name(
                getattr(mat, "name", None) if mat else None
            )
            material_names_for_mtls.append(clean_name)

            if write_jmtl is None or inference is None:
                materials_skipped += 1
                continue

            # No Blender material backing this slot — write template defaults
            # only. The DLL listed it (inherited import, or a name our collector
            # couldn't match), so a .jmtl must exist or the engine fails to
            # resolve it at link time. Use a stand-in so the template path runs.
            if mat is None:
                mat = _PlaceholderMaterial(clean_name)
                warnings.append(
                    f"Material slot '{clean_name}': no matching Blender "
                    f"material; writing template defaults only"
                )

            # Resolve template + parameter defaults.
            shader_byte, params, is_alpha = _resolve_template(
                mat, errors, is_attire=is_attire_export,
                is_environment=is_environment_export,
            )
            if shader_byte is None or params is None:
                materials_skipped += 1
                continue

            # A preset describes the broad editor vocabulary, including many
            # optional fields that shipped JMTLs leave absent.  Reduce it to
            # the schema-safe new-material baseline before applying harvested
            # values, explicit JSON, or Blender texture bindings.
            params = _prune_implicit_template_defaults(shader_byte, params)

            # Vanilla basis overlay: per-character non-texture params harvested
            # from the 2K26 corpus. Lands BEFORE _apply_user_overrides (user JSON
            # still wins) and BEFORE _substitute_template_placeholders (texture
            # overlays still win for refs). Without it every character gets the
            # generic template's single skin tone / float set (wrong shading even
            # with correct textures, since e.g. Triple H's AO tint ≠ Rock's).
            # Graceful: import/lookup failure → empty dict → no-op overlay.
            character_id = _extract_model_id(save_path)
            if character_id:
                try:
                    vb_mod = _import_vanilla_basis()
                    vanilla_params = vb_mod.get_vanilla_basis(
                        character_id, shader_byte
                    )
                    if vanilla_params:
                        # Vanilla basis wins over the generic template
                        # (it's specifically the character-tuned variant
                        # of the same defaults). But it must NOT override
                        # texture-ref keys (those get re-substituted /
                        # re-hashed below) — vanilla_basis already skips
                        # u64 slots, but defend in depth: drop any
                        # ``@ref`` key from the overlay anyway.
                        for key, value in vanilla_params.items():
                            if key.endswith("@ref"):
                                continue
                            params[key] = value
                except Exception as e:
                    # One warning per export is plenty — but we don't have
                    # a per-export sentinel here, so use the warnings list
                    # to push a single message that names the failure.
                    warnings.append(
                        f"vanilla_basis overlay unavailable for "
                        f"'{character_id}' / shader 0x{shader_byte:02X}: {e}"
                    )

            # Layer user overrides (JSON property) on top of defaults.
            _apply_user_overrides(params, mat, errors)

            # Resolve legacy alias keys (g_nrmMap@ref → nrMap@ref) before
            # any downstream substitution / global-hash injection. After
            # this pass, the orchestrator and writer can both look up
            # the modern canonical key without per-shader alias bridging.
            _resolve_legacy_aliases(params)

            # Some basemodel shaders intentionally share texture stems rather
            # than deriving them from the material slot (eye_l -> eye_color,
            # eye_caruncle -> head_color/head_nrm).  Install those generation
            # defaults now; explicit JSON is respected and node bindings still
            # overlay later.
            _apply_schema_texture_defaults(
                shader_byte, params, mat, save_path, warnings,
            )

            # Strip template-default @ref keys for slots vanilla NEVER populates
            # (Triple H 2018 basemodel-crash culprit: presets ship placeholder
            # hashes like FNV("XXX_muscle") for body.muscleMap@ref that no
            # vanilla file uses; substituting them → FNV("body_muscle.tex") →
            # nonexistent texture → crash). The writer enforces this too; this is
            # belt-and-suspenders so the bad keys never enter substitution.
            params = _strip_never_populate(shader_byte, params)

            # Also apply the harvest-derived NEVER_POPULATE set — catches
            # shaders/slots the hardcoded table hasn't been updated for. No-op
            # when the harvest is unavailable.
            params = _strip_data_driven_never_populate(
                shader_byte, params, warnings
            )

            # Inject vanilla-harvested global texture hashes BEFORE substitution.
            # For (shader, slot) pairs shipping the SAME u64 on ≥80% of vanilla
            # characters (teeth colorMap, eye nrMap, ...) use that hash directly;
            # otherwise the XXX-rewrite produces a per-character path that doesn't
            # resolve (slot renders black). User @ref overrides suppress it.
            _apply_global_texture_hashes(
                shader_byte, params, mat, warnings,
            )

            # Substitute XXX_<suffix> placeholders to the slot-prefixed form and
            # RECOMPUTE the @ref hashes. The runtime's materiallink.cpp does this
            # for strings but leaves the parallel @ref storage at the placeholder
            # (was invisible hair in 2K26). Done BEFORE texture binding so a real
            # Blender-bound @ref still wins. See the helper docstring.
            params = _substitute_template_placeholders(
                params, clean_name, save_path, warnings=warnings
            )

            # Placeholder substitution recomputes legacy texture refs such as
            # g_nrmMap@ref for the current character.  Refresh the canonical
            # alias the V6 writer reads, otherwise it would serialize the stale
            # pre-substitution preset hash for body/head/gear normals.
            _sync_substituted_legacy_aliases(params, mat)

            # Extract texture bindings from the node tree and overlay them
            # — bindings always win over template defaults and user
            # overrides, because they reflect what the user has actually
            # wired up in Blender and is the source of truth for textures.
            bindings = _extract_texture_bindings(mat, save_path, warnings, errors)
            bindings = _normalize_texture_bindings(shader_byte, bindings)
            params.update(bindings)

            # Imported Blender node graphs can contain character-local image
            # paths for engine-global textures (most importantly eye_nrm).
            # Node extraction would hash that local path and overwrite the
            # universal 2K26 binding installed above. Re-apply statistically
            # universal hashes after node bindings; explicit vc_2k26_params
            # remains the supported opt-out and is still respected here.
            _apply_global_texture_hashes(
                shader_byte, params, mat, warnings,
            )

            # Gear shader + alpha variant: set the variant byte. The
            # exact key the writer expects ("variant" vs "shaderVariant"
            # vs a positional byte) is up to jmtl_writer; we use the
            # conventional 'variant' field name and let the writer
            # ignore it on shaders that don't expose the slot.
            if (shader_byte == _SHADER_GEAR and is_alpha
                    and "variant" not in params):
                params["variant"] = 1

            # Generate the JMTL filename via the inference module so
            # it stays consistent with the import-side resolver.
            try:
                jmtl_basename = inference.get_jmtl_filename(clean_name)
            except Exception as e:
                warnings.append(
                    f"Material '{mat.name}': get_jmtl_filename failed ({e}); "
                    f"using fallback '{clean_name}.jmtl'"
                )
                jmtl_basename = clean_name + ".jmtl"

            jmtl_path = os.path.join(materials_dir, jmtl_basename)

            # Same slot name twice → same .jmtl, already written on first
            # encounter. Count as covered, skip the redundant write (same slot +
            # template + textures = byte-identical, so nothing is lost).
            if jmtl_basename in written_jmtl_basenames:
                jmtl_paths.append(jmtl_path)
                materials_written += 1
                continue

            if not overwrite and os.path.exists(jmtl_path):
                warnings.append(
                    f"Material '{mat.name}': {jmtl_path} exists and "
                    f"overwrite=False; skipping"
                )
                materials_skipped += 1
                continue

            try:
                jmtl_bytes = write_jmtl(shader_byte, params)
            except Exception as e:
                errors.append(
                    f"Material '{mat.name}': jmtl_writer.write_jmtl raised: {e}"
                )
                materials_skipped += 1
                continue

            try:
                with open(jmtl_path, "wb") as f:
                    f.write(jmtl_bytes)
            except OSError as e:
                errors.append(
                    f"Material '{mat.name}': could not write {jmtl_path}: {e}"
                )
                materials_skipped += 1
                continue

            written_jmtl_basenames.add(jmtl_basename)
            jmtl_paths.append(jmtl_path)
            materials_written += 1

        except Exception as e:
            # Catch-all per material — never let one bad material kill
            # the rest of the export.
            errors.append(
                f"Material '{getattr(mat, 'name', '<unknown>')}': "
                f"unexpected failure: {e}"
            )
            materials_skipped += 1
            continue

    # ── .mtls wrapper ──────────────────────────────────────────────────
    mtls_filename = _pick_mtls_filename(
        model_dir, is_basemodel, attire_scope,
        is_environment=is_environment_export, save_path=save_path,
    )
    mtls_path = os.path.join(model_dir, mtls_filename)

    if write_mtls is None:
        # Errors already logged. Return partial result so the caller
        # can still proceed with the model write.
        return {
            "mtls_path": "",
            "jmtl_paths": jmtl_paths,
            "warnings": warnings,
            "errors": errors,
            "materials_written": materials_written,
            "materials_skipped": materials_skipped,
        }

    if not overwrite and os.path.exists(mtls_path):
        warnings.append(
            f"{mtls_path} exists and overwrite=False; skipping .mtls write"
        )
        return {
            "mtls_path": mtls_path,
            "jmtl_paths": jmtl_paths,
            "warnings": warnings,
            "errors": errors,
            "materials_written": materials_written,
            "materials_skipped": materials_skipped,
        }

    try:
        # Pass save_path through so writer implementations that want
        # to log or co-locate auxiliary data have the context. Writers
        # that don't accept the kwarg will TypeError — fall back to
        # the positional-only form.
        try:
            mtls_bytes = write_mtls(material_names_for_mtls, save_path=mtls_path)
        except TypeError:
            mtls_bytes = write_mtls(material_names_for_mtls)
        with open(mtls_path, "wb") as f:
            f.write(mtls_bytes)
    except Exception as e:
        errors.append(f"Could not write {mtls_path}: {e}")
        mtls_path = ""

    return {
        "mtls_path": mtls_path,
        "jmtl_paths": jmtl_paths,
        "warnings": warnings,
        "errors": errors,
        "materials_written": materials_written,
        "materials_skipped": materials_skipped,
    }


# ─── Self-test ──────────────────────────────────────────────────────────────

def _self_test():
    """Smoke-test the orchestrator without bpy and without the real deps.

    Builds mock dependency modules (jmtl_writer, mtls_writer,
    material_templates, material_inference, jmtl_resolver) and injects
    them into sys.modules so the lazy imports inside the orchestrator
    pick them up. Then runs the orchestrator on a list of 8 stand-in
    materials representing the standard basemodel slot set and verifies:

      * No exception escapes the orchestrator.
      * Exactly 8 .jmtl files are written + 1 .mtls = 9 files in the
        tempdir tree.
      * The .mtls bytes start with the JSFB magic ``b'MTLs\\x06\\x00\\x00\\x00'``.

    Returns True on PASS, False on FAIL (with diagnostic prints).
    """
    import sys
    import tempfile
    import types
    from dataclasses import dataclass, field
    from typing import Any, Dict

    # ── Build mock modules ─────────────────────────────────────────
    # We install these as submodules of the real packages so the
    # ``from .jmtl_writer import ...`` style imports inside the
    # orchestrator find them. The real submodules don't exist yet
    # (other agents are writing them), so installing mocks under the
    # same names is the cleanest way to fake them.

    pkg = __package__  # 'WWE2K_MDL.Serialize' or similar
    if not pkg:
        # Running the module file directly with `python material_export.py`
        # — set a placeholder package path so the relative-import resolution
        # below can synthesize the parent chain. The mocks live entirely in
        # sys.modules and don't need real files on disk.
        pkg = "WWE2K_MDL.Serialize"

    parent_pkg = pkg.rsplit(".", 1)[0]  # 'WWE2K_MDL'

    def _mock_module(name):
        mod = types.ModuleType(name)
        sys.modules[name] = mod
        return mod

    # jmtl_writer mock — returns a tiny JSFB-like blob keyed by inputs.
    jw = _mock_module(f"{pkg}.jmtl_writer")
    def _mock_write_jmtl(shader_byte, params):
        return b"JMTL" + bytes([shader_byte]) + b"\x00" * 3 + b"{params}"
    jw.write_jmtl = _mock_write_jmtl

    # mtls_writer mock — returns the canonical 8-byte header the real
    # writer should produce, plus a body that just lists names.
    mw = _mock_module(f"{pkg}.mtls_writer")
    def _mock_write_mtls(material_names, save_path=None):
        body = b"\n".join(n.encode("utf-8") for n in material_names)
        return b"MTLs\x06\x00\x00\x00" + body
    mw.write_mtls = _mock_write_mtls

    # material_templates mock.
    mt = _mock_module(f"{pkg}.material_templates")
    def _mock_get_default_params(shader_byte):
        return {"shader_byte": shader_byte, "colorMap@ref": 0xFFFFFFFFFFFFFFFF}
    def _mock_get_template(shader, type_, alias="Default"):
        return {"__shader_byte__": 0x15, "alias": alias}
    mt.get_default_params = _mock_get_default_params
    mt.get_template = _mock_get_template

    # Blender.Extras.material_inference mock — must live under
    # WWE2K_MDL.Blender.Extras.material_inference so the relative
    # `from ..Blender.Extras import material_inference` resolves.
    # We synthesize the package chain if it isn't present.
    blender_pkg_name = f"{parent_pkg}.Blender"
    extras_pkg_name = f"{parent_pkg}.Blender.Extras"
    for chain_name in (parent_pkg, blender_pkg_name, extras_pkg_name):
        if chain_name not in sys.modules:
            chain_mod = types.ModuleType(chain_name)
            chain_mod.__path__ = []  # mark as package
            sys.modules[chain_name] = chain_mod

    mi = _mock_module(f"{extras_pkg_name}.material_inference")
    _SLOT_TO_SHADER = {
        "head": 0x17, "body": 0x19, "eye_l": 0x12, "eye_r": 0x12,
        "eyelash": 0x14, "teeth": 0x1A, "hair": 0x16, "gear": 0x15,
    }
    def _mock_infer_template(slot_name, *, is_attire=False):
        # is_attire accepted to match the real signature; mock currently
        # ignores it since the per-family table here is flat.
        clean = slot_name.split(":")[0].lower()
        shader_byte = _SLOT_TO_SHADER.get(clean, 0x15)
        return shader_byte, "Default", "Default", False
    def _mock_get_jmtl_filename(name):
        return _sanitize_material_name(name) + ".jmtl"
    def _mock_normalize_slot_name(name):
        return _sanitize_material_name(name).lower()
    def _mock_is_software_default_name(name):
        if not name:
            return False
        low = name.lower()
        # Strip Blender's .NNN suffix to match the real impl.
        import re as _re
        low = _re.sub(r"\.\d{3,}$", "", low).strip()
        if low in {"material", "defaultmat", "default_obj",
                   "standard", "physicalmaterial"}:
            return True
        for stem in ("lambert", "blinn", "phong"):
            if low == stem or (low.startswith(stem) and low[len(stem):].isdigit()):
                return True
        return False
    mi.infer_template = _mock_infer_template
    mi.get_jmtl_filename = _mock_get_jmtl_filename
    mi.normalize_slot_name = _mock_normalize_slot_name
    mi.is_software_default_name = _mock_is_software_default_name

    # jmtl_resolver mock — only need _detect_mod_root and _fnv1a_64_lower.
    jr = _mock_module(f"{extras_pkg_name}.jmtl_resolver")
    def _mock_detect_mod_root(path):
        return None
    def _mock_fnv1a(s):
        h = 0xCBF29CE484222325
        for ch in s.lower():
            h ^= ord(ch) & 0xFF
            h = (h * 0x100000001B3) & 0xFFFFFFFFFFFFFFFF
        return h
    jr._detect_mod_root = _mock_detect_mod_root
    jr._fnv1a_64_lower = _mock_fnv1a

    # ── Build mock material stand-ins ──────────────────────────────
    @dataclass
    class MockMaterial:
        name: str
        _props: Dict[str, Any] = field(default_factory=dict)
        node_tree: Any = None
        def get(self, key, default=None):
            return self._props.get(key, default)

    # 8 well-formed slots + 1 deliberate software-default leak. The
    # lambert1 entry exercises the suspicious-name warning pass added
    # in response to a real crash where a Maya-imported attire shipped
    # with the default material name unrenamed.
    slots = ["head", "body", "eye_l", "eye_r", "eyelash", "teeth", "hair", "gear"]
    materials = [MockMaterial(name=s) for s in slots]
    materials.append(MockMaterial(name="lambert1"))

    # ── Run orchestrator ───────────────────────────────────────────
    with tempfile.TemporaryDirectory() as tmpdir:
        save_path = os.path.join(tmpdir, "baseModel.mcd")
        # Touch the file so dirname() resolves cleanly.
        open(save_path, "wb").close()

        # New DLL-order signature: pass (slot_name, mat) tuples in the
        # order the .mcd's material table would list them. For the
        # self-test we just mirror the materials list 1:1 since there's
        # no real DLL in play.
        ordered = [(m.name, m) for m in materials]
        result = write_materials_for_export(
            ordered_materials=ordered,
            save_path=save_path,
            is_basemodel=True,
            attire_scope="",
            overwrite=True,
        )

        # ── Assertions ─────────────────────────────────────────────
        # We feed 9 materials: 8 real slots + 1 lambert1 default-name
        # leak. The default leak still writes (warning-only) so the
        # written count is 9, not 8.
        problems = []

        if result["materials_written"] != 9:
            problems.append(
                f"expected 9 materials_written, got {result['materials_written']}"
            )
        if len(result["jmtl_paths"]) != 9:
            problems.append(
                f"expected 9 jmtl_paths, got {len(result['jmtl_paths'])}"
            )
        if not result["mtls_path"]:
            problems.append("mtls_path empty (write failed)")

        # The pre-pass must emit a warning naming 'lambert1' explicitly.
        if not any("lambert1" in w and "software default" in w.lower()
                   for w in result["warnings"]):
            problems.append(
                "expected a software-default warning for 'lambert1' in "
                f"warnings, got: {result['warnings']}"
            )

        # Count files on disk.
        written_files = []
        for root, _dirs, files in os.walk(tmpdir):
            for fn in files:
                written_files.append(os.path.join(root, fn))
        # Expected on disk: 9 .jmtl (8 real + 1 lambert1 default-leak
        # that still writes after the warning) + 1 .mtls = 10 files,
        # excluding the touched .mcd placeholder.
        material_files = [
            f for f in written_files
            if f.lower().endswith((".jmtl", ".mtls"))
        ]
        if len(material_files) != 10:
            problems.append(
                f"expected 10 material files on disk, got {len(material_files)}: "
                f"{material_files}"
            )

        # Verify .mtls header.
        try:
            with open(result["mtls_path"], "rb") as f:
                head = f.read(8)
            if head != b"MTLs\x06\x00\x00\x00":
                problems.append(
                    f"mtls header mismatch: {head!r} != b'MTLs\\x06\\x00\\x00\\x00'"
                )
        except OSError as e:
            problems.append(f"could not read mtls back: {e}")

        if result["errors"]:
            # Errors are not necessarily a test fail (e.g. textures
            # legitimately missing) — but in this controlled self-test
            # we don't expect any.
            problems.append(f"unexpected errors: {result['errors']}")

        if problems:
            print("[material_export self-test] FAIL")
            for p in problems:
                print(f"  - {p}")
            print(f"  result = {result}")
            return False
        print("[material_export self-test] PASS")
        print(f"  wrote {result['materials_written']} jmtls, "
              f"mtls at {result['mtls_path']}")
        print(f"  warnings: {len(result['warnings'])} "
              f"(1+ expected for lambert1 default-name leak)")

        # ─── _substitute_template_placeholders unit tests ───────────────
        # Verifies the new XXX-substitution helper:
        #   1. rewrites "XXX_flow" -> "<slot>_flow" for a hair material
        #   2. produces a recomputed hash that DIFFERS from the input
        #      (pre-substitution) hash
        #   3. leaves non-XXX strings entirely alone
        sub_problems = []

        hair_save = os.path.join(
            tmpdir, "Characters", "1025_Cody_Rhodes",
            "1025_Default_Attire", "Attire.mcd",
        )
        # Synthesize the model_id directory tree so _rel_root_from_save_path
        # picks up "Characters/1025_Cody_Rhodes/1025_Default_Attire".
        os.makedirs(os.path.dirname(hair_save), exist_ok=True)

        original_hash = 0xDA06F002ED882094  # placeholder bug-context hash
        in_params = {
            "flowMap": "XXX_flow",
            "flowMap@ref": original_hash,
            "g_comboMap": "XXX_rai",
            "g_comboMap@ref": 0xDEADBEEFDEADBEEF,
            "untouched_string": "engine_default_eye_color",
            "untouched_hash": 0x1234567890ABCDEF,
            "non_string_field": 3.14,
        }
        out = _substitute_template_placeholders(
            in_params, "hair", hair_save, warnings=[]
        )

        # 1. Substitution
        if out.get("flowMap") != "hair_flow":
            sub_problems.append(
                f"flowMap substitution failed: {out.get('flowMap')!r}"
            )
        if out.get("g_comboMap") != "hair_rai":
            sub_problems.append(
                f"g_comboMap substitution failed: {out.get('g_comboMap')!r}"
            )

        # 2. Recomputed hash differs from input AND matches the expected
        # vanilla hash for hair_flow.tex under the Cody attire path.
        # The expected hash was verified against vanilla
        # Cody Rhodes 1025_Default_Attire/Materials/hair_ALPHA.jmtl,
        # which stores 0x8C0999182F80855B for flowMap@ref.
        expected_flow_hash = 0x8C0999182F80855B
        if out.get("flowMap@ref") == original_hash:
            sub_problems.append(
                f"flowMap@ref was not recomputed (still {original_hash:#018x})"
            )
        if out.get("flowMap@ref") != expected_flow_hash:
            sub_problems.append(
                f"flowMap@ref recomputed to {out.get('flowMap@ref'):#018x}, "
                f"expected vanilla {expected_flow_hash:#018x}"
            )

        # 3. Non-XXX strings untouched.
        if out.get("untouched_string") != "engine_default_eye_color":
            sub_problems.append(
                f"untouched_string was modified: {out.get('untouched_string')!r}"
            )
        if out.get("untouched_hash") != 0x1234567890ABCDEF:
            sub_problems.append(
                f"untouched_hash was modified: {out.get('untouched_hash')!r}"
            )
        if out.get("non_string_field") != 3.14:
            sub_problems.append(
                f"non_string_field was modified: {out.get('non_string_field')!r}"
            )

        # Input must not be mutated.
        if in_params.get("flowMap") != "XXX_flow":
            sub_problems.append(
                "_substitute_template_placeholders mutated input dict"
            )

        if sub_problems:
            print("[material_export self-test] SUB FAIL")
            for p in sub_problems:
                print(f"  - {p}")
            return False
        print("[material_export self-test] substitution PASS "
              f"(flowMap@ref recomputed {original_hash:#018x} -> "
              f"{out['flowMap@ref']:#018x})")
        return True


if __name__ == "__main__":
    import sys
    sys.exit(0 if _self_test() else 1)
