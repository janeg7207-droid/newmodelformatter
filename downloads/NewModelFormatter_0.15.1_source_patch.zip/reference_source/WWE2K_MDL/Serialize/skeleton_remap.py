"""
Cross-version skeleton constants (2K25 ↔ 2K26).

Only the constants and a disabled stub of `remap_skeleton_for_export()`
remain in this file. The bulk implementation (detection, attire path,
basemodel template transfer, armature swap, weight transfer, etc.) was
pulled from the shipping build — it was false-positiving on v2.15 (0x2F)
MCD files whose 2K25-era bones triggered the remap path, corrupting
models that should have been left untouched. The full implementation is
archived in version control (it last lived at
`Serialize/_disabled/skeleton_remap_logic.py`) for potential revival.

What's still live here:
    - BONES_ONLY_IN_25, BONES_ONLY_IN_26, RENAME_25_TO_26 — imported by
      `Blender/blender_save.py` (see line ~51) for skeleton-version
      awareness in the save path.
    - `remap_skeleton_for_export(compile_target)` — DISABLED stub that
      returns False. Kept so any caller that still imports the name
      (none today, but historically yes) continues to import cleanly
      instead of raising AttributeError.

To revive the remap pipeline:
    1. Restore the helpers from version control into this file (or split
       them across new modules under Serialize/).
    2. Fix the root cause of the version-detection false positives on
       v2.15 / 0x2F MCDs.
    3. Replace the stub below with the real entry point.
    4. Re-validate every call site in the export pipeline.

The two other constant sets (FACE_BONES, BASEMODEL_MESHES) and
TEMPLATE_FILENAME are NOT re-exported here because nothing in the active
addon imports them — they lived alongside the archived implementation.
"""

BONES_ONLY_IN_25 = {
    'H_Bicep_L', 'H_Bicep_R', 'H_Delt_Back_L', 'H_Delt_Back_R',
    'H_Delt_Front_L', 'H_Delt_Front_R', 'H_Delt_L_OS01', 'H_Delt_R_OS01',
    'H_Delt_Top_L', 'H_Delt_Top_R', 'H_Ebw_In_L', 'H_Ebw_In_R',
    'H_Lat_L', 'H_Lat_R', 'H_Pec_L', 'H_Pec_R',
}

BONES_ONLY_IN_26 = {
    'H_Pec_L_1', 'H_Pec_L_2', 'H_Pec_L_3',
    'H_Lat_L_1', 'H_Lat_L_2', 'H_Lat_L_3',
    'H_Delt_L_1', 'H_Delt_L_2',
    'H_Bicep_L_1', 'H_Shld_Pad_L',
    'H_Neck_L_1', 'H_Neck_L_2',
}

RENAME_25_TO_26 = {
    'H_Delt_L_OS01': 'H_Delt_L_1',
    'H_Delt_R_OS01': 'H_Delt_R_1',
    'H_Bicep_L':     'H_Bicep_L_1',
    'H_Bicep_R':     'H_Bicep_R_1',
}


def remap_skeleton_for_export(compile_target):
    # ── DISABLED — full implementation archived in version control ──────
    # The full implementation (last at
    # `Serialize/_disabled/skeleton_remap_logic.py`) is NOT shipped. The
    # version-detection step was false-positiving on v2.15 (0x2F) MCD
    # files whose 2K25-era bones triggered the remap path, corrupting
    # models that should have been left untouched. This stub returns
    # False so the export pipeline behaves as if remap is opted out —
    # exactly what the previous in-place disable already did.
    # ─────────────────────────────────────────────────────────────────────
    return False
