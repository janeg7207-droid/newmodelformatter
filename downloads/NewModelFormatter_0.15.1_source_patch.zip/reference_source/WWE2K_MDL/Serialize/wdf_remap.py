"""
WDF Vertex Index Remapper

Parses WDF files, remaps triangle vertex indices using an old→new mapping,
and writes the updated WDF. This fixes beard/facial deformation after 
roundtripping MCD meshes through Blender, which reorders vertices.

WDF Entry Format (48 bytes per entry):
  Bytes  0-15: Barycentric/weight data     (preserved)
  Bytes 16-31: Distance/weight scalars      (preserved)
  Bytes 32-39: Triangle 1 indices (4x uint16, first 3 are vertex indices)
  Bytes 40-47: Triangle 2 indices (4x uint16, first 3 are vertex indices)
"""

import struct
import os
from ..Link.log import dlog


def parse_wdf(filepath):
    """Parse a WDF file into header + list of meshes with raw entry data.
    
    Format:
      "WDF!" (4) + version (4)
      Repeated MESH blocks:
        "MESH" (4) + name_length (4) + name (padded) + entry_count (4) + entries (N*48)
      "END!" (4) + padding (4)
    """
    with open(filepath, 'rb') as f:
        data = f.read()

    if len(data) < 8:
        raise ValueError(f"WDF too small: {len(data)} bytes")

    pos = 0

    # Header
    magic = data[pos:pos+4]; pos += 4
    if magic != b'WDF!':
        raise ValueError(f"Not a WDF file (magic: {magic})")
    
    version = struct.unpack_from('<I', data, pos)[0]; pos += 4

    meshes = []

    while pos < len(data) - 4:
        tag = data[pos:pos+4]; pos += 4

        if tag == b'END!':
            break
        
        if tag != b'MESH':
            raise ValueError(f"Expected MESH or END! tag at offset {pos-4}, got {tag}")

        # Name length + name
        name_len = struct.unpack_from('<I', data, pos)[0]; pos += 4
        
        if name_len > 256:
            raise ValueError(f"WDF mesh name too long: {name_len}")

        name_raw = data[pos:pos + name_len]
        name = name_raw.decode('utf-8', errors='replace').rstrip('\x00')
        pos += name_len
        pos = (pos + 3) & ~3  # align to 4 bytes

        # Entry count
        if pos + 4 > len(data):
            raise ValueError(f"WDF truncated at entry count for '{name}'")
        
        num_entries = struct.unpack_from('<I', data, pos)[0]; pos += 4

        if num_entries > 500000:
            raise ValueError(f"WDF entry count too high for '{name}': {num_entries}")

        needed = num_entries * 48
        if pos + needed > len(data):
            raise ValueError(f"WDF truncated: '{name}' needs {needed} bytes, {len(data) - pos} available")

        # Read raw 48-byte entries
        entries = []
        for _ in range(num_entries):
            entries.append(bytearray(data[pos:pos + 48]))
            pos += 48

        meshes.append({
            'name': name,
            'entries': entries,
        })

    return {
        'magic': magic,
        'version': version,
        'meshes': meshes,
    }


def write_wdf(wdf, filepath):
    """Write a WDF structure back to file."""
    with open(filepath, 'wb') as f:
        # Header
        f.write(wdf['magic'])
        f.write(struct.pack('<I', wdf['version']))

        for mesh in wdf['meshes']:
            # MESH tag
            f.write(b'MESH')
            
            # Name length + name (padded to 4-byte alignment)
            name_bytes = mesh['name'].encode('utf-8')
            f.write(struct.pack('<I', len(name_bytes)))
            f.write(name_bytes)
            # Pad to 4-byte alignment
            pad = (4 - (len(name_bytes)) % 4) % 4
            f.write(b'\x00' * pad)

            # Entry count + entries
            f.write(struct.pack('<I', len(mesh['entries'])))
            for entry in mesh['entries']:
                f.write(bytes(entry))

        # END tag
        f.write(b'END!')
        f.write(b'\x00\x00\x00\x00')


def get_entry_indices(entry):
    """Extract the 6 triangle vertex indices from a 48-byte WDF entry."""
    tri1 = list(struct.unpack_from('<3H', entry, 32))
    tri2 = list(struct.unpack_from('<3H', entry, 40))
    return tri1, tri2


def set_entry_indices(entry, tri1, tri2):
    """Write remapped triangle vertex indices back into a 48-byte WDF entry."""
    # Preserve the 4th uint16 in each group (padding/flags)
    old_tri1_w = struct.unpack_from('<H', entry, 38)[0]
    old_tri2_w = struct.unpack_from('<H', entry, 46)[0]

    struct.pack_into('<4H', entry, 32, tri1[0], tri1[1], tri1[2], old_tri1_w)
    struct.pack_into('<4H', entry, 40, tri2[0], tri2[1], tri2[2], old_tri2_w)


def remap_wdf(wdf, index_mapping, mesh_name=None):
    """
    Remap all triangle vertex indices in a WDF using the provided mapping.
    
    Args:
        wdf: Parsed WDF structure from parse_wdf()
        index_mapping: dict of {old_vertex_index: new_vertex_index}
        mesh_name: Optional - only remap entries in this specific mesh.
                   If None, remaps all meshes.
    
    Returns:
        dict with remapping statistics
    """
    total_remapped = 0
    total_kept = 0
    total_missing = 0
    missing_indices = set()

    for mesh in wdf['meshes']:
        if mesh_name and mesh['name'] != mesh_name:
            continue

        for entry in mesh['entries']:
            tri1, tri2 = get_entry_indices(entry)

            new_tri1 = []
            new_tri2 = []

            for idx in tri1:
                if idx in index_mapping:
                    new_tri1.append(index_mapping[idx])
                    total_remapped += 1
                else:
                    new_tri1.append(idx)
                    total_kept += 1
                    if idx != 0:  # don't count zero-index as missing
                        missing_indices.add(idx)
                        total_missing += 1

            for idx in tri2:
                if idx in index_mapping:
                    new_tri2.append(index_mapping[idx])
                    total_remapped += 1
                else:
                    new_tri2.append(idx)
                    total_kept += 1
                    if idx != 0:
                        missing_indices.add(idx)
                        total_missing += 1

            set_entry_indices(entry, new_tri1, new_tri2)

    return {
        'remapped': total_remapped,
        'kept': total_kept,
        'missing': total_missing,
        'missing_indices': missing_indices,
    }


def build_vertex_index_mapping(original_positions, new_positions, tolerance=0.001):
    """
    Build old_vertex_index → new_vertex_index mapping by position matching.
    
    Args:
        original_positions: flat float list [x,y,z,x,y,z,...] from original MCD import
        new_positions: flat float list [x,y,z,x,y,z,...] from current Blender export
        tolerance: max distance for a position match
    
    Returns:
        dict of {old_index: new_index}
    """
    orig_count = len(original_positions) // 3
    new_count = len(new_positions) // 3
    tol_sq = tolerance * tolerance

    # Build spatial hash for new positions (grid-based for speed)
    grid_size = tolerance * 10 if tolerance > 0 else 0.01
    grid = {}

    for new_idx in range(new_count):
        x = new_positions[new_idx * 3]
        y = new_positions[new_idx * 3 + 1]
        z = new_positions[new_idx * 3 + 2]
        
        # Hash to grid cell
        gx = int(x / grid_size)
        gy = int(y / grid_size)
        gz = int(z / grid_size)
        
        key = (gx, gy, gz)
        if key not in grid:
            grid[key] = []
        grid[key].append(new_idx)

    mapping = {}
    matched = 0
    unmatched = 0

    for old_idx in range(orig_count):
        ox = original_positions[old_idx * 3]
        oy = original_positions[old_idx * 3 + 1]
        oz = original_positions[old_idx * 3 + 2]

        gx = int(ox / grid_size)
        gy = int(oy / grid_size)
        gz = int(oz / grid_size)

        best_idx = -1
        best_dist_sq = tol_sq

        # Search neighboring grid cells
        for dx in range(-1, 2):
            for dy in range(-1, 2):
                for dz in range(-1, 2):
                    key = (gx + dx, gy + dy, gz + dz)
                    if key not in grid:
                        continue
                    for new_idx in grid[key]:
                        nx = new_positions[new_idx * 3]
                        ny = new_positions[new_idx * 3 + 1]
                        nz = new_positions[new_idx * 3 + 2]
                        dist_sq = (ox - nx)**2 + (oy - ny)**2 + (oz - nz)**2
                        if dist_sq < best_dist_sq:
                            best_dist_sq = dist_sq
                            best_idx = new_idx

        if best_idx >= 0:
            mapping[old_idx] = best_idx
            matched += 1
        else:
            unmatched += 1

    dlog(f"[WDF Remap] Vertex mapping: {matched} matched, {unmatched} unmatched "
          f"out of {orig_count} original vertices")

    return mapping


def remap_wdf_file(wdf_path, output_path, mesh_mappings):
    """
    Full pipeline: parse WDF, remap indices for each mesh, write result.
    
    Args:
        wdf_path: path to input WDF file
        output_path: path to write remapped WDF
        mesh_mappings: dict of {mesh_name: {old_idx: new_idx}} 
                       OR a single flat {old_idx: new_idx} to apply to all meshes
    
    Returns:
        dict with overall statistics
    """
    if not os.path.exists(wdf_path):
        dlog(f"[WDF Remap] WDF file not found: {wdf_path}")
        return None

    wdf = parse_wdf(wdf_path)
    
    total_stats = {'remapped': 0, 'kept': 0, 'missing': 0, 'missing_indices': set()}

    if isinstance(mesh_mappings, dict) and all(isinstance(v, dict) for v in mesh_mappings.values()):
        # Per-mesh mappings
        for mesh_name, mapping in mesh_mappings.items():
            stats = remap_wdf(wdf, mapping, mesh_name=mesh_name)
            total_stats['remapped'] += stats['remapped']
            total_stats['kept'] += stats['kept']
            total_stats['missing'] += stats['missing']
            total_stats['missing_indices'].update(stats['missing_indices'])
            dlog(f"[WDF Remap] Mesh '{mesh_name}': {stats['remapped']} remapped, "
                  f"{stats['missing']} missing")
    else:
        # Single mapping for all meshes
        stats = remap_wdf(wdf, mesh_mappings)
        total_stats = stats
    
    write_wdf(wdf, output_path)
    dlog(f"[WDF Remap] Saved remapped WDF to: {output_path}")
    dlog(f"[WDF Remap] Total: {total_stats['remapped']} remapped, "
          f"{total_stats['kept']} kept, {total_stats['missing']} missing")

    return total_stats
