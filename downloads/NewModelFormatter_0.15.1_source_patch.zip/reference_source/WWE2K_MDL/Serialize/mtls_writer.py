"""mtls_writer — Reference-based (v6) .mtls material library serializer.

WWE 2K26's character pipeline uses a "reference-based" .mtls layout: the
.mtls file is a tiny stub lookup table whose real material data lives in
external per-material .jmtl FlatBuffer files inside the sibling Materials/
folder. The .mtls itself holds:

    1. A concatenation of NUL-terminated material names (the string table).
    2. Per-material FNV1a-64 hashes of the virtual jmtl asset path. These
       are the TOC keys the runtime uses to bind material → mesh; the game
       stores them at per-material struct +16 and resolves them through the
       global asset registry.
    3. Per-material u16 offsets back into the string table.
    4. A 36-byte empty MTL! stub per material (validated by
       materiallibrary.cpp:isStubMtlBlock — magic "MTL!", ver=4, size=1,
       24 trailing zeros).

THE canonical reference for this writer is jmtl/src/mtllibraryserializer.cpp
(::createMaterialTable + ::createMtlsHeader + ::serialize). Reading order:
header, string table (with NUL terminators) → 4-byte align → numMaterials
→ N×u64 hashes → N×u16 name offsets → 4-byte align → N×36-byte MTL! stubs.

Public API:
    write_mtls(material_names, save_path=None) -> bytes

A `_self_test()` at the bottom cross-validates structure against the
Rock baseModel.mtls sample and the documented "foo" worked example.
"""

from __future__ import annotations

import os
import struct
from typing import List, Optional


# ─── Constants ──────────────────────────────────────────────────────────────

# Magic = ASCII "MTLs" stored little-endian as 0x734C544D
_MAGIC_MTLS = b"MTLs"

# 36-byte empty-stub block — see materiallibrary.cpp:36-51 (isStubMtlBlock):
#   [0x00] "MTL!" magic, [0x04] u32 ver=4, [0x08] u32 size=1, [0x0C..0x23] zeros
_MTL_STUB = b"MTL!" + struct.pack("<II", 4, 1) + (b"\x00" * 24)
assert len(_MTL_STUB) == 36

_CONTAINER_VERSION = 6

# Recognised game-root folder anchors. Order matches the C++ knownFolders[]
# table in mtllibraryserializer.cpp:createMtlsHeader so detection priority
# stays identical. The "/" suffix is appended at scan time.
_KNOWN_ROOTS = ("Characters", "Arena", "Props", "Weapons")

# FNV-1a 64-bit — must match Blender/Extras/jmtl_resolver._fnv1a_64_lower
# (and the engine's TextureRefService.ComputeFnv1aLower).
_FNV_OFFSET_BASIS = 0xCBF29CE484222325
_FNV_PRIME = 0x100000001B3
_U64_MASK = 0xFFFFFFFFFFFFFFFF


# ─── Subhelpers ─────────────────────────────────────────────────────────────


def _clean_material_name(name: str) -> str:
    """Strip a trailing case-insensitive ``Skinned`` suffix (and any
    trailing colon left behind), per common.cpp:184-201
    (``SysCommon::strip_skinned_suffix``).

    Examples (matching the C++ impl semantics):
        "belt:Skinned" → "belt"
        "belt:skinned" → "belt"
        "BeltSKINNED"  → "Belt"
        "Skinned"      → "Skinned"   # pos == 0 → leave alone
        "body"         → "body"
        "body:"        → "body:"     # no Skinned → no trim
    """
    if not name:
        return name

    lower = name.lower()
    pos = lower.find("skinned")
    if pos == -1 or pos == 0:
        # Not found, or name IS "skinned" — leave alone (matches C++).
        return name

    result = name[:pos]
    # Trim trailing colon(s) left behind, e.g. "belt:" → "belt".
    while result and result[-1] == ":":
        result = result[:-1]
    return result


def _fnv1a_64_lower(s: str) -> int:
    """FNV-1a 64-bit hash of ``s`` after lowercasing.

    Offset basis 0xCBF29CE484222325, prime 0x100000001B3, modulo 2^64.
    Mirrors Blender/Extras/jmtl_resolver._fnv1a_64_lower byte-for-byte.
    """
    h = _FNV_OFFSET_BASIS
    for ch in s.lower():
        h ^= ord(ch) & 0xFF
        h = (h * _FNV_PRIME) & _U64_MASK
    return h


def _compute_path_hash(save_path: Optional[str], material_name: str) -> int:
    """Produce the FNV1a-64 TOC hash for one material.

    The hash key is the virtual asset path the runtime would resolve, e.g.
    ``"Characters/100_The_Rock_2017/BaseModel/Materials/head.jmtl"``. We
    derive the relative path by locating the first known game-root folder
    (Characters/, Arena/, Props/, Weapons/) inside ``save_path``, taking
    the directory portion after it, and gluing on ``Materials/<name>.jmtl``.

    Returns 0 when ``save_path`` is falsy or no recognised root is present
    (per the C++ ``relDir.empty()`` branch — a zero hash is a valid value
    that simply skips runtime TOC binding for that slot).
    """
    if not save_path:
        return 0

    # Normalise to forward slashes — matches SysCommon::back_slashes_to_forward.
    norm = save_path.replace("\\", "/")

    # Find the first known root folder in declaration order.
    root_idx = -1
    for folder in _KNOWN_ROOTS:
        # Try the canonical capitalisation first, then lowercase, mirroring
        # the C++ table that explicitly lists both variants.
        for variant in (folder + "/", folder.lower() + "/"):
            idx = norm.find(variant)
            if idx != -1:
                root_idx = idx
                break
        if root_idx != -1:
            break

    if root_idx == -1:
        return 0

    rel_path = norm[root_idx:]
    # Strip the filename component (everything after the last slash).
    last_slash = rel_path.rfind("/")
    rel_dir = rel_path[:last_slash] if last_slash != -1 else ""

    if not rel_dir:
        return 0

    virtual_path = rel_dir + "/Materials/" + material_name + ".jmtl"
    return _fnv1a_64_lower(virtual_path)


def _align4(buf: bytearray) -> None:
    """Pad ``buf`` in place with 0x00 until ``len(buf) % 4 == 0``.

    Mirrors ``align_binary_stream`` in the C++ writer — used after the
    name string table and again after the u16 offset array.
    """
    while len(buf) % 4 != 0:
        buf.append(0)


def _write_mtl_stub(buf: bytearray) -> None:
    """Append one 36-byte empty MTL! stub block to ``buf``."""
    buf.extend(_MTL_STUB)


# ─── Public API ─────────────────────────────────────────────────────────────


def write_mtls(material_names: List[str], save_path: Optional[str] = None) -> bytes:
    """Serialize a reference-based (v6) .mtls library.

    Args:
        material_names: ordered list of material slot names. Each name is
            cleaned via :func:`_clean_material_name` before serialization
            (the C++ writer pre-cleans for the same reason — leaving
            ``:Skinned`` in the string table causes binding failures).
        save_path: optional full filesystem path the .mtls will be written
            to. Used purely to compute the per-material FNV1a-64 path
            hashes (see :func:`_compute_path_hash`). If omitted, or no
            known game-root folder is found in the path, every hash is
            written as 0 (a valid configuration — runtime TOC lookup is
            simply skipped for those slots).

    Returns:
        Raw bytes of the serialized .mtls file.
    """
    # Clean every name once, up front. We use these cleaned forms for both
    # the string table AND the hash key — the C++ writer does the same.
    cleaned = [_clean_material_name(n) for n in material_names]

    # Warn (but don't fail) on suspicious names. The format allows u16
    # offsets up to 65535, but the sample data tops out around 18 chars
    # and >32 chars almost always means a bad/garbled slot name.
    for name in cleaned:
        if len(name) > 32:
            try:
                from ..Link.log import dwarn
                dwarn(
                    "mtls_writer: material name '%s' is %d chars (>32); "
                    "writing it anyway but this may indicate a stale slot."
                    % (name, len(name))
                )
            except Exception:
                # Log subsystem unavailable (e.g. running under self-test
                # outside Blender). Fall back to a plain print.
                print(
                    "[mtls_writer] WARN: material name %r is %d chars (>32); "
                    "writing it anyway." % (name, len(name))
                )

    buf = bytearray()

    # ── Fixed 12-byte header ─────────────────────────────────────────────
    buf.extend(_MAGIC_MTLS)
    buf.extend(struct.pack("<I", _CONTAINER_VERSION))

    # ── String table (and its size prefix) ───────────────────────────────
    # Build the table first so we know its raw size — matches the C++
    # tableSize accumulator that sums (name.size() + 1) for every entry.
    name_bytes: List[bytes] = []
    table_size = 0
    name_offsets: List[int] = []  # offsets relative to start of table
    for name in cleaned:
        encoded = name.encode("utf-8") + b"\x00"
        name_offsets.append(table_size)
        table_size += len(encoded)
        name_bytes.append(encoded)

    buf.extend(struct.pack("<I", table_size))
    for chunk in name_bytes:
        buf.extend(chunk)

    # 4-byte align before the material count field.
    _align4(buf)

    # ── Material count ───────────────────────────────────────────────────
    buf.extend(struct.pack("<I", len(cleaned)))

    # ── Per-material FNV1a-64 path hashes ────────────────────────────────
    for name in cleaned:
        h = _compute_path_hash(save_path, name)
        buf.extend(struct.pack("<Q", h))

    # ── Per-material u16 name offsets (into the string table) ────────────
    for off in name_offsets:
        # u16 covers the 65535-byte addressable range; the format gives
        # no spec for >u16 names so we'd be wrong either way past that.
        buf.extend(struct.pack("<H", off & 0xFFFF))

    # 4-byte align before the stub region.
    _align4(buf)

    # ── 36-byte empty MTL! stub per material ─────────────────────────────
    for _ in cleaned:
        _write_mtl_stub(buf)

    return bytes(buf)


# ─── Self-test (cross-validation) ───────────────────────────────────────────


def _expected_size(names: List[str]) -> int:
    """Closed-form expected file size for a list of cleaned names.

    Mirrors mtllibraryserializer.cpp::getHeaderSize plus the per-material
    36-byte stub count. Used by the self-test.
    """
    n = len(names)
    # Header (magic + ver + table_size) + raw name blob (each + NUL).
    size = 4 * 3
    for nm in names:
        size += len(nm.encode("utf-8")) + 1
    # Pad to 4 before the count field.
    while size % 4 != 0:
        size += 1
    size += 4              # numMaterials
    size += n * 8          # hashes
    size += n * 2          # name offsets
    while size % 4 != 0:   # pad to 4 before stub region
        size += 1
    size += n * 36         # stubs
    return size


def _self_test() -> bool:
    """Cross-validate the writer against the Rock baseModel.mtls sample
    and the worked single-material example. Prints PASS/FAIL with byte
    counts and returns True on success.
    """
    all_pass = True

    def _check(label: str, cond: bool, detail: str = "") -> None:
        nonlocal all_pass
        status = "PASS" if cond else "FAIL"
        line = "  [%s] %s" % (status, label)
        if detail and not cond:
            line += " — " + detail
        print(line)
        if not cond:
            all_pass = False

    # ── Test 1: Rock baseModel.mtls (8 materials, zero hashes) ──────────
    rock_names = [
        "body", "eye_caruncle", "eye_l", "eye_r",
        "eyelash", "head", "mouthbag", "teeth",
    ]
    blob = write_mtls(rock_names, save_path=None)
    print("Test 1 — Rock baseModel layout (zero hashes):")
    print("  produced %d bytes" % len(blob))

    expected_len = _expected_size(rock_names)
    _check("total length == formula", len(blob) == expected_len,
           "got %d, expected %d" % (len(blob), expected_len))

    # Cross-check against the on-disk sample if available. Point
    # WWE2K_MDL_SAMPLE_CHARS at a local Characters/ folder to run this;
    # never exercised by the shipped addon (guarded by __main__ below).
    sample_path = os.path.join(
        os.environ.get("WWE2K_MDL_SAMPLE_CHARS", ""),
        "100_The_Rock_2017", "BaseModel", "baseModel.mtls")
    sample = None
    if os.path.isfile(sample_path):
        with open(sample_path, "rb") as f:
            sample = f.read()
        _check("length matches Rock sample (444B)",
               len(blob) == len(sample),
               "got %d, sample %d" % (len(blob), len(sample)))

    # Header invariants.
    _check("magic == 'MTLs'", blob[:4] == b"MTLs",
           "got %r" % blob[:4])
    _check("version == 6", struct.unpack_from("<I", blob, 4)[0] == 6,
           "got %d" % struct.unpack_from("<I", blob, 4)[0])
    string_table_size = struct.unpack_from("<I", blob, 8)[0]
    _check("string_table_size == 58", string_table_size == 58,
           "got %d" % string_table_size)

    # Walk to the count.
    off = 12 + string_table_size
    while off % 4 != 0:
        off += 1
    count = struct.unpack_from("<I", blob, off)[0]
    _check("numMaterials == 8", count == 8, "got %d" % count)
    off += 4

    # Hashes should all be zero with save_path=None.
    all_zero = all(
        struct.unpack_from("<Q", blob, off + i * 8)[0] == 0 for i in range(8)
    )
    _check("all hashes == 0 (save_path=None)", all_zero)
    off += 8 * 8

    # Offset table.
    offs = [struct.unpack_from("<H", blob, off + i * 2)[0] for i in range(8)]
    expected_offs = [0, 5, 18, 24, 30, 38, 43, 52]
    _check("name offsets match sample", offs == expected_offs,
           "got %r expected %r" % (offs, expected_offs))
    off += 8 * 2
    while off % 4 != 0:
        off += 1

    # Stub region — first stub head bytes.
    if len(blob) >= off + 36:
        stub0 = blob[off:off + 36]
        _check("stub[0] magic+ver+size",
               stub0[:4] == b"MTL!" and stub0[4:8] == b"\x04\x00\x00\x00"
               and stub0[8:12] == b"\x01\x00\x00\x00",
               "got %r" % stub0[:12])
        _check("stub[0] trailing 24 bytes zero",
               all(b == 0 for b in stub0[12:]))

    # If we loaded the sample, cross-verify every structural field MATCHES
    # the on-disk bytes — only the hash region is permitted to differ.
    if sample is not None and len(sample) == len(blob):
        head_eq = blob[:12 + string_table_size] == sample[:12 + string_table_size]
        _check("header + string table bytes match sample", head_eq)
        # Skip hashes (off-of-count + 4 .. + 4 + 64), compare the rest.
        hash_start = 12 + string_table_size
        while hash_start % 4 != 0:
            hash_start += 1
        hash_start += 4
        hash_end = hash_start + 8 * 8
        tail_eq = blob[hash_end:] == sample[hash_end:]
        _check("offsets + stubs match sample bytes after hash region", tail_eq)

    # ── Test 2: single-material "foo" worked example ────────────────────
    print("Test 2 — single material ['foo'] (zero hash):")
    foo_blob = write_mtls(["foo"], save_path=None)
    foo_expected = _expected_size(["foo"])
    print("  produced %d bytes (formula-expected %d)"
          % (len(foo_blob), foo_expected))
    # Spec mentions 60 bytes; the closed-form math gives 68
    # (12 hdr + 4 strtab + 0 pad + 4 count + 8 hash + 2 off + 2 pad + 36 stub).
    # We hold to the formula — it agrees with the Rock sample byte-for-byte.
    _check("['foo'] total length == formula", len(foo_blob) == foo_expected,
           "got %d, expected %d" % (len(foo_blob), foo_expected))
    _check("['foo'] magic", foo_blob[:4] == b"MTLs")
    _check("['foo'] version == 6",
           struct.unpack_from("<I", foo_blob, 4)[0] == 6)
    _check("['foo'] string_table_size == 4",
           struct.unpack_from("<I", foo_blob, 8)[0] == 4)
    _check("['foo'] string table == b'foo\\x00'",
           foo_blob[12:16] == b"foo\x00")
    _check("['foo'] count == 1", struct.unpack_from("<I", foo_blob, 16)[0] == 1)
    _check("['foo'] hash == 0", struct.unpack_from("<Q", foo_blob, 20)[0] == 0)
    _check("['foo'] name offset == 0",
           struct.unpack_from("<H", foo_blob, 28)[0] == 0)
    _check("['foo'] stub at byte 32", foo_blob[32:36] == b"MTL!")
    _check("['foo'] stub trailing zeros",
           all(b == 0 for b in foo_blob[44:68]) if len(foo_blob) >= 68 else False)

    # ── Test 3: empty input (robustness) ────────────────────────────────
    print("Test 3 — empty material list:")
    empty_blob = write_mtls([], save_path=None)
    # 12 (hdr) + 0 (strtab) + 0 (pad) + 4 (count) = 16, no hashes/offs/stubs.
    _check("empty length == 16", len(empty_blob) == 16,
           "got %d" % len(empty_blob))
    _check("empty magic", empty_blob[:4] == b"MTLs")
    _check("empty string_table_size == 0",
           struct.unpack_from("<I", empty_blob, 8)[0] == 0)
    _check("empty count == 0",
           struct.unpack_from("<I", empty_blob, 12)[0] == 0)

    # ── Test 4: name cleaning ───────────────────────────────────────────
    print("Test 4 — name cleaning:")
    _check("strip ':Skinned'",
           _clean_material_name("belt:Skinned") == "belt",
           "got %r" % _clean_material_name("belt:Skinned"))
    _check("strip ':skinned'",
           _clean_material_name("belt:skinned") == "belt")
    _check("strip 'Skinned' (no colon)",
           _clean_material_name("BeltSkinned") == "Belt")
    _check("leave 'Skinned' alone (pos==0)",
           _clean_material_name("Skinned") == "Skinned")
    _check("leave 'body' alone",
           _clean_material_name("body") == "body")
    _check("leave 'body:' alone (no Skinned trigger)",
           _clean_material_name("body:") == "body:")

    # Self-cleaned roundtrip — passing dirty names produces a clean table.
    dirty_blob = write_mtls(["body:Skinned", "head"], save_path=None)
    # String table should be "body\0head\0" = 10 bytes.
    _check("dirty input produces cleaned string table",
           struct.unpack_from("<I", dirty_blob, 8)[0] == 10,
           "table size %d" % struct.unpack_from("<I", dirty_blob, 8)[0])
    _check("cleaned names in string table",
           dirty_blob[12:22] == b"body\x00head\x00",
           "got %r" % dirty_blob[12:22])

    # ── Test 5: path hash plumbing ──────────────────────────────────────
    print("Test 5 — path hash plumbing:")
    sample_save = (
        r"C:\WWE2K_MOD\Characters\100_The_Rock_2017\BaseModel\baseModel.mtls"
    )
    expected_hash = _fnv1a_64_lower(
        "Characters/100_The_Rock_2017/BaseModel/Materials/head.jmtl"
    )
    got_hash = _compute_path_hash(sample_save, "head")
    _check("path hash for Rock head.jmtl matches FNV1a-64",
           got_hash == expected_hash,
           "got 0x%016x expected 0x%016x" % (got_hash, expected_hash))
    _check("no known root -> hash 0",
           _compute_path_hash(r"C:\some\random\path\foo.mtls", "head") == 0)
    _check("None save_path -> hash 0",
           _compute_path_hash(None, "head") == 0)

    print("Result: %s" % ("PASS" if all_pass else "FAIL"))
    return all_pass


if __name__ == "__main__":
    import sys
    ok = _self_test()
    sys.exit(0 if ok else 1)
