"""GtPt export resolver — round-trip anchor records through topology edits.

Reads the scene's `VC_GtPt_Anchors` collection, walks each anchor empty,
resolves its target (mesh, vertex_index) on the destination model, and
returns a list of records ready to push to the DLL via cmodellib.addGotoPoint.

Confirmed wire-format semantics (from empirical TEXT-pairing audit on the
2K26 baseModel):
    no_0  →  TEXT-table index → anchor name string ("_ag_NNNN")
    no_1  →  TEXT-table index → group/mesh name string ("M_Head_Caruncle", etc.)
    no_2  →  engine slot lookup key (opaque integer; round-trip verbatim)
    no_3  →  vertex index on the mesh resolved from no_1

Resolution rules:
    1. If the source group string was 'M_Head_Caruncle' AND M_Head_Caruncle
       is no longer in the export mesh set → rewrite group to 'M_Head'.
       (The standard caruncle-merge workflow.)
    2. Resolve target vertex by reading the per-record vertex group
       VC_GTPT__{slot:03d}__{name} on the resolved target mesh.
    3. If the vertex group is missing, fall back to nearest-vertex-on-target
       using the empty's stored gtpt_source_position. Strictly target-mesh
       only — never broaden the search to other meshes (that's how M_EYE
       wins over M_Head_Caruncle; it's also how anchors silently teleport
       to wrong meshes when the user has multiple head meshes in the scene).
    4. If neither the vertex group nor the empty position resolves cleanly,
       drop the single record with a warning. Do NOT fall back to source
       bytes (that's how broken records survived round-trip in earlier
       builds and got us into "dark eyes" territory).

Drop-record vs strip-whole-table: the resolver is conservative — it returns
only records it can resolve safely. The caller (interface_save) decides what to
do with a partial list (use it, keep the source-byte transfer for the rest, or
skip GtPt). This file doesn't override that table-level decision.
"""

import os
from mathutils import Vector

from ..SkinModel.skinmodel_gp import (
    GTPT_VG_PREFIX, gtpt_vertex_group_name,
)
from ..Link.log import dlog, dwarn, derror


# Source group names rewritten to a destination group when the source mesh no
# longer exists in the export. Caruncle is the only current case; the table
# generalizes to future merges (e.g. 2K27 collapsing M_Tongue into M_MouthBag).
GROUP_MERGE_FALLBACKS = {
    'M_Head_Caruncle': 'M_Head',
}


# Result class — a per-record outcome the caller can inspect / log / surface.
class GtPtRecord:
    __slots__ = ('name', 'group_name', 'slot', 'vertex_index',
                 'status', 'reason')

    def __init__(self, name, group_name, slot, vertex_index,
                 status='ok', reason=''):
        self.name = name
        self.group_name = group_name
        self.slot = int(slot)
        self.vertex_index = int(vertex_index)
        self.status = status     # 'ok' | 'rewritten' | 'dropped'
        self.reason = reason     # human-readable detail


def canonical_mesh_name_from_str(name):
    """Apply the canonical M_*/S_* normalization to a raw datablock name.

    Strips Blender's .001 collision suffix, removes the !/$ marker
    prefixes the addon uses internally, and case-corrects M_/S_ prefix.
    Returns None for empty / falsy input.

    Shared by every GtPt code path so import / generator / export all
    agree on what counts as the "same mesh" after a datablock rename.
    """
    if not name:
        return None
    n = name.replace("!", "").replace("$", "")
    if "." in n:
        n = n.split(".")[0]
    if len(n) > 2 and n[1] == '_' and n[0] in ('M', 'm', 'S', 's'):
        n = n[0].upper() + '_' + n[2].upper() + n[3:]
    return n


def _canonical_mesh_name(obj):
    """Extract the canonical M_* identifier from a mesh object.

    Symmetric with the import-side helper of the same name in
    blender_gtpt.py (and matches getBaseName(obj.data) used by the
    skin export). The canonical name lives on the mesh DATABLOCK,
    not on the object itself.
    """
    if obj is None or obj.data is None:
        return None
    return canonical_mesh_name_from_str(obj.data.name)


def _all_export_meshes():
    """All scene meshes the export will touch.

    Mirrors getMeshSelection() (only selected MESH objects), NOT
    bpy.data.objects, because the "is M_Head_Caruncle present" check must
    match what gets EXPORTED, not what exists in the .blend. Otherwise a
    modder who parents to a vanilla baseModel (pulling its M_Head_Caruncle
    into the file) but exports only their own meshes would see the resolver
    decide "caruncle present, no merge needed" while the saved file lacks it
    — records point at a missing TEXT string, the patcher drops them, eyes
    go dark.

    Match priority: (1) canonical M_* from datablock (same as skin export),
    (2) obj.name verbatim. Returns {name → Object}, canonical winning ties.
    """
    # Import locally to avoid a circular import (blender_save → resolver).
    from ..Blender.blender_save import getMeshSelection
    selection = getMeshSelection()

    by_objname = {}
    by_canonical = {}
    for obj in selection:
        if obj.type != 'MESH':
            continue
        by_objname[obj.name] = obj
        canonical = _canonical_mesh_name(obj)
        if canonical:
            by_canonical[canonical] = obj

    # Canonical takes priority — overwrite by_objname entries when both exist.
    by_objname.update(by_canonical)
    return by_objname


def _build_vg_membership_map(mesh_obj):
    """Build an inverse map vg_index → [(weight, vertex_index), ...] for one mesh.

    Single O(V*G_avg) sweep — produced once per mesh and reused across
    every anchor that targets it. Replaces the previous per-anchor scan
    that re-walked all vertices for every record.

    Empty / non-mesh inputs return an empty dict so callers don't need
    to special-case missing meshes.
    """
    out = {}
    if mesh_obj is None or mesh_obj.type != 'MESH':
        return out
    for v in mesh_obj.data.vertices:
        for elem in v.groups:
            if elem.weight > 0.0:
                out.setdefault(elem.group, []).append((elem.weight, v.index))
    return out


def _find_anchor_vertex_group(mesh_obj, slot, name, membership_map=None):
    """Look up the per-record anchor vertex group on `mesh_obj`.

    Returns (weight, vertex_index) of the highest-weighted vertex in the
    group, or None if the group is missing / empty / has no nonzero verts.

    `membership_map` is the precomputed `_build_vg_membership_map` result;
    supplied → O(members-in-group), omitted → built on the fly (for external
    callers not on the batched API).

    A well-formed anchor group has exactly one weight-1.0 vertex, but we
    tolerate multi-vertex groups (user copying verts in edit mode) by picking
    the highest-weighted one.
    """
    if mesh_obj is None or mesh_obj.type != 'MESH':
        return None
    target_name = gtpt_vertex_group_name(slot, name)
    vg = mesh_obj.vertex_groups.get(target_name)
    if vg is None:
        return None
    if membership_map is None:
        membership_map = _build_vg_membership_map(mesh_obj)
    entries = membership_map.get(vg.index)
    if not entries:
        return None
    # Highest-weighted vertex wins.
    return max(entries, key=lambda e: e[0])


def _nearest_vertex(mesh_obj, world_pos):
    """Brute-force nearest-vertex on `mesh_obj` to a world-space position.

    Used as the fallback when the per-record vertex group is missing.
    Strictly target-mesh only — the rules explicitly forbid broadening
    the search to other meshes.

    Acceptable cost: this only runs on records that lost their vertex
    group, and even then only on a single mesh (M_Head, ~3-5k verts).
    A KDTree wouldn't pay off vs. import time.
    """
    if mesh_obj is None or mesh_obj.type != 'MESH' or world_pos is None:
        return None
    n = len(mesh_obj.data.vertices)
    if n == 0:
        return None
    inv = mesh_obj.matrix_world.inverted()
    local_target = inv @ Vector(world_pos)
    # Vectorized nearest-vertex via foreach_get + np.argmin (first-wins on ties,
    # matching the Python fallback below).
    try:
        import numpy as np
        co_flat = np.empty(n * 3, dtype=np.float64)
        mesh_obj.data.vertices.foreach_get('co', co_flat)
        co = co_flat.reshape(-1, 3)
        target = np.array([local_target.x, local_target.y, local_target.z],
                          dtype=np.float64)
        diff = co - target
        sqdist = (diff * diff).sum(axis=1)
        return int(np.argmin(sqdist))
    except Exception:
        # Defensive fallback — match the previous semantics exactly.
        best = None  # (sqdist, vertex_index)
        for v in mesh_obj.data.vertices:
            d = v.co - local_target
            sq = d.x * d.x + d.y * d.y + d.z * d.z
            if best is None or sq < best[0]:
                best = (sq, v.index)
        return best[1] if best else None


def resolve_scene_gtpts():
    """Walk VC_GtPt_Anchors and produce a list of GtPtRecord ready to push.

    Returns (records, warnings) — records is a list of GtPtRecord, warnings
    is a list of (severity, message) tuples for the operator layer to
    surface as UI banners.

    Returns ([], []) and no warnings when the anchors collection is absent
    (model never had GtPt, or user opted out of the import-side build).
    The caller treats that as "fall through to whatever transfer / skip
    behavior was in place before".
    """
    import bpy

    warnings = []
    records = []

    anchor_col = bpy.data.collections.get('VC_GtPt_Anchors')
    if anchor_col is None:
        return records, warnings

    anchors = [obj for obj in anchor_col.objects if obj.type == 'EMPTY']
    if not anchors:
        return records, warnings

    export_meshes = _all_export_meshes()

    # Memoize per-mesh vertex-group membership maps (built lazily, reused
    # across anchors). Turns per-anchor lookup from O(V*G) to O(group_members).
    vg_membership_cache = {}

    def get_membership_map(mesh_obj):
        if mesh_obj is None:
            return {}
        key = id(mesh_obj)
        cached = vg_membership_cache.get(key)
        if cached is None:
            cached = _build_vg_membership_map(mesh_obj)
            vg_membership_cache[key] = cached
        return cached

    # Sort anchors by slot — vanilla files sort ascending by no_0/slot, so
    # matching keeps the binary diff minimal when no records changed.
    def sort_key(empty):
        slot = empty.get('gtpt_slot', 0)
        try:
            return int(slot)
        except (TypeError, ValueError):
            return 0
    anchors.sort(key=sort_key)

    for empty in anchors:
        name        = empty.get('gtpt_name')
        group_name  = empty.get('gtpt_group')
        slot        = empty.get('gtpt_slot')
        src_vertex  = empty.get('gtpt_source_vertex')
        src_pos_raw = empty.get('gtpt_source_position')

        # The empty's CURRENT world position, used to detect a user drag.
        # Two competing anchors: the vertex group is "durable" (tracks a vertex
        # by membership, survives caruncle-merge/weld), the empty's transform is
        # "intent" (survives re-import). A deliberate drag means intent wins;
        # otherwise durability wins. Distinguished by drag detection below.
        try:
            empty_world_pos = (float(empty.matrix_world.translation.x),
                               float(empty.matrix_world.translation.y),
                               float(empty.matrix_world.translation.z))
        except Exception:
            empty_world_pos = None

        if name is None or group_name is None or slot is None:
            warnings.append(('WARNING', f"GtPt anchor '{empty.name}' is "
                             "missing identity custom props (gtpt_name, "
                             "gtpt_group, gtpt_slot). Dropping this record."))
            continue
        try:
            slot = int(slot)
        except (TypeError, ValueError):
            warnings.append(('WARNING', f"GtPt anchor '{empty.name}' has "
                             f"non-integer gtpt_slot {slot!r}. Dropping."))
            continue

        # Resolve target group / mesh.
        target_group = group_name
        target_mesh = export_meshes.get(target_group)
        rewritten_reason = ''

        if target_mesh is None and target_group in GROUP_MERGE_FALLBACKS:
            fallback = GROUP_MERGE_FALLBACKS[target_group]
            fb_mesh = export_meshes.get(fallback)
            if fb_mesh is not None:
                rewritten_reason = (f"Source group '{target_group}' missing "
                                    f"in export, rewriting to '{fallback}' "
                                    f"(merge fallback rule).")
                target_group = fallback
                target_mesh = fb_mesh

        if target_mesh is None:
            warnings.append(('WARNING',
                f"GtPt anchor '{name}' targets group '{group_name}' which "
                f"does not exist in the export, and no merge fallback "
                f"applies. Dropping this record — eye / shading detail "
                f"that depended on it will not render."))
            records.append(GtPtRecord(name, group_name, slot, 0,
                                       status='dropped',
                                       reason='target group missing'))
            continue

        # Resolve target vertex. Three-stage priority:
        #   1. Vertex group (durable) — ONLY if the user didn't drag the empty
        #      since import (current world pos within DRAG_EPSILON of the
        #      stamped gtpt_source_position). Tracks the vertex across mesh
        #      edits even when the empty is now displaced.
        #   2. Drag-detected nearest-vertex — empty moved; run nearest-vertex
        #      from its current position (hand-tuning path).
        #   3. Source-position fallback — no group AND no transform (rare).
        #
        # Threshold: caruncle anchors sit ~1-2 units apart, so a half-spacing
        # nudge is still deliberate. 0.05² (~2mm after import rotation) is above
        # float noise but registers intentional nudges. v1.9.38's 0.5-unit
        # threshold caused asymmetric resets (left drag >0.5, right <0.5).
        DRAG_EPSILON_SQ = 0.05 * 0.05

        # Did the user move the empty since import / generation?
        # Compare empty's current world position against gtpt_source_position
        # (the at-creation position the importer or generator stamped).
        # If those props don't exist (custom-built anchor) we conservatively
        # treat the empty as "not dragged" so vertex group wins by default.
        user_dragged = False
        if empty_world_pos is not None and src_pos_raw is not None:
            try:
                src_pos = (float(src_pos_raw[0]), float(src_pos_raw[1]),
                           float(src_pos_raw[2]))
                dx = empty_world_pos[0] - src_pos[0]
                dy = empty_world_pos[1] - src_pos[1]
                dz = empty_world_pos[2] - src_pos[2]
                sqdist = dx*dx + dy*dy + dz*dz
                user_dragged = sqdist > DRAG_EPSILON_SQ
            except (TypeError, ValueError, IndexError):
                pass

        target_vertex = None
        resolution_path = None

        # Stage 1: vertex group, only if the user didn't drag.
        if not user_dragged:
            vg_hit = _find_anchor_vertex_group(
                target_mesh, slot, name,
                membership_map=get_membership_map(target_mesh))
            if vg_hit is not None:
                _, target_vertex = vg_hit
                resolution_path = 'vertex_group'

        # Stage 2: drag-detected nearest-vertex (using empty's CURRENT
        # world position). Runs when user_dragged is True OR vertex
        # group lookup missed.
        if target_vertex is None and empty_world_pos is not None:
            target_vertex = _nearest_vertex(target_mesh, empty_world_pos)
            if target_vertex is not None:
                resolution_path = ('nearest_vertex_from_drag' if user_dragged
                                    else 'nearest_vertex_from_position')

        # Stage 3: stored source-position fallback (last resort, rare).
        if target_vertex is None and src_pos_raw is not None:
            try:
                src_pos = (float(src_pos_raw[0]), float(src_pos_raw[1]),
                           float(src_pos_raw[2]))
            except (TypeError, ValueError, IndexError):
                src_pos = None
            if src_pos is not None:
                target_vertex = _nearest_vertex(target_mesh, src_pos)
                if target_vertex is not None:
                    resolution_path = 'nearest_vertex_from_stored_pos'

        if target_vertex is None:
            warnings.append(('WARNING',
                f"GtPt anchor '{name}' on '{target_group}': could not "
                f"resolve target vertex — vertex group "
                f"'{gtpt_vertex_group_name(slot, name)}' is missing, the "
                f"empty has no readable transform, and no stored source "
                f"position is available. Dropping this record."))
            records.append(GtPtRecord(name, group_name, slot, 0,
                                       status='dropped',
                                       reason='cannot resolve vertex'))
            continue

        status = 'ok'
        reason = f"resolved via {resolution_path}"
        if rewritten_reason:
            status = 'rewritten'
            reason = rewritten_reason + ' ' + reason

        records.append(GtPtRecord(
            name=name,
            group_name=target_group,
            slot=slot,
            vertex_index=int(target_vertex),
            status=status,
            reason=reason,
        ))

    # Summary log line for the console (not as a UI warning — only true
    # warnings get surfaced to the user).
    n_ok       = sum(1 for r in records if r.status == 'ok')
    n_rewrite  = sum(1 for r in records if r.status == 'rewritten')
    n_drop     = sum(1 for r in records if r.status == 'dropped')
    if n_rewrite or n_drop:
        dwarn(f"[MDL Addon] GtPt resolver: {n_ok} ok, {n_rewrite} rewritten, "
              f"{n_drop} dropped (out of {len(anchors)} scene anchors)")

    return records, warnings


def push_resolved_records(cskinmodel, records, string_table_helper):
    """Push resolved records to the DLL.

    string_table_helper is a callable str → int that returns the TEXT-table
    index for a given string in the destination model, inserting a new
    entry if needed. The DLL's generateStringTable already produces the
    canonical table during save preparation; this helper is a thin
    wrapper that does index lookup against the in-progress table.

    Records with status='dropped' are silently skipped here (the resolver
    already logged them as warnings).
    """
    from ..Link.wrapper import cmodellib

    if not cmodellib.has_gtpt_api():
        # Older DLL build — nothing we can do here, caller falls back
        # to the legacy transferGotoPoints path.
        return 0

    pushed = 0
    for r in records:
        if r.status == 'dropped':
            continue
        # Translate strings → TEXT indices via the helper. If the helper
        # rejects either string we drop the record rather than write a
        # bad index.
        try:
            n0 = string_table_helper(r.name)
            n1 = string_table_helper(r.group_name)
        except Exception:
            continue
        if n0 is None or n1 is None or n0 < 0 or n1 < 0:
            continue
        cmodellib.addGotoPoint(cskinmodel, int(n0), int(n1),
                                int(r.slot), int(r.vertex_index))
        pushed += 1
    return pushed
