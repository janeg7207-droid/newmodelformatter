"""Shared constants for physics sub-stream handling.

Extracted so both physics_patcher.py (Serialize/) and physics_swap.py
(Blender/Extras/) reference a single source of truth. The patcher's
version is the SUPERSET — it includes CAS standalone tags
(CYWA, YWA!) on top of the four full-attire tags used by the swap UI.
The swap-UI categories (HAIR_TAGS / OTHER_TAGS) are derived in
physics_swap.py by filtering this map.
"""


# Outer tags identifying physics sub-streams. Values are the file-
# extension convention used for dedicated dump files on disk.
#
# Full-attire / MCD-embedded tags (used by both patcher and swap UI):
#   HYWA — hair sim + bone tree
#   HCYW — hair corrective (render-mesh → collider binding)
#   OYWA — body/attire sim + bone tree
#   OCYW — body/attire corrective
#
# CAS standalone tags (patcher only — these are byte-identical inside
# but ride in CAS pieces like hair_*.mcd / jacket_*.mcd where they
# appear under different outer tags. Engine merges CYWA→HCYW and
# YWA!→HYWA at composition time):
#   CYWA — CAS corrective (logical HCYW)
#   YWA! — CAS sim       (logical HYWA)
PHYSICS_OUTER_TAGS = {
    b'HYWA': '.hair_ywa',
    b'HCYW': '.hair_corr_ywa',
    b'OYWA': '.other_ywa',
    b'OCYW': '.other_corr_ywa',
    b'CYWA': '.cas_corr_ywa',
    b'YWA!': '.cas_ywa',
}
