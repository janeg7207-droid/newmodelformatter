"""2K26 material-template registry backed by ``Link/material_presets.json``.

This module exposes the previously-orphaned ``material_presets.json`` as a
queryable registry of shader templates for the 2K26 pipeline.

The JSON's schema mirrors what the engine's ``CMaterialTemplates::loadTemplates()``
consumes: a list of preset objects each carrying ``Shader`` / ``Template`` /
``Type`` metadata alongside an arbitrary set of typed parameter values.

Historical note
---------------
``Link/material_presets.README.md`` previously stated that no Python code
consumed this file. That statement is now obsolete -- this module is its
consumer. Add new templates by editing the JSON; no Python change is
required (call :func:`reload` to pick up changes at runtime).

Lookup model
------------
Each entry is keyed by ``(shader, type_, alias)`` where:

* ``shader``  -> the JSON's ``Shader``   field (e.g. ``"yCh_skin"``)
* ``type_``   -> the JSON's ``Type``     field (e.g. ``"Normal"``)
* ``alias``   -> the JSON's ``Template`` field (e.g. ``"Default"``)

Lookups are case-insensitive. When an exact ``alias`` miss occurs,
:func:`get_template` falls back to ``alias="Default"``.

Value normalisation
-------------------
JSON params are wrapped in ``{"<type>": value}`` envelopes. We unwrap to
Python natives::

    {"float":      0.5}              -> 0.5
    {"hash":       12345}            -> 12345
    {"string":     "foo"}            -> "foo"
    {"uint":       5}                -> 5
    {"vector":     [a,b,c]}          -> (a, b, c)
    {"vector":     [a,b,c,d]}        -> (a, b, c, d)
    {"shared_vec": [...]}            -> tuple(...)
    {"shared_long": n}               -> int(n)

Bare ints in the JSON (e.g. ``"flag0": 0``) are passed through unchanged.
Unknown envelope shapes are preserved verbatim (as the original dict).
"""

from __future__ import annotations

import json
import os
from typing import Any

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_HERE = os.path.dirname(os.path.abspath(__file__))
_JSON_PATH = os.path.normpath(
    os.path.join(_HERE, os.pardir, "Link", "material_presets.json")
)

#: Fields that identify a template rather than carry parameter data.
_METADATA_KEYS = frozenset({"Shader", "Template", "Type"})

#: Mapping of engine shader-byte -> ``(shader, type_)`` names. Entries without a
#: JSON preset return ``None`` from :func:`get_default_params`.
#:
#: Audit (2026-05) fixed three gaps vs material_presets.json:
#:   * 0x03 yGlass: no t_NewGlass entry — map to t_Translucency (the only
#:     render-correct default; Error variant is a debug fallback).
#:   * 0x14 eyelash lives under yCh_eyeOv/Eyelash, not yCh_eye — the wrong
#:     mapping was why get_default_params(0x14) returned None → NULL_SENTINEL.
#:   * 0x1C yCh_hairMesh has NO preset; left mapped for a deterministic name,
#:     get_default_params returns None (one-shot warning below).
#:
#: 0x13: schema labels it PedestrianFacePaint (27-field, "name guessed"), but the
#: runtime CJmtlReader::readCaruncle (jmtl_reader.cpp:813) reads a 13-field
#: caruncle table — the cpp is authoritative. Mapped to yCh_head/Caruncle (vs the
#: equivalent yCh_caruncle/Normal) to preserve prior regression coverage.
#: 0x18 SkinFull: schema groups it under the head shader (28-field); runtime
#: matches (readSkinFull). Mapping unchanged.
SHADER_BYTE_TO_NAMES: dict[int, tuple[str, str]] = {
    0x01: ("yPBR", "t_BRDF"),
    0x02: ("yIllumination", "t_Illumination"),
    0x03: ("yGlass", "t_Translucency"),  # 2026-05: was t_NewGlass (no JSON entry)
    0x06: ("speedTree", "Default"),
    0x07: ("Water", "t_Water"),
    0x12: ("yCh_eye", "Normal"),
    0x13: ("yCh_head", "Caruncle"),
    0x14: ("yCh_eyeOv", "Eyelash"),  # 2026-05: was yCh_eye/Eyelash (wrong shader name)
    0x15: ("yCh_gear", "Normal"),
    0x16: ("yCh_hair", "NewHair_ColorChanging"),
    0x17: ("yCh_head", "Normal"),
    0x18: ("yCh_head", "Normal"),  # SkinFull -- same names, distinguished by field count
    0x19: ("yCh_skin", "Normal"),
    0x1A: ("yCh_Teeth", "Normal"),
    0x1B: ("yCh_fur", "Default"),
    0x1C: ("yCh_hairMesh", "Default"),
    0x1D: ("yCh_shellFur", "Default"),
}

#: Byte values that intentionally lack a JSON template (see audit above).
#: ``get_default_params`` emits a one-shot warning on first miss so the
#: caller can tell the difference between "unknown shader byte" (returns
#: None silently) and "known shader byte we just don't have presets for".
_KNOWN_MISSING_PRESETS: frozenset[int] = frozenset()

#: Tracks which missing-preset warnings have already been emitted (one-shot).
_WARNED_MISSING: set[int] = set()


# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------

#: Lazy-populated registry: ``{(shader_lc, type_lc, alias_lc): params_dict}``
_REGISTRY: dict[tuple[str, str, str], dict[str, Any]] | None = None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _normalize_value(value: Any) -> Any:
    """Collapse a JSON envelope ``{"<type>": v}`` to a Python-native value.

    Bare (non-envelope) values pass through unchanged. Unknown envelope tags
    are returned verbatim so callers can still inspect them.
    """
    # Bare value -- e.g. int flag fields.
    if not isinstance(value, dict) or len(value) != 1:
        return value

    ((tag, payload),) = value.items()

    if tag == "float":
        return float(payload)
    if tag in ("hash", "uint", "shared_long"):
        # ``hash`` is u64; Python ints are unbounded so this is safe.
        return int(payload)
    if tag == "string":
        return str(payload)
    if tag in ("vector", "shared_vec"):
        if isinstance(payload, list):
            return tuple(payload)
        return payload

    # Unknown envelope -- preserve as-is for forensic inspection.
    return value


def _load_registry() -> dict[tuple[str, str, str], dict[str, Any]]:
    """Parse the JSON from disk into the normalised registry shape."""
    with open(_JSON_PATH, "r", encoding="utf-8") as fh:
        data = json.load(fh)

    registry: dict[tuple[str, str, str], dict[str, Any]] = {}
    for entry in data.get("Templates", []):
        if not isinstance(entry, dict):
            continue
        shader = entry.get("Shader")
        type_ = entry.get("Type")
        alias = entry.get("Template")
        if shader is None or type_ is None or alias is None:
            # Malformed entry -- skip rather than poison the registry.
            continue

        params = {
            k: _normalize_value(v)
            for k, v in entry.items()
            if k not in _METADATA_KEYS
        }
        registry[(shader.lower(), type_.lower(), alias.lower())] = params

    return registry


def _ensure_loaded() -> dict[tuple[str, str, str], dict[str, Any]]:
    global _REGISTRY
    if _REGISTRY is None:
        _REGISTRY = _load_registry()
    return _REGISTRY


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_template(
    shader: str,
    type_: str,
    alias: str = "Default",
) -> dict[str, Any] | None:
    """Look up a template by ``(shader, type_, alias)``.

    Args:
        shader: The shader name (e.g. ``"yCh_skin"``).
        type_:  The type/sub-template name (e.g. ``"Normal"``).
        alias:  The named preset variant (e.g. ``"Default"``).

    Returns:
        A dict of ``{param_name: normalised_value}`` if found, else ``None``.
        Falls back to ``alias="Default"`` when the requested alias is missing
        but a Default variant of the same ``(shader, type_)`` exists.
    """
    registry = _ensure_loaded()
    key = (shader.lower(), type_.lower(), alias.lower())
    hit = registry.get(key)
    if hit is not None:
        # Return a shallow copy so callers can mutate freely.
        return dict(hit)

    if alias.lower() != "default":
        fallback = registry.get((shader.lower(), type_.lower(), "default"))
        if fallback is not None:
            return dict(fallback)

    return None


def list_templates() -> list[tuple[str, str, str]]:
    """Return every ``(shader, type_, alias)`` triple in the registry.

    The triples are returned with their *original-case* metadata reconstructed
    from the cached entries' lowercase keys -- but to preserve canonical
    casing for downstream consumers, we re-derive from the raw JSON on the
    fly. (The registry only stores lowercase keys for lookup.)
    """
    # Re-read the JSON's Templates list to preserve canonical case.
    # This is cheap (small file) and keeps casing exactly right for callers
    # that want to round-trip the triples back into get_template().
    with open(_JSON_PATH, "r", encoding="utf-8") as fh:
        data = json.load(fh)

    out: list[tuple[str, str, str]] = []
    for entry in data.get("Templates", []):
        if not isinstance(entry, dict):
            continue
        shader = entry.get("Shader")
        type_ = entry.get("Type")
        alias = entry.get("Template")
        if shader is None or type_ is None or alias is None:
            continue
        out.append((shader, type_, alias))
    return out


def get_shader_byte(shader: str, type_: str = "") -> int | None:
    """Resolve an explicit ``Shader::Type`` selection to its engine byte.

    Explicit choices must not be routed through slot-name inference. Doing so
    previously wrote gear byte 0x15 for a material named ``jacket`` even when
    the user explicitly selected glass or illumination.
    """
    sh = (shader or "").strip().lower()
    ty = (type_ or "").strip().lower()

    simple = {
        "ypbr": 0x01,
        "yillumination": 0x02,
        "yglass": 0x03,
        "speedtree": 0x06,
        "water": 0x07,
        "ych_eyeov": 0x14,
        "ych_gear": 0x15,
        "ych_trans": 0x15,
        "ych_hair": 0x16,
        "ych_skin": 0x19,
        "ych_teeth": 0x1A,
        "ych_fur": 0x1B,
        "ych_hairmesh": 0x1C,
        "ych_shellfur": 0x1D,
    }
    if sh in simple:
        return simple[sh]
    if sh == "ych_caruncle":
        return 0x13
    if sh == "ych_eye":
        return 0x14 if ty == "eyelash" else 0x12
    if sh == "ych_head":
        if ty == "caruncle":
            return 0x13
        if ty == "skinfull":
            return 0x18
        return 0x17
    return None


def get_default_params(shader_byte: int) -> dict[str, Any] | None:
    """Convenience: look up the Default template for ``shader_byte``.

    Args:
        shader_byte: An engine shader byte (e.g. ``0x19`` for ``yCh_skin``).

    Returns:
        The normalised parameter dict for the Default preset, or ``None`` if
        the byte is unknown or the registry has no preset for that
        ``(shader, type_)`` pair.
    """
    names = SHADER_BYTE_TO_NAMES.get(shader_byte)
    if names is None:
        return None
    shader, type_ = names
    params = get_template(shader, type_, "Default")
    if params is None and shader_byte in _KNOWN_MISSING_PRESETS:
        # One-shot warning so log noise stays bounded across an export
        # that hits the same shader on every gear/hair mesh.
        if shader_byte not in _WARNED_MISSING:
            _WARNED_MISSING.add(shader_byte)
            print(
                f"[material_templates] WARN: shader byte 0x{shader_byte:02X} "
                f"({shader}/{type_}) is mapped but has no preset in "
                f"material_presets.json; caller will see empty defaults."
            )
    return params


def reload() -> None:
    """Drop the cached registry; next lookup will re-read the JSON."""
    global _REGISTRY
    _REGISTRY = None


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

def _selftest() -> bool:
    """Smoke-test the public API. Returns True on success."""
    ok = True
    reload()

    triples = list_templates()
    print(f"Loaded {len(triples)} templates")

    skin = get_default_params(0x19)
    if not skin:
        print("FAIL: get_default_params(0x19) returned falsy")
        ok = False
    else:
        print(f"  get_default_params(0x19) -> {len(skin)} params"
              f" (sample keys: {sorted(skin)[:3]})")

    gear = get_template("yCh_gear", "Normal", "Default")
    if not gear:
        print("FAIL: get_template('yCh_gear','Normal') returned falsy")
        ok = False
    else:
        print(f"  get_template('yCh_gear','Normal','Default')"
              f" -> {len(gear)} params")

    missing = get_template("nonexistent", "foo")
    if missing is not None:
        print(f"FAIL: get_template('nonexistent','foo') = {missing!r}")
        ok = False
    else:
        print("  get_template('nonexistent','foo') -> None  (ok)")

    unknown_byte = get_default_params(0xFF)
    if unknown_byte is not None:
        print(f"FAIL: get_default_params(0xFF) = {unknown_byte!r}")
        ok = False
    else:
        print("  get_default_params(0xFF) -> None  (ok)")

    # Case-insensitive lookup
    ci = get_template("YCH_SKIN", "NORMAL", "DEFAULT")
    if not ci:
        print("FAIL: case-insensitive lookup failed")
        ok = False

    # Alias fallback
    fb = get_template("yCh_skin", "Normal", "NoSuchAlias")
    if not fb:
        print("FAIL: alias fallback to Default failed")
        ok = False

    print("PASS" if ok else "FAIL")
    return ok


if __name__ == "__main__":
    import sys
    sys.exit(0 if _selftest() else 1)
