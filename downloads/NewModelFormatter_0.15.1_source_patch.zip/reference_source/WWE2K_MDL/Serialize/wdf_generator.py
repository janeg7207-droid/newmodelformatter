"""
WDF Generator - Create WDF files from M_Head and M_Combinations meshes

Generates wrap deformation data that makes M_Combinations (beard, chainmail, etc.)
follow M_Head movement. Works by finding the closest head triangle for each
combinations vertex and computing barycentric attachment.
"""

import struct
import numpy as np
from typing import List, Tuple, Optional
from ..Link.log import dlog

# Half-float conversion
def float_to_half(f: float) -> int:
    """Convert float32 to float16 bits"""
    import struct
    try:
        half_bytes = struct.pack('<e', f)
        return struct.unpack('<H', half_bytes)[0]
    except (OverflowError, struct.error):
        # Handle overflow - clamp to max half
        if f > 65504:
            return 0x7BFF  # Max positive half
        elif f < -65504:
            return 0xFBFF  # Max negative half
        else:
            return 0

def half_to_float(h: int) -> float:
    """Convert float16 bits to float32"""
    half_bytes = struct.pack('<H', h)
    return struct.unpack('<e', half_bytes)[0]


def compute_triangle_normal(v0, v1, v2):
    """Compute unit normal of triangle"""
    edge1 = np.array(v1) - np.array(v0)
    edge2 = np.array(v2) - np.array(v0)
    normal = np.cross(edge1, edge2)
    length = np.linalg.norm(normal)
    if length > 1e-10:
        return normal / length
    return np.array([0, 1, 0])


def point_to_triangle_distance(point, v0, v1, v2):
    """
    Compute closest point on triangle to given point.
    Returns (closest_point, barycentric_coords, distance)
    """
    point = np.array(point)
    v0 = np.array(v0)
    v1 = np.array(v1)
    v2 = np.array(v2)
    
    # Compute edges
    edge0 = v1 - v0
    edge1 = v2 - v0
    v0_to_point = point - v0
    
    # Compute dot products
    d00 = np.dot(edge0, edge0)
    d01 = np.dot(edge0, edge1)
    d11 = np.dot(edge1, edge1)
    d20 = np.dot(v0_to_point, edge0)
    d21 = np.dot(v0_to_point, edge1)
    
    # Compute barycentric coordinates
    denom = d00 * d11 - d01 * d01
    if abs(denom) < 1e-10:
        # Degenerate triangle
        return v0, (1.0, 0.0, 0.0), np.linalg.norm(point - v0)
    
    v = (d11 * d20 - d01 * d21) / denom
    w = (d00 * d21 - d01 * d20) / denom
    u = 1.0 - v - w
    
    # Clamp to triangle
    if u < 0:
        # Project onto edge v1-v2
        t = np.clip(np.dot(point - v1, v2 - v1) / max(np.dot(v2 - v1, v2 - v1), 1e-10), 0, 1)
        closest = v1 + t * (v2 - v1)
        u, v, w = 0, 1-t, t
    elif v < 0:
        # Project onto edge v0-v2
        t = np.clip(np.dot(point - v0, v2 - v0) / max(np.dot(v2 - v0, v2 - v0), 1e-10), 0, 1)
        closest = v0 + t * (v2 - v0)
        u, v, w = 1-t, 0, t
    elif w < 0:
        # Project onto edge v0-v1
        t = np.clip(np.dot(point - v0, v1 - v0) / max(np.dot(v1 - v0, v1 - v0), 1e-10), 0, 1)
        closest = v0 + t * (v1 - v0)
        u, v, w = 1-t, t, 0
    else:
        # Inside triangle
        closest = u * v0 + v * v1 + w * v2
    
    distance = np.linalg.norm(point - closest)
    return closest, (u, v, w), distance


def find_closest_triangle(point, vertices, triangles):
    """
    Find closest triangle to a point.
    Returns (triangle_index, closest_point, barycentric, distance)
    """
    best_tri = 0
    best_closest = vertices[triangles[0][0]]
    best_bary = (1.0, 0.0, 0.0)
    best_dist = float('inf')
    
    for tri_idx, (i0, i1, i2) in enumerate(triangles):
        v0 = vertices[i0]
        v1 = vertices[i1]
        v2 = vertices[i2]
        
        closest, bary, dist = point_to_triangle_distance(point, v0, v1, v2)
        
        if dist < best_dist:
            best_dist = dist
            best_tri = tri_idx
            best_closest = closest
            best_bary = bary
    
    return best_tri, best_closest, best_bary, best_dist


def generate_wdf_entry(combo_pos, head_vertices, head_triangles, tri_idx, closest_point, bary, distance):
    """
    Generate a 48-byte WDF entry.
    
    Args:
        combo_pos: M_Combinations vertex position
        head_vertices: M_Head vertex positions
        head_triangles: M_Head triangle indices
        tri_idx: Index of closest head triangle
        closest_point: Closest point on head surface
        bary: Barycentric coordinates (u, v, w)
        distance: Distance from head surface
    
    Returns:
        48-byte entry
    """
    entry = bytearray(48)
    
    # Get triangle vertex indices
    i0, i1, i2 = head_triangles[tri_idx]
    
    # Compute direction vector (displacement from head surface to combinations vertex)
    combo_pos = np.array(combo_pos)
    direction = combo_pos - np.array(closest_point)
    
    # Normalize if needed, keep magnitude in blend weight
    dir_length = np.linalg.norm(direction)
    if dir_length > 1e-6:
        dir_normalized = direction / dir_length
    else:
        dir_normalized = np.array([0, 0, 1])
        dir_length = 0
    
    # Direction vector 1 (half3 at offset 0)
    struct.pack_into('<HHH', entry, 0,
        float_to_half(dir_normalized[0]),
        float_to_half(dir_normalized[1]),
        float_to_half(dir_normalized[2]))
    
    # W component 1 (half at offset 6) - use distance
    struct.pack_into('<H', entry, 6, float_to_half(dir_length))
    
    # Direction vector 2 (half3 at offset 8) - same as direction 1
    struct.pack_into('<HHH', entry, 8,
        float_to_half(dir_normalized[0]),
        float_to_half(dir_normalized[1]),
        float_to_half(dir_normalized[2]))
    
    # W component 2 (half at offset 14)
    struct.pack_into('<H', entry, 14, float_to_half(dir_length))
    
    # Blend weight 1 (half at offset 16) - use barycentric u
    struct.pack_into('<H', entry, 16, float_to_half(bary[0]))
    
    # Repeated weights (offset 18-21)
    struct.pack_into('<HH', entry, 18, float_to_half(bary[1]), float_to_half(bary[2]))
    
    # Zero padding at 22
    struct.pack_into('<H', entry, 22, 0)
    
    # Blend weight 2 (half at offset 24)
    struct.pack_into('<H', entry, 24, float_to_half(1.0))
    
    # Repeated weights (offset 26-29)
    struct.pack_into('<HH', entry, 26, float_to_half(1.0), float_to_half(1.0))
    
    # Zero padding at 30
    struct.pack_into('<H', entry, 30, 0)
    
    # Triangle indices 1 (3x uint16 at offset 32)
    struct.pack_into('<HHH', entry, 32, i0, i1, i2)
    
    # Zero padding at 38
    struct.pack_into('<H', entry, 38, 0)
    
    # Triangle indices 2 (3x uint16 at offset 40) - same triangle
    struct.pack_into('<HHH', entry, 40, i0, i1, i2)
    
    # Zero padding at 46
    struct.pack_into('<H', entry, 46, 0)
    
    return bytes(entry)


def generate_wdf(combo_vertices, head_vertices, head_triangles, mesh_name="M_Combinations", use_kdtree=True):
    """
    Generate complete WDF data.
    
    Args:
        combo_vertices: List of (x,y,z) for M_Combinations
        head_vertices: List of (x,y,z) for M_Head
        head_triangles: List of (i0,i1,i2) triangle indices for M_Head
        mesh_name: Name for the mesh in WDF
        use_kdtree: Use scipy KDTree for faster lookup (if available)
    
    Returns:
        bytes: Complete WDF file data
    """
    dlog(f"[WDF Gen] Generating WDF for {len(combo_vertices)} vertices")
    dlog(f"[WDF Gen] Head mesh: {len(head_vertices)} vertices, {len(head_triangles)} triangles")
    
    # Try to use KDTree for speed
    tree = None
    tri_centers = None
    if use_kdtree:
        try:
            from scipy.spatial import cKDTree
            # Build tree of triangle centers for initial fast lookup
            tri_centers = []
            for i0, i1, i2 in head_triangles:
                center = (np.array(head_vertices[i0]) + 
                         np.array(head_vertices[i1]) + 
                         np.array(head_vertices[i2])) / 3
                tri_centers.append(center)
            tree = cKDTree(tri_centers)
            dlog("[WDF Gen] Using KDTree acceleration")
        except ImportError:
            dlog("[WDF Gen] scipy not available, using brute force (slower)")
    
    entries = []
    
    for i, combo_pos in enumerate(combo_vertices):
        if i % 1000 == 0:
            dlog(f"[WDF Gen] Processing vertex {i}/{len(combo_vertices)}")
        
        if tree is not None:
            # Use KDTree to find candidate triangles, then refine
            _, candidates = tree.query(combo_pos, k=min(10, len(head_triangles)))
            if isinstance(candidates, int):
                candidates = [candidates]
            
            best_tri = candidates[0]
            best_closest = tri_centers[best_tri]
            best_bary = (0.33, 0.33, 0.34)
            best_dist = float('inf')
            
            for tri_idx in candidates:
                i0, i1, i2 = head_triangles[tri_idx]
                closest, bary, dist = point_to_triangle_distance(
                    combo_pos,
                    head_vertices[i0],
                    head_vertices[i1],
                    head_vertices[i2]
                )
                if dist < best_dist:
                    best_dist = dist
                    best_tri = tri_idx
                    best_closest = closest
                    best_bary = bary
        else:
            # Brute force
            best_tri, best_closest, best_bary, best_dist = find_closest_triangle(
                combo_pos, head_vertices, head_triangles
            )
        
        entry = generate_wdf_entry(
            combo_pos, head_vertices, head_triangles,
            best_tri, best_closest, best_bary, best_dist
        )
        entries.append(entry)
    
    # Build WDF file
    output = bytearray()
    
    # Header
    output.extend(b'WDF!')
    output.extend(struct.pack('<I', 1))  # Version
    
    # MESH chunk
    output.extend(b'MESH')
    name_bytes = mesh_name.encode('utf-8')
    output.extend(struct.pack('<I', len(name_bytes)))
    output.extend(name_bytes)
    # Pad to 4-byte alignment
    while len(output) % 4 != 0:
        output.append(0)
    
    # Vertex count
    output.extend(struct.pack('<I', len(entries)))
    
    # Vertex data
    for entry in entries:
        output.extend(entry)
    
    # End marker
    output.extend(b'END!')
    output.extend(b'\x00\x00\x00\x00')
    
    dlog(f"[WDF Gen] Generated {len(output)} bytes")
    return bytes(output)


def generate_wdf_file(combo_vertices, head_vertices, head_triangles, output_path, mesh_name="M_Combinations"):
    """
    Generate and save WDF file.
    """
    wdf_data = generate_wdf(combo_vertices, head_vertices, head_triangles, mesh_name)
    
    with open(output_path, 'wb') as f:
        f.write(wdf_data)
    
    dlog(f"[WDF Gen] Saved to {output_path}")
    return True
