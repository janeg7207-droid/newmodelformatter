"""
WWE 2K26 .jmtl FlatBuffer writer — inverse of jmtl_resolver / jmtl_reader.cpp.

Why this exists
───────────────
The reader path (Blender/Extras/jmtl_resolver.py + the C++ reference at
jmtl_reader.cpp) gives us a one-way ticket into JMTL — enough to recover
a colorMap hash so import can bind a diffuse. For *export* and material
authoring inside Blender we need the inverse: take a (shader_byte, params)
description and emit a valid .jmtl byte stream that the WWE 2K26 engine
will accept.

This module owns that emission. It is **not** a round-trip writer — the
caller doesn't get back the exact bytes of a vanilla sample even if they
hand us identical params. FlatBuffers permits multiple equally-valid
serializations of the same logical content (vtable dedup, table packing
order, alignment padding), and chasing byte parity would be brittle and
purposeless. The contract we promise is "the engine accepts our output
and reads back the same field values," not "diff matches."

Format recap (from jmtl_reader.cpp + sample hex dumps)
──────────────────────────────────────────────────────
JMTL is a standard FlatBuffer 2.0 buffer with the file_identifier "Mate"
emitted at offset 4 (Finish(root, b"Mate") handles this for free).

Root table (3 vtable slots):
    [0] unused (always absent in shipped content)
    [1] u16      shader_type      — enum 0x01..0x1D
    [2] uoffset  payload_table    — per-shader sub-table

Payload table layout is shader-specific. See per-_write_yCh_* functions
below for each schema; field indices and types are mirrored 1:1 from
the CJmtlReader::read* handlers in jmtl_reader.cpp.

Child sub-tables that recur across shaders:
    * "color" child:  3× u8  at slots [0]=R [1]=G [2]=B (0..255)
    * "uv" child:     2× f32 at slots [0]=X [1]=Y
    * "glow" child:   4× f32 at slots [0..3]=R,G,B,A (HDR)
    * "rgba" child:   4× u8  at slots [0..3]=R,G,B,A (0..255)

Hash sentinels: 0 and 0xFFFFFFFFFFFFFFFF both mean "no texture bound."
Either input is normalized to "omit the vtable slot" so the reader's
fallback-to-default path engages.

Public API
──────────
    write_jmtl(shader_byte, params) -> bytes

Where `params` is a flat dict matching the reader-side property names
(e.g. "colorMap@ref", "g_AOcolorR", "g_detailMapU"). Texture hashes are
already-computed u64s (use jmtl_resolver._fnv1a_64_lower or your own
hasher upstream). Missing keys → omitted vtable slots → engine uses the
shader-template default. None / 0 / 0xFFFFFFFFFFFFFFFF for hashes also
maps to "omitted."
"""

from __future__ import annotations  # PEP 563: stringize annotations so the

# module-level dict[...] / tuple[...] hints below don't evaluate at import time
# (dict[str,str] is not subscriptable on Python 3.7/3.8 = Blender 2.90-2.92).
# Keeps this writer importable on the export path under old Blender.
import math
import struct

# ─── flatbuffers import: prefer vendored, fall back to system ───────────────
#
# CRASH-BUG NOTE (2026-05): the game runtime's JMTL reader is stricter than the
# tools-side reader — a missing required vtable slot null-derefs at load instead
# of falling back to the template default, so JMTLs crash unless every required
# field is emitted (even at the default value). Two-part fix:
#   1. Builder.ForceDefaults(True) so scalar slots always emit.
#   2. Policy-driven fallbacks for required texture-ref (u64) slots, since FB
#      can't force-emit a None param (the null sentinel means present/unbound).
# Empty child sub-tables (glow rgba, PbrUvScroll uv) are also emitted as
# present-but-empty — vanilla does this and the runtime needs a non-null ptr.
#
# Vendored copy (Blender/_vendor/flatbuffers/) is the production pin; the system
# fallback is for isolated unit tests. API shape is identical.

try:
    from ..Blender._vendor import flatbuffers  # type: ignore
    _FB_SOURCE = "vendored"
except Exception:
    try:
        import flatbuffers  # type: ignore
        _FB_SOURCE = "system"
    except Exception as e:  # pragma: no cover - import error path
        flatbuffers = None
        _FB_SOURCE = f"unavailable: {e!r}"


# ─── Sentinel values mirrored from the reader ───────────────────────────────

_U64_NULL_SENTINEL = 0xFFFFFFFFFFFFFFFF


def _is_null_hash(v):
    """A texture hash is "null" if it's None, 0, or the engine sentinel.

    Mirrors CJmtlReader::rdU64 which skips emitting the StMaterial entry
    when the stored u64 is 0 or 0xFFFF... — we treat the same values as
    "don't write the vtable slot" on the writer side. The reader's
    template-default code path then engages on read-back.
    """
    return v is None or v == 0 or v == _U64_NULL_SENTINEL


# ─── Engine-default fallbacks for required texture-ref slots ────────────────
#
# Harvested from vanilla Rock 100_The_Rock_2017 samples (shoes/body/head.jmtl).
# These slots must be PRESENT even with no bound texture or the runtime
# null-derefs; a real vanilla hash (or the null sentinel) guarantees a binding
# the engine can resolve to its built-in default. Add an entry when a crash
# report points at a required slot we skip (harvest via _extract_defaults.py).

_GEAR_ENGINE_DEFAULTS = {
    # field 12 nrMap@ref — engine default normal map (flat blue 0x8080FF).
    "nrMap@ref": 0xE4D4D2FFCCE99AC3,
}

_SKIN_ENGINE_DEFAULTS = {
    # INVISIBLE-BODY FIX (2026-05): vanilla body.jmtl (5 BaseModel samples)
    # ALWAYS populates outer [0 colorMap, 1 nrMap, 6 g_AOcolor, 9 g_detailMap UV,
    # 18 glow]. Refs 0/1 are per-character (XXX substitution), but emit the null
    # sentinel as a fallback so the slot is present and the engine falls through
    # to built-in body defaults. (Slot presence > hash value — see module NOTE.)
    "colorMap@ref":  _U64_NULL_SENTINEL,
    "nrMap@ref":     _U64_NULL_SENTINEL,
}

_HEAD_ENGINE_DEFAULTS = {
    # INVISIBLE-HEAD FIX (2026-05): vanilla head.jmtl (same 5 samples) ALWAYS
    # populates [1 colorMap, 5 nrMap, 9 g_AOcolor, 12 g_detailMap UV, 22 glow].
    # Same reasoning as _SKIN_ENGINE_DEFAULTS — slot must be present even when
    # neither XXX substitution nor user binding supplies a hash.
    "colorMap@ref":  _U64_NULL_SENTINEL,
    "nrMap@ref":     _U64_NULL_SENTINEL,
}

# Vanilla head/body child defaults (all 5 samples share these EXACT values —
# the engine-default skin tone for the AOcolor occlusion tint and detail-map UV
# tiling). Used when the caller supplies no g_AOcolor*/g_detailMap* and no preset
# loaded, so the required child slot isn't null. Floats are byte/255 (u8 RGB
# encoding); UV are tile counts (head=20, body=80). When the orchestrator runs,
# material_presets.json values take precedence via _resolve_template, so this
# only fires for direct write_jmtl({}) callers.
_HEAD_AOCOLOR_DEFAULT = (114.0 / 255.0, 43.0 / 255.0, 40.0 / 255.0)
_HEAD_DETAILMAP_DEFAULT = (20.0, 20.0)
_SKIN_AOCOLOR_DEFAULT = (114.0 / 255.0, 43.0 / 255.0, 40.0 / 255.0)
_SKIN_DETAILMAP_DEFAULT = (80.0, 80.0)


# ─── Param key aliasing ─────────────────────────────────────────────────────
#
# material_presets.json uses legacy 2K22-era key names for slots the 2K26 reader
# renamed. _LEGACY_FIELD_ALIASES maps a modern reader-side key (what the writer
# and _extract_texture_bindings use) to the legacy preset key it falls back to.
# Per-shader writers call _resolve_aliased(params, "nrMap@ref", alias). Add a
# pair when a 2K26 field name diverges from the preset JSON key.
#
# Per-shader audit of material_presets.json (2026-05):
#   shader   slot   reader key       preset key (legacy)
#   ──────   ────   ──────────────   ────────────────────
#   0x12     3      nrMap@ref        g_nrmMap@ref            (alias)
#   0x13     1      nrMap@ref        g_nrmMap@ref (never_pop) (alias kept defensively)
#   0x14     0      colorMap@ref     g_mEyeOvlPrm@ref         (alias)
#   0x15     12     nrMap@ref        g_nrmMap@ref            (alias)
#   0x16     —      no nrMap slot in outer table             (n/a)
#   0x17     5      nrMap@ref        g_nrmMap@ref            (alias)
#   0x18     5      nrMap@ref        g_nrmMap@ref            (alias)
#   0x19     1      nrMap@ref        g_nrmMap@ref            (alias)
#   0x1A     1      nrMap@ref        g_nrmMap@ref            (alias)  ← TEETH-BLACK FIX
#
# Every normal-map u64 ref uses nrMap@ref canonically; g_nrmMap@ref is the legacy
# spelling bridged via _resolve_aliased.
_LEGACY_FIELD_ALIASES: dict[str, str] = {
    # 2K26 runtime field name -> legacy 2K25 / preset JSON key
    "nrMap@ref":    "g_nrmMap@ref",     # head 0x17, skin 0x19, skinFull 0x18,
                                        # teeth 0x1A, eye 0x12, gear 0x15,
                                        # caruncle 0x13 (never_pop, kept
                                        # defensively in case future presets
                                        # ship the legacy key for that slot
                                        # and the orchestrator's strip pass
                                        # misses).
    "colorMap@ref": "g_mEyeOvlPrm@ref", # eyelash 0x14 only — yCh_eyeOv/Eyelash
                                        # preset names the ref differently from
                                        # the 2K26 reader (which calls it
                                        # colorMap@ref at field 0).
    # Add more pairs here as new field-name divergences are discovered.
}

# Backward-compatibility alias for the per-shader writers that already
# reference this name. New code should index ``_LEGACY_FIELD_ALIASES``
# directly so the table stays the single source of truth.
_NRMAP_LEGACY_ALIAS = _LEGACY_FIELD_ALIASES["nrMap@ref"]


def _resolve_aliased(params, primary_key, alias_key):
    """Return the value for ``primary_key`` if present, else for ``alias_key``.

    Used to bridge legacy preset keys (e.g. ``g_nrmMap@ref``) to the
    modern reader-side names (e.g. ``nrMap@ref``). The caller passes
    the primary (modern) key to the slot helper; this function pre-
    populates that key in a local copy of params when only the alias
    is present.

    Returns a (possibly-new) params dict — never mutates the input.
    """
    if primary_key in params and params[primary_key] is not None:
        return params
    if alias_key in params and params[alias_key] is not None:
        out = dict(params)
        out[primary_key] = params[alias_key]
        return out
    return params

# HAIR engine defaults — null sentinels so the runtime sees non-null entries.
# Vanilla hair_ALPHA emits flowMap@ref, g_mPixMsk@ref, g_comboMap@ref
# unconditionally (slots [0,1,2,4,5,6,11]); omitting 2/4/5/6/11 crashed the
# runtime (invisible hair). The sentinel means "no texture bound" — the engine
# falls through to its hair defaults instead of null-dereffing an absent slot.
_HAIR_ENGINE_DEFAULTS = {
    "flowMap@ref":    _U64_NULL_SENTINEL,
    "g_mPixMsk@ref":  _U64_NULL_SENTINEL,
    "g_comboMap@ref": _U64_NULL_SENTINEL,
}


# ─── NEVER-POPULATE u64 ref slots per shader (CRASH CULPRIT FIX 2026-05) ────
#
# u64 texture-ref slots that NO shipped sample populates (audited across
# 481-1043 JMTLs/shader; Triple H 2018 BaseModel crash was the smoking gun).
# material_presets.json ships placeholder hashes (FNV1a of "XXX_muscle" etc.)
# for these; unfiltered they get substituted to nonexistent textures and the
# engine crashes resolving them. Rule: None/0/null-sentinel OR in this set →
# the writer must NOT emit the slot, regardless of ForceDefaults. The
# orchestrator also strips these (belt-and-suspenders, _strip_never_populate).
_NEVER_POPULATE_U64 = {
    # Empirically-derived (2026-05) from a 510-character vanilla corpus.
    # A slot is in this set only when ZERO of N samples populate it AND
    # we have ≥5 samples of the shader. The full 510-char corpus walk
    # in vanilla_basis (see get_emission_policy) supersedes this static
    # table when the corpus is available; the table is kept as a static
    # fallback for environments where the corpus is missing.
    #
    # NOTE: slots like 0x17/3 g_facepaintNrm@ref ARE populated by some
    # vanilla characters (15/514, e.g. face-painted wrestlers like
    # Undertaker). They are NOT in this NEVER set; the data-driven
    # policy classifies them as "sometimes" and emits them only when
    # caller supplies a value.
    0x19: {2, 3, 4},   # muscleMap, detailzoneMap, translucencyMap
    0x17: {0, 4, 7},   # detailzoneMap, flushMap, translucencyMap
    0x18: {},          # only 1 vanilla sample — too few to classify
    0x13: {1, 4},      # nrMap, flushMap
    0x12: {1, 2},      # EyeInsideTex, EyeMaskTex
    0x1A: {2, 3, 4},   # translucencyMap, occlusionMap, g_mPixMsk
}


def shader_never_populate_u64(shader_byte):
    """Public helper: return the NEVER_POPULATE u64 ref slot set for a shader.

    Used by material_export to strip placeholder ``@ref`` hashes that the
    orchestrator's template defaults would otherwise pass through to the
    writer for slots vanilla NEVER populates (the Triple H 2018 crash
    pattern — see ``_NEVER_POPULATE_U64`` docstring).

    Returns an empty set for shaders that don't have any never-populate
    constraints (gear, hair, etc.).
    """
    return _NEVER_POPULATE_U64.get(int(shader_byte), set())


# Required (ALWAYS-populated by vanilla) u64 ref slots per shader. Used
# for the empty-params and template-driven smoke tests in
# _test_materials.py — the writer must emit each of these slots in the
# payload vtable even when the caller supplied no real hash, falling
# through to the null sentinel so the engine engages its built-in
# texture-template default.
_REQUIRED_SLOTS = {
    0x01: {4, 5, 6, 7, 8},           # yPBR + empty nested defaults
    0x02: {4, 5, 6, 7, 8, 9, 10, 11, 12},  # illumination baseline
    0x19: {0, 1, 6, 9, 15, 18},      # body
    0x17: {1, 5, 9, 12, 19, 22},     # head
    0x18: {0, 5, 8, 11},             # skinFull (head-family, no glow)
    0x14: {0},                       # eyelash: colorMap only
    0x13: {0, 5, 8, 11, 12},         # caruncle: maps, AO, detail UV, exposure
    0x1A: {0, 1, 6},                 # teeth: colorMap, nrMap, irradiance
    0x12: {0, 3},                    # eye: colorMap, nrMap
    0x15: {4, 9, 11, 12, 14, 15, 17, 19},  # gear
    0x16: {0, 1, 2, 4, 5, 6, 11},    # hair outer
    0x1B: {11, 12, 17, 18},           # fur texture footprint
    0x1C: {3, 6, 8, 9, 11, 12},       # hairMesh
    0x1D: {11, 12, 17, 18},           # shellFur
}


def shader_required_slots(shader_byte):
    """Public helper: return the REQUIRED-emit slot set for a shader."""
    return _REQUIRED_SLOTS.get(int(shader_byte), set())


def _safe_f32(name, value, default):
    """Coerce a float param, replacing NaN/Inf with template default.

    NaN/Inf in a vtable slot won't crash the engine but will produce
    visible artefacts (black skin, broken bloom). Substituting the
    template default at write time is the same fix the editor preset
    compiler does, and the warning surface helps the caller find the
    upstream bug.
    """
    if value is None:
        return None
    try:
        f = float(value)
    except (TypeError, ValueError):
        print(f"[jmtl_writer] WARN: {name}={value!r} not a float, using default {default}")
        return float(default)
    if math.isnan(f) or math.isinf(f):
        print(f"[jmtl_writer] WARN: {name}={f} non-finite, substituting default {default}")
        return float(default)
    return f


# ═══════════════════════════════════════════════════════════════════════════════
# Child sub-table builders
# ═══════════════════════════════════════════════════════════════════════════════
# Each helper returns either (a) an int offset to the freshly-built child
# table, or (b) None if the params dict didn't supply any of the child's
# fields. Callers then PrependUOffsetTRelativeSlot only when the offset is
# not None — preserves "omit the slot" semantics matching what the reader's
# rdColorChild / rdUvChild / rdGlowChild / rdRgbaChild expect.


def _build_color_child(builder, params, r_key, g_key, b_key):
    """Build a 3×u8 RGB color child sub-table.

    Each channel is independent — if `params` has only R+G but not B,
    we emit a 2-slot vtable. Mirrors the reader's per-channel presence
    tracking (see rdColorChild docstring re: hair g_tipColor).
    """
    have = [k in params and params[k] is not None for k in (r_key, g_key, b_key)]
    if not any(have):
        return None
    builder.StartObject(3)
    if have[0]:
        v = max(0.0, min(1.0, _safe_f32(r_key, params[r_key], 0.0)))
        builder.PrependUint8Slot(0, int(round(v * 255.0)) & 0xFF, 0)
    if have[1]:
        v = max(0.0, min(1.0, _safe_f32(g_key, params[g_key], 0.0)))
        builder.PrependUint8Slot(1, int(round(v * 255.0)) & 0xFF, 0)
    if have[2]:
        v = max(0.0, min(1.0, _safe_f32(b_key, params[b_key], 0.0)))
        builder.PrependUint8Slot(2, int(round(v * 255.0)) & 0xFF, 0)
    return builder.EndObject()


def _build_uv_child(builder, params, x_key, y_key):
    """Build a 2×f32 UV child sub-table.

    Empty params → return None (reader's "no data" branch keeps engine
    default rather than emitting [0,0]).
    """
    hx = x_key in params and params[x_key] is not None
    hy = y_key in params and params[y_key] is not None
    if not (hx or hy):
        return None
    builder.StartObject(2)
    if hx:
        builder.PrependFloat32Slot(0, _safe_f32(x_key, params[x_key], 0.0), 0.0)
    if hy:
        builder.PrependFloat32Slot(1, _safe_f32(y_key, params[y_key], 0.0), 0.0)
    return builder.EndObject()


def _build_glow_child(builder, params, key):
    """Build a 4×f32 glow child sub-table from params[key] = [r,g,b,a].

    Reader stores this as a vec4 list; we accept any length 1..4 and
    pad missing channels to "absent" so the reader's per-channel
    population stays exact.
    """
    raw = params.get(key)
    if raw is None:
        return None
    if not isinstance(raw, (list, tuple)):
        raise TypeError(f"glow param {key!r} must be a list/tuple of up to 4 floats, got {type(raw).__name__}")
    builder.StartObject(4)
    for i, v in enumerate(raw[:4]):
        if v is None:
            continue
        builder.PrependFloat32Slot(i, _safe_f32(f"{key}[{i}]", v, 0.0), 0.0)
    return builder.EndObject()


def _build_rgba_child(builder, params, key):
    """Build a 4×u8 RGBA child sub-table from params[key] = [r,g,b,a] in 0..1.

    Same shape as glow but with byte-packed channels — used for gear's
    "glow" slot which uses the rgba reader (a quirk; see jmtl_reader.cpp:841).
    """
    raw = params.get(key)
    if raw is None:
        return None
    if not isinstance(raw, (list, tuple)):
        raise TypeError(f"rgba param {key!r} must be a list/tuple of up to 4 floats 0..1")
    builder.StartObject(4)
    for i, v in enumerate(raw[:4]):
        if v is None:
            continue
        f = max(0.0, min(1.0, _safe_f32(f"{key}[{i}]", v, 0.0)))
        b = max(0, min(255, int(round(f * 255.0))))
        builder.PrependUint8Slot(i, b, 0)
    return builder.EndObject()


# ═══════════════════════════════════════════════════════════════════════════════
# Slot helpers (encapsulate the "omit if absent" pattern)
# ═══════════════════════════════════════════════════════════════════════════════


def _u64_slot(builder, params, idx, key, engine_default=None, never_populate=False):
    """Prepend a u64 texture-hash slot.

    Behaviour:
      * never_populate=True → ALWAYS omit (vanilla-never-populates slots; the
        Triple H 2018 crash — defends against orchestrator-leaked fake hashes).
      * Real hash (non-zero, non-sentinel) → emit it.
      * None/0/sentinel AND engine_default is a real hash → emit it, so the
        runtime has a non-null StMaterial entry (presence > "true" default).
      * None/0/sentinel AND engine_default is the null sentinel → force-emit the
        sentinel ("present but unbound", the invisible-hair fix): the reader
        engages its template default on read-back instead of null-dereffing.
      * None/0/sentinel AND engine_default is None → omit (truly optional ref;
        engine uses its template default).
    """
    if never_populate:
        # Defend against orchestrator leaks: even if the caller passed
        # a non-null hash for a vanilla-never-populates slot, refuse to
        # emit. The engine will null-deref the substituted texture path
        # and crash if we leave this in.
        return
    v = params.get(key)
    if _is_null_hash(v):
        if engine_default is None:
            return
        v = engine_default
    # ForceDefaults on the builder ensures the slot is present in the
    # vtable even when v == 0 or v == sentinel. We mask to u64 to defend
    # against callers passing oversized ints.
    builder.PrependUint64Slot(idx, int(v) & _U64_NULL_SENTINEL, 0)


def _f32_slot(builder, params, idx, key, default):
    """Prepend an f32 slot.

    If the param is missing, the template ``default`` is substituted so
    the slot still emits. Combined with ``builder.ForceDefaults(True)``
    set in ``write_jmtl``, the slot is guaranteed to appear in the
    output vtable. The CRASH-BUG NOTE at the top of this module
    explains why the runtime needs every slot present.
    """
    if key not in params or params[key] is None:
        builder.PrependFloat32Slot(idx, float(default), float(default))
        return
    f = _safe_f32(key, params[key], default)
    builder.PrependFloat32Slot(idx, f, float(default))


def _bool_slot(builder, params, idx, key, default):
    """Prepend a bool slot. Missing params fall back to ``default``.

    With ``ForceDefaults(True)`` on the builder the slot is always
    emitted, even when ``value == default`` (matching vanilla, which
    emits all bool slots even when False/False).
    """
    if key not in params or params[key] is None:
        builder.PrependBoolSlot(idx, bool(default), bool(default))
        return
    builder.PrependBoolSlot(idx, bool(params[key]), bool(default))


def _u8_slot(builder, params, idx, key, default):
    """Prepend a raw u8 slot. Missing params fall back to ``default``.

    Used for the gear variant byte at field 0 and similar control bytes.
    """
    if key not in params or params[key] is None:
        builder.PrependUint8Slot(idx, int(default) & 0xFF, int(default) & 0xFF)
        return
    builder.PrependUint8Slot(idx, int(params[key]) & 0xFF, int(default) & 0xFF)


def _u16_slot(builder, params, idx, key, default):
    """Prepend a u16 slot. Missing params fall back to ``default``."""
    if key not in params or params[key] is None:
        builder.PrependUint16Slot(idx, int(default) & 0xFFFF, int(default) & 0xFFFF)
        return
    builder.PrependUint16Slot(idx, int(params[key]) & 0xFFFF, int(default) & 0xFFFF)


def _u32_slot(builder, params, idx, key, default=0):
    """Prepend a u32 slot. Missing params fall back to ``default``."""
    if key not in params or params[key] is None:
        builder.PrependUint32Slot(idx, int(default) & 0xFFFFFFFF, int(default) & 0xFFFFFFFF)
        return
    builder.PrependUint32Slot(idx, int(params[key]) & 0xFFFFFFFF, int(default) & 0xFFFFFFFF)


def _uoffset_slot(builder, idx, off):
    """Prepend a sub-table offset slot iff a child was actually built.

    Convention: child builders return None when no params populated
    the child; callers must propagate that None all the way to here
    (rather than emitting a 0-byte stub child table). Slots that the
    game runtime requires present (regardless of contents) must use
    ``_uoffset_slot_required`` instead.
    """
    if off is None:
        return
    builder.PrependUOffsetTRelativeSlot(idx, off, 0)


def _uoffset_slot_required(builder, idx, off, empty_child_off):
    """Prepend a sub-table offset slot, never omitted.

    If the child builder returned None (no params populated), use the
    pre-built ``empty_child_off`` — an empty-vtable child table — so the
    slot still has a non-zero offset. Vanilla files emit empty children
    for slots like gear's glow / PbrUvScroll / irradiance and the
    runtime crashes if the slot is missing.
    """
    if off is None:
        off = empty_child_off
    builder.PrependUOffsetTRelativeSlot(idx, off, 0)


def _build_empty_child(builder, n_slots=0):
    """Build a child sub-table with no populated fields.

    Used by the required-slot path to satisfy "slot must be present"
    when the caller has no actual data. n_slots is the field count the
    reader expects — passing the right number keeps the vtable size
    matched to vanilla even when every slot is absent.
    """
    builder.StartObject(n_slots)
    return builder.EndObject()


def _build_color_child_with_default(builder, params, r_key, g_key, b_key, default_rgb):
    """Build a 3×u8 RGB color child, populating from defaults when caller has none.

    Used by head/skin shaders where vanilla files ALWAYS emit the
    g_AOcolor child with engine-default RGB values (114,43,40 across all
    audited samples) even when the user has supplied no override. Falls
    back to ``default_rgb`` = (r, g, b) floats in 0..1 when params lacks
    every channel — guarantees a populated child the runtime can read.

    When the caller supplies any of the channels, behaviour matches
    ``_build_color_child`` (per-channel presence, missing channels
    fall back to the FB-side default not ``default_rgb``).
    """
    have = [k in params and params[k] is not None for k in (r_key, g_key, b_key)]
    if not any(have):
        # Synthesise a params-like dict with the vanilla defaults so the
        # child still gets populated. The reader expects all three
        # channels present in this case (every audited vanilla sample
        # had all three).
        fake = {
            r_key: float(default_rgb[0]),
            g_key: float(default_rgb[1]),
            b_key: float(default_rgb[2]),
        }
        return _build_color_child(builder, fake, r_key, g_key, b_key)
    return _build_color_child(builder, params, r_key, g_key, b_key)


def _build_uv_child_with_default(builder, params, x_key, y_key, default_xy):
    """Build a 2×f32 UV child, populating from defaults when caller has none.

    Same shape as ``_build_color_child_with_default`` but for the
    g_detailMap UV tiling slot. Vanilla head emits (20, 20) and vanilla
    body emits (80, 80) — pass the right tuple via ``default_xy``.
    """
    hx = x_key in params and params[x_key] is not None
    hy = y_key in params and params[y_key] is not None
    if not (hx or hy):
        fake = {x_key: float(default_xy[0]), y_key: float(default_xy[1])}
        return _build_uv_child(builder, fake, x_key, y_key)
    return _build_uv_child(builder, params, x_key, y_key)


# ═══════════════════════════════════════════════════════════════════════════════
# Per-shader writers (CURATED FROM VANILLA + EDITOR, 2026-05/07 rewrite)
# ═══════════════════════════════════════════════════════════════════════════════
#
# Each writer is a thin dispatcher driven by the compact reviewed emission
# policy below, derived offline from the vanilla corpus and MaterialEditor.
# Per slot:
#   never           — 0/N samples populate → skip entirely
#   always_global   — ≥80% carry the SAME value → emit it
#   always_per_char — ≥80% populated, varying → emit caller value or fallback
#                      (null sentinel u64 / FB default scalar)
#   sometimes       — <80% populated → emit ONLY when caller provided
# (Replaces hand-curated tables that drifted — e.g. teeth emitted {0,1,5,6,7,8}
# vs vanilla's {0,1,6}.)
#
# The dispatcher looks up the policy, builds child sub-tables, then
# StartObject(N) / emit-per-slot / EndObject. When the corpus is unavailable it
# falls back to a static policy (keeps non-Blender tests green). Field indices /
# types / defaults still mirror jmtl_reader.cpp 1:1 — only WHICH slots we
# populate is policy-driven, not the wire format.


# ─── Per-shader writer spec (canonical schema) ──────────────────────────────
#
# shader_byte → ordered list of (slot_idx, canonical_key, value_type, fb_default).
#
# value_type:
#   "u64"   — texture hash (null sentinel = engine resolves)
#   "f32"   — IEEE float (fb_default per cpp reader's rdF32)
#   "bool"  — boolean
#   "u8"    — bare u8 (gear variant byte)
#   "u16"   — bare u16 (hair hairType)
#   "color" — 3×u8 RGB child from "<base>R/G/B"
#   "uv"    — 2×f32 child from "<base>U/V"
#   "glow4" — 4×f32 HDR child from a 4-element list at "<base>"
#   "rgba"  — 4×u8 child from a 4-element list at "<base>"
#
# fb_default = the FB default emitted at present-but-default; for child slots
# it's the vanilla-median (R,G,B)/(U,V)/(R,G,B,A) used when always_global and the
# caller supplied nothing. Unlisted slots are absent from schema (StartObject N =
# max(slot_idx)+1).

_WRITER_SPEC: dict[int, list] = {
    # Environment schemas verified against the 2K26 material reader.
    0x02: [
        (0, "is_shadow_caster", "bool", True), (1, "blend_mode", "u8", 0),
        (2, "bool3", "bool", False), (3, "g_receivesSSR", "bool", False),
        (4, "colorMap@ref", "u64", None), (6, "g_nrmMap@ref", "u64", None),
        (10, "sampIllumMap1@ref", "u64", None),
        (13, "usePBR", "bool", True), (14, "g_fExposure", "f32", 3.8),
    ],
    0x03: [
        (0, "is_shadow_caster", "bool", True), (1, "bool3", "bool", False),
        (2, "field_3b", "bool", False), (3, "g_receivesSSR", "bool", False),
        (4, "has_refraction", "bool", True), (5, "useAlbedo", "bool", True),
        (6, "colorMap@ref", "u64", None), (7, "g_nrmMap@ref", "u64", None),
        (13, "g_specIntensity", "f32", 1.0),
    ],
    0x06: [
        (0, "is_shadow_caster", "bool", True), (1, "twoSided", "bool", False),
        (2, "bool3", "bool", True), (3, "colorMap@ref", "u64", None),
        (4, "nrMap@ref", "u64", None),
        (5, "subSurfaceAOMap@ref", "u64", None),
    ],
    0x07: [
        (0, "g_receivesSSR", "bool", True),
        (1, "has_refraction", "bool", True), (4, "useAlbedo", "bool", True),
        (5, "colorMap@ref", "u64", None),
        (6, "SurfaceColor", "color", (0.0, 0.2, 0.25)),
        (7, "DepthFogColor", "color", (0.0, 0.08, 0.12)),
        (8, "colorIntensity", "f32", 1.0),
        (9, "DepthFogAmount", "f32", 0.125),
        (10, "MaxDistortionDepth", "f32", 10.0),
        (11, "g_specIntensity", "f32", 1.0),
        (12, "normalMap@ref", "u64", None),
        (14, "normalMap2@ref", "u64", None),
    ],
    # 0x12 yCh_eye / Normal — 20 fields. jmtl_reader.cpp:799-811.
    0x12: [
        (0,  "colorMap@ref",            "u64",   None),
        (1,  "EyeInsideTex@ref",        "u64",   None),
        (2,  "EyeMaskTex@ref",          "u64",   None),
        (3,  "nrMap@ref",               "u64",   None),
        (4,  "caustic",                 "f32",   0.5),
        (5,  "g_eyeRoughness",          "f32",   1.0),
        (6,  "g_fFresnel",              "f32",   0.65),
        (7,  "g_pupilLns",              "f32",   0.62),
        (8,  "g_pupilPar",              "f32",   0.002),
        (9,  "g_refraction",            "bool",  True),
        (10, "g_specIntensity",         "f32",   4.0),
        (11, "g_eyeWetness",            "f32",   0.3),
        (12, "eyeLidShadowDarkness",    "f32",   0.0),
        (13, "eyeLidShadowFallOff",     "f32",   0.35),
        (14, "eyeShadowConeSharpness",  "f32",   0.008),
        (15, "eyeShadowConeBgLevel",    "f32",   1.0),
        (16, "eyeShadowHorizontalFit",  "f32",   0.12),
        (17, "eyeShadowLidZBias",       "f32",   0.7),
        (18, "eyeShadowVerticalBias",   "f32",   0.22),
        (19, "eyeShadowVerticalFit",    "f32",   0.5),
    ],
    # 0x13 yCh_caruncle — 13 fields. jmtl_reader.cpp:813-822.
    0x13: [
        (0,  "colorMap@ref",         "u64",   None),
        (1,  "nrMap@ref",            "u64",   None),
        (2,  "g_mPixMsk@ref",        "u64",   None),
        (3,  "detailzoneMap@ref",    "u64",   None),
        (4,  "flushMap@ref",         "u64",   None),
        (5,  "subSurfaceAOMap@ref",  "u64",   None),
        (6,  "g_specIntensity",      "f32",   1.0),
        (7,  "roughContrast",        "f32",   0.0),
        (8,  "g_AOcolor",            "color", (0.447059, 0.168627, 0.156863)),
        (9,  "normalIntensity",      "f32",   1.0),
        (10, "roughIntens",          "f32",   1.0),
        (11, "g_detailMap",          "uv",    (14.0, 14.0)),
        (12, "exposure",             "f32",   1.0),
    ],
    # 0x14 yCh_eyeOv / Eyelash — 1 field. jmtl_reader.cpp:824-827.
    0x14: [
        (0, "colorMap@ref", "u64", None),
    ],
    # 0x15 yCh_gear — 22 fields. jmtl_reader.cpp:829-848.
    0x15: [
        (0,  "variant",          "u8",    0),
        # slots 1, 2 unused in cpp reader.
        (3,  "standardLit",      "bool",  True),
        (4,  "clothSheen",       "color", (0.0, 0.0, 0.0)),
        (5,  "clothSheenRough",  "f32",   0.0),
        # slots 6, 7 unused in cpp reader.
        (8,  "standardLighting", "bool",  False),
        (9,  "colorMap@ref",     "u64",   None),
        (10, "exposure",         "f32",   1.0),
        (11, "glow",             "rgba",  (0.0, 0.0, 0.0, 0.0)),
        (12, "nrMap@ref",        "u64",   None),
        (13, "g_mPixMsk@ref",    "u64",   None),
        (14, "PbrUvScroll",      "uv",    ()),
        (15, "irradiance",       "color", (0.0, 0.752941, 0.752941)),
        (16, "irradianceMin",    "f32",   0.0),
        (17, "microDetail",      "bool",  False),
        (18, "shadowObjBias",    "f32",   0.0),
        (19, "g_specIntensity",  "f32",   0.5),
        (20, "teethFresnel",     "f32",   0.04),
        (21, "teethWetness",     "f32",   0.5),
    ],
    # 0x16 yCh_hair OUTER — 12 fields. jmtl_reader.cpp:850-875.
    # Slot 1 is the variant-specific inner table (handled specially).
    0x16: [
        (0,  "hairType",         "u16",   1),
        # slot 1 inner uoffset — emitted unconditionally by the hair writer.
        (2,  "flowMap@ref",      "u64",   None),
        (3,  "g_hairAlbedo",     "f32",   1.0),
        (4,  "g_mPixMsk@ref",    "u64",   None),
        (5,  "g_comboMap@ref",   "u64",   None),
        (6,  "g_rootColor",      "color", (0.5, 0.5, 0.5)),
        (7,  "g_shineBoost",     "f32",   4.0),
        (8,  "g_fSpecFresnel",   "f32",   0.65),
        (9,  "g_fSpecLevel",     "f32",   0.1),
        (10, "g_fSpecRough",     "f32",   0.05),
        (11, "g_tipColor",       "color", (0.5, 0.5, 0.5)),
    ],
    # 0x17 yCh_head / Normal — 23 fields. jmtl_reader.cpp:916-931.
    0x17: [
        (0,  "detailzoneMap@ref",  "u64",   None),
        (1,  "colorMap@ref",       "u64",   None),
        (2,  "facepaint@ref",      "u64",   None),
        (3,  "g_facepaintNrm@ref", "u64",   None),
        (4,  "flushMap@ref",       "u64",   None),
        (5,  "nrMap@ref",          "u64",   None),
        (6,  "g_mPixMsk@ref",      "u64",   None),
        (7,  "translucencyMap@ref","u64",   None),
        (8,  "wrinkleMap@ref",     "u64",   None),
        (9,  "g_AOcolor",          "color", (0.447059, 0.168627, 0.156863)),
        (10, "bruiseEnable",       "bool",  True),
        (11, "UseWrinkles",        "bool",  False),
        (12, "g_detailMap",        "uv",    (20.0, 20.0)),
        (13, "g_detailStr",        "f32",   2.0),
        (14, "g_hzSmooth",         "f32",   0.6),
        (15, "g_liquidLevel",      "f32",   1.0),
        (16, "g_liquidUVRatio",    "f32",   4.0),
        (17, "g_nostrilAO",        "f32",   0.65),
        (18, "oilyParam",          "f32",   1.0),
        (19, "g_poreColor",        "f32",   0.4),
        (20, "g_specIntensity",    "f32",   1.0),
        (21, "exposure",           "f32",   1.0),
        (22, "glow",               "glow4", (0.0, 0.0, 0.0, 0.0)),
    ],
    # 0x18 yCh_head / SkinFull — 28 fields. jmtl_reader.cpp:933-950.
    # Only 1 vanilla sample exists, so the policy classifier returns
    # mostly "sometimes" — we apply a hand-curated fallback policy via
    # _STATIC_POLICY_FALLBACK below for this shader.
    0x18: [
        (0,  "colorMap@ref",       "u64",   None),
        (1,  "detailzoneMap@ref",  "u64",   None),
        (2,  "facepaint@ref",      "u64",   None),
        (3,  "g_facepaintNrm@ref", "u64",   None),
        (4,  "flushMap@ref",       "u64",   None),
        (5,  "nrMap@ref",          "u64",   None),
        (6,  "g_mPixMsk@ref",      "u64",   None),
        (7,  "wrinkleMap@ref",     "u64",   None),
        (8,  "g_AOcolor",          "color", (0.447059, 0.168627, 0.156863)),
        (9,  "bruiseEnable",       "bool",  True),
        (10, "UseWrinkles",        "bool",  False),
        (11, "g_detailMap",        "uv",    (20.0, 20.0)),
        (12, "g_detailStr",        "f32",   0.0),
        (13, "g_hzSmooth",         "f32",   0.0),
        (14, "g_liquidLevel",      "f32",   1.0),
        (15, "g_liquidUVRatio",    "f32",   4.0),
        (16, "g_nostrilAO",        "f32",   0.65),
        (17, "oilyParam",          "f32",   1.0),
        (18, "g_poreColor",        "f32",   0.6),
        (19, "g_specIntensity",    "f32",   1.0),
        (20, "eyeLidShadowDarkness",    "f32", 0.0),
        (21, "eyeLidShadowFallOff",     "f32", 0.35),
        (22, "eyeShadowConeSharpness",  "f32", 0.008),
        (23, "eyeShadowConeBgLevel",    "f32", 1.0),
        (24, "eyeShadowHorizontalFit",  "f32", 0.12),
        (25, "eyeShadowLidZBias",       "f32", 0.7),
        (26, "eyeShadowVerticalBias",   "f32", 0.22),
        (27, "eyeShadowVerticalFit",    "f32", 0.5),
    ],
    # 0x19 yCh_skin / Normal — 19 fields. jmtl_reader.cpp:952-965.
    0x19: [
        (0,  "colorMap@ref",       "u64",   None),
        (1,  "nrMap@ref",          "u64",   None),
        (2,  "muscleMap@ref",      "u64",   None),
        (3,  "detailzoneMap@ref",  "u64",   None),
        (4,  "translucencyMap@ref","u64",   None),
        (5,  "g_mPixMsk@ref",      "u64",   None),
        (6,  "g_AOcolor",          "color", (0.447059, 0.168627, 0.156863)),
        (7,  "bruiseEnable",       "bool",  True),
        (8,  "UseMuscles",         "bool",  False),
        (9,  "g_detailMap",        "uv",    (80.0, 80.0)),
        (10, "g_detailStr",        "f32",   2.0),
        (11, "g_hzSmooth",         "f32",   0.6),
        (12, "g_liquidLevel",      "f32",   1.0),
        (13, "g_liquidUVRatio",    "f32",   4.0),
        (14, "oilyParam",          "f32",   1.0),
        (15, "g_poreColor",        "f32",   0.4),
        (16, "g_specIntensity",    "f32",   1.0),
        (17, "exposure",           "f32",   1.0),
        (18, "glow",               "glow4", (0.0, 0.0, 0.0, 0.0)),
    ],
    # 0x1A yCh_Teeth — 9 fields. jmtl_reader.cpp:967-975.
    0x1A: [
        (0, "colorMap@ref",         "u64",   None),
        (1, "nrMap@ref",            "u64",   None),
        (2, "translucencyMap@ref",  "u64",   None),
        (3, "occlusionMap@ref",     "u64",   None),
        (4, "g_mPixMsk@ref",        "u64",   None),
        (5, "g_teethAOFactor",      "f32",   0.0),
        (6, "irradiance",           "color", (0.0, 0.752941, 0.752941)),
        (7, "g_teethWetness",       "f32",   0.65),
        (8, "g_wetRoughness",       "f32",   0.008),
    ],
    # Fur and shellFur share the verified 26-field payload shape.
    0x1B: [
        (0, "g_fLineJitter", "f32", 1.0),
        (1, "g_fRoughness", "f32", 0.5),
        (2, "g_fRoughLerp", "f32", 0.0),
        (3, "g_fMetallic", "f32", 0.3),
        (4, "g_fMetallicLerp", "f32", 0.0),
        (5, "g_hairIntensity", "f32", 1.0),
        (6, "g_hairR", "f32", 0.1),
        (7, "g_hairShift", "f32", 0.135),
        (8, "g_hairTRT", "f32", 0.5),
        (9, "g_hairTT", "f32", 0.5),
        (10, "g_hairWrap", "f32", 0.0),
        (11, "nrMap@ref", "u64", None),
        (12, "colorMap@ref", "u64", None),
        (13, "g_hairAlbedo", "f32", 1.0),
        (14, "g_hairShadow", "f32", 0.2),
        (15, "g_texPixMsk@ref", "u64", None),
        (16, "g_shineBoost", "f32", 5.0),
        (17, "shellFurMap@ref", "u64", None),
        (18, "shellFurDir@ref", "u64", None),
        (19, "shellFurMaxShells", "f32", 32.0),
        (20, "shellFurMinLength", "f32", 2.0),
        (21, "shellFurMaxLength", "f32", 7.0),
        (22, "shellFurDensity", "f32", 150.0),
        (23, "shellFurRadius", "f32", 0.8),
        (24, "shellFurTaper", "f32", 0.9),
        (25, "shellFurColorFade", "f32", 0.8),
    ],
    0x1C: [
        (0, "g_fLineJitter", "f32", 1.0),
        (1, "g_fLineJitX", "f32", 1.0),
        (2, "g_fLineJitY", "f32", 1.0),
        (3, "g_fRoughness", "f32", 0.5),
        (4, "g_fMetallic", "f32", 0.3),
        (5, "g_hairIntensity", "f32", 1.0),
        (6, "g_hairR", "f32", 0.1),
        (7, "g_hairShift", "f32", 0.135),
        (8, "g_hairTRT", "f32", 0.5),
        (9, "g_hairTT", "f32", 0.5),
        (10, "g_hairWrap", "f32", 0.0),
        (11, "g_nrmMap@ref", "u64", None),
        (12, "colorMap@ref", "u64", None),
        (13, "g_hairAlbedo", "f32", 1.0),
        (14, "g_hairShadow", "f32", 0.2),
        (15, "g_texPixMsk@ref", "u64", None),
        (16, "standardLit", "bool", True),
        (17, "g_shineBoost", "f32", 5.0),
    ],
    0x1D: [],
}

_WRITER_SPEC[0x1D] = list(_WRITER_SPEC[0x1B])

# Field count per shader (used by StartObject). One past the highest slot
# index in the spec — must match the reader's expected vtable size.
_PAYLOAD_FIELD_COUNT = {
    0x02: 15, 0x03: 14, 0x06: 6, 0x07: 15,
    0x12: 20, 0x13: 13, 0x14: 1, 0x15: 22, 0x16: 12,
    0x17: 23, 0x18: 28, 0x19: 19, 0x1A: 9,
    0x1B: 26, 0x1C: 18, 0x1D: 26,
}


# ─── Curated release emission policy ───────────────────────────────────────
#
# This compact policy is derived from the vanilla corpus and cross-checked
# against the MaterialEditor serializer. It is intentionally the runtime
# authority: installing an optional sample corpus must not change the bytes a
# fresh mod generates. Corpus classification remains an offline audit tool.
#
# Values match the policies the empirical classifier derives from the
# shipped 510-char corpus, modulo the sparse 0x18 case where we mirror
# the 0x17 head shape semantically.

_STATIC_POLICY_FALLBACK: dict[int, dict[int, str]] = {
    0x02: {0: "always_global", 13: "always_global", 14: "always_global"},
    0x03: {0: "always_global", 4: "always_global", 5: "always_global",
           13: "always_global"},
    0x06: {0: "always_global", 2: "always_global"},
    0x07: {0: "always_global", 1: "always_global", 4: "always_global",
           6: "always_global", 7: "always_global", 8: "always_global",
           9: "always_global", 10: "always_global", 11: "always_global"},
    0x12: {  # eye
        0: "always_per_char", 1: "never", 2: "never",
        3: "always_global",  # nrMap=0xEFBC052176B84E95
    },
    0x13: {  # caruncle
        0: "always_per_char", 1: "never", 4: "never",
        5: "always_per_char", 8: "always_global", 11: "always_global",
        12: "always_global",
    },
    0x14: {0: "always_per_char"},  # eyelash
    0x15: {  # gear — colorMap per-char, nrMap per-char, children always
        4: "always_global", 9: "always_per_char", 11: "always_global",
        12: "always_per_char", 14: "always_global", 15: "always_global",
        17: "always_global", 19: "always_per_char",
    },
    0x16: {  # hair outer — flowMap/comboMap per-char, hairType global
        0: "always_global", 2: "always_per_char", 4: "always_global",
        5: "always_per_char", 6: "always_global", 11: "always_global",
    },
    0x17: {  # head
        0: "never", 1: "always_per_char", 4: "never", 5: "always_per_char",
        7: "never", 9: "always_global", 12: "always_global",
        19: "always_per_char",
        22: "always_global",  # glow child — always present-but-empty
    },
    0x18: {  # skinFull — mirror 0x17 by semantics
        0: "always_per_char", 1: "never", 2: "never", 3: "never",
        4: "never", 5: "always_per_char",
        8: "always_global", 11: "always_global",
    },
    0x19: {  # body
        0: "always_per_char", 1: "always_per_char",
        2: "never", 3: "never", 4: "never",
        6: "always_global", 9: "always_global", 15: "always_per_char",
        18: "always_global",  # glow child — always present-but-empty
    },
    0x1A: {  # teeth
        0: "always_global",  # colorMap = 0x7357EEB9075DF170
        1: "always_global",  # nrMap = 0xBA65216DD64F5C78
        2: "never", 3: "never", 4: "never",
        5: "never", 6: "always_global",
        7: "never", 8: "never",
    },
    0x1B: {
        11: "always_per_char", 12: "always_per_char",
        17: "always_per_char", 18: "always_per_char", 21: "sometimes",
    },
    0x1C: {
        3: "always_global", 6: "always_global", 7: "sometimes",
        8: "always_global", 9: "always_global",
        11: "always_per_char", 12: "always_per_char",
    },
    0x1D: {
        11: "always_per_char", 12: "always_per_char",
        17: "always_per_char", 18: "always_per_char", 21: "sometimes",
    },
}

# Static global-value fallbacks for the always_global slots above when the
# corpus is absent. Mirrors the empirical classifier's findings.
_STATIC_GLOBAL_VALUES: dict[tuple[int, int], object] = {
    (0x12, 3): 0xEFBC052176B84E95,
    (0x13, 8): (0.447059, 0.168627, 0.156863),
    (0x13, 11): (14.0, 14.0),
    (0x13, 12): 1.0,
    (0x15, 4): (0.0, 0.0, 0.0),
    (0x15, 11): (0.0, 0.0, 0.0, 0.0),
    (0x15, 14): (),  # required present-but-empty child in vanilla gear
    (0x15, 15): (0.0, 0.752941, 0.752941),
    (0x15, 17): False,
    (0x16, 0): 1,
    (0x16, 4): 0xEACC2BCA075CE832,
    (0x16, 6): (0.5, 0.5, 0.5),
    (0x16, 11): (),
    (0x17, 9): (0.447059, 0.168627, 0.156863),
    (0x17, 12): (20.0, 20.0),
    (0x17, 19): 0.4,
    (0x17, 22): (),  # empty glow child (present-but-no-content)
    (0x18, 8): (0.447059, 0.168627, 0.156863),
    (0x18, 11): (20.0, 20.0),
    (0x19, 6): (0.447059, 0.168627, 0.156863),
    (0x19, 9): (80.0, 80.0),
    (0x19, 15): 0.4,
    (0x19, 18): (),  # empty glow child
    (0x1A, 0): 0x7357EEB9075DF170,
    (0x1A, 1): 0xBA65216DD64F5C78,
    (0x1A, 6): (0.0, 0.752941, 0.752941),
    (0x1C, 3): 0.5,
    (0x1C, 6): 0.1,
    (0x1C, 8): 0.5,
    (0x1C, 9): 0.5,
}


def _get_emission_policy_for(shader_byte: int) -> dict[int, dict]:
    """Return the deterministic curated emission policy for a shader.

    ``vanilla_basis.get_emission_policy`` is valuable for offline analysis,
    but its population thresholds vary with the locally installed corpus.
    Runtime serialization must be identical with or without that optional
    data, so new JMTLs always use the reviewed compact release policy below.
    """
    sb = int(shader_byte)
    spec = _WRITER_SPEC.get(sb, [])
    static = _STATIC_POLICY_FALLBACK.get(sb, {})
    out: dict[int, dict] = {}
    for slot_idx, key, kind, _fb in spec:
        rule = static.get(slot_idx, "sometimes")
        global_value = _STATIC_GLOBAL_VALUES.get((sb, slot_idx))
        out[slot_idx] = {
            "rule": rule,
            "global_value": global_value,
            "value_type": kind,
            "sample_count": 0,
            "total_samples": 0,
            "canonical_key": key,
        }
    return out


def _emit_child_color(builder, params, key, default_rgb):
    """Build a 3×u8 color child sub-table.

    For policy-driven emission: when caller has any of R/G/B keys
    populated, use those. When caller has none, fall back to
    ``default_rgb``. If ``default_rgb`` is an empty tuple, emit a
    present-but-empty child (vanilla uses this for slots like body's
    glow, where the runtime needs the slot present but with no content).
    """
    rk, gk, bk = f"{key}R", f"{key}G", f"{key}B"
    have = [k in params and params[k] is not None for k in (rk, gk, bk)]
    if not any(have):
        raw = params.get(key)
        if isinstance(raw, (list, tuple)) and len(raw) >= 3:
            fake = {rk: float(raw[0]), gk: float(raw[1]), bk: float(raw[2])}
            return _build_color_child(builder, fake, rk, gk, bk)
        if default_rgb is None:
            return None
        if isinstance(default_rgb, tuple) and len(default_rgb) == 0:
            # Empty child = present-but-no-content. Matches vanilla.
            return _build_empty_child(builder, 3)
        # Build with default values across all 3 channels.
        fake = {rk: float(default_rgb[0]), gk: float(default_rgb[1]),
                bk: float(default_rgb[2])}
        return _build_color_child(builder, fake, rk, gk, bk)
    return _build_color_child(builder, params, rk, gk, bk)


def _emit_child_uv(builder, params, key, default_xy):
    """Build a 2×f32 UV child sub-table with caller-or-default content."""
    # Legacy presets/editor properties call gear's channels X/Y; the other
    # character UV children use U/V. Keep both wire shapes behind one helper.
    if key == "PbrUvScroll":
        xk, yk = f"{key}X", f"{key}Y"
    else:
        xk, yk = f"{key}U", f"{key}V"
    hx = xk in params and params[xk] is not None
    hy = yk in params and params[yk] is not None
    if key == "PbrUvScroll" and (hx or hy):
        # Vanilla's zero-scroll default is a present-but-empty Uv child. Only
        # materialize fields when the author supplied an actual nonzero scroll.
        vals = [params[k] for k in (xk, yk) if k in params and params[k] is not None]
        try:
            meaningful = any(float(v) != 0.0 for v in vals)
        except (TypeError, ValueError):
            meaningful = bool(vals)
        if not meaningful:
            hx = hy = False
    if not (hx or hy):
        raw = params.get(key)
        if isinstance(raw, (list, tuple)) and len(raw) >= 2:
            if key == "PbrUvScroll":
                try:
                    if float(raw[0]) == 0.0 and float(raw[1]) == 0.0:
                        raw = ()
                except (TypeError, ValueError):
                    pass
            if len(raw) == 0:
                return _build_empty_child(builder, 2)
            fake = {xk: raw[0], yk: raw[1]}
            return _build_uv_child(builder, fake, xk, yk)
        if default_xy is None:
            return None
        if isinstance(default_xy, tuple) and len(default_xy) == 0:
            return _build_empty_child(builder, 2)
        fake = {xk: float(default_xy[0]), yk: float(default_xy[1])}
        return _build_uv_child(builder, fake, xk, yk)
    return _build_uv_child(builder, params, xk, yk)


def _emit_child_glow4(builder, params, key, default_rgba):
    """Build a 4×f32 glow child. Caller's [r,g,b,a] list takes precedence.

    Empty-tuple default = emit present-but-no-content child (vanilla
    body/head ship empty glow children at slot 18/22 across every
    audited sample).
    """
    raw = params.get(key)
    if raw is None:
        if default_rgba is None:
            return None
        if isinstance(default_rgba, tuple) and len(default_rgba) == 0:
            return _build_empty_child(builder, 4)
        raw = list(default_rgba)
    if not isinstance(raw, (list, tuple)):
        return None
    if len(raw) == 0:
        return _build_empty_child(builder, 4)
    builder.StartObject(4)
    for i, v in enumerate(raw[:4]):
        if v is None:
            continue
        builder.PrependFloat32Slot(i, _safe_f32(f"{key}[{i}]", v, 0.0), 0.0)
    return builder.EndObject()


def _emit_child_rgba(builder, params, key, default_rgba):
    """Build a 4×u8 rgba child. Caller's [r,g,b,a] list takes precedence."""
    raw = params.get(key)
    if raw is None:
        if default_rgba is None:
            return None
        if isinstance(default_rgba, tuple) and len(default_rgba) == 0:
            return _build_empty_child(builder, 4)
        raw = list(default_rgba)
    if not isinstance(raw, (list, tuple)):
        return None
    if len(raw) == 0:
        return _build_empty_child(builder, 4)
    builder.StartObject(4)
    for i, v in enumerate(raw[:4]):
        if v is None:
            continue
        f = max(0.0, min(1.0, _safe_f32(f"{key}[{i}]", v, 0.0)))
        b = max(0, min(255, int(round(f * 255.0))))
        builder.PrependUint8Slot(i, b, 0)
    return builder.EndObject()


def _policy_caller_has_value(params, key, kind):
    """Return True if params contains a non-null value for this slot's key.

    Handles child slots by checking the per-channel keys. For u64 slots,
    null sentinel and 0 count as "no value" (matching _is_null_hash).
    """
    if kind == "u64":
        v = params.get(key)
        return not _is_null_hash(v)
    if kind == "color":
        raw = params.get(key)
        return (isinstance(raw, (list, tuple)) and len(raw) >= 3) or any(
            params.get(f"{key}{ch}") is not None for ch in ("R", "G", "B")
        )
    if kind == "uv":
        raw = params.get(key)
        suffixes = ("X", "Y") if key == "PbrUvScroll" else ("U", "V")
        values = []
        if isinstance(raw, (list, tuple)) and len(raw) >= 2:
            values.extend(raw[:2])
        values.extend(
            params.get(f"{key}{ch}") for ch in suffixes
            if params.get(f"{key}{ch}") is not None
        )
        if key == "PbrUvScroll":
            try:
                return any(float(v) != 0.0 for v in values)
            except (TypeError, ValueError):
                return bool(values)
        return bool(values)
    if kind in ("glow4", "rgba"):
        return params.get(key) is not None
    v = params.get(key)
    return v is not None


def _write_payload_via_policy(
    builder, shader_byte, params,
    *, extra_inner_off=None, extra_inner_slot=None,
):
    """Generic policy-driven payload writer.

    Walks the spec for ``shader_byte``, applies the emission policy from
    ``_get_emission_policy_for``, builds child sub-tables in advance,
    then opens the payload table and emits each slot per its rule.

    ``extra_inner_off`` / ``extra_inner_slot`` is the escape hatch for
    hair's variant-specific inner table: hair_writer pre-builds the inner
    and passes (offset, slot_idx) here. The dispatcher then emits that
    slot unconditionally.
    """
    sb = int(shader_byte)
    spec = _WRITER_SPEC.get(sb, [])
    policy = _get_emission_policy_for(sb)
    n_fields = _PAYLOAD_FIELD_COUNT.get(sb, 0)
    if not spec or n_fields == 0:
        builder.StartObject(0)
        return builder.EndObject()

    # ── Build child sub-tables FIRST (FB requires children completed
    #    before parent StartObject). Stash the offsets keyed by slot_idx
    #    so the emit loop can prepend them.
    child_offsets: dict[int, int] = {}
    for slot_idx, key, kind, fb_default in spec:
        p = policy.get(slot_idx)
        if p is None:
            continue
        rule = p["rule"]
        if rule == "never":
            continue
        if kind not in ("color", "uv", "glow4", "rgba"):
            continue
        caller_has = _policy_caller_has_value(params, key, kind)
        if rule == "sometimes" and not caller_has:
            # Skip emitting the child entirely when caller hasn't provided.
            continue
        # always_global or always_per_char or (sometimes + caller_has)
        # → build the child.
        if rule == "always_global" and not caller_has:
            # Use the global value as the child's content.
            gv = p.get("global_value")
            if gv is None:
                gv = fb_default
            default = gv
        else:
            default = fb_default
        if kind == "color":
            off = _emit_child_color(builder, params, key, default)
        elif kind == "uv":
            off = _emit_child_uv(builder, params, key, default)
        elif kind == "glow4":
            off = _emit_child_glow4(builder, params, key, default)
        elif kind == "rgba":
            off = _emit_child_rgba(builder, params, key, default)
        else:
            off = None
        if off is not None:
            child_offsets[slot_idx] = off

    # ── Open payload table and emit each slot ──────────────────────────
    builder.StartObject(n_fields)

    # Inner table escape hatch (hair only — slot 1).
    if extra_inner_off is not None and extra_inner_slot is not None:
        builder.PrependUOffsetTRelativeSlot(extra_inner_slot, extra_inner_off, 0)

    for slot_idx, key, kind, fb_default in spec:
        p = policy.get(slot_idx)
        if p is None:
            continue
        rule = p["rule"]
        if rule == "never":
            continue

        caller_has = _policy_caller_has_value(params, key, kind)

        if rule == "sometimes":
            if not caller_has:
                # Skip — vanilla < 80% of samples populate, caller didn't ask.
                continue
            # Caller supplied — emit using their value.
            _emit_slot(builder, params, slot_idx, key, kind, fb_default,
                       child_offsets, global_value=None)
            continue

        if rule == "always_global":
            gv = p.get("global_value")
            if caller_has:
                # Caller-supplied wins over global (rare; usually upstream
                # already injected the global hash to params before calling).
                _emit_slot(builder, params, slot_idx, key, kind, fb_default,
                           child_offsets, global_value=None)
            else:
                _emit_slot(builder, params, slot_idx, key, kind, fb_default,
                           child_offsets, global_value=gv)
            continue

        # always_per_char
        if caller_has:
            _emit_slot(builder, params, slot_idx, key, kind, fb_default,
                       child_offsets, global_value=None)
        else:
            # No caller value, no global — emit a fallback so the slot is
            # PRESENT (the runtime requires presence for required slots).
            _emit_slot(builder, params, slot_idx, key, kind, fb_default,
                       child_offsets, global_value=None,
                       force_fallback=True)

    return builder.EndObject()


def _emit_slot(builder, params, slot_idx, key, kind, fb_default,
               child_offsets, *, global_value=None, force_fallback=False):
    """Emit a single slot per its kind.

    ``global_value`` (when set) overrides params for this slot — used by
    always_global rule. ``force_fallback`` (when True) means "params has
    no real value but we need the slot present anyway" — for u64 slots
    we emit the null sentinel, for scalars the fb_default, for children
    we emit the pre-built child (which was already built with caller-or-
    default content above).
    """
    if kind == "u64":
        if global_value is not None:
            builder.PrependUint64Slot(slot_idx, int(global_value) & _U64_NULL_SENTINEL, 0)
            return
        v = params.get(key)
        if _is_null_hash(v):
            if force_fallback:
                # Slot must be present — emit null sentinel so the runtime
                # engages its template default. Cannot pass 0 as the FB
                # default because then ForceDefaults can't tell them apart.
                builder.PrependUint64Slot(slot_idx, _U64_NULL_SENTINEL, 0)
            return
        builder.PrependUint64Slot(slot_idx, int(v) & _U64_NULL_SENTINEL, 0)
        return
    if kind == "f32":
        v = params.get(key)
        if v is None:
            f = float(fb_default if fb_default is not None else 0.0)
        else:
            f = _safe_f32(key, v, fb_default if fb_default is not None else 0.0)
        # Pass a default of 0.0 (different from f unless f is 0.0) so ForceDefaults
        # ensures the slot is emitted; if f IS the FB default, the builder's
        # ForceDefaults global still emits it.
        builder.PrependFloat32Slot(slot_idx, f, 0.0 if f != 0.0 else 1.0)
        return
    if kind == "bool":
        v = params.get(key)
        if v is None:
            b = bool(fb_default) if fb_default is not None else False
        else:
            b = bool(v)
        # Use opposite-of-value as the "default" so ForceDefaults guarantees emit.
        builder.PrependBoolSlot(slot_idx, b, not b)
        return
    if kind == "u8":
        v = params.get(key)
        if v is None:
            x = int(fb_default) if fb_default is not None else 0
        else:
            x = int(v) & 0xFF
        builder.PrependUint8Slot(slot_idx, x & 0xFF, (x + 1) & 0xFF)
        return
    if kind == "u16":
        v = params.get(key)
        if v is None:
            x = int(fb_default) if fb_default is not None else 0
        else:
            x = int(v) & 0xFFFF
        builder.PrependUint16Slot(slot_idx, x & 0xFFFF, (x + 1) & 0xFFFF)
        return
    if kind in ("color", "uv", "glow4", "rgba"):
        off = child_offsets.get(slot_idx)
        if off is not None:
            builder.PrependUOffsetTRelativeSlot(slot_idx, off, 0)
        return
    # Unknown kind — silently skip.


# Per-shader writers below are now thin dispatchers around
# _write_payload_via_policy. They exist for backwards compatibility
# (the dispatch table _SHADER_WRITERS references them by function) and
# to handle shader-specific quirks (hair's variant-specific inner table).


def _write_yCh_skin(builder, params):
    """0x19 yCh_skin / Normal — body slot. Policy-driven dispatcher."""
    params = _resolve_aliased(params, "nrMap@ref", _NRMAP_LEGACY_ALIAS)
    return _write_payload_via_policy(builder, 0x19, params)


def _write_yCh_head_normal(builder, params):
    """0x17 yCh_head / Normal — head slot. Policy-driven dispatcher."""
    params = _resolve_aliased(params, "nrMap@ref", _NRMAP_LEGACY_ALIAS)
    return _write_payload_via_policy(builder, 0x17, params)


def _write_yCh_gear(builder, params):
    """0x15 yCh_gear / Normal — clothing slot. Policy-driven dispatcher.

    Variant byte at slot 0 (0=opaque, 1/2=alpha) selects the runtime
    shader-name suffix (_ALPHA / _ALPHATEST). The orchestrator sets it
    in params; we just emit it like any other u8.
    """
    params = _resolve_aliased(params, "nrMap@ref", _NRMAP_LEGACY_ALIAS)
    return _write_payload_via_policy(builder, 0x15, params)


def _write_yCh_eye(builder, params):
    """0x12 yCh_eye / Normal — eye_l/eye_r slots. Policy-driven dispatcher."""
    params = _resolve_aliased(params, "nrMap@ref", _NRMAP_LEGACY_ALIAS)
    return _write_payload_via_policy(builder, 0x12, params)


def _write_yCh_caruncle(builder, params):
    """0x13 yCh_caruncle — eye_caruncle slot. Policy-driven dispatcher."""
    params = _resolve_aliased(params, "nrMap@ref", _NRMAP_LEGACY_ALIAS)
    return _write_payload_via_policy(builder, 0x13, params)


def _write_yCh_eyelash(builder, params):
    """0x14 yCh_eyeOv / Eyelash — eyelash slot. Policy-driven dispatcher."""
    params = _resolve_aliased(
        params, "colorMap@ref", _LEGACY_FIELD_ALIASES["colorMap@ref"]
    )
    return _write_payload_via_policy(builder, 0x14, params)


def _write_yCh_teeth(builder, params):
    """0x1A yCh_Teeth — teeth/mouthbag slot. Policy-driven dispatcher.

    The teeth shader is the canonical compact-policy case. Vanilla
    teeth.jmtl populates exactly {0, 1, 6}: colorMap and nrMap are global
    (every wrestler shares the same hash, 0x7357EEB9075DF170 /
    0xBA65216DD64F5C78), and irradiance is per-character. The policy
    classifies them as such, so empty-params produces exactly those
    three slots — matching vanilla byte-for-byte structure.
    """
    params = _resolve_aliased(params, "nrMap@ref", _NRMAP_LEGACY_ALIAS)
    return _write_payload_via_policy(builder, 0x1A, params)


def _write_yCh_skinFull(builder, params):
    """0x18 yCh_head / SkinFull — alternate body shader. Policy-driven dispatcher.

    Only 1 vanilla sample exists, so the policy classifier returns
    "sometimes" for everything; the static fallback maps the slots to
    the head-shader semantic equivalents (always_per_char for color/nr,
    always_global for AOcolor child + detailMap UV, never for the
    facepaint family).
    """
    params = _resolve_aliased(params, "nrMap@ref", _NRMAP_LEGACY_ALIAS)
    return _write_payload_via_policy(builder, 0x18, params)


def _write_yCh_hair_inner_new(builder, params):
    """0x16 inner table for hairType=1 (NewHair_ColorChanging). 24 fields.
    jmtl_reader.cpp:877-892 (readHairNew).

    Vanilla does not populate every scalar merely because the schema declares
    it.  Emitting all 23 fields produced a 328-byte generic block, while the
    shipped color-changing hair fixtures use a sparse 272-byte profile.  The
    defaults below are the safe, commonly populated authoring baseline;
    optional fields are emitted only when the caller explicitly supplies one.
    """
    baseline = {
        2: ("g_hairVariation", 0.45),
        9: ("primeIntensity", 0.5),
        10: ("rimIntensity", 0.5),
        11: ("secondIntensity", 0.85),
        12: ("primeShift", 0.3),
        13: ("primeWidth", 0.35),
        14: ("secondShift", 0.35),
        15: ("secondWidth", 0.35),
        16: ("rimShift", 0.3),
        17: ("rimWidth", 0.35),
        19: ("primeSat", 1.0),
        20: ("secondBright", 1.0),
        21: ("secondSat", 0.8),
        22: ("rimBright", 1.0),
    }

    if (params.get("g_noiseUScale") is not None or
            params.get("g_noiseVScale") is not None):
        noise_uv = _build_uv_child(
            builder, params, "g_noiseUScale", "g_noiseVScale"
        )
    else:
        noise_uv = _build_uv_child(
            builder,
            {"g_noiseUScale": 24.0, "g_noiseVScale": 24.0},
            "g_noiseUScale", "g_noiseVScale",
        )

    builder.StartObject(24)
    # HairColorChangingParams1 field 0 is the optional HairLengthVariant
    # discriminator (0=default, 1=Afro, 2=Short).  Vanilla default hair
    # normally omits it, so only serialize the slot when the caller supplied
    # ``hairLength``; ForceDefaults then keeps an explicit value 0 present.
    if "hairLength" in params and params["hairLength"] is not None:
        _u8_slot(builder, params, 0, "hairLength", 0)
    if "g_autoVariation" in params:
        _bool_slot(builder, params, 1, "g_autoVariation", False)
    if "g_specKnockout" in params:
        _f32_slot(builder, params, 3, "g_specKnockout", 1.0)
    if "g_roughMult" in params:
        _f32_slot(builder, params, 4, "g_roughMult", 1.0)
    if "g_hairNoise" in params:
        _f32_slot(builder, params, 5, "g_hairNoise", 1.0)
    _uoffset_slot(builder, 6, noise_uv)
    if "g_flowJitter" in params:
        _f32_slot(builder, params, 7, "g_flowJitter", 0.3)
    if "g_dyeHack" in params:
        _f32_slot(builder, params, 8, "g_dyeHack", 0.0)
    for slot_idx, (key, default) in baseline.items():
        _f32_slot(builder, params, slot_idx, key, default)
    if "primeBright" in params:
        _f32_slot(builder, params, 18, "primeBright", 1.0)
    if "rimSat" in params:
        _f32_slot(builder, params, 23, "rimSat", 1.0)
    return builder.EndObject()


def _write_yCh_hair_inner_std(builder, params):
    """0x16 inner table for hairType=2 (HairColorChangingParams2).

    This is a different 13-field FlatBuffer table from the 24-field NewHair
    variant.  In particular, its noise UV child is field 5 and field 6 is an
    f32.  Reusing the type-1 writer put a uoffset in field 6, so the engine read
    pointer bytes as a float and interpreted the type-1 tail as unrelated
    type-2 parameters.

    Defaults mirror MaterialEditor's authoritative ``ReadHairStd`` table.
    These are engine fallbacks, not values borrowed from the type-1 preset.
    """
    if (params.get("g_noiseUScale") is not None or
            params.get("g_noiseVScale") is not None):
        noise_uv = _build_uv_child(
            builder, params, "g_noiseUScale", "g_noiseVScale"
        )
    else:
        noise_uv = _build_uv_child(
            builder,
            {"g_noiseUScale": 24.0, "g_noiseVScale": 24.0},
            "g_noiseUScale", "g_noiseVScale",
        )

    builder.StartObject(13)
    # HairColorChangingParams2 shares the optional length discriminator.
    if "hairLength" in params and params["hairLength"] is not None:
        _u8_slot(builder, params, 0, "hairLength", 0)
    _f32_slot(builder, params, 1, "g_variation", 0.5)
    _f32_slot(builder, params, 2, "g_specKnockout", 1.0)
    _f32_slot(builder, params, 3, "g_roughMult", 1.0)
    _f32_slot(builder, params, 4, "g_hairNoise", 1.0)
    _uoffset_slot(builder, 5, noise_uv)
    _f32_slot(builder, params, 6, "g_flowJitter", 0.3)
    _f32_slot(builder, params, 7, "g_hairIntensity", 1.0)
    _f32_slot(builder, params, 8, "g_hairR", 0.1)
    _f32_slot(builder, params, 9, "g_hairShift", 0.135)
    _f32_slot(builder, params, 10, "g_hairTRT", 0.5)
    _f32_slot(builder, params, 11, "g_hairTT", 0.5)
    _f32_slot(builder, params, 12, "g_hairWrap", 0.0)
    return builder.EndObject()


def _write_yCh_hair_inner_npc(builder, params):
    """0x16 inner table for hairType=3 (HairColorChangingParams3/NPC).

    The final two fields are u64 texture hashes, not NewHair lobe floats.
    Keeping both fields present with the explicit null sentinel when unbound
    gives the runtime a valid texture entry instead of an absent pointer.
    """
    params = _resolve_aliased(params, "nrMap@ref", _NRMAP_LEGACY_ALIAS)
    builder.StartObject(16)
    _f32_slot(builder, params, 0, "g_fHairMeshPrm0", 1.0)
    _f32_slot(builder, params, 1, "g_fHairMeshPrm1", 1.0)
    _f32_slot(builder, params, 2, "g_fHairMeshPrm2", 1.0)
    _f32_slot(builder, params, 3, "g_fLineJitter", 1.0)
    _f32_slot(builder, params, 4, "g_fLineJitX", 1.0)
    _f32_slot(builder, params, 5, "g_fLineJitY", 1.0)
    _f32_slot(builder, params, 6, "g_fRoughness", 0.5)
    _f32_slot(builder, params, 7, "g_fMetallic", 0.3)
    _f32_slot(builder, params, 8, "g_hairIntensity", 1.0)
    _f32_slot(builder, params, 9, "g_hairR", 0.1)
    _f32_slot(builder, params, 10, "g_hairShift", 0.135)
    _f32_slot(builder, params, 11, "g_hairTRT", 0.5)
    _f32_slot(builder, params, 12, "g_hairTT", 0.5)
    _f32_slot(builder, params, 13, "g_hairWrap", 0.0)
    _u64_slot(
        builder, params, 14, "nrMap@ref", _U64_NULL_SENTINEL
    )
    _u64_slot(
        builder, params, 15, "colorMap@ref", _U64_NULL_SENTINEL
    )
    return builder.EndObject()


def _write_yCh_hair(builder, params):
    """0x16 yCh_hair — hair slot. Policy-driven dispatcher with inner table.

    Hair has a two-tier layout: the outer 12-field table at slot 1 is
    a uoffset to a variant-specific inner table. We build the inner
    first (per the FB child-before-parent rule), then pass its offset
    to the policy dispatcher which emits it as an extra slot.

    The reviewed policy always emits outer slots 0 (hairType), 2
    (flowMap@ref), 4 (g_mPixMsk), 5 (g_comboMap@ref), 6 (g_rootColor),
    and 11 (g_tipColor). This is the compact vanilla-equivalent baseline;
    optional outer scalars remain caller-authored.
    """
    try:
        hair_type = int(params.get("hairType", 1))
    except (TypeError, ValueError):
        hair_type = 1
    if hair_type not in (1, 2, 3):
        print(
            f"[jmtl_writer] WARN: unsupported hairType={hair_type}; "
            "using NewHair type 1"
        )
        hair_type = 1
    # Keep the outer discriminator consistent with the inner table selected
    # below, including for malformed string/custom-property inputs.
    if params.get("hairType") != hair_type:
        params = dict(params)
        params["hairType"] = hair_type
    inner_params = params.get("_inner", params)
    if hair_type == 1:
        inner_off = _write_yCh_hair_inner_new(builder, inner_params)
    elif hair_type == 2:
        inner_off = _write_yCh_hair_inner_std(builder, inner_params)
    else:
        inner_off = _write_yCh_hair_inner_npc(builder, inner_params)
    return _write_payload_via_policy(
        builder, 0x16, params,
        extra_inner_off=inner_off, extra_inner_slot=1,
    )


def _write_yPBR(builder, params):
    """0x01 yPBR / t_BRDF — env standard model fallback. 6 fields read.
    jmtl_reader.cpp:490-501. Vtable goes up to slot 10.
    """
    uv_params = _build_empty_child(builder, 4)
    diffuse_color = _build_empty_child(builder, 4)
    normal_params = _build_empty_child(builder, 1)
    builder.StartObject(13)
    if "is_shadow_caster" in params:
        _bool_slot(builder, params, 0, "is_shadow_caster", True)
    if "translucency_mode" in params:
        _u8_slot(builder, params, 1, "translucency_mode", 0)
    if "bool3" in params:
        _bool_slot(builder, params, 2, "bool3", False)
    if "g_receivesSSR" in params:
        _bool_slot(builder, params, 3, "g_receivesSSR", False)
    _u64_slot(builder, params, 4, "colorMap@ref", _U64_NULL_SENTINEL)
    _u64_slot(builder, params, 5, "g_nrmMap@ref", _U64_NULL_SENTINEL)
    _uoffset_slot(builder, 6, uv_params)
    _uoffset_slot(builder, 7, diffuse_color)
    _uoffset_slot(builder, 8, normal_params)
    if "g_specIntensity" in params:
        _f32_slot(builder, params, 10, "g_specIntensity", 1.0)
    return builder.EndObject()


def _write_yIllumination(builder, params):
    diffuse_color = _build_empty_child(builder, 4)
    pbr_uv = _build_empty_child(builder, 4)
    normal_params = _build_empty_child(builder, 1)
    rough_params = _build_empty_child(builder, 3)
    emissive_uv = _build_empty_child(builder, 4)
    illum_color = _build_empty_child(builder, 4)
    builder.StartObject(15)
    if "is_shadow_caster" in params:
        _bool_slot(builder, params, 0, "is_shadow_caster", True)
    if "blend_mode" in params:
        _u8_slot(builder, params, 1, "blend_mode", 0)
    if "bool3" in params:
        _bool_slot(builder, params, 2, "bool3", False)
    if "g_receivesSSR" in params:
        _bool_slot(builder, params, 3, "g_receivesSSR", False)
    _u64_slot(builder, params, 4, "colorMap@ref", _U64_NULL_SENTINEL)
    _uoffset_slot(builder, 5, diffuse_color)
    _u64_slot(builder, params, 6, "g_nrmMap@ref", _U64_NULL_SENTINEL)
    _uoffset_slot(builder, 7, pbr_uv)
    _uoffset_slot(builder, 8, normal_params)
    _uoffset_slot(builder, 9, rough_params)
    _u64_slot(builder, params, 10, "sampIllumMap1@ref", _U64_NULL_SENTINEL)
    _uoffset_slot(builder, 11, emissive_uv)
    _uoffset_slot(builder, 12, illum_color)
    if "usePBR" in params:
        _bool_slot(builder, params, 13, "usePBR", True)
    if "g_fExposure" in params:
        _f32_slot(builder, params, 14, "g_fExposure", 3.8)
    return builder.EndObject()


def _write_yGlass(builder, params):
    return _write_payload_via_policy(builder, 0x03, params)


def _write_speedTree(builder, params):
    params = _resolve_aliased(params, "nrMap@ref", _NRMAP_LEGACY_ALIAS)
    return _write_payload_via_policy(builder, 0x06, params)


def _write_water(builder, params):
    return _write_payload_via_policy(builder, 0x07, params)


def _write_yCh_fur(builder, params):
    params = _resolve_aliased(params, "nrMap@ref", _NRMAP_LEGACY_ALIAS)
    return _write_payload_via_policy(builder, 0x1B, params)


def _write_yCh_hairMesh(builder, params):
    if params.get("g_nrmMap@ref") is None and params.get("nrMap@ref") is not None:
        params = dict(params)
        params["g_nrmMap@ref"] = params["nrMap@ref"]
    return _write_payload_via_policy(builder, 0x1C, params)


def _write_yCh_shellFur(builder, params):
    params = _resolve_aliased(params, "nrMap@ref", _NRMAP_LEGACY_ALIAS)
    return _write_payload_via_policy(builder, 0x1D, params)


# ═══════════════════════════════════════════════════════════════════════════════
# Dispatch & public entry
# ═══════════════════════════════════════════════════════════════════════════════

_SHADER_WRITERS = {
    0x01: _write_yPBR,
    0x02: _write_yIllumination,
    0x03: _write_yGlass,
    0x06: _write_speedTree,
    0x07: _write_water,
    0x12: _write_yCh_eye,
    0x13: _write_yCh_caruncle,
    0x14: _write_yCh_eyelash,
    0x15: _write_yCh_gear,
    0x16: _write_yCh_hair,
    0x17: _write_yCh_head_normal,
    0x18: _write_yCh_skinFull,
    0x19: _write_yCh_skin,
    0x1A: _write_yCh_teeth,
    0x1B: _write_yCh_fur,
    0x1C: _write_yCh_hairMesh,
    0x1D: _write_yCh_shellFur,
}


def supported_shaders():
    """Return the list of shader_byte values this writer can emit.

    Useful for the export UI to grey-out unsupported choices rather
    than letting the user select one and hit ValueError at save time.
    """
    return sorted(_SHADER_WRITERS.keys())


def write_jmtl(shader_byte: int, params: dict) -> bytes:
    """Write a .jmtl FlatBuffer for the given shader and parameters.

    Args:
        shader_byte: One of the values in supported_shaders() — most
            commonly 0x19 (skin/body), 0x17 (head), 0x15 (gear), 0x12
            (eye_l/eye_r), 0x1A (teeth/mouthbag).
        params: dict keyed by parameter name from jmtl_reader.cpp's
            per-shader readers (e.g. "colorMap@ref", "g_AOcolorR",
            "g_detailMapU"). Texture refs are u64 FNV1a-64 hashes.
            Missing keys → omitted slot → engine uses template default.

    Returns:
        Bytes of the .jmtl file, ready to write to disk.

    Raises:
        ValueError: if shader_byte is not in supported_shaders().
        RuntimeError: if flatbuffers package is not importable.
    """
    if flatbuffers is None:
        raise RuntimeError(
            "flatbuffers package not available — vendor at Blender/_vendor/flatbuffers/ "
            "or `pip install flatbuffers` system-wide. Status: " + _FB_SOURCE
        )

    if shader_byte not in _SHADER_WRITERS:
        raise ValueError(f"Unsupported shader 0x{shader_byte:02X}")

    if params is None:
        params = {}

    # Initial capacity — most JMTLs are <500 bytes. The builder grows
    # transparently if we underestimate; this is just a perf hint.
    builder = flatbuffers.Builder(512)

    # ForceDefaults: emit every Prepend*Slot call into the final vtable
    # even when value == FB-side default. The game runtime's JMTL reader
    # is stricter than the tools-side reader and crashes on absent slots
    # it expected to be present. See CRASH-BUG NOTE at module top.
    # Vendored flatbuffers 24.3.25 supports this API (added upstream ~2020).
    if hasattr(builder, "ForceDefaults"):
        builder.ForceDefaults(True)

    # Build the per-shader payload first; FB writes back-to-front so the
    # child (payload) is laid out before the parent (root) references it.
    payload_off = _SHADER_WRITERS[shader_byte](builder, params)

    # Root table: slot 1 = u16 shader_type, slot 2 = uoffset payload.
    #
    # Order is intentional. FlatBuffers builds back-to-front, and the game's
    # JMTL accessor expects the canonical editor/vanilla body layout:
    # shader at object +6 and payload uoffset at object +8. Adding the uoffset
    # first and the u16 second produces vtable offsets [0, 6, 8]. The former
    # u8-then-uoffset order was schema-readable but produced [0, 11, 4] (or
    # [0, 9, 4]); the generic reader accepted it while the game crashed.
    builder.StartObject(3)
    builder.PrependUOffsetTRelativeSlot(2, payload_off, 0)
    builder.PrependUint16Slot(1, int(shader_byte) & 0xFFFF, 0)
    root_off = builder.EndObject()

    # Finish with the "Mate" file identifier — emits the 4 bytes at
    # offset 4 of the final buffer, exactly where CJmtlReader::isJmtlData
    # checks for them.
    builder.Finish(root_off, b"Mate")
    return bytes(builder.Output())


# ═══════════════════════════════════════════════════════════════════════════════
# Self-test
# ═══════════════════════════════════════════════════════════════════════════════
# Run as `python jmtl_writer.py` (or import _self_test() from a test
# harness). Exercises the most-used shaders against the same parsing
# code path the reader uses, so a write-then-read round-trip recovers
# every input parameter that was written.


def _self_test():  # pragma: no cover - manual / smoke test only
    import struct as _struct

    # FNV1a-64 lowercase to derive sample texture hashes — same as
    # jmtl_resolver._fnv1a_64_lower (we don't import to keep this
    # module self-contained for testing outside the Blender addon tree).
    def _fnv(s):
        h = 0xCBF29CE484222325
        for ch in s.lower():
            h ^= ord(ch) & 0xFF
            h = (h * 0x100000001B3) & 0xFFFFFFFFFFFFFFFF
        return h

    color_hash = _fnv("Characters/100_The_Rock_2017/BaseModel/Textures/body_color.tex")
    nrm_hash = _fnv("Characters/100_The_Rock_2017/BaseModel/Textures/body_nrm.tex")

    # Build a body.jmtl-shaped material with sample params.
    skin_params = {
        "colorMap@ref": color_hash,
        "nrMap@ref": nrm_hash,
        "g_AOcolorR": 0.4, "g_AOcolorG": 0.2, "g_AOcolorB": 0.1,
        "g_detailMapU": 80.0, "g_detailMapV": 80.0,
        "g_detailStr": 2.0,
    }
    skin_bytes = write_jmtl(0x19, skin_params)
    print(f"[self-test] yCh_skin: {len(skin_bytes)} bytes (flatbuffers={_FB_SOURCE})")

    # Structural verification — reuse the resolver's _read_vtable.
    assert skin_bytes[4:8] == b"Mate", "missing 'Mate' identifier"
    root_pos = _struct.unpack_from("<I", skin_bytes, 0)[0]
    soff = _struct.unpack_from("<i", skin_bytes, root_pos)[0]
    vp = root_pos - soff
    assert vp >= 0 and vp + 4 <= len(skin_bytes), "root vtable out of range"
    vt_size = _struct.unpack_from("<H", skin_bytes, vp)[0]
    assert 4 <= vt_size <= 500, f"root vt_size={vt_size} suspicious"

    # Read shader byte at slot 1.
    n = (vt_size - 4) // 2
    offs = list(_struct.unpack_from(f"<{n}H", skin_bytes, vp + 4))
    assert len(offs) >= 2 and offs[1] != 0, "root slot 1 (shader) missing"
    sb = skin_bytes[root_pos + offs[1]]
    assert sb == 0x19, f"read-back shader byte 0x{sb:02X} != 0x19"

    # Round-trip via the actual resolver (writes the same code path as import).
    try:
        from ..Blender.Extras import jmtl_resolver  # type: ignore
    except Exception:
        import sys, os
        here = os.path.dirname(os.path.abspath(__file__))
        sys.path.insert(0, os.path.join(here, "..", "Blender", "Extras"))
        import jmtl_resolver  # type: ignore

    readback = jmtl_resolver.extract_color_hash(skin_bytes)
    assert readback == color_hash, f"resolver round-trip failed: got {readback}, want {color_hash}"
    print(f"[self-test] yCh_skin colorMap round-trip OK: 0x{readback:016X}")

    # Spot-check other shaders with minimum-viable params.
    eye_params = {"colorMap@ref": _fnv("Characters/X/Textures/eye_color.tex")}
    eye_bytes = write_jmtl(0x12, eye_params)
    print(f"[self-test] yCh_eye: {len(eye_bytes)} bytes")
    assert jmtl_resolver.extract_color_hash(eye_bytes) == eye_params["colorMap@ref"]

    eyelash_bytes = write_jmtl(0x14, {"colorMap@ref": eye_params["colorMap@ref"]})
    print(f"[self-test] yCh_eyelash: {len(eyelash_bytes)} bytes (target ~56)")
    assert jmtl_resolver.extract_color_hash(eyelash_bytes) == eye_params["colorMap@ref"]

    # Head: colorMap is at field 1 — verifies non-zero index handling.
    head_hash = _fnv("Characters/X/Textures/head_color.tex")
    head_bytes = write_jmtl(0x17, {"colorMap@ref": head_hash, "detailzoneMap@ref": _fnv("X/dz.tex")})
    print(f"[self-test] yCh_head: {len(head_bytes)} bytes")
    assert jmtl_resolver.extract_color_hash(head_bytes) == head_hash

    # Gear: colorMap at field 9, plus the variant-byte semantics.
    gear_hash = _fnv("Characters/X/Textures/tops_color.tex")
    gear_bytes = write_jmtl(0x15, {"variant": 1, "colorMap@ref": gear_hash, "exposure": 1.0})
    print(f"[self-test] yCh_gear (alphaBlend): {len(gear_bytes)} bytes")
    assert jmtl_resolver.extract_color_hash(gear_bytes) == gear_hash

    # Teeth: colorMap at field 0 plus an irradiance color child.
    teeth_hash = _fnv("Characters/X/Textures/teeth_color.tex")
    teeth_bytes = write_jmtl(0x1A, {
        "colorMap@ref": teeth_hash,
        "irradianceR": 0.7, "irradianceG": 0.7, "irradianceB": 0.7,
        "g_teethWetness": 0.65,
    })
    print(f"[self-test] yCh_teeth: {len(teeth_bytes)} bytes")
    assert jmtl_resolver.extract_color_hash(teeth_bytes) == teeth_hash

    # Null-hash sentinel: omit-the-slot behaviour.
    skin_null = write_jmtl(0x19, {"colorMap@ref": 0xFFFFFFFFFFFFFFFF, "nrMap@ref": None})
    assert jmtl_resolver.extract_color_hash(skin_null) is None, "null sentinel leaked through as a hash"
    print(f"[self-test] null-sentinel omission OK")

    # NaN guard: shouldn't crash, should substitute default.
    skin_nan = write_jmtl(0x19, {"colorMap@ref": color_hash, "g_specIntensity": float("nan")})
    assert jmtl_resolver.extract_color_hash(skin_nan) == color_hash
    print(f"[self-test] NaN substitution OK")

    # Unsupported shader: must raise.
    try:
        write_jmtl(0xFF, {})
    except ValueError as e:
        print(f"[self-test] unsupported-shader raise OK: {e}")
    else:
        raise AssertionError("write_jmtl(0xFF, {}) should have raised ValueError")

    # ─── CRASH-BUG regression: empty-params gear must have all required slots ─
    # Vanilla Rock shoes.jmtl populates [4,8,9,11,12,14,15,19]; the buggy writer
    # produced 160 bytes missing 8/11/12 → crash. Post-fix: larger than 160
    # (~168) and every schema-required slot present.
    gear_empty = write_jmtl(0x15, {})
    print(f"[self-test] yCh_gear empty-params: {len(gear_empty)} bytes")
    assert len(gear_empty) > 160, (
        f"empty-params gear size {len(gear_empty)} <= 160 — crash-bug regression"
    )

    # Verify required gear slots are populated in the payload vtable.
    root_pos = _struct.unpack_from("<I", gear_empty, 0)[0]
    rsoff = _struct.unpack_from("<i", gear_empty, root_pos)[0]
    rvp = root_pos - rsoff
    rvt = _struct.unpack_from("<H", gear_empty, rvp)[0]
    rn = (rvt - 4) // 2
    roffs = list(_struct.unpack_from(f"<{rn}H", gear_empty, rvp + 4))
    payload_pos = root_pos + roffs[2] + _struct.unpack_from(
        "<I", gear_empty, root_pos + roffs[2]
    )[0]
    psoff = _struct.unpack_from("<i", gear_empty, payload_pos)[0]
    pvp = payload_pos - psoff
    pvt = _struct.unpack_from("<H", gear_empty, pvp)[0]
    pn = (pvt - 4) // 2
    poffs = list(_struct.unpack_from(f"<{pn}H", gear_empty, pvp + 4))
    populated = {i for i, o in enumerate(poffs) if o != 0}
    required_gear = shader_required_slots(0x15)
    missing = required_gear - populated
    assert not missing, f"empty-params gear missing required slots {missing}"
    print(f"[self-test] yCh_gear empty-params required slots OK: {sorted(populated)}")

    # Verify the nrMap@ref slot is present-but-unbound, not absent. Fresh real
    # exports replace this sentinel with the character/attire texture hash.
    nrmap_off = poffs[12]
    nrmap_pos = payload_pos + nrmap_off
    nrmap_val = _struct.unpack_from("<Q", gear_empty, nrmap_pos)[0]
    assert nrmap_val == _U64_NULL_SENTINEL, (
        f"gear nrMap@ref null sentinel not emitted: got 0x{nrmap_val:016X}"
    )
    print(f"[self-test] yCh_gear empty-params nrMap@ref = 0x{nrmap_val:016X} (present/unbound)")

    # ─── INVISIBLE-HAIR regression: empty-params hair must have all required slots ─
    # Vanilla hair_ALPHA populates [0,1,2,4,5,6,11] (refs flowMap/mPixMsk/comboMap
    # + both color children); the buggy writer omitted 2/4/5/6/11 → invisible
    # hair. Post-fix empty-params must include {0,1,2,4,5,6,11}.
    hair_empty = write_jmtl(0x16, {})
    print(f"[self-test] yCh_hair empty-params: {len(hair_empty)} bytes")
    root_pos = _struct.unpack_from("<I", hair_empty, 0)[0]
    rsoff = _struct.unpack_from("<i", hair_empty, root_pos)[0]
    rvp = root_pos - rsoff
    rvt = _struct.unpack_from("<H", hair_empty, rvp)[0]
    rn = (rvt - 4) // 2
    roffs = list(_struct.unpack_from(f"<{rn}H", hair_empty, rvp + 4))
    payload_pos = root_pos + roffs[2] + _struct.unpack_from(
        "<I", hair_empty, root_pos + roffs[2]
    )[0]
    psoff = _struct.unpack_from("<i", hair_empty, payload_pos)[0]
    pvp = payload_pos - psoff
    pvt = _struct.unpack_from("<H", hair_empty, pvp)[0]
    pn = (pvt - 4) // 2
    poffs = list(_struct.unpack_from(f"<{pn}H", hair_empty, pvp + 4))
    populated = {i for i, o in enumerate(poffs) if o != 0}
    required_hair = {0, 1, 2, 4, 5, 6, 11}
    missing = required_hair - populated
    assert not missing, (
        f"empty-params hair missing required slots {missing} "
        f"(populated={sorted(populated)})"
    )
    print(f"[self-test] yCh_hair empty-params required slots OK: {sorted(populated)}")

    # ─── INVISIBLE-BODY / INVISIBLE-HEAD regression ─────────────────────
    # Vanilla audit (5 BaseModel samples): head.jmtl always [1,5,9,12,22],
    # body.jmtl always [0,1,6,9,18]. The buggy writer populated only scalars and
    # omitted every texture ref + required child → null-deref → invisible/crash.
    # Fix mirrors gear/hair: null-sentinel hashes for refs + vanilla-default
    # color/UV/glow children.

    def _payload_populated_slots(buf):
        """Return the set of populated slot indices in the payload vtable."""
        root_pos = _struct.unpack_from("<I", buf, 0)[0]
        rsoff = _struct.unpack_from("<i", buf, root_pos)[0]
        rvp = root_pos - rsoff
        rvt = _struct.unpack_from("<H", buf, rvp)[0]
        rn = (rvt - 4) // 2
        roffs = list(_struct.unpack_from(f"<{rn}H", buf, rvp + 4))
        pay_uoff_pos = root_pos + roffs[2]
        pay_uoff = _struct.unpack_from("<I", buf, pay_uoff_pos)[0]
        payload_pos = pay_uoff_pos + pay_uoff
        psoff = _struct.unpack_from("<i", buf, payload_pos)[0]
        pvp = payload_pos - psoff
        pvt = _struct.unpack_from("<H", buf, pvp)[0]
        pn = (pvt - 4) // 2
        poffs = list(_struct.unpack_from(f"<{pn}H", buf, pvp + 4))
        return {i for i, o in enumerate(poffs) if o != 0}

    head_empty = write_jmtl(0x17, {})
    print(f"[self-test] yCh_head empty-params: {len(head_empty)} bytes")
    assert head_empty[4:8] == b"Mate"
    head_populated = _payload_populated_slots(head_empty)
    required_head = {1, 5, 9, 12, 22}
    missing = required_head - head_populated
    assert not missing, (
        f"empty-params head missing required slots {missing} "
        f"(populated={sorted(head_populated)})"
    )
    print(f"[self-test] yCh_head empty-params required slots OK: "
          f"{sorted(head_populated & required_head)} >= {sorted(required_head)}")

    skin_empty = write_jmtl(0x19, {})
    print(f"[self-test] yCh_skin empty-params: {len(skin_empty)} bytes")
    assert skin_empty[4:8] == b"Mate"
    skin_populated = _payload_populated_slots(skin_empty)
    required_skin = {0, 1, 6, 9, 18}
    missing = required_skin - skin_populated
    assert not missing, (
        f"empty-params skin missing required slots {missing} "
        f"(populated={sorted(skin_populated)})"
    )
    print(f"[self-test] yCh_skin empty-params required slots OK: "
          f"{sorted(skin_populated & required_skin)} >= {sorted(required_skin)}")

    # Verify legacy preset-key alias (g_nrmMap@ref → nrMap@ref) works.
    legacy_hash = 0xDEADBEEFCAFEBABE
    head_legacy = write_jmtl(0x17, {"g_nrmMap@ref": legacy_hash})
    head_pop = _payload_populated_slots(head_legacy)
    assert 5 in head_pop, "legacy g_nrmMap@ref alias didn't populate slot 5 on head"
    # Decode the nrMap@ref value to confirm the alias actually passed through.
    root_pos = _struct.unpack_from("<I", head_legacy, 0)[0]
    rsoff = _struct.unpack_from("<i", head_legacy, root_pos)[0]
    rvp = root_pos - rsoff
    rvt = _struct.unpack_from("<H", head_legacy, rvp)[0]
    rn = (rvt - 4) // 2
    roffs = list(_struct.unpack_from(f"<{rn}H", head_legacy, rvp + 4))
    pay_uoff_pos = root_pos + roffs[2]
    pay_uoff = _struct.unpack_from("<I", head_legacy, pay_uoff_pos)[0]
    payload_pos = pay_uoff_pos + pay_uoff
    psoff = _struct.unpack_from("<i", head_legacy, payload_pos)[0]
    pvp = payload_pos - psoff
    pvt = _struct.unpack_from("<H", head_legacy, pvp)[0]
    pn = (pvt - 4) // 2
    poffs = list(_struct.unpack_from(f"<{pn}H", head_legacy, pvp + 4))
    nrm_val = _struct.unpack_from("<Q", head_legacy, payload_pos + poffs[5])[0]
    assert nrm_val == legacy_hash, (
        f"legacy alias passthrough wrong: got 0x{nrm_val:016X}, want 0x{legacy_hash:016X}"
    )
    print(f"[self-test] yCh_head g_nrmMap@ref legacy alias OK")

    # Same alias check for body.
    body_legacy = write_jmtl(0x19, {"g_nrmMap@ref": legacy_hash})
    body_pop = _payload_populated_slots(body_legacy)
    assert 1 in body_pop, "legacy g_nrmMap@ref alias didn't populate slot 1 on body"
    print(f"[self-test] yCh_skin g_nrmMap@ref legacy alias OK")

    print("[self-test] ALL PASS")


if __name__ == "__main__":  # pragma: no cover
    _self_test()
