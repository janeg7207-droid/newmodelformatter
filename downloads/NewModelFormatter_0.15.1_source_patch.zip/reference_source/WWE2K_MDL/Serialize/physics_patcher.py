"""
Physics Stream Updater for WWE 2K model addon.

Generates the final physics sub-streams for export. Donor blobs serve as
structural templates; per-vertex binding records are recomputed (or
appended) against the scene's actual geometry.

Composition rules per stream:

  HCYW (hair / sim-chain corrective):
      - Donor template provides wrapper, MOD2 collider list, MOD6 mini-
        header, sub-table 2 acceleration arrays, and cross-binding records.
      - MOD1 patched/extended for scene M_*/S_* pairs (jackets, tassels,
        extra hair chains), MOD2 collider vert counts refreshed against
        scene M_Head/M_Body.
      - For every NEW render mesh (M_X with no donor MOD6 records),
        primary records are SYNTHESIZED — for each render vert, find
        nearest M_Head triangle, compute barycentric, quantize to 8-bit
        weights summing to 255. Appended to MOD6, flag table extended.
      - Donor's existing render-mesh records (M_Hair, etc.) pass through
        untouched — donor transplant for those keeps working as before.

  HYWA (hair vertex/anim): donor passes through, optional bone rename.

  OCYW (body corrective): donor template, MOD1 vert count = scene's
                          M_Combinations, MOD2 collider counts refreshed,
                          MOD6 primary records FULLY RECOMPUTED, MOD7
                          sparse positions written from M_Combinations.

  OYWA (body vertex/anim): donor passes through if original was placeholder
                           (barren attire), else original kept.

The MOD6 record format (12 bytes, derived spec):
    +0x00  u24 idx                 render-mesh vert sequential index
    +0x03  u8  weight_a            \\
    +0x04  u8  weight_b             +-- 8-bit barycentric, sum = 255
    +0x05  u8  weight_c            /
    +0x06  u16 vert_c              third triangle vert (M_Head index)
    +0x08  u16 vert_a              first  triangle vert
    +0x0A  u16 vert_b              second triangle vert

MOD header sizes (bytes from MOD! tag to data):
  MOD1 (sim meshes):          +0x4C   (68-byte header)
  MOD2 (collision refs):      +0x4C   (68-byte header)  [HCYW/OCYW]
  MOD2 (bone tree):           +0x48   (64-byte header)  [HYWA/OYWA]
  MOD4 (vertex data, "link"): +0x4C   (68-byte header)
  MOD6 (link constraints):    +0x48   (64-byte header)
  MOD7 (constraint data):     +0x48   (64-byte header)
"""

import struct
from typing import List, Dict, Optional, Tuple, Set
from ..Link.log import dlog
from .physics_constants import PHYSICS_OUTER_TAGS

# Bump this whenever patch_hcyw_template / update_physics_for_export
# learn new behavior — visible in console at every patcher run, so the
# user can verify their installed addon is the build they expect.
_PHYSICS_PATCHER_VERSION = "v2.6.2-mod4-offset-fix"

# Maps each CAS tag back to its full-attire counterpart for logical-role
# resolution (composer cares whether something is a "corrective" stream
# or a "base sim" stream, not which file flavor it came from).
CAS_TAG_ALIAS = {
    b'CYWA': b'HCYW',   # corrective: render-mesh → body-collider binding
    b'YWA!': b'HYWA',   # base sim:    bone tree + sim mesh data
}

# Reverse — when writing back, we need to remember the source's flavor
# so a CAS source stays CAS, a full-attire source stays full-attire.
CAS_TAG_INVERSE = {v: k for k, v in CAS_TAG_ALIAS.items()}


# Vanilla 200-byte placeholder OCYW substream (captured from Asuka 621_Attire):
# envelope + SIZ!/END! + empty MOD1 (mesh_count=0) + empty MOD2. The engine reads
# this as "no body proxy physics" rather than "missing substream" (a missing one
# freezes mid-match on barren attires).
_OCYW_PLACEHOLDER_208 = (
    b'\xc8\x00\x00\x00'                           # u32 size = 200
    + b'OCYW'                                     # outer tag
    + b'SIZ!'                                     # payload start
    + b'\x02\x00\x00\x00'                         # mod count = 2
    + b'MOD!\x01\x00\x00\x00' + b'\x00' * 84      # MOD! 1, all-zero data (92 bytes)
    + b'MOD!\x02\x00\x00\x00' + b'\x00' * 84      # MOD! 2, all-zero data (92 bytes)
    + b'END!'                                     # payload end
    + b'\x00\x00\x00\x00'                         # final padding
)
# OYWA placeholder is structurally identical with the OYWA tag — used only
# when both original and donor lack OYWA entirely.
_OYWA_PLACEHOLDER_208 = _OCYW_PLACEHOLDER_208.replace(b'OCYW', b'OYWA', 1)

assert len(_OCYW_PLACEHOLDER_208) == 208, len(_OCYW_PLACEHOLDER_208)
assert len(_OYWA_PLACEHOLDER_208) == 208, len(_OYWA_PLACEHOLDER_208)


# ════════════════════════════════════════════════════════════════════════════
#  Scene Analysis
# ════════════════════════════════════════════════════════════════════════════

def _vertex_count(mesh) -> int:
    """vCSkinMesh.vertices may be a list of Vector objects (DLL-loaded
    path) OR a flat float list (Blender export path: getRawMeshPositions /
    getMeshVertices). Both paths feed the same patcher entry points, so
    we use _vert_count to get the conceptual count rather than trusting
    raw len()."""
    if not mesh.vertices:
        return 0
    return _vert_count(mesh.vertices)


def get_scene_sim_meshes(scene_meshes) -> Dict[str, int]:
    """{name: vertex_count} for every M_*/S_* paired mesh in the scene.

    Generic — covers hair (M_Hair/S_Hair), jackets, tassels, anything that
    follows the convention. Both halves of the pair appear in the result.
    """
    if not scene_meshes:
        return {}

    by_name = {}
    for mesh in scene_meshes:
        name = mesh.mesh_name
        if name:
            by_name[name] = _vertex_count(mesh)

    result: Dict[str, int] = {}
    for mesh in scene_meshes:
        name = mesh.mesh_name
        if not name:
            continue
        if name.startswith('M_'):
            partner = 'S_' + name[2:]
        elif name.startswith('S_'):
            partner = 'M_' + name[2:]
        else:
            continue
        if partner not in by_name:
            continue
        if name.startswith('M_'):
            result.setdefault(name, by_name[name])
            result.setdefault(partner, by_name[partner])
        else:
            result.setdefault(partner, by_name[partner])
            result.setdefault(name, by_name[name])
    return result


def get_scene_hair_meshes(scene_meshes) -> Dict[str, int]:
    """Backward-compat alias."""
    return get_scene_sim_meshes(scene_meshes)


def get_scene_mesh_by_name(scene_meshes, name: str):
    """Return the vCSkinMesh whose mesh_name matches `name`, or None."""
    if not scene_meshes:
        return None
    for mesh in scene_meshes:
        if mesh.mesh_name == name:
            return mesh
    return None


def _pair_root(name: str) -> str:
    if name.startswith('M_') or name.startswith('S_'):
        return name[2:]
    return name


# ════════════════════════════════════════════════════════════════════════════
#  Geometry — closest-point-on-triangle, barycentric, quantization
# ════════════════════════════════════════════════════════════════════════════

def _v3_sub(a, b): return (a[0]-b[0], a[1]-b[1], a[2]-b[2])
def _v3_add(a, b): return (a[0]+b[0], a[1]+b[1], a[2]+b[2])
def _v3_scl(a, s): return (a[0]*s, a[1]*s, a[2]*s)
def _v3_dot(a, b): return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]


def _vec(p):
    return (p.x, p.y, p.z) if hasattr(p, 'x') else tuple(p)


def _normalize_verts(verts):
    """Coerce a vertex container into a uniform list of (x, y, z) tuples.

    The addon hands us vertex data in two different shapes depending on
    where it came from:
      • DLL-loaded path (skinmesh.py): list of mathutils.Vector objects
        (have .x / .y / .z, also tuple-iterable). Used by donor_colliders
        and getSceneColliderGeometry.
      • Blender export path (getRawMeshPositions / getMeshVertices):
        flat float list `[x0, y0, z0, x1, y1, z1, ...]`. Used by every
        vCSkinMesh in the export's scene_meshes list — i.e. every render
        mesh and any scene-selected M_Head / M_Body.

    Without normalization, iterating a flat-float list yields individual
    floats and `_vec(float)` blows up with "float object is not iterable".
    The flat-float case also has 3× the entry count vs the conceptual
    vert count, which would silently produce 3× the records if it didn't
    crash first.

    Detection is by element type: if the first element is a scalar number
    we chunk into triples; otherwise we _vec each element so the consumer
    sees uniform 3-tuples regardless of source.
    """
    if not verts:
        return []
    first = verts[0]
    if isinstance(first, (int, float)):
        n = len(verts) // 3
        return [(verts[i*3], verts[i*3+1], verts[i*3+2]) for i in range(n)]
    return [_vec(v) for v in verts]


def _vert_count(verts) -> int:
    """Conceptual vertex count regardless of container shape.

    Flat-float lists (Blender export path) are 3× longer than their
    conceptual vert count — naively calling len() returns the wrong
    number and silently produces 3× records. Use this helper anywhere
    the real vert count matters (record counts, MOD1 size fields,
    placeholder synthesis, allocation sizing).
    """
    if not verts:
        return 0
    return len(verts) // 3 if isinstance(verts[0], (int, float)) else len(verts)


def _normalize_tris(tris):
    """Coerce a triangle container into a list of (i0, i1, i2) tuples.

    Same dual-shape problem as _normalize_verts:
      • DLL-loaded path (skinmesh.py getIndexList): list of (i0, i1, i2)
        tuples already.
      • Blender export path (getMeshFaces): flat int list, 3 per triangle.
      • Raw export (getRawMeshPolygons): flat int list with face_sizes
        sidecar — but the addon's makeSkinMeshDLL only ships triangulated
        meshes through this path (format_game_uv_seams runs first), so by
        the time we see it the flat list is already triangle-aligned.

    Defensive policy: if we see a non-triangle face_size mid-stream we'd
    rather skip than fan-split and risk index drift. Caller can pre-
    triangulate if needed.
    """
    if not tris:
        return []
    first = tris[0]
    if isinstance(first, (tuple, list)):
        return [tuple(t) for t in tris]
    if isinstance(first, int):
        n = len(tris) // 3
        return [(tris[i*3], tris[i*3+1], tris[i*3+2]) for i in range(n)]
    return list(tris)


def _closest_point_bary(p, a, b, c):
    """Returns ((u, v, w), squared_distance) for closest point on triangle (a,b,c)."""
    ab = _v3_sub(b, a); ac = _v3_sub(c, a); ap = _v3_sub(p, a)
    d1 = _v3_dot(ab, ap); d2 = _v3_dot(ac, ap)
    if d1 <= 0.0 and d2 <= 0.0:
        diff = _v3_sub(p, a)
        return (1.0, 0.0, 0.0), _v3_dot(diff, diff)

    bp = _v3_sub(p, b); d3 = _v3_dot(ab, bp); d4 = _v3_dot(ac, bp)
    if d3 >= 0.0 and d4 <= d3:
        diff = _v3_sub(p, b)
        return (0.0, 1.0, 0.0), _v3_dot(diff, diff)

    vc = d1*d4 - d3*d2
    if vc <= 0.0 and d1 >= 0.0 and d3 <= 0.0:
        v = d1 / (d1 - d3) if (d1 - d3) != 0 else 0.0
        cp = _v3_add(a, _v3_scl(ab, v))
        diff = _v3_sub(p, cp)
        return (1.0 - v, v, 0.0), _v3_dot(diff, diff)

    cp_ = _v3_sub(p, c); d5 = _v3_dot(ab, cp_); d6 = _v3_dot(ac, cp_)
    if d6 >= 0.0 and d5 <= d6:
        diff = _v3_sub(p, c)
        return (0.0, 0.0, 1.0), _v3_dot(diff, diff)

    vb = d5*d2 - d1*d6
    if vb <= 0.0 and d2 >= 0.0 and d6 <= 0.0:
        w = d2 / (d2 - d6) if (d2 - d6) != 0 else 0.0
        cp = _v3_add(a, _v3_scl(ac, w))
        diff = _v3_sub(p, cp)
        return (1.0 - w, 0.0, w), _v3_dot(diff, diff)

    va = d3*d6 - d5*d4
    if va <= 0.0 and (d4 - d3) >= 0.0 and (d5 - d6) >= 0.0:
        denom = (d4 - d3) + (d5 - d6)
        w = (d4 - d3) / denom if denom != 0 else 0.0
        cp = _v3_add(b, _v3_scl(_v3_sub(c, b), w))
        diff = _v3_sub(p, cp)
        return (0.0, 1.0 - w, w), _v3_dot(diff, diff)

    denom = va + vb + vc
    inv = 1.0 / denom if denom != 0 else 0.0
    v = vb * inv; w = vc * inv; u = 1.0 - v - w
    cp = _v3_add(a, _v3_add(_v3_scl(ab, v), _v3_scl(ac, w)))
    diff = _v3_sub(p, cp)
    return (u, v, w), _v3_dot(diff, diff)


def _nearest_triangle(p, target_verts, target_tris):
    """For point p, find triangle in (target_verts, target_tris) minimising
    distance. Returns (a, b, c, u, v, w) or None if target empty."""
    if not target_tris or not target_verts:
        return None
    best_d2 = float('inf')
    best = None
    px = _vec(p)
    for (ia, ib, ic) in target_tris:
        if ia >= len(target_verts) or ib >= len(target_verts) or ic >= len(target_verts):
            continue
        ap = _vec(target_verts[ia])
        bp = _vec(target_verts[ib])
        cp = _vec(target_verts[ic])
        (u, v, w), d2 = _closest_point_bary(px, ap, bp, cp)
        if d2 < best_d2:
            best_d2 = d2
            best = (ia, ib, ic, u, v, w)
            if d2 < 1e-10:
                break
    return best


def _quantize_bary_255(u: float, v: float, w: float) -> Tuple[int, int, int]:
    """Quantize (u,v,w) to 8-bit weights summing to exactly 255.

    Byte-identity matters (these are raw u8s in the 12-byte record): preserve
    the exact tie-breaking of the prior list.index(max/min) version — bump the
    largest positive residual up / largest-magnitude negative down, tie-break by
    lowest index (the strict `>`/`<` on the running winner replicates
    list.index's first-occurrence).
    """
    s = u + v + w
    if s > 0.0:
        u, v, w = u/s, v/s, w/s
    raw = [u*255.0, v*255.0, w*255.0]
    rounded = [round(r) for r in raw]
    residuals = [raw[i] - rounded[i] for i in range(3)]
    diff = 255 - sum(rounded)
    while diff != 0:
        if diff > 0:
            # Equivalent to residuals.index(max(residuals)) — first occurrence wins.
            best = 0
            for j in (1, 2):
                if residuals[j] > residuals[best]:
                    best = j
            rounded[best] += 1
            residuals[best] -= 1.0
            diff -= 1
        else:
            # Equivalent to residuals.index(min(residuals)) — first occurrence wins.
            worst = 0
            for j in (1, 2):
                if residuals[j] < residuals[worst]:
                    worst = j
            rounded[worst] -= 1
            residuals[worst] += 1.0
            diff += 1
    rounded = [max(0, min(255, x)) for x in rounded]
    return rounded[0], rounded[1], rounded[2]


def _pack_primary_record(vert_idx: int, slot: int,
                         va: int, vb: int, vc: int,
                         wa: int, wb: int, wc: int) -> bytes:
    """12-byte primary record per the derived spec.

    Layout (verified across HCYW/CYWA in WWE 2K26):
        +0x00  u16 vert_index    sequential 0..N-1 (N = MOD1 slot[0] vert count)
        +0x02  u8  collider_slot 0 = MOD2.entry[0] (M_Head), 1 = MOD2.entry[1] (M_Body).
                                 Tells the engine which collider mesh's vert
                                 space the triangle indices below reference.
        +0x03  u8  weight_a      \\
        +0x04  u8  weight_b       +-- 8-bit barycentric, sum = 255
        +0x05  u8  weight_c      /
        +0x06  u16 vert_c        third triangle vert (in collider_slot's space)
        +0x08  u16 vert_a        first  triangle vert
        +0x0A  u16 vert_b        second triangle vert

    Slot distribution per file confirms which collider the verts hug:
      Asuka HCYW (hair):  11011/11012 records slot=0 (M_Head), 1 slot=1
      Hair CYWA:          4859 slot=0, 359 slot=1 (hair drapes onto shoulders)
      Jacket CYWA:        4908 slot=1 (M_Body), 342 slot=0 (collar near head)
    """
    # All four index fields are u16. Validate all four so overflow is one clear
    # error rather than the old half-silent-corruption (vert_idx masked &0xFFFF)
    # / half-crash (vc/va/vb unmasked → struct.error). Callers guard the large-
    # render-mesh case up front; this catches pathological collider overflow.
    for label, val in (('vert_index', vert_idx), ('vert_a', va),
                       ('vert_b', vb), ('vert_c', vc)):
        if not (0 <= val <= 0xFFFF):
            raise ValueError(
                f"physics record {label}={val} out of u16 range "
                f"[0, 65535] — mesh too large for MCD physics format")
    return (struct.pack('<H', vert_idx)
            + bytes([slot & 0xFF, wa, wb, wc])
            + struct.pack('<HHH', vc, va, vb))


def _nearest_triangle_dual(p, head_verts, head_tris, body_verts, body_tris):
    """Find closest triangle across BOTH M_Head and M_Body, pick the closer.
    Returns (slot, a, b, c, u, v, w) or None.

    slot = 0 if M_Head won, 1 if M_Body won. Matches MOD2 entry order
    used by the engine (and present in MOD2 collider tables of every
    file we've inspected: M_Head=slot 0, M_Body=slot 1).
    """
    head_best = _nearest_triangle(p, head_verts, head_tris) if head_tris else None
    body_best = _nearest_triangle(p, body_verts, body_tris) if body_tris else None

    if head_best is None and body_best is None:
        return None
    if body_best is None:
        ia, ib, ic, u, v, w = head_best
        return (0, ia, ib, ic, u, v, w)
    if head_best is None:
        ia, ib, ic, u, v, w = body_best
        return (1, ia, ib, ic, u, v, w)

    # Both available — recompute distances. _nearest_triangle returns the
    # winner per-mesh but discards the d² value, so we do one more round.
    def _d2(p, mesh_verts, ia, ib, ic):
        a, b, c = _vec(mesh_verts[ia]), _vec(mesh_verts[ib]), _vec(mesh_verts[ic])
        _bary, d2 = _closest_point_bary(_vec(p), a, b, c)
        return d2

    h_ia, h_ib, h_ic, h_u, h_v, h_w = head_best
    b_ia, b_ib, b_ic, b_u, b_v, b_w = body_best
    h_d2 = _d2(p, head_verts, h_ia, h_ib, h_ic)
    b_d2 = _d2(p, body_verts, b_ia, b_ib, b_ic)
    if h_d2 <= b_d2:
        return (0, h_ia, h_ib, h_ic, h_u, h_v, h_w)
    return (1, b_ia, b_ib, b_ic, b_u, b_v, b_w)


def _build_placeholder_records(start_idx: int, num_verts: int,
                                vert_remap=None) -> bytes:
    """Generate file-valid placeholder records when collider geometry isn't
    available (typical port scenario: sidecar donor mode that doesn't load
    a CSkinModel, or scene without baseModel head/body).

    Each record binds vert K to M_Head triangle (0,1,2) with weights
    (255, 0, 0) — i.e. fully anchored to vert 0 of M_Head. Physics will
    be wrong (everything attached to one head vertex) but the file stays
    structurally valid: MOD6 record count matches MOD1 slot vert count,
    triangle indices reference valid M_Head verts, weights sum to 255.
    Engine won't freeze on a count mismatch.

    User can then iterate — pick a 2K26 single-MCD donor, get proper
    colliders harvested, re-export for real bindings.
    """
    has_remap = vert_remap and len(vert_remap) >= num_verts
    # u16 hard limit on vert_index — bail (caller skips on empty result,
    # keeping MOD1/MOD6 in sync) rather than silently wrapping >65535.
    if has_remap:
        max_vert_idx = max((vert_remap[k] for k in range(num_verts)), default=0)
    else:
        max_vert_idx = start_idx + num_verts - 1 if num_verts else 0
    if max_vert_idx > 0xFFFF:
        dlog(f"[Physics Updater] placeholder vert_index {max_vert_idx} exceeds "
             f"u16 max (65535) — mesh too large for MCD physics record format; "
             f"skipping its records")
        return b''
    records_with_idx = []
    for k in range(num_verts):
        if has_remap:
            vert_idx = vert_remap[k]
        else:
            vert_idx = start_idx + k
        packed = _pack_primary_record(vert_idx, slot=0,
                                       va=0, vb=1, vc=2,
                                       wa=255, wb=0, wc=0)
        records_with_idx.append((vert_idx, packed))
    records_with_idx.sort(key=lambda r: r[0])
    return b''.join(r[1] for r in records_with_idx)


def _make_collider_query(verts, tris):
    """Build a callable that returns the nearest triangle for any query
    point. Uses Blender's BVHTree (mathutils.bvhtree) when available —
    O(log N) per query after a one-time O(N) build. Falls back to brute
    force outside Blender (pure-Python test environments).

    Verts must be normalized 3-tuples (post-_normalize_verts).
    Tris must be (i0, i1, i2) tuples (post-_normalize_tris).

    Returns None if verts/tris are empty or BVH construction fails.
    The callable takes a query point (3-tuple or vec-like) and returns
    (ia, ib, ic, u, v, w, distance) where (ia,ib,ic) are vert indices
    of the closest triangle, (u,v,w) are barycentric coords of the
    closest point on that triangle, and distance is from the query
    point to that closest point. Returns None if nothing was found.

    Performance: brute force hung Blender (26658 hair verts × ~33000 tris ≈
    880M comparisons); BVH cuts it to ~400K, sub-second.
    """
    if not verts or not tris:
        return None
    try:
        from mathutils.bvhtree import BVHTree
        from mathutils import Vector

        bvh_verts = [Vector(_vec(v)) for v in verts]
        bvh_tris = [tuple(t) for t in tris]
        bvh = BVHTree.FromPolygons(bvh_verts, bvh_tris, all_triangles=True)

        # find_nearest returns the polygon's index into bvh_tris, giving the
        # vert indices for the binding.
        def query(p):
            loc, _normal, idx, dist = bvh.find_nearest(Vector(_vec(p)))
            if idx is None:
                return None
            ia, ib, ic = bvh_tris[idx]
            # BVHTree gives the closest point but not bary — recompute.
            (u, v, w), _d2 = _closest_point_bary(
                _vec(p), _vec(verts[ia]), _vec(verts[ib]), _vec(verts[ic]))
            return (ia, ib, ic, u, v, w, dist)

        return query
    except (ImportError, AttributeError, RuntimeError, ValueError):
        # Pure-Python fallback. ~100× slower than BVH but correct, used
        # when running tests outside Blender. In production this branch
        # never fires.
        def query(p):
            best = _nearest_triangle(p, verts, tris)
            if best is None:
                return None
            ia, ib, ic, u, v, w = best
            a, b, c = _vec(verts[ia]), _vec(verts[ib]), _vec(verts[ic])
            cp = _v3_add(_v3_add(_v3_scl(a, u), _v3_scl(b, v)), _v3_scl(c, w))
            diff = _v3_sub(_vec(p), cp)
            return (ia, ib, ic, u, v, w, _v3_dot(diff, diff) ** 0.5)
        return query


def _build_primary_records(start_idx: int, render_verts,
                           head_verts, head_tris,
                           body_verts=None, body_tris=None,
                           vert_remap=None) -> Tuple[bytes, int, int]:
    """Generate primary records binding render_verts to nearest triangles
    of M_Head OR M_Body, picking whichever is closer per-vert.

    `head_verts`/`head_tris` are required. `body_verts`/`body_tris` are
    optional — when omitted (caller has no M_Body in scene or donor),
    every record falls back to slot=0 (M_Head). Functional but less
    geometrically faithful for body-hugging meshes like jackets.

    `vert_remap` (`vertex_remap[blender_idx] = mcd_idx`) is carried on every
    vCSkinMesh whose source ran through dedup. With "Use Vertex Remap" the DLL
    reorders the MCD vert buffer to MCD order; since records reference vert
    INDICES, we write `vert_idx = vert_remap[K]` so the binding survives the
    reorder. None/empty → sequential `start_idx + k`.

    Records are sorted by vert_idx to match vanilla's sequential pattern (engine
    looks up by vert_idx, so this is cosmetic — cleaner diffs only).

    Returns (records_bytes, fallback_count, slot1_count).
    fallback_count: verts where no nearest triangle was found (rare).
    slot1_count: verts whose binding chose M_Body — useful for logging.
    """
    # Normalize to uniform 3-tuples — render_verts may be flat floats (export
    # path) or Vector-likes (DLL/test path). head/body are normalized by
    # _get_collider but normalize defensively in case a caller passed raw.
    render_verts = _normalize_verts(render_verts)
    head_verts = _normalize_verts(head_verts)
    head_tris = _normalize_tris(head_tris)
    if body_verts is not None:
        body_verts = _normalize_verts(body_verts)
    if body_tris is not None:
        body_tris = _normalize_tris(body_tris)
    fallback = 0
    slot1 = 0
    has_body = bool(body_verts and body_tris)
    has_remap = bool(vert_remap and len(vert_remap) >= len(render_verts))

    # u16 hard limit on vert_index — bail (caller skips on empty recs,
    # keeping MOD1/MOD6 in sync) rather than silently wrapping >65535.
    if has_remap:
        max_vert_idx = max((vert_remap[k] for k in range(len(render_verts))),
                           default=0)
    else:
        max_vert_idx = start_idx + len(render_verts) - 1 if render_verts else 0
    if max_vert_idx > 0xFFFF:
        dlog(f"[Physics Updater] vert_index {max_vert_idx} exceeds u16 max "
             f"(65535) — mesh too large for MCD physics record format; "
             f"skipping its records (no physics binding written)")
        return b'', 0, 0

    if not head_tris:
        return b'', 0, 0

    # Build acceleration structures once per collider mesh. With BVH
    # available (Blender), each query is O(log N); ~26K hair verts ×
    # 2 colliders → ~50K queries, sub-second total. Without BVH (pure
    # Python tests) the closures fall back to brute force.
    head_query = _make_collider_query(head_verts, head_tris)
    body_query = (_make_collider_query(body_verts, body_tris)
                  if has_body else None)
    if head_query is None:
        return b'', 0, 0

    # Build records into a list of (vert_idx, packed_bytes) so we can
    # sort by vert_idx after generation.
    records_with_idx = []
    for k, p in enumerate(render_verts):
        h = head_query(p)
        b_ = body_query(p) if body_query else None
        if h is not None and b_ is not None:
            # Both colliders found a candidate — pick whichever's closer.
            # Distance is element [6] of the tuple returned by the query.
            if h[6] <= b_[6]:
                slot = 0; ia, ib, ic, u, v, w = h[:6]
            else:
                slot = 1; ia, ib, ic, u, v, w = b_[:6]
        elif h is not None:
            slot = 0; ia, ib, ic, u, v, w = h[:6]
        elif b_ is not None:
            slot = 1; ia, ib, ic, u, v, w = b_[:6]
        else:
            # No triangle found anywhere — emit a fallback record.
            ia, ib, ic = head_tris[0]
            slot = 0
            u, v, w = 1.0, 0.0, 0.0
            fallback += 1

        wa, wb, wc = _quantize_bary_255(u, v, w)
        if slot == 1:
            slot1 += 1

        if has_remap:
            vert_idx = vert_remap[k]
        else:
            vert_idx = start_idx + k

        packed = _pack_primary_record(vert_idx, slot, ia, ib, ic, wa, wb, wc)
        records_with_idx.append((vert_idx, packed))

    # Sort by vert_idx so the binary record layout matches the vanilla
    # sequential pattern. With remap this also re-orders to MCD index
    # space; without remap it's a no-op since vert_idx was already
    # sequential.
    records_with_idx.sort(key=lambda r: r[0])
    buf = bytearray()
    for _, packed in records_with_idx:
        buf.extend(packed)

    return bytes(buf), fallback, slot1


# ════════════════════════════════════════════════════════════════════════════
#  MOD parsing helpers
# ════════════════════════════════════════════════════════════════════════════

def _find_mod_positions(data: bytes, start: int, end: int) -> List[Tuple[int, int]]:
    mods = []
    scan = start
    while scan < end - 8:
        if data[scan:scan + 4] == b'MOD!':
            mod_id = struct.unpack_from('<I', data, scan + 4)[0]
            mods.append((scan, mod_id))
        scan += 4
    return mods


def _read_mod1(data: bytes, mod_offset: int) -> Tuple[List[str], List[Tuple[int, int, int]]]:
    p = mod_offset + 0x4C
    mesh_count = struct.unpack_from('<I', data, p)[0]
    if mesh_count > 500 or mesh_count == 0:
        return [], []
    p += 4
    names = []
    for _ in range(mesh_count):
        name = data[p:p + 32].split(b'\x00')[0].decode('ascii', errors='replace')
        names.append(name)
        p += 32
    record_count = struct.unpack_from('<I', data, p)[0]
    p += 4
    records = []
    for _ in range(record_count):
        records.append(struct.unpack_from('<III', data, p))
        p += 12
    return names, records


def _write_mod1_data(names: List[str], records: List[Tuple[int, int, int]]) -> bytes:
    buf = bytearray()
    buf.extend(struct.pack('<I', len(names)))
    for name in names:
        padded = name.encode('ascii')[:31].ljust(32, b'\x00')
        buf.extend(padded)
    buf.extend(struct.pack('<I', len(records)))
    for idx, off, size in records:
        buf.extend(struct.pack('<III', idx, off, size))
    return bytes(buf)


def _patch_outer_size(buf: bytearray) -> None:
    """The blob is [u32 size][4-byte tag][payload] — keep size in sync."""
    struct.pack_into('<I', buf, 0, len(buf) - 8)


# ─── Bone tree (MOD!=2 in HYWA/OYWA, and inner-pass MOD!=2 in HCYW/OCYW) ────
#
# Structurally distinct from the collider-table MOD!=2 of the HCYW/OCYW outer
# pass:
#   collider table (header +0x4C):   count + 32-byte mesh names + 12B records
#   bone tree      (header +0x48):   count + 40-byte bone entries
#
# Each 40-byte bone entry:
#   +0x00 [24B]  null-padded ASCII bone name
#   +0x18 [8B]   reserved (zero)
#   +0x20 [4B]   i32 prev_idx in chain (-1 = chain root)
#   +0x24 [4B]   i32 next_idx in chain (-1 = chain end)
#
# Bones form doubly-linked chains (one per hair strand / jacket strip). prev/next
# index INTO THIS palette, not the global skeleton; standalone bones have both
# -1. When align_skeleton adds new sim bones on a port, the donor MOD!=2 still
# carries only the donor's palette, so match-mode physics has no entries for the
# new bones and skips them (cutscene/entrance use a capsule solver that doesn't
# read MOD!=2, so they kept working).


def _is_bone_tree_mod2(data: bytes, mod2_off: int) -> bool:
    """Disambiguate bone-tree MOD!=2 from collider-table MOD!=2.

    Bone trees have a plausible u32 count at +0x48 AND printable ASCII at
    +0x4C (first byte of first bone's name). Collider tables have padding
    (zero) at +0x48 and a small u32 mesh_count at +0x4C.
    """
    if mod2_off + 0x4D > len(data):
        return False
    count = struct.unpack_from('<I', data, mod2_off + 0x48)[0]
    if count == 0 or count > 5000:
        return False
    first_byte = data[mod2_off + 0x4C]
    return 32 <= first_byte < 127


def _read_bone_tree_entries(data: bytes, mod2_off: int
                            ) -> Tuple[int, List[Tuple[str, int, int]]]:
    """Parse the bone-tree palette at a confirmed bone-tree MOD!=2.

    Returns (count, [(name, prev_idx, next_idx), ...]).
    """
    count = struct.unpack_from('<I', data, mod2_off + 0x48)[0]
    entries_start = mod2_off + 0x4C
    out: List[Tuple[str, int, int]] = []
    for i in range(count):
        rec = entries_start + i * 40
        if rec + 40 > len(data):
            break
        name = data[rec:rec + 24].split(b'\x00')[0].decode('ascii', errors='replace')
        prev_idx = struct.unpack_from('<i', data, rec + 32)[0]
        next_idx = struct.unpack_from('<i', data, rec + 36)[0]
        out.append((name, prev_idx, next_idx))
    return count, out


def _pack_bone_entry(name: str, prev_idx: int, next_idx: int) -> bytes:
    """40-byte bone entry: 24B name + 8B zero + 4B prev_idx + 4B next_idx."""
    name_b = name.encode('ascii')[:23].ljust(24, b'\x00')
    return name_b + b'\x00' * 8 + struct.pack('<ii', prev_idx, next_idx)


def _build_chains_from_parents(new_bones: List[str],
                               parent_map: Dict[str, Optional[str]]
                               ) -> List[List[str]]:
    """Group `new_bones` into chains using parent_map (bone_name → parent_name
    or None).

    A chain root is a new bone whose parent isn't itself a new bone (i.e.,
    parent is either None, a non-sim joint like J_Hair, or a bone that
    already lives in the donor MOD!=2 — anything not also being inserted
    in this pass). Children of a root are picked up via the parent_map
    (only those that are also in new_bones), depth-first via the first
    child each step. Multi-child branches at any level become their own
    chains, rooted at each branching child.

    Returns: list of chains, each chain a parent-to-child list of bone names.
    Bones in new_bones that can't be placed (orphans, cycles) are returned
    as singleton chains so they still make it into the palette.
    """
    new_set = set(new_bones)
    # parent → list of new-bone children
    children_of: Dict[str, List[str]] = {}
    for b in new_bones:
        p = parent_map.get(b)
        if p in new_set:
            children_of.setdefault(p, []).append(b)

    # A bone is a chain root if its parent is NOT also a new bone
    roots = [b for b in new_bones if parent_map.get(b) not in new_set]

    # Walk depth-first from each root, following the first child each step.
    # Any sibling beyond the first becomes its OWN chain root (next iteration
    # of the outer loop). We approximate "branch becomes new chain" by
    # adding every sibling past index-0 back into the worklist as a root.
    chains: List[List[str]] = []
    placed: Set[str] = set()
    worklist = list(roots)
    while worklist:
        root = worklist.pop(0)
        if root in placed:
            continue
        chain = [root]
        placed.add(root)
        cur = root
        while True:
            kids = children_of.get(cur, [])
            if not kids:
                break
            # First child continues this chain
            first = kids[0]
            if first in placed:
                break
            chain.append(first)
            placed.add(first)
            # Additional children become roots of their own chains
            for sibling in kids[1:]:
                if sibling not in placed:
                    worklist.append(sibling)
            cur = first
        chains.append(chain)

    # Catch bones not placed by the root-walk (parent cycles or stranded
    # entries). Each gets its own singleton chain so it still makes it in.
    for b in new_bones:
        if b not in placed:
            chains.append([b])
            placed.add(b)

    return chains


def patch_substream_add_bone_tree(blob: bytes,
                                  scene_bones_with_parents: Dict[str, Optional[str]]
                                  ) -> bytes:
    """Append entries to the substream's bone-tree MOD!=2 for bones present
    in the scene but missing from the donor's palette.

    Safe to call on any substream — silently no-ops if the substream has
    no bone-tree MOD!=2 (e.g., placeholder OCYW, collider-only substreams).
    Idempotent: bones already in the tree are skipped.

    `scene_bones_with_parents`: {bone_name: parent_bone_name_or_None}.
    Parent info lets us reconstruct chain topology (root → child → ...) for
    correct prev_idx / next_idx wiring. Bones whose parent isn't itself
    being inserted (e.g., parent is J_Hair or an existing donor bone) start
    a new chain with prev_idx = -1.
    """
    if not scene_bones_with_parents or len(blob) < 16:
        return blob

    result = bytearray(blob)
    mods = _find_mod_positions(result, 8, len(result))

    # Locate the bone-tree MOD!=2. There may be multiple MOD!=2 markers
    # — one collider-table at the outer pass, one bone-tree at the inner
    # pass (2K26 HCYW/OCYW); HYWA / OYWA only have one and it's a bone
    # tree. Skip any MOD!=2 that doesn't pass the bone-tree discriminator.
    bone_tree_off = None
    for off, mid in mods:
        if mid == 2 and _is_bone_tree_mod2(result, off):
            bone_tree_off = off
            break

    if bone_tree_off is None:
        return bytes(result)

    old_count, existing = _read_bone_tree_entries(result, bone_tree_off)
    existing_names = {e[0] for e in existing}

    # Bones in the scene but NOT in the donor palette — those are the ones
    # `align_skeleton` added during the port that aren't yet bound in
    # match-mode physics. Skip rig joints (J_*) — those drive bones but
    # don't belong in a cloth bone palette regardless of whether they're new.
    new_bones = [
        b for b in scene_bones_with_parents
        if b not in existing_names and not b.startswith('J_')
    ]
    if not new_bones:
        return bytes(result)

    chains = _build_chains_from_parents(new_bones, scene_bones_with_parents)

    # Build the appended block. Each chain becomes a contiguous run of
    # entries with prev/next wired to its position in the run. First entry
    # of each chain: prev = -1. Last entry: next = -1.
    #
    # Indices in prev_idx / next_idx are GLOBAL palette indices (point
    # into MOD!=2 as a whole, not relative to the appended block), so the
    # math is `old_count + position_within_appended_block`.
    appended = bytearray()
    abs_idx = old_count
    total_added = 0
    for chain in chains:
        clen = len(chain)
        for pos, bname in enumerate(chain):
            prev_idx = (abs_idx - 1) if pos > 0 else -1
            next_idx = (abs_idx + 1) if pos < clen - 1 else -1
            appended.extend(_pack_bone_entry(bname, prev_idx, next_idx))
            abs_idx += 1
            total_added += 1

    # Splice the appended block in immediately after the existing entries.
    splice_at = bone_tree_off + 0x4C + old_count * 40
    result[splice_at:splice_at] = appended

    # Bump the count at +0x48.
    new_count = old_count + total_added
    struct.pack_into('<I', result, bone_tree_off + 0x48, new_count)

    # Update outer wrapper size — the [u32 size] header at offset 0.
    _patch_outer_size(result)

    dlog(f"[Physics Updater] BoneTreeAdd: +{total_added} bones across "
         f"{len(chains)} chain(s); MOD!=2 count {old_count} → {new_count}; "
         f"+{len(appended)} bytes spliced at substream +0x{splice_at:X}")
    return bytes(result)


# ─── Inner-pass MOD!=4 format upgrade (2K24 legacy → 2K26 simple remap) ────
#
# 2K26 HCYW/OCYW MOD!=4 = simple vertex-index remap: u32 num_blocks + u32
# outer_mesh_count + 8B pad + per-slot (vc, off) pairs (only slot 0) + zero pad
# to +0x38 + u32 record_count + record_count × u16 sequential indices (0..N-1).
# Total 0x3C + 2*N bytes.
#
# 2K24 .hair_ywa stores per-bone collision proxy records (228/184/165 region
# counts, 80-byte stride) at the same slot. A 2K24 sidecar donor's legacy
# payload merges verbatim; 2K26 match-mode reads it as the simple-remap shape,
# interprets floats as indices → OOB garbage → binding rejected (cutscene/
# entrance don't read MOD!=4). This pass rewrites the legacy shape as a fresh
# 2K26 payload sized from the outer MOD!=6 record count. Idempotent.


def _is_modern_inner_mod4(data: bytes, mod4_off: int) -> bool:
    """Whether the inner-pass MOD!=4 at mod4_off is already in 2K26 simple-
    remap format.

    Verified against vanilla 2K26 samples (Asuka 621, CAS hair, CAS jacket).
    Data starts at MOD!+0x48. Mini-header is six u32s with pattern
    `(0, 1, mesh_count, 0, 0, primary_vc)` where `primary_vc` matches the
    primary M_* render mesh's vert count from HCYW MOD!=1 slot[0]. The
    sequential u16 remap starts at MOD!+0x88 (after another u32 copy of
    primary_vc at MOD!+0x84).

    Legacy 2K24 payload (228/184/165 region counts at the same offsets)
    fails both checks: the first u32 is 1 not 0, and the bytes at the
    expected u16 indices position are float data from the per-bone records.
    """
    ds = mod4_off + 0x48
    if ds + 0x44 > len(data):
        return False
    f0, f1, mesh_count, f3, f4, primary_vc = struct.unpack_from('<6I', data, ds)
    if f0 != 0 or f1 != 1 or f3 != 0 or f4 != 0:
        return False
    if not (0 < primary_vc < 1_000_000) or not (0 < mesh_count <= 256):
        return False
    # Second copy of primary_vc lives at +0x3C (= MOD!+0x84) just before
    # the sequential u16 indices.
    vc_again = struct.unpack_from('<I', data, ds + 0x3C)[0]
    if vc_again != primary_vc:
        return False
    if ds + 0x40 + 12 > len(data):
        return False
    first_u16s = struct.unpack_from('<HHHHHH', data, ds + 0x40)
    return first_u16s == (0, 1, 2, 3, 4, 5)


def _build_mod4_per_slot_full(vc: int, is_outer: bool, mesh_count: int = 1) -> bytes:
    """Build one mesh slot's full MOD!=4 sub-structure (used recursively).

    Layout — outer (first slot, full file header form) vs nested (slots 1+):
        +0x00 [24B] mini-header: (0, 1, X, 0, 0, Y)
              outer:  X = total_mesh_count, Y = vc (primary_vc)
              nested: X = vc, Y = 0
        +0x18 [pad] zero padding — 36 bytes outer, 24 bytes nested
        [4B]  u32 vc echo
        [vc*2B] vc × u16 sequential indices 0..vc-1
        [36B] 36-byte zero pad
        [8B]  Block 1 hdr: u32=7 sentinel, u32=vc*56 size
        [vc*56 B] Block 1 data — per-vertex bind records (we write zeros;
                  engine will treat as "no displacement / default" per vert)
        [4B]  u32 vc (start of per-vertex weight array)
        [vc*4 B] vc × f32 = 1.0 each (default cloth weight; vanilla values
                  range 0.1..2.0 per-vert from real authoring)

    Total: 28 + pad + 2*vc + 8 + vc*56 + 4 + vc*4 = 40 + pad + 62*vc
    """
    pad = 36 if is_outer else 24
    hdr_mc = mesh_count if is_outer else vc
    hdr_vc = vc if is_outer else 0

    buf = bytearray()
    buf.extend(struct.pack('<6I', 0, 1, hdr_mc, 0, 0, hdr_vc))      # mini-header
    buf.extend(b'\x00' * pad)                                         # pre-seq pad
    buf.extend(struct.pack('<I', vc))                                 # u32 vc echo
    if vc > 0xFFFF:
        raise ValueError(
            f"MOD4 vertex count {vc} exceeds u16 max (65535) — sim mesh "
            f"too large for MCD physics index format")
    idx = bytearray(vc * 2)                                           # sequential u16s
    for i in range(vc):
        struct.pack_into('<H', idx, i * 2, i)
    buf.extend(idx)
    buf.extend(b'\x00' * 36)                                          # pre-Block1 pad
    buf.extend(struct.pack('<II', 7, vc * 56))                        # Block 1 hdr
    buf.extend(b'\x00' * (vc * 56))                                   # Block 1 data (zeros)
    buf.extend(struct.pack('<I', vc))                                 # arrA hdr
    buf.extend(struct.pack(f'<{vc}f', *([1.0] * vc)))                 # arrA data (1.0 each)
    return bytes(buf)


def _build_inner_mod4_2k26(mesh_count: int, primary_vc: int,
                           slot_vcs: Optional[List[int]] = None) -> bytes:
    """Construct a 2K26 MOD!=4 data payload.

    Two output forms depending on what's known:

    1. HEADER ONLY (slot_vcs is None or empty) — only the outer mini-header
       and simple-remap. This is structurally valid as a TYPE-CHECK but
       lacks per-vertex bind data and per-slot weight arrays. Used as a
       fallback when slot vertex counts cannot be resolved.

    2. RECURSIVE FULL (slot_vcs provided) — the full nested structure
       matching vanilla 2K26 layout:
          - Outer slot 0 (full structure, vc = slot_vcs[0] = primary_vc)
          - Nested slot 1 (full structure, vc = slot_vcs[1]) if mc >= 2
          - Satellite (u32 vc, vc × 1.0f) for slots 2..mc-1 if mc >= 3
          - 16 zero bytes
          - "END!" + 4 zero bytes (8-byte terminator)
       Block 1 per-vertex bind records (vc × 56 bytes) are written as
       zeros — the actual binding format is not yet decoded, so the engine
       will see "no displacement" for each vertex. Per-slot weight arrays
       are filled with 1.0f, matching the vanilla weight range.

    `mesh_count` = HCYW MOD!=1 mesh_count.
    `primary_vc`  = slot_vcs[0] when provided; otherwise the caller's
                    explicit value. Vanilla samples always have
                    primary_vc == HCYW MOD!=1 slot[0] vc.
    """
    # Header-only fallback (legacy v2.6.2 behavior).
    if not slot_vcs:
        buf = bytearray()
        buf.extend(struct.pack('<6I', 0, 1, mesh_count, 0, 0, primary_vc))
        buf.extend(b'\x00' * 36)
        buf.extend(struct.pack('<I', primary_vc))
        if primary_vc > 0xFFFF:
            raise ValueError(
                f"MOD4 vertex count {primary_vc} exceeds u16 max (65535) — "
                f"sim mesh too large for MCD physics index format")
        idx = bytearray(primary_vc * 2)
        for i in range(primary_vc):
            struct.pack_into('<H', idx, i * 2, i)
        buf.extend(idx)
        return bytes(buf)

    # Recursive full synthesis.
    buf = bytearray()
    # Slot 0: outer with mesh_count in header[2] and primary_vc in header[5]
    buf.extend(_build_mod4_per_slot_full(slot_vcs[0], is_outer=True,
                                          mesh_count=mesh_count))
    # Slot 1 (if mc >= 2): nested with vc in header[2] and 0 in header[5]
    if len(slot_vcs) >= 2:
        buf.extend(_build_mod4_per_slot_full(slot_vcs[1], is_outer=False))
    # Slots 2+: satellite weight arrays only (no full sub-structure)
    for vc in slot_vcs[2:]:
        buf.extend(struct.pack('<I', vc))
        buf.extend(struct.pack(f'<{vc}f', *([1.0] * vc)))
    # Tail: 16 zero pad + END! + 4 zero bytes
    buf.extend(b'\x00' * 16)
    buf.extend(b'END!')
    buf.extend(b'\x00' * 4)
    return bytes(buf)


def patch_substream_fix_inner_mod4(blob: bytes,
                                   primary_vc_override: Optional[int] = None,
                                   mesh_count_override: Optional[int] = None,
                                   slot_vcs_override: Optional[List[int]] = None,
                                   ) -> bytes:
    """Detect a legacy 2K24-format inner-pass MOD!=4 and replace it with a
    fresh 2K26 simple-remap payload.

    The inner-pass MOD!=4 is identified as the first MOD!=4 marker found
    AFTER the bone-tree MOD!=2 (HYWA / OYWA always; HCYW / OCYW don't
    carry MOD!=4 at all and are silently skipped here).

    Mini-header values are looked up in this order:
        1. Explicit overrides (used when caller has cross-substream info —
           HYWA / OYWA need HCYW / OCYW's MOD!=1 fields because HYWA /
           OYWA carry only collider-declaration MOD!=1, not cloth-mesh).
        2. Outer MOD!=1 in this blob (HCYW / OCYW path — they don't have
           MOD!=4 anyway, so this fallback is mostly defensive).

    If neither path produces usable values, the function no-ops rather
    than rewriting with bad data.
    """
    if len(blob) < 16:
        return blob

    result = bytearray(blob)
    mods = _find_mod_positions(result, 8, len(result))

    # Identify the bone-tree MOD!=2.
    bone_tree_off = None
    for off, mid in mods:
        if mid == 2 and _is_bone_tree_mod2(result, off):
            bone_tree_off = off
            break
    if bone_tree_off is None:
        return bytes(result)  # No bone tree → no inner-pass MOD!=4 to fix

    # Inner-pass MOD!=4 = first MOD!=4 after the bone tree.
    inner_mod4_off = None
    for off, mid in mods:
        if mid == 4 and off > bone_tree_off:
            inner_mod4_off = off
            break
    if inner_mod4_off is None:
        return bytes(result)

    # Already modern? No-op.
    if _is_modern_inner_mod4(result, inner_mod4_off):
        return bytes(result)

    # Resolve values. Prefer explicit overrides; otherwise the in-blob
    # MOD!=1 — which gives the right answer for HCYW/OCYW (cloth mesh
    # table) but the wrong answer for HYWA/OYWA (collider mesh table).
    # HYWA/OYWA callers MUST pass overrides.
    mesh_count = mesh_count_override
    primary_vc = primary_vc_override
    if mesh_count is None or primary_vc is None:
        mod1_off = next((off for off, mid in mods if mid == 1), None)
        if mod1_off is not None and mod1_off + 0x50 + 32 + 12 <= len(result):
            in_mc = struct.unpack_from('<I', result, mod1_off + 0x4C)[0]
            # MOD!=1 record layout: mesh_count (4B) + mesh_count × 32B
            # names + record_count (4B) + record_count × 12B (idx, off,
            # count). slot[0]'s record is at mod1_off+0x4C + 4 + 32*mc + 4.
            recs_off = mod1_off + 0x4C + 4 + 32 * in_mc + 4
            if recs_off + 12 <= len(result):
                _, _, slot0_count = struct.unpack_from(
                    '<III', result, recs_off)
                if mesh_count is None:
                    mesh_count = in_mc
                if primary_vc is None:
                    primary_vc = slot0_count
    if not (0 < (mesh_count or 0) <= 256) or not (0 < (primary_vc or 0) < 1_000_000):
        return bytes(result)

    # Current MOD!=4 payload extent.
    data_start = inner_mod4_off + 0x48
    next_marker = len(result)
    for off, mid in mods:
        if off > inner_mod4_off:
            next_marker = off
            break
    old_payload_size = next_marker - data_start

    new_payload = _build_inner_mod4_2k26(mesh_count, primary_vc,
                                         slot_vcs=slot_vcs_override)
    result[data_start:next_marker] = new_payload
    _patch_outer_size(result)

    kind = "recursive-full" if slot_vcs_override else "header-only"
    dlog(f"[Physics Updater] InnerMOD4Fix: rewrote inner-pass MOD!=4 to "
         f"2K26 {kind} format (mesh_count={mesh_count}, "
         f"primary_vc={primary_vc}, slot_vcs={slot_vcs_override}); "
         f"payload {old_payload_size:,} → {len(new_payload):,} bytes")
    return bytes(result)


def _read_mod2_collider_table(data: bytes, mod2_off: int) -> Optional[Tuple[int, List[Tuple[str, int, int]]]]:
    """Parse a MOD2 collider-reference body (HCYW/OCYW format).

    Verified layout from raw byte inspection of vanilla 2K26 (Asuka 621):
        +0x00 (data start, = mod2_off + 0x4C):
            u32 mesh_count
        +0x04..+0x04+32*mesh_count:
            char[32] names ...
        After names:
            u32 record_count (typically = mesh_count)
            record_count × 12-byte entry: { u32 slot_idx; u32 zero; u32 vert_count }
        Then 8 bytes of trailing padding to the next MOD! marker.

    Returns (mesh_count, [(name, vert_count, slot_idx), ...]) or None.
    """
    body_start = mod2_off + 0x4C
    if body_start + 4 > len(data):
        return None
    mesh_count = struct.unpack_from('<I', data, body_start)[0]
    if mesh_count == 0 or mesh_count > 16:
        return None

    p = body_start + 4
    names = []
    for _ in range(mesh_count):
        if p + 32 > len(data):
            return None
        names.append(data[p:p + 32].split(b'\x00')[0].decode('ascii', errors='replace'))
        p += 32

    if p + 4 > len(data):
        return None
    record_count = struct.unpack_from('<I', data, p)[0]
    if record_count == 0 or record_count > 16:
        return None
    p += 4

    out = []
    for i in range(min(record_count, mesh_count)):
        if p + 12 > len(data):
            return None
        slot_idx   = struct.unpack_from('<I', data, p + 0)[0]
        vert_count = struct.unpack_from('<I', data, p + 8)[0]
        out.append((names[i], vert_count, slot_idx))
        p += 12
    return mesh_count, out


def _set_mod2_collider_vert_count(buf: bytearray, mod2_off: int,
                                  mesh_index: int, mesh_count_total: int,
                                  new_count: int) -> bool:
    """Write a new vert_count into the entry at mesh_index. Caller must
    pass the table's total mesh_count so we can locate the entry past the
    name array and the record_count u32."""
    body_start = mod2_off + 0x4C
    names_end  = body_start + 4 + 32 * mesh_count_total
    records_start = names_end + 4    # skip record_count u32
    entry_off  = records_start + mesh_index * 12
    vc_off     = entry_off + 8
    if vc_off + 4 > len(buf):
        return False
    struct.pack_into('<I', buf, vc_off, new_count)
    return True


def _refresh_mod2_collider_counts(buf: bytearray, mod2_off: int, scene_meshes) -> int:
    """Refresh MOD2 collider entry vert counts (M_Head/M_Body) from scene."""
    parsed = _read_mod2_collider_table(buf, mod2_off)
    if parsed is None:
        return 0
    mesh_count_total, entries = parsed
    updated = 0
    for i, (name, donor_vc, _field_a) in enumerate(entries):
        scene_mesh = get_scene_mesh_by_name(scene_meshes, name)
        if not scene_mesh:
            continue
        scene_vc = _vertex_count(scene_mesh)
        if scene_vc <= 0 or scene_vc == donor_vc:
            continue
        if _set_mod2_collider_vert_count(buf, mod2_off, i, mesh_count_total, scene_vc):
            dlog(f"[Physics Updater]   MOD2 {name}: vert count {donor_vc} → {scene_vc}")
            updated += 1
    return updated


def _get_collider(scene_meshes,
                  donor_colliders: Optional[Dict[str, Tuple[list, list]]] = None,
                  name: str = 'M_Head') -> Tuple[Optional[list], Optional[list]]:
    """Resolve `name` mesh's verts + triangles. Tries scene first; falls back
    to donor_colliders if the scene doesn't have it. Returns normalized
    (verts as 3-tuples, tris as 3-tuples) or (None, None) — handles both the
    DLL-loaded shape (Vector list / tuple list) and the Blender export shape
    (flat float list / flat int list)."""
    mesh = get_scene_mesh_by_name(scene_meshes, name)
    # v2.3.1: mesh.vertices / .index_list may be a numpy ndarray (DLL-load
    # shape) OR a Python list (export-side scene build). Bare truthiness is
    # ambiguous on numpy non-scalars; use explicit None + length checks.
    if (mesh is not None
            and mesh.vertices is not None and len(mesh.vertices) > 0
            and mesh.index_list is not None and len(mesh.index_list) > 0):
        return _normalize_verts(mesh.vertices), _normalize_tris(mesh.index_list)
    if donor_colliders and name in donor_colliders:
        verts, tris = donor_colliders[name]
        if verts and tris:
            return _normalize_verts(verts), _normalize_tris(tris)
    return None, None


def _get_proxy_mesh(scene_meshes,
                    donor_colliders: Optional[Dict[str, Tuple[list, list]]] = None):
    """Like _get_collider but for M_Combinations. Returns an object with
    .vertices and (optional) .index_list, or None. The donor fallback is
    a simple shim that quacks like vCSkinMesh for the patcher's purposes."""
    proxy = get_scene_mesh_by_name(scene_meshes, 'M_Combinations')
    # ndarray-safe truthiness (see _get_collider above for the rationale).
    if proxy is not None and proxy.vertices is not None and len(proxy.vertices) > 0:
        return proxy
    if donor_colliders and 'M_Combinations' in donor_colliders:
        verts, tris = donor_colliders['M_Combinations']
        if verts:
            class _DonorProxyShim:
                pass
            shim = _DonorProxyShim()
            shim.vertices   = verts
            shim.index_list = tris or []
            shim.mesh_name  = 'M_Combinations'
            return shim
    return None


# ════════════════════════════════════════════════════════════════════════════
#  MOD6 splice helpers — handle records + flag table together
# ════════════════════════════════════════════════════════════════════════════

def _mod6_data_start(mod6_off: int) -> int:
    return mod6_off + 0x48


def _read_mod6_minihdr(data: bytes, mod6_off: int) -> Optional[Tuple[int, int, int]]:
    """Returns (records_off, record_count, mystery_int_at_+0x00)."""
    ds = _mod6_data_start(mod6_off)
    if ds + 0x18 > len(data):
        return None
    mystery     = struct.unpack_from('<I', data, ds + 0x00)[0]
    record_count = struct.unpack_from('<I', data, ds + 0x10)[0]
    if record_count > 1_000_000:
        return None
    return (ds + 0x18, record_count, mystery)


def _update_mod2_collider_vcs(blob: bytes,
                              vc_by_name: Dict[str, int]) -> Tuple[bytes, list]:
    """Update collider vert_count fields wherever they appear in a substream.

    HCYW carries collider declarations under MOD!2 (with MOD!1 = render
    mesh table, MOD!6 = primary records). HYWA flips it: MOD!1 IS the
    collider declaration table and MOD!2 is the bone tree (Hair_b00 /
    Hair_b00_00 / ... entries with a different 40-byte-per-record
    layout). The actual collider data shape is the same in both —
    `mesh_count`, names, `record_count`, 12-byte records — just under
    different MOD ids.

    Rather than hardcode the MOD id (which gets it wrong for HYWA), we
    walk every MOD in the blob, attempt to parse it as a collider
    declaration table, and verify the parse looks well-formed AND the
    name list contains at least one of the target collider names from
    `vc_by_name`. Only then do we update vc fields. Bone-tree MODs and
    render-mesh MODs are filtered out by the name check.

    `vc_by_name` is e.g. {'M_Head': 4310, 'M_Body': 12699}. Returns the
    mutated blob plus a list of (mesh_name, old_vc, new_vc) tuples for
    every record that changed across all MODs in the blob.

    Function name kept as `_update_mod2_collider_vcs` for backward
    compatibility with existing call sites; despite the name it now
    handles HYWA's MOD1 case too.
    """
    if not vc_by_name:
        return blob, []
    buf = bytearray(blob)
    target_names = set(vc_by_name.keys())

    # Find every MOD! in the blob. Scan in 4-byte alignment because
    # record streams between MODs are 4-aligned and MOD! tags only
    # appear on aligned boundaries.
    mod_offsets = []
    scan = 0
    while scan < len(buf) - 8:
        if buf[scan:scan+4] == b'MOD!':
            mod_offsets.append(scan)
        scan += 4

    all_changes: list = []
    for mod_off in mod_offsets:
        # Try parsing this MOD as a collider table. Layout:
        #   +0x4C u32 mesh_count
        #   then mesh_count × 32-byte ASCII names
        #   then u32 record_count
        #   then record_count × 12-byte records {slot_idx, zero, vc}
        # Reject the MOD if any field is implausible.
        p = mod_off + 0x4C
        if p + 4 > len(buf):
            continue
        mc = struct.unpack_from('<I', buf, p)[0]
        if mc == 0 or mc > 100:
            continue
        p += 4
        if p + mc * 32 > len(buf):
            continue
        names = []
        ok = True
        for _ in range(mc):
            name_bytes = buf[p:p+32]
            # Reject if first byte isn't printable ASCII — bone-tree MOD!2
            # in HYWA has a 4-byte id field BEFORE the name, so its
            # "name" parse here will start with id bytes (e.g. 0x77)
            # instead of an ASCII letter, and we'll skip the whole MOD.
            first = name_bytes[0]
            if first == 0 or not (32 <= first < 127):
                ok = False
                break
            names.append(name_bytes.split(b'\x00')[0].decode('ascii', errors='replace'))
            p += 32
        if not ok:
            continue
        if p + 4 > len(buf):
            continue
        rc = struct.unpack_from('<I', buf, p)[0]
        if rc == 0 or rc > 100:
            continue
        p += 4
        if p + rc * 12 > len(buf):
            continue

        # Confirm this MOD looks like a collider table by checking that
        # its name set intersects the targets we're updating. Render-
        # mesh MODs (M_Hair, S_Hair, M_Jacket) won't match; collider
        # MODs (M_Head, M_Body) will.
        if not (set(names) & target_names):
            continue

        for k in range(rc):
            rec_off = p + k * 12
            slot = struct.unpack_from('<I', buf, rec_off)[0]
            if slot >= len(names):
                continue
            mesh_name = names[slot]
            if mesh_name not in vc_by_name:
                continue
            old_vc = struct.unpack_from('<I', buf, rec_off + 8)[0]
            new_vc = vc_by_name[mesh_name]
            if old_vc != new_vc:
                struct.pack_into('<I', buf, rec_off + 8, new_vc)
                all_changes.append((mesh_name, old_vc, new_vc))

    return bytes(buf), all_changes


def _splice_mod6_records_and_flags(buf: bytearray, mod6_off: int,
                                   new_records: bytes,
                                   new_record_count: int,
                                   old_record_count: int,
                                   new_mesh_count: Optional[int] = None,
                                   keep_extra_flag_bytes: bool = False) -> int:
    """Splice new primary records into MOD6 AND extend (or shrink) the
    per-vertex flag table that immediately follows them in sub-table 2.

    Layout being modified:
        [mod6 header][primary records (N*12)][flag table (N bytes)][rest of sub2]

    Both the records section and the flag table grow/shrink with N. The
    rest of sub-table 2 (active set, aux arrays, cross-binding) shifts by
    the combined delta. Counts in the mini-header and outer envelope are
    repatched.

    If `keep_extra_flag_bytes` is True, when growing the flag table the
    new bytes are 0xFF (default-binding sentinel). When shrinking, bytes
    are dropped from the end.

    `new_mesh_count`, when supplied, also rewrites mini-header offset 0x04
    (field [1]). This is the count of MOD1 mesh slots — the engine reads
    it to know how many MOD1 entries to walk. Must stay in sync with MOD1
    after pruning or appending; otherwise the engine reads past valid MOD1
    slots into garbage.

    Returns total size delta applied to `buf`.
    """
    ds = _mod6_data_start(mod6_off)
    records_off = ds + 0x18
    old_records_bytes = old_record_count * 12
    new_records_bytes = new_record_count * 12

    flag_table_off_old = records_off + old_records_bytes
    flag_table_old_len = old_record_count
    flag_table_new_len = new_record_count
    sub2_rest_off_old  = flag_table_off_old + flag_table_old_len

    # 1) Record-count fields in mini-header.
    struct.pack_into('<I', buf, ds + 0x10, new_record_count)
    struct.pack_into('<I', buf, ds + 0x14, new_record_count)
    if new_mesh_count is not None:
        struct.pack_into('<I', buf, ds + 0x04, new_mesh_count)

    # 2) Splice records.
    buf[records_off : records_off + old_records_bytes] = new_records

    # After step 2, the flag table currently sits at:
    #   records_off + new_records_bytes
    # but its content is the old bytes (which haven't moved relative to
    # bytearray, only relative to records). Now we need to resize the
    # flag table region.
    flag_table_off_now = records_off + new_records_bytes
    sub2_rest_off_now  = flag_table_off_now + flag_table_old_len

    # 3) Resize flag table.
    if flag_table_new_len > flag_table_old_len:
        # Insert 0xFF bytes after the old flag table.
        extra = flag_table_new_len - flag_table_old_len
        buf[sub2_rest_off_now:sub2_rest_off_now] = b'\xFF' * extra
    elif flag_table_new_len < flag_table_old_len:
        # Drop bytes from the end of the flag table.
        drop = flag_table_old_len - flag_table_new_len
        del buf[flag_table_off_now + flag_table_new_len :
                flag_table_off_now + flag_table_new_len + drop]

    # 4) Patch outer envelope.
    delta = (new_records_bytes - old_records_bytes) + (flag_table_new_len - flag_table_old_len)
    if delta:
        _patch_outer_size(buf)
    return delta


# ════════════════════════════════════════════════════════════════════════════
#  MOD7 helpers (sparse position table)
# ════════════════════════════════════════════════════════════════════════════

def _read_mod7_minihdr(data: bytes, mod7_off: int) -> Optional[Tuple[int, int]]:
    data_start = mod7_off + 0x4C
    if data_start + 0x1C > len(data):
        return None
    count = struct.unpack_from('<I', data, data_start + 0x08)[0]
    if count > 1_000_000:
        return None
    return (data_start + 0x1C, count)


def _replace_mod7_records(buf: bytearray, mod7_off: int,
                          new_records: bytes,
                          new_count: int,
                          old_count: int) -> int:
    data_start = mod7_off + 0x4C
    records_off = data_start + 0x1C
    old_byte_len = old_count * 16
    delta = (new_count * 16) - old_byte_len
    struct.pack_into('<I', buf, data_start + 0x08, new_count)
    struct.pack_into('<I', buf, data_start + 0x18, new_count)
    buf[records_off : records_off + old_byte_len] = new_records
    if delta:
        _patch_outer_size(buf)
    return delta


# ════════════════════════════════════════════════════════════════════════════
#  HCYW — patch existing slots, append records for new sim chains
# ════════════════════════════════════════════════════════════════════════════

def patch_hcyw_template(hcyw_blob: bytes, scene_meshes,
                        scene_sim_meshes: Dict[str, int],
                        donor_colliders: Optional[Dict[str, Tuple[list, list]]] = None
                        ) -> bytes:
    """HCYW patch path. Updates MOD1 sim slots, refreshes MOD2 collider
    counts, and APPENDS MOD6 records for any new render-mesh slots that
    the donor didn't have records for (jackets, tassels, extra hair
    chains)."""
    # Version stamp — if you're running this and DON'T see it in the
    # console after an export, your runtime has a stale physics_patcher
    # (Blender .pyc cache or addon dir mix-up). Wipe `__pycache__/` and
    # re-install.
    dlog(f"[Physics Updater] patch_hcyw_template ENTER "
         f"({_PHYSICS_PATCHER_VERSION}, {len(scene_meshes)} scene meshes, "
         f"{len(scene_sim_meshes)} sim chains, "
         f"{len(donor_colliders or {})} donor colliders)")

    if len(hcyw_blob) < 16:
        return hcyw_blob

    result = bytearray(hcyw_blob)
    mods = _find_mod_positions(result, 16, len(result))
    mod1_off = next((o for o, m in mods if m == 1), None)
    mod2_off = next((o for o, m in mods if m == 2), None)
    mod6_off = next((o for o, m in mods if m == 6), None)

    # ── MOD2 collider vert counts (M_Head / M_Body) ──
    if mod2_off is not None:
        n = _refresh_mod2_collider_counts(result, mod2_off, scene_meshes)
        if n:
            dlog(f"[Physics Updater] HCYW: refreshed {n} MOD2 collider count(s)")

    if mod1_off is None:
        return bytes(result)

    donor_names, donor_records = _read_mod1(result, mod1_off)
    if not donor_names:
        return bytes(result)

    # ── Capture donor's existing MOD6 record count BEFORE any MOD1 change.
    donor_record_count = 0
    if mod6_off is not None:
        info = _read_mod6_minihdr(result, mod6_off)
        if info is not None:
            _, donor_record_count, _ = info

    # Donor's MOD1 mesh_count — the splice path compares against the
    # final new_names count to decide whether mini-header field [1]
    # needs rewriting.
    mc_donor = len(donor_names)

    # ── Build new MOD1 lists (update existing + append scene-new pairs) ──
    new_names   = list(donor_names)
    new_records = list(donor_records)
    donor_set   = set(donor_names)
    matched = appended_mod1 = pruned = 0

    # Pass 0 — prune donor MOD1 entries stale vs the current scene (user swapped
    # M_Jacket1 → M_Jacket2 across re-imports; the old donor still carries
    # M_Jacket1, so without pruning both chains persist and the second behaves
    # erratically). A slot is orphan when (a) no scene mesh matches it directly
    # AND (b) it doesn't share a root with an in-scene base (i.e. it's not a
    # render-alternate like M_Hair_ENT of an in-scene M_Hair). Render alternates
    # stay — driven by the engine's render-pass system, not scene meshes.
    scene_roots_with_M = {
        _pair_root(n) for n in scene_sim_meshes if n.startswith('M_')
    }

    def _is_alt_of_scene_base(name: str) -> bool:
        """Check whether `name` is M_<root>_<suffix> or S_<root>_<suffix>
        where <root> matches a scene base (M_<root> in scene)."""
        if not (name.startswith('M_') or name.startswith('S_')):
            return False
        # Strip prefix; remaining must contain a separator.
        body = name[2:]
        if '_' not in body:
            return False
        # Try every prefix split — the longest matching base wins.
        for cut in range(len(body) - 1, 0, -1):
            if body[cut] == '_':
                root_candidate = body[:cut]
                if root_candidate in scene_roots_with_M:
                    return True
        return False

    keep_indices = []
    for i, dname in enumerate(donor_names):
        if dname in scene_sim_meshes:
            keep_indices.append(i)
        elif _is_alt_of_scene_base(dname):
            keep_indices.append(i)
        else:
            pruned += 1
            dlog(f"[Physics Updater] HCYW: pruning orphan slot[{i}] '{dname}' "
                 f"— not in scene and no in-scene base shares its root")

    if pruned > 0:
        # Remap each kept record's idx into the post-prune names array. Donor
        # idx values index donor_names; after dropping slots they'd point at the
        # wrong name (silent corruption) or past the end (engine reads OOB on
        # init, rejects the substream → broke match-mode collision while
        # cutscenes, which don't use idx for dispatch, kept working).
        old_to_new_idx = {old_i: new_i for new_i, old_i in enumerate(keep_indices)}
        new_names = [donor_names[i] for i in keep_indices]
        new_records = []
        for new_i, old_i in enumerate(keep_indices):
            old_idx, old_off, old_vc = donor_records[old_i]
            # Common case: record's idx equals its own slot position
            # (vanilla layout). Edge case: record idx points elsewhere
            # (shared-name pattern). Try the remap; fall back to the
            # record's own new position if the original target got
            # pruned out from under it.
            new_idx = old_to_new_idx.get(old_idx, new_i)
            new_records.append((new_idx, old_off, old_vc))
        donor_set = set(new_names)
        # Slot[0] identity may have changed if the previous slot[0] got
        # pruned. Re-sync slot0_mesh_name (used below).
        slot0_mesh_name = new_names[0] if new_names else None
    else:
        slot0_mesh_name = donor_names[0] if donor_names else None

    # Pass 1 — update existing slot vert counts. ALSO detect whether
    # slot[0]'s render mesh vert count differs from MOD6's record count;
    # if so, the donor's records are bound to topology that no longer
    # matches the scene (typical port-from-older-game scenario where the
    # source's render mesh has different vert count than the donor's),
    # and we must regenerate slot[0]'s records from scratch against
    # scene geometry.
    slot0_topology_mismatch = False
    for i, dname in enumerate(new_names):
        if dname in scene_sim_meshes:
            idx, off, donor_vc = new_records[i]
            scene_vc = scene_sim_meshes[dname]
            if scene_vc != donor_vc:
                new_records[i] = (idx, off, scene_vc)
                # MOD6 records bind slot[0]'s render mesh — if its count
                # changed, records are now wrong and we need to recompute.
                if i == 0 and donor_record_count > 0:
                    slot0_topology_mismatch = True
                    dlog(f"[Physics Updater] HCYW: slot[0] '{dname}' vert "
                         f"count {donor_vc} → {scene_vc} (donor MOD6 has "
                         f"{donor_record_count} records, will recompute)")
            matched += 1
    # If pruning changed slot[0] identity OR slot[0] survived but isn't
    # in the scene as a real mesh, force a slot[0] recompute. This is
    # the natural place to repaint records onto whatever's actually
    # present in the scene now.
    if (slot0_mesh_name and slot0_mesh_name not in scene_sim_meshes
            and donor_record_count > 0):
        # Couldn't infer a scene mesh for slot[0]. Fall back to the first
        # M_-prefixed scene mesh, if any, as the binding target.
        m_meshes = [n for n in scene_sim_meshes if n.startswith('M_')]
        if m_meshes:
            fallback = m_meshes[0]
            scene_vc = scene_sim_meshes[fallback]
            dlog(f"[Physics Updater] HCYW: slot[0] '{slot0_mesh_name}' "
                 f"absent from scene; will rebind records to '{fallback}' "
                 f"({scene_vc} verts) — port-style fallback")
            # Rename slot[0] in MOD1 so the engine knows what to look up.
            new_names[0] = fallback
            new_records[0] = (new_records[0][0], new_records[0][1], scene_vc)
            slot0_mesh_name = fallback
            slot0_topology_mismatch = True
            donor_set.add(fallback)

    # Pass 2 — append slots for scene pairs the donor doesn't have.
    new_render_meshes_to_synth: List[str] = []  # M_X names that need fresh records
    seen_roots: Set[str] = set()
    for sname in scene_sim_meshes:
        if sname in donor_set:
            continue
        root = _pair_root(sname)
        if root in seen_roots:
            continue
        seen_roots.add(root)
        for n in (f"M_{root}", f"S_{root}"):
            if n in scene_sim_meshes and n not in donor_set:
                new_names.append(n)
                # idx MUST point at this name's array position (len-1).
                # Hardcoding 0 (the old behaviour) made every appended slot
                # claim name[0] (M_Hair), so the engine saw contradictory
                # off/vc for the same name and rejected the chain on init
                # (broke match-mode cloth collision; cutscenes don't walk
                # MOD1 records this way).
                new_idx = len(new_names) - 1
                # off field will be patched after we know record offsets
                new_records.append((new_idx, 0, scene_sim_meshes[n]))
                donor_set.add(n)
                appended_mod1 += 1
                if n.startswith('M_'):
                    new_render_meshes_to_synth.append(n)

    # ── Resolve colliders (M_Head / M_Body) from scene + donor ──
    head_verts, head_tris = _get_collider(scene_meshes, donor_colliders, 'M_Head')
    body_verts, body_tris = _get_collider(scene_meshes, donor_colliders, 'M_Body')
    head_available = bool(head_verts and head_tris)
    body_available = bool(body_verts and body_tris)
    # Status log — fires unconditionally so the user sees collider state
    # whether records get recomputed for slot[0] only, additionals only,
    # or both.
    if head_available:
        head_src = "scene" if get_scene_mesh_by_name(scene_meshes, 'M_Head') else "donor"
        body_src = ("scene" if get_scene_mesh_by_name(scene_meshes, 'M_Body')
                    else "donor" if body_available else "absent")
        dlog(f"[Physics Updater] HCYW: colliders available — "
             f"M_Head from {head_src} ({len(head_verts)} verts, "
             f"{len(head_tris)} tris), M_Body {body_src}"
             + (f" ({len(body_verts)} verts, {len(body_tris)} tris)"
                if body_available else " (degraded — body-hugging meshes "
                                       "will bind to head only)"))
    else:
        dlog(f"[Physics Updater] HCYW: NO COLLIDER GEOMETRY AVAILABLE "
             f"(neither scene nor donor supplied M_Head/M_Body). "
             f"All MOD6 records will be PLACEHOLDERS — physics will be wrong "
             f"in-game. Drop a baseModel.mcd next to the donor file.")

    extra_records_buf = bytearray()
    extra_record_count = 0
    cumulative_off = donor_record_count  # new records start after donor's

    # Track per-slot record offsets so we can write `off` into MOD1 records.
    # Donor slot off = 0 (engine reads from start of MOD6 records).
    # New slot off = cumulative_off at the time the slot is added.
    name_to_off: Dict[str, int] = {}
    name_to_count: Dict[str, int] = {n: c for n, _, c in
                                     ((nm, 0, sz) for nm, sz in
                                      ((nm, scene_sim_meshes.get(nm, 0))
                                       for nm in new_render_meshes_to_synth))}

    for mname in new_render_meshes_to_synth:
        render = get_scene_mesh_by_name(scene_meshes, mname)
        if not render or not render.vertices:
            continue
        vc = _vert_count(render.vertices)
        if head_available:
            recs, fallback, slot1 = _build_primary_records(
                start_idx=cumulative_off,
                render_verts=render.vertices,
                head_verts=head_verts, head_tris=head_tris,
                body_verts=body_verts, body_tris=body_tris,
                vert_remap=getattr(render, 'vertex_remap', None),
            )
        else:
            recs = _build_placeholder_records(
                start_idx=cumulative_off,
                num_verts=vc,
                vert_remap=getattr(render, 'vertex_remap', None),
            )
            fallback = vc
            slot1 = 0
        if not recs:
            continue
        extra_records_buf.extend(recs)
        name_to_off[mname] = cumulative_off
        cumulative_off += vc
        extra_record_count += vc
        if head_available:
            if fallback:
                dlog(f"[Physics Updater] HCYW: {mname} {fallback} verts fell back "
                     f"to triangle-0 (no nearest found)")
            if slot1:
                dlog(f"[Physics Updater] HCYW: {mname} {slot1}/{vc} verts bound "
                     f"to M_Body (slot 1), rest to M_Head (slot 0)")
        else:
            dlog(f"[Physics Updater] HCYW: {mname} placeholder records written "
                 f"({vc} verts bound to M_Head triangle 0)")
        if getattr(render, 'vertex_remap', None):
            dlog(f"[Physics Updater] HCYW: {mname} records used vertex remap "
                 f"({len(render.vertex_remap)} entries) — vert_idx values "
                 f"written in MCD-side index space")

    # ── Slot-0 record recompute (port scenario) ──
    # If donor slot[0]'s render mesh has different topology than what's
    # in the scene, donor records are bound to the wrong vert space and
    # we have to regenerate them. The new record count = scene's
    # slot[0] vert count, and each record binds via dual-collider.
    slot0_recomputed_bytes = b''
    slot0_new_record_count = 0
    if slot0_topology_mismatch and slot0_mesh_name:
        slot0_render = get_scene_mesh_by_name(scene_meshes, slot0_mesh_name)
        if slot0_render and slot0_render.vertices and head_verts and head_tris:
            recs, fallback, slot1 = _build_primary_records(
                start_idx=0,
                render_verts=slot0_render.vertices,
                head_verts=head_verts, head_tris=head_tris,
                body_verts=body_verts, body_tris=body_tris,
                vert_remap=getattr(slot0_render, 'vertex_remap', None),
            )
            slot0_recomputed_bytes = recs
            slot0_new_record_count = _vert_count(slot0_render.vertices)
            dlog(f"[Physics Updater] HCYW: slot[0] '{slot0_mesh_name}' "
                 f"records recomputed ({donor_record_count} → "
                 f"{slot0_new_record_count}), fallbacks={fallback}, "
                 f"M_Body bindings={slot1}")
            if getattr(slot0_render, 'vertex_remap', None):
                dlog(f"[Physics Updater] HCYW: slot[0] records used vertex remap "
                     f"({len(slot0_render.vertex_remap)} entries) — vert_idx "
                     f"values written in MCD-side index space")

            # Render-alternate variants (M_X_ENT, M_X_CS_noMask, etc.) share
            # MOD6 records with slot[0] because they're alternate render
            # passes of the same geometry. If slot[0] now has 5218 verts
            # but the alternates' MOD1 entries still claim 11012 from the
            # donor, the engine reads past the actual vert buffer. Force
            # the alternates to match slot[0]'s count so the engine's
            # record-replay walks valid index ranges.
            base_name = slot0_mesh_name
            for i in range(1, len(new_names)):
                nm = new_names[i]
                # Match alternates: same base name with a suffix
                # (M_Hair → M_Hair_ENT / M_Hair_CS_noMask) AND not already
                # represented in the scene (don't override real scene meshes).
                if (nm != base_name
                        and nm.startswith(base_name + '_')
                        and nm not in scene_sim_meshes):
                    idx, off, donor_alt_vc = new_records[i]
                    if donor_alt_vc != slot0_new_record_count:
                        new_records[i] = (idx, off, slot0_new_record_count)
                        dlog(f"[Physics Updater] HCYW: render-alt slot[{i}] "
                             f"'{nm}' vert count {donor_alt_vc} → "
                             f"{slot0_new_record_count} (matches recomputed slot[0])")
        else:
            # Real recompute failed — render mesh missing OR no head
            # collider geometry available (typical port: scene without
            # baseModel head/body, donor loaded via sidecar/directory
            # mode that didn't harvest a CSkinModel for colliders).
            # Fall back to placeholder records so MOD1 and MOD6 stay
            # internally consistent. Physics will be wrong (everything
            # bound to M_Head triangle 0) but the file's structurally
            # valid and the engine won't trip on a count mismatch.
            slot0_render = get_scene_mesh_by_name(scene_meshes, slot0_mesh_name)
            if slot0_render and slot0_render.vertices:
                placeholder = _build_placeholder_records(
                    start_idx=0,
                    num_verts=_vert_count(slot0_render.vertices),
                    vert_remap=getattr(slot0_render, 'vertex_remap', None),
                )
                slot0_recomputed_bytes = placeholder
                slot0_new_record_count = _vert_count(slot0_render.vertices)
                dlog(f"[Physics Updater] HCYW: slot[0] '{slot0_mesh_name}' "
                     f"PLACEHOLDER records written ({donor_record_count} → "
                     f"{slot0_new_record_count}) — collider geometry "
                     f"unavailable. File is structurally valid; physics "
                     f"will be wrong. Re-export with a 2K26 single-MCD "
                     f"donor (loads M_Head/M_Body) for real bindings.")
                # Keep render-alternate vert counts in sync with slot[0]
                # — same logic as the real-recompute branch above.
                base_name = slot0_mesh_name
                for i in range(1, len(new_names)):
                    nm = new_names[i]
                    if (nm != base_name
                            and nm.startswith(base_name + '_')
                            and nm not in scene_sim_meshes):
                        idx, off, donor_alt_vc = new_records[i]
                        if donor_alt_vc != slot0_new_record_count:
                            new_records[i] = (idx, off, slot0_new_record_count)
            else:
                # Genuinely nothing to bind — donor records stay, MOD1
                # mesh_count fix below will still apply.
                dlog(f"[Physics Updater] HCYW: slot[0] '{slot0_mesh_name}' "
                     f"render mesh has no vertices — leaving donor records, "
                     f"file may be inconsistent")
                slot0_topology_mismatch = False  # downgrade splice path

    # Write back MOD1 — patch new slot records' off fields.
    # New slots' offsets need to account for slot[0]'s new size if recomputed.
    if slot0_topology_mismatch and slot0_new_record_count > 0:
        # New slots come AFTER the recomputed slot[0]'s records.
        offset_base_for_new_slots = slot0_new_record_count
        # Rebuild name_to_off using the correct base.
        name_to_off = {}
        running = offset_base_for_new_slots
        for mname in new_render_meshes_to_synth:
            render = get_scene_mesh_by_name(scene_meshes, mname)
            if render and render.vertices:
                name_to_off[mname] = running
                running += _vert_count(render.vertices)
    for i in range(len(new_names)):
        nm = new_names[i]
        if nm in name_to_off:
            idx, _old_off, sz = new_records[i]
            new_records[i] = (idx, name_to_off[nm], sz)

    old_data = _write_mod1_data(donor_names, donor_records)
    new_data = _write_mod1_data(new_names,   new_records)
    data_start = mod1_off + 0x4C
    data_end   = data_start + len(old_data)
    delta_mod1 = len(new_data) - len(old_data)
    result[data_start:data_end] = new_data
    if delta_mod1:
        _patch_outer_size(result)
        if mod6_off is not None and mod6_off > mod1_off:
            mod6_off += delta_mod1

    # ── Splice records + mini-header into MOD6 ──
    # Cases:
    #   (a) slot[0] recompute (real or placeholder) + maybe additionals →
    #       replace ALL records with (recomputed slot[0]) + (additionals)
    #   (b) additionals only (slot[0] passthrough) → append additionals
    #       after donor's records, keep donor's record block
    #   (c) MOD1 mesh_count changed but records didn't → still need to
    #       sync mini-header field [1] so engine reads the right number
    #       of MOD1 slots
    #   (d) nothing changed → no splice needed
    new_mesh_count = len(new_names)
    mesh_count_changed = (new_mesh_count != mc_donor)
    if mod6_off is not None:
        info = _read_mod6_minihdr(result, mod6_off)
        if info is not None:
            _records_off, old_record_count, _mystery = info
            ds = _mod6_data_start(mod6_off)

            if slot0_topology_mismatch and slot0_new_record_count > 0:
                # Case (a): slot[0] fully recomputed.
                combined = slot0_recomputed_bytes + bytes(extra_records_buf)
                new_total_count = slot0_new_record_count + extra_record_count
                _splice_mod6_records_and_flags(
                    result, mod6_off,
                    new_records=combined,
                    new_record_count=new_total_count,
                    old_record_count=old_record_count,
                    new_mesh_count=new_mesh_count,
                )
                dlog(f"[Physics Updater] HCYW: MOD6 fully rebuilt — "
                     f"slot[0]={slot0_new_record_count} recomputed + "
                     f"{extra_record_count} additionals = "
                     f"{new_total_count} records (was {old_record_count}); "
                     f"mesh_count {mc_donor} → {new_mesh_count}")
            elif extra_record_count > 0:
                # Case (b): preserve donor's records, append additionals.
                donor_records_bytes = bytes(
                    result[ds + 0x18 : ds + 0x18 + old_record_count * 12])
                combined = donor_records_bytes + bytes(extra_records_buf)
                new_total_count = old_record_count + extra_record_count
                _splice_mod6_records_and_flags(
                    result, mod6_off,
                    new_records=combined,
                    new_record_count=new_total_count,
                    old_record_count=old_record_count,
                    new_mesh_count=new_mesh_count,
                )
                dlog(f"[Physics Updater] HCYW: appended {extra_record_count} "
                     f"records ({old_record_count} → {new_total_count}); "
                     f"mesh_count {mc_donor} → {new_mesh_count}")
            elif mesh_count_changed:
                # Case (c): only the MOD1 slot count changed (e.g. orphan
                # pruning with no scene additionals). Sync mini-header.
                struct.pack_into('<I', result, ds + 0x04, new_mesh_count)
                dlog(f"[Physics Updater] HCYW: MOD6 mini-header mesh_count "
                     f"{mc_donor} → {new_mesh_count} (records unchanged)")
            # Case (d): everything matches — no MOD6 write needed.

    dlog(f"[Physics Updater] HCYW: MOD1 pruned {pruned}, matched {matched}, "
         f"appended {appended_mod1}, synthesized {extra_record_count} records")

    # Reconcile MOD2 collider vc with the geometry we bound against. If scene
    # M_Head/M_Body has more verts than the donor's MOD2 declared (common after
    # caruncle/HPL UV-seam splits), MOD6 records reference indices past the
    # declared vc → engine reads OOB / skips bindings (cloth clips through
    # head/body). Updating MOD2 to the real size makes the file consistent,
    # provided the runtime baseModel has ≥ that many collider verts.
    result_bytes = bytes(result)
    vc_by_name = {}
    if head_verts:
        vc_by_name['M_Head'] = len(head_verts)
    if body_verts:
        vc_by_name['M_Body'] = len(body_verts)
    if vc_by_name:
        result_bytes, vc_changes = _update_mod2_collider_vcs(result_bytes, vc_by_name)
        for mesh_name, old_vc, new_vc in vc_changes:
            dlog(f"[Physics Updater] HCYW: MOD2 {mesh_name} vc {old_vc} → "
                 f"{new_vc} (matches scene-side collider size; ensure runtime "
                 f"baseModel has {new_vc}-vert {mesh_name})")
    return result_bytes


# ════════════════════════════════════════════════════════════════════════════
#  OCYW — full recompute against scene geometry
# ════════════════════════════════════════════════════════════════════════════

def recompute_ocyw_blob(donor_blob: bytes, scene_meshes,
                        donor_colliders: Optional[Dict[str, Tuple[list, list]]] = None
                        ) -> bytes:
    """Rebuild OCYW from the donor template against scene geometry.

    Falls back to `donor_colliders['M_Head']` and `donor_colliders['M_Combinations']`
    when the scene doesn't contain those meshes (typical case when the user
    is exporting just an attire without the baseModel head/body in scene).

    1) MOD1 vert count → scene M_Combinations (or donor's if scene-less)
    2) MOD2 collider vert counts → scene M_Head / M_Body (refresh only)
    3) MOD6 primary records → recomputed against M_Head triangle topology
    4) MOD6 flag table → resized to match new record count
    5) MOD7 sparse positions → one per M_Combinations vert
    """
    proxy = _get_proxy_mesh(scene_meshes, donor_colliders)
    head_verts, head_tris = _get_collider(scene_meshes, donor_colliders, 'M_Head')
    body_verts, body_tris = _get_collider(scene_meshes, donor_colliders, 'M_Body')

    if not proxy or not proxy.vertices:
        dlog(f"[Physics Updater] OCYW recompute skipped — no M_Combinations in scene or donor")
        return donor_blob
    if not head_verts or not head_tris:
        dlog(f"[Physics Updater] OCYW recompute skipped — no M_Head geometry in scene or donor")
        return donor_blob

    # Log when using donor fallback so the user knows.
    if donor_colliders:
        if not get_scene_mesh_by_name(scene_meshes, 'M_Head') and 'M_Head' in donor_colliders:
            dlog(f"[Physics Updater] OCYW: using donor M_Head as collider "
                 f"({_vert_count(head_verts)} verts, {len(head_tris)} tris)")
        if not get_scene_mesh_by_name(scene_meshes, 'M_Combinations') and 'M_Combinations' in donor_colliders:
            dlog(f"[Physics Updater] OCYW: using donor M_Combinations as proxy "
                 f"({_vert_count(proxy.vertices)} verts)")
        if not get_scene_mesh_by_name(scene_meshes, 'M_Body') and 'M_Body' in donor_colliders:
            dlog(f"[Physics Updater] OCYW: using donor M_Body as collider "
                 f"({_vert_count(body_verts)} verts, {len(body_tris)} tris)")
    if not (body_verts and body_tris):
        dlog(f"[Physics Updater] OCYW: M_Body not available — binding to M_Head only "
             f"(degraded geometry — M_Combinations is a body proxy, M_Body is normally "
             f"the closer collider for most of its verts)")

    # Normalize before counting / iterating. proxy.vertices may be flat
    # floats (Blender export path when M_Combinations is in the export
    # selection — rare) or Vector list (donor-loaded path — common).
    proxy_verts = _normalize_verts(proxy.vertices)
    proxy_count = len(proxy_verts)
    proxy_remap = getattr(proxy, 'vertex_remap', None)

    # ── Compute MOD6 records ──
    new_records_bytes, fail_count, slot1_count = _build_primary_records(
        start_idx=0,
        render_verts=proxy_verts,
        head_verts=head_verts, head_tris=head_tris,
        body_verts=body_verts, body_tris=body_tris,
        vert_remap=proxy_remap,
    )
    if not new_records_bytes:
        dlog(f"[Physics Updater] OCYW recompute skipped — record build failed")
        return donor_blob
    if proxy_remap:
        dlog(f"[Physics Updater] OCYW: M_Combinations records used vertex remap "
             f"({len(proxy_remap)} entries) — vert_idx values in MCD index space")

    # ── Compute MOD7 sparse positions (one per proxy vert) ──
    # MOD7 records are (idx, x, y, z) tuples. The idx field, like MOD6's
    # vert_idx, references the render mesh's vert array — which the DLL
    # reorders during save when vertex remap is enabled. Apply the same
    # mapping here so MOD7's idx field stays aligned with the post-save
    # vertex layout. Records also get sorted by idx so they appear in
    # MCD order.
    new_mod7_records = []
    for i, p in enumerate(proxy_verts):
        v = _vec(p)
        if proxy_remap and i < len(proxy_remap):
            mcd_idx = proxy_remap[i] & 0xFFFFFFFF
        else:
            mcd_idx = i
        new_mod7_records.append((mcd_idx, struct.pack('<I', mcd_idx) + struct.pack('<fff', *v)))
    new_mod7_records.sort(key=lambda r: r[0])
    new_mod7_buf = bytearray()
    for _, packed in new_mod7_records:
        new_mod7_buf.extend(packed)

    # ── Apply patches in order ──
    result = bytearray(donor_blob)
    mods = _find_mod_positions(result, 16, len(result))
    mod1_off = next((o for o, m in mods if m == 1), None)
    mod2_off = next((o for o, m in mods if m == 2), None)
    mod6_off = next((o for o, m in mods if m == 6), None)
    mod7_off = next((o for o, m in mods if m == 7), None)

    if mod2_off is not None:
        _refresh_mod2_collider_counts(result, mod2_off, scene_meshes)

    # MOD1 vert count
    if mod1_off is not None:
        donor_names, donor_records = _read_mod1(result, mod1_off)
        if donor_names and donor_records:
            new_records_list = list(donor_records)
            for i, n in enumerate(donor_names):
                if n == 'M_Combinations':
                    idx, off, _ = donor_records[i]
                    new_records_list[i] = (idx, off, proxy_count)
                    break
            new_data = _write_mod1_data(donor_names, new_records_list)
            old_data = _write_mod1_data(donor_names, donor_records)
            data_start = mod1_off + 0x4C
            result[data_start:data_start + len(old_data)] = new_data
            # Same length — no resize needed for the single-slot case.

    # MOD6 records + flag table
    if mod6_off is not None:
        info = _read_mod6_minihdr(result, mod6_off)
        if info is not None:
            _records_off, old_count, _mystery = info
            _splice_mod6_records_and_flags(
                result, mod6_off,
                new_records=new_records_bytes,
                new_record_count=proxy_count,
                old_record_count=old_count,
            )
            dlog(f"[Physics Updater] OCYW: MOD6 records {old_count} → {proxy_count}")
            if fail_count:
                dlog(f"[Physics Updater] OCYW: {fail_count} verts fell back")
            if slot1_count:
                dlog(f"[Physics Updater] OCYW: {slot1_count}/{proxy_count} verts "
                     f"bound to M_Body (slot 1), rest to M_Head (slot 0)")

            # MOD7 may have shifted because of MOD6 size delta.
            mods2 = _find_mod_positions(result, 16, len(result))
            mod7_off = next((o for o, m in mods2 if m == 7), None)

    # MOD7 sparse positions
    if mod7_off is not None:
        info7 = _read_mod7_minihdr(result, mod7_off)
        if info7 is not None:
            _records_off, old_count = info7
            _replace_mod7_records(result, mod7_off, bytes(new_mod7_buf),
                                  proxy_count, old_count)
            dlog(f"[Physics Updater] OCYW: MOD7 sparse {old_count} → {proxy_count}")

    return bytes(result)


# ════════════════════════════════════════════════════════════════════════════
#  Bone tree renaming (HYWA)
# ════════════════════════════════════════════════════════════════════════════

def patch_hywa_bone_names(hywa_blob: bytes, rename_map: Dict[str, str]) -> bytes:
    if len(hywa_blob) < 16 or not rename_map:
        return hywa_blob
    result = bytearray(hywa_blob)
    mods = _find_mod_positions(result, 16, len(result))
    for moff, mid in mods:
        if mid != 2:
            continue
        data_off = moff + 0x48
        if data_off + 4 > len(result):
            continue
        bone_count = struct.unpack_from('<I', result, data_off)[0]
        if bone_count == 0 or bone_count > 10000:
            continue
        if data_off + 8 > len(result):
            continue
        first_char = result[data_off + 4]
        if first_char == 0 or not (32 <= first_char < 127):
            continue
        renamed = 0
        p = data_off + 4
        for _ in range(bone_count):
            if p + 40 > len(result):
                break
            name = result[p:p + 32].split(b'\x00')[0].decode('ascii', errors='replace')
            new_name = name
            for old_pfx, new_pfx in rename_map.items():
                if name.startswith(old_pfx):
                    new_name = new_pfx + name[len(old_pfx):]
                    break
            if new_name != name:
                result[p:p + 32] = new_name.encode('ascii')[:31].ljust(32, b'\x00')
                renamed += 1
            p += 40
        if renamed > 0:
            dlog(f"[Physics Updater] HYWA.MOD2: renamed {renamed}/{bone_count} bones")
    return bytes(result)


# ════════════════════════════════════════════════════════════════════════════
#  Public API
# ════════════════════════════════════════════════════════════════════════════

def extract_original_substreams(model_ptr, cmodellib) -> Dict[str, bytes]:
    """Read the model's currently-loaded physics sub-streams as {ext: blob}."""
    out: Dict[str, bytes] = {}
    try:
        num = cmodellib.getNumRawSubStreams(model_ptr)
    except Exception:
        return out
    for i in range(num):
        try:
            blob, size = cmodellib.getRawSubStreamData(model_ptr, i)
        except Exception:
            continue
        if not blob or size < 8:
            continue
        tag = blob[4:8]
        if tag in PHYSICS_OUTER_TAGS:
            out[PHYSICS_OUTER_TAGS[tag]] = blob[:size]
    return out


# Backward-compat alias for older callers
def patch_hcyw_mod1(hcyw_blob: bytes, scene_sim_meshes: Dict[str, int]) -> bytes:
    """Deprecated — use patch_hcyw_template with full scene_meshes."""
    return patch_hcyw_template(hcyw_blob, [], scene_sim_meshes or {})


def update_physics_for_export(original_substreams: Dict[str, bytes],
                              donor_substreams: Dict[str, bytes],
                              scene_meshes,
                              bone_rename_map: Optional[Dict[str, str]] = None,
                              donor_colliders: Optional[Dict[str, Tuple[list, list]]] = None,
                              scene_bones_with_parents: Optional[Dict[str, Optional[str]]] = None,
                              ) -> Dict[str, bytes]:
    """Compose final physics sub-streams. Returns only streams that need
    to be injected (originals to keep are omitted).

    `donor_colliders`: optional dict of M_Head / M_Body / M_Combinations
    geometry from the donor MCD, used as a fallback collider when the
    Blender scene lacks those meshes (typical when exporting an attire
    alone with no baseModel head/body present).

    `scene_bones_with_parents`: optional {bone_name: parent_or_None} from the
    scene armature. Bones present in the scene but missing from a substream's
    MOD!=2 palette get appended with chain wiring. Port-pipeline fix for
    "entrance works but match-mode collisions don't" — align_skeleton adds new
    bones the donor's MOD!=2 lacks, so match-mode skips them."""
    dlog(f"[Physics Updater] update_physics_for_export ENTER "
         f"({_PHYSICS_PATCHER_VERSION}, original={list(original_substreams.keys())}, "
         f"donor={list(donor_substreams.keys())}, "
         f"scene_meshes={len(scene_meshes) if scene_meshes else 0}, "
         f"donor_colliders={list((donor_colliders or {}).keys())})")
    scene_sim = get_scene_sim_meshes(scene_meshes) if scene_meshes else {}
    result: Dict[str, bytes] = {}

    # Resolve collider sizes once (scene > donor, same as _get_collider) so the
    # MOD2 vc fix can reach companion substreams (HYWA, CAS YWA!) that have no
    # collider-aware patch path. Without it HYWA keeps the donor's stale vc
    # while HCYW updates, leaving conflicting declarations (binding rejection).
    collider_vcs: Dict[str, int] = {}
    for _cname in ('M_Head', 'M_Body', 'M_Combinations'):
        _cv, _ct = _get_collider(scene_meshes or [], donor_colliders, _cname)
        if _cv:
            collider_vcs[_cname] = len(_cv)

    # ── HCYW ──
    if '.hair_corr_ywa' in donor_substreams:
        hcyw = donor_substreams['.hair_corr_ywa']
        hcyw = patch_hcyw_template(hcyw, scene_meshes or [], scene_sim,
                                   donor_colliders=donor_colliders)
        result['.hair_corr_ywa'] = hcyw
        dlog(f"[Physics Updater] HCYW: using donor ({len(hcyw) // 1024} KB)")

    # ── HYWA ──
    if '.hair_ywa' in donor_substreams:
        hywa = donor_substreams['.hair_ywa']
        if bone_rename_map:
            hywa = patch_hywa_bone_names(hywa, bone_rename_map)
        # Sync MOD2 collider vcs with HCYW so both substreams agree on
        # how many head/body verts the runtime baseModel must provide.
        if collider_vcs:
            hywa, hywa_vc_changes = _update_mod2_collider_vcs(hywa, collider_vcs)
            for mname, old, new in hywa_vc_changes:
                dlog(f"[Physics Updater] HYWA: MOD2 {mname} vc {old} → {new} "
                     f"(synced with HCYW collider size)")
        result['.hair_ywa'] = hywa
        dlog(f"[Physics Updater] HYWA: using donor ({len(hywa) // 1024} KB)")

    # ── CYWA (CAS-flavor HCYW) ──
    # CAS standalone files (hair_*.mcd, jacket_*.mcd) carry their physics
    # under CYWA / YWA! tags instead of HCYW / HYWA. Internal MOD layout
    # is identical: same MOD1 mesh table, same MOD2 collider list with
    # M_Head=slot0 / M_Body=slot1, same 12-byte primary records, same
    # MOD7 sparse positions. We feed it through the same patch path.
    if '.cas_corr_ywa' in donor_substreams:
        cywa = donor_substreams['.cas_corr_ywa']
        cywa = patch_hcyw_template(cywa, scene_meshes or [], scene_sim,
                                   donor_colliders=donor_colliders)
        result['.cas_corr_ywa'] = cywa
        dlog(f"[Physics Updater] CYWA: using donor "
             f"({len(cywa) // 1024} KB) — CAS-flavor HCYW")

    # ── YWA! (CAS-flavor HYWA) ──
    if '.cas_ywa' in donor_substreams:
        ywa = donor_substreams['.cas_ywa']
        if bone_rename_map:
            ywa = patch_hywa_bone_names(ywa, bone_rename_map)
        if collider_vcs:
            ywa, ywa_vc_changes = _update_mod2_collider_vcs(ywa, collider_vcs)
            for mname, old, new in ywa_vc_changes:
                dlog(f"[Physics Updater] YWA!: MOD2 {mname} vc {old} → {new} "
                     f"(synced with CYWA collider size)")
        result['.cas_ywa'] = ywa
        dlog(f"[Physics Updater] YWA!: using donor "
             f"({len(ywa) // 1024} KB) — CAS-flavor HYWA")

    # ── OCYW: prefer original; recompute donor template; fall back to placeholder ──
    # Vanilla 2K26 always has an OCYW substream — even attires without body
    # proxy sim have a 200-byte placeholder. A missing substream entirely
    # is an invalid MCD shape that causes mid-match engine freezes when the
    # game's physics dispatcher tries to look it up.
    PLACEHOLDER_MAX = 256
    orig_ocyw  = original_substreams.get('.other_corr_ywa')
    donor_ocyw = donor_substreams.get('.other_corr_ywa')

    if orig_ocyw and len(orig_ocyw) > PLACEHOLDER_MAX:
        # Original has real body-proxy physics — keep it, but inject into result
        # (not rely on the loaded model) so the final-pass vc sync can update its
        # MOD2 to match HCYW's. Otherwise the kept original declares the old vc
        # (e.g. 4035) while HCYW declares 4310 (post-caruncle-merge) → conflict →
        # hard rejection on most builds.
        result['.other_corr_ywa'] = orig_ocyw
        dlog(f"[Physics Updater] OCYW: keeping original "
             f"({len(orig_ocyw) // 1024} KB) — re-injecting for vc sync")
    elif donor_ocyw and len(donor_ocyw) > PLACEHOLDER_MAX:
        # Donor has real data — recompute against scene geometry.
        recomputed = recompute_ocyw_blob(donor_ocyw, scene_meshes or [],
                                         donor_colliders=donor_colliders)
        result['.other_corr_ywa'] = recomputed
        why = "no original" if not orig_ocyw else "original was placeholder"
        dlog(f"[Physics Updater] OCYW: recomputed donor "
             f"({len(recomputed) // 1024} KB) — {why}")
    elif not orig_ocyw and donor_ocyw:
        # Original missing, donor has placeholder — pass donor placeholder
        # through so the substream exists in the export.
        result['.other_corr_ywa'] = donor_ocyw
        dlog(f"[Physics Updater] OCYW: injecting donor placeholder "
             f"({len(donor_ocyw)} bytes) — original was missing")
    elif not orig_ocyw:
        # Neither side has anything — synthesize a vanilla-shape placeholder.
        result['.other_corr_ywa'] = _OCYW_PLACEHOLDER_208
        dlog(f"[Physics Updater] OCYW: injecting synthetic 208-byte placeholder "
             f"— no source data anywhere")
    # else: original has placeholder already in model, donor has nothing — leave alone.

    # ── OYWA: same fallback chain as OCYW ──
    orig_oywa  = original_substreams.get('.other_ywa')
    donor_oywa = donor_substreams.get('.other_ywa')
    if orig_oywa and len(orig_oywa) > PLACEHOLDER_MAX:
        # See OCYW comment above — same vc-sync rationale.
        result['.other_ywa'] = orig_oywa
        dlog(f"[Physics Updater] OYWA: keeping original "
             f"({len(orig_oywa) // 1024} KB) — re-injecting for vc sync")
    elif donor_oywa and len(donor_oywa) > PLACEHOLDER_MAX:
        result['.other_ywa'] = donor_oywa
        why = "no original" if not orig_oywa else "original was placeholder"
        dlog(f"[Physics Updater] OYWA: using donor "
             f"({len(donor_oywa) // 1024} KB) — {why}")
    elif not orig_oywa and donor_oywa:
        result['.other_ywa'] = donor_oywa
        dlog(f"[Physics Updater] OYWA: injecting donor placeholder "
             f"({len(donor_oywa)} bytes) — original was missing")
    elif not orig_oywa:
        result['.other_ywa'] = _OYWA_PLACEHOLDER_208
        dlog(f"[Physics Updater] OYWA: injecting synthetic 208-byte placeholder "
             f"— no source data anywhere")

    # ── Final pass: sync collider vcs across ALL injected physics substreams ──
    # HCYW (in patch_hcyw_template) and HYWA/YWA! (inline above) are already
    # synced, but OCYW/OYWA aren't (their MOD2 refresh sees only export-selected
    # meshes, not scene colliders). Run the agnostic updater so every substream
    # agrees — otherwise the engine reads M_Head as 4310 in HCYW and 4037 in
    # OCYW and refuses one chain.
    if collider_vcs:
        for ext_key in ('.other_corr_ywa', '.other_ywa'):
            if ext_key not in result:
                continue
            blob = result[ext_key]
            if len(blob) <= PLACEHOLDER_MAX:
                continue  # placeholders don't have collider tables to update
            blob, vc_changes = _update_mod2_collider_vcs(blob, collider_vcs)
            result[ext_key] = blob
            for mname, old, new in vc_changes:
                tag = ext_key.lstrip('.').upper().replace('OTHER_CORR_YWA', 'OCYW').replace('OTHER_YWA', 'OYWA')
                dlog(f"[Physics Updater] {tag}: collider {mname} vc {old} → {new} "
                     f"(synced with HCYW collider size)")

    # ── Bone-tree append pass ──
    # Extend each injected substream's inner-pass MOD!=2 palette with sim bones
    # that align_skeleton added to the armature on a port but that the donor's
    # MOD!=2 lacks — otherwise match-mode physics has no chain entries for them
    # and skips them (entrance/cutscene use a capsule solver that masks it).
    # patch_substream_add_bone_tree is idempotent + substream-aware (no-ops on
    # placeholders / collider-only MOD!=2), so it's safe across the result dict.
    if scene_bones_with_parents:
        for ext_key in list(result.keys()):
            blob = result[ext_key]
            if len(blob) <= PLACEHOLDER_MAX:
                continue
            new_blob = patch_substream_add_bone_tree(blob, scene_bones_with_parents)
            if new_blob is not blob and len(new_blob) != len(blob):
                # Only replace if something actually changed
                result[ext_key] = new_blob

    # ── Inner-pass MOD!=4 format upgrade (2K24 → 2K26 simple-remap) ──
    # HYWA/OYWA carry the inner-pass MOD!=4 remap. 2K26 wants mini-header
    # (0, 1, mesh_count, 0, 0, primary_vc) at MOD!+0x48 + 36 zero bytes + a u32
    # copy of primary_vc + primary_vc sequential u16 indices. A 2K24 sidecar's
    # per-bone proxy payload carried in verbatim fails match-mode (see banner
    # above the patch helpers).
    #
    # mesh_count / primary_vc come from the PAIRED cloth substream's MOD!=1
    # (HCYW for HYWA, OCYW for OYWA) — HYWA/OYWA's own MOD!=1 is the collider
    # table (would give mc=2, M_Head's vc as primary_vc). Verified vs vanilla
    # (Asuka 621, CAS hair, CAS jacket).
    def _read_cloth_slot0_info(blob: bytes) -> Tuple[Optional[int], Optional[int], Optional[List[int]]]:
        """Extract (mesh_count, slot0_count, all_slot_vcs) from HCYW/OCYW
        MOD!=1. Returns the cloth mesh count, the primary M_* render
        mesh's vertex count, and the full per-slot vertex-count list —
        what HYWA/OYWA's MOD!=4 needs to synthesize the full recursive
        payload (slot 0 outer + slot 1 nested + slots 2..N satellite).

        Returns (None, None, None) if MOD!=1 is missing or malformed.
        """
        if len(blob) < 16:
            return None, None, None
        mods = _find_mod_positions(blob, 8, len(blob))
        mod1_off = next((o for o, m in mods if m == 1), None)
        if mod1_off is None or mod1_off + 0x50 + 32 + 12 > len(blob):
            return None, None, None
        mc = struct.unpack_from('<I', blob, mod1_off + 0x4C)[0]
        if not (0 < mc <= 256):
            return None, None, None
        # MOD!=1 layout: mesh_count (4B) + mc × 32B names + record_count
        # (4B) + record_count × 12B (idx, off, count). Records are stored
        # in slot order — vanilla samples (621 Asuka mc=6, 1229 mc=4, 864
        # mc=2) all confirm slot[i]'s record is at recs_off + i*12 with
        # (slot_idx_u32, padding_u32, vc_u32).
        recs_off = mod1_off + 0x4C + 4 + 32 * mc + 4
        if recs_off + mc * 12 > len(blob):
            return None, None, None
        slot_vcs: List[int] = []
        for i in range(mc):
            _, _, vc = struct.unpack_from('<III', blob, recs_off + i * 12)
            if not (0 < vc < 1_000_000):
                # Suspect record — fall back to header-only mode.
                return mc, slot_vcs[0] if slot_vcs else None, None
            slot_vcs.append(vc)
        return mc, slot_vcs[0], slot_vcs

    pair_map = {
        '.hair_ywa':       '.hair_corr_ywa',   # HYWA needs HCYW's MOD!=1
        '.other_ywa':      '.other_corr_ywa',  # OYWA needs OCYW's MOD!=1
    }
    # CAS-flavor substreams (.cas_ywa / .cas_corr_ywa) ship a DIFFERENT vanilla
    # 2K26 inner MOD!=4 (mini-header first u32 is 1, with real per-vertex bind
    # data that doesn't follow the `(0,1,mc,0,0,vc)` simple-remap pattern).
    # _is_modern_inner_mod4 can't tell it from a 2K24 legacy payload, so the
    # rewrite would wipe the bind data → engine sees "no displacement" → physics
    # flies apart. Skip them — vanilla CAS donors are already correct.
    CAS_SKIP_INNER_MOD4_FIX = {'.cas_ywa', '.cas_corr_ywa'}
    for ext_key in list(result.keys()):
        if ext_key in CAS_SKIP_INNER_MOD4_FIX:
            continue
        blob = result[ext_key]
        if len(blob) <= PLACEHOLDER_MAX:
            continue
        mc_override = vc_override = None
        slot_vcs_override = None
        partner_key = pair_map.get(ext_key)
        if partner_key and partner_key in result:
            mc_override, vc_override, slot_vcs_override = \
                _read_cloth_slot0_info(result[partner_key])
        new_blob = patch_substream_fix_inner_mod4(
            blob,
            primary_vc_override=vc_override,
            mesh_count_override=mc_override,
            slot_vcs_override=slot_vcs_override,
        )
        if new_blob is not blob and new_blob != blob:
            result[ext_key] = new_blob

    return result
