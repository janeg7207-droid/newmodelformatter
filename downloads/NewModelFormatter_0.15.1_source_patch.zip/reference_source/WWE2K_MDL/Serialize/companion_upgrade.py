"""
2K25 → 2K26 sub-stream upgrade.

In 2K25 attire MCDs, companion data lives as sibling files on disk
(.ctg, .hair_ywa, .hair_corr_ywa, .other_ywa, .other_corr_ywa). 2K26
expects those same blobs embedded as sub-streams. This module performs that
one-way upgrade (reads siblings, embeds them in the export) and ONLY in that
direction.

What this is NOT:
  - Not a generic "copy companions" helper. .mtls and .ycl are sidecars in
    BOTH 2K25 and 2K26 and are deliberately excluded — auto-copying them was
    the bleed-through vector that overwrote user edits and pulled .mtls from
    the wrong source on multi-stamped scenes.
  - Not a same-version helper. 26→26 never enters this path.
  - Not a basemodel-source helper. baseModels contribute only GtPt, handled in
    model_serialize.py.

.hpl is deliberately NOT embedded from a 25 source. The caller instead invokes
inject_empty_hpl_substream() when the scene has no HPL edits (canonical
zero-mask form); scene HPL edits go through the round-trip which overrides it.
This avoids embed-then-overwrite of a .hpl the round-trip would discard.

Layering at save time (each uses idempotent replaceOrAddSubStreamByTag, so
later layers override earlier without duplicates):
  1. CModelSerializer.build()         — DLL emits HCYW/HYWA/etc. from model
  2. transferGotoPoints               — GtPt from any stamped source
  3. embed_25_companions_for_2k26     — THIS MODULE, attire 25→26 only
  4. inject_empty_hpl_substream       — THIS MODULE, 25→26 + no scene HPL
  5. HPL round-trip                   — scene HPL group edits override
  6. Physics swap                     — donor blobs override everything
"""

import os
import struct

from ..Link.wrapper import cmodellib
from ..Link.log import dlog, dwarn


# Reason codes returned alongside the bool from embed_25_companions_for_2k26
# so callers can distinguish "source wasn't a candidate" from "nothing was
# upgrade-eligible" for logs/branching.
REASON_OK = "ok"
REASON_NO_PATH = "no_source_path"
REASON_NO_BASEMODEL = "not_a_basemodel"
REASON_NOT_2K25 = "source_not_2k25"

# Sanity-floor for an embedded sub-stream payload: inner 4-byte magic +
# minimal header (~4 bytes). Shorter than 8 bytes = stub/truncated file.
MIN_SIDECAR_SIZE = 8


# 2K25 sibling extensions that become 2K26 sub-streams. Each value is the
# 4-byte outer tag the DLL/game expects on the sub-stream envelope.
#
# `.hpl` is intentionally absent — see module docstring.
#
# `.ctg` is also intentionally absent. CTG is a basemodel-format substream;
# vanilla 2K26 attires carry ZERO CTG. This embedder only fires for attire
# sources (bails on "basemodel" basenames), so a `.ctg` embed would only ever
# apply to a 2K25 attire — which doesn't get CTG in 2K26. Embedding it put an
# 82-KB CTG! block at offset 0xC, shifting MDL!/HCYW/HYWA/HPL!/OCYW/OYWA/WDF!
# back and leaking basemodel slot names into the TEXT block (basemodel-shaped
# file under an attire name). Basemodel exports never reach this code.
SUBSTREAM_COMPANIONS = {
    '.hair_ywa':       b'HYWA',
    '.hair_corr_ywa':  b'HCYW',
    '.other_ywa':      b'OYWA',
    '.other_corr_ywa': b'OCYW',
}

# MDL version byte that identifies a 2K25-format source MCD.
_MDL_VERSION_2K25 = 0x29


def _is_2k25_source(source_path):
    """Read the MDL version byte from the source MCD; True iff it's 2K25.

    Re-detected at upgrade time rather than trusting a stored collection stamp
    — eliminates stamp drift and "user swapped the source file" bugs. Reuses
    wrapper.detect_mcd_version, imported lazily (this module loads early).
    """
    try:
        from ..Link.wrapper import detect_mcd_version
    except Exception as e:
        dwarn(f"_is_2k25_source detection failed: {e}")
        return False
    try:
        return detect_mcd_version(source_path) == _MDL_VERSION_2K25
    except Exception as e:
        dwarn(f"_is_2k25_source detection failed: {e}")
        return False


def embed_25_companions_for_2k26(cmodel_ptr, source_path):
    """Embed the 2K25 source's sibling sub-stream files into the 2K26 export.

    Returns (did_embed, reason). `did_embed` is True iff ≥1 sub-stream was
    written; `reason` is a REASON_* constant so callers can log why nothing
    was embedded without re-running the gating.

    Strict gates — all must pass before any sub-stream is written:
      - source_path provided and exists on disk
      - source basename does not contain "basemodel" (basemodels contribute
        only GtPt, handled in model_serialize.py)
      - source MCD's MDL version byte is 2K25 (re-read every time, no stamp)

    Caller gates on `compile_target` being 2K26 — this function only checks
    that the SOURCE is 2K25.
    """
    if not source_path or not os.path.exists(source_path):
        return False, REASON_NO_PATH
    if 'basemodel' in os.path.basename(source_path).lower():
        return False, REASON_NO_BASEMODEL
    if not _is_2k25_source(source_path):
        # Source is 26 (no upgrade needed; DLL already wrote correct sub-
        # streams) or older than 25 (different format, not handled here).
        return False, REASON_NOT_2K25

    src_dir = os.path.dirname(source_path)
    src_base = os.path.splitext(os.path.basename(source_path))[0]

    embedded = []
    for ext, tag in SUBSTREAM_COMPANIONS.items():
        sidecar = os.path.join(src_dir, src_base + ext)
        if not os.path.exists(sidecar):
            continue

        try:
            with open(sidecar, 'rb') as f:
                file_data = f.read()
        except OSError:
            continue

        if len(file_data) < MIN_SIDECAR_SIZE:
            continue

        # Same envelope HPL round-trip and physics swap use:
        #   [u32 size_of_payload][4-byte outer tag][payload]
        blob = struct.pack('<I', len(file_data)) + tag + file_data
        cmodellib.replaceOrAddSubStreamByTag(cmodel_ptr, blob, len(blob))
        embedded.append(f"{ext} ({len(file_data) // 1024} KB)")

    if embedded:
        dlog(f"[MDL Addon] 25→26 sub-stream upgrade embedded "
             f"{len(embedded)} companion(s): {', '.join(embedded)}")
        return True, REASON_OK
    return False, REASON_OK


def inject_empty_hpl_substream(cmodel_ptr):
    """Inject the canonical zero-mask HPL sub-stream — the same binary the
    'Generate Empty HPL' button produces after export.

    Used in the 25→26 path when the scene has no HPL_Ring / HPL_Entrance edits,
    which would otherwise leave the 2K26 file with no HPL sub-stream at all
    (the game's HPL parser misbehaves on some builds). Ships the canonical
    12-byte empty form (no masking). If the user later adds HPL groups, the
    round-trip overrides this via replaceOrAddSubStreamByTag.
    """
    # Lazy import — masking_hpl pulls in bpy, which isn't ready at this module's
    # early import time on some Blender startup orders.
    from ..Blender.Extras.masking_hpl import getBinaryHPL

    # Empty inputs → canonical 12-byte form b'HPL!END!\x00\x00\x00\x00'
    # ("minimal empty form" path in masking_hpl.py).
    hpl_payload = getBinaryHPL([], [], 0)
    blob = struct.pack('<I', len(hpl_payload)) + b'HPL!' + hpl_payload
    cmodellib.replaceOrAddSubStreamByTag(cmodel_ptr, blob, len(blob))
    dlog(f"[MDL Addon] 25→26 upgrade: injected empty HPL sub-stream "
         f"(no scene HPL edits, source had no .hpl to embed)")


def scrub_oversized_hpl_substreams(saved_path, threshold_bytes=32):
    """Strip oversized HPL sub-stream wrappers from a saved baseModel MCD.

    When a previously-broken baseModel mod (exported with attire-context HPL
    baked in by an old addon version) is round-tripped, the DLL parses BOTH the
    canonical empty HPL stub AND the oversized block as separate sub-streams and
    saveModelToFile emits both. The pre-save scrub's replaceOrAddSubStreamByTag
    only catches the first matching tag, so the oversized duplicate survives.

    The DLL has no removeSubStreamByTag, so we strip at the file level after
    save: find every [u32 size][HPL!][payload] wrapper and delete any whose
    size exceeds threshold_bytes (canonical empty stub is 12 bytes).

    Parameters
    ----------
    saved_path : str
        Path to the already-saved MCD file. Mutated in-place.
    threshold_bytes : int
        Wrappers with size strictly greater are removed. Default 32 — above the
        12-byte empty stub, below any real attire HPL block (smallest ~4 KB).

    Returns
    -------
    int : number of wrappers removed (0 if the file was clean).
    """
    try:
        with open(saved_path, 'rb') as f:
            data = bytearray(f.read())
    except OSError as e:
        dlog(f"[MDL Addon] HPL scrub: cannot read {saved_path}: {e}")
        return 0

    removed = 0
    removed_total_bytes = 0
    # Match the literal [u32 size][HPL!][payload] sequence. Use
    # bytearray.find to jump to candidate HPL! sites rather than striding
    # (outer alignment isn't guaranteed). HPL! has no internal 'H', so
    # overlapping matches are impossible and skipping a failed candidate
    # by 4 bytes is safe.
    pos = 0
    while True:
        j = data.find(b'HPL!', pos)
        if j < 0:
            break
        # Need a 4-byte size word in front of the tag.
        if j < 4:
            pos = j + 4
            continue
        i = j - 4
        # Candidate must leave room for ≥9 bytes past i (orig bound
        # `while i < len(data) - 8`).
        if i >= len(data) - 8:
            break
        size = struct.unpack_from('<I', data, i)[0]
        if (threshold_bytes < size
                and i + 8 + size <= len(data)):
            del data[i:i+8+size]
            removed += 1
            removed_total_bytes += 8 + size
            # Re-check this position in case another HPL wrapper follows.
            pos = i
            continue
        # Not oversized — skip past this HPL! tag (no self-overlap).
        pos = j + 4

    if removed > 0:
        try:
            with open(saved_path, 'wb') as f:
                f.write(data)
            dlog(f"[MDL Addon] HPL scrub: stripped {removed} oversized "
                 f"HPL sub-stream(s) from baseModel "
                 f"({removed_total_bytes:,} bytes total) — "
                 f"file size now {len(data):,} bytes")
        except OSError as e:
            dlog(f"[MDL Addon] HPL scrub: cannot write {saved_path}: {e}")
            return 0
    else:
        dlog(f"[MDL Addon] HPL scrub: no oversized HPL sub-streams found "
             f"(file is already clean)")

    return removed
