"""
HPL round-trip handler for WWE 2K26 attire masking.

In 2K26, HPL data is embedded as a sub-stream inside the attire MCD. This module
handles the round-trip workflow:

  1. DETECT  — Scan scene collections for attire sidecars containing HPL! data
  2. EXTRACT — Pull HPL! blob from the attire's round-trip sidecar
  3. APPLY   — Parse the HPL and create HPL_Ring / HPL_Entrance vertex groups
               on the baseModel's M_Head and M_Body meshes
  4. UPDATE  — On attire export, regenerate HPL from scene vertex groups and
               inject as the replacement sub-stream (skipping the stale original)

The HPL lives in the attire MCD but masks the baseModel — so the user loads both,
edits the vertex groups on the baseModel meshes, and exports the attire with the
updated masking data.

VERTEX INDEX SPACE:
  HPL files store vertex indices in MCD order (pre-dedup, with UV seam splits).
  Blender works with deduplicated vertices. The vcmodel_vertex_remap custom
  property on each mesh maps Blender indices → MCD indices:
    vertex_remap[blender_idx] = mcd_idx
  
  Import: MCD indices → reverse map → Blender vertex groups
  Export: Blender vertex groups → forward map → MCD indices in HPL
"""

import bpy
import io
import json
import os
import struct

from ..Blender.Extras.masking_hpl import parseHPL, getBinaryHPL, modelLods
from ..Link.log import dlog, dwarn, derror

# HPL! sub-stream outer tag.
HPL_OUTER_TAG = b'\x48\x50\x4C\x21'  # HPL!
HPL_INNER_TAG = b'HPL!'

# Canonical HPL flag mapping. Hoisted to module top so the import/export/check
# paths all reference the same two-channel definition instead of redefining
# the literals at every call site. flag 0 = Ring, flag 1 = Entrance.
FLAG_NAMES = {0: 'HPL_Ring', 1: 'HPL_Entrance'}
ALL_VG_NAMES = ('HPL_Ring', 'HPL_Entrance')


# ═══════════════════════════════════════════════════════════════════════════
#  VERTEX REMAP HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def _get_vertex_remap(obj):
    """Get the vertex_remap array from a Blender mesh object.
    
    Returns list where vertex_remap[blender_idx] = mcd_idx, or None.
    """
    raw = obj.get("vcmodel_vertex_remap")
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None


def _build_reverse_remap(vertex_remap):
    """Build reverse mapping: mcd_idx → blender_idx.

    Multiple MCD vertices may collapse to the same Blender vertex (UV seam dedup),
    so a given MCD index maps to exactly one Blender index but the same Blender
    index may appear for multiple MCD indices.

    Returns dict of {mcd_idx: blender_idx}.
    """
    reverse = {}
    for blender_idx, mcd_idx in enumerate(vertex_remap):
        # First Blender index wins — they all map to the same geometric vertex
        if mcd_idx not in reverse:
            reverse[mcd_idx] = blender_idx
    return reverse


# Module-level reverse-remap cache. Keyed on obj.as_pointer() so it doesn't
# bloat the .blend file with a 70k-entry IDProperty per basemodel; the hash
# of the source vertex_remap JSON is stored alongside so we can detect when
# the user re-imports the mesh and invalidate stale entries. Cleared
# automatically on Blender restart, which is fine — the cost of rebuilding
# is single-digit ms even on big bodies.
_REVERSE_REMAP_CACHE = {}


def _get_reverse_remap_cached(obj):
    """Return the {mcd_idx: blender_idx} reverse map for an object, building
    it on first use and caching subsequent calls.

    Cache invalidates when the source vcmodel_vertex_remap JSON changes
    (re-import, manual edit) — hashed string comparison, not deep compare,
    so the check is O(1) per call after the first build.

    Returns None when the object has no vcmodel_vertex_remap.
    """
    raw = obj.get("vcmodel_vertex_remap")
    if raw is None:
        return None
    key = obj.as_pointer()
    src_hash = hash(raw)
    cached = _REVERSE_REMAP_CACHE.get(key)
    if cached is not None and cached[0] == src_hash:
        return cached[1]
    try:
        vremap = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None
    reverse = _build_reverse_remap(vremap)
    _REVERSE_REMAP_CACHE[key] = (src_hash, reverse)
    return reverse


def _mcd_to_blender_indices(mcd_indices, vertex_remap_or_reverse):
    """Convert a list of MCD-order vertex indices to Blender-order indices.

    Accepts either the raw forward vertex_remap (list/tuple of mcd_idx by
    blender_idx) — in which case the reverse map is built on the fly — or a
    pre-built reverse map dict ({mcd_idx: blender_idx}) from
    _get_reverse_remap_cached for hot loops.

    Indices that can't be mapped are dropped (can happen if the HPL
    references a vertex that was optimized out).

    Returns (blender_indices, num_unmapped).
    """
    if isinstance(vertex_remap_or_reverse, dict):
        reverse = vertex_remap_or_reverse
    else:
        reverse = _build_reverse_remap(vertex_remap_or_reverse)
    blender_indices = []
    unmapped = 0
    for mcd_idx in mcd_indices:
        blender_idx = reverse.get(mcd_idx)
        if blender_idx is not None:
            blender_indices.append(blender_idx)
        else:
            unmapped += 1
    return blender_indices, unmapped


def _blender_to_mcd_indices(blender_indices, vertex_remap):
    """Convert a list of Blender-order vertex indices to MCD-order indices.
    
    Direct lookup: vertex_remap[blender_idx] = mcd_idx.
    
    Returns (mcd_indices, num_unmapped).
    """
    mcd_indices = []
    unmapped = 0
    for blender_idx in blender_indices:
        if blender_idx < len(vertex_remap):
            mcd_indices.append(vertex_remap[blender_idx])
        else:
            unmapped += 1
    return mcd_indices, unmapped


# ═══════════════════════════════════════════════════════════════════════════
#  DETECTION — Find and extract HPL! data from the source MCD or companion
# ═══════════════════════════════════════════════════════════════════════════

def find_attire_hpl_sidecar():
    """Lightweight check for the panel — returns (source_path, collection_name)
    if any attire collection has a source that could contain HPL data.
    Skips baseModel sources.
    """
    for col in bpy.data.collections:
        source_path = col.get("vcmodel_source_path")
        if not source_path or not os.path.exists(source_path):
            continue
        
        if 'basemodel' in os.path.basename(source_path).lower():
            continue
        
        hpl_path = _find_companion_hpl(source_path)
        if hpl_path:
            return hpl_path, col.name
        
        if source_path.lower().endswith(('.mcd', '.model')):
            return source_path, col.name
    
    return None, None

def find_attire_hpl_source():
    """Scan collections for an attire source that could contain HPL data.
    Skips baseModel sources (they don't have HPL).
    """
    for col in bpy.data.collections:
        source_path = col.get("vcmodel_source_path")
        if not source_path or not os.path.exists(source_path):
            continue
        
        # Skip baseModel — no HPL sub-streams
        if 'basemodel' in os.path.basename(source_path).lower():
            continue
        
        hpl_path = _find_companion_hpl(source_path)
        if hpl_path:
            return 'companion', hpl_path, col.name
        
        if source_path.lower().endswith(('.mcd', '.model')):
            return 'mcd', source_path, col.name
    
    return None, None, None


def _find_companion_hpl(source_mcd_path):
    """Find a .hpl companion file next to a source MCD."""
    source_dir = os.path.dirname(source_mcd_path)
    source_base = os.path.splitext(os.path.basename(source_mcd_path))[0]
    hpl_path = os.path.join(source_dir, source_base + '.hpl')
    if os.path.exists(hpl_path):
        return hpl_path
    return None


def extract_hpl_from_mcd(mcd_path):
    """Load an MCD via the DLL and extract the HPL! sub-stream payload.
    
    Reads the HPL directly from the source file — no sidecar needed.
    The DLL handles all MCD format parsing.
    
    Returns:
        bytes: the HPL file data (starting with HPL! magic), or None
    """
    import ctypes
    from ..Link.wrapper import ExternalLibary, cmodellib
    
    try:
        module = ExternalLibary()
        model_file = ctypes.c_void_p()
        skin_model = module.load_model(mcd_path.encode('utf-8'), 
                                        ctypes.byref(model_file), False)
        
        if not model_file or not skin_model:
            dlog(f"[HPL Roundtrip] Could not load MCD for HPL extraction: {mcd_path}")
            return None
        
        try:
            num_streams = cmodellib.getNumRawSubStreams(skin_model)
            for i in range(num_streams):
                blob, size = cmodellib.getRawSubStreamData(skin_model, i)
                if blob and size >= 8:
                    tag = blob[4:8]
                    if tag == HPL_OUTER_TAG or tag == HPL_INNER_TAG:
                        # Blob format: [u32 payload_size][HPL! tag][HPL file data]
                        hpl_data = blob[8:]
                        if len(hpl_data) >= 4 and hpl_data[0:4] == HPL_INNER_TAG:
                            dlog(f"[HPL Roundtrip] Extracted HPL from MCD: "
                                  f"{len(hpl_data)} bytes ({os.path.basename(mcd_path)})")
                            return bytes(hpl_data)
            
            dlog(f"[HPL Roundtrip] No HPL! sub-stream found in {os.path.basename(mcd_path)}")
            return None
        finally:
            module.release_model_file(model_file)
    
    except Exception as e:
        derror(f"[HPL Roundtrip] Error extracting HPL from MCD: {e}")
        return None


def extract_hpl_from_companion(hpl_path):
    """Read a standalone .hpl companion file from disk.
    
    Returns:
        bytes: the HPL file data (starting with HPL! magic), or None
    """
    try:
        with open(hpl_path, 'rb') as f:
            data = f.read()
        if len(data) >= 4 and data[0:4] == HPL_INNER_TAG:
            return data
        return None
    except Exception as e:
        derror(f"[HPL Roundtrip] Error reading HPL companion: {e}")
        return None


def extract_hpl_data():
    """Extract HPL data from whatever source is available (MCD or companion).
    
    For 2K26 sources: loads the MCD directly via the DLL and reads HPL from it.
    For 2K25 sources: reads the .hpl companion file from disk.
    No sidecar involved.
    
    Returns:
        tuple of (hpl_data: bytes, source_description: str) or (None, None)
    """
    source_type, source_path, col_name = find_attire_hpl_source()
    
    if source_type == 'mcd':
        data = extract_hpl_from_mcd(source_path)
        if data:
            return data, f"{col_name} (embedded)"
    elif source_type == 'companion':
        data = extract_hpl_from_companion(source_path)
        if data:
            return data, f"{col_name} ({os.path.basename(source_path)})"
    
    return None, None


# ═══════════════════════════════════════════════════════════════════════════
#  APPLY — Parse HPL and create vertex groups on baseModel meshes
# ═══════════════════════════════════════════════════════════════════════════

def find_basemodel_meshes(scope_objects=None):
    """Find M_Head and M_Body mesh objects in the scene.

    Handles the naming patterns seen in practice:
      * data.name exactly 'M_Head' / 'M_Body' (with '.NNN' suffix stripped).
      * split_material_groups imports: object names come from the active
        material ('body:skinned', 'head:skinned'), so we also match object
        names / material names for 'body' / 'head' substrings.

    Returns the first match per key. Multiple M_Body candidates (split-by-
    material) are a scene-org issue the user resolves — we don't pick winners.

    Parameters
    ----------
    scope_objects : iterable of bpy.types.Object, optional
        Two filters run before ranking, both strict-when-possible (prune
        dominated candidates, never strand the caller with empty results):

        1. VISIBILITY (always). "The visible basemodel is the one used":
           visible candidates drop hidden ones; if all are hidden, bypassed.
        2. COLLECTION SCOPE (only with scope_objects). Restricts to candidates
           sharing a collection with a scope object — picks the right one when
           two basemodels are both visible. Each import lands in its own
           collection, so membership is a clean signal.

        Active/selected/name ranking runs last to break ties.

    Returns:
        dict of {'M_Head': obj, 'M_Body': obj} for matches found.
    """
    import bpy as _bpy

    # In-scope = any users_collection overlaps this set. Direct
    # users_collection (not an ancestor walk) — import puts a file's meshes in
    # one flat collection, and an ancestor walk would re-include both basemodels
    # via the shared scene root, defeating the scoping.
    scope_collections = None
    if scope_objects:
        scope_collections = set()
        for obj in scope_objects:
            try:
                for col in obj.users_collection:
                    scope_collections.add(col)
            except (AttributeError, ReferenceError):
                # Object freed mid-call or non-collection-bearing — skip.
                continue

    def _is_in_scope(obj):
        if scope_collections is None:
            return True
        try:
            return any(col in scope_collections for col in obj.users_collection)
        except (AttributeError, ReferenceError):
            return False

    # Gather ALL candidates for each key rather than picking the first
    # match, so we can prefer user-selected objects when there are
    # multiple baseModels in the scene (common during attire A/B work).
    head_candidates = []  # list of (obj, priority-int)
    body_candidates = []

    # Pass 1: exact match on data.name (with .NNN suffix strip).
    # This is the strongest signal — priority 0 (highest).
    for obj in _bpy.data.objects:
        if obj.type != 'MESH':
            continue
        mesh_name = obj.data.name
        if '.' in mesh_name:
            mesh_name = mesh_name.rsplit('.', 1)[0]
        if mesh_name == 'M_Head':
            head_candidates.append((obj, 0))
        elif mesh_name == 'M_Body':
            body_candidates.append((obj, 0))

    # Pass 2: widened matching for split_material_groups workflows.
    # Priority 1 (weaker signal than Pass 1).
    def _name_indicates(obj, token):
        obj_lower = obj.name.lower()
        if token in obj_lower:
            return True
        for slot in obj.material_slots:
            if slot.material and token in slot.material.name.lower():
                return True
        return False

    already_head = {id(o) for o, _ in head_candidates}
    already_body = {id(o) for o, _ in body_candidates}
    for obj in _bpy.data.objects:
        if obj.type != 'MESH':
            continue
        if id(obj) not in already_head and _name_indicates(obj, 'head'):
            if (':skinned' in obj.name.lower()
                    or obj.name.lower() in ('head', 'm_head')
                    or obj.data.name.lower().startswith('m_head')):
                head_candidates.append((obj, 1))
        if id(obj) not in already_body and _name_indicates(obj, 'body'):
            if (':skinned' in obj.name.lower()
                    or obj.name.lower() in ('body', 'm_body')
                    or obj.data.name.lower().startswith('m_body')):
                body_candidates.append((obj, 1))

    # ── Filter 1: VISIBILITY (strict-when-possible) ────────────────────
    # "The visible basemodel is the one used" — hiding the unwanted basemodel
    # outranks selection (users often have the attire selected for export while
    # the wanted basemodel sits unselected but visible). Uses obj.visible_get()
    # (combines hide/viewport-disable/collection-exclude), with a per-flag
    # fallback for very old Blender. If a key has ANY visible candidate, hidden
    # ones drop; if ALL are hidden, fall through.
    def _is_visible(obj):
        try:
            return bool(obj.visible_get())
        except (AttributeError, TypeError):
            pass
        try:
            return (not obj.hide_get()) and (not obj.hide_viewport)
        except (AttributeError, ReferenceError):
            return True  # If we can't tell, don't penalize the candidate

    dropped_for_visibility = {'M_Head': [], 'M_Body': []}
    vis_head = [(o, p) for (o, p) in head_candidates if _is_visible(o)]
    vis_body = [(o, p) for (o, p) in body_candidates if _is_visible(o)]
    if vis_head and len(vis_head) < len(head_candidates):
        dropped_for_visibility['M_Head'] = [o for (o, _) in head_candidates if not _is_visible(o)]
        head_candidates = vis_head
    if vis_body and len(vis_body) < len(body_candidates):
        dropped_for_visibility['M_Body'] = [o for (o, _) in body_candidates if not _is_visible(o)]
        body_candidates = vis_body

    # ── Filter 2: COLLECTION SCOPE (strict-when-possible) ──────────────
    # Only with scope_objects, for when both basemodels pass visibility (user
    # comparing side by side): pick the one sharing a collection with the
    # selected attire. No in-scope candidate for a key → fall back to full set.
    dropped_for_scope = {'M_Head': [], 'M_Body': []}
    if scope_collections is not None:
        in_scope_head = [(o, p) for (o, p) in head_candidates if _is_in_scope(o)]
        in_scope_body = [(o, p) for (o, p) in body_candidates if _is_in_scope(o)]
        if in_scope_head:
            dropped_for_scope['M_Head'] = [o for (o, _) in head_candidates if not _is_in_scope(o)]
            head_candidates = in_scope_head
        if in_scope_body:
            dropped_for_scope['M_Body'] = [o for (o, _) in body_candidates if not _is_in_scope(o)]
            body_candidates = in_scope_body

    # Disambiguate multiple candidates by (priority, !is_active, !is_selected,
    # name) — lower wins. Active+selected strongest; name breaks ties
    # deterministically.
    try:
        active_obj = _bpy.context.view_layer.objects.active
    except Exception:
        active_obj = None
    try:
        selected_objs = set(_bpy.context.selected_objects)
    except Exception:
        selected_objs = set()

    def _rank(entry):
        obj, priority = entry
        is_active = (obj is active_obj)
        is_selected = (obj in selected_objs)
        # Parent-selection counts too: if the user selected an armature
        # or collection instance that parents the basemodel, count that
        # as "user-expressed intent toward this object."
        if not is_selected and obj.parent is not None and obj.parent in selected_objs:
            is_selected = True
        return (priority, 0 if is_active else 1, 0 if is_selected else 1, obj.name)

    head_candidates.sort(key=_rank)
    body_candidates.sort(key=_rank)

    result = {}
    if head_candidates:
        result['M_Head'] = head_candidates[0][0]
    if body_candidates:
        result['M_Body'] = body_candidates[0][0]

    # Diagnostic: log the winning pick plus alternatives so multi-candidate
    # ambiguity (and the chosen winner) is visible.
    found_list = ", ".join(f"{k}={v.name}" for k, v in result.items()) or "(none)"
    scope_tag = f" scope={[o.name for o in scope_objects]}" if scope_objects else ""
    dlog(f"[HPL Roundtrip] find_basemodel_meshes -> {found_list}{scope_tag}")
    if len(head_candidates) > 1:
        dlog(f"[HPL Roundtrip]   multiple M_Head candidates — chose '{result['M_Head'].name}'; others: "
              + ", ".join(f"'{c[0].name}'" for c in head_candidates[1:]))
    if len(body_candidates) > 1:
        dlog(f"[HPL Roundtrip]   multiple M_Body candidates — chose '{result['M_Body'].name}'; others: "
              + ", ".join(f"'{c[0].name}'" for c in body_candidates[1:]))
    # Surface visibility-pruned candidates (the common "hide the unwanted
    # basemodel" path) so the behavior is obvious in the console.
    if dropped_for_visibility['M_Head']:
        dlog(f"[HPL Roundtrip]   M_Head visibility-filter dropped (hidden in viewport): "
              + ", ".join(f"'{o.name}'" for o in dropped_for_visibility['M_Head']))
    if dropped_for_visibility['M_Body']:
        dlog(f"[HPL Roundtrip]   M_Body visibility-filter dropped (hidden in viewport): "
              + ", ".join(f"'{o.name}'" for o in dropped_for_visibility['M_Body']))
    # Surface scope-pruned candidates so "which basemodel's HPL did this use?"
    # is answerable from the log.
    if dropped_for_scope['M_Head']:
        dlog(f"[HPL Roundtrip]   M_Head scope-filter dropped (not in user selection's collection): "
              + ", ".join(f"'{o.name}'" for o in dropped_for_scope['M_Head']))
    if dropped_for_scope['M_Body']:
        dlog(f"[HPL Roundtrip]   M_Body scope-filter dropped (not in user selection's collection): "
              + ", ".join(f"'{o.name}'" for o in dropped_for_scope['M_Body']))
    if not result:
        mesh_objects = [o for o in _bpy.data.objects if o.type == 'MESH']
        dlog(f"[HPL Roundtrip]   scene has {len(mesh_objects)} mesh objects:")
        for o in mesh_objects[:20]:
            dlog(f"[HPL Roundtrip]     obj='{o.name}'  data='{o.data.name}'")
        if len(mesh_objects) > 20:
            dlog(f"[HPL Roundtrip]     ...and {len(mesh_objects)-20} more")

    return result


def apply_hpl_to_basemodel(hpl_data, report_fn=None):
    """Parse HPL binary data and apply as vertex groups on baseModel meshes.

    Always creates both HPL_Ring and HPL_Entrance vertex groups on M_Head
    and M_Body so the user can edit them. Populates with masked vertex indices
    from the HPL where data exists; empty groups are created for missing entries
    so the user can add to them.

    HPL stores indices in MCD order — these are converted to Blender order
    using the mesh's vcmodel_vertex_remap before assigning to vertex groups.

    Args:
        hpl_data: bytes starting with HPL! magic
        report_fn: optional callable (set, str) mirroring an Operator.report
            method. If provided, out-of-bounds drops and unmapped indices
            surface as a {'WARNING'} report so the user sees them in the
            info bar rather than only in the console.

    Returns:
        tuple (success: bool, message: str)
    """
    dlog(f"[HPL Roundtrip] apply_hpl_to_basemodel: {len(hpl_data) if hpl_data else 0} bytes of HPL data")
    # Parse the HPL
    hpl_buffer = io.BytesIO(hpl_data)
    hpl_lods = parseHPL(hpl_buffer)
    
    if not hpl_lods:
        dlog("[HPL Roundtrip] parseHPL returned no LODs — HPL data malformed or empty")
        return False, "Failed to parse HPL data"
    dlog(f"[HPL Roundtrip] parsed {len(hpl_lods)} LOD entries from HPL data")
    
    # Find baseModel meshes
    base_meshes = find_basemodel_meshes()
    if not base_meshes:
        return False, "No M_Head or M_Body meshes found in scene"
    
    # FLAG_NAMES / ALL_VG_NAMES are defined at module top.

    # Step 1: Ensure both vertex groups exist on both meshes (clear any old data)
    for mesh_key, obj in base_meshes.items():
        for vg_name in ALL_VG_NAMES:
            vg = obj.vertex_groups.get(vg_name)
            if vg:
                obj.vertex_groups.remove(vg)
            obj.vertex_groups.new(name=vg_name)
    
    # Step 2: Build reverse remap for each mesh (MCD index → Blender index).
    # _get_reverse_remap_cached avoids rebuilding the dict on every Apply
    # HPL pass — the source vcmodel_vertex_remap is hashed for invalidation
    # so the cache stays correct across re-imports.
    mesh_remaps = {}
    for mesh_key, obj in base_meshes.items():
        rev = _get_reverse_remap_cached(obj)
        if rev:
            mesh_remaps[mesh_key] = rev
            dlog(f"[HPL Roundtrip] {mesh_key}: vertex_remap found "
                  f"({len(rev)} MCD verts → Blender space)")
        else:
            dlog(f"[HPL Roundtrip] {mesh_key}: no vertex_remap, "
                  f"using indices as-is (baseModel may not need remap)")
    
    # Step 3: Parse LOD 0 and populate vertex groups with HPL data
    lod0 = hpl_lods[0] if hpl_lods else None
    applied_count = 0
    details = []
    
    # Accumulate drop counts across all (mesh, group) pairs so the
    # operator-visible warning is one summary line per Apply rather than
    # one per group. Per-group detail still goes to dlog.
    total_oob_drops = 0
    total_unmapped = 0
    drop_details = []  # list[str] for the summary report

    if lod0 and lod0.objects:
        for hpl_obj in lod0.objects:
            # Match mesh name from HPL to scene object
            mesh_name = hpl_obj.name
            target_obj = base_meshes.get(mesh_name)
            matched_key = mesh_name

            if not target_obj:
                # Strict partial match: equality or a 'key_'-prefixed extension
                # ('M_Body_LOD1' → M_Body). Avoids the substring trap where
                # 'M_Body' matched 'M_Bodyguard'.
                for key, obj in base_meshes.items():
                    if mesh_name == key or mesh_name.startswith(key + '_'):
                        target_obj = obj
                        matched_key = key
                        break

            if not target_obj:
                dlog(f"[HPL Roundtrip] No baseModel mesh for HPL entry '{hpl_obj.name}', skipping")
                continue

            # Get the vertex group (already created above)
            vg_name = FLAG_NAMES.get(hpl_obj.sceneFlag, f'HPL_Flag{hpl_obj.sceneFlag}')
            vg = target_obj.vertex_groups.get(vg_name)
            if not vg:
                vg = target_obj.vertex_groups.new(name=vg_name)

            # Convert MCD indices to Blender indices using vertex_remap
            mcd_indices = hpl_obj.visibility_vector
            vremap = mesh_remaps.get(matched_key)

            if vremap:
                blender_indices, unmapped = _mcd_to_blender_indices(mcd_indices, vremap)
                if unmapped > 0:
                    total_unmapped += unmapped
                    drop_details.append(f"{matched_key}/{vg_name}: {unmapped} unmapped")
                    dlog(f"[HPL Roundtrip] Warning: {unmapped} MCD indices could not be "
                          f"mapped to Blender verts in '{matched_key}' {vg_name}")
            else:
                # No remap available — use indices directly and validate bounds
                max_vert = len(target_obj.data.vertices)
                blender_indices = [idx for idx in mcd_indices if idx < max_vert]
                oob = len(mcd_indices) - len(blender_indices)
                if oob > 0:
                    total_oob_drops += oob
                    drop_details.append(f"{matched_key}/{vg_name}: {oob} out-of-bounds")
                    dwarn(f"[HPL Roundtrip] Warning: {oob} out-of-bounds vertices in "
                          f"'{matched_key}' {vg_name} (mesh has {max_vert} verts)")

            if blender_indices:
                vg.add(blender_indices, 1.0, 'REPLACE')
                applied_count += 1
                details.append(f"{matched_key}/{vg_name}: {len(blender_indices)} verts")
                dlog(f"[HPL Roundtrip] Applied {len(blender_indices)} verts to "
                      f"{target_obj.name} → {vg_name}")

    # Surface accumulated drops to the operator's info bar if a report fn
    # was supplied. Console always has the per-group detail above.
    if (total_oob_drops or total_unmapped) and report_fn is not None:
        try:
            report_fn({'WARNING'},
                f"HPL apply dropped {total_oob_drops} out-of-bounds + "
                f"{total_unmapped} unmapped indices: " + "; ".join(drop_details))
        except Exception:
            pass
    
    # Build summary
    mesh_names = list(base_meshes.keys())
    if applied_count > 0:
        msg = f"Applied HPL to {', '.join(mesh_names)} ({applied_count} groups populated)"
    else:
        msg = f"Created empty HPL groups on {', '.join(mesh_names)} (HPL had no vertex data)"

    # Force Blender to re-read the vertex groups. On 4.x/5.x the Properties
    # Editor doesn't refresh vertex_groups after vg.add() until something
    # triggers it — the groups exist in data but don't show in the panel.
    # Three nudges: data.update() (depsgraph), active_index reset (forces the
    # Vertex Groups list to redraw), tag_redraw on viewports + Properties.
    for mesh_key, obj in base_meshes.items():
        obj.data.update()
        # Make an HPL group active so the list widget re-renders.
        vg_ring = obj.vertex_groups.get('HPL_Ring')
        if vg_ring is not None:
            obj.vertex_groups.active_index = vg_ring.index

    try:
        import bpy as _bpy_ui
        for window in _bpy_ui.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type in {'PROPERTIES', 'VIEW_3D', 'OUTLINER'}:
                    area.tag_redraw()
    except Exception as e:
        # Non-fatal — groups are still correctly applied, only UI may lag
        # until the user clicks into the Properties Editor.
        derror(f"[HPL Roundtrip] UI redraw tag failed (non-fatal): {e}")

    dlog(f"[HPL Roundtrip] {msg}")
    if details:
        for d in details:
            dlog(f"[HPL Roundtrip]   {d}")

    return True, msg


# ═══════════════════════════════════════════════════════════════════════════
#  EXPORT SPLIT SIMULATION — expand HPL indices for remap-OFF exports
# ═══════════════════════════════════════════════════════════════════════════

def _simulate_export_split(obj):
    """Simulate the export pipeline (triangulate + UV seam split) on a temp
    copy of a mesh and return a mapping from pre-split → post-split indices.

    When exporting with vertex remap OFF, the MCD gets vertices in
    post-split Blender order. HPL vertex groups reference pre-split
    indices. This bridges the gap so HPL works without re-exporting
    the baseModel first.

    Returns:
        dict {pre_split_idx: [post_split_idx, clone1, ...]}
        or None if the mesh didn't need splitting (identity).

    Not cached (rebuilt per export pass) despite being the slow part: a stale
    split map silently corrupts the round-trip (HPL indices land on wrong
    clones, mask drifts off the surface), and correct invalidation (vertex/
    polygon count, UV hash, split-affecting transforms) needs careful design.
    """
    import bmesh as _bm
    import numpy as np

    mesh = obj.data
    pre_count = len(mesh.vertices)
    if pre_count == 0 or len(mesh.polygons) == 0:
        return None

    # Snapshot pre-split positions
    pre_coords = np.empty(pre_count * 3, dtype=np.float32)
    mesh.vertices.foreach_get('co', pre_coords)
    pre_coords = pre_coords.reshape((pre_count, 3))

    def _to_key(xyz):
        return (round(float(xyz[0]), 5), round(float(xyz[1]), 5), round(float(xyz[2]), 5))

    pos_to_pre = {}
    for i in range(pre_count):
        k = _to_key(pre_coords[i])
        if k not in pos_to_pre:
            pos_to_pre[k] = i

    # Duplicate into temp object
    temp_mesh = mesh.copy()
    temp_obj = bpy.data.objects.new("__hpl_temp__", temp_mesh)
    bpy.context.scene.collection.objects.link(temp_obj)
    bpy.context.view_layer.objects.active = temp_obj
    temp_obj.select_set(True)

    try:
        bpy.ops.object.mode_set(mode='EDIT')
        bm = _bm.from_edit_mesh(temp_mesh)

        # Triangulate (same as format_game_uv_seams)
        non_tris = [f for f in bm.faces if len(f.verts) != 3]
        if non_tris:
            _bm.ops.triangulate(bm, faces=bm.faces[:], ngon_method='EAR_CLIP')

        # Mark UV seams + split edges (same as check_uv_seams path)
        uv_layer = bm.loops.layers.uv.active
        if uv_layer:
            for edge in bm.edges:
                edge.seam = False

            for edge in bm.edges:
                if len(edge.link_loops) != 2:
                    continue
                la = edge.link_loops[0]
                lb = edge.link_loops[1]
                la_n = la.link_loop_next if la.link_loop_next.vert == edge.other_vert(la.vert) else la.link_loop_prev
                lb_n = lb.link_loop_next if lb.link_loop_next.vert == edge.other_vert(lb.vert) else lb.link_loop_prev
                t = 0.0001
                m0 = abs(la[uv_layer].uv.x - lb_n[uv_layer].uv.x) < t and abs(la[uv_layer].uv.y - lb_n[uv_layer].uv.y) < t
                m1 = abs(la_n[uv_layer].uv.x - lb[uv_layer].uv.x) < t and abs(la_n[uv_layer].uv.y - lb[uv_layer].uv.y) < t
                if not (m0 and m1):
                    edge.seam = True

            seam_edges = [e for e in bm.edges if e.seam]
            if seam_edges:
                _bm.ops.split_edges(bm, edges=seam_edges)

        _bm.update_edit_mesh(temp_mesh)
        bpy.ops.object.mode_set(mode='OBJECT')

        post_count = len(temp_mesh.vertices)
        if post_count == pre_count:
            return None

        post_coords = np.empty(post_count * 3, dtype=np.float32)
        temp_mesh.vertices.foreach_get('co', post_coords)
        post_coords = post_coords.reshape((post_count, 3))

        mapping = {}
        for post_idx in range(post_count):
            k = _to_key(post_coords[post_idx])
            pre_idx = pos_to_pre.get(k)
            if pre_idx is not None:
                if pre_idx not in mapping:
                    mapping[pre_idx] = []
                mapping[pre_idx].append(post_idx)

        dlog(f"[HPL Roundtrip] Simulated export split on '{obj.name}': "
              f"{pre_count} → {post_count} verts, "
              f"{post_count - pre_count} clones")
        return mapping

    except Exception as e:
        derror(f"[HPL Roundtrip] _simulate_export_split failed: {e}")
        import traceback; traceback.print_exc()
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass
        return None

    finally:
        # Narrowed to Exception so KeyboardInterrupt / SystemExit still
        # propagate. None of these cleanups are critical for correctness;
        # they just keep the scene tidy if the user aborts mid-simulation.
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass
        try:
            bpy.data.objects.remove(temp_obj, do_unlink=True)
        except Exception:
            pass
        try:
            if temp_mesh and temp_mesh.users == 0:
                bpy.data.meshes.remove(temp_mesh)
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════════════════
#  UPDATE — Regenerate HPL from scene vertex groups for export
# ═══════════════════════════════════════════════════════════════════════════

def scene_has_hpl_edits(scope_objects=None):
    """Check if the canonical baseModel meshes have HPL_Ring/HPL_Entrance groups.

    Routes through find_basemodel_meshes() rather than walking bpy.data.objects
    so stale duplicates (M_Body.001 with leftover groups) can't trip the check
    — otherwise "scene has edits" and collect_hpl_from_scene would both pick up
    the duplicate and the result was a coin flip vs. the user's intent.

    Parameters
    ----------
    scope_objects : iterable of bpy.types.Object, optional
        Forwarded to find_basemodel_meshes for collection-scoped resolution, so
        the check sees only the basemodel sharing a collection with the
        selection (not a second loaded basemodel).
    """
    basemodel = find_basemodel_meshes(scope_objects=scope_objects)
    for obj in basemodel.values():
        for vg in obj.vertex_groups:
            if vg.name in ALL_VG_NAMES:
                return True
    return False


def collect_hpl_from_scene(use_vertex_remap=False, scope_objects=None):
    """Collect HPL masking data from all scene meshes with HPL_ vertex groups.
    
    Two modes based on the export's vertex remap checkbox:
    
      use_vertex_remap=True (remap ON):
        Remap Blender indices → MCD order via vcmodel_vertex_remap.
        HPL matches vanilla baseModel. Standard workflow.
    
      use_vertex_remap=False (remap OFF):
        The exported baseModel MCD has vertices in post-split Blender
        order (after triangulate + UV seam split). HPL vertex groups
        reference pre-split Blender indices. We simulate the export
        split on a temp copy of each mesh and expand HPL indices to
        include all UV seam clones — so the HPL just works without
        requiring a double-export of the baseModel.
    
    Returns:
        tuple (sceneLODs, sceneMeshes, flagCeiling) ready for getBinaryHPL(),
        or (None, None, None) if no HPL data found.
    """
    scene_maps = []
    scene_meshes = []
    flag_ceiling = -1

    # Flush depsgraph + view-layer before reading groups. Group-modifying
    # operators (Generate Empty HPL, Apply HPL, weight paint, auto-mask boolean)
    # may have state not yet flushed to obj.data.vertices; without this the read
    # returns the PREVIOUS state ("clicked Generate Empty but export still has
    # masking").
    try:
        bpy.context.view_layer.update()
    except Exception:
        pass

    # find_basemodel_meshes picks ONE M_Head/M_Body via active/selected/name
    # ranking, so we don't read stale HPL groups off duplicates (M_Body.001,
    # an attire with a body slot). bpy.data.objects order is implementation-
    # defined, so iterating it directly was nondeterministic. scope_objects
    # forwards the selection so the scope filter restricts to the basemodel
    # sharing a collection with the export — preventing a SECOND basemodel's
    # HPL from leaking in.
    basemodel = find_basemodel_meshes(scope_objects=scope_objects)
    target_objs = list(basemodel.values())
    if not target_objs:
        dlog("[HPL Roundtrip] No baseModel meshes resolved — nothing to collect.")
        return None, None, None

    dlog(f"[HPL Roundtrip] Collecting HPL data (use_vertex_remap={use_vertex_remap}) "
         f"from baseModel: {[o.name for o in target_objs]}")

    for obj in target_objs:
        mesh_name = obj.data.name
        if '.' in mesh_name:
            mesh_name = mesh_name.rsplit('.', 1)[0]
        
        # Pick HPL groups by NAME (ALL_VG_NAMES), not "anything containing
        # HPL_". The engine reads only flag 0=Ring, 1=Entrance. Accepting any
        # HPL_-containing name let leftover/duplicate groups sneak in with the
        # same flag as HPL_Ring; getBinaryHPL's getLODsFromFlagIndex returns the
        # FIRST match, so a stale group could silently win ("HPL won't apply on
        # some meshes"). Iterate in ALL_VG_NAMES order for deterministic flags.
        hpl_groups = [vg for vg in (obj.vertex_groups.get(n) for n in ALL_VG_NAMES) if vg is not None]
        if not hpl_groups:
            continue
        
        dlog(f"[HPL Roundtrip] Found HPL groups on '{obj.name}' "
              f"(mesh: '{mesh_name}'): {[vg.name for vg in hpl_groups]}")
        
        # Remap ON: use stored vertex remap (Blender → MCD order)
        # Remap OFF: simulate export split (pre-split → post-split Blender order)
        vremap = None
        split_map = None
        if use_vertex_remap:
            vremap = _get_vertex_remap(obj)
            if vremap:
                dlog(f"[HPL Roundtrip]   vertex_remap: {len(vremap)} entries (Blender → MCD)")
            else:
                dlog(f"[HPL Roundtrip]   no vertex_remap — using Blender indices as-is")
        else:
            split_map = _simulate_export_split(obj)
            if split_map:
                dlog(f"[HPL Roundtrip]   export split simulated: {len(split_map)} verts have clones")
            else:
                dlog(f"[HPL Roundtrip]   no split needed — using Blender indices as-is")
        
        # Batched vertex-group membership read: build group_index → [vert_index]
        # in ONE walk, then look up each HPL group O(1). The per-group nested
        # loop re-crossed Python↔C per vertex (~560k crossings on a 70k mesh ×
        # 8 groups).
        hpl_group_indices = {vg.index for vg in hpl_groups}
        group_to_verts = {gi: [] for gi in hpl_group_indices}
        for v in obj.data.vertices:
            for g in v.groups:
                if g.group in hpl_group_indices:
                    group_to_verts[g.group].append(v.index)

        # Inverse of FLAG_NAMES — module-top constant; vg names here are
        # guaranteed to be in this map since we filtered earlier.
        name_to_flag = {n: f for f, n in FLAG_NAMES.items()}
        for vg in hpl_groups:
            scene_flag = name_to_flag.get(vg.name, 0)

            blender_indices = group_to_verts.get(vg.index, [])

            if not blender_indices:
                dlog(f"[HPL Roundtrip]   {vg.name}: 0 vertices (empty group)")
                export_indices = []
            elif vremap:
                export_indices, unmapped = _blender_to_mcd_indices(blender_indices, vremap)
                if unmapped > 0:
                    dwarn(f"[HPL Roundtrip]   {vg.name}: WARNING — {unmapped} indices unmapped")
                dlog(f"[HPL Roundtrip]   {vg.name}: {len(blender_indices)} Blender → "
                      f"{len(export_indices)} MCD indices (flag={scene_flag})")
            elif split_map:
                # Expand pre-split indices to include all post-split clones
                export_indices = []
                for bi in blender_indices:
                    clones = split_map.get(bi)
                    if clones:
                        export_indices.extend(clones)
                    else:
                        # Vertex wasn't split — same index in post-split space
                        export_indices.append(bi)
                dlog(f"[HPL Roundtrip]   {vg.name}: {len(blender_indices)} pre-split → "
                      f"{len(export_indices)} post-split indices (flag={scene_flag})")
            else:
                export_indices = blender_indices
                dlog(f"[HPL Roundtrip]   {vg.name}: {len(blender_indices)} verts (flag={scene_flag})")
            
            lod_entry = modelLods(name=mesh_name, flag=scene_flag, indices=export_indices)
            scene_maps.append(lod_entry)
            
            if scene_flag > flag_ceiling:
                flag_ceiling = scene_flag
            if mesh_name not in scene_meshes:
                scene_meshes.append(mesh_name)
    
    if not scene_maps:
        dlog(f"[HPL Roundtrip] No HPL data collected — no HPL vertex groups found")
        return None, None, None
    
    dlog(f"[HPL Roundtrip] Collected: {len(scene_maps)} entries across "
          f"{scene_meshes} (flagCeiling={flag_ceiling})")
    return scene_maps, scene_meshes, flag_ceiling


def generate_hpl_substream(use_vertex_remap=False, scope_objects=None):
    """Generate an HPL sub-stream blob from scene vertex groups.
    
    use_vertex_remap: when True, converts Blender indices to MCD order.
    When False, uses Blender indices directly.

    scope_objects: forwarded to collect_hpl_from_scene → find_basemodel_meshes
    for collection-scoped basemodel resolution. Pass the export selection
    (getMeshSelection()) so HPL is collected from only the basemodel that
    shares a collection with the meshes being exported — preventing
    bleed-over from a second basemodel coexisting in the scene.

    Returns:
        bytes: sub-stream blob [u32 size][HPL! tag][HPL data], or None
    """
    scene_maps, scene_meshes, flag_ceiling = collect_hpl_from_scene(
        use_vertex_remap, scope_objects=scope_objects)
    if scene_maps is None:
        dlog(f"[HPL Roundtrip] generate_hpl_substream: no scene data collected, returning None")
        return None
    
    # Generate raw HPL binary using existing writer
    hpl_data = getBinaryHPL(scene_maps, scene_meshes, flag_ceiling)
    
    if not hpl_data or len(hpl_data) < 8:
        dlog(f"[HPL Roundtrip] generate_hpl_substream: getBinaryHPL returned "
              f"{'None' if not hpl_data else f'{len(hpl_data)} bytes (too small)'}")
        return None
    
    # Wrap as sub-stream: [u32 file_size][outer_tag][file_data]
    blob = struct.pack('<I', len(hpl_data)) + HPL_OUTER_TAG + hpl_data
    
    dlog(f"[HPL Roundtrip] Generated HPL sub-stream: {len(hpl_data)} bytes HPL data, "
          f"{len(blob)} bytes total blob, {len(scene_maps)} entries across {scene_meshes}")
    
    return blob
