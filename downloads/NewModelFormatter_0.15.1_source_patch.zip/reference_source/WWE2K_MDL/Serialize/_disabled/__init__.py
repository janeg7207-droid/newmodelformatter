# This folder is NOT a runtime Python package.
#
# It is a quarantine area for serialize modules that are not currently
# wired into the active addon. See README.md in this directory.
#
# Do not import anything from `Serialize._disabled.*` in active code.
# If you need a module from here, move it back to `Serialize/` and
# re-validate its call sites first.
