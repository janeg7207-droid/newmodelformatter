"""
MCD Patcher - Add M_Head reference back to mesh name table

When exporting from Blender, empty mesh references like M_Head get dropped.
The WDF needs M_Head in the mesh list to work. This patcher adds it back.
"""

import struct
import os
from ..Link.log import dlog


def find_mesh_names_region(data):
    """Find the mesh names region in MCD"""
    # Mesh names appear before BONE chunk
    bone_pos = data.find(b'BONE')
    if bone_pos < 0:
        return None, None
    
    # Find first M_ before BONE
    pos = 0
    first_mesh = -1
    while True:
        pos = data.find(b'M_', pos)
        if pos < 0 or pos > bone_pos:
            break
        if first_mesh < 0:
            first_mesh = pos
        pos += 1
    
    return first_mesh, bone_pos


def get_mesh_names(data, start, end):
    """Extract mesh names from region"""
    names = []
    pos = start
    while pos < end:
        m_pos = data.find(b'M_', pos)
        if m_pos < 0 or m_pos >= end:
            break
        
        # Find null terminator
        null_pos = data.find(b'\x00', m_pos)
        if null_pos < 0 or null_pos > end:
            break
        
        name = data[m_pos:null_pos].decode('ascii', errors='replace')
        names.append((m_pos, name))
        pos = null_pos + 1
    
    return names


def patch_mcd_add_mhead(input_path, output_path=None):
    """
    Add M_Head to MCD mesh name table if missing.
    
    M_Head should appear after M_Combinations in the name list.
    """
    if output_path is None:
        output_path = input_path.replace('.mcd', '_patched.mcd')
    
    with open(input_path, 'rb') as f:
        data = bytearray(f.read())
    
    dlog(f"[MCD Patch] Input: {input_path} ({len(data)} bytes)")
    
    # Find mesh names region
    start, end = find_mesh_names_region(data)
    if start is None:
        dlog("[MCD Patch] Could not find mesh names region")
        return False
    
    dlog(f"[MCD Patch] Mesh names region: {start} - {end}")
    
    # Get current mesh names
    names = get_mesh_names(data, start, end)
    dlog(f"[MCD Patch] Found {len(names)} mesh names:")
    for pos, name in names:
        print(f"  {pos}: {name}")
    
    # Check if M_Head already exists
    if any(name == 'M_Head' for _, name in names):
        dlog("[MCD Patch] M_Head already exists, no patch needed")
        return True
    
    # Find M_Combinations position - M_Head should go after it
    combo_info = next(((p, n) for p, n in names if n == 'M_Combinations'), None)
    if combo_info is None:
        dlog("[MCD Patch] M_Combinations not found, cannot patch")
        return False
    
    combo_pos, _ = combo_info
    combo_end = combo_pos + len(b'M_Combinations\x00')
    
    dlog(f"[MCD Patch] Inserting M_Head after M_Combinations at offset {combo_end}")
    
    # Insert M_Head\x00 after M_Combinations\x00
    insert_data = b'M_Head\x00'
    new_data = data[:combo_end] + insert_data + data[combo_end:]
    
    # Write output
    with open(output_path, 'wb') as f:
        f.write(new_data)
    
    dlog(f"[MCD Patch] Saved patched MCD to: {output_path}")
    dlog(f"[MCD Patch] Added {len(insert_data)} bytes")
    
    return True


if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print("Usage: python mcd_patch_mhead.py <input.mcd> [output.mcd]")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else None
    
    if patch_mcd_add_mhead(input_path, output_path):
        print("Patch successful!")
    else:
        print("Patch failed!")
        sys.exit(1)
