"""
Cross-version skeleton converter — DISABLED bulk logic.

This module contains the implementation that used to live in
`Serialize/skeleton_remap.py` below line 46. It is preserved here for
potential revival but is NOT imported by the active addon.

Original entry point `remap_skeleton_for_export(compile_target)` was
hard-disabled (returns False immediately) in production because version
detection was false-positiving on v2.15 (0x2F) MCD files whose 2K25-era
bones triggered the remap path, corrupting models that should have been
left untouched. Re-enable only once detection and remap logic are solid,
and after re-validating every call site.

If you revive any function here:
  1. Move it back to `Serialize/skeleton_remap.py` (or a sibling module
     under `Serialize/`).
  2. Re-validate that its `..Link.*`, `..SkinModel.*`, `..Blender.*`
     relative imports still resolve from its new location.
  3. The constants `BONES_ONLY_IN_25`, `BONES_ONLY_IN_26`, `FACE_BONES`,
     `BASEMODEL_MESHES`, `TEMPLATE_FILENAME`, `RENAME_25_TO_26` are
     duplicated below for self-containment — the live copy lives in
     `Serialize/skeleton_remap.py`. Keep them in sync if you edit either.

This file is intentionally NOT runtime-importable from `Serialize._disabled`.
See README.md in this directory.
"""

import bpy
import ctypes
import os
import json
# NOTE: When this module lived at Serialize/skeleton_remap.py, the log
# import was `from ..Link.log import dlog, dwarn, derror`. From
# Serialize/_disabled/ that two-dot prefix would resolve to `Serialize`,
# which has no `Link` submodule. If you revive this file, restore it to
# `Serialize/` (or fix the relative depth) before importing.
from ..Link.log import dlog, dwarn, derror

# ─────────────────────────────────────────────────────────────────────────────
# Constants (duplicated from the live Serialize/skeleton_remap.py).
# The live copy is the source of truth — these are here so the helpers
# below remain self-contained if revived.
# ─────────────────────────────────────────────────────────────────────────────

BONES_ONLY_IN_25 = {
    'H_Bicep_L', 'H_Bicep_R', 'H_Delt_Back_L', 'H_Delt_Back_R',
    'H_Delt_Front_L', 'H_Delt_Front_R', 'H_Delt_L_OS01', 'H_Delt_R_OS01',
    'H_Delt_Top_L', 'H_Delt_Top_R', 'H_Ebw_In_L', 'H_Ebw_In_R',
    'H_Lat_L', 'H_Lat_R', 'H_Pec_L', 'H_Pec_R',
}

BONES_ONLY_IN_26 = {
    'H_Pec_L_1', 'H_Pec_L_2', 'H_Pec_L_3',
    'H_Lat_L_1', 'H_Lat_L_2', 'H_Lat_L_3',
    'H_Delt_L_1', 'H_Delt_L_2',
    'H_Bicep_L_1', 'H_Shld_Pad_L',
    'H_Neck_L_1', 'H_Neck_L_2',
}

FACE_BONES = {
    'J_Jaw', 'J_upperTeeth', 'J_lowerTeeth', 'J_Eye_L', 'J_Eye_R',
    'J_Tongue1', 'J_Tongue2', 'J_Tongue3', 'J_Tongue4'
}

BASEMODEL_MESHES = {
    'M_Head', 'M_Head_Caruncle', 'M_EYE', 'M_Teeth',
    'M_Tongue', 'M_MouthBag', 'M_transB_eyelash', 'M_Body'
}

TEMPLATE_FILENAME = 'baseModel_ref_26.mcd'

RENAME_25_TO_26 = {
    'H_Delt_L_OS01': 'H_Delt_L_1',
    'H_Delt_R_OS01': 'H_Delt_R_1',
    'H_Bicep_L':     'H_Bicep_L_1',
    'H_Bicep_R':     'H_Bicep_R_1',
}


def _detect_source_version(mesh_objects):
    """Detect whether the model uses 2K25 or 2K26 skeleton.

    Uses a scoring approach: count how many indicator bones from each version
    are present, then compare. This avoids false positives from partially
    renamed bones (e.g. H_Delt_L_OS01 → H_Delt_L_1 which appears in both
    the rename target set and BONES_ONLY_IN_26).

    Also checks the armature bones directly, not just vertex groups, since
    vertex groups can be incomplete on attire meshes.
    """
    # Bones that exist as rename targets should not count as 2K26 indicators,
    # because they can appear on a 2K25 model that was partially renamed.
    rename_targets = set(RENAME_25_TO_26.values())
    exclusive_26 = BONES_ONLY_IN_26 - rename_targets

    score_25 = 0
    score_26 = 0

    # Check vertex groups across all mesh objects
    for obj in mesh_objects:
        if obj.type != 'MESH':
            continue
        for name in BONES_ONLY_IN_25:
            if obj.vertex_groups.get(name):
                score_25 += 1
        for name in exclusive_26:
            if obj.vertex_groups.get(name):
                score_26 += 1

    # Also check armature bones directly (more reliable for attire meshes
    # that may not have vertex groups for every bone)
    armature_obj = _get_armature(mesh_objects)
    if armature_obj and armature_obj.data:
        for bone in armature_obj.data.bones:
            if bone.name in BONES_ONLY_IN_25:
                score_25 += 2  # weight armature bones higher
            if bone.name in exclusive_26:
                score_26 += 2

    if score_25 == 0 and score_26 == 0:
        return None

    if score_25 > score_26:
        return "2K25"
    elif score_26 > score_25:
        return "2K26"
    else:
        # Tie-breaker: if ANY 2K25-exclusive bone exists, it's 2K25
        # (a true 2K26 model would never have these)
        for obj in mesh_objects:
            if obj.type != 'MESH':
                continue
            for name in BONES_ONLY_IN_25:
                if obj.vertex_groups.get(name):
                    return "2K25"
        return "2K26"


def _is_basemodel_export(mesh_objects):
    for obj in mesh_objects:
        if obj.type != 'MESH':
            continue
        name = obj.data.name
        if '.' in name:
            name = name.rsplit('.', 1)[0]
        if name in BASEMODEL_MESHES:
            return True
    return False


def _ensure_vg(obj, name):
    vg = obj.vertex_groups.get(name)
    if not vg:
        vg = obj.vertex_groups.new(name=name)
    return vg


def _get_armature(mesh_objects):
    for obj in mesh_objects:
        if obj.type != 'MESH':
            continue
        for mod in obj.modifiers:
            if mod.type == 'ARMATURE' and mod.object:
                return mod.object
        if obj.parent and obj.parent.type == 'ARMATURE':
            return obj.parent
    return None


def _get_template_path():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(script_dir, TEMPLATE_FILENAME)
    return path if os.path.exists(path) else None


def _load_template_model(template_path):
    from ..Link.wrapper import ExternalLibary
    from ..SkinModel.skinmodel import vCSkinModel
    module = ExternalLibary()
    model_file = ctypes.c_void_p()
    skin_model = module.load_model(
        template_path.encode('utf-8'), ctypes.byref(model_file), False)
    if not model_file or not skin_model:
        return None, None, None
    return vCSkinModel(skin_model), model_file, module


def _load_ref_skeleton():
    ref_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'skeleton_ref_26.json')
    if not os.path.exists(ref_path):
        return None
    with open(ref_path, 'r') as f:
        return json.load(f)


def _find_sibling_basemodel():
    for col in bpy.data.collections:
        sidecar = col.get("vcmodel_roundtrip_sidecar")
        if sidecar and os.path.exists(sidecar):
            attire_dir = os.path.dirname(sidecar)
            char_dir = os.path.dirname(attire_dir)
            basemodel_dir = os.path.join(char_dir, "BaseModel")
            if os.path.isdir(basemodel_dir):
                for f in os.listdir(basemodel_dir):
                    if f.lower().endswith('.mcd') and 'basemodel' in f.lower():
                        return os.path.join(basemodel_dir, f)
    return None


def _import_basemodel(path):
    from ..Link.interface import loadModelFile
    before_objects = set(bpy.data.objects.keys())
    before_collections = set(bpy.data.collections.keys())
    loadModelFile(path, {
        'import_shape_keys': False,
        'load_textures': False,
        'split_material_groups': False,
        'load_attachment_points': False,
    })
    new_objects = [bpy.data.objects[n] for n in (set(bpy.data.objects.keys()) - before_objects)]
    new_collections = [bpy.data.collections[n] for n in (set(bpy.data.collections.keys()) - before_collections)]
    body_obj = None
    for obj in new_objects:
        if obj.type == 'MESH' and 'M_Body' in obj.data.name:
            body_obj = obj
            break
    return body_obj, new_objects, new_collections


def _cleanup_imported(objects, collections):
    for obj in objects:
        try:
            data = obj.data
            bpy.data.objects.remove(obj, do_unlink=True)
            if data and data.users == 0:
                if hasattr(data, 'vertices'):
                    bpy.data.meshes.remove(data)
                elif hasattr(data, 'bones'):
                    bpy.data.armatures.remove(data)
        except:
            pass
    for col in collections:
        try:
            bpy.data.collections.remove(col)
        except:
            pass


def _remap_armature_inplace(mesh_objects):
    armature_obj = _get_armature(mesh_objects)
    if not armature_obj:
        return
    ref = _load_ref_skeleton()
    if not ref:
        return

    prev_active = bpy.context.view_layer.objects.active
    bpy.context.view_layer.objects.active = armature_obj
    bpy.ops.object.mode_set(mode='EDIT')
    armature = armature_obj.data

    for old_name, new_name in RENAME_25_TO_26.items():
        ebone = armature.edit_bones.get(old_name)
        if ebone:
            ebone.name = new_name

    strip_set = BONES_ONLY_IN_25 - set(RENAME_25_TO_26.keys())
    for strip_name in strip_set:
        ebone = armature.edit_bones.get(strip_name)
        if ebone:
            for child in list(ebone.children):
                child.parent = ebone.parent
            armature.edit_bones.remove(ebone)

    import struct as _struct
    from mathutils import Matrix, Vector

    bones_added = 0
    for bone_name, ref_data in ref.items():
        if armature.edit_bones.get(bone_name):
            continue
        parent_name = ref_data.get('parent')
        parent_bone = armature.edit_bones.get(parent_name) if parent_name else None
        if not parent_bone and parent_name:
            continue
        raw_bytes = bytes.fromhex(ref_data['raw_hex'])
        px, py, pz, rx, ry, rz = _struct.unpack_from('<6f', raw_bytes, 0)
        rot_x = Matrix.Rotation(rx, 4, 'X')
        rot_y = Matrix.Rotation(ry, 4, 'Y')
        rot_z = Matrix.Rotation(rz, 4, 'Z')
        local_mat = (rot_z @ rot_y @ rot_x).copy()
        local_mat[0][3] = pz; local_mat[1][3] = py; local_mat[2][3] = px
        world_mat = parent_bone.matrix @ local_mat if parent_bone else local_mat
        new_bone = armature.edit_bones.new(bone_name)
        new_bone.tail = Vector((0.0, 1.0, 0.0)) * 0.01
        if parent_bone:
            new_bone.parent = parent_bone
        new_bone.matrix = world_mat
        if new_bone.length < 0.00001:
            new_bone.length = 0.0001
        if ref_data.get('jig_index', -1) >= 0:
            new_bone["vcmodel_jig_index"] = ref_data['jig_index']
            if ref_data.get('jig_params'):
                jig_bytes = b''.join(_struct.pack('<f', v) for v in ref_data['jig_params'])
                new_bone["vcmodel_jig_params"] = jig_bytes.hex()
        bones_added += 1

    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.view_layer.objects.active = prev_active
    dlog(f"[MDL Addon]   Armature updated: {bones_added} bones added")


# ═══════════════════════════════════════════════════════════════════════════
#  ATTIRE PATH
# ═══════════════════════════════════════════════════════════════════════════

def _do_attire_remap(mesh_objects):
    dlog(f"[MDL Addon]   Mode: Attire (heat seek)")

    # 1. Save original armature ref
    original_armature = _get_armature(mesh_objects)

    # 2. Update armature to 2K26
    _remap_armature_inplace(mesh_objects)

    # 3. Find and import the 2K26 baseModel
    basemodel_path = _find_sibling_basemodel()
    if not basemodel_path:
        basemodel_path = _get_template_path()
    if not basemodel_path:
        dwarn(f"[MDL Addon]   WARNING: No baseModel found")
        return

    dlog(f"[MDL Addon]   Importing: {os.path.basename(basemodel_path)}")
    body_obj, imported_objects, imported_collections = _import_basemodel(basemodel_path)
    if not body_obj:
        dwarn(f"[MDL Addon]   WARNING: M_Body not found")
        _cleanup_imported(imported_objects, imported_collections)
        return

    # 4. For each attire mesh: clear groups, transfer from body
    from ..Blender.Extras.streamline4_1 import transfer_weights_mdt

    for obj in mesh_objects:
        if obj.type != 'MESH':
            continue
        obj.vertex_groups.clear()
        transfer_weights_mdt(body_obj, obj, normalize=True, threshold=0.01)
        dlog(f"[MDL Addon]   Transferred: {obj.name} ({len(obj.vertex_groups)} groups)")

    # 5. Make sure we're in object mode
    if bpy.context.mode != 'OBJECT':
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except:
            pass

    # 6. Restore parent + armature modifier to ORIGINAL attire armature
    if original_armature:
        for obj in mesh_objects:
            if obj.type != 'MESH':
                continue
            # Restore parent without inverse (same as manual workflow)
            obj.parent = original_armature
            obj.matrix_parent_inverse.identity()
            # Ensure armature modifier points to the right armature
            arm_mod = None
            for mod in obj.modifiers:
                if mod.type == 'ARMATURE':
                    arm_mod = mod
                    break
            if arm_mod:
                arm_mod.object = original_armature
            else:
                obj.modifiers.new(type='ARMATURE', name='Armature').object = original_armature

    # 7. Clean up imported baseModel
    _cleanup_imported(imported_objects, imported_collections)

    # 8. Force depsgraph update so export pipeline sees fresh data
    bpy.context.view_layer.update()

    dlog(f"[MDL Addon]   Heat seek complete")


# ═══════════════════════════════════════════════════════════════════════════
#  BASEMODEL PATH (from doc 5 — template transfer + armature swap)
# ═══════════════════════════════════════════════════════════════════════════

def _build_temp_armature(skeleton):
    from math import radians
    arm_data = bpy.data.armatures.new("__vctemp_armature")
    arm_obj = bpy.data.objects.new("__vctemp_armature", arm_data)
    bpy.context.scene.collection.objects.link(arm_obj)
    arm_obj.rotation_euler[0] = radians(-90)
    bpy.context.view_layer.objects.active = arm_obj
    bpy.ops.object.mode_set(mode='EDIT')
    bone_map = {}
    for bd in skeleton.bones:
        if not bd.name: continue
        eb = arm_data.edit_bones.new(bd.name)
        eb.head = (0, 0, 0); eb.tail = (0, 0.01, 0)
        eb.matrix = bd.matrix
        if eb.length < 0.00001: eb.length = 0.0001
        bone_map[bd.name] = eb
    for bd in skeleton.bones:
        if not bd.name or bd.name not in bone_map: continue
        if bd.parent is not None:
            pb = skeleton.bones[bd.parent]
            if pb.name and pb.name in bone_map:
                bone_map[bd.name].parent = bone_map[pb.name]
    bpy.ops.object.mode_set(mode='OBJECT')
    return arm_obj

def _build_temp_mesh(mesh_data, armature_obj):
    if not mesh_data.vertices or len(mesh_data.vertices) == 0: return None
    name = f"__vctemp_{mesh_data.mesh_name}"
    bm = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, bm)
    bpy.context.scene.collection.objects.link(obj)
    bm.from_pydata(mesh_data.vertices, [], mesh_data.index_list if mesh_data.index_list else [])
    bm.update(); bm.validate()
    skin = mesh_data.skin
    num_verts = len(bm.vertices)
    if skin and skin.groups:
        for i, gn in enumerate(skin.groups):
            vg = obj.vertex_groups.new(name=gn)
            for vid, w in enumerate(skin.weights[i]):
                if vid >= num_verts: break
                if w > 0.0: vg.add([vid], w, 'ADD')
    if armature_obj:
        obj.parent = armature_obj
        obj.modifiers.new(type='ARMATURE', name="Armature").object = armature_obj
    return obj

def _find_matching_template(target_name, temp_objects):
    for obj in temp_objects:
        if obj.name.replace("__vctemp_", "") == target_name: return obj
    body_obj = head_obj = None
    for obj in temp_objects:
        tn = obj.name.replace("__vctemp_", "")
        if 'Body' in tn: body_obj = obj
        if tn == 'M_Head': head_obj = obj
    head_set = {'M_Head', 'M_Head_Caruncle', 'M_EYE', 'M_Teeth',
                'M_Tongue', 'M_MouthBag', 'M_transB_eyelash'}
    return head_obj if target_name in head_set else body_obj

def _transfer_weights_from_template(source_obj, target_obj):
    """
    Transfer vertex groups from template source to target using MeshDataTransfer.
    Replaces the old DATA_TRANSFER modifier approach with direct barycentric
    interpolation — normalized, thresholded, UV-space-aware.
    Falls back to _manual_weight_copy only if MeshDataTransfer fails.
    """
    from ..Blender.Extras.streamline4_1 import transfer_weights_mdt
    success = transfer_weights_mdt(source_obj, target_obj,
                                    normalize=True, threshold=0.01)
    if not success:
        derror(f"[MDL] _transfer_weights_from_template: MDT failed, falling back to manual copy")
        _manual_weight_copy(source_obj, target_obj)

def _manual_weight_copy(source_obj, target_obj):
    import mathutils
    src_mesh = source_obj.data
    kd = mathutils.kdtree.KDTree(len(src_mesh.vertices))
    for i, v in enumerate(src_mesh.vertices):
        kd.insert(source_obj.matrix_world @ v.co, i)
    kd.balance()
    for src_vg in source_obj.vertex_groups:
        if not (src_vg.name.startswith('J_') or src_vg.name.startswith('H_') or src_vg.name == 'vector'): continue
        tgt_vg = _ensure_vg(target_obj, src_vg.name)
        for v in target_obj.data.vertices:
            co, idx, _ = kd.find(target_obj.matrix_world @ v.co)
            if idx is None: continue
            try:
                w = src_vg.weight(idx)
                if w > 0.0: tgt_vg.add([v.index], w, 'REPLACE')
            except RuntimeError: continue

def _stash_face_weights(mesh_objects):
    stash = {}
    for obj in mesh_objects:
        if obj.type != 'MESH': continue
        od = {}
        for bn in FACE_BONES:
            vg = obj.vertex_groups.get(bn)
            if not vg: continue
            wts = {}
            for v in obj.data.vertices:
                try:
                    w = vg.weight(v.index)
                    if w > 0.0: wts[v.index] = w
                except RuntimeError: continue
            if wts: od[bn] = wts
        if od: stash[obj.name] = od
    return stash

def _restore_face_weights(mesh_objects, stash):
    for obj in mesh_objects:
        if obj.type != 'MESH' or obj.name not in stash: continue
        for bn, wts in stash[obj.name].items():
            vg = _ensure_vg(obj, bn)
            for vid, w in wts.items():
                vg.add([vid], w, 'REPLACE')

def _cleanup(temp_objects, temp_armature):
    for obj in temp_objects:
        md = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if md and md.users == 0: bpy.data.meshes.remove(md)
    if temp_armature:
        ad = temp_armature.data
        bpy.data.objects.remove(temp_armature, do_unlink=True)
        if ad and ad.users == 0: bpy.data.armatures.remove(ad)


def _do_basemodel_remap(mesh_objects):
    template_path = _get_template_path()
    if not template_path:
        _do_attire_remap(mesh_objects)
        return
    dlog(f"[MDL Addon]   Mode: BaseModel (template transfer)")
    model, model_file, module = _load_template_model(template_path)
    if not model:
        _do_attire_remap(mesh_objects)
        return
    try:
        skeleton = model.getSkeleton()
        temp_armature = _build_temp_armature(skeleton) if skeleton else None
        temp_objects = []
        for mesh in model.getMeshes():
            obj = _build_temp_mesh(mesh, temp_armature)
            if obj: temp_objects.append(obj)
    finally:
        # Release the template even if armature/mesh construction raised —
        # otherwise the file handle leaks into the rest of the addon
        # session and the source MCD stays locked from disk-side rewrites.
        module.release_model_file(model_file)
    dlog(f"[MDL Addon]   Template: {len(temp_objects)} meshes, {len(skeleton.bones) if skeleton else 0} bones")

    transfers = 0
    for obj in mesh_objects:
        if obj.type != 'MESH': continue
        target_name = obj.data.name
        if '.' in target_name: target_name = target_name.rsplit('.', 1)[0]
        source = _find_matching_template(target_name, temp_objects)
        if source:
            to_remove = [vg for vg in obj.vertex_groups if vg.name.startswith('J_') or vg.name.startswith('H_') or vg.name == 'vector']
            for vg in to_remove: obj.vertex_groups.remove(vg)
            _transfer_weights_from_template(source, obj)
            transfers += 1
    dlog(f"[MDL Addon]   Template transfers: {transfers}")

    old_armature = _get_armature(mesh_objects)
    adopted = False
    if old_armature and temp_armature:
        old_name = old_armature.name
        old_col = None
        for col in bpy.data.collections:
            if old_armature.name in col.objects: old_col = col; break
        if not old_col: old_col = bpy.context.scene.collection
        if old_col != bpy.context.scene.collection:
            if temp_armature.name not in old_col.objects: old_col.objects.link(temp_armature)
            if temp_armature.name in bpy.context.scene.collection.objects: bpy.context.scene.collection.objects.unlink(temp_armature)
        temp_armature.rotation_euler = old_armature.rotation_euler
        temp_armature.location = old_armature.location
        temp_armature.scale = old_armature.scale
        for obj in mesh_objects:
            if obj.type != 'MESH': continue
            if obj.parent == old_armature: obj.parent = temp_armature
            arm_mod = None
            for mod in obj.modifiers:
                if mod.type == 'ARMATURE': arm_mod = mod; break
            if arm_mod: arm_mod.object = temp_armature
            else: obj.modifiers.new(type='ARMATURE', name="Armature").object = temp_armature
        old_data = old_armature.data
        bpy.data.objects.remove(old_armature, do_unlink=True)
        if old_data and old_data.users == 0: bpy.data.armatures.remove(old_data)
        temp_armature.name = old_name
        temp_armature.data.name = old_name
        adopted = True
        bpy.context.view_layer.update()
        dlog(f"[MDL Addon]   Replaced armature with 2K26 skeleton")
    _cleanup(temp_objects, None if adopted else temp_armature)


# ═══════════════════════════════════════════════════════════════════════════
#  ENTRY POINT (original, now superseded by the disabled stub in
#  Serialize/skeleton_remap.py — see comment at top of this file)
# ═══════════════════════════════════════════════════════════════════════════

def remap_skeleton_for_export(compile_target):
    # ── DISABLED ──────────────────────────────────────────────────────────
    # Auto 2K25→2K26 skeleton conversion is disabled while we investigate
    # further. The version detection was also false-positiving on v2.15
    # (0x2F) MCD files whose 2K25-era bones triggered the remap path,
    # corrupting models that should have been left untouched.
    # Re-enable once detection and remap logic are solid.
    # ─────────────────────────────────────────────────────────────────────
    return False
