# Serialize/_disabled/

Quarantine folder for serialize modules that are not currently wired into the
active addon runtime. Preserved here for potential revival, reference, or
salvage of individual helpers — they are intentionally NOT importable from
active code paths.

## Why these are here

A code audit confirmed the following modules are unreferenced (or effectively
unreferenced) by the live addon:

- **ctg_generator.py** — Zero imports anywhere in the addon. The CTG
  post-save / pre-save / placeholder pipeline it provides is not invoked
  by any current export path. Reference baseModel data files
  (`baseModel_ref_26.mcd`, `baseModel_ref_26.ctg`) it would have consumed
  are still bundled in `Serialize/` for any future revival.

- **mcd_patch_mhead.py** — Zero imports. Only the `__main__` CLI is
  reachable, and only if someone runs the file directly with `python`.
  The M_Head name-table fix-up it performs is not part of any current
  Blender-driven export path.

- **skeleton_remap_logic.py** — The bulk implementation of the cross-version
  (2K25 → 2K26) skeleton remap. The public entry point,
  `remap_skeleton_for_export()`, is hard-disabled (returns `False`
  immediately) due to false-positive detection on v2.15 / 0x2F MCDs that
  was corrupting unrelated models. None of the helpers below that entry
  point are reachable while the gate is closed.

  The three constants that ARE still live (`BONES_ONLY_IN_25`,
  `BONES_ONLY_IN_26`, `RENAME_25_TO_26`) remain in
  `Serialize/skeleton_remap.py` alongside a thin stub of
  `remap_skeleton_for_export()` so that `blender_save.py:51` and any
  other consumer of those names continues to import cleanly.

## Rules

1. **Do not import from this folder in active addon code.** Treat it as a
   read-only archive. If you need something here, revive it intentionally
   by moving the module (or the specific function) back to `Serialize/`
   and re-validating its call sites.

2. **This folder is not a Python package for runtime use.** The
   `__init__.py` exists only to suppress accidental partial-package
   behavior and to document intent — not to expose anything.

3. **If you delete this folder, also delete the bundled reference data
   that only these modules consume** (`baseModel_ref_26.mcd`,
   `baseModel_ref_26.ctg`, `skeleton_ref_26.json` in `Serialize/`).
   Until then, keep those files in place — the existing addon does not
   load them at runtime, but they round-trip with these modules.
