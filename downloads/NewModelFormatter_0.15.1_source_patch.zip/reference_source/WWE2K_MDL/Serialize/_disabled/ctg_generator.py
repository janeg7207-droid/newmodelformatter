"""
CTG Generator — Vertex remap tables for WWE 2K MCD files.

CTG structure (from vanilla analysis):
  TOBJ: Forward permutation — TOBJ[position] = vertex_index
        Count = total_verts - num_position_dups_excluded
        Contains vertex indices (NOT sequential), acts as DLL's vertex reorder.
        Max value < total_verts (RCTG count).
        
  RCTG: Inverse permutation — RCTG[vertex] = position_in_TOBJ
        Count = total_verts (one entry per vertex).
        For non-excluded verts: TOBJ[RCTG[v]] == v (round-trip).
        For excluded dup verts: RCTG[v] == RCTG[primary_v].
        Max value < TOBJ count.
        
  DUPS: Groups of position-coincident vertices (on RCTG section only).
        Position-only matching — normals are NOT considered.
        Each group has one primary (in TOBJ) and extras (excluded from TOBJ).

Post-save path:
  Re-loads the saved MCD via the DLL, reads vertexRemap (the DLL's own
  vertex reorder from deserialization), and builds the CTG from it.

Pre-save placeholder path:
  Builds an identity-based CTG from Blender mesh data with proper
  position-only dup detection for the pre-injection sub-stream.
"""

import struct
import os
import ctypes
from ..Link.log import dlog, derror

_CTG  = b'CTG!'
_SOBJ = b'SOBJ'
_TOBJ = b'TOBJ'
_RSOB = b'RSOB'
_RCTG = b'RCTG'
_DUPS = b'DUPS'
_END  = b'END!'


# ═══════════════════════════════════════════════════════════════════════════════
#  Low-level writer
# ═══════════════════════════════════════════════════════════════════════════════

def _w32(buf, val):
    buf += struct.pack('<I', val & 0xFFFFFFFF)

def _w16(buf, val):
    buf += struct.pack('<H', val & 0xFFFF)

def _w_name(buf, name):
    enc = name.encode('ascii')
    _w32(buf, len(enc))
    buf += enc
    while len(buf) % 4 != 0:
        buf += b'\x00'

def _w_dups(buf, dup_groups):
    buf += _DUPS
    if not dup_groups:
        _w32(buf, 1)
        _w32(buf, 0)
        return
    cap = 1
    for g in dup_groups:
        cap += 1 + len(g)
    _w32(buf, cap)
    _w32(buf, len(dup_groups))
    for g in dup_groups:
        _w32(buf, len(g))
        for idx in g:
            _w32(buf, idx)


# ═══════════════════════════════════════════════════════════════════════════════
#  Position duplicate detection (position-only, no normal filtering)
# ═══════════════════════════════════════════════════════════════════════════════

def _find_dup_groups(positions, num_verts, tolerance=0.0001):
    """Find groups of vertices sharing the same position.
    
    Uses spatial hashing + union-find for O(n) average performance.
    Position-only matching — normals are NOT considered (matches vanilla).
    """
    if num_verts == 0: return []
    cell = max(tolerance * 10, 0.001)
    tol_sq = tolerance * tolerance
    grid = {}
    for i in range(num_verts):
        x, y, z = positions[i]
        grid.setdefault((int(x/cell), int(y/cell), int(z/cell)), []).append(i)
    parent = list(range(num_verts))
    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb: parent[ra] = rb
    for i in range(num_verts):
        x, y, z = positions[i]
        gx, gy, gz = int(x/cell), int(y/cell), int(z/cell)
        for dx in range(-1, 2):
            for dy in range(-1, 2):
                for dz in range(-1, 2):
                    for j in grid.get((gx+dx, gy+dy, gz+dz), ()):
                        if j <= i: continue
                        jx, jy, jz = positions[j]
                        if (x-jx)**2 + (y-jy)**2 + (z-jz)**2 < tol_sq:
                            union(i, j)
    gm = {}
    for i in range(num_verts):
        gm.setdefault(find(i), []).append(i)
    dups = [sorted(g) for g in gm.values() if len(g) >= 2]
    dups.sort(key=lambda g: g[0])
    return dups


# ═══════════════════════════════════════════════════════════════════════════════
#  CTG construction from vertexRemap
# ═══════════════════════════════════════════════════════════════════════════════

def _load_ref_mesh_ctg(mesh_name):
    """Load the reference 2K26 CTG data for a specific mesh.
    
    Returns (tobj, rctg, dups) or None if reference unavailable.
    """
    ref = _load_ref_ctg()
    if not ref or not ref.tobj or not ref.rctg:
        return None
    
    ref_tobj = None
    ref_rctg = None
    ref_dups = None
    for entry in ref.tobj:
        if entry.name == mesh_name and entry.sub_entries:
            ref_tobj = entry.sub_entries[0].remaps
    for entry in ref.rctg:
        if entry.name == mesh_name and entry.sub_entries:
            ref_rctg = entry.sub_entries[0].remaps
            ref_dups = entry.sub_entries[0].dup_groups
    
    if ref_tobj and ref_rctg:
        return ref_tobj, ref_rctg, ref_dups or []
    return None


def _load_ref_mesh_positions(mesh_name):
    """Load vertex positions for a mesh from the reference 2K26 MCD.
    
    Returns list of (x, y, z) tuples, or None if unavailable.
    """
    try:
        from ..Link.wrapper import ExternalLibary, cmodellib
        ref_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'baseModel_ref_26.mcd')
        if not os.path.exists(ref_path):
            return None
        
        module = ExternalLibary()
        model_file = ctypes.c_void_p()
        skin_model = module.load_model(ref_path.encode('utf-8'), ctypes.byref(model_file), False)
        if not model_file or not skin_model:
            return None
        
        try:
            positions = None
            num_meshes = cmodellib.getNumMeshes(skin_model)
            for i in range(num_meshes):
                name = cmodellib.getMeshName(skin_model, i)
                if not name: continue
                if name.decode('utf-8') != mesh_name: continue
                
                nv = cmodellib.getNumVerts(skin_model, i)
                vert_ptr = cmodellib.getVertexData(skin_model, i)
                if vert_ptr and nv > 0:
                    positions = [(vert_ptr[v*3], vert_ptr[v*3+1], vert_ptr[v*3+2]) for v in range(nv)]
                break
            return positions
        finally:
            module.release_model_file(model_file)
    except Exception as e:
        derror(f"[CTG Gen] Failed to load ref positions for {mesh_name}: {e}")
        return None


def _build_vertex_mapping(exported_pos, ref_pos, tolerance=0.005):
    """Build vertex correspondence: exported[i] → ref[j] by position matching.
    
    Returns mapping array where mapping[exp_idx] = ref_idx, or -1 if no match.
    Uses spatial hashing for O(n) average performance.
    """
    cell = tolerance * 2
    grid = {}
    for j, (x, y, z) in enumerate(ref_pos):
        key = (int(x / cell), int(y / cell), int(z / cell))
        grid.setdefault(key, []).append(j)
    
    tol_sq = tolerance * tolerance
    mapping = [-1] * len(exported_pos)
    used = set()
    
    for i, (ex, ey, ez) in enumerate(exported_pos):
        gx, gy, gz = int(ex / cell), int(ey / cell), int(ez / cell)
        best_j = -1
        best_dist = tol_sq
        for dx in range(-1, 2):
            for dy in range(-1, 2):
                for dz in range(-1, 2):
                    for j in grid.get((gx+dx, gy+dy, gz+dz), ()):
                        if j in used: continue
                        rx, ry, rz = ref_pos[j]
                        d = (ex-rx)**2 + (ey-ry)**2 + (ez-rz)**2
                        if d < best_dist:
                            best_dist = d
                            best_j = j
        if best_j >= 0:
            mapping[i] = best_j
            used.add(best_j)
    
    return mapping


def _transform_ctg_with_mapping(ref_tobj, ref_rctg, ref_dups, mapping, num_verts):
    """Transform reference CTG through position-based vertex mapping.
    
    mapping[exp_idx] = ref_idx maps exported vertices to reference vertices.
    Stock CTG values are in reference space — transform them to exported space.
    
    TOBJ transform: new_TOBJ[rev_map[i]] = rev_map[stock_TOBJ[i]]
    RCTG transform: new_RCTG[rev_map[ref_tgt]] = rev_map[stock_RCTG[ref_tgt]]
    """
    # Build reverse mapping: ref_idx → exp_idx
    rev_map = {}
    for exp_idx, ref_idx in enumerate(mapping):
        if ref_idx >= 0:
            rev_map[ref_idx] = exp_idx
    
    # Transform TOBJ
    new_tobj = []
    for ref_src in range(len(ref_tobj)):
        stk_target = ref_tobj[ref_src]
        exp_src = rev_map.get(ref_src, -1)
        exp_target = rev_map.get(stk_target, -1)
        if exp_src >= 0 and exp_target >= 0:
            new_tobj.append(exp_target)
        elif exp_src >= 0:
            new_tobj.append(exp_src)  # fallback to identity
        # else: skip entries with no exported correspondence
    
    # Transform RCTG
    new_rctg = [0] * num_verts
    for ref_tgt in range(len(ref_rctg)):
        ref_source = ref_rctg[ref_tgt]
        exp_tgt = rev_map.get(ref_tgt, -1)
        exp_src = rev_map.get(ref_source, ref_source)
        if exp_tgt >= 0 and exp_tgt < num_verts:
            new_rctg[exp_tgt] = min(exp_src, len(new_tobj) - 1) if exp_src >= 0 else exp_tgt
    
    # Fill any unmapped RCTG entries with identity
    for v in range(num_verts):
        if new_rctg[v] == 0 and v > 0:
            # Check if it was actually set to 0 or is unfilled
            # (vertex 0 mapping to 0 is valid, so we check if it was reached)
            pass  # 0 is a valid default
    
    # Extend RCTG if needed
    while len(new_rctg) < num_verts:
        new_rctg.append(len(new_rctg))
    
    # Transform dup groups
    new_dups = []
    for g in ref_dups:
        fg = [rev_map[v] for v in g if v in rev_map and rev_map[v] < num_verts]
        if len(fg) >= 2:
            new_dups.append(sorted(fg))
    new_dups.sort(key=lambda g: g[0])
    
    return new_tobj, new_rctg, new_dups


def _adapt_ref_ctg(ref_tobj, ref_rctg, ref_dups, num_verts):
    """Simple adaptation fallback — filter out-of-range and rebuild inverse.
    
    Used when position mapping isn't available. Less accurate than
    _transform_ctg_with_mapping but structurally valid.
    """
    tobj = [v for v in ref_tobj if v < num_verts]
    
    dups = []
    for g in ref_dups:
        fg = [v for v in g if v < num_verts]
        if len(fg) >= 2:
            dups.append(list(fg))
    
    vert_to_pos = {}
    for pos, v in enumerate(tobj):
        if v not in vert_to_pos:
            vert_to_pos[v] = pos
    
    dup_primary = {}
    for g in dups:
        primary = None
        for v in g:
            if v in vert_to_pos:
                primary = v
                break
        if primary is not None:
            for v in g:
                if v not in vert_to_pos:
                    dup_primary[v] = primary
    
    rctg = []
    max_pos = len(tobj) - 1
    for v in range(num_verts):
        if v in vert_to_pos:
            rctg.append(vert_to_pos[v])
        elif v in dup_primary and dup_primary[v] in vert_to_pos:
            rctg.append(vert_to_pos[dup_primary[v]])
        else:
            rctg.append(min(v, max_pos))
    
    return tobj, rctg, dups


def _build_ctg_for_mesh(name, num_verts, dup_groups, positions=None):
    """Build TOBJ/RCTG/DUPS for a specific mesh.
    
    For M_Body: uses reference 2K26 CTG directly (identical topology).
    For M_Head: position-maps exported vertices to reference, then transforms
      the stock CTG through that mapping for character-specific accuracy.
    
    Falls back to simple adaptation or identity if mapping fails.
    
    Returns (tobj_remaps, rctg_remaps, rctg_dups).
    """
    ref_data = _load_ref_mesh_ctg(name)
    if ref_data:
        ref_tobj, ref_rctg, ref_dups = ref_data
        ref_rctg_count = len(ref_rctg)
        
        if ref_rctg_count == num_verts:
            # Exact match — use directly (M_Body case)
            dlog(f"[CTG Gen] {name}: using reference CTG "
                  f"(TOBJ={len(ref_tobj)}, RCTG={ref_rctg_count}, "
                  f"{len(ref_dups)} dups)")
            return list(ref_tobj), list(ref_rctg), [list(g) for g in ref_dups]
        
        elif abs(ref_rctg_count - num_verts) <= 10 and positions:
            # Close vertex count + we have positions — do position mapping
            ref_positions = _load_ref_mesh_positions(name)
            if ref_positions:
                mapping = _build_vertex_mapping(positions, ref_positions)
                matched = sum(1 for m in mapping if m >= 0)
                pct = 100 * matched // len(mapping)
                
                if matched > len(mapping) * 0.9:
                    tobj, rctg, dups = _transform_ctg_with_mapping(
                        ref_tobj, ref_rctg, ref_dups, mapping, num_verts)
                    dlog(f"[CTG Gen] {name}: position-mapped CTG "
                          f"({matched}/{len(mapping)} matched={pct}%, "
                          f"TOBJ={len(tobj)}, RCTG={len(rctg)}, {len(dups)} dups)")
                    return tobj, rctg, dups
                else:
                    dlog(f"[CTG Gen] {name}: mapping weak ({pct}%), "
                          f"falling back to adaptation")
            
            # Fallback: simple adaptation
            tobj, rctg, dups = _adapt_ref_ctg(ref_tobj, ref_rctg, ref_dups, num_verts)
            dlog(f"[CTG Gen] {name}: adapted reference CTG "
                  f"(ref={ref_rctg_count} -> port={num_verts}, "
                  f"TOBJ={len(tobj)}, RCTG={len(rctg)}, {len(dups)} dups)")
            return tobj, rctg, dups
        
        elif abs(ref_rctg_count - num_verts) <= 10:
            # Close but no positions — simple adaptation
            tobj, rctg, dups = _adapt_ref_ctg(ref_tobj, ref_rctg, ref_dups, num_verts)
            dlog(f"[CTG Gen] {name}: adapted reference CTG "
                  f"(ref={ref_rctg_count} -> port={num_verts}, "
                  f"TOBJ={len(tobj)}, RCTG={len(rctg)}, {len(dups)} dups)")
            return tobj, rctg, dups
        
        else:
            dlog(f"[CTG Gen] {name}: ref count {ref_rctg_count} too far from "
                  f"mesh verts {num_verts}, falling back to identity")
    
    return _build_identity_ctg(num_verts, dup_groups)


def _build_ctg_from_vremap(vertex_remap, num_verts, dup_groups, mesh_name='', positions=None):
    """Build TOBJ/RCTG/DUPS for ported models.
    
    Uses reference 2K26 CTG with position-mapping for M_Head.
    Uses reference 2K26 CTG directly for M_Body.
    
    Returns (tobj_remaps, rctg_remaps, rctg_dups).
    """
    return _build_ctg_for_mesh(mesh_name, num_verts, dup_groups, positions=positions)


def _build_identity_ctg(num_verts, dup_groups):
    """Build an identity-based CTG keeping all vertices in TOBJ.
    
    Fallback when reference data is unavailable.
    TOBJ[v] = v, RCTG[v] = v, with dup groups annotated on RCTG.
    """
    tobj = list(range(num_verts))
    rctg = list(range(num_verts))
    return tobj, rctg, dup_groups


# ═══════════════════════════════════════════════════════════════════════════════
#  CTG Binary Builder
# ═══════════════════════════════════════════════════════════════════════════════

def _build_ctg_bytes(meshes):
    buf = bytearray()
    buf += _CTG

    buf += _SOBJ
    _w32(buf, len(meshes))
    for m in meshes:
        _w_name(buf, m['name'])
        _w32(buf, 1); _w32(buf, 0)

    buf += _TOBJ
    _w32(buf, len(meshes))
    for mi, m in enumerate(meshes):
        _w_name(buf, m['name'])
        _w32(buf, 1)
        _w32(buf, 0); _w32(buf, mi)
        remaps = m['tobj_remaps']
        _w32(buf, len(remaps))
        for v in remaps: _w16(buf, v)
        _w_dups(buf, [])  # TOBJ never has dup groups

    buf += _RSOB
    _w32(buf, len(meshes))
    for m in meshes:
        _w_name(buf, m['name'])
        _w32(buf, 1); _w32(buf, 0)

    buf += _RCTG
    _w32(buf, len(meshes))
    for mi, m in enumerate(meshes):
        _w_name(buf, m['name'])
        _w32(buf, 1)
        _w32(buf, 0); _w32(buf, mi)
        remaps = m['rctg_remaps']
        _w32(buf, len(remaps))
        for v in remaps: _w16(buf, v)
        _w_dups(buf, m['rctg_dups'])

    buf += _END
    buf += b'\x00\x00\x00\x00'
    return bytes(buf)


def _wrap(ctg_bytes):
    """Vanilla MCD format: [size][CTG!][CTG!SOBJ...END!]"""
    if ctg_bytes[:4] == _CTG:
        return struct.pack('<I', len(ctg_bytes)) + _CTG + ctg_bytes
    return struct.pack('<I', len(ctg_bytes) + 4) + _CTG + _CTG + ctg_bytes


# ═══════════════════════════════════════════════════════════════════════════════
#  MCD Patching
# ═══════════════════════════════════════════════════════════════════════════════

def _patch_ctg_in_mcd(mcd_path, new_ctg_bytes):
    with open(mcd_path, 'rb') as f:
        data = bytearray(f.read())
    if data[:4] != b'MCD!':
        dlog(f"[CTG Gen] Not an MCD file: {mcd_path}")
        return False

    pos = 8
    ctg_pos = None
    while pos + 8 <= len(data):
        size = struct.unpack_from('<I', data, pos)[0]
        tag = data[pos+4:pos+8]
        if tag == _CTG:
            ctg_pos = pos
            break
        if size == 0: break
        pos += 4 + size
        while pos % 4 != 0: pos += 1

    if ctg_pos is None:
        dlog(f"[CTG Gen] No CTG in {mcd_path}")
        return False

    old_size = struct.unpack_from('<I', data, ctg_pos)[0]
    old_end = ctg_pos + 4 + 4 + old_size

    mdl_start = old_end
    while mdl_start < len(data) - 4:
        if data[mdl_start+4:mdl_start+8] == b'MDL!':
            break
        mdl_start += 1

    new_size = len(new_ctg_bytes)
    new_substream = struct.pack('<I', new_size) + _CTG + new_ctg_bytes
    pad = (4 - (len(new_substream) % 4)) % 4
    new_substream += b'\x00' * pad
    new_substream += struct.pack('<I', 0x04)

    data[ctg_pos:mdl_start] = new_substream

    with open(mcd_path, 'wb') as f:
        f.write(data)

    dlog(f"[CTG Gen] Patched CTG: {old_size + 8} -> {len(new_substream)} bytes")
    return True


# ═══════════════════════════════════════════════════════════════════════════════
#  Post-save entry point
# ═══════════════════════════════════════════════════════════════════════════════

def generate_ctg_post_save(mcd_path):
    """Re-load saved MCD, read DLL's vertexRemap, build correct CTG.
    
    The DLL reconstructs vertexRemap during deserialization. We read it
    back and use it to build TOBJ (forward permutation) and RCTG (inverse).
    
    Position-only dup detection — normals are NOT considered, matching
    vanilla CTG behavior. Excluded dup extras map to their primary's
    TOBJ position in RCTG.
    
    If the DLL doesn't provide vertexRemap (size=0), falls back to
    identity-based CTG with position-only dup groups.
    """
    try:
        from ..Link.wrapper import ExternalLibary, cmodellib

        module = ExternalLibary()
        model_file = ctypes.c_void_p()
        skin_model = module.load_model(
            mcd_path.encode('utf-8'), ctypes.byref(model_file), False)

        if not model_file or not skin_model:
            derror(f"[CTG Gen] Failed to re-load {mcd_path}")
            return False

        try:
            num_meshes = cmodellib.getNumMeshes(skin_model)
            render_meshes = []

            for i in range(num_meshes):
                name = cmodellib.getMeshName(skin_model, i)
                if not name: continue
                name = name.decode('utf-8')
                if name not in ('M_Head', 'M_Body'): continue

                nv = cmodellib.getNumVerts(skin_model, i)
                if nv <= 0: continue

                # Read positions for dup detection
                vert_ptr = cmodellib.getVertexData(skin_model, i)
                positions = []
                if vert_ptr:
                    for v in range(nv):
                        positions.append((vert_ptr[v*3], vert_ptr[v*3+1], vert_ptr[v*3+2]))

                # Position-only dup groups (no normal filtering)
                dups = _find_dup_groups(positions, nv) if positions else []

                # Try to read vertexRemap from the DLL
                vremap_size = cmodellib.getVertexRemapSize(skin_model, i)
                vremap = None
                if vremap_size > 0 and vremap_size == nv:
                    vremap_ptr = cmodellib.getVertexRemapData(skin_model, i)
                    if vremap_ptr:
                        vremap = [vremap_ptr[v] for v in range(vremap_size)]

                if vremap:
                    tobj, rctg, rctg_dups = _build_ctg_from_vremap(vremap, nv, dups, mesh_name=name, positions=positions)
                    src = "ref"
                else:
                    tobj, rctg, rctg_dups = _build_ctg_for_mesh(name, nv, dups, positions=positions)
                    src = "ref"

                dlog(f"[CTG Gen] {name}: {nv} verts, TOBJ={len(tobj)}, "
                      f"RCTG={nv}, {len(dups)} dup groups [{src}]")

                render_meshes.append({
                    'name': name,
                    'tobj_remaps': tobj,
                    'rctg_remaps': rctg,
                    'rctg_dups': rctg_dups,
                })
        finally:
            module.release_model_file(model_file)

        if not render_meshes:
            dlog(f"[CTG Gen] No render meshes in {mcd_path}")
            return False

        render_meshes.sort(key=lambda m: 0 if m['name'] == 'M_Head' else 1)

        ctg_bytes = _build_ctg_bytes(render_meshes)
        dlog(f"[CTG Gen] Built CTG: {len(ctg_bytes)} bytes")
        return _patch_ctg_in_mcd(mcd_path, ctg_bytes)

    except Exception as e:
        import traceback
        derror(f"[CTG Gen] Post-save error: {e}")
        traceback.print_exc()
        return False


def remap_ctg_post_save(mcd_path):
    """Transform the injected source CTG through the DLL's vertex remap.
    
    The source 2K25 CTG has the correct character-specific vertex permutation
    but its indices reference pre-serialization vertex order. The DLL may
    reorder vertices during saveModelToFile. We read the DLL's vertexRemap
    (which maps serialized_idx → original_idx) and update the CTG indices
    so they reference the post-serialization order in the saved MCD.
    
    For each mesh:
      vertexRemap[ser_idx] = orig_idx → build reverse: orig_idx → ser_idx
      TOBJ[pos] = orig_vertex → new_TOBJ[pos] = reverse[orig_vertex]
      RCTG[orig_vertex] = pos → new_RCTG[reverse[orig_vertex]] = pos
      DUPS members: orig_vertex → reverse[orig_vertex]
    """
    try:
        from ..Link.wrapper import ExternalLibary, cmodellib

        module = ExternalLibary()
        model_file = ctypes.c_void_p()
        skin_model = module.load_model(
            mcd_path.encode('utf-8'), ctypes.byref(model_file), False)

        if not model_file or not skin_model:
            derror(f"[CTG Remap] Failed to re-load {mcd_path}")
            return False

        try:
            # Read the existing CTG from the saved MCD
            with open(mcd_path, 'rb') as f:
                mcd_data = f.read()
            
            pos = 8
            existing_ctg = None
            while pos + 8 <= len(mcd_data):
                size = struct.unpack_from('<I', mcd_data, pos)[0]
                tag = mcd_data[pos+4:pos+8]
                if tag == _CTG:
                    existing_ctg = parse_ctg_data(mcd_data[pos+4:pos+4+size])
                    break
                if size == 0: break
                pos += 4 + size
                while pos % 4 != 0: pos += 1
            
            if not existing_ctg or not existing_ctg.tobj:
                dlog(f"[CTG Remap] No valid CTG found in {mcd_path}")
                return False

            # Build vertex remaps for each render mesh
            remaps = {}  # mesh_name → {orig_idx → ser_idx}
            num_meshes = cmodellib.getNumMeshes(skin_model)
            for i in range(num_meshes):
                name = cmodellib.getMeshName(skin_model, i)
                if not name: continue
                name = name.decode('utf-8')
                if name not in ('M_Head', 'M_Body'): continue

                nv = cmodellib.getNumVerts(skin_model, i)
                vremap_size = cmodellib.getVertexRemapSize(skin_model, i)
                if vremap_size > 0 and vremap_size == nv:
                    vremap_ptr = cmodellib.getVertexRemapData(skin_model, i)
                    if vremap_ptr:
                        # vremap[ser_idx] = orig_idx → build reverse
                        reverse = {}
                        for ser_idx in range(vremap_size):
                            orig_idx = vremap_ptr[ser_idx]
                            reverse[orig_idx] = ser_idx
                        remaps[name] = (reverse, nv)
                        dlog(f"[CTG Remap] {name}: {nv} verts, "
                              f"remap coverage {len(reverse)}/{nv}")
        finally:
            module.release_model_file(model_file)

        if not remaps:
            dlog(f"[CTG Remap] No vertex remaps available, keeping existing CTG")
            return False

        # Transform CTG through remaps
        render_meshes = []
        for tobj_entry in existing_ctg.tobj:
            mesh_name = tobj_entry.name
            if mesh_name not in remaps:
                # No remap for this mesh — keep as-is
                sub = tobj_entry.sub_entries[0] if tobj_entry.sub_entries else None
                if sub:
                    rctg_sub = None
                    rctg_dups = []
                    for rctg_entry in existing_ctg.rctg:
                        if rctg_entry.name == mesh_name and rctg_entry.sub_entries:
                            rctg_sub = rctg_entry.sub_entries[0]
                            break
                    render_meshes.append({
                        'name': mesh_name,
                        'tobj_remaps': list(sub.remaps),
                        'rctg_remaps': list(rctg_sub.remaps) if rctg_sub else list(sub.remaps),
                        'rctg_dups': [list(g) for g in (rctg_sub.dup_groups if rctg_sub else [])],
                    })
                continue

            reverse, nv = remaps[mesh_name]
            sub = tobj_entry.sub_entries[0] if tobj_entry.sub_entries else None
            if not sub:
                continue

            old_tobj = sub.remaps
            
            # Find matching RCTG entry
            old_rctg = None
            old_dups = []
            for rctg_entry in existing_ctg.rctg:
                if rctg_entry.name == mesh_name and rctg_entry.sub_entries:
                    old_rctg = rctg_entry.sub_entries[0].remaps
                    old_dups = rctg_entry.sub_entries[0].dup_groups
                    break

            if not old_rctg:
                old_rctg = list(old_tobj)
            
            # Transform TOBJ: old_TOBJ[pos] = orig_vertex
            # → new_TOBJ[pos] = reverse[orig_vertex] (convert to serialized index)
            new_tobj = []
            for orig_v in old_tobj:
                if orig_v in reverse:
                    new_tobj.append(reverse[orig_v])
                else:
                    new_tobj.append(orig_v)  # fallback: keep original
            
            # Transform RCTG: old_RCTG[orig_vertex] = position
            # → new_RCTG[reverse[orig_vertex]] = position
            new_rctg = [0] * nv
            for orig_v in range(len(old_rctg)):
                position = old_rctg[orig_v]
                if orig_v in reverse:
                    ser_v = reverse[orig_v]
                    if ser_v < nv:
                        new_rctg[ser_v] = position
            
            # Handle any extra serialized vertices not in old RCTG
            # (identity fallback)
            for v in range(nv):
                if new_rctg[v] == 0 and v > 0:
                    # Check if this vertex was actually mapped
                    pass  # 0 is valid default
            
            # Transform dup groups
            new_dups = []
            for g in old_dups:
                new_g = []
                for orig_v in g:
                    if orig_v in reverse:
                        new_g.append(reverse[orig_v])
                if len(new_g) >= 2:
                    new_dups.append(sorted(new_g))
            new_dups.sort(key=lambda g: g[0])

            dlog(f"[CTG Remap] {mesh_name}: TOBJ {len(old_tobj)}→{len(new_tobj)}, "
                  f"RCTG {len(old_rctg)}→{nv}, dups {len(old_dups)}→{len(new_dups)}")

            render_meshes.append({
                'name': mesh_name,
                'tobj_remaps': new_tobj,
                'rctg_remaps': new_rctg,
                'rctg_dups': new_dups,
            })

        if not render_meshes:
            dlog(f"[CTG Remap] No meshes to remap")
            return False

        render_meshes.sort(key=lambda m: 0 if m['name'] == 'M_Head' else 1)

        ctg_bytes = _build_ctg_bytes(render_meshes)
        dlog(f"[CTG Remap] Built remapped CTG: {len(ctg_bytes)} bytes")
        return _patch_ctg_in_mcd(mcd_path, ctg_bytes)

    except Exception as e:
        import traceback
        derror(f"[CTG Remap] Error: {e}")
        traceback.print_exc()
        return False


# ═══════════════════════════════════════════════════════════════════════════════
#  Pre-save placeholder
# ═══════════════════════════════════════════════════════════════════════════════

def generate_ctg_placeholder(scene_meshes):
    """Build a pre-save CTG placeholder from Blender mesh data.
    
    Uses position-only dup detection to build proper TOBJ/RCTG structure
    matching vanilla layout. This gets injected as a sub-stream before
    the DLL serializes — the post-save pass will replace it with the
    correct CTG using the DLL's actual vertexRemap.
    """
    render = [m for m in scene_meshes if m.mesh_name in ('M_Head', 'M_Body')]
    if not render: return None
    render.sort(key=lambda m: 0 if m.mesh_name == 'M_Head' else 1)
    meshes = []
    for m in render:
        v = m.vertices
        nv = len(v) if isinstance(v, list) and len(v) > 0 and not isinstance(v[0], (int, float)) else len(v) // 3

        # Extract positions for dup detection and position mapping
        # Blender uses Z-up, game uses Y-up: swizzle (x, y, z) → (x, -z, y)
        positions = []
        if isinstance(v, list) and len(v) > 0:
            if isinstance(v[0], (list, tuple)):
                positions = [(p[0], -p[2], p[1]) for p in v]
            else:
                # Flat float list
                positions = [(v[i*3], -v[i*3+2], v[i*3+1]) for i in range(nv)]

        # Position-only dup groups
        dups = _find_dup_groups(positions, nv) if positions else []

        tobj, rctg, rctg_dups = _build_ctg_for_mesh(m.mesh_name, nv, dups, positions=positions)

        dlog(f"[CTG Gen] Placeholder {m.mesh_name}: {nv} verts, TOBJ={len(tobj)}, "
              f"RCTG={len(rctg)}, {len(rctg_dups)} dup groups")

        meshes.append({
            'name': m.mesh_name,
            'tobj_remaps': tobj,
            'rctg_remaps': rctg,
            'rctg_dups': rctg_dups,
        })
    ctg_bytes = _build_ctg_bytes(meshes)
    dlog(f"[CTG Gen] Placeholder CTG: {len(ctg_bytes)} bytes")
    return _wrap(ctg_bytes)

def generate_ctg_from_ref(scene_meshes, compile_target="option_vcexport_26"):
    return generate_ctg_placeholder(scene_meshes)
def generate_ctg(scene_meshes):
    return generate_ctg_placeholder(scene_meshes)
def generate_ctg_identity(scene_meshes):
    return generate_ctg_placeholder(scene_meshes)


# ═══════════════════════════════════════════════════════════════════════════════
#  Parser
# ═══════════════════════════════════════════════════════════════════════════════

class CtgSubEntry:
    __slots__ = ('field_a', 'field_b', 'remaps', 'dup_groups')
    def __init__(self, fa=0, fb=0, remaps=None, dups=None):
        self.field_a = fa; self.field_b = fb
        self.remaps = remaps or []; self.dup_groups = dups or []

class CtgMeshEntry:
    __slots__ = ('name', 'num_groups', 'flags', 'sub_entries')
    def __init__(self, name='', ng=1, fl=0, subs=None):
        self.name = name; self.num_groups = ng; self.flags = fl
        self.sub_entries = subs or []

class CtgData:
    __slots__ = ('sobj', 'tobj', 'rsob', 'rctg')
    def __init__(self):
        self.sobj = []; self.tobj = []; self.rsob = []; self.rctg = []

def parse_ctg_data(data):
    if not data or len(data) < 8 or data[:4] != _CTG: return None
    pos = [4]
    # Handle double CTG! header (CTG!CTG!SOBJ...)
    if data[4:8] == _CTG:
        pos[0] = 8
    def u32():
        v = struct.unpack_from('<I', data, pos[0])[0]; pos[0] += 4; return v
    def u16():
        v = struct.unpack_from('<H', data, pos[0])[0]; pos[0] += 2; return v
    def rd_name():
        nl = u32(); n = data[pos[0]:pos[0]+nl].split(b'\x00')[0].decode('ascii', errors='replace')
        pos[0] += nl
        while pos[0] % 4 != 0: pos[0] += 1
        return n
    def parse_sobj():
        c = u32(); out = []
        for _ in range(c):
            n = rd_name(); ng = u32(); fl = u32()
            out.append(CtgMeshEntry(n, ng, fl))
        return out
    def parse_tobj():
        c = u32(); out = []
        for _ in range(c):
            n = rd_name(); sc = u32(); e = CtgMeshEntry(n, sc)
            for _ in range(sc):
                fa = u32(); fb = u32(); rc = u32()
                remaps = [u16() for _ in range(rc)]
                pos[0] += 4
                vc = u32(); fv = u32(); dups = []
                if fv > 0:
                    for _ in range(fv):
                        gs = u32(); dups.append([u32() for _ in range(gs)])
                e.sub_entries.append(CtgSubEntry(fa, fb, remaps, dups))
            out.append(e)
        return out
    ctg = CtgData()
    while pos[0] < len(data) - 4:
        tag = data[pos[0]:pos[0]+4]; pos[0] += 4
        if   tag == _END:  break
        elif tag == _SOBJ: ctg.sobj = parse_sobj()
        elif tag == _RSOB: ctg.rsob = parse_sobj()
        elif tag == _TOBJ: ctg.tobj = parse_tobj()
        elif tag == _RCTG: ctg.rctg = parse_tobj()
        else: break
    return ctg

def parse_ctg_file(filepath):
    with open(filepath, 'rb') as f: return parse_ctg_data(f.read())

def _load_ref_ctg():
    ref_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'baseModel_ref_26.mcd')
    if not os.path.exists(ref_path): return None
    with open(ref_path, 'rb') as f: mcd = f.read()
    if mcd[:4] != b'MCD!': return None
    pos = 8
    while pos + 8 <= len(mcd):
        size = struct.unpack_from('<I', mcd, pos)[0]
        tag = mcd[pos+4:pos+8]
        if tag == _CTG: return parse_ctg_data(mcd[pos+4:pos+4+size])
        pos += 8 + size
        while pos % 4 != 0: pos += 1
    return None

def write_ctg_file(ctg_data, output_path):
    with open(output_path, 'wb') as f: f.write(ctg_data)
