import bpy
from .vcskinmodel_import import *
from .vcskinmodel_export import *
from .Blender.Extras.model_properties import *
from .Blender.Extras.skeleton_alignment import *
from .Blender.Extras.masking_hpl import *
from .Blender.Extras.model_points_gen import *
from .Blender.Extras.model_gtpt_gen import *
from .Blender.Extras.streamline4_1 import *
from .Blender.Extras.hair_slot_renamer import *
from .Blender.Extras.physics_swap import *
from .Blender.Extras import material_export_panel as _mat_export_panel
from .Blender.Extras import MeshDataTransfer as _mdt
from . import Yukes as _yukes

bl_info = {
    "name": "Visual Concepts | WWE (.MDL, .MCD) Import/Export Add-On v2.10.3",
    "author": "Hanleys",
    "version": (2, 10, 3),
    # Min supported Blender. Explicit compat branches exist 2.93→5.1; raising
    # this would make the addon refuse to enable on older LTS builds that work.
    "blender": (2, 93, 0),
    "description": "Import/Export plugin for WWE2K models.",
    "category": "Object",
}

# -- v2.10.3 --
# MATERIAL PRESET CONTEXT + UI PASS -- the export dialog gains a "Presets"
# selector (Auto / Character BaseModel / Character Attire / Arena-Prop-Weapon)
# so arena/prop exports no longer depend on the save path containing an
# Arena/Props/Weapons folder; per-material vc_2k26_attire_scope (stamped at
# import, edited in the panel) is now honored on export (unanimous-consensus
# rule); environment exports name the .mtls after the model file. New "2K26
# Materials" 3D-View sidebar panel (Physics Swap's former slot -- swap feature
# still active for configured .blends, panel unregistered): per-material
# template dropdown + alpha toggle grouped by selected mesh, resolved-Auto
# labels, Set All Templates batch operator. IMPORT RELIABILITY: imports with
# "Load Material Textures" crashed the DLL on Blender 2.93-5.0. ROOT CAUSE
# (fixed at the source, DLL rebuilt): VCModel.dll was built with VS 2022
# 17.10+ whose constexpr std::mutex requires msvcp140.dll >= 14.40; Blender
# 2.93-5.0 bundle blender.crt\msvcp140.dll 14.29, so the first mutex lock in
# VCMaterials' buffer-bounds registry read a null pointer. Rebuilt with
# _DISABLE_CONSTEXPR_MUTEX_CONSTRUCTOR (Directory.Build.props in both source
# trees). Bonus DLL fixes: MTLS loadMaterialTable no longer depends on
# unspecified C++ evaluation order, bounds-sanity cap on the index count, and
# isStubMtlBlock now recognizes real vanilla 2K26 stub blocks (nonzero flag
# byte) so reference-based baseModels correctly merge their .jmtl data. The
# addon-side no-texture retry guard remains as defense in depth. Verified
# end-to-end (register/import W/textures/export/materials) on 2.93, 3.3,
# 4.1-4.5, 5.0, 5.1, 5.1 beta. UI PERF: HPL Masking panel status
# (collection+disk scan, O(verts) vertex-group counting) now TTL-cached
# instead of recomputed every redraw; panel template inference memoized.

# -- v2.10.2 --
# GAME-LOAD MATERIAL FIX -- JMTL roots now use the canonical editor/vanilla
# u16 discriminator layout; shared eye normals remain on the universal 2K26
# hash; and post-substitution legacy aliases are synchronized so fresh body,
# head, and gear/attire normal refs point at the current mod's texture paths.
# Generation now uses a deterministic compact policy independent of an optional
# sample corpus, emits canonical empty gear UV-scroll children, and writes the
# distinct type-1/type-2/type-3 nested hair schemas instead of reusing type 1.
#
# -- v2.10.1 --
# FRESH 2K26 MATERIAL GENERATION HARDENING -- schema-correct sparse JMTLs for
# character base models, attire, fur/hair variants, and common arena PBR /
# illumination materials; canonical shared texture stems; finite color/UV
# values; stable-deduplicated V6 MTLS rows; and DCC defaults such as lambert1
# excluded from output. Explicit gear variants remain authorable.

# -- v2.10.0 --
# 2K26 MATERIAL EXPORT COMPLETION -- curated character/attire/arena templates,
# explicit template-to-byte resolution, environment inference, safe corpus-free
# global texture defaults, and verified writers for illumination, glass,
# speedTree, water, fur, hairMesh, and shellFur.

# ── v2.9.1 ──
# 2K26 WDF WRAP-DEFORM FIX (DLL) — M_Combinations/M_Cap/M_Mask/M_Pierce now follow the head's
# shapekey animation after a Blender round-trip. Root cause (corpus-proven, 296/296 vanilla WDF
# files): the WDF! block is a CONCATENATION of per-LOD entry segments sized by the driven mesh's
# per-LOD index-buffer prefixes; our exporter writes clone-LOD0 LODs, so the passed-through
# vanilla 4-real-LOD block was mis-sliced by the game — the binding broke even byte-identical.
#   * The serializer now REBUILDS the WDF for the exported LOD structure (vanilla LOD0 segment
#     per clone LOD). Unedited meshes: bit-exact vanilla entries (verified). Edited/reordered
#     driven meshes: entries re-keyed by exact/nearest source-vertex position (verbatim vanilla
#     anchors — approximate but plausible wrap on trimmed/sculpted combos instead of none).
#     Every driven mesh missing/unsliceable -> WDF dropped with a console warning (never ships a
#     mis-keyed binding); unparseable WDF -> verbatim passthrough (never destroys data).
#   * transferRawSubStreams additionally stashes the source model's per-mesh render-order
#     positions (the re-key reference for edited meshes).
# HAIR-PHYSICS FALSE-DROP FIX (DLL) — the v2.9.0 stale-physics detector identified a blob's
# driven mesh as the FIRST live mesh named anywhere in it; H-family blobs also name the S_*
# sim twin (e.g. S_Hair 521 verts for a blob driving M_Hair 9142), so ~5% of vanilla
# characters (86/1630 corpus files) silently lost HAIR physics on every round-trip (hair went
# static). The detector now treats a blob as stale only when an embedded driven-vertex count
# matches NO live mesh named in the blob (validated 258/258 link chunks corpus-wide; real
# edits still drop correctly). Full-corpus sweep: 22,530/22,530 2K26 files load clean;
# DLL round-trip semantic-equivalence green across all characters + all 838 WDF files.
# EXPORT CRASH-PROOFING (DLL) — the whole export path is now SEH-guarded like the loader:
# prepareMeshForExport + saveModelToFile convert access faults from inconsistent mesh data into
# clean console errors instead of killing Blender; setMeshPolygons validates face sizes/vertex
# indices; MikkTSpace tangent regen moved inside the failure guard, its missing-UV throw replaced
# with a safe flat fallback (a throw there terminated the process); getRawMeshPolygons clamps
# stale loop indices addon-side. Blender 3.3/2.93 regression battery (corrupt/truncated load,
# shapekeys, weld/quad/degen/mirror edits, 10x soak, stale props, reprocessing older exports):
# 9/9 PASS on both; all-9-Blender-versions smoke ALL_OK.
#
# ── v2.9.0 ──
# 2K26 CTG (face-shading weld table) — PROPER generation instead of stale passthrough (generateCTG_v2, DLL):
#   * Unedited head/body -> byte-exact passthrough (535/535 baseModels).
#   * Edited/ported/fresh head/body -> regenerate via 3 tiers: (C1) adopt the NATIVE donor table from an
#     embedded catalog keyed by a triangle-adjacency hash — byte-exact when the topology matches a shipped
#     2K26 base (M_Head 100%, M_Body 99.6% over 535 chars); else (C2) a real exact-position weld
#     (render-correct); else (C3) identity. Kills the dark-shading / shard-explosion an edited mesh shipped
#     before, and never ships a stale wrong-size table. Ships ctg_donor_catalog.flat next to VCModel.dll.
#   * Also fixed a +1-vertex export over-split caused by a native zero-area "stitch" triangle (119_Andre
#     M_Body) -> 535/535 baseModel byte-exact round-trips. Gated to the 2K26 PackedTBN path (no older-game change).
# 2K26 PHYSICS export crash fixed: editing a physics-driven mesh (M_Combinations / M_Hair) then exporting shipped
#   the captured per-vertex cloth/jiggle records (OYWA/HYWA/OCYW/HCYW) verbatim over the NEW vertex buffer ->
#   out-of-bounds read at load -> game crash. The serializer now DROPS a physics sub-stream whose driven mesh was
#   edited (its vertex count changed) so the mesh loads STATIC (no cloth sim) instead of crashing; unedited meshes
#   pass through byte-exact. (Full cloth-preserving regeneration is a future step — the MOD4 spring table needs
#   more RE.)
#
# ── v2.8.0 ──
# CUSTOM MULTI-UV / MULTI-MATERIAL UV-MANGLE FIX (e.g. shao1.fbx: 4 UV layers, 11 materials, welded).
# Two independent bugs fixed:
#   1. DLL splitUvSeams keyed split verts on UV0 + normal only, so corners differing only in a SECONDARY
#      UV layer (UV1/UV2/UV3) collided and the loser's higher-layer UVs were discarded -> islands collapsed
#      to zero-area on the Preserve-Custom-Normals path. LoopKey now includes ALL secondary UV layers
#      (quvExtra). No-op + byte-identical on vanilla meshes (imported pre-split).
#   2. Default (non-preserve) path SKIPPED the UV-seam split for multi-facegroup meshes but never ran the
#      DLL split either, so a welded custom mesh stayed un-split and the per-vertex UV read (last-loop-wins)
#      scrambled every UV island. getSceneMeshes now auto-routes a mesh through the DLL per-loop split ONLY
#      when (multi-facegroup AND welded AND no shape keys) — vanilla meshes (pre-split) never trigger it.
# Validated: shao1 all-4-layers clean on default+preserve across Blender 2.93..5.1; vanilla byte-exact
# round-trips unchanged (5-file A/B OLD-vs-NEW DLL identical incl. 2-UV + PackedTBN physics; 92-mesh
# corpus sweep 0 welded / 0 would-route). DLL rebuilt (Release-DLL|x64). New helper mesh_has_welded_uv_seams.
#
# ── v2.7.0 ──
# PER-SHADER MATERIAL IMPORT — setup_material now builds a proper Principled node graph
# by 2K26 shader type instead of color-only. Verified on Blender 2.93, 4.1, 5.1:
#   * EYELASH (shader 0x14): the DXT5 color map's own alpha drives transparency
#     (color -> Base Color, color.Alpha -> BSDF Alpha, alpha BLEND).
#   * HAIR (0x16 / any _rai+_flow suffix pair — incl. combinations / hair2 / named cards
#     like joe,potato): base color is PROCEDURAL in-engine, so it is driven by the mesh's
#     active VERTEX COLOR. The _rai map (R=roughness, G=alpha, B=irradiance) drives
#     G -> BSDF Alpha (strand coverage, CLIP cutout — BLEND let EEVEE depth-sort show the
#     scalp through the cards) and R -> BSDF Roughness.
#   * PACKED _nrm (R,G = tangent normal / B = roughness / A = metallic, verified across
#     the corpus): split it — (R,G) recombined with Z=1 -> Normal Map -> BSDF Normal (so B
#     never reaches the normal, which was the chrome/'wet-drip' artifact); B -> BSDF
#     Roughness; A -> BSDF Metallic (gated on a real BC7 alpha, so the common const-0 alpha
#     stays non-metal and a DXT1/BC5 _nrm can't force chrome). BC7 decodes on Blender 4.1+
#     (older skips cleanly); BC5 (_flow / 2-channel) loads on all versions.
#   * MESH-FABRIC CUTOUT (e.g. chainmail tops): a non-hair color map carrying a real DXT5/
#     BC7 alpha drives color.Alpha -> BSDF Alpha as a CLIP cutout (the open links).
#   Secondary maps resolve by Textures-folder naming (<stem>_<suffix>.dds), stripping the
#   ':Skinned' and '_ALPHA' slot suffixes. All node construction is version-gated by
#   bpy.app.version (SeparateRGB<->SeparateColor, the EEVEE-Next surface_render_method
#   cutout/blend path, shadow_method removal in 4.3, active-color-attribute lookup) so
#   it is silent + correct on 2.93 -> 5.1.
# DDS LOADER: stopped skipping BC5 (ATI2 — the _flow/_normal 2-channel maps decode on
#   every version); BC7 is now allowed on Blender 4.1+ (was skipped everywhere).
#
# ── v2.5.0 ──
# 2K26 TEXTURE LOAD FIX (Blender 5.x) — the game ships its .dds textures with a
# non-standard dwCaps header (no DDSCAPS_TEXTURE flag). Blender 4.x tolerated this, but
# Blender 5.x's stricter DDS loader rejects them as "unknown file-format", so every
# diffuse/normal map silently failed to load (gray model + one console error per texture).
# The importer now repairs dwCaps on a temp copy before loading — pixel data untouched,
# the original game file is never modified — so textures load correctly on 5.x and the
# console errors are gone. Verified on Blender 2.93 + 5.1 (body/eye/eyelash/head all load).
# Console is now quiet on import: just the "[MDL Addon] Model Imported in Xs" timing line.
#
# BLENDER 2.9x / OLD-VERSION LOAD + EXPORT FIX — the addon could not enable on
# Blender 2.9x (still widely used in the CAW community); installing it there
# crashed and the File > Export operator "disappeared", and even past that, an
# actual model import hard-crashed. Several causes, all now fixed — validated
# end-to-end on all 11 installed Blender builds, 2.93 to 5.1 (Python 3.9-3.13):
#   * IMPORT-TIME (de-registered the WHOLE addon): material_inference.py and
#     jmtl_writer.py used Python 3.9/3.10 annotation syntax (tuple[...], str|None,
#     module-level dict[...]) that EVALUATES at import on Python 3.7/3.9, raising
#     TypeError before register() ran. material_inference is imported eagerly by
#     __init__ (via material_export_panel), so the whole package import aborted →
#     no operators registered. Both files now carry `from __future__ import
#     annotations` (PEP 563): the hints are stringized and never evaluated, so the
#     addon loads on 2.9x's Python and the export operator reappears.
#   * REGISTRATION (Blender 2.9x only): two GtPt-generator operator properties named
#     with a leading underscore (_confirmed, _tuned_count) — which Blender 2.9x rejects
#     ("property starts with '_'") — are renamed (confirmed, tuned_count). They already
#     carry options={'HIDDEN','SKIP_SAVE'}, so there is no 4.x/5.x UI or behavior change.
#   * IMPORT HARD-CRASH (Blender < 4.1, incl. 2.93 + 3.x): the VC_TANGENT/VC_PACKEDTBN
#     vertex-stream capture — which preserves the tangent FRAME that the passed-through
#     WDF! substream's deltas are read in — hard-crashed mid-import on 2.93/3.3. Two root
#     causes, both fixed so the capture works byte-identically on EVERY version (no skip,
#     no lost fidelity on old Blender):
#       - ORDER: adding a POINT attribute AFTER create_normals_split (pre-4.1) had built
#         the legacy custom-normal CustomData layer crashed the realloc. The capture now
#         runs BEFORE setMeshNormals, on the fresh mesh.
#       - STALE REF: each attributes.new() reallocates CustomData, invalidating an earlier
#         attribute's Python ref; writes are now interleaved (write each attribute's data
#         before creating the next).
#     Verified on all 11 installed builds (2.93 to 5.1, Python 3.9-3.13): each registers,
#     imports (VC_TANGENT on all 8 character meshes, head custom-normals intact) AND
#     re-exports. Vertex positions are bit-identical across every version and the
#     tangent/PackedTBN frame is carried through; the only cross-version delta is
#     sub-millidegree normals (Blender's own version-specific custom-normal float storage),
#     reflected by the re-encode gate in a few percent of PackedTBN words. The modern range
#     4.3 -> 5.1 produces byte-identical exports. Yukes color_attributes read getattr-guarded.
#
# ── v2.3.11 ──
# YUKES SKINNING — per-mesh skin_bone_palette START-OFFSET resolution. The
# skin's per-vertex bone indices are local to a SLICE of the global bone palette
# that, for some meshes (outfit/shoe/secondary-body layers, eyes, tongue),
# begins partway in — the engine's hkSkinnedMeshShape "Start boneSet". Applying
# offset 0 to everyone bound those verts to far/wrong bones, which exploded into
# long spikes once an animation moved the skeleton. The importer now recovers
# each mesh's offset geometrically (the offset that binds each vertex to its
# nearest rest bone), GATED so it only overrides 0 when it more than halves the
# bind AND lands tight (<20) — meshes already correct at offset 0 are left
# untouched. Verified geometrically on the corpus: ~85% of skinned meshes
# collapse to a tight bind (Shoes 142->9.5, body layers 89-156->7-13); the few
# genuinely multi-part meshes keep offset 0 (known follow-up: per-part boneset
# splitting). Pairs with the v2.3.9 animation-coordinate fix.
#
# ── v2.3.9 ──
# YUKES (WWE 2K15-19) ANIMATION COMPATIBILITY — the Yukes importer now builds
# the armature with the SAME convention as the modern 2K26 path, so the Yukes
# Animation Add-on (io_scene_yukes_anims) applies .yanm keys correctly:
#   * Bones are placed via edit_bone.matrix = <game world bind> (raw game
#     frame), NOT a per-bone Y-up->Z-up bake. The animation plugin frames its
#     game-space euler/translation keys relative to bone.matrix_local, so that
#     frame must stay in game space. The up-axis flip is now the armature
#     object's -90deg X rotation (Rx(-90) == the old (x,z,-y) bake), applied
#     once at the object level; meshes parent to the armature and inherit it.
#     Meshes/shape-keys are kept in raw game space to match (export gates the
#     old inverse on a per-mesh `yobj_gamespace` flag for legacy .blend files).
#   * EVERY named bone is now included in the armature. The 'm###' parentless
#     deform bones (shoes, outfit layers, facial markers) — which meshes skin
#     to at 47-100% — were previously filtered out, leaving those parts frozen
#     during animation because their vertex groups had no bone. The .yanm keys
#     them directly; they now have bones to drive.
#
# ── v2.3.7 ──
# YUKES (WWE 2K19) EXPORT — byte-exact YOBJ/JBOY round-trip across the full
# pac/ch corpus: 1715/1715 model blobs re-export bit-identical to the source,
# spanning every on-disk format version (v0/v1/v3/v7). Unedited meshes export
# byte-for-byte identical to vanilla; edited meshes re-encode only the changed
# geometry. Each on-disk block (vertex+morph frames, weight, UV, normal, face,
# shader-param, skeleton/texture/material region, trailer, and the unreferenced
# post-mesh-table block) is captured verbatim and only the offsets a re-layout
# moves are patched — with source-order block emission and version-7 header
# preservation (face_sec / inline-palette / texture+morph-count fields left
# intact). YUKES IMPORT — Oodle (oo2core) DLL auto-discovery from installed
# WWE 2K* game folders + EPK8 thin-wrapper container support → near-100%
# ch*.pac import coverage.
#
# ── v2.3.5 ──
# 2K25 (v2.09) EXPORT FIX: the R8_G8_B8_A8 stream-table token was missing for
# color-less meshes (CAS attire), collapsing the vertex-format index and breaking
# reload on export. Now guaranteed in CModelSerializer_2_9::serialize(). Verified
# 19,072/19,072 2K25 corpus files round-trip clean.
# 2K24/2K25 IMPORTS now route to the modern VCModel.dll (full-corpus verified to
# load .mdl/v2.08 + .mcd/v2.09 cleanly); legacy DLL remains the 2K22/2K23 export
# fallback. Codebase comment cleanup — behavior-neutral (byte-identical-export
# verified, 24/24 sample md5-match).
#
# ── v2.3.3 ──
# IMPORT PERF ("Load Material Textures"): memoized two pure caches (cleared via
# clear_cache()/_clear_metadata_caches()), no behavior change:
#   * jmtl_resolver.resolve_diffuse_path memoized per (model_path, material_name);
#     negative (None) results cached too (most expensive — they exhaust the search).
#   * materials._is_loadable_dds (BC4/5/6H/7 header sniff) memoized per filepath.
#
# ── v2.3.2 (HOTFIX) ──
#   * skinmesh.getTexCoords / wrapper.add_vertex_colors: `!= None`/`== None` on
#     v2.3.1 ndarrays raised "truth value of array ambiguous". Replaced with
#     `is None`. v2.3.1 was unusable for import on any mesh with UV channels.
#
# ── v2.3.1 ──
# IMPORT PERF:
#   * skinmesh getters (getMeshVerts/Normals/IndexList/UVChannel) now return numpy
#     float32/int32 ndarrays instead of list[Vector]/list[tuple] comprehensions;
#     getMeshNormals scrub+normalize vectorized in numpy.
#   * loadSkinMesh (blender_mesh.py) replaces from_pydata with vertices.add(N) +
#     foreach_set('co') + loops/polygons, then update(calc_edges=True) to restore
#     the edge derivation from_pydata did for free. Face validation vectorized.
#   * setBlendShapes (blender_mesh.py) + fast_apply_blendshape (perf.py): share one
#     working buffer across shapes, reset only indices touched by the PREVIOUS shape
#     (old path did basis_co.copy() per shape — ~251 MB memcpy on an 871-key 2K26
#     rig). Empty shapes skip foreach_set. Defensive `sk.value = 0.0` gated Blender 5+.
# COMPATIBILITY: ndarray skinmesh fields' bare truthiness `if x:` updated to
#   `x is not None and len(x) > 0` in blender_scene.py, blender_mesh.py,
#   physics_swap.py, physics_patcher.py (numpy raises "truth value ambiguous").
# NOT REGRESSED: skeleton creation + setVertexGroups audited byte-equivalent/faster.
#
# ── v2.3.0 ──
# FIXES (from v2.2.0):
#   * Removed per-mesh origin-shift-to-visual-center: it made matrix_world non-
#     identity per export, and float32 matmul drift between M_Head/M_Body's
#     independently-shifted translations gave ~1 ULP divergence at the neck seam,
#     breaking byte-exact round-trip (visible in-game gap) and facial morphs. All
#     imported meshes now ship identity matrix_world as in v2.1.
# PERFORMANCE:
#   * wrapper.py: ctypes array construction replaced with numpy zero-copy pointer
#     pass-through (arrays bound to named locals for ctypes lifetime — see comment
#     above _as_c_float_ptr).
#   * splitAllMaterialGroups routes mode switches through setBlenderMode (early-
#     returns when already in target mode).
#   * remove_shape_keys (Streamline) uses obj.shape_key_clear() data API instead of
#     the shape_key_remove(all=True) operator (skips queued depsgraph tick).

def register():
    register_mdl_panel()
    register_rig_alignment_utility()
    register_vcs_export()
    register_vcs_import()
    register_hpl_export()
    register_vc_ap_generator()
    register_vc_gtpt_generator()
    register_streamline_tools()
    register_hair_slot_renamer()
    register_physics_swap()
    _mat_export_panel.register()  # 2K26 per-material export panel + custom props
    _mdt.register()          # MeshDataTransfer panel + operators
    _yukes.register()        # Yukes-era YOBJ/JBOY import/export

def unregister():
    _yukes.unregister()
    _mdt.unregister()
    _mat_export_panel.unregister()
    unregister_mdl_panel()
    unregister_rig_alignment_utility()
    unregister_vcs_export()
    unregister_vcs_import()
    unregister_hpl_export()
    unregister_vc_ap_generator()
    unregister_vc_gtpt_generator()
    unregister_streamline_tools()
    unregister_hair_slot_renamer()
    unregister_physics_swap()

if __name__ == "__main__":
    register()
    bpy.ops.import_vcskinmodel.load('INVOKE_DEFAULT')
    bpy.ops.export_vcskinmodel.save('INVOKE_DEFAULT')
