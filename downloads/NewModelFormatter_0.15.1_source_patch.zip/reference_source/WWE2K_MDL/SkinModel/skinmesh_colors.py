from ..Link.wrapper import cmodellib
from mathutils import Vector
import ctypes
import numpy as np
from ..Link.log import dlog

class vCMeshColors():

    def __debugLog(self):
        if (len(self.maps) == 0):
            return
        dlog("[MDL Addon] Color Data: ", self.maps[0])
        return
    
    def __getNumVtxColors(self):
        return cmodellib.getNumMeshVertexColors(self.__data, self.__id)

    def __getColorMap(self, map_index):
        size = ctypes.c_int()
        data = cmodellib.getMeshVertexColors(self.__data, self.__id, map_index, ctypes.byref(size))
        if (data is None): return None
        if size.value <= 0: return None
        
        data = np.ctypeslib.as_array(data, shape=(size.value,)).tolist()
        return [Vector(data[i:i+4]) for i in range(0, len(data), 4)]
    
    def __getVertexColors(self):
        num_maps = self.__getNumVtxColors()
        if (num_maps is None or num_maps <= 0):
            return
        
        for i in range(num_maps):
            color_map = self.__getColorMap(i)

            if (color_map != None):
                self.maps.append(color_map)
                self.labels.append("ColorMap")
        return
    
    def __setup(self):
        self.__getVertexColors()
        # self.__debugLog()
        return

    def __init__(self, data, mesh_index):
        self.__data = data
        self.__id   = mesh_index
        self.maps   = []
        self.labels = []
        self.__setup()