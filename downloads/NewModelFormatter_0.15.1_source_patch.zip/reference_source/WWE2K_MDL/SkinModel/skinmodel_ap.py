from ..Link.wrapper import cmodellib
import ctypes
import json

class vCAttachPoint:

    @staticmethod
    def points_from_json(file_path):
        points_list = []
        with open(file_path, 'r') as json_file:
            data = json.load(json_file)
            for item in data:
                point           = vCAttachPoint()
                point.id_a      = item["id_a"]
                point.id_b      = item["id_b"]
                point.co        = item["co"]
                point.flag      = item["flag"]
                point.bone_id   = item["bone_id"]
                points_list.append(point)
        return points_list

    @staticmethod
    def serialize_to_json(points, file_path):
        data = []
        for struct in points:
            data.append({
                "id_a": struct.id_a,
                "id_b": struct.id_b,
                "co": struct.co,
                "flag": struct.flag,
                "bone_id": struct.bone_id })

        with open(file_path, 'w') as json_file:
            json.dump(data, json_file, indent=4)

    def __load_data(self):
        cmodellib.getAttachmentPointData( self.__data, self.index,
            ctypes.byref(self.id_a), ctypes.byref(self.id_b),
            ctypes.byref(self.joint), ctypes.byref(self.flag),
            ctypes.byref(self.co[0]), ctypes.byref(self.co[1]), ctypes.byref(self.co[2]) )
        return

    def __convert_cvalues(self):
        self.id_a  = self.id_a.value
        self.id_b  = self.id_b.value
        self.joint = self.joint.value
        self.flag  = self.flag.value
        self.co    = [i.value for i in self.co]
        # Attach-point coords pass through verbatim. The old 2K25 quirk-nudge
        # (normalize_for_2k25) was removed: vanilla 2K26's 191 attach points are
        # byte-identical to the 2K25 template, so the <0.01 hardcoded fixes were
        # unnecessary and silently corrupted 2K24/2K26 coords.
        return

    def get_data(self):
        self.__load_data()
        self.__convert_cvalues()
        return

    def __init__(self, data=None, index=None):
        self.__data   = data
        self.index    = index
        self.id_a     = ctypes.c_int()
        self.id_b     = ctypes.c_int()
        # Initialize with explicit zeros instead of undefined values
        self.co       = [ctypes.c_float(0.0), ctypes.c_float(0.0), ctypes.c_float(0.0)]
        self.joint    = ctypes.c_int()
        self.flag     = ctypes.c_int()
        self.bone_id  = None

        if (self.__data):
            self.get_data()
