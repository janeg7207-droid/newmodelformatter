from ..Link.wrapper import cmodellib
import ctypes
import json


# Single source of truth for the GtPt vertex-group naming convention.
# getVertexWeights (blender_utils.py) imports this prefix and filters it out
# before bone-name resolution, so anchor groups never enter the skin/weight
# serializer despite living alongside real deform groups.
#
# Format: VC_GTPT__{slot:03d}__{anchor_name}
#   - VC_GTPT__ prefix: distinct from real bone conventions (J_*, H_*, M_*).
#   - {slot:03d}: zero-padded slot from the record's no_2 field. Engine looks
#     records up by this slot → must round-trip verbatim. Padding sorts in UI.
#   - {anchor_name}: the anchor's _ag_NNNN string from the source TEXT table.
GTPT_VG_PREFIX = "VC_GTPT__"


def gtpt_vertex_group_name(slot, anchor_name):
    """Build the canonical vertex-group name for a GtPt anchor. Used by both the
    import scene builder and the export resolver — any format change MUST happen
    here so both sides stay in sync.
    """
    return f"{GTPT_VG_PREFIX}{slot:03d}__{anchor_name}"


def parse_gtpt_vertex_group_name(name):
    """Inverse of gtpt_vertex_group_name. Returns (slot, anchor_name) or None.
    Malformed names (prefix but wrong format) yield None rather than raising, so
    the export resolver can skip-with-warning on user-edited group names.
    """
    if not name.startswith(GTPT_VG_PREFIX):
        return None
    rest = name[len(GTPT_VG_PREFIX):]
    parts = rest.split("__", 1)
    if len(parts) != 2:
        return None
    slot_str, anchor_name = parts
    try:
        slot = int(slot_str, 10)
    except ValueError:
        return None
    return slot, anchor_name


class vCGotoPoint:
    """One GtPt record + its resolved string identities.

    Wire format (cmodelserializer.cpp createGtPtBuffer): 4 × int16 (no_0..no_3).
    Semantics (validated vs baseModel TEXT block, see Serialize/gtpt_resolver.py):
      no_0 → TEXT index → anchor name string (e.g. "_ag_0005")
      no_1 → TEXT index → group/mesh name string (e.g. "M_Head_Caruncle")
      no_2 → engine slot lookup key — opaque, preserve verbatim. Cluster-1 values
             (1,3,0,2,4) prove it is NOT a record-position counter; the engine
             asks for "slot N" by value.
      no_3 → vertex index on the mesh resolved from no_1.

    Round-trip discipline:
      - no_0/no_1 strings are resolved via the TEXT table into name/group_name;
        the integer indices are NOT preserved (the dest TEXT table is regenerated
        by the DLL, so strings are re-looked-up at export).
      - no_2 (slot) and no_3 (vertex_index) are kept as integers throughout.
      - Custom props on the Blender empty store the resolved strings, not indices.
    """

    @staticmethod
    def points_from_json(file_path):
        out = []
        with open(file_path, 'r') as f:
            data = json.load(f)
            for item in data:
                p = vCGotoPoint()
                p.name        = item["name"]
                p.group_name  = item["group_name"]
                p.slot        = int(item["slot"])
                p.vertex_index = int(item["vertex_index"])
                out.append(p)
        return out

    @staticmethod
    def serialize_to_json(points, file_path):
        data = []
        for p in points:
            data.append({
                "name": p.name,
                "group_name": p.group_name,
                "slot": int(p.slot),
                "vertex_index": int(p.vertex_index),
            })
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=4)

    def __load_data(self, string_table):
        cmodellib.getGotoPointData(
            self.__data, self.index,
            ctypes.byref(self.no_0), ctypes.byref(self.no_1),
            ctypes.byref(self.no_2), ctypes.byref(self.no_3))
        # Resolve strings via the table; out-of-range indices → None (resolver
        # drops those records rather than feeding garbage to the scene builder).
        n0, n1 = self.no_0.value, self.no_1.value
        if string_table is not None:
            self.name       = string_table[n0] if 0 <= n0 < len(string_table) else None
            self.group_name = string_table[n1] if 0 <= n1 < len(string_table) else None
        else:
            self.name = None
            self.group_name = None
        self.slot         = self.no_2.value
        self.vertex_index = self.no_3.value

    def get_data(self, string_table):
        self.__load_data(string_table)

    def __init__(self, data=None, index=None, string_table=None):
        self.__data = data
        self.index  = index
        self.no_0 = ctypes.c_int()
        self.no_1 = ctypes.c_int()
        self.no_2 = ctypes.c_int()
        self.no_3 = ctypes.c_int()
        self.name        = None
        self.group_name  = None
        self.slot        = 0
        self.vertex_index = 0

        if self.__data is not None and index is not None:
            self.get_data(string_table)
