import numpy as np
from ..Link.log import dlog
from ..Link.wrapper        import cmodellib
from .skinmesh_weights     import vCMeshWeights
from .skinmesh_colors      import vCMeshColors
from .skinmesh_blendshapes import getBlendshapes
from .skinmesh_groups      import getMaterialGroups
from mathutils import Vector

def getMeshName(mesh):
    return cmodellib.getMeshName(mesh.data, mesh.id).decode("utf-8")
    
def getNumVerts(mesh):
    return cmodellib.getNumVerts(mesh.data, mesh.id)

def getNumTris(mesh):
    return cmodellib.getNumTriangles(mesh.data, mesh.id)

def getNumUvChannels(mesh):
    return cmodellib.getNumUvChannels(mesh.data, mesh.id)

def getSceneFlag(mesh):
    return cmodellib.getMeshSceneFlag(mesh.data, mesh.id)

def getMotionFlag(mesh):
    return cmodellib.getMeshMotionFlag(mesh.data, mesh.id)

# PERF NOTE (v2.3.1): these getters return numpy float32/int32 arrays instead of
# list[Vector]/list[tuple] comprehensions (~95k allocs/baseModel eliminated). The
# defensive `.copy()` detaches each array from the DLL heap, which release_model_file
# frees at end-of-import — without it a deferred consumer reads freed memory (the
# bug skinmesh_blendshapes.py documents). loadSkinMesh consumes these as-is.

def getMeshVerts(mesh):
    """Return (num_verts, 3) float32 ndarray of vertex positions, or None."""
    num_items = getNumVerts(mesh)
    vert_data = cmodellib.getVertexData(mesh.data, mesh.id)
    if vert_data is None or num_items <= 0:
        return None
    # .copy() detaches from the DLL heap (freed by release_model_file at end-of-import).
    return np.ctypeslib.as_array(vert_data, shape=(num_items, 3)).copy()


def getMeshNormals(mesh):
    """Return (num_verts, 3) float32 ndarray of normals from the DLL, or None.

    Returns the DLL's normals as-is (already unit-length in every vanilla MCD
    seen). setMeshNormals (blender_mesh.py) runs the defensive scrub (non-finite
    + zero-length → +Z) before normals_split_custom_set_from_vertices, so the
    in-skinmesh re-scrub/re-normalize the old v1.9.6/v2.x code did was redundant.
    """
    num_items = getNumVerts(mesh)
    vert_data = cmodellib.getMeshNormals(mesh.data, mesh.id)
    if vert_data is None or num_items <= 0:
        return None
    return np.ctypeslib.as_array(vert_data, shape=(num_items, 3)).copy()


def getMeshTangents(mesh):
    """Return (num_verts, 4) float32 ndarray of stride-4 tangents [x,y,z,w] in
    GAME/LOCAL coords (NO axis swap), or None.

    xyz from the DLL's per-vertex TANGENT lane; w is the bitangent handedness
    (+1/-1) from the BINORMAL lane — a per-vertex SIGN scalar here, not a full
    vector. This [tangent.xyz, sign(binormal)] pairing is what the byte-exact DLL
    proof round-trips through the serializer at ~0deg.

    Why preserve: WDF (wrap-deform) stores its barycentric deltas in TANGENT
    space; letting MikkTSpace regenerate drifts them (measured up to 133deg) and
    silently breaks the binding. Capturing vanilla tangents lets the exporter
    feed them back byte-for-byte on an unedited mesh. None = no tangent lane
    (export regenerates, correct for new geometry).
    """
    num_verts = getNumVerts(mesh)
    if num_verts <= 0:
        return None
    tan_ptr, tan_size = cmodellib.getMeshTangents(mesh.data, mesh.id)
    if tan_ptr is None or tan_size <= 0:
        return None
    stride = tan_size // num_verts
    if stride < 3:
        return None
    # .copy() detaches from the DLL heap (freed at end-of-import).
    tan = np.ctypeslib.as_array(
        tan_ptr, shape=(num_verts, stride)).astype(np.float32, copy=True)

    # Handedness w. Priority matches the proof: dedicated binormal-sign lane
    # first (it is the serializer's authoritative sign source), then the
    # tangent's own 4th column, then +1.
    bn_ptr, bn_size = cmodellib.getMeshBinormals(mesh.data, mesh.id)
    if bn_ptr is not None and bn_size >= num_verts:
        bn = np.ctypeslib.as_array(
            bn_ptr, shape=(bn_size,)).astype(np.float32, copy=True)
        w = np.sign(bn[:num_verts])
    elif stride >= 4:
        w = np.sign(tan[:, 3])
    else:
        w = np.ones(num_verts, dtype=np.float32)
    w[w == 0] = 1.0  # snorm 0 -> treat as +1 (matches proof)

    out = np.empty((num_verts, 4), dtype=np.float32)
    out[:, :3] = tan[:, :3]
    out[:, 3]  = w
    return out


def getMeshOriginalPackedTBN(mesh):
    """Return (num_verts,) uint32 ndarray of verbatim vanilla PackedTBN octahedral
    words captured at load (4 bytes/vert, vanilla render order), or None.

    OPAQUE words: oct-encoded normal + tangent azimuth in the Hughes-Moller ONB
    of the decoded normal, GAME/LOCAL space. Stashed in a per-vertex VC_PACKEDTBN
    attribute so an UNEDITED export re-emits them byte-for-byte (DLL's per-vertex
    serializer gate decides keep-vs-reencode). loadSkinMesh builds the mesh 1:1
    from the MCD vertex buffer, so word[i] aligns with vertex i (same ordering as
    getMeshVerts/Normals/Tangents). None on length mismatch → falls back to
    regeneration rather than corrupting the export.
    """
    num_verts = getNumVerts(mesh)
    if num_verts <= 0:
        return None
    words = cmodellib.getMeshOriginalPackedTBN(mesh.data, mesh.id)
    if words is None or len(words) != num_verts:
        return None
    return words


def getIndexList(mesh):
    """Return (num_tris, 3) int32 ndarray of triangle vertex indices, or None."""
    num_indices = getNumTris(mesh)
    index_data = cmodellib.getMeshTriangleList(mesh.data, mesh.id)
    if (index_data is None or num_indices <= 0):
        return None
    # DLL returns uint32; cast to int32 for Blender's signed foreach_set on
    # mesh.loops.vertex_index. Vertex range << INT32_MAX, so the cast is identity.
    return np.ctypeslib.as_array(
        index_data, shape=(num_indices, 3)).astype(np.int32, copy=True)


def getUVChannel(mesh, index):
    """Return (num_verts, 2) float32 ndarray of UV coords, or None."""
    num_verts = getNumVerts(mesh)
    uv_data = cmodellib.getMeshUvChannel(mesh.data, mesh.id, index)
    if uv_data is None or num_verts <= 0:
        return None
    return np.ctypeslib.as_array(uv_data, shape=(num_verts, 2)).copy()

def getTexCoords(mesh):
    num_channels = getNumUvChannels(mesh)
    uv_channels = []

    for i in range(num_channels):
        map = getUVChannel(mesh, i)

        # getUVChannel returns an (N,2) ndarray (v2.3.1+); `is not None` identity
        # check — `!= None` triggers numpy's "truth value ambiguous" error.
        if map is not None:
            uv_channels.append(map)

    return uv_channels

def getVertexRemapArray(mesh):
    size = cmodellib.getVertexRemapSize(mesh.data, mesh.id)
    if size <= 0:
        return None
    data_ptr = cmodellib.getVertexRemapData(mesh.data, mesh.id)
    if data_ptr is None:
        return None
    return np.ctypeslib.as_array(data_ptr, shape=(size,)).tolist()

class vCSkinMesh():
    def __debug_log(self):
        dlog("\n[MDL Addon] Reading Mesh Data For: ", self.mesh_name)
        dlog("\n[MDL Addon] Total Vertices: ",  len(self.vertices))
        dlog("\n[MDL Addon] Total Triangles: ", len(self.index_list) )
        dlog("\n[MDL Addon] Tri List: ", self.index_list)
        return
    
    def __setup(self):
        # Populate mesh data 
        self.mesh_name       = getMeshName(self)
        self.vertices        = getMeshVerts(self)
        self.vertex_normals  = getMeshNormals(self)
        self.vertex_tangents = getMeshTangents(self)
        self.original_packedtbn = getMeshOriginalPackedTBN(self)
        self.index_list      = getIndexList(self)
        self.texcoords       = getTexCoords(self)
        self.skin            = vCMeshWeights(self.data, self.id)
        self.vertex_colors   = vCMeshColors(self.data, self.id)
        self.blendshapes     = getBlendshapes(self.data, self.id)
        self.material_groups = getMaterialGroups(self.data, self.id)
        self.scene_flag      = getSceneFlag(self)
        self.motion_flag     = getMotionFlag(self)
        self.vertex_remap    = getVertexRemapArray(self)

        # Assign last material name to object
        if (len(self.material_groups) != 0):
            self.name = self.material_groups[-1].material
        return
    
    def __init__(self, data=None, index=None):
        self.data            = data
        self.scene_flag      = None
        self.motion_flag     = None
        self.name            = None
        self.mesh_name       = None
        self.id              = index
        self.vertices        = None
        self.vertex_normals  = None
        self.vertex_tangents = None   # legacy export: per-vertex stride-4 [x,y,z,w]
        self.loop_tangents   = None   # DLL-preprocess export: per-loop stride-4
        self.original_packedtbn = None  # import capture: per-vertex uint32 oct-TBN words
        self.loop_packedtbn  = None   # DLL-preprocess export: per-loop uint32 oct-TBN words
        self.index_list      = None
        self.texcoords       = None
        self.skin            = None
        self.vertex_colors   = None
        self.blendshapes     = None
        self.material_groups = None
        self.vertex_remap    = None

        if (self.data != None):
            self.__setup()

