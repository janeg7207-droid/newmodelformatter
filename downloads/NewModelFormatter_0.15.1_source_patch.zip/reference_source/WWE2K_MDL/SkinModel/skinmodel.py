from ..Link.wrapper            import cmodellib
from ..SkinModel.skinmesh      import vCSkinMesh
from ..SkinModel.skinrig       import vCSkeleton
from ..SkinModel.skinmodel_ap  import vCAttachPoint
from ..SkinModel.skinmodel_gp  import vCGotoPoint

class vCSkinModel():
    
    def getNumMeshes(self):
        return len(self.__meshes)
    
    def getSkeleton(self):
        return self.__skeleton
    
    def getMeshes(self):
        return self.__meshes
    
    def has_skeleton(self):
        skeleton = self.getSkeleton()
        return (len(skeleton.bones) != 0)
    
    def __getNumMeshes(self):
        return cmodellib.getNumMeshes(self.__data)
    
    def __get_attach_points(self):
        num_points = cmodellib.getNumAttachPoints(self.__data)
        if (num_points > 0):
            self.attach_points = [vCAttachPoint(self.__data, i) for i in range(num_points)]
        return

    def __get_string_table(self):
        """Pull the model's full string table from the DLL (for resolving GtPt
        record indices to anchor/mesh names). None when the DLL lacks the read
        API (older builds) — vCGotoPoint then yields name=None and the scene
        builder skips unresolved records rather than placing empties at wrong verts.
        """
        if not cmodellib.has_string_table_api():
            return None
        try:
            n = cmodellib.getNumStringTableEntries(self.__data)
        except Exception:
            return None
        if n <= 0:
            return None
        return [cmodellib.getStringTableEntry(self.__data, i) for i in range(n)]

    def __get_goto_points(self):
        """Load all GtPt records, resolving each record's name_id/group_id against
        the model's string table. Gated on has_gtpt_api so the addon stays loadable
        against legacy DLLs; when missing, goto_points stays None (= "no GtPt",
        vanilla pre-2K26 behavior).
        """
        if not cmodellib.has_gtpt_api():
            return
        num_points = cmodellib.getNumGotoPoints(self.__data)
        if num_points <= 0:
            return
        string_table = self.__get_string_table()
        self.goto_points = [vCGotoPoint(self.__data, i, string_table)
                            for i in range(num_points)]
        return

    def __setup(self):
        total_meshes = self.__getNumMeshes() # Gather all skin meshes

        for i in range(total_meshes):
            mesh = vCSkinMesh(self.__data, i)
            self.__meshes.append(mesh)

        self.__skeleton = vCSkeleton(self.__data) # Gather all rig/joint data

        self.__get_attach_points() # Gather all model APs
        self.__get_goto_points()   # Gather all GtPt records
        return
    
    def __init__(self, data=None):
        self.__data   = data
        self.__meshes = []
        self.__skeleton = None
        self.attach_points = None
        self.goto_points   = None
        
        if (self.__data != None):
            self.__setup()
        


    