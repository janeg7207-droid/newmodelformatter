from ..Link.wrapper import cmodellib
import ctypes
import numpy as np
from ..Link.log import derror

class vCMeshShape():
    def __init__(self):
        self.name    = None
        self.verts   = None
        self.indices = None # Defines morphed vertex indices

def getBlendShapeVerts(cmodel, mesh_index, shape_index):
    numCoords = ctypes.c_int()
    vert_data = cmodellib.getMeshBlendShape(cmodel, mesh_index, shape_index, numCoords)
    if (vert_data == None):
        derror("[MDL Addon] Failed to retrieve mesh blendshape @ Shape#", shape_index)
        return None

    if numCoords.value <= 0:
        return None

    # Copy to a Python list with .tolist(): a bare as_array wrap of the DLL's
    # memory stays valid only until release_model_file frees the heap. It works
    # today (freed after setBlendShapes consumes it) but any deferred shape-key
    # processing would read freed memory — the copy removes that dependency.
    data = np.ctypeslib.as_array(vert_data, shape=(numCoords.value, )).tolist()
    return data

def getLabels(cmodel, mesh_index):
    numShapes = ctypes.c_int()
    data = cmodellib.getAllMeshMorphs(cmodel, mesh_index, ctypes.byref(numShapes))
    if (data == None): return None
    
    # Convert the received data to a Python list of strings
    shape_labels = [ctypes.string_at(data[i]).decode("utf-8") for i in range(numShapes.value)]

    # Free allocated memory
    cmodellib.free_string_arr(data)
    return shape_labels

def getMorphIndices(cmodel, mesh_index, shape_index):
    numIndices = ctypes.c_int()
    data = cmodellib.getVtxMorphIndices(cmodel, mesh_index, shape_index, ctypes.byref(numIndices))
    if ((data == None) or (numIndices.value == 0)):
        return []
    
    # Creates a NumPy array that points to original memory allocation
    indices = np.ctypeslib.as_array(data, shape=(numIndices.value,)).tolist()
    return indices

def getBlendshapes(cmodel, mesh_index):
    shapes = []
    shape_names = getLabels(cmodel, mesh_index)
    if (shape_names == None): return shapes

    for i, label in enumerate(shape_names):
        blendshape = vCMeshShape()
        blendshape.name    = label
        blendshape.verts   = getBlendShapeVerts(cmodel, mesh_index, i)
        blendshape.indices = getMorphIndices(cmodel, mesh_index, i)
        shapes.append(blendshape)
    return shapes


