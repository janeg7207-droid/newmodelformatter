"""2K26 Quick-Port by Vynx.dev.

Copyright (c) 2026 Vynx.dev. All rights reserved.
This add-on is proprietary software. Unauthorized redistribution,
rebranding, or resale is prohibited.
"""

bl_info = {
    "name": "2K26 Quick Port by Vynx.dev",
    "author": "Vynx.dev",
    "version": (1, 0, 1),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Vynx Tools",
    "description": "WWE 2K26 porting workflow tools for base models and attires.",
    "category": "Object",
}

import bpy
import json
import re
import threading
import time
import urllib.request
from mathutils import Matrix


                                                     
HOW_TO_VIDEO_URL = "https://www.youtube.com/watch?v=inYs4e8VbNw"
VYNX_WEBSITE_URL = "https://vynx.dev"
UPDATE_MANIFEST_URL = "https://vynx.dev/downloads/Quick-Port_version.json"
UPDATE_DOWNLOAD_URL = "https://vynx.dev/downloads/Quick-Port_Vynx.dev.zip"
UPDATE_CHANGELOG_URL = "https://vynx.dev/downloads"
UPDATE_REMIND_LATER_HOURS = 24
OFFICIAL_BUILD_LABEL = "Official build by Vynx.dev"
_update_check_running = False
_update_check_result = None


                                                              
         
                                                              

def get_selected_objects(context):
    return list(context.selected_objects)


def version_tuple(version):
    if isinstance(version, (tuple, list)):
        parts = []
        for item in version:
            try:
                parts.append(int(item))
            except (TypeError, ValueError):
                parts.append(0)
        return tuple(parts)

    if isinstance(version, str):
        matches = re.findall(r"\d+", version)
        return tuple(int(match) for match in matches)

    try:
        return (int(version),)
    except (TypeError, ValueError):
        return tuple()


def get_installed_version_string():
    installed_version = bl_info.get("version", ())
    version_parts = version_tuple(installed_version)

    if version_parts:
        return ".".join(str(part) for part in version_parts)

    return "0.0.0"


def is_update_newer(installed_version, latest_version):
    installed_tuple = version_tuple(installed_version)
    latest_tuple = version_tuple(latest_version)

    max_len = max(len(installed_tuple), len(latest_tuple), 1)
    installed_tuple += (0,) * (max_len - len(installed_tuple))
    latest_tuple += (0,) * (max_len - len(latest_tuple))

    return latest_tuple > installed_tuple


def fetch_update_manifest():
    request = urllib.request.Request(
        UPDATE_MANIFEST_URL,
        headers={"User-Agent": f"VynxQuickPort/{get_installed_version_string()}"},
    )

    with urllib.request.urlopen(request, timeout=5) as response:
        payload = response.read().decode("utf-8")

    manifest = json.loads(payload)

    if not isinstance(manifest, dict):
        raise ValueError("Update manifest is not a JSON object.")

    return manifest


def is_official_download_url(url):
    return str(url).startswith("https://vynx.dev/downloads/") and str(url).lower().endswith(".zip")


def is_official_vynx_url(url):
    return str(url).startswith("https://vynx.dev/")


def get_update_download_url(scene):
    manifest_url = str(getattr(scene, "vynx_qpt_update_download_url", "") or "").strip()

    if is_official_download_url(manifest_url):
        return manifest_url

    return UPDATE_DOWNLOAD_URL


def apply_update_manifest_to_scene(scene, manifest, installed_version):
    latest_version = str(manifest.get("latest_version", "") or "")
    message = str(manifest.get("message", "") or "")
    download_url = str(manifest.get("download_url", "") or "")
    changelog_url = str(manifest.get("changelog_url", "") or "")

    if not latest_version:
        raise ValueError("Manifest missing latest_version.")

    scene.vynx_qpt_latest_version = latest_version
    scene.vynx_qpt_update_message = message
    scene.vynx_qpt_update_download_url = (
        download_url if is_official_download_url(download_url) else UPDATE_DOWNLOAD_URL
    )
    scene.vynx_qpt_update_changelog_url = (
        changelog_url if is_official_vynx_url(changelog_url) else UPDATE_CHANGELOG_URL
    )

    if is_update_newer(installed_version, latest_version):
        current_time = time.time()

        if latest_version and latest_version == scene.vynx_qpt_dismissed_version:
            scene.vynx_qpt_update_status = "DISMISSED"
        elif current_time < scene.vynx_qpt_remind_after_timestamp:
            scene.vynx_qpt_update_status = "REMIND_LATER"
        else:
            scene.vynx_qpt_update_status = "OUTDATED"
    else:
        scene.vynx_qpt_update_status = "UP_TO_DATE"


def begin_async_update_check(scene, installed_version):
    global _update_check_running
    global _update_check_result

    if _update_check_running:
        return False

    _update_check_running = True
    _update_check_result = None

    def worker():
        global _update_check_result

        try:
            _update_check_result = {"ok": True, "manifest": fetch_update_manifest()}
        except Exception as exc:
            _update_check_result = {"ok": False, "error": get_short_update_error(exc)}

    def finish_on_main_thread():
        global _update_check_running
        global _update_check_result

        if _update_check_result is None:
            return 0.2

        result = _update_check_result
        _update_check_result = None
        _update_check_running = False

        try:
            if result.get("ok"):
                apply_update_manifest_to_scene(scene, result["manifest"], installed_version)
            else:
                scene.vynx_qpt_update_status = "ERROR"
                scene.vynx_qpt_update_error = result.get("error", "Unknown error.")
        except Exception as exc:
            scene.vynx_qpt_update_status = "ERROR"
            scene.vynx_qpt_update_error = get_short_update_error(exc)

        return None

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    bpy.app.timers.register(finish_on_main_thread, first_interval=0.2)

    return True


def is_mesh(obj):
    return obj is not None and obj.type == 'MESH'


def is_armature(obj):
    return obj is not None and obj.type == 'ARMATURE'


def validate_skeleton_target(obj):
    return obj is not None and obj.type == 'ARMATURE'


def has_vertex_groups(obj):
    return hasattr(obj, "vertex_groups") and obj.vertex_groups is not None


def count_vertex_groups(obj):
    if not has_vertex_groups(obj):
        return 0
    return len(obj.vertex_groups)


def clear_vertex_groups(obj):
    if not has_vertex_groups(obj):
        return 0

    count = len(obj.vertex_groups)

    while obj.vertex_groups:
        obj.vertex_groups.remove(obj.vertex_groups[-1])

    return count


def clear_parent_keep_transform(obj):
    world_matrix = obj.matrix_world.copy()

    if obj.parent is not None:
        obj.parent = None
        obj.matrix_parent_inverse = Matrix.Identity(4)
        obj.matrix_world = world_matrix
        return True

    return False


def get_stored_skeleton(context):
    name = getattr(context.scene, "vynx_qpt_skeleton_object_name", "")
    if not name:
        return None

    obj = bpy.data.objects.get(name)

    if obj is not None and not validate_skeleton_target(obj):
        return None

    return obj


def move_to_skeleton_collection(obj, skeleton):
    if not skeleton.users_collection:
        return

    target_collection = skeleton.users_collection[0]

    if obj.name not in target_collection.objects:
        target_collection.objects.link(obj)

    for collection in list(obj.users_collection):
        if collection != target_collection:
            try:
                collection.objects.unlink(obj)
            except RuntimeError:
                pass


def collection_has_child(parent, child):
    return parent is not None and child.name in parent.children


def iter_collection_parents(child):
    for scene in bpy.data.scenes:
        if collection_has_child(scene.collection, child):
            yield scene.collection

    for collection in bpy.data.collections:
        if collection_has_child(collection, child):
            yield collection


def is_model_ap_collection(collection):
    if collection is None or not collection.name.startswith("Model APs"):
        return False

    for obj in collection.objects:
        base_name = obj.name.split(".")[0]
        if base_name == "ap_root" or base_name.startswith("ap_"):
            return True

    return True


def find_model_ap_collections():
    return [
        collection for collection in bpy.data.collections
        if is_model_ap_collection(collection)
    ]


def collection_contains_object(collection, obj):
    if collection is None or obj is None:
        return False

    return obj.name in collection.objects


def retarget_ap_constraints(collection, skeleton):
    changed_count = 0
    missing_bones = set()

    for obj in collection.objects:
        for constraint in obj.constraints:
            if constraint.type != 'ARMATURE':
                continue

            if not constraint.targets:
                target = constraint.targets.new()
                target.target = skeleton
                changed_count += 1
                continue

            for target in constraint.targets:
                subtarget = getattr(target, "subtarget", "")
                target.target = skeleton
                if subtarget and subtarget not in skeleton.data.bones:
                    missing_bones.add(subtarget)
                changed_count += 1

    return changed_count, missing_bones


def move_model_aps_to_skeleton(skeleton):
    if skeleton is None or not validate_skeleton_target(skeleton):
        return False, "No valid skeleton target.", 0, 0

    if not skeleton.users_collection:
        return False, f"Skeleton '{skeleton.name}' is not linked to a collection.", 0, 0

    target_collection = skeleton.users_collection[0]
    ap_collections = find_model_ap_collections()

    if not ap_collections:
        return False, "No Model APs collection detected.", 0, 0

    moved_count = 0
    constraint_count = 0
    missing_bones = set()

    for ap_collection in ap_collections:
        parents = list(iter_collection_parents(ap_collection))
        already_under_target = any(parent == target_collection for parent in parents)

        if not already_under_target:
            target_collection.children.link(ap_collection)
            moved_count += 1

        for parent in parents:
            if parent != target_collection:
                try:
                    parent.children.unlink(ap_collection)
                except RuntimeError:
                    pass

        changed, missing = retarget_ap_constraints(ap_collection, skeleton)
        constraint_count += changed
        missing_bones.update(missing)

    warning = ""
    if missing_bones:
        preview = ", ".join(sorted(missing_bones)[:5])
        extra = "" if len(missing_bones) <= 5 else f" +{len(missing_bones) - 5} more"
        warning = f" Missing AP bone target(s) on '{skeleton.name}': {preview}{extra}."

    msg = (
        f"Moved {moved_count} Model APs collection(s) to '{skeleton.name}' "
        f"and retargeted {constraint_count} AP constraint target(s).{warning}"
    )

    return True, msg, moved_count, constraint_count


def parent_to_skeleton_keep_transform(obj, skeleton):
    if obj == skeleton:
        return False

    world_matrix = obj.matrix_world.copy()

    obj.parent = skeleton
    obj.matrix_parent_inverse = skeleton.matrix_world.inverted()
    obj.matrix_world = world_matrix

    move_to_skeleton_collection(obj, skeleton)

    return True


def set_armature_modifier_to_skeleton(obj, skeleton):
    if obj == skeleton:
        return False

    if obj.type not in {'MESH', 'CURVE', 'SURFACE', 'LATTICE'}:
        return False

    armature_mod = None

    for mod in obj.modifiers:
        if mod.type == 'ARMATURE':
            armature_mod = mod
            break

    if armature_mod is None:
        armature_mod = obj.modifiers.new(name="Armature", type='ARMATURE')

    armature_mod.object = skeleton
    armature_mod.use_vertex_groups = True

    return True


def send_objects_to_skeleton(objects, skeleton):
    parented_count = 0
    modifier_count = 0

    for obj in objects:
        if obj == skeleton:
            continue

        if parent_to_skeleton_keep_transform(obj, skeleton):
            parented_count += 1

        if set_armature_modifier_to_skeleton(obj, skeleton):
            modifier_count += 1

    return parented_count, modifier_count


def run_pwm_heat_seek(context, source, destination_objects):
    if not destination_objects:
        return True, "No destination objects."

    try:
        from WWE2K_MDL.Blender.Extras.streamline4_1 import heat_seek_rigging
    except Exception as exc:
        return False, (
            "Could not import PWM Heat Seek function. "
            "Make sure the WWE2K_MDL / PWM add-on is installed and enabled. "
            f"Import error: {exc}"
        )

    method = getattr(context.scene, 'mdl_weight_search_method', 'AUTO')

    try:
        heat_seek_rigging(source, destination_objects, search_method=method)
    except Exception as exc:
        return False, f"Heat Seek failed: {exc}"

    return True, f"Heat Seek ran on {len(destination_objects)} object(s) using '{source.name}'."


def mesh_has_real_weights(obj):
    if not is_mesh(obj):
        return False

    for vertex in obj.data.vertices:
        if len(vertex.groups) > 0:
            return True

    return False


def transfer_weights_from_source_to_target(context, source, target):
    if source == target:
        return False, "Source and target are the same object."

    if not is_mesh(source):
        return False, f"Source '{source.name}' is not a mesh."

    if not is_mesh(target):
        return False, f"Target '{target.name}' is not a mesh."

    if not mesh_has_real_weights(source):
        return False, f"Source '{source.name}' has no real vertex weights."

    clear_vertex_groups(target)

    if bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode='OBJECT')

    bpy.ops.object.select_all(action='DESELECT')

    target.select_set(True)
    source.select_set(True)
    context.view_layer.objects.active = source

    try:
        bpy.ops.object.data_transfer(
            data_type='VGROUP_WEIGHTS',
            use_create=True,
            vert_mapping='POLYINTERP_NEAREST',
            layers_select_src='ALL',
            layers_select_dst='NAME',
            mix_mode='REPLACE',
            mix_factor=1.0
        )
    except Exception as exc:
        return False, str(exc)

    if not mesh_has_real_weights(target):
        return False, f"Transfer ran, but '{target.name}' still has no actual vertex weights."

    return True, "OK"


                                                              
                                
                                                              

def evaluate_hair_alignment_skeletons(armature_1, armature_2):
    arm1_has_jhair = "J_Hair" in armature_1.data.bones
    arm2_has_jhair = "J_Hair" in armature_2.data.bones

    if arm1_has_jhair and not arm2_has_jhair:
        donor = armature_1
        receiver = armature_2
    elif arm2_has_jhair and not arm1_has_jhair:
        donor = armature_2
        receiver = armature_1
    else:
        if len(armature_1.data.bones) > len(armature_2.data.bones):
            donor = armature_1
            receiver = armature_2
        else:
            donor = armature_2
            receiver = armature_1

    return donor, receiver


def run_pwm_align_skeleton_hair_only(context, armature_1, armature_2):
    try:
        from WWE2K_MDL.Blender.Extras.skeleton_alignment import (
            alignArmature,
            check_parenting,
        )
    except Exception as exc:
        return False, None, (
            "Could not import PWM skeleton alignment function. "
            "Make sure the WWE2K_MDL / PWM add-on is installed and enabled. "
            f"Import error: {exc}"
        )

    donor, receiver = evaluate_hair_alignment_skeletons(armature_1, armature_2)

    if bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode='OBJECT')

    try:
        alignArmature(donor, receiver, hair_only=True)
        check_parenting(receiver)
        bpy.ops.object.mode_set(mode='OBJECT')
    except Exception as exc:
        try:
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass
        return False, None, f"Prep Skeleton failed: {exc}"

    return True, receiver, f"Hair-only skeleton alignment complete. Donor: '{donor.name}', receiver: '{receiver.name}'."


                                                              
                       
                                                              

def prep_parts_to_skeleton(context, label):
    selected = get_selected_objects(context)
    skeleton = context.view_layer.objects.active

    if not selected:
        return {'CANCELLED'}, "No objects selected.", None

    if skeleton is None:
        return {'CANCELLED'}, "No active skeleton/object. Select the skeleton last.", None

    if not validate_skeleton_target(skeleton):
        return {'CANCELLED'}, f"Active target '{skeleton.name}' is not a skeleton/armature. Select the orange Skeleton object LAST, not body:skinned.", None

    parts = [obj for obj in selected if obj != skeleton]

    if not parts:
        return {'CANCELLED'}, f"Select {label} parts first, then select skeleton last.", None

    cleared_count = 0

    for obj in parts:
        if clear_parent_keep_transform(obj):
            cleared_count += 1

    parented_count, modifier_count = send_objects_to_skeleton(parts, skeleton)

    context.scene.vynx_qpt_skeleton_object_name = skeleton.name

    msg = (
        f"{label} done: cleared {cleared_count}, sent {parented_count} part(s) "
        f"to '{skeleton.name}', set {modifier_count} Armature modifier(s)."
    )

    return {'FINISHED'}, msg, skeleton


def heat_seek_parts_to_stored_skeleton(context, label):
    original_selection = get_selected_objects(context)
    source_body = context.view_layer.objects.active
    skeleton = get_stored_skeleton(context)

    if skeleton is None:
        return {'CANCELLED'}, f"No stored skeleton. Run the matching skeleton/port prep step first."

    if source_body is None:
        return {'CANCELLED'}, "No active source body. Select body:skinned last."

    if not is_mesh(source_body):
        return {'CANCELLED'}, f"Active source '{source_body.name}' is not a mesh. Select body:skinned last."

    preserved_source_groups = count_vertex_groups(source_body)

    targets = [
        obj for obj in original_selection
        if obj != source_body
        and obj != skeleton
        and is_mesh(obj)
    ]

    if not targets:
        return {'CANCELLED'}, "No target meshes selected. Select target parts first, then body:skinned last."

    deleted_groups = 0

    for obj in targets:
        deleted_groups += clear_vertex_groups(obj)

    heat_ok, heat_msg = run_pwm_heat_seek(context, source_body, targets)

    parented_count, modifier_count = send_objects_to_skeleton(targets, skeleton)

                                                        
    bpy.ops.object.select_all(action='DESELECT')

    for obj in original_selection:
        if obj.name in bpy.data.objects:
            obj.select_set(True)

    if source_body.name in bpy.data.objects:
        context.view_layer.objects.active = source_body

    if not heat_ok:
        return {'CANCELLED'}, heat_msg

    msg = (
        f"{label} done: deleted {deleted_groups} groups from {len(targets)} target part(s). "
        f"Preserved '{source_body.name}' with {preserved_source_groups} group(s). "
        f"{heat_msg}, moved {parented_count} part(s) to '{skeleton.name}', "
        f"set {modifier_count} Armature modifier(s)."
    )

    return {'FINISHED'}, msg


def apply_pwm_hpl_to_basemodel():
    try:
        from WWE2K_MDL.Serialize.hpl_roundtrip import (
            extract_hpl_data,
            apply_hpl_to_basemodel,
            find_basemodel_meshes,
        )
    except Exception as exc:
        return False, f"Could not import PWM HPL tools. Import error: {exc}"

    base_meshes = find_basemodel_meshes()
    if not base_meshes:
        return False, "No M_Head or M_Body found. Import the baseModel first."

    hpl_data, source_desc = extract_hpl_data()
    if not hpl_data:
        return False, "No HPL found in any loaded attire. Make sure an attire MCD is imported."

    success, message = apply_hpl_to_basemodel(hpl_data)
    if not success:
        return False, message

    return True, f"{message} (from {source_desc})"


def get_short_update_error(error_text):
    if not error_text:
        return "Unknown error."

    return str(error_text).strip()[:120]


class VYNXQPT_OT_step1_prepare_body(bpy.types.Operator):
    bl_idname = "vynx_qpt.step1_prepare_body"
    bl_label = "Step 1 - Prepare Body"
    bl_description = "Join the selected head into body:skinned and preserve the skeleton setup"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = get_selected_objects(context)
        body = context.view_layer.objects.active

        if len(selected) != 2:
            self.report({'WARNING'}, "Select exactly 2 mesh objects: head first, body last.")
            return {'CANCELLED'}

        if body is None:
            self.report({'WARNING'}, "No active body object. Select body:skinned last.")
            return {'CANCELLED'}

        if not is_mesh(body):
            self.report({'WARNING'}, "Active object must be body:skinned mesh.")
            return {'CANCELLED'}

        head_candidates = [obj for obj in selected if obj != body]

        if len(head_candidates) != 1:
            self.report({'WARNING'}, "Could not determine head mesh. Select head first, body last.")
            return {'CANCELLED'}

        head = head_candidates[0]

        if not is_mesh(head):
            self.report({'WARNING'}, "Head object must be a mesh.")
            return {'CANCELLED'}

        body_name_lower = body.name.lower()
        head_name_lower = head.name.lower()

        if "body" not in body_name_lower:
            self.report({'WARNING'}, f"Active object '{body.name}' does not look like body:skinned.")
            return {'CANCELLED'}

        if "head" not in head_name_lower:
            self.report({'WARNING'}, f"Other object '{head.name}' does not look like head:skinned.")
            return {'CANCELLED'}

        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode='OBJECT')

        final_name = body.name
        final_data_name = body.data.name

                                                                                 
        body_parent = body.parent
        body_parent_inverse = body.matrix_parent_inverse.copy()
        body_world = body.matrix_world.copy()

        armature_targets = []
        for obj in [head, body]:
            for mod in obj.modifiers:
                if mod.type == 'ARMATURE' and mod.object is not None:
                    armature_targets.append(mod.object)

                                                                                         
        keep_objects = set(selected)

        def keep_parent_chain(obj):
            current = obj.parent
            while current is not None:
                keep_objects.add(current)
                current = current.parent

        keep_parent_chain(head)
        keep_parent_chain(body)

        for arm_obj in armature_targets:
            keep_objects.add(arm_obj)
            keep_parent_chain(arm_obj)

                                                                                        
        delete_count = 0
        bpy.ops.object.select_all(action='DESELECT')

        for obj in list(context.scene.objects):
            if obj not in keep_objects:
                obj.select_set(True)
                delete_count += 1

        if delete_count > 0:
            bpy.ops.object.delete()

                                     
        bpy.ops.object.select_all(action='DESELECT')

        if head.name not in bpy.data.objects:
            self.report({'ERROR'}, "Head object was removed before join. Operation cancelled.")
            return {'CANCELLED'}

        if body.name not in bpy.data.objects:
            self.report({'ERROR'}, "Body object was removed before join. Operation cancelled.")
            return {'CANCELLED'}

        head.select_set(True)
        body.select_set(True)
        context.view_layer.objects.active = body

        try:
            bpy.ops.object.join()
        except Exception as exc:
            self.report({'ERROR'}, f"Join failed: {exc}")
            return {'CANCELLED'}

        final_obj = context.view_layer.objects.active

        if final_obj is None:
            self.report({'ERROR'}, "Join finished but no active body object was found.")
            return {'CANCELLED'}

                                           
        final_obj.name = final_name
        final_obj.data.name = final_data_name
        final_obj.parent = body_parent
        final_obj.matrix_parent_inverse = body_parent_inverse
        final_obj.matrix_world = body_world

                                                                                     
        if body_parent is not None:
            move_to_skeleton_collection(final_obj, body_parent)

                                                                        
        if validate_skeleton_target(body_parent):
            context.scene.vynx_qpt_skeleton_object_name = body_parent.name
        elif armature_targets:
            context.scene.vynx_qpt_skeleton_object_name = armature_targets[0].name

                                                                                         
        for mod in final_obj.modifiers:
            if mod.type == 'ARMATURE' and mod.object is None and armature_targets:
                mod.object = armature_targets[0]

        bpy.ops.object.select_all(action='DESELECT')
        final_obj.select_set(True)
        context.view_layer.objects.active = final_obj

        self.report(
            {'INFO'},
            f"Prepared body: deleted {delete_count} object(s), joined head into '{final_name}', preserved skeleton hierarchy."
        )
        return {'FINISHED'}


                                                              
                               
                                                              

class VYNXQPT_OT_step1_prep_mouth_parts(bpy.types.Operator):
    bl_idname = "vynx_qpt.step1_prep_mouth_parts"
    bl_label = "Step 1 - Prep Mouth Parts"
    bl_description = "Send selected mouth parts to the active skeleton and store that skeleton"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        result, msg, _skeleton = prep_parts_to_skeleton(context, "Step 1")
        if result == {'FINISHED'}:
            self.report({'INFO'}, msg)
        else:
            self.report({'WARNING'}, msg)
        return result


class VYNXQPT_OT_step2_heat_seek_body_parts(bpy.types.Operator):
    bl_idname = "vynx_qpt.step2_heat_seek_body_parts"
    bl_label = "Step 2 - Heat Seek Body Parts"
    bl_description = "Run Heat Seek on selected body parts using the stored skeleton workflow"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        result, msg = heat_seek_parts_to_stored_skeleton(context, "Step 2")
        if result == {'FINISHED'}:
            self.report({'INFO'}, msg)
        else:
            self.report({'ERROR'}, msg)
        return result


                                                              
                           
                                                              

class VYNXQPT_OT_attire_prep_skeleton(bpy.types.Operator):
    bl_idname = "vynx_qpt.attire_prep_skeleton"
    bl_label = "Prep Skeleton"
    bl_description = "Align two selected skeletons for the attire workflow and store the result"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_armatures = [obj for obj in get_selected_objects(context) if is_armature(obj)]

        if len(selected_armatures) != 2:
            self.report({'WARNING'}, "Select exactly two skeletons/armatures.")
            return {'CANCELLED'}

        ok, receiver, msg = run_pwm_align_skeleton_hair_only(
            context,
            selected_armatures[0],
            selected_armatures[1],
        )

        if not ok:
            self.report({'ERROR'}, msg)
            return {'CANCELLED'}

        context.scene.vynx_qpt_skeleton_object_name = receiver.name

        ap_msg = ""
        ap_collections = find_model_ap_collections()
        if ap_collections:
            ap_ok, ap_msg, _moved_count, _constraint_count = move_model_aps_to_skeleton(receiver)
            if not ap_ok:
                ap_msg = f" AP move skipped: {ap_msg}"
            else:
                ap_msg = f" {ap_msg}"

                                                              
        bpy.ops.object.select_all(action='DESELECT')
        for obj in selected_armatures:
            if obj.name in bpy.data.objects:
                obj.select_set(True)
        context.view_layer.objects.active = receiver

        self.report({'INFO'}, f"{msg} Stored skeleton: '{receiver.name}'.{ap_msg}")
        return {'FINISHED'}


class VYNXQPT_OT_attire_quick_port_hair(bpy.types.Operator):
    bl_idname = "vynx_qpt.attire_quick_port_hair"
    bl_label = "Quick Port Hair/Lamberts"
    bl_description = "Send selected hair and lambert parts to the stored attire skeleton"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        result, msg, _skeleton = prep_parts_to_skeleton(context, "Quick Port Hair")
        if result == {'FINISHED'}:
            self.report({'INFO'}, msg)
        else:
            self.report({'WARNING'}, msg)
        return result


class VYNXQPT_OT_attire_heat_seek_attire(bpy.types.Operator):
    bl_idname = "vynx_qpt.attire_heat_seek_attire"
    bl_label = "Heat Seek Attire"
    bl_description = "Run Heat Seek on selected attire parts using the stored skeleton"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        result, msg = heat_seek_parts_to_stored_skeleton(context, "Heat Seek Attire")
        if result == {'FINISHED'}:
            self.report({'INFO'}, msg)
        else:
            self.report({'ERROR'}, msg)
        return result


                                                              
                                                              
                         

class VYNXQPT_OT_apply_hpl_to_basemodel(bpy.types.Operator):
    bl_idname = "vynx_qpt.apply_hpl_to_basemodel"
    bl_label = "Apply HPL to BaseModel"
    bl_description = "Run PWM Apply HPL to BaseModel using the loaded attire HPL"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        success, msg = apply_pwm_hpl_to_basemodel()
        if success:
            self.report({'INFO'}, msg)
            return {'FINISHED'}

        self.report({'ERROR'}, msg)
        return {'CANCELLED'}


class VYNXQPT_OT_clear_and_keep_transform(bpy.types.Operator):
    bl_idname = "vynx_qpt.clear_and_keep_transform"
    bl_label = "Clear and Keep Transform"
    bl_description = "Clear selected object parents while preserving their world transforms"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = get_selected_objects(context)

        if not selected:
            self.report({'WARNING'}, "No objects selected.")
            return {'CANCELLED'}

        cleared_count = 0

        for obj in selected:
            if clear_parent_keep_transform(obj):
                cleared_count += 1

        self.report({'INFO'}, f"Cleared parent and kept transform on {cleared_count} object(s).")
        return {'FINISHED'}


class VYNXQPT_OT_send_to_skeleton(bpy.types.Operator):
    bl_idname = "vynx_qpt.send_to_skeleton"
    bl_label = "Send To Skeleton"
    bl_description = "Parent selected objects to the active skeleton and set armature modifiers"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = get_selected_objects(context)
        skeleton = context.view_layer.objects.active

        if not selected:
            self.report({'WARNING'}, "No objects selected.")
            return {'CANCELLED'}

        if skeleton is None:
            self.report({'WARNING'}, "No active skeleton/object. Select the skeleton last.")
            return {'CANCELLED'}

        if not validate_skeleton_target(skeleton):
            self.report({'WARNING'}, f"Active target '{skeleton.name}' is not a skeleton/armature. Select the orange Skeleton object LAST, not body:skinned.")
            return {'CANCELLED'}

        children = [obj for obj in selected if obj != skeleton]

        if not children:
            self.report({'WARNING'}, "Select child objects first, then select the skeleton last.")
            return {'CANCELLED'}

        parented_count, modifier_count = send_objects_to_skeleton(children, skeleton)
        context.scene.vynx_qpt_skeleton_object_name = skeleton.name

        self.report(
            {'INFO'},
            f"Sent {parented_count} object(s) to '{skeleton.name}' and set {modifier_count} Armature modifier(s)."
        )
        return {'FINISHED'}


class VYNXQPT_OT_move_model_aps(bpy.types.Operator):
    bl_idname = "vynx_qpt.move_model_aps"
    bl_label = "Move Models AP"
    bl_description = "Move detected Model APs to the active skeleton and retarget AP constraints"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        skeleton = context.view_layer.objects.active

        if skeleton is None:
            self.report({'WARNING'}, "No active skeleton/object. Select the 2K26 skeleton last.")
            return {'CANCELLED'}

        if not validate_skeleton_target(skeleton):
            self.report({'WARNING'}, f"Active target '{skeleton.name}' is not a skeleton/armature. Select the 2K26 skeleton.")
            return {'CANCELLED'}

        ok, msg, _moved_count, _constraint_count = move_model_aps_to_skeleton(skeleton)

        if not ok:
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}

        context.scene.vynx_qpt_skeleton_object_name = skeleton.name
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class VYNXQPT_OT_delete_all_vertex_groups(bpy.types.Operator):
    bl_idname = "vynx_qpt.delete_all_vertex_groups"
    bl_label = "Delete All Vertex Groups"
    bl_description = "Delete every vertex group from the selected objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = get_selected_objects(context)

        if not selected:
            self.report({'WARNING'}, "No objects selected.")
            return {'CANCELLED'}

        changed_count = 0
        group_count = 0

        for obj in selected:
            if has_vertex_groups(obj):
                group_count += clear_vertex_groups(obj)
                changed_count += 1

        self.report({'INFO'}, f"Deleted {group_count} vertex groups from {changed_count} object(s).")
        return {'FINISHED'}


class VYNXQPT_OT_transfer_weights_manual(bpy.types.Operator):
    bl_idname = "vynx_qpt.transfer_weights_manual"
    bl_label = "Transfer Weights"
    bl_description = "Transfer vertex weights from the active mesh to selected target meshes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        original_selection = get_selected_objects(context)
        source = context.view_layer.objects.active

        if source is None:
            self.report({'WARNING'}, "No active source mesh. Select the good weighted mesh last.")
            return {'CANCELLED'}

        if not is_mesh(source):
            self.report({'WARNING'}, f"Active source '{source.name}' is not a mesh.")
            return {'CANCELLED'}

        targets = [obj for obj in original_selection if obj != source and is_mesh(obj)]

        if not targets:
            self.report({'WARNING'}, "No target meshes selected. Select broken meshes first, source mesh last.")
            return {'CANCELLED'}

        success_count = 0
        failed = []

        for target in targets:
            ok, msg = transfer_weights_from_source_to_target(context, source, target)

            if ok:
                success_count += 1
            else:
                failed.append(f"{target.name}: {msg}")

        bpy.ops.object.select_all(action='DESELECT')

        for obj in original_selection:
            if obj.name in bpy.data.objects:
                obj.select_set(True)

        if source.name in bpy.data.objects:
            context.view_layer.objects.active = source

        if failed:
            self.report(
                {'WARNING'},
                f"Transferred weights to {success_count}; failed {len(failed)}. First fail: {failed[0]}"
            )
        else:
            self.report(
                {'INFO'},
                f"Transferred weights from '{source.name}' to {success_count} mesh object(s)."
            )

        return {'FINISHED'}


class VYNXQPT_OT_open_how_to_video(bpy.types.Operator):
    bl_idname = "vynx_qpt.open_how_to_video"
    bl_label = "Watch How-To Video"
    bl_description = "Open the Quick-Port tutorial video in your browser"
    bl_options = {'REGISTER'}

    def execute(self, context):
        bpy.ops.wm.url_open(url=HOW_TO_VIDEO_URL)
        return {'FINISHED'}


class VYNXQPT_OT_open_vynx_website(bpy.types.Operator):
    bl_idname = "vynx_qpt.open_vynx_website"
    bl_label = "Made by Vynx.dev"
    bl_description = "Open Vynx.dev in your browser"
    bl_options = {'REGISTER'}

    def execute(self, context):
        bpy.ops.wm.url_open(url=VYNX_WEBSITE_URL)
        return {'FINISHED'}


class VYNXQPT_OT_check_for_updates(bpy.types.Operator):
    bl_idname = "vynx_qpt.check_for_updates"
    bl_label = "Check For Updates"
    bl_description = "Check vynx.dev for the latest available Quick-Port version"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        installed_version = get_installed_version_string()

        if _update_check_running:
            self.report({'INFO'}, "Update check is already running.")
            return {'FINISHED'}

        scene.vynx_qpt_update_status = "CHECKING"
        scene.vynx_qpt_update_error = ""

        if begin_async_update_check(scene, installed_version):
            self.report({'INFO'}, "Checking vynx.dev for updates...")
            return {'FINISHED'}

        scene.vynx_qpt_update_status = "ERROR"
        scene.vynx_qpt_update_error = "Update check is already running."
        self.report({'ERROR'}, scene.vynx_qpt_update_error)
        return {'CANCELLED'}


class VYNXQPT_OT_open_update_download(bpy.types.Operator):
    bl_idname = "vynx_qpt.open_update_download"
    bl_label = "Update"
    bl_description = "Open the latest Quick-Port download in your browser"
    bl_options = {'REGISTER'}

    def execute(self, context):
        url = get_update_download_url(context.scene)
        bpy.ops.wm.url_open(url=url)
        return {'FINISHED'}


class VYNXQPT_OT_open_update_changelog(bpy.types.Operator):
    bl_idname = "vynx_qpt.open_update_changelog"
    bl_label = "View Changelog"
    bl_description = "Open the Quick-Port downloads page in your browser"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        url = scene.vynx_qpt_update_changelog_url or UPDATE_CHANGELOG_URL
        bpy.ops.wm.url_open(url=url)
        return {'FINISHED'}


class VYNXQPT_OT_remind_update_later(bpy.types.Operator):
    bl_idname = "vynx_qpt.remind_update_later"
    bl_label = "Remind Me Later"
    bl_description = "Pause this update reminder for 24 hours"
    bl_options = {'REGISTER'}

    def execute(self, context):
        context.scene.vynx_qpt_remind_after_timestamp = time.time() + (UPDATE_REMIND_LATER_HOURS * 3600)
        context.scene.vynx_qpt_update_status = "REMIND_LATER"
        self.report({'INFO'}, f"Update reminder paused for {UPDATE_REMIND_LATER_HOURS} hours.")
        return {'FINISHED'}


class VYNXQPT_OT_dismiss_update_version(bpy.types.Operator):
    bl_idname = "vynx_qpt.dismiss_update_version"
    bl_label = "Don't Show Again"
    bl_description = "Hide this update notification for the current latest version"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        scene.vynx_qpt_dismissed_version = scene.vynx_qpt_latest_version
        scene.vynx_qpt_update_status = "DISMISSED"
        self.report({'INFO'}, f"Dismissed update {scene.vynx_qpt_latest_version or 'for this version'}.")
        return {'FINISHED'}


def draw_tool_section(layout, scene, title, icon, toggle_property, hint, tools):
    section_box = layout.box()
    header = section_box.row(align=True)
    is_expanded = getattr(scene, toggle_property, True)
    header.prop(
        scene,
        toggle_property,
        text=title.upper(),
        emboss=False,
        icon='TRIA_DOWN' if is_expanded else 'TRIA_RIGHT'
    )

    if is_expanded:
        if hint:
            hint_row = section_box.row(align=True)
            hint_row.enabled = False
            hint_row.label(text=hint)

        tool_col = section_box.column(align=True)
        tool_col.scale_y = 1.15

        for operator_id, label, tool_icon in tools:
            draw_safe_operator(tool_col, operator_id, label, tool_icon)

    return section_box


def draw_safe_label(layout, text, icon='NONE'):
    try:
        layout.label(text=text, icon=icon)
    except TypeError:
        layout.label(text=text)


def draw_safe_operator(layout, operator_id, text, icon='NONE', emboss=True):
    try:
        return layout.operator(operator_id, text=text, icon=icon, emboss=emboss)
    except TypeError:
        return layout.operator(operator_id, text=text, emboss=emboss)


def draw_update_section(layout, scene, installed_version, update_status):
    update_box = layout.box()
    header = update_box.row(align=True)
    draw_safe_label(header, "UPDATES", 'FILE_REFRESH')

    draw_safe_label(update_box, f"Version {installed_version}", 'PLUGIN')
    draw_safe_label(update_box, OFFICIAL_BUILD_LABEL, 'CHECKMARK')
    draw_safe_operator(update_box, "vynx_qpt.check_for_updates", "Check For Updates", 'FILE_REFRESH')

    if update_status == "OUTDATED":
        update_box.alert = True
        draw_safe_label(update_box, "Update Available", 'ERROR')
        if scene.vynx_qpt_latest_version:
            draw_safe_label(update_box, f"Latest: {scene.vynx_qpt_latest_version}", 'SORT_DESC')
        if scene.vynx_qpt_update_message:
            update_box.label(text=scene.vynx_qpt_update_message)

        button_col = update_box.column(align=True)
        draw_safe_operator(button_col, "vynx_qpt.open_update_download", "Update", 'IMPORT')
        draw_safe_operator(button_col, "vynx_qpt.remind_update_later", "Remind Me Later", 'TIME')
        draw_safe_operator(button_col, "vynx_qpt.dismiss_update_version", "Don't Show Again", 'CANCEL')
    elif update_status == "UP_TO_DATE":
        draw_safe_label(update_box, "You are up to date.", 'CHECKMARK')
    elif update_status == "ERROR":
        draw_safe_label(update_box, "Update check failed.", 'ERROR')
        if scene.vynx_qpt_update_error:
            update_box.label(text=get_short_update_error(scene.vynx_qpt_update_error))
    elif update_status == "REMIND_LATER":
        draw_safe_label(update_box, "Update reminder paused.", 'TIME')
    elif update_status == "DISMISSED":
        draw_safe_label(update_box, "Update dismissed for this version.", 'CANCEL')
    elif update_status == "CHECKING":
        draw_safe_label(update_box, "Checking for updates...", 'FILE_REFRESH')

    return update_box


def draw_stored_skeleton_status(layout, skeleton, skeleton_name):
    status_box = layout.box()
    status_col = status_box.column(align=True)

    if skeleton:
        draw_safe_label(status_col, f"Stored Skeleton: {skeleton.name}", 'OUTLINER_OB_ARMATURE')
    elif skeleton_name:
        draw_safe_label(status_col, f"Stored Skeleton Missing: {skeleton_name}", 'ERROR')
    else:
        status_col.enabled = False
        draw_safe_label(status_col, "Stored Skeleton: None", 'INFO')


def draw_text_instructions(layout, scene):
    instructions_box = layout.box()
    draw_safe_operator(instructions_box, "vynx_qpt.open_how_to_video", "Watch How-To Video", 'URL')

    header_row = instructions_box.row(align=True)
    header_row.scale_y = 1.2
    header_row.prop(
        scene,
        "vynx_qpt_show_text_instructions",
        text="Hide Text Instructions" if scene.vynx_qpt_show_text_instructions else "Show Text Instructions",
        emboss=True,
        icon='TRIA_DOWN' if scene.vynx_qpt_show_text_instructions else 'TRIA_RIGHT'
    )

    if not scene.vynx_qpt_show_text_instructions:
        return instructions_box

    draw_safe_label(instructions_box, "Base Model Workflow:", 'MESH_CUBE')
    instructions_box.label(text="1. Import 2K26 Base Model.")
    instructions_box.label(text="2. Select head:skinned.")
    instructions_box.label(text="3. Select body:skinned LAST.")
    instructions_box.label(text="4. Press Prepare Body.")
    instructions_box.label(text="5. Import wrestler Base Model.")
    instructions_box.label(text="6. Select Mouth Parts.")
    instructions_box.label(text="7. Select Skeleton LAST.")
    instructions_box.label(text="8. Press Quick Port Mouth.")
    instructions_box.label(text="9. Select all other parts.")
    instructions_box.label(text="10. Select 2K26 body LAST.")
    instructions_box.label(text="11. Press Heat Seek Body Parts.")
    instructions_box.label(text="12. Press A in viewport and Export!")
    instructions_box.label(text="13. Delete all except body:skinned.")
    instructions_box.label(text="14. Continue to Attire Workflow.")

    instructions_box.separator()

    draw_safe_label(instructions_box, "Attire Workflow:", 'MOD_CLOTH')
    instructions_box.label(text="1. Import wrestler Attire.")
    instructions_box.label(text="2. Select BOTH skeletons.")
    instructions_box.label(text="3. Press Prep Skeletons.")
    instructions_box.label(text="4. Select Hair & Lamberts.")
    instructions_box.label(text="5. Select Skeleton LAST.")
    instructions_box.label(text="6. Press Quick Port Hair/Lamberts.")
    instructions_box.label(text="7. Select all other parts.")
    instructions_box.label(text="8. Select body:skinned LAST.")
    instructions_box.label(text="9. Press Heat Seek Attire.")

    return instructions_box


                                                              
          
                                                              

class VYNXQPT_PT_quick_porting_tools(bpy.types.Panel):
    bl_label = "2K26 Quick-Port by Vynx.dev"
    bl_idname = "VYNXQPT_PT_quick_porting_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Vynx Tools"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        skeleton = get_stored_skeleton(context)
        skeleton_name = getattr(context.scene, "vynx_qpt_skeleton_object_name", "")
        installed_version = get_installed_version_string()
        update_status = getattr(scene, "vynx_qpt_update_status", "UNKNOWN")

        header_col = layout.column(align=True)
        draw_safe_operator(header_col, "vynx_qpt.open_vynx_website", "Made by Vynx.dev", 'URL')
        draw_stored_skeleton_status(header_col, skeleton, skeleton_name)

        layout.separator()

        draw_tool_section(layout, scene, "Base Model", 'MESH_CUBE', "vynx_qpt_show_base_model", "", (
            ("vynx_qpt.step1_prepare_body", "Step 1 - Prepare Body", 'OUTLINER_OB_ARMATURE'),
            ("vynx_qpt.step1_prep_mouth_parts", "Step 2 - Quick Port Mouth", 'MESH_DATA'),
            ("vynx_qpt.step2_heat_seek_body_parts", "Step 3 - Heat Seek Body Parts", 'FORCE_VORTEX'),
        ))

        layout.separator()

        draw_tool_section(layout, scene, "Attire", 'MOD_CLOTH', "vynx_qpt_show_attire", "", (
            ("vynx_qpt.attire_prep_skeleton", "Step 1 - Prep Skeletons", 'OUTLINER_OB_ARMATURE'),
            ("vynx_qpt.attire_quick_port_hair", "Step 2 - Quick Port Hair/Lamberts", 'PARTICLEMODE'),
            ("vynx_qpt.attire_heat_seek_attire", "Step 3 - Heat Seek Attire", 'FORCE_VORTEX'),
        ))

        layout.separator()

        draw_tool_section(layout, scene, "Manual Tools", 'TOOL_SETTINGS', "vynx_qpt_show_manual_tools", "", (
            ("vynx_qpt.apply_hpl_to_basemodel", "Apply HPL to BaseModel", 'MOD_MASK'),
            ("vynx_qpt.clear_and_keep_transform", "Clear and Keep Transform", 'LOOP_BACK'),
            ("vynx_qpt.send_to_skeleton", "Send To Skeleton", 'LINKED'),
            ("vynx_qpt.move_model_aps", "Move Models AP", 'EMPTY_AXIS'),
            ("vynx_qpt.delete_all_vertex_groups", "Delete All Vertex Groups", 'TRASH'),
            ("vynx_qpt.transfer_weights_manual", "Transfer Weights", 'MOD_VERTEX_WEIGHT'),
        ))

        layout.separator()

        draw_text_instructions(layout, scene)

        layout.separator()

        draw_update_section(layout, scene, installed_version, update_status)


                                                              
          
                                                              

classes = (
    VYNXQPT_OT_step1_prepare_body,
    VYNXQPT_OT_step1_prep_mouth_parts,
    VYNXQPT_OT_step2_heat_seek_body_parts,
    VYNXQPT_OT_attire_prep_skeleton,
    VYNXQPT_OT_attire_quick_port_hair,
    VYNXQPT_OT_attire_heat_seek_attire,
    VYNXQPT_OT_apply_hpl_to_basemodel,
    VYNXQPT_OT_clear_and_keep_transform,
    VYNXQPT_OT_send_to_skeleton,
    VYNXQPT_OT_move_model_aps,
    VYNXQPT_OT_delete_all_vertex_groups,
    VYNXQPT_OT_transfer_weights_manual,
    VYNXQPT_OT_open_how_to_video,
    VYNXQPT_OT_open_vynx_website,
    VYNXQPT_OT_check_for_updates,
    VYNXQPT_OT_open_update_download,
    VYNXQPT_OT_open_update_changelog,
    VYNXQPT_OT_remind_update_later,
    VYNXQPT_OT_dismiss_update_version,
    VYNXQPT_PT_quick_porting_tools,
)


def register():
    bpy.types.Scene.vynx_qpt_skeleton_object_name = bpy.props.StringProperty(
        name="Vynx Skeleton Object Name",
        description="Stored skeleton object used by workflow steps",
        default=""
    )
    bpy.types.Scene.vynx_qpt_update_status = bpy.props.StringProperty(
        name="Vynx Update Status",
        default="UNKNOWN"
    )
    bpy.types.Scene.vynx_qpt_show_text_instructions = bpy.props.BoolProperty(
        name="Show Text Instructions",
        default=False
    )
    bpy.types.Scene.vynx_qpt_show_base_model = bpy.props.BoolProperty(
        name="Show Base Model Tools",
        default=True
    )
    bpy.types.Scene.vynx_qpt_show_attire = bpy.props.BoolProperty(
        name="Show Attire Tools",
        default=True
    )
    bpy.types.Scene.vynx_qpt_show_manual_tools = bpy.props.BoolProperty(
        name="Show Manual Tools",
        default=True
    )
    bpy.types.Scene.vynx_qpt_latest_version = bpy.props.StringProperty(
        name="Vynx Latest Version",
        default=""
    )
    bpy.types.Scene.vynx_qpt_update_message = bpy.props.StringProperty(
        name="Vynx Update Message",
        default=""
    )
    bpy.types.Scene.vynx_qpt_update_download_url = bpy.props.StringProperty(
        name="Vynx Update Download URL",
        default=""
    )
    bpy.types.Scene.vynx_qpt_update_changelog_url = bpy.props.StringProperty(
        name="Vynx Update Changelog URL",
        default=""
    )
    bpy.types.Scene.vynx_qpt_update_error = bpy.props.StringProperty(
        name="Vynx Update Error",
        default=""
    )
    bpy.types.Scene.vynx_qpt_dismissed_version = bpy.props.StringProperty(
        name="Vynx Dismissed Update Version",
        default=""
    )
    bpy.types.Scene.vynx_qpt_remind_after_timestamp = bpy.props.FloatProperty(
        name="Vynx Remind After Timestamp",
        default=0.0
    )

    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    if hasattr(bpy.types.Scene, "vynx_qpt_skeleton_object_name"):
        del bpy.types.Scene.vynx_qpt_skeleton_object_name
    if hasattr(bpy.types.Scene, "vynx_qpt_update_status"):
        del bpy.types.Scene.vynx_qpt_update_status
    if hasattr(bpy.types.Scene, "vynx_qpt_show_text_instructions"):
        del bpy.types.Scene.vynx_qpt_show_text_instructions
    if hasattr(bpy.types.Scene, "vynx_qpt_show_base_model"):
        del bpy.types.Scene.vynx_qpt_show_base_model
    if hasattr(bpy.types.Scene, "vynx_qpt_show_attire"):
        del bpy.types.Scene.vynx_qpt_show_attire
    if hasattr(bpy.types.Scene, "vynx_qpt_show_manual_tools"):
        del bpy.types.Scene.vynx_qpt_show_manual_tools
    if hasattr(bpy.types.Scene, "vynx_qpt_latest_version"):
        del bpy.types.Scene.vynx_qpt_latest_version
    if hasattr(bpy.types.Scene, "vynx_qpt_update_message"):
        del bpy.types.Scene.vynx_qpt_update_message
    if hasattr(bpy.types.Scene, "vynx_qpt_update_download_url"):
        del bpy.types.Scene.vynx_qpt_update_download_url
    if hasattr(bpy.types.Scene, "vynx_qpt_update_changelog_url"):
        del bpy.types.Scene.vynx_qpt_update_changelog_url
    if hasattr(bpy.types.Scene, "vynx_qpt_update_error"):
        del bpy.types.Scene.vynx_qpt_update_error
    if hasattr(bpy.types.Scene, "vynx_qpt_dismissed_version"):
        del bpy.types.Scene.vynx_qpt_dismissed_version
    if hasattr(bpy.types.Scene, "vynx_qpt_remind_after_timestamp"):
        del bpy.types.Scene.vynx_qpt_remind_after_timestamp


if __name__ == "__main__":
    register()
