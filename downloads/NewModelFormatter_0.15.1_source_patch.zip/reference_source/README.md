# Supplied source snapshot

100 supplied source/configuration files from ModelFormatter, Vynx and WWE2K_MDL
are preserved unchanged with SHA-256 hashes in manifest.json. Compiled DLLs,
EXEs, original mod models and textures are excluded from this source snapshot.
The uploaded PWM VCModel.dll matches Gorilla's bundled DLL exactly.

Active integration uses copied reference weight diagnostics and the tested
Gorilla native repair wrappers. The full Blender add-on is not auto-imported;
its scene setup, operators and updaters are not needed by those wrappers.
The newly supplied source contains import/export and Heat Seek implementations;
full Blender scene processing is not active in the current Windows build.
Gorilla YCL remains unchanged; a folder wrapper now translates it independently
of unsupported WDF/YWA companion processing. Those companions are not presumed
compatible merely because the reference supports embedding their bytes.
