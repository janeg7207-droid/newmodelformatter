"""Bounded native clone-LOD proof and lossless per-LOD HPL additions.

These pure helpers never read or write files. The caller must separately read
the native Base/Attire with the real model reader, prove both clone-LOD layouts,
and establish the anatomical coverage and scene meaning of proposed IDs. HPL's
five mask slots do not establish how many geometry LODs a model contains.
"""
import hashlib
from numbers import Integral
import struct

PATCH_VERSION = 'bounded-clone-lods-and-per-lod-mask-union-1'
EMPTY_HPL = b'HPL!END!' + bytes(4)
_MAX_MODEL_BYTES = 512 * 1024 * 1024
_MAX_MASK_BYTES = 64 * 1024 * 1024
_MAX_GROUP_IDS = 500000
_MAX_FLAG = 255


def _digest(data):
    return hashlib.sha256(data).hexdigest()


def _bytes(data, maximum, label):
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise ValueError(label + ' must be a byte buffer')
    extent = data.nbytes if isinstance(data, memoryview) else len(data)
    if extent > maximum:
        raise ValueError(label + ' exceeds the bounded format')
    return bytes(data)


def _model_payload(data):
    """Base containers can have CTG! before MDL!; attire usually starts MDL!."""
    if data[:4] != b'MCD!':
        raise ValueError('clone proof requires a framed MCD container')
    cursor = 4; payload = None; count = 0
    while cursor < len(data):
        if cursor + 12 > len(data):
            raise ValueError('MCD envelope header is truncated')
        version, size, tag = struct.unpack_from('<II4s', data, cursor)
        start = cursor + 12; end = start + size
        if version != 4 or end > len(data):
            raise ValueError('MCD envelope version or complete extent is unsupported')
        count += 1
        if count > 512:
            raise ValueError('MCD has too many envelopes')
        if tag == b'MDL!':
            if payload is not None:
                raise ValueError('MCD contains ambiguous model envelopes')
            payload = data[start:end]
        if tag == b'END!':
            if size or end != len(data) or payload is None:
                raise ValueError('MCD model or complete terminal envelope is missing')
            return payload
        aligned = (end + 3) & ~3
        if aligned > len(data) or data[end:aligned] != bytes(aligned - end):
            raise ValueError('MCD envelope alignment is invalid')
        cursor = aligned
    raise ValueError('MCD terminal envelope is missing')


def verify_cloned_lods(mcd_bytes):
    """Prove equal complete native geometry segments without file whitelists.

    Segment syntax beyond its mesh count and terminal is validated by the
    caller's native model reader. This helper proves framing, extent and byte
    identity, rather than interpreting or fabricating model geometry.
    """
    data = _bytes(mcd_bytes, _MAX_MODEL_BYTES, 'native MCD')
    model = _model_payload(data)
    if len(model) < 36 or model[:4] != b'MDL!' or struct.unpack_from('<II', model, 4) != (47, 1):
        raise ValueError('clone proof requires the framed native v47/1 36-byte MDL header')
    cursor = 36; lods = None; terminal = False; chunks = 0
    while cursor < len(model):
        if cursor + 8 > len(model):
            raise ValueError('native MDL chunk header is truncated')
        tag, size = struct.unpack_from('<4sI', model, cursor)
        start = cursor + 8; end = start + size
        if end > len(model):
            raise ValueError('native MDL chunk extent leaves its envelope')
        chunks += 1
        if chunks > 512:
            raise ValueError('native MDL has too many chunks')
        if tag == b'LODs':
            if lods is not None:
                raise ValueError('native MDL has ambiguous LOD chunks')
            lods = model[start:end]
        if tag == b'END!':
            if size or end != len(model):
                raise ValueError('native MDL terminal extent or trailing bytes are invalid')
            terminal = True; break
        cursor = end
    if not terminal or lods is None or len(lods) < 4:
        raise ValueError('native MDL LOD or terminal framing is incomplete')
    count = struct.unpack_from('<I', lods)[0]
    if not 1 <= count <= 5:
        raise ValueError('native geometry LOD count must be within the supported range 1..5')
    extent = len(lods) - 4
    if extent % count or extent // count < 12:
        raise ValueError('native LOD payload does not divide into complete equal segment extents')
    size = extent // count
    first = lods[4:4 + size]
    mesh_count = struct.unpack_from('<I', first)[0]
    if not 1 <= mesh_count <= 4096 or first[-8:] != b'ENDM' + bytes(4):
        raise ValueError('native LOD segment mesh count or terminal is unsupported')
    for index in range(count):
        segment = lods[4 + index * size:4 + (index + 1) * size]
        if segment != first:
            raise ValueError('native geometry LOD segments are not byte-identical clones')
    return {'version': PATCH_VERSION, 'lod_count': count, 'mesh_count': mesh_count,
            'lod_segment_bytes': size, 'lod_segment_sha256': _digest(first),
            'all_lod_segments_byte_identical': True, 'complete_lod_extent_checked': True,
            'inner_mdl_sha256': _digest(model), 'mcd_sha256': _digest(data),
            'native_reader_required': True,
            'scope': 'bounded v47/1 framing and complete LOD-segment byte identity; native geometry syntax and coverage require separate checks'}


def _integer(value, maximum, label):
    if isinstance(value, bool) or not isinstance(value, Integral) or not 0 <= int(value) <= maximum:
        raise ValueError(label + ' is outside the supported unsigned domain')
    return int(value)


def _name(value):
    if not isinstance(value, str) or not value or any(ord(char) < 32 for char in value):
        raise ValueError('HPL mesh name is empty or contains control characters')
    try:
        encoded = value.encode('latin1')
    except UnicodeEncodeError as error:
        raise ValueError('HPL mesh name is outside the original writer encoding') from error
    if len(encoded) > 256:
        raise ValueError('HPL mesh name exceeds the bounded format')
    return value


def _decode_hpl(data):
    """Walk known records by their extents, never search for magic byte strings."""
    data = _bytes(data, _MAX_MASK_BYTES, 'HPL')
    if data[:4] != b'HPL!':
        raise ValueError('HPL signature is missing')
    cursor = 4; levels = []; seen_lods = set(); level = None; block = None; groups_count = 0
    while cursor < len(data):
        start = cursor
        if cursor + 8 > len(data):
            raise ValueError('HPL record header is truncated')
        tag, value = struct.unpack_from('<4sI', data, cursor); cursor += 8
        if tag == b'END!':
            if value or cursor != len(data):
                raise ValueError('HPL terminal or trailing bytes are unsupported')
            return levels
        if tag == b'LOD!':
            if value > 4 or value in seen_lods:
                raise ValueError('HPL LOD index is unsupported or duplicated')
            seen_lods.add(value)
            level = {'lod': value, 'blocks': []}; levels.append(level); block = None
            continue
        if level is None:
            raise ValueError('HPL record precedes its LOD')
        if tag == b'DATA':
            if value > _MAX_FLAG or any(item['flag'] == value for item in level['blocks']):
                raise ValueError('HPL scene flag is unsupported or duplicated')
            block = {'flag': value, 'groups': []}; level['blocks'].append(block)
            continue
        if tag != b'MESH' or block is None:
            raise ValueError('HPL block tag or record ordering is unsupported')
        if not 1 <= value <= 256 or cursor + value > len(data):
            raise ValueError('HPL mesh-name extent is unsupported or truncated')
        name = _name(data[cursor:cursor + value].decode('latin1')); cursor += value
        aligned = (cursor + 3) & ~3
        if aligned + 4 > len(data) or data[cursor:aligned] != bytes(aligned - cursor):
            raise ValueError('HPL mesh alignment is invalid')
        count = struct.unpack_from('<I', data, aligned)[0]; cursor = aligned + 4
        if count > _MAX_GROUP_IDS or cursor + count * 4 > len(data):
            raise ValueError('HPL vertex-vector extent is unsupported or truncated')
        end = cursor + count * 4
        ids = [row[0] for row in struct.iter_unpack('<I', data[cursor:end])]; cursor = end
        block['groups'].append({'name': name, 'ids': ids, 'raw': data[start:end]})
        groups_count += 1
        if groups_count > 5120:
            raise ValueError('HPL has too many mesh groups')
    raise ValueError('HPL terminal is missing')


def _parsed(levels):
    return {level['lod']: {block['flag']: [(group['name'], list(group['ids'])) for group in block['groups']]
                          for block in level['blocks']} for level in levels}


def _checked(data, mcd):
    levels = _decode_hpl(data)
    try:
        whole = mcd.hpl_is_whole(data)
        parsed = mcd.parse_hpl(data)
    except Exception as error:
        raise ValueError('original HPL reader refused the bounded record walk') from error
    if not whole or parsed != _parsed(levels):
        raise ValueError('original HPL reader disagrees with the bounded record walk')
    return levels


def _domains(domains):
    if not isinstance(domains, dict) or not domains:
        raise ValueError('actual paired-base mask domains are missing')
    result = {}
    for name, values in domains.items():
        _name(name)
        try:
            ids = {_integer(value, 0xffffffff, 'paired-base remap ID') for value in values}
        except TypeError as error:
            raise ValueError('paired-base remap domain is not an iterable') from error
        if not ids or len(ids) > _MAX_GROUP_IDS:
            raise ValueError('paired-base remap domain is empty or exceeds the bounded format')
        result[name] = ids
    return result


def merge_mask(current, mcd, domains, additions_by_flag):
    """Add Body IDs while preserving each of five authored LODs independently.

    Existing flags, group order, custom groups and authored index order are
    retained, including zero-length groups. Only flags 0/1 may gain new Body
    IDs. Unsupported author LOD sets or unreadable data are refused. A caller
    deliberately replacing unknown/absent coverage must pass None and report
    that loss separately; this function never silently treats corruption as
    empty. Both paired geometry clone proofs remain the caller's obligation.
    """
    domains = _domains(domains)
    if not isinstance(additions_by_flag, dict) or any(type(flag) is not int or flag not in (0, 1) for flag in additions_by_flag):
        raise ValueError('generated mask additions require explicit scene flags 0 and/or 1')
    additions = {}
    for flag, values in additions_by_flag.items():
        try:
            ids = sorted({_integer(value, 0xffffffff, 'generated Body ID') for value in values})
        except TypeError as error:
            raise ValueError('generated Body IDs are not an iterable') from error
        if len(ids) > _MAX_GROUP_IDS or any(value not in domains.get('M_Body', set()) for value in ids):
            raise ValueError('generated Body IDs leave the actual paired-base domain')
        additions[flag] = ids
    source = EMPTY_HPL if current is None else _bytes(current, _MAX_MASK_BYTES, 'source HPL')
    levels = _checked(source, mcd)
    if levels and [level['lod'] for level in levels] != list(range(5)):
        raise ValueError('authored HPL requires ordered complete slots 0..4; other LOD maps are preserved by refusal')
    for level in levels:
        for block in level['blocks']:
            for group in block['groups']:
                if group['name'] not in domains or any(value not in domains[group['name']] for value in group['ids']):
                    raise ValueError('authored HPL IDs leave an actual paired-base mesh domain')
    had_authored = any(group['ids'] for level in levels for block in level['blocks'] for group in block['groups'])
    output_levels = []; counts = {}; original = _parsed(levels)
    for lod in range(5):
        blocks = [] if not levels else levels[lod]['blocks']
        desired = {block['flag']: [(group['name'], list(group['ids'])) for group in block['groups']] for block in blocks}
        counts[str(lod)] = {}
        for flag in sorted(additions):
            groups = desired.setdefault(flag, [])
            bodies = [index for index, (name, ids) in enumerate(groups) if name == 'M_Body']
            if len(bodies) > 1 and additions[flag]:
                raise ValueError('authored HPL has ambiguous Body groups for generated additions')
            existing = [] if not bodies else groups[bodies[0]][1]
            existing_ids = set(existing)
            added = [value for value in additions[flag] if value not in existing_ids]
            counts[str(lod)][str(flag)] = len(added)
            if added:
                if bodies:
                    groups[bodies[0]] = ('M_Body', existing + added)
                else:
                    groups.append(('M_Body', added))
        # Use the reviewed original serializer for changed Body records. Its
        # normal five copies are walked and checked before taking one segment.
        built = bytes(mcd.build_hpl(desired)); built_levels = _checked(built, mcd)
        nonempty = {flag: [(name, ids) for name, ids in groups if ids]
                    for flag, groups in desired.items() if any(ids for name, ids in groups)}
        canonical = {flag: nonempty.get(flag, []) for flag in range(max(max(nonempty), 1) + 1)} if nonempty else {}
        expected_built = {index: canonical for index in range(5)} if nonempty else {}
        if ([level['lod'] for level in built_levels] != (list(range(5)) if nonempty else [])
                or _parsed(built_levels) != expected_built):
            raise ValueError('original HPL writer changed the requested groups, authored prefixes or generated Body IDs')
        generated = {} if not built_levels else {block['flag']: block for block in built_levels[0]['blocks']}
        written_blocks = []
        flag_order = [block['flag'] for block in blocks]
        flag_order.extend(flag for flag in sorted(additions) if flag not in flag_order and additions[flag])
        if not levels and generated:
            flag_order = list(generated)
        for flag in flag_order:
            previous = next((block for block in blocks if block['flag'] == flag), None)
            old_groups = [] if previous is None else previous['groups']
            result_groups = []
            for group in old_groups:
                if group['name'] == 'M_Body' and counts[str(lod)].get(str(flag), 0):
                    replacement = [item for item in generated.get(flag, {}).get('groups', []) if item['name'] == 'M_Body']
                    if len(replacement) != 1 or replacement[0]['ids'][:len(group['ids'])] != group['ids']:
                        raise ValueError('original HPL writer changed an authored Body ID prefix')
                    result_groups.append(replacement[0])
                else:
                    result_groups.append(group)
            if not any(group['name'] == 'M_Body' for group in old_groups) and counts[str(lod)].get(str(flag), 0):
                replacement = [item for item in generated.get(flag, {}).get('groups', []) if item['name'] == 'M_Body']
                if len(replacement) != 1:
                    raise ValueError('original HPL writer omitted generated Body IDs')
                result_groups.append(replacement[0])
            written_blocks.append({'flag': flag, 'groups': result_groups})
        output_levels.append({'lod': lod, 'blocks': written_blocks})
    if not any(group['ids'] for level in output_levels for block in level['blocks'] for group in block['groups']) and not levels:
        changed = EMPTY_HPL
    else:
        changed = bytearray(b'HPL!')
        for level in output_levels:
            changed += b'LOD!' + struct.pack('<I', level['lod'])
            for block in level['blocks']:
                changed += b'DATA' + struct.pack('<I', block['flag'])
                for group in block['groups']:
                    changed += group['raw']
        changed += b'END!' + bytes(4); changed = bytes(changed)
    written = _checked(changed, mcd)
    if _parsed(written) != _parsed(output_levels if changed != EMPTY_HPL else []):
        raise ValueError('assembled per-LOD HPL did not preserve its intended groups and IDs')
    final = _parsed(written)
    if any(name not in domains or any(value not in domains[name] for value in ids)
           for flags in final.values() for groups in flags.values() for name, ids in groups):
        raise ValueError('assembled HPL IDs leave the actual paired-base domains')
    for lod, flags in original.items():
        for flag, groups in flags.items():
            after = final[lod][flag]
            if len(after) < len(groups) or any(name != after[index][0] or list(ids) != after[index][1][:len(ids)]
                                             for index, (name, ids) in enumerate(groups)):
                raise ValueError('assembled HPL lost authored flags, group order or ID prefixes')
    proof = {'version': PATCH_VERSION, 'state': 'changed' if changed != source else 'already_covered',
             'had_authored_mask': had_authored, 'source_mask_state': 'not_supplied' if current is None else 'empty' if source == EMPTY_HPL else 'readable_five_lods',
             'input_mask_sha256': None if current is None else _digest(source), 'input_mask_bytes': None if current is None else len(source),
             'output_mask_sha256': _digest(changed), 'output_mask_bytes': len(changed), 'changed': changed != source,
             'original_flags_groups_and_id_prefixes_preserved': True,
             'nonuniform_authored_lods_preserved': len(set(repr(flags) for flags in original.values())) > 1,
             'per_lod_added_counts': counts,
             'additions_counts_by_flag': {str(flag): {'min': min(counts[str(lod)][str(flag)] for lod in range(5)),
                                                    'max': max(counts[str(lod)][str(flag)] for lod in range(5))} for flag in additions},
             'all_five_hpl_slots': [level['lod'] for level in written] == list(range(5)),
             'paired_base_and_attire_clone_proofs_required_from_caller': True,
             'native_reader_and_in_game_coverage_validation': 'required; not performed by these pure utilities'}
    return changed, proof
