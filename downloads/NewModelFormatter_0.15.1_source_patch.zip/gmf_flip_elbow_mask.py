"""One exact Flip pair's conservative, static elbow mask extension.

This is a frozen-data profile, never a general mask generator. Only vertices
whose complete incident triangle rings were geometrically covered by the actual
opaque pad footprints at rest may be added. Animated appearance is unverified.
No mask is emitted until the independently reviewed profile is frozen below.
"""
import copy
import functools
import hashlib
import inspect
import json
import os
from pathlib import Path
import struct
from types import SimpleNamespace

import numpy as np
from gmf_2k26_repair import game_folder, path_hash, read_native_library
from gmf_jmtl_audit import Table, inspect_material
from gmf_native_masks import envelopes, splice_mask, staged_mask


PATCH_VERSION = 'exact-flip-conservative-static-elbow-mask-extension-1'
# Frozen after independent all-triangle/front-face geometry and original
# HPL-serializer proofs. These are actual remap IDs, never bone/bbox guesses.
_PROFILE = {'attire_prefix': ('33482e11266896c19ff6e199ce2637bf80f23dadd4b01a660868f475cd4cbdbf', 1521376),
 'source_attire_allowed': [('017a44865267d32d99b639d5b245d5ea3afde60f3c46852721420e18c3e1b2ec', 1204548),
                           ('c27a87f9fab7b5604dd2f308bcda69a4467c76f89cb8a3a8fdfb6075cfb211fd', 1696852),
                           ('1158ed1a36e1b60f511f9ff11f49d06a2f86b536d8961f35aeb89866c3f56b75', 1716212)],
 'source_base_allowed': [('6670af89dc43b0d95e44d70f715bb9033cf449010f3430de2978fd63884b495c', 6043100),
                         ('1ec8da39b5d85554b6fbcb3aa71782ebbaf665868f35e30734aa6a30c8a128dc', 6800912),
                         ('8ef00213999d1921c7b0adea4dc4afa9389ea71579b43556a9ce9f84e2e0ae0b', 6800912),
                         ('32fe8b4697cf01fd1068191fde7f9b9be6cc979ccd7a5fffc2896e6345c31302', 6800912)],
 'output_base_allowed': [('1ec8da39b5d85554b6fbcb3aa71782ebbaf665868f35e30734aa6a30c8a128dc', 6800912),
                         ('8ef00213999d1921c7b0adea4dc4afa9389ea71579b43556a9ce9f84e2e0ae0b', 6800912),
                         ('32fe8b4697cf01fd1068191fde7f9b9be6cc979ccd7a5fffc2896e6345c31302', 6800912)],
 'authored_hpl': ('9dcde5d700159ca5b50cceefef6d77e3550d2a90bb55e4e41fb8831b19f5ccd8', 175452),
 'extended_hpl': ('2eb48567b01e4e59e66aa3e200599d548f0fc57e8293fbb186a05d4ed0af4b6b', 194812),
 'extended_attire': ('1158ed1a36e1b60f511f9ff11f49d06a2f86b536d8961f35aeb89866c3f56b75', 1716212),
 'body_mesh_sha256': 'e4ee805906d149483ab992c0c9c1b6ccd0862bd37bc0077077971b113b069db6',
 'pad_mesh_sha256': {'l_elbowpad': 'ce6a7ed04561ef2294c4adb83becadb5603174c027f85e0459d068aec2da0947',
                     'r_elbowpad': '272ba9f1f678f15befcd6a00b52d5c75ffd042f16d8c1cfb499408b477a65bfc'},
 'source_hpl_allowed': [('57abd17dd82782bcd4c1509c311d3f70227af707e7975a2e1b3fcbf1eae2c3dd', 81408),
                        ('8a280ab3add1727a763796e9556d7a99b55cfae8ead98448fc82fd2183b927fc', 70188),
                        ('9dcde5d700159ca5b50cceefef6d77e3550d2a90bb55e4e41fb8831b19f5ccd8', 175452),
                        ('2eb48567b01e4e59e66aa3e200599d548f0fc57e8293fbb186a05d4ed0af4b6b', 194812)],
 'selected_ids': [111,
                  113,
                  114,
                  179,
                  180,
                  181,
                  182,
                  183,
                  184,
                  185,
                  186,
                  187,
                  188,
                  189,
                  190,
                  191,
                  192,
                  193,
                  197,
                  198,
                  199,
                  200,
                  201,
                  202,
                  203,
                  204,
                  205,
                  206,
                  207,
                  208,
                  209,
                  213,
                  235,
                  237,
                  238,
                  303,
                  304,
                  305,
                  306,
                  307,
                  308,
                  309,
                  310,
                  311,
                  312,
                  313,
                  314,
                  315,
                  316,
                  317,
                  321,
                  322,
                  323,
                  324,
                  325,
                  326,
                  327,
                  328,
                  329,
                  330,
                  331,
                  332,
                  333,
                  337,
                  1958,
                  1959,
                  1960,
                  1993,
                  1994,
                  1995,
                  1996,
                  1997,
                  1998,
                  2005,
                  2006,
                  2038,
                  2039,
                  2040,
                  2073,
                  2074,
                  2075,
                  2076,
                  2077,
                  2078,
                  2085,
                  2086,
                  3712,
                  3713,
                  3714,
                  3750,
                  3751,
                  3752,
                  3753,
                  3754,
                  3755,
                  3756,
                  3757,
                  3758,
                  3759,
                  3760,
                  3761,
                  3762,
                  3763,
                  3764,
                  3765,
                  3766,
                  3767,
                  3768,
                  3769,
                  3770,
                  3771,
                  3772,
                  3773,
                  3774,
                  3775,
                  3776,
                  3777,
                  3779,
                  3780,
                  3781,
                  3782,
                  3783,
                  3784,
                  3785,
                  3786,
                  3821,
                  3822,
                  3823,
                  3824,
                  3828,
                  3829,
                  3830,
                  3844,
                  3845,
                  3846,
                  3882,
                  3883,
                  3884,
                  3885,
                  3886,
                  3887,
                  3888,
                  3889,
                  3890,
                  3891,
                  3892,
                  3893,
                  3894,
                  3895,
                  3896,
                  3897,
                  3898,
                  3899,
                  3900,
                  3901,
                  3902,
                  3903,
                  3904,
                  3905,
                  3906,
                  3907,
                  3908,
                  3909,
                  3911,
                  3912,
                  3913,
                  3914,
                  3915,
                  3916,
                  3917,
                  3918,
                  3953,
                  3954,
                  3955,
                  3956,
                  3960,
                  3961,
                  3962,
                  6939,
                  6940,
                  6941,
                  6942,
                  6952,
                  6953,
                  6954,
                  6962,
                  7151,
                  7152,
                  7153,
                  7154,
                  7156,
                  7157,
                  7159,
                  7160,
                  7161,
                  7162,
                  7163,
                  7164,
                  7165,
                  7166,
                  7167,
                  7168,
                  7169,
                  7170,
                  7171,
                  7172,
                  7173,
                  7174,
                  7175,
                  7176,
                  7177,
                  7178,
                  7179,
                  7180,
                  7181,
                  7183,
                  7184,
                  7185,
                  7187,
                  7188,
                  7189,
                  7190,
                  7192,
                  7193,
                  7195,
                  7196,
                  7197,
                  7198,
                  7199,
                  7200,
                  7201,
                  7202,
                  7203,
                  7204,
                  7205,
                  7206,
                  7207,
                  7208,
                  7209,
                  7210,
                  7211,
                  7212,
                  7213,
                  7214,
                  7215,
                  7216,
                  7217,
                  7219,
                  7220,
                  7221,
                  7222,
                  7223,
                  7225,
                  7226,
                  7228,
                  7229,
                  7230,
                  7231,
                  7232,
                  7233,
                  7234,
                  7235,
                  7236,
                  7237,
                  7238,
                  7239,
                  7240,
                  7241,
                  7242,
                  7243,
                  7244,
                  7245,
                  7246,
                  7247,
                  7248,
                  7249,
                  7250,
                  7251,
                  7252,
                  7253,
                  7254,
                  7255,
                  7256,
                  7257,
                  7258,
                  7384,
                  7385,
                  7386,
                  7387,
                  7388,
                  7389,
                  7390,
                  7391,
                  7392,
                  7410,
                  7411,
                  7412,
                  7413,
                  7417,
                  7418,
                  7419,
                  7420,
                  7421,
                  7422,
                  7423,
                  7424,
                  7425,
                  7426,
                  7427,
                  7428,
                  7429,
                  7430,
                  7431,
                  7432,
                  7433,
                  7434,
                  7435,
                  7436,
                  7437,
                  7438,
                  7439,
                  7440,
                  7441,
                  7442,
                  7443,
                  7444,
                  7458,
                  7459,
                  7460,
                  7461,
                  7462,
                  7463,
                  7464,
                  7465,
                  7466,
                  7476,
                  7477,
                  7478,
                  7486,
                  7675,
                  7676,
                  7677,
                  7678,
                  7680,
                  7681,
                  7683,
                  7684,
                  7685,
                  7686,
                  7687,
                  7688,
                  7689,
                  7690,
                  7691,
                  7692,
                  7693,
                  7694,
                  7695,
                  7696,
                  7697,
                  7698,
                  7699,
                  7700,
                  7701,
                  7702,
                  7703,
                  7704,
                  7706,
                  7707,
                  7708,
                  7709,
                  7711,
                  7712,
                  7713,
                  7714,
                  7716,
                  7717,
                  7718,
                  7720,
                  7721,
                  7722,
                  7723,
                  7724,
                  7725,
                  7726,
                  7727,
                  7728,
                  7729,
                  7730,
                  7731,
                  7732,
                  7733,
                  7734,
                  7735,
                  7736,
                  7737,
                  7738,
                  7739,
                  7740,
                  7741,
                  7743,
                  7744,
                  7745,
                  7746,
                  7747,
                  7749,
                  7750,
                  7752,
                  7753,
                  7754,
                  7755,
                  7756,
                  7757,
                  7758,
                  7759,
                  7760,
                  7761,
                  7762,
                  7763,
                  7764,
                  7765,
                  7766,
                  7767,
                  7768,
                  7769,
                  7770,
                  7771,
                  7772,
                  7773,
                  7774,
                  7775,
                  7776,
                  7777,
                  7778,
                  7779,
                  7780,
                  7781,
                  7782,
                  7908,
                  7909,
                  7910,
                  7911,
                  7912,
                  7913,
                  7914,
                  7915,
                  7916,
                  7934,
                  7935,
                  7936,
                  7937,
                  7941,
                  7942,
                  7943,
                  7944,
                  7945,
                  7946,
                  7947,
                  7948,
                  7949,
                  7950,
                  7951,
                  7952,
                  7953,
                  7954,
                  7955,
                  7956,
                  7957,
                  7958,
                  7959,
                  7960,
                  7961,
                  7962,
                  7963,
                  7964,
                  7965,
                  7966,
                  7967,
                  7968,
                  7982,
                  7983,
                  7984,
                  7985,
                  7986],
 'selected_ids_fingerprint': ('7a1934378d686b02ce6a75340c98dab81e9c49ccf4e939a1e323ef92fce19d6c', 1936),
 'authored_id_count': 4378,
 'selection_proof_sha256': '580a8f104e799ef98c03bb759b61315158718359b51108cc12add6b034ca0f9c',
 'independent_selection_proof_sha256': '5d219615b297aa011d9c9740cdadd45760842ab3f334c4ea45535a24c02a34d8',
 'independent_front_face_proof_sha256': '059c9fd015e334944a59a43dcb02ace5a746abbf0f2581a92b162d9e62de928c',
 'selection_scope': 'exact source/restored geometry; full positive-depth front-face pad footprint coverage '
                    'and all-incident-triangle one-ring erosion; animation unverified'}
_GAME_CHECK = 'Exact Flip elbow mask extension is experimental; entrance and gameplay checks are required for pad edges and arm motion.'


def fingerprint(data):
    return hashlib.sha256(data).hexdigest(), len(data)


def profile():
    return copy.deepcopy(_PROFILE)


def _array(value):
    array = np.asarray(value)
    return {'shape': list(array.shape), 'dtype': array.dtype.str,
            'sha256': fingerprint(array.tobytes(order='C'))[0]}


def mesh_fingerprint(mesh):
    """Exact actual native geometry/remap/UV/color/normal/weight identity."""
    count = int(mesh.num_verts)
    positions = np.asarray(mesh.positions); triangles = np.asarray(mesh.triangles)
    remap = (np.arange(count, dtype=np.uint32) if mesh.vertex_remap is None
             else np.asarray(mesh.vertex_remap))
    if (count <= 0 or positions.shape != (count, 3) or not np.isfinite(positions).all()
            or triangles.ndim != 2 or triangles.shape[1:] != (3,) or triangles.dtype.kind not in 'iu'
            or (triangles < 0).any() or (triangles >= count).any()
            or remap.shape != (count,) or remap.dtype.kind not in 'iu'
            or (remap < 0).any() or len(set(map(int, remap))) != count):
        raise ValueError('Flip elbow body/pad geometry or remap domain is invalid')
    facts = {'vertices': count, 'scene_flag': int(mesh.scene_flag), 'motion_flag': int(mesh.motion_flag),
             'positions': _array(positions), 'triangles': _array(triangles), 'vertex_remap': _array(remap),
             'uvs': [], 'colors': [], 'weights': {}}
    for name in ('normals', 'tangents'):
        value = getattr(mesh, name, None)
        facts[name] = None if value is None else _array(value)
    for name in ('uvs', 'colors'):
        for value in getattr(mesh, name, []):
            array = np.asarray(value)
            if len(array) != count or not np.isfinite(array).all():
                raise ValueError('Flip elbow ' + name + ' domain is invalid')
            facts[name].append(_array(array))
    for name, value in sorted(mesh.weights.items()):
        array = np.asarray(value)
        if array.shape != (count,) or not np.isfinite(array).all() or (array < 0).any():
            raise ValueError('Flip elbow native weight domain is invalid')
        facts['weights'][name] = _array(array)
    return hashlib.sha256(json.dumps(facts, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def _safe_file(path, root):
    path, root = Path(path), Path(root)
    current = path
    while True:
        if current.is_symlink():
            raise ValueError('Flip elbow repair refuses file or directory symlinks')
        if current == current.parent:
            break
        current = current.parent
    if not path.resolve().is_relative_to(root.resolve()) or not path.is_file():
        raise ValueError('Flip elbow paired file is missing or outside its selected folder: ' + path.name)
    return path.read_bytes()


def _roots(report, chosen_source, chosen_output):
    source = Path(report.get('source') or chosen_source)
    output = Path(report.get('output') or chosen_output)
    paths = [source, output, Path(chosen_source), Path(chosen_output)]
    for path in paths:
        current = path
        while True:
            if current.is_symlink():
                raise ValueError('Flip elbow repair refuses source/output root symlinks')
            if current == current.parent:
                break
            current = current.parent
    src, dst, selected_src, selected_dst = [path.resolve() for path in paths]
    if (not src.is_relative_to(selected_src) or not dst.is_relative_to(selected_dst)
            or selected_src.is_relative_to(selected_dst) or selected_dst.is_relative_to(selected_src)):
        raise ValueError('Flip elbow repair requires separate contained source/output folders')
    return source, output


def _mask_frame(data):
    frames = envelopes(data)
    masks = [frame for frame in frames if frame['tag'] == b'HPL!']
    if len(masks) != 1 or masks[0] is not frames[-2]:
        raise ValueError('Flip elbow requires exactly one existing HPL tail immediately before END')
    frame = masks[0]
    return frame['payload'], data[:frame['start']], frames


def extend_mask(current, mcd, domain, selected):
    """Append only frozen IDs, retaining every authored sequence at five LODs."""
    if not mcd.hpl_is_whole(current):
        raise ValueError('Flip elbow source mask is unreadable')
    parsed = mcd.parse_hpl(current)
    if set(parsed) != set(range(5)) or any(flags != parsed[0] for flags in parsed.values()):
        raise ValueError('Flip elbow requires the same authored records at all five LODs')
    flags = parsed[0]
    if set(flags) != {0, 1} or any(len(groups) != 1 or groups[0][0] != 'M_Body' for groups in flags.values()):
        raise ValueError('Flip elbow requires both authored scene flags and only M_Body groups')
    original = list(flags[0][0][1])
    if list(flags[1][0][1]) != original or len(set(original)) != len(original):
        raise ValueError('Flip elbow authored scene masks disagree or contain duplicate IDs')
    selected = list(selected)
    if selected != sorted(set(selected)) or not selected or any(type(value) is not int for value in selected):
        raise ValueError('Flip elbow frozen IDs are missing, ambiguous or unsorted')
    if not set(original).issubset(domain) or not set(selected).issubset(domain):
        raise ValueError('Flip elbow mask IDs leave the actual paired Body remap domain')
    if set(original).intersection(selected):
        raise ValueError('Flip elbow selected additions already exist in the authored mask')
    combined = original + selected
    expected = {flag: [('M_Body', combined)] for flag in (0, 1)}
    result = mcd.build_hpl(expected)
    written = mcd.parse_hpl(result)
    if (not mcd.hpl_is_whole(result) or set(written) != set(range(5))
            or any(flags != expected for flags in written.values())):
        raise ValueError('Flip elbow original HPL writer did not preserve all flags, LODs and ID sequences')
    return result, len(original)


def _geometry(base, attire, expected):
    if int(base.version) != 47 or int(attire.version) != 47:
        raise ValueError('Flip elbow paired outputs must read as native 2K26')
    bodies = [mesh for mesh in base.meshes if mesh.name == 'M_Body']
    if len(bodies) != 1 or mesh_fingerprint(bodies[0]) != expected['body_mesh_sha256']:
        raise ValueError('Flip elbow paired Body geometry/remap/native weights differ from the inspected profile')
    body = bodies[0]
    clean = lambda name: str(name).split(':', 1)[0]
    for role in ('l_elbowpad', 'r_elbowpad'):
        pads = [mesh for mesh in attire.meshes if any(clean(group[0]) == role for group in mesh.face_groups)]
        if (len(pads) != 1 or pads[0].name != 'M_L_Elbowpad'
                or any(clean(group[0]) != role for group in pads[0].face_groups)
                or mesh_fingerprint(pads[0]) != expected['pad_mesh_sha256'][role]):
            raise ValueError('Flip elbow ' + role + ' role or geometry/remap/native weights differ from the inspected profile')
    remap = (np.arange(body.num_verts, dtype=np.uint32) if body.vertex_remap is None
             else np.asarray(body.vertex_remap))
    return set(map(int, remap))


def _materials(target, report, output_root, writer):
    table = target.with_suffix('.mtls'); raw = _safe_file(table, output_root)
    entries = read_native_library(raw); virtual = game_folder(table)
    rows = [row for row in report.get('materials', []) if row.get('output')
            and Path(row['output']).resolve() == table.resolve()]
    if len(rows) != 1 or str(rows[0].get('status', '')).startswith(('failed', 'unsupported')):
        raise ValueError('Flip elbow paired native material table lacks one successful recorded conversion')
    snapshots = [(table, raw, output_root)]; facts = []
    for role in ('l_elbowpad', 'r_elbowpad'):
        matching = [entry for entry in entries if entry['name'].casefold() == role]
        if len(matching) != 1 or matching[0]['name'] != role or virtual is None:
            raise ValueError('Flip elbow pad material binding is missing or ambiguous: ' + role)
        directory = target.parent / 'Materials'
        paths = [path for path in directory.iterdir() if path.name.casefold() == role + '.jmtl']
        if len(paths) != 1:
            raise ValueError('Flip elbow local pad JMTL is missing or ambiguous: ' + role)
        path = paths[0]; data = _safe_file(path, output_root)
        if matching[0]['path_hash'] != path_hash(virtual + '/Materials/' + path.name):
            raise ValueError('Flip elbow MTLS does not bind the actual local pad material: ' + role)
        inspected = inspect_material(data)
        refs = {row['field']: row['hash'] for row in inspected['texture_references']}
        if inspected['shader_byte'] != 0x15 or set(refs) != {'colorMap@ref', 'nrMap@ref'}:
            raise ValueError('Flip elbow pad is not the inspected ordinary gear schema: ' + role)
        params = {**refs, 'g_specIntensity': 1.0, 'irradianceR': 0.0,
                  'irradianceG': 192.0 / 255.0, 'irradianceB': 192.0 / 255.0}
        if writer is None:
            from thirdparty.wwe2k_mdl.jmtl_writer import write_jmtl
            writer = write_jmtl
        reconstructed = bytes(writer(0x15, params))
        root = Table(data, struct.unpack_from('<I', data)[0]); payload = root.child(2)
        if data != reconstructed or len(data) != 184 or payload.number(0, '<B', 0) != 0:
            raise ValueError('Flip elbow pad differs from the exact opaque gear declaration: ' + role)
        snapshots.append((path, data, output_root))
        facts.append({'role': role, 'file': str(path), 'sha256': fingerprint(data)[0],
                      'bytes': len(data), 'shader': 0x15, 'variant': 0, 'whole_payload_reconstruction_match': True,
                      'texture_references': refs, 'texture_pixels_and_game_alpha': 'not established'})
    return snapshots, facts


def _preflight(report, record):
    for key in ('models', 'materials', 'problems', 'warnings'):
        if key in report and type(report[key]) is not list:
            raise ValueError('Flip elbow report ' + key + ' metadata is malformed')
    for key in ('models', 'materials'):
        if any(type(row) is not dict for row in report.get(key, [])):
            raise ValueError('Flip elbow report ' + key + ' rows are malformed')
    for key in ('facts', 'supplied_hide_mask_recovery', 'face_output_audit'):
        if key in record and type(record[key]) is not dict:
            raise ValueError('Flip elbow model ' + key + ' metadata is malformed')
    for key in ('repairs', 'notes', 'problems'):
        if key in record and type(record[key]) is not list:
            raise ValueError('Flip elbow model ' + key + ' metadata is malformed')
    for key in ('native_2k26_models_preserved', 'native_2k26_masks_repaired'):
        if key in report and type(report[key]) is not int:
            raise ValueError('Flip elbow report ' + key + ' counter is malformed')
    native = record.get('native_missing_data_audit')
    if native is not None and (type(native) is not dict or
                               ('masks' in native and type(native['masks']) is not dict)):
        raise ValueError('Flip elbow preceding native mask audit is malformed')
    physics = report.get('physics_binding_audit')
    if physics is not None:
        if (type(physics) is not dict or type(physics.get('rows', [])) is not list
                or any(type(row) is not dict or type(row.get('paired_models', [])) is not list
                       or any(type(paired) is not dict for paired in row.get('paired_models', []))
                       for row in physics.get('rows', []))):
            raise ValueError('Flip elbow preceding physics audit is malformed')
    top = record.get('supplied_hide_mask_recovery')
    nested = record.get('facts', {}).get('supplied_hide_mask_recovery')
    if (top is None) != (nested is None) or (top is not None and (type(nested) is not dict or top != nested)):
        raise ValueError('Flip elbow supplied-mask restoration provenance is missing or inconsistent')


def _updates(report, record, target, proof, changed):
    facts = record.setdefault('facts', {})
    prior_keys = ('output_sha256', 'byte_identical', 'model_bytes_preserved',
                  'geometry_weights_bones_and_embedded_streams', 'hide_mask')
    facts.setdefault('before_exact_flip_elbow_extension', {key: copy.deepcopy(facts[key]) for key in prior_keys if key in facts})
    facts.update(output_sha256=proof['after_mcd_sha256'], written_hpl_sha256=proof['after_hpl_sha256'])
    if changed:
        facts.update(byte_identical=False, model_bytes_preserved=False,
                     geometry_weights_bones_and_embedded_streams='every non-HPL byte preserved; existing authored HPL extended only with frozen covered elbow Body IDs')
    facts['flip_elbow_mask_extension'] = copy.deepcopy(proof)
    record['flip_elbow_mask_extension'] = copy.deepcopy(proof)
    for recovery in (record.get('supplied_hide_mask_recovery'), facts.get('supplied_hide_mask_recovery')):
        if recovery is not None:
            recovery['output_byte_proof_stage'] = 'historical authored restoration before exact elbow extension'
            recovery['following_exact_elbow_mask_extension'] = copy.deepcopy(proof)
    record.setdefault('verification_scope_before_exact_flip_elbow_extension', record.get('verification_scope', 'original model conversion checks'))
    record['verification_scope'] = 'original model verification plus unchanged non-HPL bytes and exact native HPL structure/domains; animated pad coverage requires game validation'
    native = record.get('native_missing_data_audit', {})
    if isinstance(native.get('masks'), dict):
        mask_audit = native['masks']
        mask_audit.setdefault('before_exact_flip_elbow_extension', copy.deepcopy(mask_audit))
        count = proof['authored_ids_preserved'] + proof['generated_added_ids']
        mask_audit.update(state='readable_indices_valid_after_exact_flip_elbow_extension',
                          mask_sha256=proof['after_hpl_sha256'],
                          counts={str(lod): {str(flag): {'M_Body': count} for flag in (0, 1)} for lod in range(5)},
                          following_exact_elbow_mask_extension=copy.deepcopy(proof),
                          coverage_validation='paired index domains and frozen conservative static coverage only; animation and game visibility unverified')
    if changed:
        record['status'] = 'repaired_exact_flip_elbow_mask'
        if 'exact_flip_elbow_mask_extension' not in record.setdefault('repairs', []):
            record['repairs'].append('exact_flip_elbow_mask_extension')
        if proof['prior_status'] == 'preserved_2k26':
            report['native_2k26_models_preserved'] = max(0, report.get('native_2k26_models_preserved', 0) - 1)
            report['native_2k26_masks_repaired'] = report.get('native_2k26_masks_repaired', 0) + 1
    # The wrapper is installed before final audits. Preexisting audit rows are
    # annotated as historical until their normal audit regenerates final data.
    audit = record.get('face_output_audit')
    if audit is not None and audit.get('output_sha256') == proof['before_mcd_sha256']:
        audit['before_exact_flip_elbow_extension'] = {'output_sha256': audit['output_sha256']}
        audit['output_sha256'] = proof['after_mcd_sha256']
        audit['output_byte_proof_stage'] = 'geometry/material observations preserved; exact HPL-only extension follows this audit'
    for row in report.get('physics_binding_audit', {}).get('rows', []):
        for paired in row.get('paired_models', []):
            if (paired.get('file') or paired.get('path')) == str(target) and paired.get('sha256') == proof['before_mcd_sha256']:
                paired['before_exact_flip_elbow_extension_sha256'] = paired['sha256']
                paired['sha256'] = proof['after_mcd_sha256']
                if 'bytes' in paired:
                    paired['before_exact_flip_elbow_extension_bytes'] = paired['bytes']
                    paired['bytes'] = proof['after_mcd_bytes']
                paired['following_hpl_only_extension'] = True
    if _GAME_CHECK not in report.setdefault('problems', []):
        report['problems'].append(_GAME_CHECK)
    if _GAME_CHECK not in report.setdefault('warnings', []):
        report['warnings'].append(_GAME_CHECK)
    report['experimental_flip_elbow_mask_game_check'] = True
    report['conversion_completeness'] = 'incomplete'


def process(report, selected_source, selected_output, vcmodel, mcd, log=lambda text: None, *, writer=None):
    expected = profile()
    summary = {'version': PATCH_VERSION, 'applied': 0, 'already_applied': 0, 'refused': 0,
               'failed_after_write': 0, 'not_applicable': 0, 'rows': [], 'source_files_changed': False,
               'in_game_validation': 'not_performed', 'scope': 'one exact Flip pair; frozen conservative static pad coverage only'}
    report['flip_elbow_mask_extension'] = summary
    if expected is None:
        summary['state'] = 'inactive_candidate_proof_not_frozen_no_asset_reads_or_writes'
        return summary
    try:
        _preflight(report, {})
        source_root, output_root = _roots(report, selected_source, selected_output)
    except (ValueError, TypeError) as error:
        summary.update(state='requires_attention', refused=1)
        summary['rows'].append({'state': 'not_applied', 'reason': str(error), 'output_file_changes': 'none'})
        return summary
    for record in report.get('models', []):
        if not record.get('source') or not record.get('output'):
            continue
        # A known source must explicitly refuse a changed/custom output. The
        # native prefix also identifies the case when source provenance fails.
        # Unrelated models remain outside this frozen profile.
        source_known = False; prefix_known = False
        try:
            source, target = Path(record['source']), Path(record['output'])
            source_known = fingerprint(_safe_file(source, source_root)) in [
                tuple(value) for value in expected['source_attire_allowed']]
        except (OSError, ValueError, struct.error):
            pass
        try:
            output_mask, prefix, _ = _mask_frame(_safe_file(target, output_root))
            prefix_known = fingerprint(prefix) == tuple(expected['attire_prefix'])
        except (OSError, ValueError, struct.error):
            pass
        if not source_known and not prefix_known:
            summary['not_applicable'] += 1; continue
        row = {'source': str(source), 'output': str(target), 'in_game_validation': 'not_performed'}
        committed = False
        try:
            _preflight(report, record)
            if record.get('verify') != 'pass':
                raise ValueError('Flip elbow output has not passed model verification')
            source_bytes = _safe_file(source, source_root); before = _safe_file(target, output_root)
            current, prefix, frames = _mask_frame(before)
            if fingerprint(prefix) != tuple(expected['attire_prefix']):
                raise ValueError('Flip elbow complete native model/rig/weight prefix differs')
            if fingerprint(current) not in (tuple(expected['authored_hpl']), tuple(expected['extended_hpl'])):
                raise ValueError('Flip elbow preserves an unrecognized or custom existing HPL')
            if fingerprint(source_bytes) not in [tuple(value) for value in expected['source_attire_allowed']]:
                raise ValueError('Flip elbow source attire is outside the exact inspected legacy/native pair')
            if target.with_suffix('.hpl').exists() or target.with_suffix('.hpl').is_symlink():
                raise ValueError('Flip elbow refuses a conflicting separate output HPL')
            source_base = source.parent.parent / 'BaseModel' / 'baseModel.mcd'
            output_base = target.parent.parent / 'BaseModel' / 'baseModel.mcd'
            bases = [base for base in report['models'] if base.get('output')
                     and Path(base['output']).resolve() == output_base.resolve()]
            if (len(bases) != 1 or bases[0].get('verify') != 'pass' or not bases[0].get('source')
                    or Path(bases[0]['source']).resolve() != source_base.resolve()):
                raise ValueError('Flip elbow needs one verified current-job same-character paired BaseModel')
            src_base_bytes = _safe_file(source_base, source_root); base_bytes = _safe_file(output_base, output_root)
            if (fingerprint(src_base_bytes) not in [tuple(value) for value in expected['source_base_allowed']]
                    or fingerprint(base_bytes) not in [tuple(value) for value in expected['output_base_allowed']]):
                raise ValueError('Flip elbow paired source/output BaseModel fingerprints differ')
            snapshots = [(source, source_bytes, source_root), (target, before, output_root),
                         (source_base, src_base_bytes, source_root), (output_base, base_bytes, output_root)]
            sidecar = source.with_suffix('.hpl')
            if sidecar.exists() or sidecar.is_symlink():
                sidecar_bytes = _safe_file(sidecar, source_root)
                if fingerprint(sidecar_bytes) not in [tuple(value) for value in expected['source_hpl_allowed']]:
                    raise ValueError('Flip elbow preserves a custom or changed source HPL')
                snapshots.append((sidecar, sidecar_bytes, source_root))
            base_model = vcmodel.read_model(str(output_base), with_shapes=False)
            attire_model = vcmodel.read_model(str(target), with_shapes=False)
            domain = _geometry(base_model, attire_model, expected)
            streams = [data for tag, data in attire_model.substreams if tag == b'HPL!']
            if streams != [current]:
                raise ValueError('Flip elbow native reader disagrees with the current HPL tail')
            materials, material_facts = _materials(target, report, output_root, writer)
            snapshots.extend(materials)
            selected = list(expected['selected_ids'])
            if fingerprint(struct.pack('<' + 'I' * len(selected), *selected)) != tuple(expected['selected_ids_fingerprint']):
                raise ValueError('Flip elbow frozen index data failed integrity validation')
            if fingerprint(current) == tuple(expected['extended_hpl']):
                changed = before; mask = current; original_count = expected['authored_id_count']
                state = 'already_applied'
                parsed = mcd.parse_hpl(current)
                if not mcd.hpl_is_whole(current) or set(parsed) != set(range(5)) or any(flags != parsed[0] for flags in parsed.values()):
                    raise ValueError('Flip elbow existing extended mask flags or LODs differ')
                flags = parsed[0]
                if set(flags) != {0, 1} or any(len(groups) != 1 or groups[0][0] != 'M_Body' for groups in flags.values()):
                    raise ValueError('Flip elbow existing extended mask groups differ')
                full = list(flags[0][0][1]); authored_part = full[:original_count]
                if full[original_count:] != selected or flags[1] != flags[0] or not set(full).issubset(domain):
                    raise ValueError('Flip elbow existing extended IDs disagree with the frozen profile')
                restored = mcd.build_hpl({flag: [('M_Body', authored_part)] for flag in (0, 1)})
                if fingerprint(restored) != tuple(expected['authored_hpl']):
                    raise ValueError('Flip elbow existing extended mask lost original authored coverage')
            else:
                mask, original_count = extend_mask(current, mcd, domain, selected)
                if original_count != expected['authored_id_count']:
                    raise ValueError('Flip elbow authored ID count differs from the inspected mask')
                if fingerprint(mask) != tuple(expected['extended_hpl']):
                    raise ValueError('Flip elbow extended HPL differs from the reviewed serializer proof')
                changed = splice_mask(before, mask); state = 'applied_experimental_static_mask'
            if fingerprint(changed) != tuple(expected['extended_attire']):
                raise ValueError('Flip elbow candidate model differs from the exact reviewed HPL-only result')
            after_mask, after_prefix, after_frames = _mask_frame(changed)
            if after_prefix != prefix or [(f['tag'], f['payload']) for f in frames if f['tag'] != b'HPL!'] != [
                    (f['tag'], f['payload']) for f in after_frames if f['tag'] != b'HPL!']:
                raise ValueError('Flip elbow candidate changed non-HPL bytes or framed payloads')
            proof = {'version': PATCH_VERSION, 'state': state, 'prior_status': record.get('status'),
                     'original_model_verify_before_mask_extension': record['verify'],
                     'before_mcd_sha256': fingerprint(before)[0], 'after_mcd_sha256': fingerprint(changed)[0],
                     'before_mcd_bytes': len(before), 'after_mcd_bytes': len(changed),
                     'before_hpl_sha256': fingerprint(current)[0], 'after_hpl_sha256': fingerprint(mask)[0],
                     'before_hpl_bytes': len(current), 'after_hpl_bytes': len(mask),
                     'authored_ids_preserved': original_count, 'generated_added_ids': len(selected),
                     'selected_indices_sha256': expected['selected_ids_fingerprint'][0],
                     'flags': [0, 1], 'lods': list(range(5)), 'every_non_hpl_byte_preserved': True,
                     'paired_base_sha256': fingerprint(base_bytes)[0], 'body_pad_geometry_and_native_weights_verified': True,
                     'materials': material_facts, 'selection_proof_sha256': expected['selection_proof_sha256'],
                     'independent_selection_proof_sha256': expected.get('independent_selection_proof_sha256'),
                     'independent_front_face_proof_sha256': expected.get('independent_front_face_proof_sha256'),
                     'coverage_generated': True, 'coverage_scope': 'frozen actual-pad static positive-depth footprint coverage with all-incident-triangle boundary erosion; no whole-arm hiding',
                     'source_files_changed': False, 'in_game_validation': 'not_performed',
                     'animated_pad_coverage_and_appearance_proved': False}
            def recheck():
                for path, data, root in snapshots:
                    if _safe_file(path, root) != data:
                        raise ValueError('Flip elbow paired asset changed during mask staging; output preserved')
            recheck()
            if changed != before:
                def read_staged(path, **kwargs):
                    model = vcmodel.read_model(path, **kwargs)
                    recheck()
                    return model
                staged_mask(target, changed, mask, SimpleNamespace(read_model=read_staged))
                committed = True
            if _safe_file(target, output_root) != changed:
                raise ValueError('Flip elbow final output differs from its prepared candidate')
            for path, data, root in snapshots:
                if path != target and _safe_file(path, root) != data:
                    raise ValueError('Flip elbow final paired/source file preservation failed')
            proof['native_reader_passed'] = True
            _updates(report, record, target, proof, changed != before)
            row.update(proof, output_file_changes='none' if changed == before else 'only the existing HPL tail')
            summary['applied' if changed != before else 'already_applied'] += 1
            try:
                log('Flip elbow mask: ' + state + '; original coverage preserved, game checks required.')
            except Exception:
                pass
        except Exception as error:
            row.update(state='applied_with_verification_or_reporting_error' if committed else 'not_applied',
                       reason=str(error), output_file_changes='HPL write committed; final validation/reporting failed' if committed else 'none')
            summary['failed_after_write' if committed else 'refused'] += 1
            message = str(target.name) + (': Flip elbow mask write completed; final check failed: ' if committed
                                         else ': Flip elbow mask not applied: ') + str(error)
            if type(report.get('problems', [])) is list and message not in report.setdefault('problems', []):
                report['problems'].append(message)
            try:
                log(message)
            except Exception:
                pass
        summary['rows'].append(row)
    summary['state'] = 'requires_attention' if summary['refused'] or summary['failed_after_write'] else 'checked_with_in_game_validation_required'
    return summary


def install(folder):
    """Install after mask/anchor recovery, before final face and physics audits."""
    if getattr(folder, '_exact_flip_elbow_mask_patch', None) == PATCH_VERSION:
        return
    original = folder.convert_folder
    @functools.wraps(original)
    def convert_folder(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs); bound.apply_defaults()
        report = original(*args, **kwargs)
        process(report, bound.arguments['src'], bound.arguments['dst'], folder.vc, folder.mcd,
                bound.arguments.get('log', lambda text: None))
        from gmf_report import save_intermediate
        save_intermediate(report, bound.arguments['dst'])
        return report
    folder.convert_folder = convert_folder
    folder._exact_flip_elbow_mask_patch = PATCH_VERSION
