"""Conservative opaque-clothing coverage in the supplied common rest frame.

This module changes no geometry, weights, materials, or masks. Its caller must
select actually opaque clothing faces separately for each applicable scene.
Static coverage is not a proof of animated coverage or game visibility.
"""
import hashlib
import math

import numpy as np


PATCH_VERSION = 'conservative-per-model-clothing-surface-coverage-2'
WORK_LIMITS = {
    'body_vertices': 200000, 'body_triangles': 400000,
    'clothing_vertices': 500000, 'clothing_triangles': 500000,
    'clothing_meshes': 128, 'bvh_node_visits': 10000000,
    'ray_triangle_tests': 20000000, 'coverage_triangles': 100000,
    'polygon_operations': 2000000, 'convex_pieces': 512,
}


class CoverageError(ValueError):
    """Unsupported geometry or exhausted bounded work; no selection is emitted."""


class _Budget:
    def __init__(self):
        self.counts = {key: 0 for key in ('bvh_node_visits', 'ray_triangle_tests',
                                        'coverage_triangles', 'polygon_operations')}

    def add(self, key, count=1):
        self.counts[key] += int(count)
        if self.counts[key] > WORK_LIMITS[key]:
            raise CoverageError('clothing coverage work limit exceeded: ' + key)


def _digest_ids(ids):
    return hashlib.sha256(np.asarray(ids, dtype='<u4').tobytes()).hexdigest()


def _mesh(mesh, role):
    positions = np.asarray(mesh.positions)
    if (positions.ndim != 2 or positions.shape[1:] != (3,)
            or positions.dtype.kind not in 'fiu' or not np.isfinite(positions).all()):
        raise CoverageError(role + ' positions must be finite 3D coordinates')
    count = len(positions)
    if count == 0 or count > WORK_LIMITS[role + '_vertices']:
        raise CoverageError(role + ' vertex domain exceeds supported limits')
    declared = getattr(mesh, 'num_verts', count)
    if isinstance(declared, (bool, np.bool_)) or not isinstance(declared, (int, np.integer)) or int(declared) != count:
        raise CoverageError(role + ' declared vertex domain disagrees with positions')
    triangles = np.asarray(mesh.triangles)
    if (triangles.ndim != 2 or triangles.shape[1:] != (3,) or triangles.dtype.kind not in 'iu'
            or len(triangles) == 0 or len(triangles) > WORK_LIMITS[role + '_triangles']
            or triangles.min() < 0 or triangles.max() >= count):
        raise CoverageError(role + ' triangle index domain is invalid or exceeds supported limits')
    normals = np.asarray(getattr(mesh, 'normals', None))
    if (normals.shape != (count, 3) or normals.dtype.kind not in 'fiu' or not np.isfinite(normals).all()):
        raise CoverageError(role + ' stored outward normals are unavailable or invalid')
    positions = positions.astype(np.float64, copy=True)
    triangles = triangles.astype(np.int64, copy=True)
    normals = normals.astype(np.float64, copy=True)
    lengths = np.linalg.norm(normals, axis=1)
    if not np.isfinite(lengths).all() or (lengths <= 1e-12).any():
        raise CoverageError(role + ' stored normals have zero or unsupported length')
    normals /= lengths[:, None]
    faces = positions[triangles]
    cross = np.cross(faces[:, 1] - faces[:, 0], faces[:, 2] - faces[:, 0])
    sizes = np.linalg.norm(cross, axis=1)
    if not np.isfinite(sizes).all():
        raise CoverageError(role + ' coordinate scale makes triangle geometry unsupported')
    nondegenerate = sizes > 0
    face_normals = np.zeros_like(cross)
    face_normals[nondegenerate] = cross[nondegenerate] / sizes[nondegenerate, None]
    mean_normals = normals[triangles].mean(axis=1)
    mean_lengths = np.linalg.norm(mean_normals, axis=1)
    agreement = np.zeros(len(triangles))
    stable = nondegenerate & (mean_lengths > 1e-12)
    agreement[stable] = np.einsum('ij,ij->i', face_normals[stable], mean_normals[stable]) / mean_lengths[stable]
    inconsistent = stable & (agreement < -1e-8)
    ambiguous = nondegenerate & (~stable | (np.abs(agreement) <= 1e-8))
    # Preserve authored winding and normals. An unproved Body face remains
    # uncovered, withholding every incident render vertex and logical alias.
    # An unproved clothing face never enters the ray/footprint union index.
    valid = stable & (agreement > 1e-8)
    return {'name': str(getattr(mesh, 'name', role)), 'positions': positions, 'triangles': triangles,
            'normals': normals, 'face_normals': face_normals, 'faces': faces, 'valid': valid,
            'nondegenerate': nondegenerate, 'unproved_winding': inconsistent | ambiguous,
            'degenerate_triangles': int((~nondegenerate).sum()),
            'winding_inconsistent_triangles': int(inconsistent.sum()),
            'winding_ambiguous_triangles': int(ambiguous.sum()),
            'minimum_winding_normal_cosine': float(agreement[nondegenerate].min()) if nondegenerate.any() else None,
            'minimum_supported_winding_normal_cosine': float(agreement[valid].min()) if valid.any() else None}


class _Index:
    """AABB tree over actual clothing triangles; bounds are culling only."""
    def __init__(self, faces):
        self.faces = faces
        self.lower = faces.min(axis=1)
        self.upper = faces.max(axis=1)
        self.centers = (self.lower + self.upper) * .5
        self.nodes = []
        if len(faces):
            self._build(np.arange(len(faces), dtype=np.int64))

    def _build(self, ids):
        lower = self.lower[ids].min(0); upper = self.upper[ids].max(0)
        node = len(self.nodes); self.nodes.append(None)
        if len(ids) <= 16:
            self.nodes[node] = (lower, upper, np.sort(ids), None)
        else:
            axis = int(np.argmax(upper - lower))
            order = np.argsort(self.centers[ids, axis], kind='stable')
            ids = ids[order]; middle = len(ids) // 2
            children = (self._build(ids[:middle]), self._build(ids[middle:]))
            self.nodes[node] = (lower, upper, None, children)
        return node

    def box(self, lower, upper, budget):
        if not self.nodes:
            return np.empty(0, dtype=np.int64)
        found = []; stack = [0]
        while stack:
            budget.add('bvh_node_visits')
            low, high, ids, children = self.nodes[stack.pop()]
            if (high < lower).any() or (low > upper).any():
                continue
            if ids is None:
                stack.extend(children)
            else:
                keep = np.all(self.upper[ids] >= lower, axis=1) & np.all(self.lower[ids] <= upper, axis=1)
                found.extend(ids[keep])
        return np.sort(np.asarray(found, dtype=np.int64))


def _ray(points, directions, index, face_normals, depth_min, depth_max, budget):
    hits = np.zeros(len(points), dtype=bool)
    owners = np.full(len(points), -1, dtype=np.int64)
    distances = np.full(len(points), np.inf)
    for vertex, (point, direction) in enumerate(zip(points, directions)):
        end = point + direction * depth_max
        ids = index.box(np.minimum(point, end), np.maximum(point, end), budget)
        if not len(ids):
            continue
        budget.add('ray_triangle_tests', len(ids))
        front = face_normals[ids] @ direction > 1e-8
        ids = ids[front]
        if not len(ids):
            continue
        faces = index.faces[ids]
        edge1, edge2 = faces[:, 1] - faces[:, 0], faces[:, 2] - faces[:, 0]
        h = np.cross(direction, edge2)
        determinant = np.einsum('ij,ij->i', edge1, h)
        nonparallel = determinant != 0
        inverse = np.zeros_like(determinant)
        inverse[nonparallel] = 1 / determinant[nonparallel]
        delta = point - faces[:, 0]
        u = inverse * np.einsum('ij,ij->i', delta, h)
        q = np.cross(delta, edge1)
        v = inverse * (q @ direction)
        depth = inverse * np.einsum('ij,ij->i', edge2, q)
        valid = (nonparallel & np.isfinite(depth) & (u >= -1e-10) & (v >= -1e-10)
                 & (u + v <= 1 + 1e-10) & (depth > depth_min) & (depth <= depth_max))
        if valid.any():
            eligible = np.flatnonzero(valid)
            nearest = eligible[int(np.argmin(depth[eligible]))]
            hits[vertex] = True; owners[vertex] = int(ids[nearest]); distances[vertex] = float(depth[nearest])
    return hits, owners, distances


def _area(poly):
    if len(poly) < 3:
        return 0.
    # Translate before summation to limit cancellation at large coordinates.
    p = poly - poly[0]
    return .5 * abs(float(p[:, 0] @ np.roll(p[:, 1], -1) - p[:, 1] @ np.roll(p[:, 0], -1)))


def _ccw(poly):
    p = poly - poly[0]
    return poly if float(p[:, 0] @ np.roll(p[:, 1], -1) - p[:, 1] @ np.roll(p[:, 0], -1)) >= 0 else poly[::-1]


def _clip(poly, values):
    output = []
    for i, current in enumerate(poly):
        previous = poly[i - 1]; a, b = float(values[i - 1]), float(values[i])
        if (a >= 0) != (b >= 0):
            output.append(previous + (current - previous) * (a / (a - b)))
        if b >= 0:
            output.append(current)
    return np.asarray(output, dtype=np.float64).reshape((-1, poly.shape[1]))


def _halfplane(poly, a, b, inside):
    edge = b - a; delta = poly - a
    values = edge[0] * delta[:, 1] - edge[1] * delta[:, 0]
    return _clip(poly, values if inside else -values)


def _subtract(piece, cover, dust, budget):
    rest = piece; outside = []; lost_upper_bound = 0.
    for i, a in enumerate(cover):
        budget.add('polygon_operations')
        b = cover[(i + 1) % len(cover)]
        fragment = _halfplane(rest, a, b, False); size = _area(fragment)
        if size > dust:
            outside.append(fragment)
        else:
            lost_upper_bound += size
        rest = _halfplane(rest, a, b, True); size = _area(rest)
        if size <= dust:
            # Remaining edges were not checked: count the tiny rest as unknown.
            lost_upper_bound += size
            break
    return outside, lost_upper_bound


def _triangle_coverage(triangle, direction, index, face_normals, face_mesh,
                       depth_min, depth_max, area_scale, budget):
    origin = triangle[0]
    u = triangle[1] - origin; u /= np.linalg.norm(u)
    v = np.cross(direction, u)
    body_poly = _ccw(np.column_stack(((triangle - origin) @ u, (triangle - origin) @ v)))
    total = _area(body_poly)
    tolerance = min(area_scale * 1e-12, total * 1e-9)
    dust = min(area_scale * 1e-18, total * 1e-15)
    displaced = triangle + direction * depth_max
    lower = np.minimum(triangle.min(0), displaced.min(0))
    upper = np.maximum(triangle.max(0), displaced.max(0))
    ids = index.box(lower, upper, budget)
    ids = ids[face_normals[ids] @ direction > 1e-8]
    remaining = [body_poly]; lost = 0.; contributors = set()
    for face_id in ids:
        relative = index.faces[face_id] - origin
        pad = np.column_stack((relative @ u, relative @ v, relative @ direction))
        if (pad[:, 2].max() <= depth_min or pad[:, 2].min() > depth_max
                or (pad[:, :2].max(0) < body_poly.min(0)).any()
                or (pad[:, :2].min(0) > body_poly.max(0)).any()):
            continue
        clipped = _clip(pad, pad[:, 2] - depth_min)
        if len(clipped) < 3:
            continue
        clipped = _clip(clipped, depth_max - clipped[:, 2])
        if len(clipped) < 3:
            continue
        footprint = _ccw(clipped[:, :2])
        if _area(footprint) <= dust:
            continue
        updated = []; before_area = sum(_area(piece) for piece in remaining)
        for piece in remaining:
            fragments, discarded = _subtract(piece, footprint, dust, budget)
            updated.extend(fragments); lost += discarded
        if len(updated) > WORK_LIMITS['convex_pieces']:
            raise CoverageError('clothing coverage work limit exceeded: convex_pieces')
        if sum(_area(piece) for piece in updated) < before_area:
            contributors.add(int(face_mesh[face_id]))
        remaining = updated
        if not remaining:
            break
    missing = sum(_area(piece) for piece in remaining) + lost
    if not math.isfinite(missing):
        raise CoverageError('clothing coverage polygon arithmetic became nonfinite')
    return missing <= tolerance, missing, tolerance, contributors


def select_covered_vertices(body, clothing_meshes, depth_max=None):
    """Return a conservative static selection, or raise CoverageError.

    Inputs must already share a verified rest coordinate frame. Clothing must
    already contain only opaque faces eligible for one specific scene. The
    result is not emitted as a mask here. Work refusal returns no partial IDs.
    """
    budget = _Budget(); base = _mesh(body, 'body')
    bounded_meshes = []
    for mesh in clothing_meshes:
        bounded_meshes.append(mesh)
        if len(bounded_meshes) > WORK_LIMITS['clothing_meshes']:
            raise CoverageError('clothing mesh count exceeds supported limits')
    clothing_meshes = bounded_meshes
    garments = [_mesh(mesh, 'clothing') for mesh in clothing_meshes]
    if sum(len(m['positions']) for m in garments) > WORK_LIMITS['clothing_vertices'] or sum(len(m['triangles']) for m in garments) > WORK_LIMITS['clothing_triangles']:
        raise CoverageError('combined clothing domains exceed supported limits')
    # Unsupported orientation cannot change the physical distance scale or
    # turn an entirely unproved finite surface into a claimed valid mask.
    referenced = np.unique(base['triangles'][base['nondegenerate']].ravel())
    if not len(referenced):
        raise CoverageError('paired Body has no usable referenced surface triangles')
    reference_positions = base['positions'][referenced]
    span = float(np.ptp(reference_positions, axis=0).max())
    if not math.isfinite(span) or span <= 0:
        raise CoverageError('paired Body extent is invalid for relative distance bounds')
    explicit = depth_max is not None
    if depth_max is None:
        depth_max = span * .02
    if isinstance(depth_max, (bool, np.bool_)) or not isinstance(depth_max, (int, float, np.number)) or not math.isfinite(float(depth_max)) or float(depth_max) <= 0:
        raise CoverageError('positive finite clothing depth bound is required')
    depth_max = float(depth_max)
    coordinate_scale = max(span, float(np.abs(reference_positions).max()))
    depth_min = max(span * 1e-7, np.finfo(np.float64).eps * coordinate_scale * 16)
    if depth_max <= depth_min:
        raise CoverageError('clothing depth bound is below supported coordinate precision')
    raw_remap = getattr(body, 'vertex_remap', None)
    remap = np.arange(len(base['positions']), dtype=np.uint32) if raw_remap is None else np.asarray(raw_remap)
    if (remap.shape != (len(base['positions']),) or remap.dtype.kind not in 'iu'
            or remap.min() < 0 or remap.max() > 0xffffffff):
        raise CoverageError('Body remap is outside the supported uint32 vertex domain')
    remap = remap.astype(np.uint32, copy=True)
    per_mesh = []; faces = []; normals = []; owners = []
    for i, garment in enumerate(garments):
        valid = garment['valid']; faces.append(garment['faces'][valid]); normals.append(garment['face_normals'][valid])
        owners.append(np.full(int(valid.sum()), i, dtype=np.int64))
        per_mesh.append({'index': i, 'name': garment['name'], 'input_triangles': len(garment['triangles']),
                         'usable_front_test_triangles': int(valid.sum()), 'degenerate_triangles_excluded': garment['degenerate_triangles'],
                         'winding_inconsistent_triangles_excluded': garment['winding_inconsistent_triangles'],
                         'winding_ambiguous_triangles_excluded': garment['winding_ambiguous_triangles'],
                         'minimum_winding_normal_cosine': garment['minimum_winding_normal_cosine'],
                         'minimum_supported_winding_normal_cosine': garment['minimum_supported_winding_normal_cosine'],
                         'nearest_normal_ray_hits': 0, 'fully_covered_body_triangles_contributed': 0})
    all_faces = np.concatenate(faces) if faces else np.empty((0, 3, 3))
    all_normals = np.concatenate(normals) if normals else np.empty((0, 3))
    face_mesh = np.concatenate(owners) if owners else np.empty(0, dtype=np.int64)
    index = _Index(all_faces)
    hits, ray_faces, distances = _ray(base['positions'], base['normals'], index, all_normals, depth_min, depth_max, budget)
    for i, row in enumerate(per_mesh):
        row['nearest_normal_ray_hits'] = int((face_mesh[ray_faces[hits]] == i).sum())
    possible = np.flatnonzero(base['valid'] & np.all(hits[base['triangles']], axis=1))
    budget.add('coverage_triangles', len(possible))
    covered = np.zeros(len(base['triangles']), dtype=bool)
    maximum_missing = 0.; maximum_tolerance = 0.
    for triangle_id in possible:
        triangle = base['faces'][triangle_id]
        accepted, missing, tolerance, contributors = _triangle_coverage(triangle, base['face_normals'][triangle_id], index,
            all_normals, face_mesh, depth_min, depth_max, span * span, budget)
        covered[triangle_id] = accepted
        if accepted:
            maximum_missing = max(maximum_missing, missing); maximum_tolerance = max(maximum_tolerance, tolerance)
            for i in contributors:
                per_mesh[i]['fully_covered_body_triangles_contributed'] += 1
    incident = np.zeros(len(base['positions']), dtype=np.int64)
    uncovered_incident = np.zeros(len(base['positions']), dtype=np.int64)
    np.add.at(incident, base['triangles'].ravel(), 1)
    np.add.at(uncovered_incident, base['triangles'][~covered].ravel(), 1)
    eligible = hits & (incident > 0) & (uncovered_incident == 0)
    unique, inverse, multiplicity = np.unique(remap, return_inverse=True, return_counts=True)
    bad_alias = np.zeros(len(unique), dtype=bool)
    np.logical_or.at(bad_alias, inverse, ~eligible)
    proposed_before_alias = eligible.copy()
    eligible &= ~bad_alias[inverse]
    vertices = np.flatnonzero(eligible).astype(np.uint32)
    ids = np.unique(remap[eligible])
    touched = np.any(eligible[base['triangles']], axis=1)
    if not np.all(covered[touched]):
        raise CoverageError('clothing selection failed all-incident triangle preservation check')
    unproved_vertices = np.unique(base['triangles'][base['unproved_winding']].ravel())
    return {'version': PATCH_VERSION, 'state': 'static_covered_region_selected' if len(ids) else 'no_supported_static_covered_region',
            'selected_vertex_indices': vertices.tolist(), 'selected_remap_ids': ids.tolist(),
            'selected_remap_ids_sha256': _digest_ids(ids), 'selected_vertex_indices_sha256': _digest_ids(vertices),
            'body': {'vertices': len(base['positions']), 'triangles': len(base['triangles']),
                     'maximum_span': span, 'degenerate_triangles_not_covered': base['degenerate_triangles'],
                     'winding_inconsistent_triangles_not_covered': base['winding_inconsistent_triangles'],
                     'winding_ambiguous_triangles_not_covered': base['winding_ambiguous_triangles'],
                     'vertices_incident_to_unproved_winding_triangles': int(len(unproved_vertices)),
                     'remap_ids_incident_to_unproved_winding_triangles': int(len(np.unique(remap[unproved_vertices]))),
                     'referenced_surface_vertices': int(len(referenced)),
                     'unused_vertices_excluded_from_distance_scale': int(len(base['positions']) - len(referenced)),
                     'minimum_winding_normal_cosine': base['minimum_winding_normal_cosine'],
                     'minimum_supported_winding_normal_cosine': base['minimum_supported_winding_normal_cosine']},
            'depth_policy': {'maximum': depth_max, 'minimum': depth_min, 'explicit_maximum': explicit,
                             'default_maximum_body_span_fraction': .02, 'scale_basis': 'referenced nondegenerate Body surface',
                             'units': 'actual shared rest-coordinate units'},
            'per_mesh': per_mesh,
            'evidence': {'normal_ray_hit_vertices': int(hits.sum()), 'triangles_with_three_normal_ray_hits': int(len(possible)),
                         'fully_covered_body_triangles': int(covered.sum()), 'all_incident_covered_vertices_before_alias_filter': int(proposed_before_alias.sum()),
                         'selected_vertices': int(len(vertices)), 'selected_remap_ids': int(len(ids)),
                         'triangles_touched_under_any_vertex_hiding': int(touched.sum()),
                         'triangles_selected_under_all_vertex_hiding': int(np.all(eligible[base['triangles']], axis=1).sum()),
                         'every_incident_triangle_covered': True, 'alias_groups': int((multiplicity > 1).sum()),
                         'unproved_body_winding_faces_never_covered': bool(not covered[base['unproved_winding']].any()),
                         'unproved_clothing_winding_faces_excluded_before_queries': True,
                         'authored_winding_and_normal_directions_not_reoriented': True,
                         'alias_groups_excluded_for_uncovered_render_vertex': int((bad_alias & (multiplicity > 1)).sum()),
                         'eligible_vertices_excluded_by_alias': int((proposed_before_alias & ~eligible).sum()),
                         'maximum_accepted_uncovered_area_upper_bound': maximum_missing,
                         'maximum_accepted_area_tolerance': maximum_tolerance,
                         'minimum_positive_ray_hit_distance': float(distances[hits].min()) if hits.any() else None,
                         'maximum_positive_ray_hit_distance': float(distances[hits].max()) if hits.any() else None,
                         'discarded_polygon_dust_counted_as_uncovered': True},
            'work': {'counts': budget.counts, 'limits': dict(WORK_LIMITS)},
            'limits': ['Static coverage in the supplied common rest frame only; animated coverage is unverified.',
                       'Finite ambiguous or inconsistent winding faces are excluded; every incident Body vertex and logical alias remains withheld.',
                       'Caller must validate opaque material bindings, applicable scene, paired model identity and all emitted LOD domains.',
                       'No weights, textures, geometry, simulation or source masks were changed.'],
            'in_game_validation': 'not_performed', 'input_changes': 'none'}
