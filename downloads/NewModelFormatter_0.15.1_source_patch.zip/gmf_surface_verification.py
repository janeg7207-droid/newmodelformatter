"""Check every written gear weight against the explicitly requested policy.

Geometry/rig/mask checks remain in Gorilla's original verifier. Only the
expected source-weight view for deliberately reweighted meshes is replaced.
"""
import numpy as np

TOLERANCE=2.0/255.0+1e-6


def check_written_weights(expected, actual, rig_names):
    """Reject wrong bindings even if they are finite and sum to one."""
    if expected.num_verts!=actual.num_verts:
        raise ValueError('surface target vertex count changed')
    count=expected.num_verts;rig=set(rig_names);names=sorted(set(expected.weights)|set(actual.weights))
    actual_total=np.zeros(count,dtype=np.float64)
    influence_count=np.zeros(count,dtype=np.int32)
    maximum=0.
    for name in names:
        want=np.asarray(expected.weights.get(name,np.zeros(count)),dtype=np.float64)
        got=np.asarray(actual.weights.get(name,np.zeros(count)),dtype=np.float64)
        if want.shape!=(count,) or got.shape!=(count,):raise ValueError('surface weight vector domain changed')
        if not np.isfinite(got).all() or (got<0).any():raise ValueError('written surface weights are invalid')
        if name not in rig and (got>1e-7).any():raise ValueError('written surface weight references an absent rig bone: '+name)
        error=float(np.abs(want-got).max(initial=0.))
        maximum=max(maximum,error)
        if error>TOLERANCE:raise ValueError(name+': written surface weights differ from requested policy by '+format(error,'.6f'))
        actual_total+=got;influence_count+=(got>1e-7)
    if (np.abs(actual_total-1.)>.03).any():raise ValueError('written surface influence budgets are not normalized')
    if (influence_count>8).any():raise ValueError('written surface weights exceed native eight-influence budget')
    return {'mesh':expected.name,'vertices_checked':count,'maximum_weight_error':maximum,
            'quantization_tolerance':TOLERANCE,'policy':'paired_body_nearest_surface_reference_math',
            'checks':'every bone weight, vertex budget, rig target and influence count'}
