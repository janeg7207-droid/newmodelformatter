"""Bounded, experimental shading-anchor corrections for two supplied models.

The supplied native 2K26 reference places slot 4 on its tongue. The original
Gorilla reference instead always selects M_Teeth. Complete oriented-triangle
and edge correspondence independently maps native tongue vertex 167 to
supplied Bryan and Flip tongue vertex 127. This is an anatomical-role experiment, not a confirmed
black-teeth fix. Only exact inspected input/output bytes are eligible.
"""
import functools
import hashlib
import inspect
import os
from pathlib import Path
import struct
import tempfile


PATCH_VERSION = 'exact-supplied-bryan-and-flip-tongue-anchor-experiment-2'
LEGACY_SOURCE = ('343eede12271859708f75b52deb28c92fae9fe5983dcbb7d37cd0684378d4f67', 5881276)
ORIGINAL_OUTPUT = ('9727b9f46c18eb54d4eb11a40fdf98a25d8b3ca4aac135c2b26be2714e9fad60', 6688516)
# Filled from the strictly bounded two-u16-field patch of ORIGINAL_OUTPUT.
PATCHED_OUTPUT = ('19956b0ba487d68f90999d86a3837d695b3b14c0c79763d46cebc5814a1ac4ba', 6688516)
NATIVE_REFERENCE_SHA256 = 'bb0176e86fc2e74cebc61058acac1fa3103c7a859f2e54a2196947fe95ee4a1c'
OLD_POINT = ('_ag_0004', 'M_Teeth', 4, 1605)
NEW_POINT = ('_ag_0004', 'M_Tongue', 4, 127)
PROVENANCE = {
    'native_reference_sha256': NATIVE_REFERENCE_SHA256,
    'native_reference_slot': 4,
    'native_reference_mesh': 'M_Tongue',
    'native_reference_vertex': 167,
    'matched_supplied_mesh': 'M_Tongue',
    'matched_supplied_vertex': 127,
    'render_vertices_both': 341,
    'unique_position_vertices_both': 302,
    'oriented_triangles_both': 584,
    'all_oriented_triangles_and_edges_matched': True,
    'match_method': '20 topology-label refinements; mirrored pairs resolved by anatomical X side; full oriented triangle and edge bijection independently verified',
    'anchor_target_class': 'unique one-node topology class; unique render vertex; target selection does not depend on mirrored-pair resolution',
    'current_anchor_distance_to_matched_tongue_cm': 1.4352437257766724,
    'scope': 'exact inspected supplied Bryan input/output only; no universal anchor-role assumption',
}
FLIP_LEGACY_SOURCE = ('6670af89dc43b0d95e44d70f715bb9033cf449010f3430de2978fd63884b495c', 6043100)
FLIP_ORIGINAL_OUTPUT = ('1ec8da39b5d85554b6fbcb3aa71782ebbaf665868f35e30734aa6a30c8a128dc', 6800912)
FLIP_PATCHED_OUTPUT = ('8ef00213999d1921c7b0adea4dc4afa9389ea71579b43556a9ce9f84e2e0ae0b', 6800912)
FLIP_OLD_POINT = ('_ag_0004', 'M_Teeth', 4, 1603)
FLIP_NEW_POINT = ('_ag_0004', 'M_Tongue', 4, 127)
FLIP_PROVENANCE = dict(PROVENANCE,
    current_anchor_distance_to_matched_tongue_cm=0.912656,
    scope='exact inspected supplied Flip Gordon input/output only; no universal anchor-role assumption')


def profiles():
    """Construct from constants so reviewed tests can isolate each exact profile."""
    return (
        {'name': 'Bryan', 'legacy_source': LEGACY_SOURCE,
         'original_output': ORIGINAL_OUTPUT, 'patched_output': PATCHED_OUTPUT,
         'old_point': OLD_POINT, 'new_point': NEW_POINT, 'provenance': PROVENANCE},
        {'name': 'Flip Gordon', 'legacy_source': FLIP_LEGACY_SOURCE,
         'original_output': FLIP_ORIGINAL_OUTPUT, 'patched_output': FLIP_PATCHED_OUTPUT,
         'old_point': FLIP_OLD_POINT, 'new_point': FLIP_NEW_POINT, 'provenance': FLIP_PROVENANCE},
    )


def source_profile(identity):
    matches = [profile for profile in profiles() if identity in (
        profile['legacy_source'], profile['original_output'], profile['patched_output'])]
    if len(matches) > 1: raise ValueError('experimental anchor source profile is ambiguous')
    return matches[0] if matches else None


def fingerprint(data):
    return hashlib.sha256(data).hexdigest(), len(data)


def _chunks(data):
    """Bound complete outer MCD and inner v47 model chunk streams."""
    if data[:4] != b'MCD!':
        raise ValueError('experimental anchor input is not a framed MCD')
    position = 4; models = []; terminal = False; frames = 0
    while position < len(data):
        if position + 12 > len(data):
            raise ValueError('experimental anchor MCD envelope is truncated')
        version, size, tag = struct.unpack_from('<II4s', data, position)
        if version != 4:
            raise ValueError('experimental anchor envelope version is unsupported')
        start = position + 12; end = start + size
        if end > len(data):
            raise ValueError('experimental anchor envelope payload is truncated')
        frames += 1
        if frames > 64:
            raise ValueError('experimental anchor has too many envelopes')
        if tag == b'MDL!': models.append((start, end))
        if tag == b'END!':
            if size or end != len(data):
                raise ValueError('experimental anchor terminal envelope is invalid')
            terminal = True; break
        aligned = (end + 3) & ~3
        if aligned > len(data) or data[end:aligned] != bytes(aligned - end):
            raise ValueError('experimental anchor envelope alignment is invalid')
        position = aligned
    if not terminal or len(models) != 1:
        raise ValueError('experimental anchor requires exactly one complete model')
    start, end = models[0]
    if end - start < 36 or data[start:start + 4] != b'MDL!':
        raise ValueError('experimental anchor model header is truncated')
    if struct.unpack_from('<II', data, start + 4) != (47, 1):
        raise ValueError('experimental anchor model header is unsupported')
    position = start + 36; chunks = {}; terminal = False; count = 0
    while position < end:
        if position + 8 > end:
            raise ValueError('experimental anchor inner chunk is truncated')
        tag, size = struct.unpack_from('<4sI', data, position)
        block_end = position + 8 + size
        if block_end > end:
            raise ValueError('experimental anchor inner payload is truncated')
        count += 1
        if count > 512:
            raise ValueError('experimental anchor has too many model chunks')
        if tag in (b'TEXT', b'GtPt'):
            if tag in chunks:
                raise ValueError('experimental anchor has duplicate target chunks')
            chunks[tag] = (position + 8, block_end)
        if tag == b'END!':
            if size or block_end != end:
                raise ValueError('experimental anchor inner terminal is invalid')
            terminal = True; break
        position = block_end
    if not terminal or set(chunks) != {b'TEXT', b'GtPt'}:
        raise ValueError('experimental anchor TEXT/GtPt framing is incomplete')
    return chunks


def read_points(data):
    chunks = _chunks(data)
    start, end = chunks[b'TEXT']
    if start + 4 > end:
        raise ValueError('experimental anchor TEXT count is truncated')
    count = struct.unpack_from('<I', data, start)[0]
    if not 1 <= count <= 65535 or start + 4 + 4 * count > end:
        raise ValueError('experimental anchor TEXT offsets are invalid')
    buffer = start + 4 + 4 * count; strings = []; last_terminator = buffer
    for i in range(count):
        offset = struct.unpack_from('<I', data, start + 4 + i * 4)[0]
        beginning = buffer + offset
        if beginning >= end:
            raise ValueError('experimental anchor TEXT offset leaves its chunk')
        if offset and data[beginning - 1] != 0:
            raise ValueError('experimental anchor TEXT offset points inside a string')
        terminator = data.find(b'\0', beginning, end)
        if terminator < 0:
            raise ValueError('experimental anchor TEXT string is unterminated')
        strings.append(data[beginning:terminator].decode('utf-8'))
        last_terminator = max(last_terminator, terminator + 1)
    if end - last_terminator > 3 or data[last_terminator:end] != bytes(end - last_terminator):
        raise ValueError('experimental anchor TEXT trailing padding is invalid')
    start, end = chunks[b'GtPt']
    if end - start != 4 + 13 * 8 or struct.unpack_from('<I', data, start)[0] != 13:
        raise ValueError('experimental anchor requires thirteen complete records')
    points = []; records = []; slots = set()
    for i in range(13):
        position = start + 4 + i * 8
        name, mesh, slot, vertex = struct.unpack_from('<HHHH', data, position)
        if name >= len(strings) or mesh >= len(strings) or slot in slots or not 0 <= slot < 13:
            raise ValueError('experimental anchor record indices are invalid')
        if strings[name] != '_ag_%04d' % slot:
            raise ValueError('experimental anchor record name disagrees with its slot')
        # Other mesh indices are preserved verbatim. The inspected file itself
        # contains two M_Head strings, which are not targets of this patch.
        if strings.count(strings[name]) != 1 or (slot == 4 and strings.count(strings[mesh]) != 1):
            raise ValueError('experimental anchor referenced TEXT names are ambiguous')
        slots.add(slot); points.append((strings[name], strings[mesh], slot, vertex))
        records.append(position)
    if slots != set(range(13)):
        raise ValueError('experimental anchor slot coverage is incomplete')
    return points, strings, records


def _replace_point(data, profile=None):
    """Replace only slot 4's mesh string index and vertex, both u16."""
    profile = profiles()[0] if profile is None else profile
    old_point, new_point = profile['old_point'], profile['new_point']
    points, strings, offsets = read_points(data)
    index = next(i for i, point in enumerate(points) if point[2] == 4)
    if points[index] == new_point:
        return data, [], points
    if points[index] != old_point or strings.count(new_point[1]) != 1:
        raise ValueError('experimental anchor target differs from inspected bytes')
    changed = bytearray(data); position = offsets[index]
    struct.pack_into('<H', changed, position + 2, strings.index(new_point[1]))
    struct.pack_into('<H', changed, position + 6, new_point[3])
    changed = bytes(changed); after, _, _ = read_points(changed)
    expected = list(points); expected[index] = new_point
    if after != expected:
        raise ValueError('experimental anchor changed another record')
    permitted = {position + 2, position + 3, position + 6, position + 7}
    differences = [i for i, (a, b) in enumerate(zip(data, changed)) if a != b]
    if len(data) != len(changed) or not set(differences).issubset(permitted):
        raise ValueError('experimental anchor changed non-target bytes')
    return changed, differences, after


def candidate_bytes(data, profile=None):
    identity = fingerprint(data)
    if profile is None:
        matches = [item for item in profiles() if identity in (item['original_output'], item['patched_output'])]
        if len(matches) != 1:
            raise ValueError('experimental anchor output does not match the exact inspected profile')
        profile = matches[0]
    if identity not in (profile['original_output'], profile['patched_output']):
        raise ValueError('experimental anchor output does not match the exact inspected profile')
    changed, differences, points = _replace_point(data, profile)
    if fingerprint(changed) != profile['patched_output']:
        raise ValueError('experimental anchor result does not match its reviewed fingerprint')
    return changed, differences, points


def _safe_output(source, output, selected_source, selected_output, report_output):
    if Path(source).is_symlink() or Path(output).is_symlink():
        raise ValueError('experimental anchor refuses source/output file symlinks')
    source = Path(source).resolve(); output = Path(output).resolve()
    root = Path(selected_source).resolve(); destination = Path(selected_output).resolve()
    report_root = Path(report_output).resolve()
    if (not source.is_relative_to(root) or not output.is_relative_to(destination)
            or not output.is_relative_to(report_root) or output.is_relative_to(root)
            or source == output):
        raise ValueError('experimental anchor requires separate contained output')
    return source, output


def _paired_provenance_updates(report, source, before_sha256, after_sha256):
    """Keep the pre-patch mask verification and final base-byte identity explicit."""
    source_key = os.path.normcase(str(source.resolve()))
    updates = []
    for record in report.get('models', []):
        if not isinstance(record, dict): continue
        holders = [record, record.get('facts', {})]
        for holder in holders:
            if not isinstance(holder, dict): continue
            recovery = holder.get('supplied_hide_mask_recovery')
            if not isinstance(recovery, dict): continue
            value = recovery.get('paired_source_base')
            if (not value or os.path.normcase(str(Path(value).resolve())) != source_key
                    or recovery.get('paired_output_base_sha256') != before_sha256): continue
            values = {'paired_base_verified_before_anchor_sha256': before_sha256,
                      'paired_output_base_sha256': after_sha256}
            values['paired_base_anchor_only_patch'] = {
                'version': PATCH_VERSION, 'final_sha256': after_sha256,
                'all_non_target_bytes_preserved': True,
                'body_head_mask_domains_and_geometry_preserved': True,
                'scope': 'mask verification preceded the four-wire-byte anchor patch; its paired body/head bytes did not change',
            }
            updates.append((recovery, values))
    return updates


def _warning(report, message):
    warnings = report.setdefault('warnings', [])
    if not isinstance(warnings, list):
        warnings = report.setdefault('tongue_anchor_reporting_warnings', [])
    if message not in warnings: warnings.append(message)


def _require_game_check(report, name):
    message = 'Experimental ' + name + ' tongue anchor test requires an in-game teeth check; a visual fix has not been established.'
    problems = report.setdefault('problems', [])
    if isinstance(problems, list) and message not in problems: problems.append(message)
    report['conversion_completeness'] = 'incomplete'
    report['experimental_tongue_anchor_game_check'] = 'required; appearance not validated'


def _log(log, message, detail):
    try: log(message)
    except Exception as error: detail['logging_error'] = str(error)


def process(report, selected_source, selected_output, vcmodel, log=lambda text: None):
    summary = {'version': PATCH_VERSION, 'scope': 'exact inspected supplied Bryan and Flip Gordon profiles only; each source must match its own output profile', 'applied': 0,
               'already_applied': 0, 'in_game_validation': 'not_performed',
               'black_teeth_fixed': 'not established; controlled anatomical anchor experiment', 'matched_profiles': []}
    for record in report.get('models', []):
        source = Path(record.get('source', ''))
        if not source.is_file(): continue
        source_identity = fingerprint(source.read_bytes())
        profile = source_profile(source_identity)
        if profile is None: continue
        if record.get('verify') != 'pass': continue
        committed = False; detail = None
        try:
            source, output = _safe_output(source, record['output'], selected_source,
                                          selected_output, report['output'])
            before = output.read_bytes(); changed, differences, expected_points = candidate_bytes(before, profile)
            facts = record.setdefault('facts', {})
            if not isinstance(facts, dict):
                raise ValueError('experimental anchor model facts are not a dictionary')
            if record.get('status') == 'preserved_2k26' and not isinstance(report.get('native_2k26_models_preserved', 0), int):
                raise ValueError('experimental anchor native preservation counter is invalid')
            paired_updates = _paired_provenance_updates(report, source, fingerprint(before)[0], fingerprint(changed)[0])
            old_point, new_point = profile['old_point'], profile['new_point']
            detail = {'version': PATCH_VERSION, 'profile': profile['name'], 'provenance': dict(profile['provenance']),
                      'source_sha256': source_identity[0], 'before_sha256': fingerprint(before)[0],
                      'after_sha256': fingerprint(changed)[0],
                      'old_point': list(old_point if differences else new_point),
                      'profile_original_point': list(old_point),
                      'new_point': list(new_point), 'wire_format': 'four unsigned 16-bit fields per record',
                      'fields_written': ['mesh_string_index', 'vertex_index'],
                      'permitted_wire_bytes': 4, 'changed_byte_offsets': differences,
                      'all_non_target_bytes_preserved': True, 'other_twelve_records_preserved': True,
                      'geometry_weights_masks_and_other_substreams_preserved': True,
                      'original_verification_scope': 'original model/gear/mask checks preceded the anchor-only patch; native record syntax and matched tongue domain were separately checked',
                      'in_game_validation': 'not_performed', 'black_teeth_fixed': 'not established'}
            if not differences:
                detail['state'] = 'already_applied'; summary['already_applied'] += 1
                _require_game_check(report, profile['name'])
            else:
                handle, name = tempfile.mkstemp(prefix='.tongue-anchor-', suffix='.mcd', dir=output.parent)
                stage = Path(name)
                try:
                    with os.fdopen(handle, 'wb') as stream:
                        stream.write(changed); stream.flush(); os.fsync(stream.fileno())
                    inspected = vcmodel.read_model(str(stage), with_shapes=False)
                    if [tuple(point) for point in inspected.goto_points] != expected_points:
                        raise ValueError('native reader disagrees with experimental anchor records')
                    tongue = [mesh for mesh in inspected.meshes if mesh.name == 'M_Tongue']
                    if len(tongue) != 1 or tongue[0].num_verts != 341 or new_point[3] >= tongue[0].num_verts:
                        raise ValueError('native reader did not validate the matched tongue domain')
                    if (stage.read_bytes() != changed or output.read_bytes() != before
                            or fingerprint(source.read_bytes()) != source_identity):
                        raise ValueError('experimental anchor input/output changed during staging')
                    os.replace(stage, output)
                    committed = True
                finally:
                    if stage.exists(): stage.unlink()
                detail['state'] = 'applied_experimental_anchor_test'; summary['applied'] += 1
                for recovery, values in paired_updates: recovery.update(values)
                facts['output_sha256_before_experimental_anchor'] = fingerprint(before)[0]
                facts['output_sha256'] = fingerprint(changed)[0]
                facts['byte_identical'] = False
                facts['model_bytes_preserved'] = False
                facts['geometry_weights_bones_and_embedded_streams'] = 'geometry, weights, bones and every non-target byte preserved; only GtPt slot 4 mesh-index and vertex fields changed'
                if record.get('status') == 'preserved_2k26':
                    record['status'] = 'repaired_2k26_experimental_tongue_anchor'
                    report['native_2k26_models_preserved'] = max(0, report.get('native_2k26_models_preserved', 0) - 1)
                message = 'Experimental supplied ' + profile['name'] + ' tongue anchor applied; black teeth appearance requires an in-game check.'
                _warning(report, message)
                _require_game_check(report, profile['name'])
                _log(log, message, detail)
            record['experimental_tongue_anchor'] = detail
            if profile['name'] not in summary['matched_profiles']: summary['matched_profiles'].append(profile['name'])
        except Exception as error:
            if committed:
                detail = detail or {'version': PATCH_VERSION}
                detail.update(state='applied_with_reporting_error', reason=str(error),
                              file_changes='only the reviewed GtPt target fields were committed')
                record['experimental_tongue_anchor'] = detail
                message = 'Supplied ' + profile['name'] + ' tongue anchor was written, but a reporting step failed: ' + str(error)
            else:
                record['experimental_tongue_anchor'] = {'version': PATCH_VERSION, 'state': 'not_applied',
                    'reason': str(error), 'in_game_validation': 'not_performed', 'file_changes': 'none'}
                message = 'Supplied ' + profile['name'] + ' tongue anchor experiment was not applied: ' + str(error)
            _warning(report, message)
            _log(log, message, record['experimental_tongue_anchor'])
    report['tongue_anchor_experiment'] = summary


def install(convert, anchors, folder):
    """Run after model/gear/mask checks, before face audit and durable reporting."""
    if getattr(folder, '_tongue_anchor_experiment', None) == PATCH_VERSION: return
    original = folder.convert_folder
    @functools.wraps(original)
    def convert_folder(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs); bound.apply_defaults()
        report = original(*args, **kwargs)
        process(report, bound.arguments['src'], bound.arguments['dst'], convert.vc,
                bound.arguments.get('log', lambda text: None))
        from gmf_report import save_intermediate
        save_intermediate(report, bound.arguments['dst'])
        return report
    folder.convert_folder = convert_folder
    folder._tongue_anchor_experiment = PATCH_VERSION
