"""Preserve ordinary-eye authoring and apply the user's eye-shadow defaults.

MaterialEditor's ordinary yCh_eye/Normal path clones the source properties.
Its shader 0x12 schema stores these same-key fields at slots 4--19. Gorilla's
parameter builder previously discarded them. The user explicitly requested
darkness 1.00 and falloff 0.50 for all emitted ordinary eyes; these two fields
override source authoring. Other recognized values and source data are kept.
No iris pixels or texture references are changed; appearance is unverified.
"""
import math
import struct


# MaterialEditor.dll JmtlFileService.GetWriteSchema (shader 0x12), independently
# checked against the supplied PWM jmtl_writer._WRITER_SPEC[0x12]. The dedicated
# editor conversion map has pupil aliases, but the active Working.cs path does
# not call that map. Consequently no legacy aliases are introduced here.
EYE_FLOAT_SLOTS = {
    'caustic': 4,
    'g_eyeRoughness': 5,
    'g_fFresnel': 6,
    'g_pupilLns': 7,
    'g_pupilPar': 8,
    'g_specIntensity': 10,
    'g_eyeWetness': 11,
    'eyeLidShadowDarkness': 12,
    'eyeLidShadowFallOff': 13,
    'eyeShadowConeSharpness': 14,
    'eyeShadowConeBgLevel': 15,
    'eyeShadowHorizontalFit': 16,
    'eyeShadowLidZBias': 17,
    'eyeShadowVerticalBias': 18,
    'eyeShadowVerticalFit': 19,
}
EYE_BOOL_SLOTS = {'g_refraction': 9}
FIELD_KEY_TYPES = {**{key: 'f32' for key in EYE_FLOAT_SLOTS},
                   **{key: 'bool' for key in EYE_BOOL_SLOTS}}
USER_EYE_SHADOW_DEFAULTS = {'eyeLidShadowDarkness': 1.0, 'eyeLidShadowFallOff': 0.5}
_NOTE = ('user-requested eye shadow defaults applied: eyeLidShadowDarkness=1.00, '
         'eyeLidShadowFallOff=0.50; other eligible authored eye scalars preserved; '
         'in-game eye appearance unverified')


def _float32_value(value):
    if type(value) not in (int, float):
        return None
    try:
        number = float(value)
        if not math.isfinite(number):
            return None
        # Finite Python floats can still overflow the actual f32 wire type.
        if not math.isfinite(struct.unpack('<f', struct.pack('<f', number))[0]):
            return None
        return number
    except (OverflowError, struct.error, ValueError):
        return None


def preserve_source_eye_parameters(material, result):
    """Return an isolated parameter tuple with recognized typed source values.

    Only ordinary emitted shader 0x12 receives the requested shadow defaults.
    Other authoring is preserved only for ordinary source yCh_eye/Normal.
    Legacy MTLS type 2 is float; numeric/flag types 0, 1, and 2 are accepted for
    the refraction flag, using the supplied editor's finite numeric != 0 rule.
    No texture dependencies, shader choice, or source data change. Missing or
    invalid source values cannot prevent these explicit user-requested defaults.
    """
    if result[0] != 0x12:
        return result
    source = getattr(material, 'params', {})
    source_types = getattr(material, 'types', {})
    if (str(getattr(material, 'shader', '')).casefold() != 'ych_eye'
            or str(getattr(material, 'technique', '')).casefold() != 'normal'
            or not isinstance(source, dict) or not isinstance(source_types, dict)):
        source = {}; source_types = {}
    values = {}
    for key in EYE_FLOAT_SLOTS:
        if type(source_types.get(key)) is not int or source_types[key] != 2:
            continue
        value = _float32_value(source.get(key))
        if value is not None:
            values[key] = value
    for key in EYE_BOOL_SLOTS:
        if type(source_types.get(key)) is not int or source_types[key] not in (0, 1, 2):
            continue
        value = source.get(key)
        if type(value) is bool:
            values[key] = value
        else:
            value = _float32_value(value)
            if value is not None:
                values[key] = value != 0.0
    values.update(USER_EYE_SHADOW_DEFAULTS)
    if not any(key not in result[1] or result[1][key] != value
               for key, value in values.items()) and _NOTE in (result[3] or ''):
        return result
    params = dict(result[1])
    params.update(values)
    note = result[3]
    if not note:
        note = _NOTE
    elif _NOTE not in note:
        note += '; ' + _NOTE
    return result[0], params, result[2], note
