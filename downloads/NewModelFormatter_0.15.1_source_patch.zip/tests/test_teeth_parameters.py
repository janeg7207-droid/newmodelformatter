"""Preserve authored teeth illumination without interpreting absent schema fields."""
import copy
from pathlib import Path
import sys,types,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from gmf_teeth_parameters import preserve_source_irradiance
from test_repair import recovered_function


def original_converter():
    namespace={'shader_for':lambda m:(0x1a,None),'SKIN':0x19,'HEAD':0x17,'EYE':0x12,'CARUNCLE':0x13,'EYELASH':0x14,'TEETH':0x1a,
               'HAIR':0x16,'TEETH_IRRADIANCE':(0.0,0.7490196078431373,0.7490196078431373),
               '_ref':lambda m,k:m.params.get(k)}
    return recovered_function('gmf.materials','to_2k26',namespace)


class TeethParameterTests(unittest.TestCase):
    def test_original_fixed_tuple_overrides_source_then_adapter_preserves_it(self):
        source=types.SimpleNamespace(shader='yCh_Teeth',params={'colorMap@ref':123,'g_nrmMap@ref':456,
            'irradianceR':1.0,'irradianceG':.75,'irradianceB':.75})
        before=copy.deepcopy(source.params);original=original_converter()(source,None)
        self.assertEqual(original[1]['irradianceR'],0.0)
        result=preserve_source_irradiance(source,original)
        self.assertEqual([result[1][k] for k in ['irradianceR','irradianceG','irradianceB']],[1.,.75,.75])
        self.assertEqual((result[0],result[1]['colorMap@ref'],result[1]['nrMap@ref']),(0x1a,123,456))
        self.assertEqual(source.params,before);self.assertEqual(original[1]['irradianceR'],0.)
        self.assertIn('unverified',result[3])

    def test_missing_invalid_and_out_of_range_source_values_retain_defaults(self):
        for value in [None,'1',True,float('nan'),float('inf'),-1,2]:
            source=types.SimpleNamespace(shader='yCh_Teeth',params={'irradianceR':value})
            result=original_converter()(source,None)
            self.assertIs(preserve_source_irradiance(source,result),result)

    def test_zero_is_a_valid_explicit_value_and_other_shaders_are_unchanged(self):
        source=types.SimpleNamespace(params={'irradianceR':0.})
        original=(0x1a,{'irradianceR':1.,'colorMap@ref':1},[],None)
        self.assertEqual(preserve_source_irradiance(source,original)[1]['irradianceR'],0.)
        other=(0x19,original[1],[],None)
        self.assertIs(preserve_source_irradiance(source,other),other)

    def test_valid_partial_components_keep_other_original_parameters_and_note(self):
        source=types.SimpleNamespace(params={'irradianceR':1.})
        original=(0x1a,{'irradianceR':0.,'irradianceG':.749,'irradianceB':.749,'nrMap@ref':9},['x'],'prior note')
        fixed=preserve_source_irradiance(source,original)
        self.assertEqual(fixed[1]['irradianceG'],.749);self.assertEqual(fixed[1]['nrMap@ref'],9)
        self.assertIs(fixed[2],original[2]);self.assertTrue(fixed[3].startswith('prior note;'))
        self.assertIs(preserve_source_irradiance(source,fixed),fixed)

if __name__=='__main__':unittest.main()
