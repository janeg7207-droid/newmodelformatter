"""Regression: a cloned wrapper's globals cannot override a raw closure.

Use the real gear and partial-rig wrappers with real nearest-surface math.
The raw verifier below checks both weights and unchanged source geometry.
"""
import copy
import hashlib
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import gmf_partial_rig
import gmf_repair


class PartialRigGearOrderTests(unittest.TestCase):
    def verify_with_order(self,gear_first=True,geometry_error=False):
        with tempfile.TemporaryDirectory() as temp:
            source=Path(temp)/'source.mcd';target=Path(temp)/'target.mcd'
            source.write_bytes(b'exact controlled source');target.write_bytes(b'controlled target')
            source_mesh=types.SimpleNamespace(name='M_Tights',num_verts=1,
                positions=np.array([[.2,.3,.4]]),weights={'J_A':np.array([1.])})
            written_mesh=copy.deepcopy(source_mesh)
            written_mesh.weights={'J_A':np.array([.5]),'J_B':np.array([.5])}
            if geometry_error:written_mesh.positions[0,0]+=.1
            bones=[types.SimpleNamespace(name=name) for name in ('J_A','J_B')]
            models={str(source):types.SimpleNamespace(meshes=[source_mesh],bones=bones),
                    str(target):types.SimpleNamespace(meshes=[written_mesh],bones=bones)}
            vc=types.SimpleNamespace(read_model=lambda path,*a,**k:copy.deepcopy(models[str(path)]))
            namespace={'vc':vc,'np':np}
            exec('''def verify(src_path,dst_path,ref,attached_dropped=0,variant="male",body_limits=None):
    source=vc.read_model(src_path).meshes[0]
    written=vc.read_model(dst_path).meshes[0]
    problems=[]
    for name in set(source.weights)|set(written.weights):
        if not np.allclose(source.weights.get(name,np.zeros(1)),written.weights.get(name,np.zeros(1))):
            problems.append("weights of untouched vertices moved")
            break
    if not np.array_equal(source.positions,written.positions):problems.append("source geometry changed")
    return not problems,problems,{"raw_verifier_called":True}
''',namespace)
            def convert_mcd(src_path,dst_path,ref,body_label=None):return {'notes':[]}
            skeleton=types.SimpleNamespace(convert_weights=lambda *a,**k:None)
            module=types.SimpleNamespace(verify=namespace['verify'],convert_mcd=convert_mcd,vc=vc,
                rig_family=lambda *a:'2K25')
            donor=types.SimpleNamespace(name='M_Body',num_verts=3,
                positions=[(0,0,0),(1,0,0),(0,1,0)],triangles=[(0,1,2)],
                weights={'J_A':[1.,0.,0.],'J_B':[0.,1.,1.]})
            supplied_base=types.SimpleNamespace(meshes=[donor])
            if gear_first:
                gmf_repair.patch_gear_converter(module,skeleton)
                gmf_partial_rig.install(module,skeleton)
            else:
                gmf_partial_rig.install(module,skeleton)
                gmf_repair.patch_gear_converter(module,skeleton)
            gmf_repair.set_gear_policy(True,'surface')
            try:
                with patch.object(gmf_repair,'REY_MODEL_SHA256',hashlib.sha256(source.read_bytes()).hexdigest()), \
                     patch('gmf_mask_recovery.validated_paired_base',return_value=(supplied_base,'controlled_donor')):
                    return module.verify(str(source),str(target),types.SimpleNamespace())
            finally:gmf_repair.set_gear_policy(False)

    def test_gear_before_partial_reaches_raw_expected_weight_reader(self):
        result=self.verify_with_order()
        self.assertTrue(result[0]);self.assertEqual(result[1],[])
        self.assertTrue(result[2]['raw_verifier_called'])
        self.assertEqual(result[2]['surface_weight_verification'][0]['vertices_checked'],1)

    def test_geometry_checks_still_use_real_source_after_weight_adaptation(self):
        result=self.verify_with_order(geometry_error=True)
        self.assertFalse(result[0]);self.assertEqual(result[1],['source geometry changed'])
        self.assertTrue(result[2]['raw_verifier_called'])

    def test_inverse_order_reproduces_the_closed_over_reader_regression(self):
        result=self.verify_with_order(gear_first=False)
        self.assertFalse(result[0]);self.assertIn('weights of untouched vertices moved',result[1])
        self.assertIn('surface_weight_verification',result[2])


if __name__=='__main__':unittest.main()
