import hashlib
import json
import marshal
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest
from unittest import mock

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import gmf_ycl_repair as repair


def original_ycl():
    package=types.ModuleType('_original_ycl_fixture');package.__path__=[]
    own=types.ModuleType(package.__name__+'.ycl_own');own.__package__=package.__name__
    ycl=types.ModuleType(package.__name__+'.ycl');ycl.__package__=package.__name__
    root=Path(__file__).parent/'fixtures'
    exec(marshal.loads((root/'gmf.ycl_own.marshal').read_bytes()),own.__dict__)
    package.ycl_own=own
    with mock.patch.dict(sys.modules,{package.__name__:package,own.__name__:own}):
        exec(marshal.loads((root/'gmf.ycl.marshal').read_bytes()),ycl.__dict__)
    return ycl


def sample_ycl():
    # Real kind-3 structural growth through the inspected original converter.
    node=struct.pack('<III',3,96,96)+bytes(84)
    return struct.pack('<4I2H3I',0,32,32+len(node),1,1,25,0xffffffff,0,0)+node


class YclRepairTests(unittest.TestCase):
    def test_checked_translation_uses_original_converter_and_parses_target_tree(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'in.ycl';dst=root/'out.ycl';data=sample_ycl();src.write_bytes(data)
            module=types.SimpleNamespace(ycl=original_ycl())
            result=repair.checked_translation(module,src,dst)
            self.assertEqual(src.read_bytes(),data)
            self.assertEqual(len(dst.read_bytes()),len(data)+16)
            self.assertEqual(struct.unpack_from('<HH',dst.read_bytes(),16),(1,26))
            self.assertTrue(result['target_tree_parsed']);self.assertIsNone(result['stable_2k26_roundtrip']);self.assertTrue(result['original_gorilla_translator'])

    def test_unreadable_source_retains_existing_output_and_removes_staging_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'in.ycl';dst=root/'out.ycl';src.write_bytes(b'bad');dst.write_bytes(b'original output')
            with self.assertRaisesRegex(ValueError,'readable'):repair.checked_translation(types.SimpleNamespace(ycl=original_ycl()),src,dst)
            self.assertEqual(dst.read_bytes(),b'original output');self.assertEqual(src.read_bytes(),b'bad')
            self.assertFalse(list(root.glob('.ycl-convert-*')))

    def test_output_must_not_alias_input(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'file.ycl';p.write_bytes(sample_ycl())
            with self.assertRaisesRegex(ValueError,'replace its input'):repair.checked_translation(types.SimpleNamespace(ycl=original_ycl()),p,p)

    def folder(self,source,destination,carry=None,mapped=None,companion='.wdf'):
        ycl=original_ycl()
        if carry is not None:ycl.carry=carry
        def convert_folder(src,dst,log=print,copy_other=True,slot=None):
            rel='873_Attire.ycl'
            warning=rel+': hair/cloth physics not converted (this attire also has cloth data ('+companion+') that is not converted yet) - they will not swing'
            return {'source':src,'output':dst,'problems':[warning],'warnings':[warning],
                    'physics_converted':[],'left_out':[rel+' (2K25 physics file: this attire also has cloth data ('+companion+') that is not converted yet)','873_Attire'+companion+' (2K25 physics data)']}
        return types.SimpleNamespace(convert_folder=convert_folder,ycl=ycl,
            _mapped=mapped or (lambda rel,plan:rel),_slot_plan=lambda src,slot:({}, {}, []))

    def test_folder_converts_ycl_despite_companion_and_keeps_companion_omission(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'input';dst=root/'output';src.mkdir();dst.mkdir()
            (src/'873_Attire.ycl').write_bytes(sample_ycl());(src/'873_Attire.wdf').write_bytes(b'unsupported physics'*30)
            mod=self.folder(src,dst);repair.install(mod)
            result=mod.convert_folder(str(src),str(dst),log=lambda _:None,copy_other=False)
            self.assertTrue((dst/'873_Attire.ycl').is_file());self.assertFalse((dst/'873_Attire.wdf').exists())
            self.assertEqual(result['warnings'],[]);self.assertEqual(result['left_out'],['873_Attire.wdf (2K25 physics data)'])
            self.assertEqual(len(result['physics_converted']),1);self.assertEqual(result['conversion_completeness'],'incomplete')
            self.assertIn('companion conversion is incomplete',result['problems'][0])
            saved=json.loads((dst/'input - conversion report.json').read_text());self.assertEqual(saved,result)

    def test_failed_translation_does_not_remove_original_skip_or_copy_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'input';dst=root/'output';src.mkdir();dst.mkdir()
            (src/'873_Attire.ycl').write_bytes(sample_ycl());(src/'873_Attire.wdf').write_bytes(b'unsupported')
            mod=self.folder(src,dst,carry=lambda *args:(None,'rejected source layout'));repair.install(mod)
            result=mod.convert_folder(str(src),str(dst),log=lambda _:None)
            self.assertTrue(result['warnings']);self.assertFalse((dst/'873_Attire.ycl').exists())
            self.assertEqual(result['physics_converted'],[]);self.assertIn('rejected source layout',result['problems'][-1])

    def test_mapped_away_attire_stays_omitted(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'input';dst=root/'output';src.mkdir();dst.mkdir()
            (src/'873_Attire.ycl').write_bytes(sample_ycl());(src/'873_Attire.wdf').write_bytes(b'unsupported')
            mod=self.folder(src,dst,mapped=lambda *args:None);repair.install(mod)
            result=mod.convert_folder(str(src),str(dst),log=lambda _:None,slot='999_Test')
            self.assertEqual(result['physics_converted'],[]);self.assertFalse((dst/'873_Attire.ycl').exists())

    def test_source_output_overlap_is_rejected_before_original_loop(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);mod=self.folder(root,root)
            mod.convert_folder=mock.Mock(side_effect=AssertionError('must not run original'))
            # An explicit signature models the actual original entrypoint.
            original=mod.convert_folder
            def convert_folder(src,dst,log=print,copy_other=True,slot=None):return original(src,dst)
            mod.convert_folder=convert_folder;repair.install(mod)
            with self.assertRaisesRegex(ValueError,'separate'):mod.convert_folder(str(root),str(root/'out'))
            original.assert_not_called()

    def test_plain_ywa_only_triggers_checked_ycl_without_copying_unknown_blob(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'input';dst=root/'output';src.mkdir();dst.mkdir()
            raw=sample_ycl();opaque=b'unknown authored YWA bytes - do not assign a target tag'
            (src/'873_Attire.ycl').write_bytes(raw);(src/'873_Attire.ywa').write_bytes(opaque)
            module=self.folder(src,dst,companion='.ywa');repair.install(module)
            result=module.convert_folder(str(src),str(dst),log=lambda text:None)
            self.assertEqual((src/'873_Attire.ycl').read_bytes(),raw)
            self.assertEqual((src/'873_Attire.ywa').read_bytes(),opaque)
            self.assertEqual(struct.unpack_from('<HH',(dst/'873_Attire.ycl').read_bytes(),16),(1,26))
            self.assertFalse((dst/'873_Attire.ywa').exists())
            self.assertEqual(result['left_out'],['873_Attire.ywa (2K25 physics data)'])
            self.assertEqual(result['physics_converted'][0]['unknown_companion_suffixes'],['.ywa'])
            self.assertIn('format unknown',result['physics_converted'][0]['unknown_companion_policy'])
            self.assertIn('plain .ywa format is unknown',result['problems'][0])
            self.assertEqual(sum('plain .ywa format is unknown' in text for text in result['problems']),1)
            self.assertEqual(len(result['unknown_ywa_companions']),1)
            self.assertEqual(result['conversion_completeness'],'incomplete')

    def test_plain_ywa_does_not_bypass_names_or_unreadable_source_guards(self):
        for reason in ('the exported file names other joints or meshes than the 2K25 file','unsupported source'):
            with tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);src=root/'input';dst=root/'output';src.mkdir();dst.mkdir()
                (src/'873_Attire.ycl').write_bytes(sample_ycl());(src/'873_Attire.ywa').write_bytes(b'unknown')
                module=self.folder(src,dst,carry=lambda *args:(None,reason),companion='.ywa');repair.install(module)
                result=module.convert_folder(str(src),str(dst),log=lambda text:None)
                self.assertFalse((dst/'873_Attire.ycl').exists());self.assertFalse((dst/'873_Attire.ywa').exists())
                self.assertTrue(result['warnings']);self.assertEqual(result['physics_converted'],[])
                self.assertTrue(any(reason in text for text in result['problems']))

    def successful_folder(self,src,dst,companion='.ywa'):
        module=self.folder(src,dst,companion=companion)
        original_carry=module.ycl.carry
        module.ycl.carry=mock.Mock(wraps=original_carry)
        def convert_folder(src,dst,log=print,copy_other=True,slot=None):
            source=Path(src)/'873_Attire.ycl';target=Path(dst)/'873_Attire.ycl'
            translated=repair.checked_translation(module,source,target)
            module.original_target_snapshot=(target.read_bytes(),target.stat().st_mtime_ns)
            return {'source':src,'output':dst,'problems':[],'warnings':[],
                'physics_converted':[{'file':'873_Attire.ycl','source':str(source),'how':translated['how']}],
                'left_out':['873_Attire.ywa (2K25 physics data)'] if companion=='.ywa' else []}
        module.convert_folder=convert_folder
        return module

    def test_already_successful_original_ycl_gets_unknown_notice_without_second_write(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'input';dst=root/'output';src.mkdir();dst.mkdir()
            data=sample_ycl();opaque=b'unknown'
            (src/'873_Attire.ycl').write_bytes(data);(src/'873_Attire.ywa').write_bytes(opaque)
            module=self.successful_folder(src,dst);repair.install(module)
            result=module.convert_folder(str(src),str(dst),log=lambda text:None)
            self.assertEqual(module.ycl.carry.call_count,1)
            target=dst/'873_Attire.ycl'
            self.assertEqual((target.read_bytes(),target.stat().st_mtime_ns),module.original_target_snapshot)
            self.assertEqual(len(result['physics_converted']),1)
            self.assertEqual(result['physics_converted'][0]['unknown_companion_suffixes'],['.ywa'])
            self.assertEqual(len(result['problems']),1)
            self.assertIn('plain .ywa format is unknown',result['problems'][0])
            self.assertEqual(result['conversion_completeness'],'incomplete')
            self.assertFalse((dst/'873_Attire.ywa').exists())
            self.assertEqual((src/'873_Attire.ywa').read_bytes(),opaque)
            self.assertEqual((src/'873_Attire.ycl').read_bytes(),data)

    def test_successful_known_companion_path_does_not_get_new_unknown_incompleteness(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'input';dst=root/'output';src.mkdir();dst.mkdir()
            (src/'873_Attire.ycl').write_bytes(sample_ycl());(src/'873_Attire.wdf').write_bytes(b'known original handling')
            module=self.successful_folder(src,dst,companion='.wdf');repair.install(module)
            result=module.convert_folder(str(src),str(dst),log=lambda text:None)
            self.assertEqual(module.ycl.carry.call_count,1)
            self.assertEqual(result['problems'],[])
            self.assertEqual(result['conversion_completeness'],'structural_checks_only')
            self.assertNotIn('unknown_ywa_companions',result)

    def test_unknown_companion_without_ycl_is_recorded_without_inventing_translation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'input';dst=root/'output';src.mkdir();dst.mkdir()
            (src/'873_Attire.ywa').write_bytes(b'opaque source-only companion')
            module=self.folder(src,dst,companion='.ywa')
            module.ycl.carry=mock.Mock(side_effect=AssertionError('no YCL exists'))
            def convert_folder(src,dst,log=print,copy_other=True,slot=None):
                return {'source':src,'output':dst,'problems':[],'warnings':[],
                    'physics_converted':[],'left_out':['873_Attire.ywa (2K25 physics data)']}
            module.convert_folder=convert_folder;repair.install(module)
            result=module.convert_folder(str(src),str(dst),log=lambda text:None)
            module.ycl.carry.assert_not_called()
            self.assertEqual(result['physics_converted'],[])
            self.assertFalse((dst/'873_Attire.ycl').exists());self.assertFalse((dst/'873_Attire.ywa').exists())
            self.assertEqual(len(result['problems']),1)
            self.assertIn('format is unknown',result['problems'][0])
            self.assertEqual(result['conversion_completeness'],'incomplete')
            self.assertFalse(result['unknown_ywa_companions'][0]['decoded'])
            self.assertIsNone(result['unknown_ywa_companions'][0]['target_tag'])
