"""Meaningful bounded framing and authored-mask preservation regressions."""
from pathlib import Path
import struct
import sys
import unittest
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gmf_mask_lods as masks
from test_mask_recovery import pure_mcd


def frame(tag, payload):
    result = struct.pack('<II4s', 4, len(payload), tag) + payload
    return result + bytes((-len(result)) % 4)


def native_lods(count=4, levels=None, extra_chunks=b''):
    segment = struct.pack('<I', 2) + b'bounded opaque native mesh bytes' + b'ENDM' + bytes(4)
    levels = [segment] * count if levels is None else levels
    payload = struct.pack('<I', count) + b''.join(levels)
    inner = b'MDL!' + struct.pack('<II', 47, 1) + bytes(24)
    inner += b'LODs' + struct.pack('<I', len(payload)) + payload + extra_chunks + b'END!' + bytes(4)
    return b'MCD!' + frame(b'MDL!', inner) + frame(b'END!', b'')


class CloneLODTests(unittest.TestCase):
    def test_actual_four_geometry_lods_do_not_infer_five_from_mask_slots(self):
        facts = masks.verify_cloned_lods(native_lods())
        self.assertEqual(facts['lod_count'], 4)
        self.assertEqual(facts['mesh_count'], 2)
        self.assertTrue(facts['all_lod_segments_byte_identical'])
        self.assertTrue(facts['native_reader_required'])

    def test_supported_one_and_five_segment_counts(self):
        for count in (1, 5):
            self.assertEqual(masks.verify_cloned_lods(native_lods(count))['lod_count'], count)

    def test_base_ctg_prefix_is_preserved_and_one_model_envelope_required(self):
        attire = native_lods()
        base = attire[:4] + frame(b'CTG!', b'actual preceding contact payload') + attire[4:]
        self.assertEqual(masks.verify_cloned_lods(base)['lod_segment_sha256'],
                         masks.verify_cloned_lods(attire)['lod_segment_sha256'])
        model = masks._model_payload(attire)
        duplicate = b'MCD!' + frame(b'MDL!', model) + frame(b'MDL!', model) + frame(b'END!', b'')
        with self.assertRaisesRegex(ValueError, 'ambiguous model'):
            masks.verify_cloned_lods(duplicate)

    def test_equal_length_different_levels_refuse(self):
        raw = native_lods(); changed = bytearray(raw)
        second = changed.find(b'bounded opaque native mesh bytes', changed.find(b'bounded opaque native mesh bytes') + 1)
        changed[second] ^= 1
        with self.assertRaisesRegex(ValueError, 'not byte-identical'):
            masks.verify_cloned_lods(changed)

    def test_unsupported_header_count_terminal_and_duplicate_lod_refuse(self):
        for count in (0, 6):
            with self.assertRaises(ValueError): masks.verify_cloned_lods(native_lods(count))
        raw = bytearray(native_lods()); struct.pack_into('<I', raw, 24, 41)
        with self.assertRaisesRegex(ValueError, 'v47'):
            masks.verify_cloned_lods(raw)
        with self.assertRaisesRegex(ValueError, 'ambiguous'):
            masks.verify_cloned_lods(native_lods(extra_chunks=b'LODs' + struct.pack('<I', 4) + struct.pack('<I', 1)))
        raw = native_lods().replace(b'ENDM', b'NOPE')
        with self.assertRaisesRegex(ValueError, 'terminal'):
            masks.verify_cloned_lods(raw)

    def test_inner_extent_truncation_and_unequal_segment_extents_refuse(self):
        raw = bytearray(native_lods()); struct.pack_into('<I', raw, 56, 0xffffffff)
        with self.assertRaises(ValueError): masks.verify_cloned_lods(raw)
        with self.assertRaises(ValueError): masks.verify_cloned_lods(native_lods(levels=[b'abc']))
        with self.assertRaises(ValueError): masks.verify_cloned_lods(native_lods()[:-1])


class PerLODMaskTests(unittest.TestCase):
    def setUp(self):
        self.mcd = pure_mcd()
        self.domains = {'M_Body': set(range(100)), 'M_Head': set(range(20)), 'M_Custom': {7, 9}}

    def different_lods(self, flags_by_lod):
        raw = bytearray(b'HPL!')
        for lod, flags in enumerate(flags_by_lod):
            built = self.mcd.build_hpl(flags)
            first = masks._decode_hpl(built)[0]
            raw += b'LOD!' + struct.pack('<I', lod)
            for block in first['blocks']:
                raw += b'DATA' + struct.pack('<I', block['flag'])
                for group in block['groups']: raw += group['raw']
        return bytes(raw) + b'END!' + bytes(4)

    def test_nonuniform_lods_custom_groups_and_authored_order_are_preserved(self):
        source = self.different_lods([{0: [('M_Head', [4, 2]), ('M_Body', [8, 3])],
            1: [('M_Custom', [9, 7])], 2: [('M_Head', [6, lod])]} for lod in range(5)])
        original = self.mcd.parse_hpl(source)
        changed, proof = masks.merge_mask(source, self.mcd, self.domains, {0: [3, 10, 11], 1: [12]})
        written = self.mcd.parse_hpl(changed)
        self.assertTrue(proof['had_authored_mask']); self.assertTrue(proof['nonuniform_authored_lods_preserved'])
        self.assertTrue(proof['original_flags_groups_and_id_prefixes_preserved'])
        for lod in range(5):
            self.assertEqual(written[lod][0], [('M_Head', [4, 2]), ('M_Body', [8, 3, 10, 11])])
            self.assertEqual(written[lod][1], [('M_Custom', [9, 7]), ('M_Body', [12])])
            self.assertEqual(written[lod][2], original[lod][2])
        self.assertEqual(proof['per_lod_added_counts']['0'], {'0': 2, '1': 1})
        repeated, again = masks.merge_mask(changed, self.mcd, self.domains, {0: [3, 10, 11], 1: [12]})
        self.assertEqual(repeated, changed); self.assertFalse(again['changed'])

    def test_source_none_and_exact_empty_generate_only_actual_body_ids(self):
        for source in (None, masks.EMPTY_HPL):
            changed, proof = masks.merge_mask(source, self.mcd, self.domains, {1: [5, 2, 5]})
            self.assertFalse(proof['had_authored_mask'])
            self.assertTrue(proof['all_five_hpl_slots'])
            for flags in self.mcd.parse_hpl(changed).values():
                self.assertEqual(flags, {0: [], 1: [('M_Body', [2, 5])]})

    def test_existing_per_lod_body_coverage_keeps_its_own_prefix_and_added_counts(self):
        source = self.different_lods([{0: [('M_Body', [lod, 10])]} for lod in range(5)])
        changed, proof = masks.merge_mask(source, self.mcd, self.domains, {0: [0, 1, 10], 1: [12]})
        written = self.mcd.parse_hpl(changed)
        for lod in range(5):
            self.assertEqual(written[lod][0][0][1], [lod, 10] + [value for value in (0, 1) if value != lod])
            self.assertEqual(written[lod][1], [('M_Body', [12])])
        self.assertEqual(proof['additions_counts_by_flag']['0'], {'min': 1, 'max': 2})
        self.assertEqual(proof['additions_counts_by_flag']['1'], {'min': 1, 'max': 1})

    def test_new_scene_flag_appended_without_reordering_existing_flag_blocks(self):
        source = self.mcd.build_hpl({2: [('M_Custom', [9])]})
        levels = masks._decode_hpl(source); raw = bytearray(b'HPL!')
        for level in levels:
            raw += b'LOD!' + struct.pack('<I', level['lod'])
            for block in level['blocks']:
                if block['flag'] != 2: continue
                raw += b'DATA' + struct.pack('<I', 2)
                raw += b''.join(group['raw'] for group in block['groups'])
        source = bytes(raw) + b'END!' + bytes(4)
        changed, _ = masks.merge_mask(source, self.mcd, self.domains, {1: [5], 0: [4]})
        for level in masks._decode_hpl(changed):
            self.assertEqual([block['flag'] for block in level['blocks']], [2, 0, 1])
            self.assertEqual(level['blocks'][0]['groups'][0]['ids'], [9])

    def test_empty_additions_do_not_rewrite_author_mask(self):
        source = self.mcd.build_hpl({0: [('M_Head', [1]), ('M_Body', [3, 2])]})
        written, proof = masks.merge_mask(source, self.mcd, self.domains, {})
        self.assertEqual(written, source); self.assertFalse(proof['changed'])
        self.assertEqual(masks.merge_mask(None, self.mcd, self.domains, {})[0], masks.EMPTY_HPL)

    def test_custom_flag_order_and_empty_mesh_records_are_byte_preserved(self):
        data = bytearray(b'HPL!')
        name = b'M_Custom'
        group = b'MESH' + struct.pack('<I', len(name)) + name
        group += bytes((-(4 + 8 + 8 + len(group))) % 4) + struct.pack('<I', 0)
        for lod in range(5):
            data += b'LOD!' + struct.pack('<I', lod)
            data += b'DATA' + struct.pack('<I', 2) + group + b'DATA' + struct.pack('<I', 0)
        source = bytes(data) + b'END!' + bytes(4)
        changed, _ = masks.merge_mask(source, self.mcd, self.domains, {0: [2]})
        for level in masks._decode_hpl(changed):
            self.assertEqual([block['flag'] for block in level['blocks']], [2, 0])
            self.assertEqual(level['blocks'][0]['groups'][0]['raw'], group)
            self.assertEqual(level['blocks'][0]['groups'][0]['ids'], [])

    def test_author_prefix_duplicates_remain_unchanged(self):
        source = self.mcd.build_hpl({0: [('M_Body', [3, 2, 3])]})
        changed, _ = masks.merge_mask(source, self.mcd, self.domains, {0: [3, 6]})
        self.assertEqual(self.mcd.parse_hpl(changed)[0][0], [('M_Body', [3, 2, 3, 6])])

    def test_invalid_domains_ids_flags_and_unreadable_source_refuse(self):
        for additions in ({2: [1]}, {True: [1]}, {0: [100]}, {0: [-1]}, {0: [1.5]}, {0: [True]}):
            with self.subTest(additions=additions), self.assertRaises(ValueError):
                masks.merge_mask(None, self.mcd, self.domains, additions)
        with self.assertRaises(ValueError): masks.merge_mask(None, self.mcd, {}, {0: [1]})
        for data in (b'HPL!broken', self.mcd.build_hpl({0: [('M_Head', [20])]})):
            with self.assertRaises(ValueError): masks.merge_mask(data, self.mcd, self.domains, {0: [1]})

    def test_writer_cannot_substitute_an_in_domain_or_out_of_domain_generated_id(self):
        for wrong in (3, 100):
            def bad_writer(flags):
                changed = {flag: [(name, [wrong if name == 'M_Body' and value == 2 else value for value in ids])
                                  for name, ids in groups] for flag, groups in flags.items()}
                return self.mcd.build_hpl(changed)
            bad = SimpleNamespace(build_hpl=bad_writer, parse_hpl=self.mcd.parse_hpl, hpl_is_whole=self.mcd.hpl_is_whole)
            with self.subTest(wrong=wrong), self.assertRaisesRegex(ValueError, 'generated Body IDs'):
                masks.merge_mask(None, bad, self.domains, {0: [2]})

    def test_writer_cannot_add_a_group_or_drop_requested_author_prefix(self):
        source = self.mcd.build_hpl({0: [('M_Body', [8, 3])], 1: [('M_Custom', [9])]})
        for action in ('extra_group', 'drop_prefix'):
            def bad_writer(flags):
                altered = {flag: [(name, list(ids)) for name, ids in groups] for flag, groups in flags.items()}
                if action == 'extra_group': altered[0].append(('M_Head', [2]))
                else: altered[0] = [(name, ids[1:] if name == 'M_Body' else ids) for name, ids in altered[0]]
                return self.mcd.build_hpl(altered)
            bad = SimpleNamespace(build_hpl=bad_writer, parse_hpl=self.mcd.parse_hpl, hpl_is_whole=self.mcd.hpl_is_whole)
            with self.subTest(action=action), self.assertRaisesRegex(ValueError, 'authored prefixes'):
                masks.merge_mask(source, bad, self.domains, {0: [5]})

    def test_single_author_lod_and_duplicate_body_groups_refuse_without_loss(self):
        source = self.mcd.build_hpl({0: [('M_Body', [1])]})
        level = masks._decode_hpl(source)[0]
        one = b'HPL!LOD!' + bytes(4)
        for block in level['blocks']:
            one += b'DATA' + struct.pack('<I', block['flag']) + b''.join(group['raw'] for group in block['groups'])
        one += b'END!' + bytes(4)
        with self.assertRaisesRegex(ValueError, 'slots 0..4'):
            masks.merge_mask(one, self.mcd, self.domains, {0: [2]})
        duplicate = self.mcd.build_hpl({0: [('M_Body', [1]), ('M_Body', [2])]})
        with self.assertRaisesRegex(ValueError, 'ambiguous Body'):
            masks.merge_mask(duplicate, self.mcd, self.domains, {0: [3]})

    def test_duplicate_flags_unknown_tags_padding_and_extents_refuse(self):
        source = self.mcd.build_hpl({0: [('M_Body', [1])]})
        first_lod = source.find(b'LOD!'); first_data = source.find(b'DATA')
        variants = [source[:first_data] + b'DATA' + bytes(4) + source[first_data:],
                    source.replace(b'MESH', b'WHAT', 1), source[:-1],
                    source[:first_lod + 4] + struct.pack('<I', 9) + source[first_lod + 8:]]
        corrupt = bytearray(source); position = corrupt.find(b'MESH'); struct.pack_into('<I', corrupt, position + 4, 0xffffffff); variants.append(corrupt)
        for data in variants:
            with self.assertRaises(ValueError): masks.merge_mask(data, self.mcd, self.domains, {0: [2]})


if __name__ == '__main__':
    unittest.main()
