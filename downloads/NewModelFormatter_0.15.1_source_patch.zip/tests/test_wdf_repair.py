import copy
from pathlib import Path
import struct
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import gmf_wdf_repair as wdf


def frame(tag, payload):
    value = struct.pack('<II4s', 4, len(payload), tag) + payload
    return value + bytes((-len(value)) % 4)


def chunk(tag, payload):
    return tag + struct.pack('<I', len(payload)) + payload


def block(name, records):
    raw = name.encode('ascii')
    return b'MESH' + struct.pack('<I', len(raw)) + raw + bytes((-len(raw)) % 4) + struct.pack('<I', len(records) // 48) + records


def fixture():
    records = b''.join(struct.pack('<16e8H', *([0.25 + i / 16] * 16), 1, 2, 3, 7, 4, 5, 6, 9) for i in range(5))
    raw = b'WDF!' + struct.pack('<I', 1) + block('M_Combinations', records) + b'END!' + bytes(4)
    level = struct.pack('<I', 1) + b'inspected native geometry and remap records' + b'ENDM' + bytes(4)
    mdl = b'MDL!' + struct.pack('<II', 47, 1) + bytes(24)
    mdl += chunk(b'LODs', struct.pack('<I', 4) + level * 4)
    mdl += chunk(b'MBfD', b'opaque WDF! and MESH text remains unchanged') + chunk(b'END!', b'')
    target = b'MCD!' + frame(b'MDL!', mdl) + frame(b'HPL!', b'authored mask unchanged') + frame(b'END!', b'')
    source = b'exact independently inspected legacy model'
    source_base = b'exact inspected paired source head'
    target_base = b'exact inspected corresponding native head'
    profile = dict(wdf.PROFILE, source_attire=wdf.fingerprint(source), target_attire=wdf.fingerprint(target),
                   source_base=wdf.fingerprint(source_base), target_base=wdf.fingerprint(target_base),
                   source_wdf=wdf.fingerprint(raw), source_lod0_vertices=3, source_wdf_records=5,
                   head_vertices=12, lod_mesh_count=1, lod_segment_bytes=len(level),
                   lod_segment_sha256=wdf.fingerprint(level)[0], authored_lod0_sha256=wdf.fingerprint(records[:144])[0])
    return source, target, raw, source_base, target_base, profile, records


class WdfRepairTests(unittest.TestCase):
    def setUp(self):
        self.source, self.target, self.raw, self.source_base, self.target_base, self.profile, self.records = fixture()

    def prepare(self, **changes):
        values = dict(source=self.source, target=self.target, wdf=self.raw, source_base=self.source_base, target_base=self.target_base)
        values.update(changes)
        with patch.object(wdf, 'PROFILE', self.profile): return wdf.prepare(**values)

    def test_authored_records_are_replicated_for_actual_four_model_lods(self):
        changed, payload, detail = self.prepare()
        self.assertEqual(wdf.parse_wdf(payload)[0]['records'], self.records[:144] * 4)
        self.assertEqual(detail['output_records'], 12)
        self.assertEqual(detail['target_model_lods'], 4)
        self.assertTrue(detail['all_authored_lod0_record_bytes_preserved'])
        self.assertFalse(detail['synthetic_binding_records_created'])
        self.assertEqual(detail['in_game_validation'], 'not_performed')
        before = [(f['tag'], f['payload']) for f in wdf.envelopes(self.target)]
        after = [(f['tag'], f['payload']) for f in wdf.envelopes(changed) if f['tag'] != b'WDF!']
        self.assertEqual(before, after)

    def test_every_inspected_source_target_and_pair_identity_is_required(self):
        for key, value in (('source', self.source), ('target', self.target), ('wdf', self.raw),
                           ('source_base', self.source_base), ('target_base', self.target_base)):
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, 'exact inspected'):
                self.prepare(**{key: value + b'different'})

    def test_native_raw_fallback_unsupported_version_is_rejected(self):
        value = bytearray(self.raw); struct.pack_into('<I', value, 4, 1250)
        with self.assertRaisesRegex(ValueError, 'version 1'): wdf.parse_wdf(bytes(value))

    def test_truncation_dangling_data_and_incomplete_terminal_are_rejected(self):
        for value in (self.raw[:-16], self.raw[:-4], self.raw + b'trailer'):
            with self.subTest(length=len(value)), self.assertRaises(ValueError): wdf.parse_wdf(value)

    def test_invalid_count_cannot_trigger_raw_copy_or_allocation(self):
        value = bytearray(self.raw); cursor = wdf.parse_wdf(self.raw)[0]['count_offset']
        for count in (0, 500001, 100):
            struct.pack_into('<I', value, cursor, count)
            with self.subTest(count=count), self.assertRaises(ValueError): wdf.parse_wdf(bytes(value))

    def test_duplicate_unsafe_names_and_nonzero_alignment_are_rejected(self):
        for value in (b'WDF!' + struct.pack('<I', 1) + block('../head', self.records) + b'END!' + bytes(4),
                      self.raw[:-8] + block('M_Combinations', self.records) + self.raw[-8:]):
            with self.assertRaisesRegex(ValueError, 'unsafe or duplicated'): wdf.parse_wdf(value)
        value = bytearray(self.raw); value[16 + len('M_Combinations')] = 1
        with self.assertRaisesRegex(ValueError, 'alignment'): wdf.parse_wdf(bytes(value))

    def test_header_lod_count_is_not_sufficient_without_complete_clone_geometry(self):
        marker = b'inspected native geometry and remap records'; offset = self.target.index(marker)
        value = bytearray(self.target); value[offset + self.profile['lod_segment_bytes']] ^= 1
        profile = dict(self.profile, target_attire=wdf.fingerprint(bytes(value)))
        with patch.object(wdf, 'PROFILE', profile), self.assertRaisesRegex(ValueError, 'unproved or nonidentical'):
            wdf.prepare(self.source, bytes(value), self.raw, self.source_base, self.target_base)

    def test_hpl_lod_slots_do_not_control_model_count(self):
        profile = dict(self.profile, target_lods=5)
        with patch.object(wdf, 'PROFILE', profile), self.assertRaisesRegex(ValueError, 'LOD count'):
            wdf.prepare(self.source, self.target, self.raw, self.source_base, self.target_base)

    def test_existing_wdf_stream_is_preserved_and_not_guessed(self):
        changed, payload, _ = self.prepare()
        with self.assertRaisesRegex(ValueError, 'already has'): wdf.splice_wdf(changed, payload)

    def test_nonfinite_authored_half_scalar_and_out_of_range_head_index_refuse_repair(self):
        for field, value in ((0, 0x7E00), (32, 12)):
            raw = bytearray(self.raw); start = wdf.parse_wdf(self.raw)[0]['count_offset'] + 4
            struct.pack_into('<H', raw, start + field, value)
            profile = dict(self.profile, source_wdf=wdf.fingerprint(bytes(raw)),
                           authored_lod0_sha256=wdf.fingerprint(bytes(raw[start:start + 144]))[0])
            with patch.object(wdf, 'PROFILE', profile), self.assertRaises(ValueError):
                wdf.prepare(self.source, self.target, bytes(raw), self.source_base, self.target_base)

    def make_job(self, root):
        source_root = root / 'source'; target_root = root / 'output'
        src = source_root / 'Character' / '881_Default_Attire' / '881_Attire.mcd'
        dst = target_root / 'Characters' / 'Character' / '881_Default_Attire' / '881_Attire.mcd'
        src.parent.mkdir(parents=True); dst.parent.mkdir(parents=True)
        src.write_bytes(self.source); dst.write_bytes(self.target); src.with_suffix('.wdf').write_bytes(self.raw)
        for path, value in ((src.parent.parent / 'BaseModel' / 'baseModel.mcd', self.source_base),
                            (dst.parent.parent / 'BaseModel' / 'baseModel.mcd', self.target_base)):
            path.parent.mkdir(); path.write_bytes(value)
        src.with_suffix('.ycl').write_bytes(b'original translator input')
        dst.with_suffix('.ycl').write_bytes(b'original translator output')
        row = {'source': str(src), 'output': str(dst), 'verify': 'pass', 'facts': {'substreams': ['MDL!', 'HPL!']}}
        prefix = src.relative_to(source_root).as_posix()
        report = {'source': str(source_root), 'output': str(target_root), 'models': [row],
                  'left_out': [prefix[:-4] + '.wdf (2K25 physics data)', prefix[:-4] + '.other_ywa (2K25 physics data)'],
                  'problems': [prefix[:-4] + '.ycl: YCL converted; WDF/YWA companion conversion is incomplete (.hair_corr_ywa, .hair_ywa, .other_corr_ywa, .other_ywa, .wdf); hair/cloth motion still requires validation'],
                  'physics_converted': [{'kind': 'original_unchanged_ycl_translation'}]}
        return source_root, target_root, src, dst, row, report

    def native(self, failure=False):
        def read_model(path, with_shapes):
            self.assertTrue(with_shapes)
            if failure: raise ValueError('native reader refused staged model')
            return SimpleNamespace(version=47, substreams=[(f['tag'], f['payload']) for f in wdf.envelopes(Path(path).read_bytes()) if f['tag'] != b'END!'])
        return SimpleNamespace(read_model=read_model)

    def test_job_preserves_originals_ycl_other_physics_and_truthful_incomplete_reporting(self):
        with tempfile.TemporaryDirectory() as name:
            source_root, target_root, src, dst, row, report = self.make_job(Path(name))
            snapshot = {str(p): p.read_bytes() for p in source_root.rglob('*') if p.is_file()}
            old_ycl = dst.with_suffix('.ycl').read_bytes()
            with patch.object(wdf, 'PROFILE', self.profile): wdf.process(report, source_root, target_root, self.native())
            self.assertEqual(snapshot, {str(p): p.read_bytes() for p in source_root.rglob('*') if p.is_file()})
            self.assertEqual(dst.with_suffix('.ycl').read_bytes(), old_ycl)
            self.assertEqual(report['wdf_layout_repair']['applied'], 1)
            self.assertEqual(report['conversion_completeness'], 'incomplete')
            self.assertEqual(row['facts']['output_sha256'], wdf.fingerprint(dst.read_bytes())[0])
            self.assertEqual(row['facts']['substreams'], ['MDL!', 'HPL!', 'WDF!'])
            self.assertTrue(any('.other_ywa' in x for x in report['left_out']))
            self.assertFalse(any('.wdf' in x for x in report['left_out']))
            self.assertIn('YWA companion conversion is incomplete', report['problems'][0])
            self.assertNotIn(', .wdf)', report['problems'][0])
            self.assertEqual(report['physics_converted'][0]['kind'], 'original_unchanged_ycl_translation')

    def test_native_stage_failure_and_changed_output_keep_existing_file_unchanged(self):
        for failed_native, changed_output in ((True, False), (False, True)):
            with tempfile.TemporaryDirectory() as name:
                source_root, target_root, src, dst, row, report = self.make_job(Path(name))
                if changed_output: dst.write_bytes(dst.read_bytes() + b'user change')
                before = dst.read_bytes()
                with patch.object(wdf, 'PROFILE', self.profile):
                    wdf.process(report, source_root, target_root, self.native(failed_native))
                self.assertEqual(dst.read_bytes(), before)
                self.assertEqual(report['wdf_layout_repair']['applied'], 0)
                self.assertEqual(report['wdf_layout_repair']['refused'], 1)
                self.assertTrue(any('.wdf' in x for x in report['left_out']))
                self.assertFalse(list(dst.parent.glob('.wdf-layout-*')))

    def test_failed_original_model_verifier_and_missing_paired_base_do_not_get_physics(self):
        for verify, remove_base in (('fail', False), ('pass', True)):
            with tempfile.TemporaryDirectory() as name:
                source_root, target_root, src, dst, row, report = self.make_job(Path(name)); row['verify'] = verify
                if remove_base: (dst.parent.parent / 'BaseModel' / 'baseModel.mcd').unlink()
                with patch.object(wdf, 'PROFILE', self.profile): wdf.process(report, source_root, target_root, self.native())
                self.assertEqual(dst.read_bytes(), self.target)
                self.assertEqual(report['wdf_layout_repair']['applied'], 0)

    def test_overlap_is_rejected_before_any_conversion_result_mutation(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name); report = {}
            with self.assertRaisesRegex(ValueError, 'separate'): wdf.process(report, root, root, self.native())
            self.assertEqual(report, {})

    def test_selected_folder_alias_is_rejected_before_a_source_read_or_commit(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name); source_root, target_root, src, dst, row, report = self.make_job(root)
            alias = root / 'source_alias'; alias.symlink_to(source_root, target_is_directory=True)
            row['source'] = str(alias / src.relative_to(source_root))
            with patch.object(wdf, 'PROFILE', self.profile), self.assertRaisesRegex(ValueError, 'folder aliases'):
                wdf.process(report, alias, target_root, self.native())
            self.assertEqual(dst.read_bytes(), self.target)

    def test_nested_directory_alias_does_not_commit_or_claim_restoration(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name); source_root, target_root, src, dst, row, report = self.make_job(root)
            alias = source_root / 'character_alias'; alias.symlink_to(src.parent.parent, target_is_directory=True)
            row['source'] = str(alias / src.parent.name / src.name)
            with patch.object(wdf, 'PROFILE', self.profile): wdf.process(report, source_root, target_root, self.native())
            self.assertEqual(dst.read_bytes(), self.target)
            self.assertEqual(report['wdf_layout_repair']['applied'], 0)
            self.assertNotIn('wdf_layout_repair', row)

    def test_malformed_metadata_is_rejected_before_the_file_write(self):
        for field in ('facts', 'problems', 'physics_converted', 'output'):
            with self.subTest(field=field), tempfile.TemporaryDirectory() as name:
                source_root, target_root, src, dst, row, report = self.make_job(Path(name))
                if field == 'facts': row[field] = 'malformed'
                elif field == 'output': del report['output']
                else: report[field] = 'malformed'
                with patch.object(wdf, 'PROFILE', self.profile): wdf.process(report, source_root, target_root, self.native())
                self.assertEqual(dst.read_bytes(), self.target)
                self.assertEqual(report['wdf_layout_repair']['applied'], 0)
                self.assertEqual(report['wdf_layout_repair']['refused'], 1)
                self.assertEqual(report['conversion_completeness'], 'incomplete')

    def test_later_reporting_failure_retains_truthful_written_file_identity(self):
        with tempfile.TemporaryDirectory() as name:
            source_root, target_root, src, dst, row, report = self.make_job(Path(name))
            with patch.object(wdf, 'PROFILE', self.profile), patch.object(wdf, '_record_report', side_effect=RuntimeError('late report failure')):
                wdf.process(report, source_root, target_root, self.native())
            self.assertNotEqual(dst.read_bytes(), self.target)
            self.assertEqual(row['facts']['output_sha256'], wdf.fingerprint(dst.read_bytes())[0])
            self.assertEqual(row['wdf_layout_repair']['state'], 'written_with_reporting_error')
            self.assertEqual(report['wdf_layout_repair']['applied'], 1)
            self.assertEqual(report['conversion_completeness'], 'incomplete')

    def test_concurrent_source_change_and_atomic_failure_keep_the_existing_target(self):
        for mutate_source in (True, False):
            with tempfile.TemporaryDirectory() as name:
                source_root, target_root, src, dst, row, report = self.make_job(Path(name))
                native = self.native()
                if mutate_source:
                    original_reader = native.read_model
                    def reader(path, with_shapes):
                        result = original_reader(path, with_shapes)
                        src.with_suffix('.wdf').write_bytes(b'external user change')
                        return result
                    native.read_model = reader
                    with patch.object(wdf, 'PROFILE', self.profile): wdf.process(report, source_root, target_root, native)
                else:
                    with patch.object(wdf, 'PROFILE', self.profile), patch.object(wdf.os, 'replace', side_effect=OSError('atomic replace failure')):
                        wdf.process(report, source_root, target_root, native)
                self.assertEqual(dst.read_bytes(), self.target)
                self.assertEqual(report['wdf_layout_repair']['applied'], 0)
                self.assertFalse(list(dst.parent.glob('.wdf-layout-*')))


if __name__ == '__main__': unittest.main()
