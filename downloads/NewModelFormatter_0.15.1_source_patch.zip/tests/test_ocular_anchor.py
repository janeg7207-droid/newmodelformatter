"""Binary-write guards for the two exact existing caruncle-chart profiles."""
import copy
import shutil
from pathlib import Path
import struct
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import gmf_ocular_anchor as ocular
from gmf_tongue_anchor import read_points
from tests.test_tongue_anchor import fixture as framed_fixture
sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_material_formats import library, STUB
from test_local_textures import reference_writer


def model_bytes(profile, extra_head=False):
    data, _ = framed_fixture(extra_strings=('M_Head',) if extra_head else (),
                             other_mesh='M_Head', slot4=127,
                             opaque_marker=('opaque geometry colors mask '+profile['name']).encode())
    points, strings, offsets = read_points(data)
    value = bytearray(data)
    for i,p in enumerate(points):
        if p[2] == 4:struct.pack_into('<H',value,offsets[i]+2,strings.index('M_Tongue'))
        if 5 <= p[2] <= 12:struct.pack_into('<H',value,offsets[i]+6,profile['old_vertices'][p[2]-5])
    old = bytes(value)
    for i,p in enumerate(points):
        if 5 <= p[2] <= 12:struct.pack_into('<H',value,offsets[i]+6,profile['new_vertices'][p[2]-5])
    return old,bytes(value)


class OcularAnchorTests(unittest.TestCase):
    def setUp(self):
        self.profiles = copy.deepcopy(ocular.profiles())
        self.bytes = {}
        for profile in self.profiles:
            old,new = model_bytes(profile)
            legacy = ('exact legacy '+profile['name']).encode()
            prior = ('exact native pre-tongue '+profile['name']).encode()
            profile.update(legacy=ocular.fingerprint(legacy),before_tongue=ocular.fingerprint(prior),
                           before_eye=ocular.fingerprint(old),complete=ocular.fingerprint(new))
            self.bytes[profile['name']] = {'legacy':legacy,'before_tongue':prior,'before_eye':old,'complete':new}
        self.patch = patch.object(ocular,'profiles',return_value=self.profiles)
        self.patch.start();self.addCleanup(self.patch.stop)
        self.writer = reference_writer().write_jmtl

    def paths(self,root,profile=None,source_kind='legacy',already=False,native=False,paired=True):
        profile = profile or self.profiles[0]
        source_root=root/'source';output_root=root/'output';source_root.mkdir();output_root.mkdir()
        source=source_root/'baseModel.mcd';target=output_root/'Characters'/'controlled_profile'/'BaseModel'/'baseModel.mcd'
        target.parent.mkdir(parents=True)
        source.write_bytes(self.bytes[profile['name']][source_kind])
        target.write_bytes(self.bytes[profile['name']]['complete' if already else 'before_eye'])
        gear=output_root/'Attire.mcd';gear.write_bytes(b'untouched gear weights masks physics and CPV')
        facts={'source_sha256':ocular.fingerprint(source.read_bytes())[0],
               'output_sha256':ocular.fingerprint(target.read_bytes())[0],
               'byte_identical':bool(native),'geometry_weights_bones_and_embedded_streams':'byte_identical' if native else 'original conversion checked'}
        record={'source':str(source),'output':str(target),'verify':'pass',
                'status':'preserved_2k26' if native else 'converted','facts':facts}
        if not already:
            record['experimental_tongue_anchor']={'before_sha256':profile['before_tongue'][0],
                'after_sha256':profile['before_eye'][0],'permitted_wire_bytes':4,'state':'applied_experimental_anchor_test'}
            facts['output_sha256_before_experimental_anchor']=profile['before_tongue'][0]
        report={'output':str(output_root),'models':[record],'native_2k26_models_preserved':1 if native else 0,
                'problems':[],'warnings':[]}
        # Controlled supported material fixtures; these are not authored Flip
        # assets and do not establish that the actual incomplete upload works.
        mtls=target.with_suffix('.mtls');data=bytearray(library([STUB,STUB],['eye_l','eye_r']))
        for entry in ocular.read_native_library(data):
            struct.pack_into('<Q',data,entry['hash_offset'],ocular.path_hash(ocular.game_folder(mtls)+'/Materials/'+entry['name']+'.jmtl'))
        mtls.write_bytes(data)
        materials=target.parent/'Materials';materials.mkdir()
        audit=[]
        for eye in ('eye_l','eye_r'):
            path=materials/(eye+'.jmtl')
            data=self.writer(0x12,{'colorMap@ref':123,'nrMap@ref':456,
                'eyeLidShadowDarkness':1.0,'eyeLidShadowFallOff':.5})
            path.write_bytes(data)
            audit.append({'name':eye,'file':str(path),'state':'payload_inspected',
                'shader_byte':0x12,'texture_schema_supported':True,'sha256':ocular.fingerprint(data)[0]})
        report['materials']=[{'source':str(source.with_suffix('.mtls')),'output':str(mtls),
                             'status':'preserved_2k26' if native else 'converted',
                             'written_material_payload_audit':audit}]
        if paired:
            recovery={'paired_source_base':str(source),'paired_output_base_sha256':profile['complete' if already else 'before_eye'][0],
                'paired_base_verified_before_anchor_sha256':profile['before_tongue'][0],
                'paired_base_anchor_only_patch':{'version':'prior tongue stage','final_sha256':profile['before_eye'][0],
                    'all_non_target_bytes_preserved':True,'body_head_mask_domains_and_geometry_preserved':True}}
            report['models'].append({'supplied_hide_mask_recovery':copy.deepcopy(recovery),
                                    'facts':{'supplied_hide_mask_recovery':copy.deepcopy(recovery)}})
        return source_root,output_root,source,target,gear,record,report

    def reader(self,profile=None,fail=False,wrong_head=False,wrong_uv=False,wrong_points=False,mutate_stage=False):
        profile=profile or self.profiles[0]
        def read_model(path,with_shapes):
            self.assertFalse(with_shapes)
            if fail:raise RuntimeError('native stage refused')
            data=Path(path).read_bytes()
            points,_,_=read_points(data)
            if wrong_points:points[0]=(*points[0][:3],0)
            uv=np.zeros((profile['head_vertices'],2),dtype=np.float32)
            for v,value in zip(profile['new_vertices'],ocular.REFERENCE_UVS):uv[v]=value
            if wrong_uv:uv[profile['new_vertices'][0],0]=0
            heads=[] if wrong_head else [SimpleNamespace(name='M_Head',num_verts=profile['head_vertices'],uvs=[uv])]
            if mutate_stage:Path(path).write_bytes(b'changed during native inspection')
            return SimpleNamespace(goto_points=points,meshes=heads+[SimpleNamespace(name='M_Tongue',num_verts=341)])
        return SimpleNamespace(read_model=read_model)

    def run_process(self,paths,profile=None,reader=None,log=lambda text:None):
        src,dst,source,target,gear,record,report=paths
        ocular.process(report,src,dst,reader or self.reader(profile),log)

    def test_only_eight_u16_vertex_fields_change_and_other_five_records_survive(self):
        for profile in self.profiles:
            old,new=self.bytes[profile['name']]['before_eye'],self.bytes[profile['name']]['complete']
            changed,offsets,after=ocular.candidate_bytes(old,profile)
            self.assertEqual(changed,new)
            before,_,positions=read_points(old)
            allowed={position+delta for point,position in zip(before,positions) if point[2]>=5 for delta in (6,7)}
            self.assertTrue(set(offsets)<=allowed);self.assertLessEqual(len(offsets),16)
            self.assertEqual([p for p in before if p[2]<5],[p for p in after if p[2]<5])
            self.assertEqual(len(changed),len(old))
            for i,(a,b) in enumerate(zip(old,changed)):
                if i not in allowed:self.assertEqual(a,b)

    def test_idempotence_and_source_identity_for_both_complete_outputs(self):
        for profile in self.profiles:
            data=self.bytes[profile['name']]['complete']
            self.assertEqual(ocular.candidate_bytes(data,profile)[1],[])
            self.assertEqual(ocular.source_profile(ocular.fingerprint(data))['name'],profile['name'])

    def test_unknown_and_cross_profile_outputs_are_refused(self):
        with self.assertRaisesRegex(ValueError,'exact inspected'):ocular.candidate_bytes(b'unknown')
        for a,b in ((self.profiles[0],self.profiles[1]),(self.profiles[1],self.profiles[0])):
            for stage in ('before_eye','complete'):
                with self.assertRaisesRegex(ValueError,'exact source profile'):
                    ocular.candidate_bytes(self.bytes[b['name']][stage],a)

    def test_preserved_tongue_is_required_and_partial_or_changed_eye_points_refused(self):
        profile=self.profiles[0];old=self.bytes[profile['name']]['before_eye'];points,_,offsets=read_points(old)
        for slot in (4,5):
            value=bytearray(old);index=next(i for i,p in enumerate(points) if p[2]==slot)
            struct.pack_into('<H',value,offsets[index]+6,0)
            with self.assertRaises(ValueError):ocular._replace_points(bytes(value),profile)

    def test_duplicate_untargeted_head_text_indices_are_preserved(self):
        profile=self.profiles[0];old,new=model_bytes(profile,extra_head=True)
        self.assertEqual(ocular._replace_points(old,profile)[0],new)

    def test_legacy_success_preserves_assets_and_all_prior_proof_stages(self):
        for profile in self.profiles:
            with tempfile.TemporaryDirectory() as name:
                paths=self.paths(Path(name),profile);src,dst,source,target,gear,row,report=paths
                source_before=source.read_bytes();gear_before=gear.read_bytes();tongue=copy.deepcopy(row['experimental_tongue_anchor'])
                self.run_process(paths,profile)
                self.assertEqual(target.read_bytes(),self.bytes[profile['name']]['complete'])
                self.assertEqual(source.read_bytes(),source_before);self.assertEqual(gear.read_bytes(),gear_before)
                self.assertEqual(report['ocular_anchor_correction']['applied'],1)
                self.assertEqual(report['ocular_anchor_correction']['matched_profiles'],[profile['name']])
                self.assertEqual(row['experimental_tongue_anchor']['after_sha256'],tongue['after_sha256'])
                self.assertEqual(row['experimental_tongue_anchor']['following_ocular_anchor_correction']['after_sha256'],profile['complete'][0])
                self.assertEqual(row['facts']['output_sha256_before_experimental_anchor'],profile['before_tongue'][0])
                self.assertEqual(row['facts']['output_sha256_before_ocular_anchor_correction'],profile['before_eye'][0])
                self.assertEqual(row['facts']['output_sha256'],profile['complete'][0]);self.assertFalse(row['facts']['byte_identical'])
                for holder in (report['models'][1],report['models'][1]['facts']):
                    recovery=holder['supplied_hide_mask_recovery']
                    self.assertEqual(recovery['paired_base_verified_before_anchor_sha256'],profile['before_tongue'][0])
                    self.assertEqual(recovery['paired_output_base_sha256'],profile['complete'][0])
                    self.assertEqual(recovery['paired_base_anchor_only_patch_before_ocular']['final_sha256'],profile['before_eye'][0])
                    self.assertEqual(recovery['paired_base_anchor_only_patch']['chain'][1]['slots_changed'],list(range(5,13)))
                self.assertEqual(report['conversion_completeness'],'incomplete')
                self.assertTrue(report['experimental_ocular_anchor_game_check'])
                self.assertTrue(any('in-game eye check' in p for p in report['problems']))

    def nested_paths(self, root, profile):
        paths = list(self.paths(root, profile))
        target = paths[3]
        old_character = target.parent.parent
        inner = paths[1] / 'Characters' / 'outer_archive' / 'Characters' / 'INPUT'
        inner.mkdir(parents=True)
        character = inner / old_character.name
        shutil.move(str(old_character), str(character))
        target = character / 'BaseModel' / 'baseModel.mcd'
        paths[3] = target
        row, report = paths[-2:]
        row['output'] = str(target)
        report['output'] = str(inner)
        material = report['materials'][0]
        material['output'] = str(target.with_suffix('.mtls'))
        for item in material['written_material_payload_audit']:
            item['file'] = str(target.parent / 'Materials' / (item['name'] + '.jmtl'))
        # Independently specified original-writer namespace. These remain
        # controlled material fixtures, not newly supplied authored Flip data.
        virtual = 'Characters/INPUT/controlled_profile/BaseModel'
        data = bytearray(target.with_suffix('.mtls').read_bytes())
        for entry in ocular.read_native_library(data):
            struct.pack_into('<Q', data, entry['hash_offset'],
                             ocular.path_hash(virtual + '/Materials/' + entry['name'] + '.jmtl'))
        target.with_suffix('.mtls').write_bytes(data)
        return paths, virtual

    def test_nested_characters_original_writer_bindings_allow_both_profiles(self):
        for profile in self.profiles:
            with self.subTest(profile=profile['name']), tempfile.TemporaryDirectory() as name:
                paths, virtual = self.nested_paths(Path(name), profile)
                target = paths[3]
                first_virtual = 'Characters/outer_archive/' + virtual
                snapshot = {str(p): p.read_bytes() for p in target.parent.rglob('*') if p.is_file()}
                # Reproduce the old guard's namespace error without changing
                # the report or assets before exercising the real correction.
                with patch.object(ocular, 'game_folder', return_value=first_virtual):
                    with self.assertRaisesRegex(ValueError, 'does not bind the actual local eye_l'):
                        ocular._material_guard(paths[-1], paths[2], target, profile, profile['legacy'])
                self.run_process(paths, profile)
                self.assertEqual(target.read_bytes(), self.bytes[profile['name']]['complete'])
                self.assertEqual(paths[-1]['ocular_anchor_correction']['applied'], 1)
                for filename, data in snapshot.items():
                    if filename != str(target):
                        self.assertEqual(Path(filename).read_bytes(), data)
                self.assertEqual(paths[2].read_bytes(), self.bytes[profile['name']]['legacy'])

    def test_nested_characters_wrong_actual_binding_still_refuses_model_write(self):
        for profile in self.profiles:
            with self.subTest(profile=profile['name']), tempfile.TemporaryDirectory() as name:
                paths, virtual = self.nested_paths(Path(name), profile)
                target = paths[3]
                library_path = target.with_suffix('.mtls')
                data = bytearray(library_path.read_bytes())
                entry = next(e for e in ocular.read_native_library(data) if e['name'] == 'eye_l')
                struct.pack_into('<Q', data, entry['hash_offset'],
                                 ocular.path_hash('Characters/outer_archive/' + virtual + '/Materials/eye_l.jmtl'))
                library_path.write_bytes(data)
                before = target.read_bytes()
                self.run_process(paths, profile)
                self.assertEqual(target.read_bytes(), before)
                self.assertEqual(paths[-1]['ocular_anchor_correction']['applied'], 0)
                self.assertIn('does not bind the actual local eye_l',
                              paths[-2]['experimental_ocular_anchor']['reason'])
                self.assertEqual(library_path.read_bytes(), bytes(data))

    def test_native_tongue_corrected_input_then_combined_input_keeps_truthful_identity(self):
        for profile in self.profiles:
            with tempfile.TemporaryDirectory() as name:
                paths=self.paths(Path(name),profile,source_kind='before_eye',native=True,paired=False)
                self.run_process(paths,profile)
                row,report=paths[-2:]
                self.assertFalse(row['facts']['byte_identical']);self.assertEqual(report['native_2k26_models_preserved'],0)
                self.assertEqual(row['status'],'repaired_2k26_experimental_ocular_anchors')
            with tempfile.TemporaryDirectory() as name:
                paths=self.paths(Path(name),profile,source_kind='complete',native=True,already=True,paired=False)
                before=paths[3].read_bytes();self.run_process(paths,profile)
                row,report=paths[-2:]
                self.assertEqual(paths[3].read_bytes(),before);self.assertTrue(row['facts']['byte_identical'])
                self.assertEqual(row['facts']['output_sha256'],profile['complete'][0]);self.assertEqual(report['native_2k26_models_preserved'],1)
                self.assertEqual(report['ocular_anchor_correction']['already_applied'],1)
                self.assertEqual(row['status'],'preserved_2k26');self.assertEqual(report['conversion_completeness'],'incomplete')

    def test_failed_original_geometry_or_missing_material_checks_cannot_authorize_write(self):
        for problem in ('triangles changed','native missing-data check: missing_mtls'):
            with tempfile.TemporaryDirectory() as name:
                paths=self.paths(Path(name));row,report=paths[-2:];row.update(verify='fail',problems=[problem])
                before=paths[3].read_bytes();self.run_process(paths)
                self.assertEqual(paths[3].read_bytes(),before);self.assertNotIn('experimental_ocular_anchor',row)
                self.assertEqual(report['ocular_anchor_correction']['applied'],0)

    def test_legacy_model_pass_cannot_override_missing_failed_or_stale_paired_materials(self):
        failures=('missing_row','failed_row','wrong_source','row_problem','missing_mtls','malformed_mtls','wrong_binding',
                  'missing_eye','bad_eye','wrong_eye_shader','stale_audit','failed_audit','missing_audit',
                  'missing_eye_policy','paired_policy_failed')
        for failure in failures:
            with self.subTest(failure=failure),tempfile.TemporaryDirectory() as name:
                paths=self.paths(Path(name));row,report=paths[-2:]
                material=report['materials'][0];mtls=Path(material['output']);eye=mtls.parent/'Materials'/'eye_l.jmtl'
                if failure=='missing_row':report['materials']=[]
                elif failure=='failed_row':material['status']='unsupported_inline_materials'
                elif failure=='wrong_source':material['source']=str(paths[0]/'other.mtls')
                elif failure=='row_problem':material['problems']=['a genuine conversion failure']
                elif failure=='missing_mtls':mtls.unlink()
                elif failure=='malformed_mtls':mtls.write_bytes(b'MTLs invalid')
                elif failure=='wrong_binding':
                    value=bytearray(mtls.read_bytes());entry=ocular.read_native_library(value)[0]
                    struct.pack_into('<Q',value,entry['hash_offset'],123);mtls.write_bytes(value)
                elif failure=='missing_eye':eye.unlink()
                elif failure=='bad_eye':eye.write_bytes(b'invalid Eye')
                elif failure=='wrong_eye_shader':eye.write_bytes(self.writer(0x1a,{'colorMap@ref':123,'nrMap@ref':456}))
                elif failure=='stale_audit':material['written_material_payload_audit'][0]['sha256']='stale'
                elif failure=='failed_audit':material['written_material_payload_audit'][0]['state']='payload_not_inspected'
                elif failure=='missing_audit':material['written_material_payload_audit']=[]
                elif failure=='missing_eye_policy':eye.write_bytes(self.writer(0x12,{'colorMap@ref':123,'nrMap@ref':456}))
                else:report['eye_scalar_policy']={'rows':[{'output':str(eye),'state':'eye_policy_not_applied','reason':'unsupported layout'}]}
                before=paths[3].read_bytes();self.run_process(paths)
                self.assertEqual(row['verify'],'pass');self.assertEqual(paths[3].read_bytes(),before)
                self.assertEqual(row['experimental_ocular_anchor']['state'],'not_applied')
                self.assertEqual(row['experimental_ocular_anchor']['file_changes'],'none')
                self.assertEqual(report['conversion_completeness'],'incomplete')
                self.assertTrue(any('ocular anchor correction was not applied' in item for item in report['problems']))

    def test_unrelated_attire_and_global_game_checks_do_not_block_complete_base_materials(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.paths(Path(name));report=paths[-1]
            report['problems']=['attire hide-mask game check remains required']
            report['materials'].append({'output':str(paths[1]/'Attire.mtls'),'status':'failed','problems':['unrelated attire']})
            report['eye_scalar_policy']={'rows':[{'output':str(paths[1]/'Other'/'Materials'/'eye_l.jmtl'),
                'state':'eye_policy_not_applied','reason':'unrelated material'}]}
            self.run_process(paths)
            self.assertEqual(paths[3].read_bytes(),self.bytes['Bryan']['complete'])
            self.assertEqual(report['ocular_anchor_correction']['applied'],1)

    def test_native_complete_materials_are_required_even_with_model_pass(self):
        for failure in ('missing_mtls','missing_eye','malformed_mtls'):
            with self.subTest(failure=failure),tempfile.TemporaryDirectory() as name:
                paths=self.paths(Path(name),source_kind='before_eye',native=True,paired=False)
                mtls=paths[3].with_suffix('.mtls')
                if failure=='missing_mtls':mtls.unlink()
                elif failure=='missing_eye':(mtls.parent/'Materials'/'eye_r.jmtl').unlink()
                else:mtls.write_bytes(b'invalid')
                before=paths[3].read_bytes();self.run_process(paths)
                self.assertEqual(paths[3].read_bytes(),before)
                self.assertEqual(paths[-2]['experimental_ocular_anchor']['state'],'not_applied')

    def test_paired_material_mutation_during_native_validation_refuses_atomically(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.paths(Path(name));reader=self.reader();original=reader.read_model
            def mutate(path,with_shapes):
                model=original(path,with_shapes)
                paths[3].with_suffix('.mtls').write_bytes(b'mutated externally')
                return model
            before=paths[3].read_bytes();self.run_process(paths,reader=SimpleNamespace(read_model=mutate))
            self.assertEqual(paths[3].read_bytes(),before)
            self.assertIn('material',paths[-2]['experimental_ocular_anchor']['reason'])

    def test_unknown_source_and_known_source_with_changed_geometry_are_untouched(self):
        for unknown_source in (True,False):
            with tempfile.TemporaryDirectory() as name:
                paths=self.paths(Path(name))
                if unknown_source:paths[2].write_bytes(b'unknown source')
                else:paths[3].write_bytes(paths[3].read_bytes()+b'changed geometry')
                before=paths[3].read_bytes();self.run_process(paths)
                self.assertEqual(paths[3].read_bytes(),before)
                self.assertEqual(paths[-1]['ocular_anchor_correction']['applied'],0)

    def test_cross_profile_process_never_stages_foreign_output(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.paths(Path(name));paths[3].write_bytes(self.bytes['Flip Gordon']['before_eye'])
            before=paths[3].read_bytes();self.run_process(paths)
            self.assertEqual(paths[3].read_bytes(),before)
            self.assertEqual(paths[-2]['experimental_ocular_anchor']['state'],'not_applied')

    def test_native_reader_head_uv_record_and_stage_mutation_failures_are_atomic(self):
        for kwargs in ({'fail':True},{'wrong_head':True},{'wrong_uv':True},{'wrong_points':True},{'mutate_stage':True}):
            with tempfile.TemporaryDirectory() as name:
                paths=self.paths(Path(name));before=paths[3].read_bytes()
                self.run_process(paths,reader=self.reader(**kwargs))
                self.assertEqual(paths[3].read_bytes(),before)
                self.assertEqual(list(paths[1].glob('.ocular-anchor-*')),[])
                self.assertEqual(paths[-2]['experimental_ocular_anchor']['state'],'not_applied')

    def test_invalid_facts_and_stale_tongue_or_mask_proofs_refuse_before_commit(self):
        for field in ('facts','tongue','mask','problems'):
            with tempfile.TemporaryDirectory() as name:
                paths=self.paths(Path(name));row,report=paths[-2:]
                if field=='facts':row['facts']=[]
                elif field=='tongue':row['experimental_tongue_anchor']['after_sha256']='wrong'
                elif field=='mask':report['models'][1]['facts']['supplied_hide_mask_recovery']['paired_output_base_sha256']='wrong'
                else:report['problems']='invalid'
                before=paths[3].read_bytes();self.run_process(paths)
                self.assertEqual(paths[3].read_bytes(),before);self.assertEqual(row['experimental_ocular_anchor']['state'],'not_applied')

    def test_source_output_symlinks_and_overlapping_roots_are_refused(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.paths(Path(name));source=paths[2];actual=source.with_name('actual.mcd');source.rename(actual);source.symlink_to(actual)
            before=paths[3].read_bytes();self.run_process(paths);self.assertEqual(paths[3].read_bytes(),before)
            self.assertIn('symlink',paths[-2]['experimental_ocular_anchor']['reason'])
        with tempfile.TemporaryDirectory() as name:
            paths=self.paths(Path(name));target=paths[3];actual=target.with_name('actual.mcd');target.rename(actual);target.symlink_to(actual)
            before=actual.read_bytes();self.run_process(paths);self.assertEqual(actual.read_bytes(),before);self.assertTrue(target.is_symlink())
        with tempfile.TemporaryDirectory() as name:
            paths=self.paths(Path(name));before=paths[3].read_bytes()
            ocular.process(paths[-1],Path(name),paths[1],self.reader())
            self.assertEqual(paths[3].read_bytes(),before)

    def test_log_failure_cannot_claim_committed_file_unchanged(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.paths(Path(name))
            def fail(text):raise RuntimeError('UI logger failed')
            self.run_process(paths,log=fail)
            self.assertEqual(paths[3].read_bytes(),self.bytes['Bryan']['complete'])
            detail=paths[-2]['experimental_ocular_anchor']
            self.assertEqual(detail['state'],'applied_existing_ocular_anchor_correction');self.assertIn('logging_error',detail)
            self.assertEqual(paths[-2]['facts']['output_sha256'],self.profiles[0]['complete'][0])

    def test_prior_proof_link_error_after_commit_keeps_current_hash_and_game_status(self):
        class FailedLink(dict):
            def update(self,*args,**kwargs):raise RuntimeError('prior proof link failed')
        with tempfile.TemporaryDirectory() as name:
            paths=self.paths(Path(name),source_kind='before_eye',native=True,paired=False)
            with patch.object(ocular,'_provenance_updates',return_value=[(FailedLink(),{})]):
                self.run_process(paths)
            row,report=paths[-2:]
            self.assertEqual(paths[3].read_bytes(),self.bytes['Bryan']['complete'])
            self.assertEqual(row['experimental_ocular_anchor']['state'],'applied_with_reporting_error')
            self.assertEqual(row['facts']['output_sha256'],self.profiles[0]['complete'][0])
            self.assertFalse(row['facts']['byte_identical']);self.assertEqual(report['native_2k26_models_preserved'],0)
            self.assertEqual(report['conversion_completeness'],'incomplete')
            self.assertTrue(report['experimental_ocular_anchor_game_check'])

    def test_install_uses_actual_vc_alias_and_is_idempotent(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.paths(Path(name));report=paths[-1]
            def original(src,dst,log=lambda text:None):return report
            folder=SimpleNamespace(convert_folder=original);convert=SimpleNamespace(vc=self.reader())
            checkpoints=[]
            with patch('gmf_report.save_intermediate',side_effect=lambda r,d:checkpoints.append((r,d))):
                ocular.install(convert,folder);first=folder.convert_folder
                ocular.install(convert,folder);self.assertIs(folder.convert_folder,first)
                actual=folder.convert_folder(str(paths[0]),str(paths[1]))
            self.assertIs(actual,report);self.assertEqual(len(checkpoints),1)
            self.assertEqual(report['ocular_anchor_correction']['applied'],1)


if __name__=='__main__':unittest.main()
