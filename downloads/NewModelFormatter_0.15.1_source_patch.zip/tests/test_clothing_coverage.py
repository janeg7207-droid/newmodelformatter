"""Analytic per-model coverage, boundary/alias safety and explicit work refusal."""
import copy
import hashlib
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gmf_clothing_coverage as coverage


def grid(count=5, scale=1.):
    coords = np.linspace(-2., 2., count) * scale
    positions = np.asarray([[x, y, 0.] for y in coords for x in coords])
    triangles = []
    for row in range(count - 1):
        for col in range(count - 1):
            a = row * count + col
            triangles.extend(((a, a + 1, a + count + 1), (a, a + count + 1, a + count)))
    return SimpleNamespace(name='body', num_verts=len(positions), positions=positions,
        triangles=np.asarray(triangles, dtype=np.int32), normals=np.tile([0., 0., 1.], (len(positions), 1)),
        vertex_remap=np.arange(len(positions), dtype=np.uint32), weights={'untouched': np.ones(len(positions))})


def rectangle(x1=-2.1, x2=2.1, y1=-2.1, y2=2.1, z=1., *, back=False, name='opaque clothing'):
    positions = np.asarray([[x1, y1, z], [x2, y1, z], [x2, y2, z], [x1, y2, z]], dtype=float)
    triangles = np.asarray([[0, 1, 2], [0, 2, 3]], dtype=np.int32)
    if back:
        triangles = triangles[:, [0, 2, 1]]
    return SimpleNamespace(name=name, num_verts=4, positions=positions, triangles=triangles,
        normals=np.tile([0., 0., -1. if back else 1.], (4, 1)), weights={'untouched': np.ones(4)})


def box(expansion=0., omit_bottom=False):
    x, y, z = 1. + expansion, 2. + expansion, 1. + expansion
    corners = np.asarray([[-x, -y, -z], [x, -y, -z], [x, y, -z], [-x, y, -z],
                          [-x, -y, z], [x, -y, z], [x, y, z], [-x, y, z]])
    definitions = [([0, 3, 2, 1], [0., 0., -1.]), ([4, 5, 6, 7], [0., 0., 1.]),
                   ([0, 4, 7, 3], [-1., 0., 0.]), ([1, 2, 6, 5], [1., 0., 0.]),
                   ([0, 1, 5, 4], [0., -1., 0.]), ([3, 7, 6, 2], [0., 1., 0.])]
    if omit_bottom:
        definitions = definitions[1:]
    positions = []; normals = []; triangles = []; remap = []
    for ids, normal in definitions:
        first = len(positions); positions.extend(corners[ids]); normals.extend([normal] * 4); remap.extend(ids)
        triangles.extend([[first, first + 1, first + 2], [first, first + 2, first + 3]])
    return SimpleNamespace(name='closed sole and upper', num_verts=len(positions), positions=np.asarray(positions),
        triangles=np.asarray(triangles, dtype=np.int32), normals=np.asarray(normals),
        vertex_remap=np.asarray(remap, dtype=np.uint32))


class ClothingCoverageTests(unittest.TestCase):
    def test_full_offset_plane_covers_body_without_raw_bbox_containment_or_input_changes(self):
        body, cloth = grid(), rectangle(); before = copy.deepcopy((body, cloth))
        result = coverage.select_covered_vertices(body, [cloth], depth_max=2.)
        self.assertEqual(result['selected_vertex_indices'], list(range(25)))
        self.assertEqual(result['selected_remap_ids'], list(range(25)))
        self.assertTrue(result['evidence']['every_incident_triangle_covered'])
        self.assertEqual(result['evidence']['fully_covered_body_triangles'], 32)
        self.assertEqual(result['in_game_validation'], 'not_performed')
        for old, new in zip(before, (body, cloth)):
            for key in ('positions', 'triangles', 'normals'):
                np.testing.assert_array_equal(getattr(old, key), getattr(new, key))
            np.testing.assert_array_equal(old.weights['untouched'], new.weights['untouched'])

    def test_one_ring_erosion_keeps_only_interior_vertex_and_no_bare_neighbor_triangle(self):
        body = grid(); result = coverage.select_covered_vertices(body, [rectangle(-1.2, 1.2, -1.2, 1.2)], 2.)
        self.assertEqual(result['selected_vertex_indices'], [12])
        self.assertEqual(result['evidence']['normal_ray_hit_vertices'], 9)
        selected = set(result['selected_vertex_indices'])
        touched = [t for t in body.triangles if any(int(v) in selected for v in t)]
        self.assertTrue(all((np.abs(body.positions[t, :2]) <= 1.2).all() for t in touched))

    def test_rotated_translated_sole_frame_has_the_same_selection(self):
        body, cloth = grid(), rectangle()
        rotation = np.asarray([[1., 0., 0.], [0., 0., -1.], [0., 1., 0.]])
        shift = np.asarray([20., -30., 100.])
        for mesh in (body, cloth):
            mesh.positions = mesh.positions @ rotation.T + shift
            mesh.normals = mesh.normals @ rotation.T
        result = coverage.select_covered_vertices(body, [cloth], 2.)
        self.assertEqual(result['selected_remap_ids'], list(range(25)))

    def test_closed_boot_surface_and_missing_sole_respect_all_face_render_aliases(self):
        body = box(); complete = coverage.select_covered_vertices(body, [box(.04)])
        self.assertEqual(complete['selected_remap_ids'], list(range(8)))
        self.assertEqual(len(complete['selected_vertex_indices']), 24)
        missing = coverage.select_covered_vertices(body, [box(.04, omit_bottom=True)])
        self.assertEqual(missing['selected_remap_ids'], [4, 5, 6, 7])
        self.assertEqual(missing['evidence']['alias_groups_excluded_for_uncovered_render_vertex'], 4)

    def test_multiple_clothes_jointly_cover_triangles_crossing_their_boundary(self):
        body = grid(4)
        left = rectangle(-2.1, 0., name='left piece'); right = rectangle(0., 2.1, name='right piece')
        result = coverage.select_covered_vertices(body, [left, right], 2.)
        self.assertEqual(len(result['selected_vertex_indices']), 16)
        self.assertEqual(result['evidence']['fully_covered_body_triangles'], 18)
        self.assertTrue(all(row['fully_covered_body_triangles_contributed'] > 0 for row in result['per_mesh']))

    def test_all_vertex_rays_hit_but_actual_hole_inside_triangles_prevents_mask(self):
        body = grid(2)
        result = coverage.select_covered_vertices(body, [rectangle(-2.1, -.01), rectangle(.01, 2.1)], 2.)
        self.assertEqual(result['evidence']['normal_ray_hit_vertices'], 4)
        self.assertEqual(result['evidence']['triangles_with_three_normal_ray_hits'], 2)
        self.assertEqual(result['selected_remap_ids'], [])

    def test_tiny_uncovered_sliver_is_not_discarded_as_complete_coverage(self):
        body = grid(2)
        gap = 1e-9
        result = coverage.select_covered_vertices(body, [rectangle(-2.1, -gap), rectangle(gap, 2.1)], 2.)
        self.assertEqual(result['evidence']['normal_ray_hit_vertices'], 4)
        self.assertEqual(result['selected_vertex_indices'], [])
        self.assertTrue(result['evidence']['discarded_polygon_dust_counted_as_uncovered'])

    def test_backface_only_negative_depth_and_over_distance_do_not_hide_skin(self):
        for cloth in (rectangle(back=True), rectangle(z=-1.), rectangle(z=3.)):
            with self.subTest(cloth=cloth.positions.tolist()):
                result = coverage.select_covered_vertices(grid(), [cloth], 2.)
                self.assertEqual(result['selected_remap_ids'], [])

    def test_entirely_inconsistent_surfaces_have_no_coverage_without_orientation_guess(self):
        cloth = rectangle(); cloth.triangles = cloth.triangles[:, [0, 2, 1]]
        result = coverage.select_covered_vertices(grid(), [cloth], 2.)
        self.assertEqual(result['selected_remap_ids'], [])
        self.assertEqual(result['per_mesh'][0]['winding_inconsistent_triangles_excluded'], 2)
        self.assertEqual(result['per_mesh'][0]['usable_front_test_triangles'], 0)
        body = grid(); body.triangles = body.triangles[:, [0, 2, 1]]
        original_triangles = body.triangles.copy(); original_normals = body.normals.copy()
        result = coverage.select_covered_vertices(body, [rectangle()], 2.)
        self.assertEqual(result['selected_remap_ids'], [])
        self.assertEqual(result['state'], 'no_supported_static_covered_region')
        self.assertEqual(result['body']['winding_inconsistent_triangles_not_covered'], 32)
        self.assertEqual(result['body']['vertices_incident_to_unproved_winding_triangles'], 25)
        self.assertEqual(result['evidence']['fully_covered_body_triangles'], 0)
        np.testing.assert_array_equal(body.triangles, original_triangles)
        np.testing.assert_array_equal(body.normals, original_normals)

    def test_one_inconsistent_body_face_withholds_shared_vertices_but_keeps_independent_regions(self):
        body = grid(); body.triangles[0] = body.triangles[0, [0, 2, 1]]
        affected = set(map(int, body.triangles[0])); self.assertEqual(affected, {0, 1, 6})
        result = coverage.select_covered_vertices(body, [rectangle()], 2.)
        self.assertEqual(result['selected_vertex_indices'], sorted(set(range(25)) - affected))
        self.assertEqual(result['body']['winding_inconsistent_triangles_not_covered'], 1)
        self.assertEqual(result['body']['vertices_incident_to_unproved_winding_triangles'], 3)
        self.assertEqual(result['evidence']['fully_covered_body_triangles'], 31)
        self.assertTrue(result['evidence']['unproved_body_winding_faces_never_covered'])
        self.assertTrue(result['evidence']['authored_winding_and_normal_directions_not_reoriented'])

    def test_cancelling_mean_normals_exclude_ambiguous_body_component_only(self):
        body = grid(2)
        body.positions = np.asarray([[-2., -2., 0.], [-1., -2., 0.], [-2., -1., 0.],
                                     [1., 1., 0.], [2., 1., 0.], [1., 2., 0.]])
        body.triangles = np.asarray([[0, 1, 2], [3, 4, 5]], dtype=np.int32)
        body.normals = np.asarray([[1., 0., 0.], [-.5, np.sqrt(3.) / 2., 0.],
                                   [-.5, -np.sqrt(3.) / 2., 0.], [0., 0., 1.], [0., 0., 1.], [0., 0., 1.]])
        body.num_verts = 6; body.vertex_remap = np.arange(6, dtype=np.uint32)
        result = coverage.select_covered_vertices(body, [rectangle()], 2.)
        self.assertEqual(result['selected_remap_ids'], [3, 4, 5])
        self.assertEqual(result['body']['winding_ambiguous_triangles_not_covered'], 1)
        self.assertEqual(result['body']['winding_inconsistent_triangles_not_covered'], 0)
        self.assertEqual(result['body']['vertices_incident_to_unproved_winding_triangles'], 3)

    def test_one_garment_keeps_proved_faces_and_excludes_its_inconsistent_independent_piece(self):
        left = rectangle(-2.1, -.5); right = rectangle(.5, 2.1)
        cloth = copy.deepcopy(left)
        cloth.positions = np.vstack((left.positions, right.positions))
        cloth.normals = np.vstack((left.normals, right.normals))
        cloth.triangles = np.vstack((left.triangles, right.triangles[:, [0, 2, 1]] + 4))
        cloth.num_verts = 8
        result = coverage.select_covered_vertices(grid(), [cloth], 2.)
        # Only x=-2 has a wholly covered incident fan; the x=-1 boundary
        # also touches bare triangles. The incorrect right piece adds no IDs.
        self.assertEqual(result['selected_vertex_indices'], [0, 5, 10, 15, 20])
        self.assertEqual(result['per_mesh'][0]['winding_inconsistent_triangles_excluded'], 2)
        self.assertEqual(result['per_mesh'][0]['usable_front_test_triangles'], 2)
        self.assertTrue(result['evidence']['unproved_clothing_winding_faces_excluded_before_queries'])

    def test_unproved_body_face_alias_blocks_otherwise_covered_logical_id(self):
        body = grid(); body.triangles[0] = body.triangles[0, [0, 2, 1]]
        body.vertex_remap[24] = body.vertex_remap[0]
        result = coverage.select_covered_vertices(body, [rectangle()], 2.)
        self.assertEqual(result['selected_vertex_indices'], sorted(set(range(25)) - {0, 1, 6, 24}))
        self.assertNotIn(0, result['selected_remap_ids'])
        self.assertEqual(result['evidence']['eligible_vertices_excluded_by_alias'], 1)
        self.assertEqual(result['evidence']['alias_groups_excluded_for_uncovered_render_vertex'], 1)

    def test_permuted_remap_returns_actual_ids_and_stable_little_endian_hash(self):
        body = grid(); body.vertex_remap = np.roll(body.vertex_remap, 4)
        result = coverage.select_covered_vertices(body, [rectangle(-1.2, 1.2, -1.2, 1.2)], 2.)
        expected = int(body.vertex_remap[12])
        self.assertEqual(result['selected_vertex_indices'], [12]); self.assertEqual(result['selected_remap_ids'], [expected])
        self.assertEqual(result['selected_remap_ids_sha256'], hashlib.sha256(np.asarray([expected], dtype='<u4').tobytes()).hexdigest())

    def test_uncovered_render_alias_blocks_otherwise_covered_mask_id(self):
        body = grid(); body.vertex_remap[0] = body.vertex_remap[12]
        result = coverage.select_covered_vertices(body, [rectangle(-1.2, 1.2, -1.2, 1.2)], 2.)
        self.assertEqual(result['selected_remap_ids'], [])
        self.assertEqual(result['evidence']['eligible_vertices_excluded_by_alias'], 1)
        self.assertEqual(result['evidence']['alias_groups_excluded_for_uncovered_render_vertex'], 1)

    def test_all_covered_render_aliases_allow_one_logical_id(self):
        body = grid(); body.vertex_remap[0] = body.vertex_remap[12]
        result = coverage.select_covered_vertices(body, [rectangle()], 2.)
        self.assertEqual(len(result['selected_vertex_indices']), 25)
        self.assertEqual(len(result['selected_remap_ids']), 24)
        self.assertEqual(result['evidence']['eligible_vertices_excluded_by_alias'], 0)

    def test_default_relative_depth_is_scale_invariant(self):
        outputs = []
        for scale in (1e-9, 1e-3, 1., 1000.):
            body = grid(scale=scale)
            cloth = rectangle(-2.1 * scale, 2.1 * scale, -2.1 * scale, 2.1 * scale, .04 * scale)
            result = coverage.select_covered_vertices(body, [cloth])
            self.assertAlmostEqual(result['depth_policy']['maximum'], .08 * scale)
            self.assertFalse(result['depth_policy']['explicit_maximum']); outputs.append(result['selected_remap_ids'])
        self.assertEqual(outputs, [list(range(25))] * 4)

    def test_unreferenced_far_vertex_cannot_inflate_safe_distance_bound(self):
        body = grid()
        body.positions = np.vstack((body.positions, [1e6, 1e6, 1e6]))
        body.normals = np.vstack((body.normals, [0., 0., 1.]))
        body.vertex_remap = np.arange(26, dtype=np.uint32); body.num_verts = 26
        result = coverage.select_covered_vertices(body, [rectangle(z=100.)])
        self.assertEqual(result['selected_remap_ids'], [])
        self.assertAlmostEqual(result['depth_policy']['maximum'], .08)
        self.assertEqual(result['body']['unused_vertices_excluded_from_distance_scale'], 1)

    def test_nonfinite_positions_normals_invalid_indices_and_remap_are_refused(self):
        for scenario in ('position', 'normal', 'zero_normal', 'triangle', 'negative_remap', 'huge_remap', 'count'):
            with self.subTest(scenario=scenario):
                body = grid()
                if scenario == 'position': body.positions[0, 0] = np.nan
                elif scenario == 'normal': body.normals[0, 0] = np.inf
                elif scenario == 'zero_normal': body.normals[0] = 0.
                elif scenario == 'triangle': body.triangles[0, 0] = 1000
                elif scenario == 'negative_remap': body.vertex_remap = np.arange(25, dtype=np.int64); body.vertex_remap[0] = -1
                elif scenario == 'huge_remap': body.vertex_remap = np.arange(25, dtype=np.uint64); body.vertex_remap[0] = 2**40
                else: body.num_verts = 24
                with self.assertRaises(coverage.CoverageError): coverage.select_covered_vertices(body, [rectangle()], 2.)

    def test_nonunit_normals_are_normalized_without_mutation(self):
        body = grid(); body.normals *= .98; cloth = rectangle(); cloth.normals *= .99
        result = coverage.select_covered_vertices(body, [cloth], 2.)
        self.assertEqual(len(result['selected_remap_ids']), 25)
        np.testing.assert_array_equal(body.normals[:, 2], np.full(25, .98))

    def test_degenerate_body_face_is_not_covered_and_its_incident_vertices_are_excluded(self):
        body = grid(); body.triangles = np.vstack((body.triangles, [12, 12, 12]))
        result = coverage.select_covered_vertices(body, [rectangle()], 2.)
        self.assertNotIn(12, result['selected_vertex_indices'])
        self.assertEqual(result['body']['degenerate_triangles_not_covered'], 1)

    def test_work_budget_exhaustion_refuses_all_selection_and_preserves_inputs(self):
        body = grid(); before = body.positions.copy()
        with patch.dict(coverage.WORK_LIMITS, {'polygon_operations': 0}):
            with self.assertRaisesRegex(coverage.CoverageError, 'work limit'):
                coverage.select_covered_vertices(body, [rectangle()], 2.)
        np.testing.assert_array_equal(body.positions, before)

    def test_unbounded_mesh_generator_is_stopped_at_declared_cap(self):
        calls = []
        def clothes():
            while True:
                calls.append(1); yield rectangle()
        with patch.dict(coverage.WORK_LIMITS, {'clothing_meshes': 2}):
            with self.assertRaisesRegex(coverage.CoverageError, 'mesh count'):
                coverage.select_covered_vertices(grid(), clothes(), 2.)
        self.assertEqual(len(calls), 3)

    def test_no_clothing_produces_empty_selection_and_no_fabricated_coverage(self):
        result = coverage.select_covered_vertices(grid(), [])
        self.assertEqual(result['selected_remap_ids'], [])
        self.assertEqual(result['per_mesh'], [])
        self.assertEqual(result['state'], 'no_supported_static_covered_region')


if __name__ == '__main__':
    unittest.main()
