from pathlib import Path
import sys,types,unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from gmf_surface_verification import check_written_weights

def mesh(weights):return types.SimpleNamespace(name='M_Tights',num_verts=len(next(iter(weights.values()))),weights=weights)

class WrittenSurfaceTests(unittest.TestCase):
    def test_native_quantization_is_accepted(self):
        expected=mesh({'J_A':[.501,.199],'J_B':[.499,.801]})
        written=mesh({'J_A':[128/255,51/255],'J_B':[127/255,204/255]})
        self.assertEqual(check_written_weights(expected,written,{'J_A','J_B'})['vertices_checked'],2)
    def test_wrong_normalized_bone_weights_are_rejected(self):
        expected=mesh({'J_A':[.8],'J_B':[.2]});written=mesh({'J_A':[.2],'J_B':[.8]})
        with self.assertRaisesRegex(ValueError,'differ'):check_written_weights(expected,written,{'J_A','J_B'})
    def test_nonfinite_and_absent_bones_are_rejected(self):
        expected=mesh({'J_A':[1.]})
        with self.assertRaisesRegex(ValueError,'invalid'):check_written_weights(expected,mesh({'J_A':[np.nan]}),{'J_A'})
        with self.assertRaisesRegex(ValueError,'absent'):check_written_weights(mesh({'missing':[1.]}),mesh({'missing':[1.]}),{'J_A'})
    def test_budgets_and_eight_influences_are_checked(self):
        expected=mesh({'J_A':[1.035]})
        with self.assertRaisesRegex(ValueError,'normalized'):check_written_weights(expected,mesh({'J_A':[1.035]}),{'J_A'})
        names=['J_'+str(i) for i in range(9)];weights={n:[1/9] for n in names}
        with self.assertRaisesRegex(ValueError,'eight'):check_written_weights(mesh(weights),mesh(weights),set(names))
