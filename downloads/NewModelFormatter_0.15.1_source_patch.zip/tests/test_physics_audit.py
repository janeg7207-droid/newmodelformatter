"""Exposed physics evidence stays bounded, cautious and entirely read-only."""
from pathlib import Path
import struct
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import gmf_physics_audit as audit


def ycl(objects=('S_Hair',), joints=('Hair_01',), version=(1, 25)):
    def node(kind, head, body=b'', fields=b''):
        return struct.pack('<III', kind, head, head + len(body)) + fields.ljust(head - 12, b'\0') + body
    names = list(objects) + ['old_attire_name']
    def table(kind, values):
        children = b''
        for name in values:
            text = name.encode('ascii') + b'\0';text += bytes((-len(text)) % 4)
            children += node(24, 12, text)
        return node(kind, 20, children, struct.pack('<I', len(values)))
    nodes = [node(5, 24, fields=struct.pack('<III', len(names) - 1, i, 264)) for i in range(len(objects))]
    nodes += [table(23, names), table(25, joints)]
    body = b''.join(nodes)
    return struct.pack('<IIIIHHIII', 0, 32, 32 + len(body), len(nodes), *version, 0xffffffff, 0, 0) + body


def mesh_table(mid, declarations):
    data = b'MOD!' + struct.pack('<I', mid) + bytes(68) + struct.pack('<I', len(declarations))
    data += b''.join(name.encode('ascii').ljust(32, b'\0') for name, count in declarations)
    data += struct.pack('<I', len(declarations))
    data += b''.join(struct.pack('<III', i, 0, count) for i, (name, count) in enumerate(declarations))
    return data + bytes(8)


def ywa(suffix='.hair_ywa', render_count=6, name='M_Hair'):
    corrective = 'corr' in suffix
    render = [(name, render_count)];colliders = [('M_Head', 7), ('M_Body', 9)]
    first, second = (render, colliders) if corrective else (colliders, render)
    data = b'SIZ!' + struct.pack('<I', 4 if corrective else 3) + mesh_table(1, first) + mesh_table(2, second)
    if corrective:
        payload = b'MOD!' + struct.pack('<I', 6) + bytes(64)
        payload += struct.pack('<6I', 29, 1, 0, 0, render_count, render_count)
        payload += b''.join(struct.pack('<HBBBBHHH', i, 0, 255, 0, 0, 0, 1, 2) for i in range(render_count))
        payload += bytes(render_count)
    else:
        payload = b'MOD!' + struct.pack('<I', 4) + bytes(64)
        payload += struct.pack('<6I', 0, 1, 1, 0, 0, render_count) + bytes(36) + struct.pack('<I', render_count)
        payload += struct.pack('<' + 'H' * render_count, *range(render_count))
    # Opaque payload deliberately includes MOD!; no signature scan may treat it
    # as a new table or claim the undisclosed remainder has been validated.
    return data + payload + b'opaque MOD! not a framed table\0\0' + b'END!\0\0\0\0'


def mesh(name, count, remap=None):
    return SimpleNamespace(name=name, num_verts=count, vertex_remap=remap)


class PhysicsAuditTests(unittest.TestCase):
    def layout(self, root, suffixes=('.ycl', '.hair_ywa', '.hair_corr_ywa', '.other_ywa', '.other_corr_ywa'),
               hair_count=4, hair_remap=None, simulation=True, base=True):
        source = root / 'source';destination = root / 'output';output = destination / 'Characters' / '881_Test'
        character = source / '881_Test';attire_dir = character / '881_Default_Attire';target_dir = output / '881_Default_Attire'
        attire_dir.mkdir(parents=True);target_dir.mkdir(parents=True)
        src_model = attire_dir / '881_Attire.mcd';dst_model = target_dir / src_model.name
        src_model.write_bytes(b'original attire');dst_model.write_bytes(b'converted attire')
        rows = [{'source': str(src_model), 'output': str(dst_model), 'verify': 'pass'}]
        if base:
            src_base = character / 'BaseModel' / 'baseModel.mcd';dst_base = output / 'BaseModel' / src_base.name
            src_base.parent.mkdir();dst_base.parent.mkdir();src_base.write_bytes(b'original base');dst_base.write_bytes(b'converted base')
            rows.append({'source': str(src_base), 'output': str(dst_base), 'verify': 'pass'})
        for suffix in suffixes:
            data = ycl() if suffix == '.ycl' else ywa(suffix, name='M_Combinations' if 'other' in suffix else 'M_Hair') if suffix != '.wdf' else b'opaque WDF'
            src_model.with_suffix(suffix).write_bytes(data);dst_model.with_suffix(suffix).write_bytes(data)
        attire = SimpleNamespace(meshes=[mesh('M_Hair', hair_count, hair_remap), mesh('M_Combinations', 4)]
                                + ([mesh('S_Hair', 264)] if simulation else []), bones=[SimpleNamespace(name='Hair_01')])
        base_model = SimpleNamespace(meshes=[mesh('M_Head', 7), mesh('M_Body', 9)], bones=[SimpleNamespace(name='J_Head')])
        calls = []
        def read_model(path, with_shapes):
            self.assertFalse(with_shapes);calls.append(path)
            return base_model if Path(path).parent.name == 'BaseModel' else attire
        report = {'source': str(character), 'output': str(output), 'models': rows, 'problems': [], 'warnings': []}
        return character, destination, output, src_model, dst_model, report, SimpleNamespace(read_model=read_model), calls

    def run_audit(self, paths, **kwargs):
        return audit.process(paths[5], paths[0], paths[1], paths[6], **kwargs)

    def test_plain_ywa_fingerprinted_as_unknown_even_when_bytes_resemble_known_ywa(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=())
            raw=ywa('.hair_ywa')
            paths[3].with_suffix('.ywa').write_bytes(raw)
            paths[4].with_suffix('.ywa').write_bytes(raw)
            summary=self.run_audit(paths)
            self.assertEqual(len(summary['rows']),1)
            row=summary['rows'][0]
            self.assertEqual(row['state'],'not_audited')
            for side in ('source','output'):
                self.assertEqual(row[side+'_format']['unknown_suffix'],'.ywa')
                self.assertIn('format is unknown',row[side+'_format']['reason'])
                self.assertNotIn('render_declarations',row[side+'_format'])
            self.assertEqual(row['source_sha256'],audit._sha(raw))
            self.assertEqual(row['output_sha256'],audit._sha(raw))
            self.assertEqual(paths[7],[])
            self.assertTrue(summary['all_inspected_files_unchanged'])
            self.assertFalse(summary['physics_files_modified'])

    def test_plain_ywa_missing_output_is_not_decoded_or_claimed_delivered(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=())
            raw=b'unknown authored singular YWA'
            source=paths[3].with_suffix('.ywa');source.write_bytes(raw)
            summary=self.run_audit(paths);row=summary['rows'][0]
            self.assertEqual(row['source_format']['state'],'not_audited')
            self.assertIn('missing',row['output_format']['reason'])
            self.assertNotIn('delivery',row)
            self.assertEqual(source.read_bytes(),raw)
            self.assertFalse(paths[4].with_suffix('.ywa').exists())
            self.assertEqual(paths[7],[])

    def test_measured_ycl_versions_names_and_translation_are_separate_from_compatibility(self):
        for version in ((0, 1), (1, 25), (1, 26)):
            data = ycl(version=version);facts = audit.inspect_ycl(data)
            self.assertEqual(facts['state'], 'exposed_names_inspected')
            self.assertEqual(facts['joint_names'], ['Hair_01']);self.assertEqual(facts['objects'][0]['name'], 'S_Hair')
            self.assertEqual(facts['objects'][0]['model_name'], 'old_attire_name')
            self.assertEqual(facts['output_2k26_version_observed'], version == (1, 26))
            self.assertEqual(facts['compatibility'], 'not established')
            self.assertEqual(facts['objects'][0]['count_semantics'], 'not inferred')

    def test_unknown_malformed_ycl_versions_tables_and_indices_are_not_guessed(self):
        valid = ycl();samples = [b'bad', ycl(version=(2, 26)), valid[:-1]]
        for position, value in ((8, len(valid) + 4), (12, 0), (32 + 16, 99)):
            data = bytearray(valid);struct.pack_into('<I', data, position, value);samples.append(bytes(data))
        for data in samples:
            self.assertEqual(audit.inspect_ycl(data)['state'], 'not_audited')

    def test_four_contiguous_ywa_prefixes_and_maps_are_read_without_opaque_signature_scan(self):
        for suffix in audit.SUFFIXES[1:5]:
            data = ywa(suffix);facts = audit.inspect_ywa(data, suffix)
            self.assertEqual(facts['state'], 'exposed_declarations_inspected')
            self.assertEqual(facts['primary_indices']['maximum'], 5)
            self.assertTrue(facts['primary_indices']['exact_sequential'])
            self.assertFalse(facts['full_MOD_count_and_opaque_payloads_validated'])
            self.assertEqual(facts['compatibility'], 'not established')
            self.assertEqual(data, ywa(suffix))

    def test_bad_ywa_envelopes_counts_padding_names_and_nonsequential_maps_are_not_audited(self):
        valid = ywa();samples = [valid[:-1], b'unknown' + valid, valid.replace(b'END!', b'FAIL')]
        for position, value in ((4, 9), (8 + 76, 9999), (8 + 8, 1)):
            data = bytearray(valid);struct.pack_into('<I', data, position, value);samples.append(bytes(data))
        parsed = audit.inspect_ywa(valid, '.hair_ywa')
        _, pos = audit._mesh_table(valid, 8, 1, len(valid)-8);_, pos = audit._mesh_table(valid, pos, 2, len(valid)-8)
        data=bytearray(valid);struct.pack_into('<H',data,pos+136,5);samples.append(bytes(data))
        for data in samples:self.assertEqual(audit.inspect_ywa(data, '.hair_ywa')['state'], 'not_audited')

    def test_u16_count_and_ycl_node_or_byte_budgets_reject_before_large_allocations(self):
        for suffix in ('.hair_ywa','.hair_corr_ywa'):
            data=bytearray(ywa(suffix));_, second=audit._mesh_table(data,8,1,len(data)-8)
            _, payload=audit._mesh_table(data,second,2,len(data)-8)
            count_offset=(second-12) if 'corr' in suffix else payload-12
            struct.pack_into('<I',data,count_offset,65537)
            for offset in ((payload+88,payload+92) if 'corr' in suffix else (payload+92,payload+132)):
                struct.pack_into('<I',data,offset,65537)
            result=audit.inspect_ywa(bytes(data),suffix)
            self.assertEqual(result['state'],'not_audited');self.assertIn('u16',result['reason'])
        with patch.object(audit,'MAX_YCL_NODES',2):
            self.assertIn('node budget',audit.inspect_ycl(ycl())['reason'])
        with patch.object(audit,'MAX_YCL_BYTES',16):
            self.assertIn('byte limit',audit.inspect_ycl(ycl())['reason'])

    def test_inactive_or_sentinel_corrective_vertices_are_not_assumed_active_bindings(self):
        for inactive in (True,False):
            data=bytearray(ywa('.hair_corr_ywa'));_, second=audit._mesh_table(data,8,1,len(data)-8)
            _, payload=audit._mesh_table(data,second,2,len(data)-8)
            if inactive:data[payload+96+3:payload+96+6]=bytes(3)
            else:struct.pack_into('<H',data,payload+96+6,0xffff)
            self.assertEqual(audit.inspect_ywa(bytes(data),'.hair_corr_ywa')['state'],'not_audited')

    def test_exposed_indices_outside_both_render_and_remap_domains_are_visible(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name));before={p:p.read_bytes() for root in (paths[0],paths[2]) for p in root.rglob('*') if p.is_file()}
            summary=self.run_audit(paths)
            self.assertEqual(summary['model_reads'],4);self.assertEqual(len(paths[7]),4)
            row=next(r for r in summary['rows'] if r['file'].endswith('.hair_corr_ywa'))
            for side in ('source','output'):
                self.assertTrue(any('exposed vertex index range through 5' in p for p in row[side+'_bindings']['problems']))
            self.assertTrue(row['unchanged_source_declarations_against_output_models']['problems'])
            self.assertTrue(paths[5]['problems']);self.assertEqual(paths[5]['conversion_completeness'],'incomplete')
            self.assertTrue(summary['all_inspected_files_unchanged']);self.assertFalse(summary['physics_files_modified'])
            self.assertTrue(all(p.read_bytes()==data for p,data in before.items()))

    def test_explicit_larger_remap_domain_prevents_false_out_of_range_failure(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=('.hair_ywa',),hair_count=4,hair_remap=[0,1,2,5])
            row=self.run_audit(paths)['rows'][0]
            self.assertFalse(row['source_bindings']['problems'])
            self.assertTrue(any('count alone does not prove' in item for item in row['source_bindings']['warnings']))

    def test_sparse_large_remap_and_invalid_domains_are_bounded(self):
        domain = audit._domain(mesh('M_Hair', 2, [0, 0xffffffff]))
        self.assertFalse(domain['domain_dense']);self.assertEqual(domain['remap_maximum'], 0xffffffff)
        for count, remap in ((-1,None),(0,None),(3,[0,1]),(2,[0,-1]),(2,[0,.5])):
            with self.assertRaises(ValueError):audit._domain(mesh('M_Hair',count,remap))
        malformed=bytearray(ycl());struct.pack_into('<I',malformed,32+4,28);struct.pack_into('<I',malformed,32+8,24)
        self.assertEqual(audit.inspect_ycl(bytes(malformed))['state'],'not_audited')

    def test_absent_ycl_simulation_name_is_observed_without_claiming_solver_failure(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=('.ycl',),simulation=False)
            row=self.run_audit(paths)['rows'][0];binding=row['source_bindings']
            self.assertFalse(binding['problems']);self.assertEqual(binding['observations'][0]['model_reference_state'],'missing_model_reference')
            self.assertEqual(binding['observations'][0]['active_or_embedded_solver_semantics'],'not established')
            self.assertTrue(binding['warnings']);self.assertFalse(paths[5]['problems'])

    def test_missing_base_or_paired_attire_is_unavailable_not_a_missing_mesh_claim(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=('.hair_corr_ywa',),base=False)
            row=self.run_audit(paths)['rows'][0]
            colliders=[item for item in row['source_bindings']['observations'] if item['model_role']=='base']
            self.assertTrue(all(item['state']=='not_audited' and 'unavailable' in item['reason'] for item in colliders))
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=('.ycl',));paths[5]['models']=[]
            row=self.run_audit(paths)['rows'][0]
            self.assertEqual(row['source_bindings']['state'],'not_audited');self.assertFalse(paths[5]['problems'])

    def test_unknown_formats_and_no_physics_skip_all_native_model_reads(self):
        for suffixes in ((),('.wdf',),('.hair_ywa',)):
            with tempfile.TemporaryDirectory() as name:
                paths=self.layout(Path(name),suffixes=suffixes)
                if suffixes==('.hair_ywa',):
                    paths[3].with_suffix('.hair_ywa').write_bytes(b'unknown');paths[4].with_suffix('.hair_ywa').write_bytes(b'unknown')
                self.assertEqual(self.run_audit(paths)['model_reads'],0)
                self.assertFalse(paths[7])

    def test_unavailable_native_reader_is_cached_and_never_becomes_missing_mesh_claim(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name));attempts=[]
            class NativeFailure(Exception):pass
            def failing(path,with_shapes):
                attempts.append(path);raise NativeFailure('reader cannot expose this model')
            paths[6].read_model=failing
            summary=self.run_audit(paths)
            self.assertEqual(len(attempts),4);self.assertEqual(summary['model_reads'],4)
            self.assertTrue(all(row['source_bindings']['state']=='not_audited' and row['output_bindings']['state']=='not_audited' for row in summary['rows']))
            self.assertFalse(paths[5]['problems'])

    def test_duplicate_mesh_domains_are_unresolved_instead_of_selected_by_count(self):
        info=audit.inspect_ywa(ywa(),'.hair_ywa')
        models={'attire':SimpleNamespace(meshes=[mesh('M_Hair',4),mesh('M_Hair',6)],bones=[]),
                'base':SimpleNamespace(meshes=[mesh('M_Head',7),mesh('M_Body',9)],bones=[])}
        result=audit._binding(info,models)
        self.assertFalse(result['problems']);self.assertTrue(any('ambiguous' in p for p in result['warnings']))

    def test_normal_collider_declarations_do_not_claim_unread_index_bounds(self):
        info=audit.inspect_ywa(ywa(),'.hair_ywa')
        models={'attire':SimpleNamespace(meshes=[mesh('M_Hair',6)],bones=[]),
                'base':SimpleNamespace(meshes=[mesh('M_Head',7),mesh('M_Body',9)],bones=[])}
        result=audit._binding(info,models)
        rows=[r for r in result['observations'] if r['model_role']=='base']
        self.assertTrue(all(r['state']=='declarations_only_bounds_unverified' and r['declared_range_exceeds_both_exposed_domains'] is None for r in rows))

    def test_missing_ycl_joint_name_is_a_name_observation_without_numeric_rebasing(self):
        info=audit.inspect_ycl(ycl(joints=('Hair_old','null')))
        models={'attire':SimpleNamespace(meshes=[mesh('S_Hair',264)],bones=[SimpleNamespace(name='Hair_new')])}
        result=audit._binding(info,models)
        self.assertEqual(result['declared_joint_names_missing_from_available_rigs'],['Hair_old'])
        self.assertFalse(result['problems']);self.assertTrue(result['warnings'])

    def test_omitted_output_is_not_audited_but_authored_source_can_be_compared_to_real_target(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=('.hair_corr_ywa',));paths[4].with_suffix('.hair_corr_ywa').unlink()
            row=self.run_audit(paths)['rows'][0]
            self.assertEqual(row['output_format']['state'],'not_audited');self.assertEqual(row['output_bindings']['state'],'not_audited')
            self.assertTrue(row['unchanged_source_declarations_against_output_models']['problems'])
            self.assertNotIn('output_sha256',row)

    def test_mapped_slot_and_excluded_attire_rules_are_preserved(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=('.ycl',))
            old=paths[4].with_suffix('.ycl');new=old.with_name('999_Attire.ycl');old.rename(new)
            relative=new.relative_to(paths[2]).as_posix()
            row=self.run_audit(paths,mapped=lambda rel,plan:relative,plan={'chosen':'slot'})['rows'][0]
            self.assertEqual(row['output_sha256'],audit._sha(new.read_bytes()))
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name));summary=self.run_audit(paths,mapped=lambda rel,plan:None)
            self.assertEqual(summary['rows'],[]);self.assertEqual(summary['model_reads'],0)

    def test_symlink_escape_mapped_collision_and_overlap_are_refused_without_changes(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=('.ycl',));row=self.run_audit(paths,mapped=lambda rel,plan:'../escape.ycl')['rows'][0]
            self.assertEqual(row['state'],'not_audited')
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=('.ycl',));target=paths[4].with_suffix('.ycl');target.unlink();target.symlink_to(paths[3].with_suffix('.ycl'))
            with self.assertRaisesRegex(ValueError,'link into the source'):self.run_audit(paths)
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=('.ycl','.hair_ywa'))
            rows=self.run_audit(paths,mapped=lambda rel,plan:'collision.ycl')['rows']
            self.assertTrue(all(row['state']=='not_audited' and 'aliases' in row['reason'] for row in rows))
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name))
            with self.assertRaisesRegex(ValueError,'separate'):audit.process(paths[5],paths[0],paths[0],paths[6])

    def test_concurrent_file_mutation_invalidates_evidence_not_repaired_claim(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=('.ycl',));original=paths[6].read_model
            def mutation(path,with_shapes):
                paths[3].with_suffix('.ycl').write_bytes(b'changed externally')
                return original(path,with_shapes)
            paths[6].read_model=mutation
            summary=self.run_audit(paths)
            self.assertFalse(summary['all_inspected_files_unchanged']);self.assertEqual(summary['state'],'invalidated_by_concurrent_file_change')
            self.assertTrue(any('evidence invalidated' in p for p in paths[5]['problems']))

    def test_install_preserves_original_callable_order_mapping_and_checkpoints_once(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=('.ycl',));calls=[]
            def original(src,dst,log=lambda text:None,slot=None):
                calls.append('original');return paths[5]
            folder=SimpleNamespace(convert_folder=original,_mapped=lambda rel,plan:rel,_slot_plan=lambda src,slot:({}, {}, []))
            with patch('gmf_report.save_intermediate',side_effect=lambda report,dst:calls.append('checkpoint')):
                audit.install(folder,paths[6]);installed=folder.convert_folder;audit.install(folder,paths[6])
                self.assertIs(installed,folder.convert_folder)
                self.assertIs(folder.convert_folder(str(paths[0]),str(paths[1])),paths[5])
            self.assertEqual(calls,['original','checkpoint']);self.assertIn('physics_binding_audit',paths[5])

    def test_install_refuses_selected_root_alias_before_original_conversion(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=('.ycl',));alias=Path(name)/'alias';alias.symlink_to(paths[0]);calls=[]
            def original(src,dst,slot=None):calls.append(True);return paths[5]
            folder=SimpleNamespace(convert_folder=original,_mapped=lambda rel,plan:rel)
            audit.install(folder,paths[6])
            with self.assertRaisesRegex(ValueError,'folder aliases'):folder.convert_folder(str(alias),str(paths[1]))
            self.assertEqual(calls,[])

    def test_verified_embedded_wdf_delivery_is_not_labelled_an_omitted_sidecar_or_solver_pass(self):
        with tempfile.TemporaryDirectory() as name:
            paths=self.layout(Path(name),suffixes=('.wdf',));paths[4].with_suffix('.wdf').unlink()
            def frame(tag,payload):
                value=struct.pack('<II4s',4,len(payload),tag)+payload
                return value+bytes((-len(value))%4)
            payload=b'authored WDF payload delivered without a solver claim'
            model=b'MCD!'+frame(b'MDL!',b'bounded model')+frame(b'WDF!',payload)+frame(b'END!',b'')
            paths[4].write_bytes(model)
            paths[5]['physics_converted']=[{'source':str(paths[3].with_suffix('.wdf')),'output':str(paths[4]),
                'kind':'wrap_deformation_layout','embedded_tag':'WDF!','state':'authored_wdf_clone_lod_layout_restored',
                'source_wdf_sha256':audit._sha(paths[3].with_suffix('.wdf').read_bytes()),
                'output_model_sha256':audit._sha(model),'output_wdf_sha256':audit._sha(payload)}]
            row=self.run_audit(paths)['rows'][0]
            self.assertEqual(row['delivery']['state'],'embedded_payload_delivery_verified')
            self.assertEqual(row['output_sha256'],audit._sha(payload))
            self.assertEqual(row['delivery']['output_model_sha256'],audit._sha(model))
            self.assertNotIn('missing',row['output_format']['reason'])
            self.assertEqual(row['output_bindings']['state'],'not_audited');self.assertFalse(paths[7])
            self.assertEqual(paths[4].read_bytes(),model)

    def test_stale_ambiguous_wrong_model_or_missing_embedded_wdf_proof_is_refused(self):
        def frame(tag,payload):
            value=struct.pack('<II4s',4,len(payload),tag)+payload
            return value+bytes((-len(value))%4)
        for failure in ('stale_model','stale_payload','wrong_source','wrong_model','duplicate_record','duplicate_payload','missing_payload','bad_envelope'):
            with self.subTest(failure=failure),tempfile.TemporaryDirectory() as name:
                paths=self.layout(Path(name),suffixes=('.wdf',));paths[4].with_suffix('.wdf').unlink()
                payload=b'authored stream';streams=frame(b'WDF!',payload)
                if failure=='duplicate_payload':streams+=frame(b'WDF!',payload)
                if failure=='missing_payload':streams=b''
                model=b'MCD!'+frame(b'MDL!',b'bounded')+streams+frame(b'END!',b'')
                if failure=='bad_envelope':model=model[:-1]
                paths[4].write_bytes(model)
                record={'source':str(paths[3].with_suffix('.wdf')),'output':str(paths[4]),'embedded_tag':'WDF!',
                    'kind':'wrap_deformation_layout','state':'authored_wdf_clone_lod_layout_restored',
                    'source_wdf_sha256':audit._sha(paths[3].with_suffix('.wdf').read_bytes()),
                    'output_model_sha256':audit._sha(model),'output_wdf_sha256':audit._sha(payload)}
                if failure=='stale_model':record['output_model_sha256']='stale'
                elif failure=='stale_payload':record['output_wdf_sha256']='stale'
                elif failure=='wrong_source':record['source_wdf_sha256']='stale'
                elif failure=='wrong_model':record['output']=str(paths[4].with_name('other.mcd'))
                paths[5]['physics_converted']=[record,dict(record)] if failure=='duplicate_record' else [record]
                row=self.run_audit(paths)['rows'][0]
                self.assertEqual(row['state'],'not_audited');self.assertNotIn('delivery',row)
                self.assertEqual(paths[4].read_bytes(),model)


if __name__ == '__main__':
    unittest.main()
