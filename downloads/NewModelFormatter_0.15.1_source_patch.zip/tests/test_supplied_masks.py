"""Verify the exact supplied Bryan profile and its scoped original-writer path."""
import base64
import copy
import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import zlib

import gmf_embedded_masks as embedded
import gmf_supplied_masks as supplied
from test_embedded_masks import EmbeddedFixture
from test_mask_recovery import pure_mcd


class SuppliedFixture(EmbeddedFixture):
    def __init__(self, root):
        super().__init__(root)
        self.source_attire.substreams = []
        for mesh in self.source_base.meshes:
            mesh.num_verts = 12768 if mesh.name == 'M_Body' else 4375
            mesh.vertex_remap = list(range(mesh.num_verts))
        self.output_base = copy.deepcopy(self.source_base); self.output_base.version = 47
        self.body_limits.update(M_Body=12768, M_Head=4375)
        self.actual_fingerprint = embedded._fingerprint

    def profile_fingerprint(self, path):
        path = Path(path)
        if path in self.fingerprint_override:
            return self.fingerprint_override[path]
        recorded = {self.src_model: (supplied.MODEL_SHA256, supplied.MODEL_BYTES),
                    self.src_base: (supplied.BASE_SHA256, supplied.BASE_BYTES),
                    self.src_hpl: (supplied.INVALID_HPL_SHA256, supplied.INVALID_HPL_BYTES)}
        if path in recorded and path.exists() and path.read_bytes() == self.before[path]:
            return recorded[path]
        return self.actual_fingerprint(path)

    def run(self):
        # These digests are substituted ONLY for synthetic geometry fixtures;
        # actual runtime hashes real files and also validates its native pair.
        with mock.patch.object(embedded, '_fingerprint', self.profile_fingerprint):
            return super().run()


class SuppliedMaskTests(unittest.TestCase):
    def test_payload_is_exact_supplied_original_mask_and_writer_preserves_arrays(self):
        data = supplied.supplied_hpl()
        self.assertEqual(len(data), 67580)
        self.assertEqual(hashlib.sha256(data).hexdigest(), '3c4b880b325f1f424d8d0b8dae88f9f38d7263751b23654d2906fa6123dc00be')
        mcd = pure_mcd(); self.assertTrue(mcd.hpl_is_whole(data))
        parsed = mcd.parse_hpl(data)
        self.assertEqual(set(parsed), {0, 1}); self.assertEqual(parsed[0], parsed[1])
        self.assertEqual(set(parsed[0]), {0, 1})
        for groups in parsed[0].values():
            self.assertEqual([(name, len(ids)) for name, ids in groups], [('M_Body', 4215)])
            self.assertTrue(all(0 <= index < 12768 for _, ids in groups for index in ids))
        written = mcd.parse_hpl(mcd.build_hpl(parsed[0]))
        self.assertEqual(set(written), set(range(5)))
        self.assertTrue(all(flags == parsed[0] for flags in written.values()))

    def test_payload_integrity_rejects_modified_bytes(self):
        changed = supplied.supplied_hpl()[:-1] + b'X'
        with mock.patch.object(supplied, '_PAYLOAD', base64.b85encode(zlib.compress(changed))):
            with self.assertRaisesRegex(ValueError, 'integrity check'): supplied.supplied_hpl()

    def test_exact_model_base_and_bad_sidecar_are_all_required(self):
        fingerprints = [(supplied.MODEL_SHA256, supplied.MODEL_BYTES),
                        (supplied.BASE_SHA256, supplied.BASE_BYTES),
                        (supplied.INVALID_HPL_SHA256, supplied.INVALID_HPL_BYTES)]
        self.assertIsNotNone(supplied.select_profile(*fingerprints))
        for which in range(3):
            for replacement in (None, ('0'*64, fingerprints[which][1]),
                                (fingerprints[which][0], fingerprints[which][1]+1)):
                with self.subTest(which=which, replacement=replacement):
                    args = fingerprints.copy(); args[which] = replacement
                    self.assertIsNone(supplied.select_profile(*args))

    def test_scoped_profile_uses_original_parser_writer_verifier_without_source_changes(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = SuppliedFixture(Path(tmp)); report = f.run()
            record = report['models'][1]['supplied_hide_mask_recovery']
            self.assertEqual(record['profile'], supplied.PROFILE_VERSION)
            self.assertEqual(record['method'], 'verified_original_user_supplied_hpl_through_original_parser_filter_writer')
            self.assertEqual(record['source_supplied_hpl_sha256'], supplied.SUPPLIED_HPL_SHA256)
            self.assertEqual(record['source_invalid_sidecar_sha256'], supplied.INVALID_HPL_SHA256)
            self.assertNotIn('source_embedded_hpl_sha256', record)
            self.assertNotIn('embedded_hide_mask_recovery', report['models'][1])
            self.assertFalse(record['coverage_generated']); self.assertTrue(report['verification'][0])
            self.assertEqual(report['verification'][2]['hide_mask'], 'mask')
            self.assertIn('supplied_hide_mask_recovery', report['verification'][2])
            self.assertEqual(f.streams, [(b'HPL!', f.mcd.build_hpl(f.mcd.parse_hpl(supplied.supplied_hpl())[0]))])
            self.assertEqual({p: p.read_bytes() for p in f.before}, f.before)
            self.assertIs(f.original_namespace['expected_mask'], f.original_expected)
            self.assertEqual(f.module.expected_mask(str(f.src_hpl), {}, f.body_limits)[1], 'unreadable')

    def test_nonmatching_model_base_mask_or_missing_sidecar_cannot_recover(self):
        for mode in ('model', 'base', 'mask', 'missing'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                f = SuppliedFixture(Path(tmp))
                if mode == 'missing': f.src_hpl.unlink()
                else:
                    path = {'model': f.src_model, 'base': f.src_base, 'mask': f.src_hpl}[mode]
                    f.fingerprint_override[path] = ('0'*64, path.stat().st_size)
                report = f.run()
                self.assertNotIn('supplied_hide_mask_recovery', report['models'][1])
                self.assertEqual(f.streams, [(b'HPL!', f.mcd.EMPTY_HPL)])

    def test_failed_unrun_or_changed_base_mapping_blocks_supplied_mask(self):
        for mode in ('failed', 'unrun', 'remap'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                f = SuppliedFixture(Path(tmp))
                if mode == 'failed': f.base_verify_failure = True
                elif mode == 'unrun': f.skip_base_verification = True
                else: f.output_base.meshes[0].vertex_remap.reverse()
                report = f.run()
                self.assertNotIn('supplied_hide_mask_recovery', report['models'][1])

    def test_matching_topology_with_a_missing_actual_mask_index_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = SuppliedFixture(Path(tmp))
            index = f.mcd.parse_hpl(supplied.supplied_hpl())[0][0][0][1][0]
            for model in (f.source_base, f.output_base):
                mesh = next(mesh for mesh in model.meshes if mesh.name == 'M_Body')
                mesh.vertex_remap[index] = (index+1) % mesh.num_verts
            self.assertNotIn('supplied_hide_mask_recovery', f.run()['models'][1])

    def test_readable_embedded_mask_has_precedence_over_supplied_profile(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = SuppliedFixture(Path(tmp)); f.source_attire.substreams = [(b'HPL!', f.mask)]
            report = f.run()
            self.assertIn('embedded_hide_mask_recovery', report['models'][1])
            self.assertNotIn('supplied_hide_mask_recovery', report['models'][1])
            self.assertEqual(f.streams, [(b'HPL!', f.mask)])

    def test_readable_or_intentional_empty_sidecar_and_native_inputs_are_unchanged(self):
        for mode in ('readable', 'empty', 'native'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                f = SuppliedFixture(Path(tmp))
                if mode == 'readable': f.src_hpl.write_bytes(f.mask)
                elif mode == 'empty': f.src_hpl.write_bytes(f.mcd.EMPTY_HPL)
                else: f.source_attire.version = 47
                report = f.run()
                self.assertNotIn('supplied_hide_mask_recovery', report['models'][1])


if __name__ == '__main__': unittest.main()
