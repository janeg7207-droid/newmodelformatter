"""Independent format/closure checks for old 2K26 port recovery."""
from pathlib import Path
import hashlib,os,struct,sys,tempfile,types,unittest
from unittest import mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import gmf_2k26_repair as native
import gmf_native_assets as assets
import gmf_native_masks as masks
import gmf_jmtl_audit as jmtl
import gmf_2k26_audit as audit
from test_2k26_repair import writer
from test_mask_recovery import pure_mcd


def material(shader=0x15,refs=None):
    """Author a small FlatBuffer by hand, independently of production parser."""
    refs=refs or {};slots=max(refs,default=0)+1
    size=8+8*len(refs);data=bytearray(128+size)
    struct.pack_into('<I4s',data,0,20,b'Mate')
    struct.pack_into('<HHHHH',data,10,10,12,0,6,8)
    struct.pack_into('<i',data,20,10);struct.pack_into('<H',data,26,shader);struct.pack_into('<I',data,28,100)
    struct.pack_into('<HH',data,36,4+slots*2,size);struct.pack_into('<i',data,128,92)
    for i,(field,value) in enumerate(sorted(refs.items())):
        struct.pack_into('<H',data,40+field*2,8+i*8);struct.pack_into('<Q',data,136+i*8,value)
    return bytes(data)


def dds():
    data=bytearray(144);data[:4]=b'DDS '
    struct.pack_into('<IIIIIII',data,4,124,0x81007,4,4,16,0,1)
    struct.pack_into('<II4s',data,76,32,4,b'DXT5');struct.pack_into('<I',data,108,0x1000)
    return bytes(data)


class MaterialDependencyTests(unittest.TestCase):
    def tree(self,tmp):
        root=Path(tmp);source=root/'input'/'100_Test';output=root/'output'/'Characters'/'100_Test'
        source_model=source/'100_Default_Attire'/'100_Attire.mcd';target=output/'100_Default_Attire'/'100_Attire.mcd'
        (source_model.parent/'Materials').mkdir(parents=True);target.parent.mkdir(parents=True)
        source_model.write_bytes(b'native model');target.write_bytes(b'native model')
        return source,output,source_model,target

    def test_bounded_jmtl_reader_extracts_actual_refs_and_preserves_bytes(self):
        data=material(refs={9:123,12:456});before=data
        parsed=jmtl.inspect_material(data)
        self.assertEqual(parsed['shader_byte'],0x15)
        self.assertEqual(parsed['texture_references'],[{'field':'colorMap@ref','hash':123},{'field':'nrMap@ref','hash':456}])
        self.assertEqual(data,before)

    def test_truncated_or_bad_tables_are_rejected(self):
        data=material(refs={9:123})
        broken=bytearray(data);struct.pack_into('<I',broken,28,0xfffffff0)
        for value in [b'opaque shader',data[:-1],bytes(broken)]:
            with self.assertRaises(ValueError):jmtl.inspect_material(value)

    def test_procedural_hair_has_no_invented_color_texture(self):
        parsed=jmtl.inspect_material(material(0x16))
        self.assertEqual(parsed['hair_type'],1);self.assertEqual(parsed['texture_references'],[])

    def test_library_serialization_matches_supplied_reference_writer(self):
        path='Characters/100_Test/100_Default_Attire/100_Attire.mtls';names=['hair_alpha','shoes','body']
        entries=[{'name':name,'path_hash':native.path_hash('Characters/100_Test/100_Default_Attire/Materials/'+name+'.jmtl')} for name in names]
        self.assertEqual(assets.write_library(entries),writer.write_mtls(names,path))

    def test_missing_mtls_restored_only_from_actual_valid_jmtl(self):
        with tempfile.TemporaryDirectory() as tmp:
            source,output,model,target=self.tree(tmp);payload=material();shader=model.parent/'Materials'/'hair_ALPHA.jmtl';shader.write_bytes(payload)
            index=assets.AssetIndex(source,output)
            result=assets.recover_materials(model,target,{'hair_alpha'},index)
            self.assertTrue(result['complete']);self.assertEqual(result['findings'],[])
            self.assertEqual(native.read_native_library(target.with_suffix('.mtls').read_bytes())[0]['name'],'hair_alpha')
            self.assertEqual((target.parent/'Materials'/'hair_ALPHA.jmtl').read_bytes(),payload)
            self.assertEqual(shader.read_bytes(),payload);self.assertFalse(model.with_suffix('.mtls').exists())

    def test_missing_shader_does_not_generate_material_defaults_or_partial_table(self):
        with tempfile.TemporaryDirectory() as tmp:
            source,output,model,target=self.tree(tmp)
            result=assets.recover_materials(model,target,{'beard'},assets.AssetIndex(source,output))
            self.assertFalse(result['complete']);self.assertFalse(target.with_suffix('.mtls').exists())
            self.assertEqual({f['state'] for f in result['findings']},{'missing_material_definition','missing_mtls'})

    def test_missing_entry_is_added_without_dropping_existing_reference(self):
        with tempfile.TemporaryDirectory() as tmp:
            source,output,model,target=self.tree(tmp)
            (model.parent/'Materials'/'body.jmtl').write_bytes(material(0x19))
            (model.parent/'Materials'/'beard.jmtl').write_bytes(material(0x16))
            data=writer.write_mtls(['body'],'Characters/100_Test/100_Default_Attire/100_Attire.mtls');model.with_suffix('.mtls').write_bytes(data)
            result=assets.recover_materials(model,target,{'body','beard'},assets.AssetIndex(source,output))
            self.assertTrue(result['complete'])
            self.assertEqual([e['name'] for e in native.read_native_library(target.with_suffix('.mtls').read_bytes())],['body','beard'])
            self.assertEqual(model.with_suffix('.mtls').read_bytes(),data)

    def test_case_collision_or_invalid_jmtl_never_rebuilds_table(self):
        for case in ['collision','invalid']:
            with self.subTest(case=case),tempfile.TemporaryDirectory() as tmp:
                source,output,model,target=self.tree(tmp)
                (model.parent/'Materials'/'hair_ALPHA.jmtl').write_bytes(material() if case=='collision' else b'invalid')
                if case=='collision':(model.parent/'Materials'/'hair_alpha.jmtl').write_bytes(material())
                result=assets.recover_materials(model,target,{'hair_alpha'},assets.AssetIndex(source,output))
                self.assertFalse(result['complete']);self.assertFalse(target.with_suffix('.mtls').exists())

    def test_unsupported_table_is_preserved_and_reported_not_rewritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            source,output,model,target=self.tree(tmp);data=b'MTLs'+struct.pack('<I',6)+b'unsupported inline payload'
            model.with_suffix('.mtls').write_bytes(data)
            result=assets.recover_materials(model,target,{'body'},assets.AssetIndex(source,output))
            self.assertEqual(result['format'],'unsupported_or_inline_layout')
            self.assertEqual(target.with_suffix('.mtls').read_bytes(),data)

    def test_referenced_texture_recovered_by_exact_hash_even_when_generic_copy_off(self):
        with tempfile.TemporaryDirectory() as tmp:
            source,output,model,target=self.tree(tmp);texture=model.parent/'Textures'/'shoes_color.dds';texture.parent.mkdir();texture.write_bytes(dds())
            value=native.path_hash('Characters/100_Test/100_Default_Attire/Textures/shoes_color.tex')
            index=assets.AssetIndex(source,output)
            result=assets.recover_textures([{'binding':'shoes','output':'shoes.jmtl','texture_references':[{'field':'colorMap@ref','hash':value}]}],index)
            self.assertEqual(result[0]['state'],'present_or_recovered');self.assertTrue(result[0]['files'][0]['recovered'])
            self.assertEqual(index.target(texture).read_bytes(),texture.read_bytes())

    def test_unresolved_hash_does_not_guess_from_matching_texture_filename(self):
        with tempfile.TemporaryDirectory() as tmp:
            source,output,model,target=self.tree(tmp);texture=model.parent/'Textures'/'shoes_color.dds';texture.parent.mkdir();texture.write_bytes(dds())
            index=assets.AssetIndex(source,output)
            result=assets.recover_textures([{'binding':'shoes','output':'shoes.jmtl','texture_references':[{'field':'colorMap@ref','hash':1}]}],index)
            self.assertEqual(result[0]['state'],'unresolved_external_or_missing_texture')
            self.assertFalse(index.target(texture).exists())

    def test_output_symlink_cannot_redirect_recovery_into_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            source,output,model,target=self.tree(tmp);shader=model.parent/'Materials'/'hair.jmtl';shader.write_bytes(material())
            (target.parent/'Materials').symlink_to(model.parent/'Materials',target_is_directory=True)
            with self.assertRaisesRegex(ValueError,'separate output'):assets.recover_materials(model,target,{'hair'},assets.AssetIndex(source,output))


def container(mask=None):
    frames=[(b'MDL!',b'MDL!'+struct.pack('<I',47)+b'original geometry weights shapes'),(b'CTG!',b'unchanged attachments')]
    if mask is not None:frames.append((b'HPL!',mask))
    frames.append((b'END!',b''));data=bytearray(b'MCD!')
    for tag,payload in frames:
        data.extend(struct.pack('<II4s',4,len(payload),tag)+payload)
        if tag!=b'END!':data.extend(bytes((-len(data))%4))
    return bytes(data)


class NativeMaskRecoveryTests(unittest.TestCase):
    def test_splice_keeps_every_nonmask_substream_byte_identical(self):
        mcd=pure_mcd();mask=mcd.build_hpl({0:[('M_Body',[0,2])],1:[('M_Body',[0,2])]})
        for original in [container(),container(b'HPL!END!\0\0\0\0')]:
            changed=masks.splice_mask(original,mask)
            before=[(f['tag'],f['payload']) for f in masks.envelopes(original) if f['tag']!=b'HPL!']
            after=[(f['tag'],f['payload']) for f in masks.envelopes(changed) if f['tag']!=b'HPL!']
            self.assertEqual(before,after)

    def test_truncated_envelopes_never_look_like_repairable_mask(self):
        for data in [container()[:-1],b'MDL!raw file',container()+b'extra']:
            with self.assertRaises(ValueError):masks.splice_mask(data,b'HPL!')

    def fixture(self,root,ids):
        source=root/'input'/'100_Test'/'100_Default_Attire'/'100_Attire.mcd';target=root/'output'/'Characters'/'100_Test'/'100_Default_Attire'/'100_Attire.mcd'
        source.parent.mkdir(parents=True);target.parent.mkdir(parents=True);data=container(b'HPL!END!\0\0\0\0');source.write_bytes(data);target.write_bytes(data)
        srcbase=source.parent.parent/'BaseModel'/'baseModel.mcd';dstbase=target.parent.parent/'BaseModel'/'baseModel.mcd'
        for path in [srcbase,dstbase]:path.parent.mkdir();path.write_bytes(b'identical native base')
        mcd=pure_mcd();supplied=mcd.build_hpl({0:[('M_Body',ids)],1:[('M_Body',ids)]});source.with_suffix('.hpl').write_bytes(supplied)
        body=types.SimpleNamespace(name='M_Body',num_verts=3,vertex_remap=[0,1,2])
        def read(path,**kwargs):
            if Path(path)==dstbase:return types.SimpleNamespace(version=47,meshes=[body])
            return types.SimpleNamespace(version=47,substreams=[(f['tag'],f['payload']) for f in masks.envelopes(Path(path).read_bytes()) if f['tag'] not in (b'MDL!',b'END!')])
        folder=types.SimpleNamespace(mcd=mcd,vc=types.SimpleNamespace(read_model=read))
        return source,target,folder,read(target),data

    def test_valid_sidecar_restores_embedded_mask_without_reweighting(self):
        with tempfile.TemporaryDirectory() as tmp:
            src,dst,folder,model,before=self.fixture(Path(tmp),[0,2]);sidecar=src.with_suffix('.hpl').read_bytes()
            result=masks.audit_mask(src,dst,model,folder)
            self.assertEqual(result['state'],'recovered_from_matching_sidecar')
            self.assertEqual(src.read_bytes(),before);self.assertEqual(src.with_suffix('.hpl').read_bytes(),sidecar)
            self.assertTrue(result['repairs'][0]['model_and_other_substreams_byte_identical'])

    def test_invalid_indices_or_different_pair_does_not_recover(self):
        for case in ['ids','pair']:
            with self.subTest(case=case),tempfile.TemporaryDirectory() as tmp:
                src,dst,folder,model,before=self.fixture(Path(tmp),[99] if case=='ids' else [0,2])
                if case=='pair':(dst.parent.parent/'BaseModel'/'baseModel.mcd').write_bytes(b'different base')
                result=masks.audit_mask(src,dst,model,folder)
                self.assertFalse(result['repairs']);self.assertEqual(dst.read_bytes(),before)

    def test_absent_sidecar_does_not_create_whole_body_mask(self):
        with tempfile.TemporaryDirectory() as tmp:
            src,dst,folder,model,before=self.fixture(Path(tmp),[0,2]);src.with_suffix('.hpl').unlink()
            result=masks.audit_mask(src,dst,model,folder)
            self.assertEqual(result['state'],'empty_missing_or_invalid_mask');self.assertEqual(result['repairs'],[])
            self.assertEqual(dst.read_bytes(),before)

    def test_existing_valid_mask_is_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            src,dst,folder,model,before=self.fixture(Path(tmp),[0,2]);good=src.with_suffix('.hpl').read_bytes();dst.write_bytes(masks.splice_mask(before,good))
            model=folder.vc.read_model(str(dst));before=dst.read_bytes();result=masks.audit_mask(src,dst,model,folder)
            self.assertEqual(result['state'],'readable_indices_valid');self.assertEqual(result['repairs'],[]);self.assertEqual(dst.read_bytes(),before)


class AuditGuardTests(unittest.TestCase):
    def test_failed_native_record_cannot_repair_a_stale_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source=root/'source';source.mkdir();output=root/'output'/'Characters';output.mkdir(parents=True);stale=output/'old.mcd';stale.write_bytes(b'stale output')
            record={'source_version':47,'status':'failed_native_2k26','source':str(source/'input.mcd'),'output':str(stale)}
            report={'source':str(source),'output':str(output),'models':[record]};reader=mock.Mock(side_effect=AssertionError('must not read stale output'))
            audit.process(report,types.SimpleNamespace(vc=types.SimpleNamespace(read_model=reader)),source,lambda _:None)
            reader.assert_not_called();self.assertEqual(stale.read_bytes(),b'stale output')

    def test_no_native_inputs_does_not_scan_asset_tree(self):
        report={'models':[{'source_version':41}]}
        with mock.patch.object(audit,'AssetIndex',side_effect=AssertionError('not needed')):audit.process(report,None,'unused',lambda _:None)
        self.assertEqual(report['native_2k26_missing_data_check']['state'],'not_applicable_no_native_inputs')
