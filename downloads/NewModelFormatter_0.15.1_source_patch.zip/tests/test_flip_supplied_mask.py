"""Exact authored Flip mask data and guarded existing-writer integration."""
import base64
import copy
import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import zlib

import gmf_embedded_masks as embedded
import gmf_supplied_masks as supplied
import gmf_flip_supplied_mask as flip
from test_embedded_masks import EmbeddedFixture
from test_mask_recovery import pure_mcd


class FlipFixture(EmbeddedFixture):
    def __init__(self, root):
        super().__init__(root)
        self.source_attire.substreams = []
        for mesh in self.source_base.meshes:
            mesh.num_verts = 12755 if mesh.name == 'M_Body' else 4382
            mesh.vertex_remap = list(range(mesh.num_verts))
        self.output_base = copy.deepcopy(self.source_base)
        self.output_base.version = 47
        self.body_limits.update(M_Body=12755, M_Head=4382)
        self.actual_fingerprint = embedded._fingerprint

    def profile_fingerprint(self, path):
        path = Path(path)
        if path in self.fingerprint_override:
            return self.fingerprint_override[path]
        expected = {self.src_model: (flip.MODEL_SHA256, flip.MODEL_BYTES),
                    self.src_base: (flip.BASE_SHA256, flip.BASE_BYTES),
                    self.src_hpl: (flip.INVALID_HPL_SHA256, flip.INVALID_HPL_BYTES)}
        if path in expected and path.exists() and path.read_bytes() == self.before[path]:
            return expected[path]
        return self.actual_fingerprint(path)

    def run(self):
        # Only synthetic test bytes receive substituted fingerprints. Production
        # hashes the native user files and verifies actual output remap/topology.
        with mock.patch.object(embedded, '_fingerprint', self.profile_fingerprint):
            return super().run()


class FlipSuppliedMaskTests(unittest.TestCase):
    def test_lossless_supplied_bytes_whole_flags_and_actual_domains(self):
        data = flip.supplied_hpl()
        self.assertEqual(len(data), 70188)
        self.assertEqual(hashlib.sha256(data).hexdigest(),
                         '8a280ab3add1727a763796e9556d7a99b55cfae8ead98448fc82fd2183b927fc')
        mcd = pure_mcd()
        self.assertTrue(mcd.hpl_is_whole(data))
        parsed = mcd.parse_hpl(data)
        self.assertEqual(set(parsed), {0, 1})
        self.assertEqual(parsed[0], parsed[1])
        self.assertEqual(set(parsed[0]), {0, 1})
        for groups in parsed[0].values():
            self.assertEqual([name for name, ids in groups], ['M_Body'])
            ids = groups[0][1]
            self.assertEqual(len(ids), 4378)
            self.assertEqual(len(set(ids)), 4378)
            self.assertEqual((min(ids), max(ids)), (1016, 12754))
            self.assertTrue(all(0 <= index < 12755 for index in ids))
        written = mcd.parse_hpl(mcd.build_hpl(parsed[0]))
        self.assertEqual(set(written), set(range(5)))
        self.assertTrue(all(flags == parsed[0] for flags in written.values()))

    def test_payload_integrity_rejects_modified_authored_bytes(self):
        bad = flip.supplied_hpl()[:-1] + b'X'
        with mock.patch.object(flip, '_PAYLOAD', base64.b85encode(zlib.compress(bad))):
            with self.assertRaisesRegex(ValueError, 'integrity check'):
                flip.supplied_hpl()

    def test_all_three_fingerprints_required_even_with_same_numeric_slot(self):
        values = [(flip.MODEL_SHA256, flip.MODEL_BYTES),
                  (flip.BASE_SHA256, flip.BASE_BYTES),
                  (flip.INVALID_HPL_SHA256, flip.INVALID_HPL_BYTES)]
        selected = supplied.select_profile(*values)
        self.assertEqual(selected['profile'], flip.PROFILE_VERSION)
        for which in range(3):
            for replacement in (None, ('0' * 64, values[which][1]),
                                (values[which][0], values[which][1] + 1)):
                with self.subTest(which=which, replacement=replacement):
                    changed = values.copy()
                    changed[which] = replacement
                    self.assertIsNone(supplied.select_profile(*changed))

    def test_scoped_original_parser_filter_writer_verifier_preserve_sources(self):
        with tempfile.TemporaryDirectory() as tmp:
            fixture = FlipFixture(Path(tmp))
            report = fixture.run()
            record = report['models'][1]['supplied_hide_mask_recovery']
            self.assertEqual(record['profile'], flip.PROFILE_VERSION)
            self.assertEqual(record['source_supplied_hpl_sha256'], flip.SUPPLIED_HPL_SHA256)
            self.assertEqual(record['source_invalid_sidecar_sha256'], flip.INVALID_HPL_SHA256)
            self.assertFalse(record['coverage_generated'])
            self.assertNotIn('embedded_hide_mask_recovery', report['models'][1])
            self.assertTrue(report['verification'][0])
            expected = fixture.mcd.build_hpl(fixture.mcd.parse_hpl(flip.supplied_hpl())[0])
            self.assertEqual(fixture.streams, [(b'HPL!', expected)])
            self.assertEqual({path: path.read_bytes() for path in fixture.before}, fixture.before)
            self.assertEqual(fixture.module.expected_mask(str(fixture.src_hpl), {}, fixture.body_limits)[1], 'unreadable')

    def test_failed_or_changed_paired_base_and_missing_actual_domain_id_reject(self):
        for mode in ('failed', 'unrun', 'remap', 'missing_domain'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                f = FlipFixture(Path(tmp))
                if mode == 'failed':
                    f.base_verify_failure = True
                elif mode == 'unrun':
                    f.skip_base_verification = True
                elif mode == 'remap':
                    f.output_base.meshes[0].vertex_remap.reverse()
                else:
                    index = f.mcd.parse_hpl(flip.supplied_hpl())[0][0][0][1][0]
                    for model in (f.source_base, f.output_base):
                        body = next(mesh for mesh in model.meshes if mesh.name == 'M_Body')
                        body.vertex_remap[index] = (index + 1) % body.num_verts
                self.assertNotIn('supplied_hide_mask_recovery', f.run()['models'][1])

    def test_current_readable_empty_embedded_masks_and_native_inputs_win(self):
        for mode in ('readable', 'empty', 'embedded', 'native'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                f = FlipFixture(Path(tmp))
                if mode == 'readable':
                    f.src_hpl.write_bytes(f.mask)
                elif mode == 'empty':
                    f.src_hpl.write_bytes(f.mcd.EMPTY_HPL)
                elif mode == 'embedded':
                    f.source_attire.substreams = [(b'HPL!', f.mask)]
                else:
                    f.source_attire.version = 47
                report = f.run()
                self.assertNotIn('supplied_hide_mask_recovery', report['models'][1])
                if mode == 'embedded':
                    self.assertIn('embedded_hide_mask_recovery', report['models'][1])

    def test_missing_or_changed_bad_sidecar_never_invokes_profile(self):
        for mode in ('missing', 'changed'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                f = FlipFixture(Path(tmp))
                if mode == 'missing':
                    f.src_hpl.unlink()
                else:
                    f.src_hpl.write_bytes(b'HPL!unrecognized bad mask')
                self.assertNotIn('supplied_hide_mask_recovery', f.run()['models'][1])


if __name__ == '__main__':
    unittest.main()
