"""Universal output coverage must report dependencies without guessing game assets."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gmf_face_audit as audit
from gmf_2k26_repair import path_hash
from gmf_native_assets import write_library
from test_local_textures import dds
from test_native_missing_data import material


def game_folder(directory):
    parts = Path(directory).parts
    for i, part in enumerate(parts):
        if part.casefold() == 'characters': return '/'.join(parts[i:])
    return None


def mesh(name='M_EYE', bindings=None):
    return types.SimpleNamespace(name=name, num_verts=3,
        positions=np.array([[0., 0., 0.], [1., 0., 0.], [0., 1., 0.]]),
        triangles=np.array([[0, 1, 2]], dtype=np.int32),
        uvs=[np.array([[0., 0.], [1., 0.], [0., 1.]])],
        normals=np.array([[0., 0., 1.]] * 3), tangents=np.array([[1., 0., 0., 1.]] * 3),
        face_groups=bindings or [('eye_l:skinned', 0, 1)])


def model(meshes=None, anchors=True):
    meshes = meshes or [mesh()]
    return types.SimpleNamespace(version=47, meshes=meshes,
        goto_points=[('_ag_%04d' % i, meshes[0].name, i, i % meshes[0].num_verts) for i in range(13)] if anchors else [])


class Tree:
    def __init__(self, root, mod='159_Bryan_Danielson', meshes=None, anchors=True):
        self.root = root / 'output'; self.character = self.root / 'Characters' / mod
        self.target = self.character / 'BaseModel' / 'baseModel.mcd'
        self.target.parent.mkdir(parents=True); self.target.write_bytes(b'fixture native output bytes')
        self.model = model(meshes, anchors); self.models = {str(self.target): self.model}
        self.folder = types.SimpleNamespace(vc=types.SimpleNamespace(read_model=lambda path: self.models[str(Path(path))]),
                                            materials=types.SimpleNamespace(game_folder=game_folder))
        self.record = {'source': str(root / 'input' / mod / 'BaseModel' / 'baseModel.mdl'),
            'output': str(self.target), 'status': 'converted', 'source_version': '0x28', 'verify': 'pass'}
        self.report = {'source': str(root / 'input'), 'output': str(self.root),
                       'models': [self.record], 'materials': [], 'problems': [], 'warnings': []}
        self.entries = []

    def shader(self, name, shader=0x12, color=123, normal=audit.SHARED_EYE_NORMAL, *, local_entry=True, include_payload=True):
        path = self.target.parent / 'Materials' / (name + '.jmtl')
        virtual = game_folder(path.parent) + '/' + path.name
        self.entries.append({'name': name, 'path_hash': path_hash(virtual) if local_entry else 0x1234567})
        if include_payload:
            path.parent.mkdir(exist_ok=True)
            slots = {0: color, 3 if shader == 0x12 else 1: normal}
            path.write_bytes(material(shader, slots))
        self.target.with_suffix('.mtls').write_bytes(write_library(self.entries))
        return path

    def texture(self, stem='eye_color', copied=False):
        path = self.target.parent / 'Textures' / (stem + '.dds'); path.parent.mkdir(exist_ok=True)
        raw = dds(); path.write_bytes(raw); value = path_hash(game_folder(path.parent) + '/' + stem + '.tex')
        if copied:
            self.report['materials'].append({'local_texture_bindings': [
                {'output': str(path), 'output_sha256': hashlib.sha256(raw).hexdigest()}]})
        return value, path

    def run(self):
        before = {p: p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
        audit.process(self.report, self.folder)
        self.assert_unchanged = all(p.read_bytes() == raw for p, raw in before.items())
        return self.record['face_output_audit']


class FaceOutputAuditTests(unittest.TestCase):
    def test_current_copied_local_eye_texture_is_verified_without_claiming_game_resolution(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp)); value, _ = tree.texture(copied=True); tree.shader('eye_l', color=value)
            result = tree.run(); row = result['materials'][0]
            self.assertEqual(row['face_texture_check']['color_ref'], value)
            self.assertEqual([r['state'] for r in row['texture_resolution']], ['copied_local_dds_verified', 'known_shared_game_reference'])
            self.assertEqual(result['problems'], []); self.assertTrue(tree.assert_unchanged)
            self.assertEqual(tree.report['face_output_check']['records_audited'], 1)
            self.assertEqual(row['texture_resolution'][0]['in_game_resolution'], 'not_verified')

    def test_unknown_external_texture_is_a_warning_not_an_invented_missing_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp)); tree.shader('eye_l', color=999)
            result = tree.run(); self.assertEqual(result['problems'], [])
            self.assertTrue(result['warnings']); self.assertEqual(tree.report['problems'], [])
            self.assertEqual(result['materials'][0]['texture_resolution'][0]['state'], 'unresolved_external_or_local_texture')

    def test_native_preserved_model_is_audited_with_external_material_dependencies_unverified(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp)); tree.record.update(status='preserved_2k26', source_version=47)
            tree.shader('eye_l', local_entry=False, include_payload=False)
            result = tree.run(); self.assertEqual(result['problems'], [])
            self.assertEqual(result['materials'][0]['state'], 'external_material_not_available_for_audit')
            self.assertEqual(tree.report['face_output_check']['face_models'], 1)
            self.assertTrue(result['warnings']); self.assertEqual(tree.record['verify'], 'pass')

    def test_same_name_local_jmtl_cannot_resolve_a_different_declared_path_hash(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp)); tree.shader('eye_l', local_entry=False)
            result = tree.run(); row = result['materials'][0]
            self.assertEqual(row['state'], 'external_material_not_available_for_audit')
            self.assertTrue(row['unbound_local_file_present']); self.assertNotIn('face_texture_check', row)

    def test_required_own_local_payload_and_binding_omissions_are_problems(self):
        for kind in ['payload', 'binding']:
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as tmp:
                tree = Tree(Path(tmp))
                tree.shader('eye_l' if kind == 'payload' else 'unused', include_payload=False)
                result = tree.run(); self.assertTrue(result['problems'])
                self.assertEqual(tree.report['conversion_completeness'], 'incomplete')
                self.assertEqual(tree.record['verify'], 'pass')

    def test_missing_required_refs_and_wrong_face_shader_are_reported(self):
        for shader, color in [(0x12, 0), (0x15, 123)]:
            with self.subTest(shader=shader), tempfile.TemporaryDirectory() as tmp:
                tree = Tree(Path(tmp)); tree.shader('eye_l', shader, color)
                result = tree.run(); self.assertTrue(result['problems']); self.assertTrue(tree.assert_unchanged)

    def test_legitimate_left_and_right_eye_colors_are_not_forced_equal(self):
        with tempfile.TemporaryDirectory() as tmp:
            eye = mesh(bindings=[('eye_r:skinned', 0, 1), ('eye_l:skinned', 1, 1)])
            eye.triangles = np.array([[0, 1, 2], [2, 1, 0]], dtype=np.int32)
            tree = Tree(Path(tmp), meshes=[eye]); tree.shader('eye_l', color=111); tree.shader('eye_r', color=222)
            result = tree.run(); self.assertEqual(result['problems'], [])
            self.assertEqual({m['face_texture_check']['color_ref'] for m in result['materials']}, {111, 222})
            self.assertIn('may differ', result['eye_color_policy'])

    def test_teeth_are_classified_as_body_atlas_shared_game_or_explicit_custom(self):
        for pair, expected in [((123, 456), 'shared_body_atlas'),
                               (audit.SHARED_TEETH_PAIR, 'known_shared_2k26_teeth_pair'),
                               ((789, 987), 'explicit_custom_face_pair')]:
            with self.subTest(expected=expected), tempfile.TemporaryDirectory() as tmp:
                teeth = mesh('M_Teeth', [('teeth:skinned', 0, 1)])
                tree = Tree(Path(tmp), meshes=[teeth]); tree.shader('body', 0x19, 123, 456)
                tree.shader('teeth', 0x1a, *pair)
                result = tree.run(); self.assertEqual(result['problems'], [])
                self.assertEqual(result['materials'][0]['texture_pair_classification'], expected)

    def test_comparison_style_skin_teeth_and_mouthbag_body_atlas_are_supported(self):
        for name, binding in [('M_Teeth', 'teeth'), ('M_MouthBag', 'mouthbag')]:
            with self.subTest(binding=binding), tempfile.TemporaryDirectory() as tmp:
                tree = Tree(Path(tmp), meshes=[mesh(name, [(binding + ':skinned', 0, 1)])])
                color, _ = tree.texture('body_color'); normal, _ = tree.texture('body_nrm')
                tree.shader('body', 0x19, color, normal); tree.shader(binding, 0x19, color, normal)
                result = tree.run(); row = result['materials'][0]
                self.assertEqual(result['problems'], []); self.assertEqual(result['warnings'], [])
                self.assertEqual(row['shader_byte'], 0x19)
                self.assertEqual(row['texture_pair_classification'], 'shared_body_atlas')
                self.assertEqual(row['face_shader_validation'], 'comparison_style_skin_body_atlas_refs_confirmed')
                self.assertTrue(tree.assert_unchanged)

    def test_skin_teeth_external_or_other_body_pairs_are_unverified_not_declared_bad(self):
        for body in ['missing', 'external', 'different']:
            with self.subTest(body=body), tempfile.TemporaryDirectory() as tmp:
                tree = Tree(Path(tmp), meshes=[mesh('M_Teeth', [('teeth:skinned', 0, 1)])])
                if body != 'missing': tree.shader('body', 0x19, 111, 222, local_entry=body != 'external', include_payload=body != 'external')
                tree.shader('teeth', 0x19, 123, 456)
                result = tree.run(); self.assertEqual(result['problems'], [])
                self.assertEqual(result['materials'][0]['face_shader_validation'], 'skin_face_body_atlas_comparison_unverified')
                self.assertTrue(result['warnings']); self.assertEqual(tree.report['problems'], [])

    def test_other_teeth_shader_layouts_remain_scoped_unverified_without_replacement(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp), meshes=[mesh('M_Teeth', [('teeth:skinned', 0, 1)])])
            tree.shader('teeth', 0x15, 123, 456); result = tree.run()
            self.assertEqual(result['problems'], [])
            self.assertEqual(result['materials'][0]['face_shader_validation'], 'unsupported_face_layout_unverified')
            self.assertTrue(result['warnings']); self.assertTrue(tree.assert_unchanged)

    def test_named_native_baseline_is_provenanced_but_does_not_require_identical_topology(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp)); tree.shader('eye_l'); result = tree.run()
            baseline = tree.report['face_output_check']['reference_baseline']
            self.assertEqual(baseline['source_model_sha256'], 'bb0176e86fc2e74cebc61058acac1fa3103c7a859f2e54a2196947fe95ee4a1c')
            self.assertEqual(baseline['observed_anchor_slots'], list(range(13)))
            self.assertEqual(baseline['observed_eye_shape_names'], ['PupilContract', 'PupilExpand'])
            self.assertEqual(baseline['additional_139_John_Cena_2019_archive'], 'not inspected for this baseline')
            self.assertEqual(result['meshes'][0]['vertices'], 3)  # Not overwritten with reference counts.
            self.assertEqual(result['problems'], [])

    def test_bad_uv_triangle_and_anchor_domains_are_detected_without_changing_geometry(self):
        for kind in ['uv', 'triangles', 'anchor', 'range']:
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as tmp:
                tree = Tree(Path(tmp)); tree.shader('eye_l')
                if kind == 'uv': tree.model.meshes[0].uvs[0][0, 0] = float('nan')
                if kind == 'triangles': tree.model.meshes[0].triangles[0, 0] = 3
                if kind == 'anchor': tree.model.goto_points[0] = ('_ag_0000', 'M_EYE', 0, 3)
                if kind == 'range': tree.model.meshes[0].face_groups = [('eye_l:skinned', 1, 1)]
                result = tree.run(); self.assertTrue(result['problems']); self.assertTrue(tree.assert_unchanged)

    def test_tiling_uvs_and_missing_anchors_are_unverified_detail_not_automatic_repairs(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp), anchors=False); tree.shader('eye_l')
            tree.model.meshes[0].uvs[0][0, 0] = 2.
            result = tree.run(); self.assertEqual(result['problems'], []); self.assertTrue(result['warnings'])
            self.assertEqual(result['anchors']['count'], 0); self.assertEqual(result['meshes'][0]['uv_channels'][0]['maximum'][0], 2.)

    def test_vertex_colors_and_actual_game_flags_are_observed_without_stock_substitution(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp)); tree.shader('eye_l')
            eye = tree.model.meshes[0]; eye.colors = [np.full((3, 4), .25)]
            eye.scene_flag = 417; eye.motion_flag = 610051
            result = tree.run(); observed = result['meshes'][0]
            self.assertEqual((observed['scene_flag'], observed['motion_flag']), (417, 610051))
            self.assertEqual(observed['color_channels'][0]['minimum'], [.25] * 4)
            self.assertTrue(np.all(eye.colors[0] == .25))
            eye.colors[0][0, 0] = float('inf')
            self.assertTrue(any('vertex-color' in p for p in tree.run()['problems']))

    def test_every_record_including_failed_skipped_unreadable_and_attire_gets_an_entry(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp)); tree.shader('eye_l')
            missing = {'source': 'missing', 'output': str(tree.character / 'missing.mcd'), 'status': 'failed'}
            unreadable = tree.character / 'unreadable.mcd'; unreadable.write_bytes(b'unreadable fixture')
            tree.report['models'].extend([missing, {'source': 'unreadable', 'output': str(unreadable), 'status': 'failed'},
                                         {**tree.record, 'source': 'previous', 'status': 'skipped'}])
            attire = tree.character / '159_Default_Attire' / '159_Attire.mcd'; attire.parent.mkdir(); attire.write_bytes(b'attire')
            tree.models[str(attire)] = model([mesh('M_Outfit', [('outfit:skinned', 0, 1)])])
            tree.report['models'].append({'source': 'attire', 'output': str(attire), 'status': 'converted'})
            tree.run(); summary = tree.report['face_output_check']
            self.assertEqual((summary['records_total'], summary['records_audited']), (5, 5))
            self.assertEqual(summary['not_applicable'], 1); self.assertEqual(summary['unavailable_or_unreadable'], 2)
            self.assertIn('failed_or_skipped', tree.report['models'][3]['face_output_audit']['output_provenance'])
            self.assertTrue(summary['coverage_complete']); self.assertTrue(tree.assert_unchanged)

    def test_siblings_are_audited_independently_with_their_own_material_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); first = Tree(root, '159_Bryan'); first.shader('eye_l', color=111)
            second = Tree(root, '139_Cena'); second.shader('eye_l', color=222)
            first.models.update(second.models); first.report['models'].append(second.record)
            first.run(); self.assertEqual(first.report['face_output_check']['face_models'], 2)
            rows = [r['face_output_audit']['materials'][0] for r in first.report['models']]
            self.assertEqual([r['face_texture_check']['color_ref'] for r in rows], [111, 222])
            self.assertIn('159_Bryan', rows[0]['file']); self.assertIn('139_Cena', rows[1]['file'])

    def test_missing_or_unsupported_native_link_table_is_explicit(self):
        for value in [None, b'MTLs unsupported layout']:
            with tempfile.TemporaryDirectory() as tmp:
                tree = Tree(Path(tmp))
                if value is not None: tree.target.with_suffix('.mtls').write_bytes(value)
                result = tree.run(); self.assertEqual(result['material_library']['state'], 'unavailable_or_unsupported')
                self.assertTrue(result['problems']); self.assertEqual(result['file_changes'], 'none; read-only audit')

    def test_unsupported_model_version_and_parser_failures_still_have_coverage(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp)); tree.shader('eye_l'); tree.model.version = 41
            result = tree.run(); self.assertIn('not a native 2K26', result['problems'][0])
            tree.folder.vc.read_model = lambda path: (_ for _ in ()).throw(ValueError('native rejection'))
            result = tree.run(); self.assertEqual(result['state'], 'model_unreadable')
            self.assertEqual(tree.report['face_output_check']['records_audited'], 1)

    def test_broken_output_symlink_is_not_reached_as_a_material_or_texture_dependency(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); tree = Tree(root); shader = tree.shader('eye_l'); shader.unlink()
            outside = root / 'outside.jmtl'; outside.write_bytes(material(0x12, {0: 123, 3: audit.SHARED_EYE_NORMAL}))
            shader.symlink_to(outside); result = tree.run()
            self.assertEqual(result['materials'][0]['state'], 'missing_required_local_jmtl')
            self.assertEqual(outside.read_bytes(), material(0x12, {0: 123, 3: audit.SHARED_EYE_NORMAL}))

    def test_local_texture_bytes_must_match_report_copy_evidence_before_verification(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp)); value, path = tree.texture(copied=True); tree.shader('eye_l', color=value)
            raw = bytearray(path.read_bytes()); raw[-1] = 1; path.write_bytes(raw)
            result = tree.run()
            self.assertEqual(result['materials'][0]['texture_resolution'][0]['state'], 'matching_local_asset_present')
            self.assertFalse(result['materials'][0]['texture_resolution'][0]['files'][0]['copied_bytes_verified'])

    def test_final_header_normalization_evidence_uses_actual_output_hash(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp)); value, path = tree.texture(); tree.shader('eye_l', color=value)
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            tree.report['dds_header_normalization'] = {'rows': [{
                'state': 'output_header_count_repaired', 'output': str(path),
                'output_sha256': digest, 'source_unchanged': True,
                'expected_output_bytes_verified': True}]}
            result = tree.run()
            self.assertEqual(result['materials'][0]['texture_resolution'][0]['state'], 'copied_local_dds_verified')
            raw = bytearray(path.read_bytes()); raw[-1] = 1; path.write_bytes(raw)
            result = tree.run()
            self.assertFalse(result['materials'][0]['texture_resolution'][0]['files'][0]['copied_bytes_verified'])

    def test_failed_header_normalization_does_not_authorize_copy_verification(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp)); value, path = tree.texture(); tree.shader('eye_l', color=value)
            tree.report['dds_header_normalization'] = {'rows': [{
                'state': 'normalization_failed', 'output': str(path),
                'output_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                'source_unchanged': True, 'expected_output_bytes_verified': True}]}
            result = tree.run()
            self.assertFalse(result['materials'][0]['texture_resolution'][0]['files'][0]['copied_bytes_verified'])

    def test_folder_wrapper_persists_final_audit_and_is_idempotent(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Tree(Path(tmp)); tree.shader('eye_l')
            def convert_folder(src, dst, log=lambda text: None): return tree.report
            tree.folder.convert_folder = convert_folder; audit.install(tree.folder)
            installed = tree.folder.convert_folder; audit.install(tree.folder)
            self.assertIs(installed, tree.folder.convert_folder)
            with mock.patch('gmf_report.save_intermediate') as save:
                result = tree.folder.convert_folder(str(Path(tmp) / 'input'), str(tree.root))
            save.assert_called_once_with(result, str(tree.root))
            self.assertEqual(result['face_output_check']['records_audited'], 1)
            json.dumps(result)  # Native audit facts must remain report-serializable.


if __name__ == '__main__':
    unittest.main()
