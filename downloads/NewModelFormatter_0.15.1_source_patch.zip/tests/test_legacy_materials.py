"""Measured legacy source fixtures and refusal boundaries, without file writes."""
import base64
import copy
import hashlib
import json
import math
from pathlib import Path
import struct
import sys
import unittest
import zlib

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from gmf_legacy_materials import (LegacyMaterialError, decode_legacy_material_library,
                                 to_material25, to_material25_library)


# Exact supplied source captures follow below; zlib/base85 only makes this
# portable fixture compact. Their hashes, extents and expected values are
# checked independently of the reader. No attachment paths are needed.
_CAPTURED = {
    'kenny_base': ('e59dae5ddc85ceaf01fafabd5595a49a792ab0e2de2ce6fb49fc4ae251f5e406',
        'c-rk&U2GIp6u#S?*-iT(7(s$OP*J0Zkp662AhPXtX#wrpLjP<fS!Q={cgN1o)S20~TOVwU2^xq*L&RdhMld82jG&Fg7zp}+K}aAG'
        '31|RAATb(A+Jx|e_5PfhJ6lTwAyH!N!+z(Ud+s^+ob#RAiM2IZGD1iTB9t&vd6bW~#;smeM=uy=R?$#8-V?L5rv9?ZL64kA*_@Ts'
        'a7^h#M4iI6qH0Y>0=KF|u3356phwP&<JDf7*+dnqMKP5u;+}>Kow=qriVKxhxLs%B9uXkq2^R7MsPM|v#u~tiy}`((GtNRKt}WDV'
        ';TTKGq6b3JNNb~}r0KnAhNjWirfRC5rkkyOIN5~zF)dG|IcaEySx-bweI=)++B-H7mj=qJNz+)(E=>0N3=>DGA+k+Hx3pXm>&d*E'
        'q*poB0`knZsDm-9SA^Uk5-ayKr(7gl&g6udQ!QL3EUG-#Re8v+)i$x7wlm^zmB*3y$O^BVciT^H+TmTalSO8zHES3ir)A#Ocw1KC'
        'mGe%K8%=EKSo0+0iS4D7mui(B{c^9&x=+$ndLvmQr`w(*gQBc!s1=F5PPegcsdgSQwc9GTa&^!gUgL5%e^O0XTj@#_u2khpAy=w#'
        'rD}2M8c)JCZe1Mua>hAS)Xl7WOCq}(c1P~HL01wQMmUe-NyW_RgzjwQGgwKXsG}J$RlS!_HwoC;%PKF#G9gw9v4T!eCqGF?NH<8W'
        'RV~siOsa$!LNugjxKWRmvobtn+Qe9osg}*^naHI(6tkQk;MEuEkn2)77rGi(surPLN#r5YsPOo%^vD&i#R^wi&aXsEO$(~AN)m|}'
        'kYB-FvgpJ%dt{)0EyjT79YGCwypB*Uh1>8TbEUJ#H?A^e!8Yq9-=?(^#zF~{q#TZFN|qZrbt5t(58P$|+pV1IG)hdddYvm|iA+wJ'
        'I#xVe;JYu^r)u#&_B8g0M7dhiE#|@K$EK#_ovJkV(?_g<3R(-4%qY}>cV-;X`Z5YLGU>0TSQ!T)8OB-Gfr8hQjJBOgC}|eA4P)~9'
        'sHUl;R7Fo>`excx7in%(k~Z-o_SQIiqFJOoqFTbT9vR6bp{r`>v<a4>sj2utMzwLl21|!|<iBxu6BQ%+C!@*92MGGu>UlI5q(=dl'
        'A_>(HTu#=fPByJt3;H&|O@JEUASyyr|K1=z-X*w)L|ggt@K;Os#+QtN{V~8(fad|PG8_(%!+H|1#P@gqkND``Xyi$PJ4Z%pLj+6C'
        'Jr=HIdQ{iUaJcp*hIO@RpM(a8_?Ayb<tMvOoL+Wy_bwmLb04wk>A4m@#LuE5fF}Td1iTFRJK#--5iH{ChX5A>E&;4zI9k6NaD5T2'
        '>&fs&*v|mkfWv@Wi)e0LwI9HGAK>SJM*+VFJO_BCh~H}*)_)Rwb<VPIv7g7C@0ZXbKk2hyM$wV4|2Xi=*!q=zZo8V{<+>JFcLSyX'
        'b-+Qu*8#Tzz7M#U;o-<ZKflXS67xF}^9+f(<H*%di{{<fbP@J`^WXGOPLgJ@ekV|g#QQRpmvbeKrGQHStEIxbIJ}L3J|@xr_SAO4'
        '`gVLyNi*}=kT{>uoSWFPb9coLPOf*$Yo{Og%4^!od*QXitK0G0>EUb8kK6Ix>HYM)F9qJ0GTzg_H>JY&<4)&bD*v}jGxOi!UNIo$'
        '{iwuwADMUSo$#igqJ_Li=uUaRA7XzAc+9yA;90;+fWHDx0N#=cXV{t5pbWJITnM-rkj_!1%;%_mfi%>%r7P;p(X(>B3@^KnPS11X'
        '%(idN)^^IAe<_*w(~vp0hGYqCCcZ{w8TFq0xg&7>iP@hJ-4{f6l;|=Op{`luyPlqor@W@9?iBM`8gY0@YkXejHGVjC@FKpjvil0L'
        'S-f#pcpPjeNsN*J;d($ui$ZgPAAkFve{q2Ec~w<__qvYYQ?vGmn*uKeXihwP2_*t#4$0Yma`wXB{iF5K#DdL%!ai>g{P*gxQ`Eud'
        ')ZrtjL)b{3=-PJt!@@cs^jUzut4<yMe^>AJdtofV-_<K?_e{jPv-<t@u8v0Fdm`d|Py8G2s`EWD^SgTI-xK%ayLvouIv~E7XQS!9'
        'pDw`cU1M`Qf5!jIHv*hvML}Nw2ZMa(OM_hhOi)5Af(SJPW%PK*p~L>M#;wjwPxl?w5&Y-xw-N5Q?)v;4Zy&g{ws?l`yuSda^mNY'),
    'kenny_attire': ('6899137edd9861a62e41ab38af3d1cf352aaf33649c1561ffd71ecbf0245e371',
        'c-rk&O=w(I6h1Ta0u|APDMDST?Z$3wk}8TglbI<=t1~f7(#Gmyxbx<|H#d3j-SNIViE$xzA-GVwa?v27pwNX~ST_a1iU<m}8)<Qu'
        'B3;ylD1w4eFy5bYXWmQ(SCK3<kazBP&bjBD@0>fATVJlF69BNFKAY90W=M&ERZd}ni<m?ZHiM-u_2&dl6B<FP*1d>`I_Uxvg0vY)'
        'eA>vY=QHa%OERdUgB`Dym*yf8ri&^M2Cva|9lAr>eB*`IYK4(hnRKdCiKI!&<R-+-7yJa3ghk-<h?@#jolOJ!s#!q;kd(@ft2k`N'
        'i|o~Uy5_PqcrWZ|P$jwu5?lWjDifOO#EFPqaJB3!OlValr>Xs7YP;5+u$EBTC2c3s!6D<aAy_Ky7tMBUjFN>NnW8{50%P}kB1-Mo'
        '@iuE?)YIz_CP06h<=W!OGAz)IlNwdEbG1W~kR_q!USkP;j>#9*n)D<;Lj)s|@dN_F6FEnGTBD*1LBuz7FHA@coW?XGH2Idy+z<=~'
        'rrO3?N>4BOB%%sQ)-_ektF_=<8qm<SsEDc*Nkzu1g7L~xi?%s}6`@LL5r3^;UnZ2^vEHXKh}6K%TDEDc7sfQ{H9OPUz4Pd^ygcM2'
        'XNKYQFr3ndw4)kX;atsh$aY*4GbarXl?7OIP*(>zikOesbn1-jl&PdKTuNsO+B6`&$ekM3dlpDsFX$jTxSn{OrkzC*AH(0#^9lFY'
        'cu!_?XO6+yk!@2Mo1IJ6I^8eD{ybuBJF!XiK?zlPaf|oQj36wd!&4)4E9xo$Kt$pe6{?kPf%N*&9Bp&9r65TPLC@F!=q6l;bwaJ~'
        'D~3!aZ>)JcKLh$IV^7S5=Nv2=D2<CT=z{d!Fi5454QTERyHougQ2+P9mbbHWA3!db)4EA`1#+-;;X>&aXvLNCL4(hhE`kT2D$VCG'
        '0hhKfZENq#o(D(O&3xS(=(d&aDW&@@qx(zgDoQswG0;uqJh)$_crZ86-BdXaE8Tl0_ZuYwc^Lisd5rFD^ncw*fFnv6R-joO1jpep'
        '#(y0BpD}W_G;i#Oil-5e%j^2$a=4tXR^6YYx#9kNt872McBABYxt@;W@TZMCtNZfgNMFkP#OKr=@mU$+)7~dOt9!&}eT2`sed6=h'
        '9`Sj1gwKb$FLFCO-zzej&(rXexf~uY|86e{@bb2X2l5^~q(UFb5B452HYh!dK6N9%EWeC6%v;VfZ}=6@q5d6|TS{KPcCG06f2?p2'
        '1f|Qk@2d4Heuw_!xVirSpnPU#J}chBn7?3*yC}Va<ui%$QIu0gelS}^Tvzh^SAP^=LOgC>A=)+ymhYPdo8x>z=dKOS?ft^=+&-~;'
        'OIHfk=WCR1jyDRn2e%8B$FFF2^Sz7sUeC%yDD`X~^M+^pglA(`m0VD^mCQXI;J$DEpZ|Y){vUbSSHVBO2`+lO-vn2^-EV?B-tITS'
        'fiZ7_M<)KAH^JYW7;Lr'),
    'hammer_base': ('23bee31d1e34832acd52421bea88702a5b419afee1b5004bc6abe47d8a53f218',
        'c-rlm32YSC8OPsxcWIzGz$8!-=OCdZAq3g$GgW<u!@*ZE#=)j+W_M@3Q_s#WGrP9eQ3TBap`j+FEy%8*P(xK2+zM1EDM1nGfzq0m'
        'gj7yK8`2;WH6<m)>P1xOH#7g4d26Qu1X7gBme#-Teeale&HKLZP0iwJZ5(549{mEbP>P8u(H|7lq!N@xBOx3AW9_0U3ud;e|Ca?V'
        '!Xly&V$oPK5eW#bEFp@C2(>ewUClo)%Vb|*GuSNVV}-1YG&PH>r@M&bJdC9(BYv$-Qdn(FjS4ags7Xl^=PE*gy5H&#*JyHedv<Oo'
        'C#P66snO_agg7I$7KwHEHBBQiBqjt&u8sx72C2)gk(1rY$tkC$0$%Q9X6>$+VzjJJrr%L%>Dgtf7^ceQb-|b%Q!AYI^SEc_aqatf'
        'Sudk?h(bc5hBelxi8aQE^f81R;$pB`Y!_u~Yyo{Jva}*8g&LPEqDnCqm4a&QL8C*I7mul8rQQ#gPz6PklR;4lrtCrR%8?~7j%dBq'
        'S);W%BU<G2Hiw)09A^|chHNfZw%ygBEeTGoe6EFju7xz2EAs#^>t#ZcrtgQeRi@4_;S-J4lcQa>#Pxw+3x17!yqvP;f1WC8im?LL'
        'V7V^wTgcp6dX+`7WNXBFaxmWRlqurM7jcg>HZ|sZzFw1BsZtW6qDhIAy|JUrC}6Lqk+OAIKci?!u@@xAo|%S(YHM?C$!AOXwv=Z}'
        'g|<{cQlzUP8jB_Dv4xyBE4z@JmO^edb5r(~wYIXNM(r_>Y-@}W=zkY3=;w}pF4WU+q9Ls+z11LN_k#J%!%B%|NG~KF8LTdDLAn*x'
        'z?I-LRIi8FPv_B>zP9S;_iy*#_dMlI7`m(EFv=VQPk?^~{|S0rCT}42_VkoyAwAP%S%J&!bA`dO(pr~?EhjPV^0J)4=HDEhb85?z'
        'F0=pLR3;pLr=$mM>;QLz2f@SO%iwYFU2qt@0DeBh<W%r3FvsB5iV|=k^o^h&Yy&&MC&2X?`k0rNZb7;q+y}mBaDVylk$wYw2mBB`'
        'Pki*oIVI!W`nnC4Omm~3ZV#L7W~|WdWh>X5UVEymtK~uD)q)Qje5)*kv;ua5kAv&Ljo?;1YbVls!9(B?@O8Jje(zFWKA^t*oBDG6'
        '<m7=LEt_(?WwV;Srp+=eXQgFl)2vp9Dk*KYc}lZjO>Kr<uwJE(E=QT;h}n*q>xe$PmcYHAVIe5S1xZPKvL&?6X)-lUX7}_`N=!?r'
        'l3ZTrJSG3~%qG3)>1I=(7tU;6ZL8^6>og0Rc8-3wEGTbaF3X1UM#nnU!*WuK=-s|D8#|9SRlUBctXcfuCYQ4gt*R(0HIkMXVIM|W'
        'jVrUoyrCIwi$h`{*}6nfb1uykr`xEDT3};$U!esKOR5+UWci{d*cwWn{dVTtlA|lMr2^+Iwk78%aZVE72s_QYBi1u>IoW5|e8859'
        '9E)zu$ta6X1+9~*mhw=5*P)obYZfF$&JWQ4qV&szA8<R_?^z_>2U}bSR)E!D6Bq!aU?=!ExDM@YM0y+ih}}pZ0CnFW91fRSzQLQ|'
        'd*DC74A|f6$-ZZiIGb$#%R|G@^ltIJTH-SOj4G6A1O+e(rogAb4KCAGZic_n5B*Q!Z~PMe#!;7P-~LF?K256goWGHoVU9B^!}K@q'
        'h8@lYOF_#YXaa>#^au8rKZ|rP+V4a9C*T3_FnA37Gx&kQJ1YJIPJj)*37ihz4;F%zU>(>3wz^IKq<w@h&<*y2KLmG!2f>$M`-f~F'
        'z|@~5U*H`10$z`oy}zukw|jNp@=TAJmj%uQec+eD`QTT;7ElCNfRBPtf$PB@un!yne+C``kASa(r@*t|N1)g1Vb_!YGS%y4<BJdf'
        'E%n;d6K9Yvmvlv>TeG)q)1lw>U0CQf%UeFrtuE8&5mTZSrnma(?Nx;!nNnqhEggA?QZ2(w8HU<ENsViY(Ff_=lvqU-L*inw(<mbu'
        'De_c|$MV_MF{9gv`dEjaS0iX`R>dgE^aNEA1uhGf;>oxq`{RPj%!aKV;W4(7e+C%|U3AQm*@&!Y4CmH0di+9jHA#;VaBgLR_n7BI'
        'SrO9n>HN{-oMt^9nH~>h?K!uhm2?TxttQ=$p65^ar<{Lf6EokpA5h+azF#Tt&b%8xx8oNZ-Gh{O@3Qs9uTkFHl=nX6MTYa1-tgh('
        'SsyX;%oyh~--}7c8Btwot!V?Z*R-zPS=H!VJuTPMX>HybrRgvoMxAmw9uY<@w=oYBtayp(bKzmP5x+=%dt>{~treAlTM94-mEhPu'
        '`~Tf%&6l#z^t(u`(q(TqYrnbD_uFjh<3oSg)jetLE%n8ii-%bHxwevz<v#BI@l%TAYzcE>r+Hs<EY7>Cah@@ru{dum&KryKt|ZQL'
        'j;>1%_;Bw_2eOiO@9Sarq}}_PwC;Vav%C>}1Z)G_!ByZlsJ-tHx079vcMiAgD}MU;9^@TF>~{p|A@C$(zcWam1IHl_%LH!&XHooB'
        'MB)N2_G?D$C!)*>@G)>L_+4-t_+!L=&ms2vHS|Xj`@MzO?=<e3|3%NfCWEn?Gra8Ng1+IJ=BP3!!<@q+#D0~Cz3RXguocw6$G|n<'
        'x54it_S<FO{hIB+fb?&{A@C%42GnCcn&*;hjo4~y`804Q?q_ola}|SCU<2p}+rSR+3B-OIklq6JgZsc2KlZ+t;w8j<!{~<_@zQl3'
        '51T?x#dI$An}fU}u)<^BN!KF%Fc<`*U<deh@SET!a2vQ2+zY+{z62fv{{;R8{5$AE>~<YE6`W3S-YoKWa=F;AjC6IR`zq<G-+Oal'
        'T}oRT9})ZA0iS%a@ol)q`c!<;Z&H$~3L!~Qf}(C9jW5gPb!2Z6SK*G8Yka=dc$1ibhtMG=oH)QKS;1n#Ael`HB=l!$F<A=vJ0em-'
        'Ov|v2`4JZ4B44j`AJqJtNWaN+)?^XyX3n>aJe+G~hQB<mq@Kz=LK>AhcQva?_blnY#msklGc)(~F5`R}EIt7JVJi2kzU!#&j3s;a'
        'yZ6ppcNS-pi_U=wBu;jX{&sO^+FHWl{mieVQOR$suEJ_s>*>OJ>M_O5h+(bu^kF?qu%5M4W;to%+<HDqx^DeG2kZ7dtY<&g^Ev2$'
        'Mde;0>20c8b!OV8?tv2vhS9#8*7I5tZ{pVTzr?K}a{'),
    'hammer_attire': ('631ca8f6fb308da8b982b672de962f6e4e7c66a1d5b360320ac48bce0ed5b9b8',
        'c-rk*3vg7`89uw4P&6$A(`hO?Q=~i`D-$6gr6}1vFb~YeunD9PWx3fso4sWB-p#$ciHVF=Mk0zjlu|3mq<~JxcC1Z1=vZp2Q)nhr'
        'Efr0%1raP(5wR&um2{xc|D5~n-MeWD$rv)!F*BL(f1LlEyXSo8`}g6itu)6l#_ps42Cf*P`DT-<X*|S&daOa!l!U5lrX7qZs$n}#'
        '8t1kXSJI_PEyRshn$3>18mgJFy=vPsBRWsdPJdUhk^CFSrm&f80jps3Ol2lTe6^L6U4&117;7tu1jGwsRlK#FFi@gLb)zJrXpO4Y'
        '$QqPjQ>hZ<mE4HaZcxgn#2E`m^;TiX-3kaV6)H4%n1u~pOW0+N0VNubDCzNfTnVa)Hb+8Mk(*5DOBF+v8&1C1emz}hD5@ifnh<YD'
        'HpaM?3`AySy7?JyA~Ty9ke!|B&Jk`KFQ=DJR(MWHQB7%7X*8=9L--|%u#}jv#jg3d8L2j6GY9yy2KZvlaHXp8MQY;P4ttryPH?$`'
        'k0+F9R1G?9>}J@nCmSOfj>b(>I5lw|EH${P@o37e<Sl7O4i*j_mc5oZ{-S6D59x3!v;@~o>x6_~rK=`~?FZIGln|YI%2C4!*tP!J'
        'l$A2-3`IPu8cH8!#llno#~2gaw6Kl)<j`2PdY8`>Td#?=m(&E6C{KAyZO@2_;R0<B(;2#+kW4OiI%Q7B568hT^3p+jCfYJzGAc4='
        'gwCi~*G=ire%_|(!6rQ^+=Lpp7fjh@4qGhOVskqtj#R81Q-g-SkUTZYG~I|<Q6qJz^0qN{{yb@d%SD&An7m2M#lqpRcLvL1H<3S='
        'uz;|FWwUAL4t})0x@yc4CT{q>-XP^PvQ|^>=1<IdZ_VhdTaVlml=~4`U6lLx@g3S9_cwICM7ck_TIt;@@zsJuax7yffM<YLx-6Us'
        'oZ@o-m-5UWB<6KlYu^qG0CnKqzz2ZeC)~1mbHR43^K;;DT-F}EBJ<0<2dr`4_htTtqJN^!<+kP-2mBiF8*VF~@0PE(z)RS?;L3vA'
        '5MKgZ;kMRO-C3-eUQW9^n?3T-nO_`Och=}|Tl>EW*eS=pT=WcZ7sYo|O%K(4eDuZ>{4eMC{)uv{PyJ)TUkN+bjV<USd~N5Pg0nPs'
        '4C(O%Pc~b9=fAeEh_<eo<guRh28r7W=XtDWDf3u!)Of5p0v>CQCgfW^*7Mwp`iJ2^22AOH_ovo>XMY?<8^|ademBS{|GX)D2AV>~'
        'iC$*CA(L&FZHpLUkEkZCZ+1nSb}w4{+#Toxt0<Qw>mf&v*o@qdDYuiX--)^pYVTVbd1Os5dc;xmh*RhZE@<<3;3QxkaNZ#OpnQ;6'
        'Ewn!bOaSi(ZUAlt{sdb8Jl5$3zJVTb1U;e;J>o2S#1+u^T=aw~z}Y}A@@41|wdfHm5nlx~(If654ey|r^O&PY>_Bhm0`5X@=mGAh'
        '_+hGf*U=+RqDP!VkH~?(Uq$-;b<*rPjvi4AjjuwFs7DW2g&xs@9<c^<Jc|4l^nxc*|1<c%9MB^=KXs1~mBZ)_a`^Cjf-L*I7kmbK'
        'fjr5}tOr=^`hVB{a?<d{XU|N?d8_k>wb1tl%EicPcWD2E$Ze+FQ)K;=a{InCzbC+s^t}k}e+Alq0NVcnupjsZXmBp@+Cg-F<{+_K'
        'py`#sJAhH(T?2Z-MreO0)_E5AD`<ZYwEs<L|GUuslc+m~d2*on*8s1Bw%-WtzXjS~j<_FK5A6?=j%)OCS{&NH2AaPCxCNU3H1K(f'
        'zeF{A9NNDR+W$7R|3iE}=%=x6(&8^VwEt>o_jG9gY-oEiw7&}4zZ}{hM&5wN-;MeQ;D2|3_P4t%?Qf({$E-@SFRkz5i?4w6>=>@Z'
        'kVPhSi_=$CPCD3i<w35taI>bykE@lIAk{FGkg8}wUhJ^T9JWu@9G*XYyX11xvtx3>!Ec@QaMm{1Q8_;2KFVQsBqJvWn^G8WZ&+2V'
        'Dke*Co`|G2OFDHtAq(w$%>+fS67Q?%K29W@O80Sl_OasR#@DvYvhJI=P~yv8pTuj6meW}AWg^Gt|5mEGslK`Y?{W9Z`*BA%;-2r2'
        'Sm=EgxQhvHPb}y`zL(}WMAk8yW9oY=b9>v@c|JzY<;r3?WPa6^&1SIcjuk$!ZQ(SE<x{MPVuubNy!oRa@J2uG<x0YL+Izh*%P&lE'
        'EqNiX#g)*AQ%%e{dQ20m4Vh^2(Jsm}F=~Wp_CI(wh0c4z?ylqWmhFFhCV1ur&nm&QWi&QORtSA0DZYcMUO&C)&x^a)fM*-Pm2KeH'
        'Gr$+Xvu@;Hr#TLi^*0C4P9b-Wa%0K-vV&)niD!8((KFIK^MPme;8|n<&%Spdp4s2ok2u@XGmjqU(rXTxd5*`tDF4!9M}~!ibMSiN'
        '!rJ)b&mB7&KQb2_ycHbugM$GYtBTJ&gr@u*hd!&$kG6H^uYK=PaBwSl<m8^fJ>cN$$iGc<yie9?2M4q89$`H3?P@Y_aB%Qj6f33J'
        'at8;Sz`-_fuwwuRzjGlD%3p~_oPXA=qsKjKy&>}sk9SedS>rAx-=@*IpZ=sGxi$Bl(tPl(2z;vo-|A^B7w`E9b#cyA<Jsd^`}g(!'
        'x&wUM1U@|lo^=6V1mAv-{C=9_Fj*fu_|}hH7IAAFnb$b@c0I-BQmoX$w>t2RgKx$FzBOI2w~l;g9nHQvjIKJAo_a~SHJQ$M?D4+5'
        '@way7=7C!az^z5#RvnF1#P86Aw5hC_YM46pD|v_R%((~LdKmoJ3Qj!@+zD>|7Wut2$D3pwc5v$ia{ZJOA475++?q(-nohBN2e(SV'
        't;OKhis5LP{AGK@`DM*IdK|OX8#2%Eco*fGHSSVt*`@>Kr``w#=MG29rtUkqHvG-gO_!6F{RdF`_uc'),
}


def captured(name):
    digest, payload = _CAPTURED[name]
    raw = zlib.decompress(base64.b85decode(payload))
    if hashlib.sha256(raw).hexdigest() != digest:
        raise AssertionError('source fixture fingerprint changed')
    return raw


def specimen(version=6, *, records=None, names=('teeth',), block_versions=None,
             shader='yCh_Teeth', technique='Normal'):
    """Independent hand-authored small source format specimen.

    This describes its bytes explicitly, not by invoking production writers.
    Retained flag words deliberately differ from target flags. Parameter names
    and values contain ordinary scalar, local texture and u64 fields.
    """
    records = records or [('irradianceR', 1, 1.0), ('colorMap', 4, 'body_color'),
                          ('colorMap@ref', 5, 0xFEDCBA9876543210),
                          ('g_nrmMap', 4, 'body_nrm'),
                          ('g_nrmMap@ref', 5, 0x123456789ABCDEFF)]
    strings = bytearray()
    offsets = {}
    def entry(text):
        if text not in offsets:
            offsets[text] = len(strings); strings.extend(text.encode('latin1') + b'\0')
        return offsets[text]
    for name in names:
        entry(name)
    entry(shader); entry(technique)
    for name, kind, value in records:
        entry(name)
        if kind == 4:
            entry(value)
    data = bytearray(b'MTLs' + struct.pack('<II', version, len(strings)) + strings)
    data.extend(bytes((-len(data)) % 4))
    data.extend(struct.pack('<I', len(names)))
    if version == 6:
        data.extend(b''.join(struct.pack('<Q', i + 111) for i in range(len(names))))
        data.extend(b''.join(struct.pack('<H', offsets[name]) for name in names))
        data.extend(bytes((-len(data)) % 4))
    for index, name in enumerate(names):
        if version == 6:
            block_version = block_versions[index] if block_versions is not None else 1
            data.extend(b'MTL!' + struct.pack('<II', block_version, len(strings)) + strings)
            data.extend(bytes((-len(data)) % 4))
        else:
            data.extend(struct.pack('<H', offsets[name]))
        data.extend(struct.pack('<HHHBBBH', offsets[shader], 0xFFFF,
                                offsets[technique], 0, 0, 1, 0))
        data.extend(bytes((-len(data)) % 4))
        data.extend(struct.pack('<H', len(records)))
        if version == 6:
            data.extend(bytes((-len(data)) % 4))
        for pname, kind, value in records:
            data.extend(struct.pack('<Hh', offsets[pname], kind))
            if kind == 1:
                data.extend(struct.pack('<f', value))
            elif kind == 2:
                data.extend(value)
            elif kind == 3:
                data.extend(struct.pack('<I', value))
            elif kind == 4:
                data.extend(struct.pack('<H', offsets[value]))
            elif kind == 5:
                data.extend(struct.pack('<Q', value))
            else:
                data.extend(b'\0' * 4)
            phase = 2 if version == 5 else 0
            data.extend(bytes((phase-len(data)) % 4))
    return bytes(data)


class LegacySourceExtentTests(unittest.TestCase):
    def test_four_exact_uploaded_source_tables_consume_all_declared_bytes(self):
        expected = {'kenny_base': (5, 5102, 9, 1916, 8),
                    'kenny_attire': (5, 3658, 8, 1376, 16),
                    'hammer_base': (6, 8692, 9, 180, 0),
                    'hammer_attire': (6, 8612, 9, 240, 6)}
        for name, (version, size, count, start, vectors) in expected.items():
            with self.subTest(name=name):
                source = bytearray(captured(name)); before = bytes(source)
                result = decode_legacy_material_library(source)
                self.assertEqual(bytes(source), before)
                self.assertEqual((result['library_version'], result['bytes'], result['material_count']),
                                 (version, size, count))
                self.assertEqual(result['materials'][0]['offset'], start)
                self.assertEqual(result['walk_end'], size)
                self.assertTrue(result['payload_extents_validated'])
                self.assertEqual(len(result['unverified_vectors']), vectors)
                self.assertEqual(result['sha256'], _CAPTURED[name][0])
                self.assertEqual(result['nonzero_padding'], [])
                for first, following in zip(result['materials'], result['materials'][1:]):
                    self.assertEqual(first['end'], following['offset'])
                self.assertEqual(result['materials'][-1]['end'], size)
                json.dumps(result, allow_nan=False)

    def test_actual_source_teeth_maps_scalar_values_and_shader_identity(self):
        for key, shader, color_hash, normal_hash in [
            ('kenny_base', 'yCS_Teeth', 5887860225007720771, 6986797172203568791),
            ('hammer_base', 'yCh_Teeth', 6591716130890221439, 2240079744191423451)]:
            with self.subTest(source=key):
                result = decode_legacy_material_library(captured(key))
                teeth = next(m for m in result['materials'] if m['name'] == 'teeth')
                fields = {p['name']: p for p in teeth['parameters']}
                self.assertEqual(teeth['shader'], shader)
                self.assertEqual(teeth['technique'], 'Normal')
                self.assertEqual(teeth['parameter_count'], 16)
                self.assertEqual(fields['colorMap']['value'], 'body_color')
                self.assertEqual(fields['g_nrmMap']['value'], 'body_nrm')
                self.assertEqual(fields['colorMap@ref']['value'], color_hash)
                self.assertEqual(fields['g_nrmMap@ref']['value'], normal_hash)
                self.assertEqual(fields['irradianceR']['value'], 1.0)
                self.assertEqual(fields['irradianceG']['value'], .75)
                self.assertAlmostEqual(fields['g_teethWetness']['value'], .85, places=6)
                self.assertEqual(fields['occlusionMap']['value'], 'teeth_occlusion')
        hammer = decode_legacy_material_library(captured('hammer_base'))
        mouth = next(m for m in hammer['materials'] if m['name'] == 'mouthbag')
        self.assertEqual((mouth['offset'], mouth['end'], mouth['technique']), (7768, 8228, 'Mouthbag'))
        teeth = next(m for m in hammer['materials'] if m['name'] == 'teeth')
        self.assertEqual((teeth['offset'], teeth['end']), (8228, 8692))

    def test_v5_parameter_phase_two_and_inline_v1_phase_zero_are_distinct(self):
        kenny = decode_legacy_material_library(captured('kenny_base'))
        hammer = decode_legacy_material_library(captured('hammer_base'))
        first = kenny['materials'][0]['parameters']
        self.assertEqual([p['offset'] for p in first[:2]], [1934, 1942])
        self.assertTrue(all(p['end'] % 4 == 2 for m in kenny['materials'] for p in m['parameters']))
        self.assertTrue(all(p['end'] % 4 == 0 for m in hammer['materials'] for p in m['parameters']))

    def test_selective_truncations_cannot_produce_partial_material_results(self):
        raw = captured('hammer_base')
        for cut in (0, 3, 7, 11, 79, 179, 184, 191, 1223, 1237, 1245, 1889, 4180, 8689, 8691):
            with self.subTest(cut=cut), self.assertRaises(LegacyMaterialError):
                decode_legacy_material_library(raw[:cut])
        for cut in (1911, 1915, 1933, 1939, 3413, 5101):
            with self.subTest(v5cut=cut), self.assertRaises(LegacyMaterialError):
                decode_legacy_material_library(captured('kenny_base')[:cut])

    def test_trailing_bytes_empty_library_and_bad_counts_are_rejected(self):
        raw = specimen()
        for tail in (b'\0', b'junk'):
            with self.assertRaisesRegex(LegacyMaterialError, 'trailing'):
                decode_legacy_material_library(raw+tail)
        facts = decode_legacy_material_library(raw)
        broken = bytearray(raw); struct.pack_into('<I', broken, facts['count_offset'], 0xFFFFFFFF)
        with self.assertRaisesRegex(LegacyMaterialError, 'count'):
            decode_legacy_material_library(broken)
        broken = bytearray(raw); struct.pack_into('<I', broken, facts['count_offset'], 0)
        with self.assertRaisesRegex(LegacyMaterialError, 'empty'):
            decode_legacy_material_library(broken)

    def test_string_offsets_terminators_and_table_extents_are_bounded(self):
        raw = specimen(); facts = decode_legacy_material_library(raw); material = facts['materials'][0]
        mutations = []
        for value in (0xFFFF, material['shader_offset']+1):
            broken = bytearray(raw); struct.pack_into('<H', broken, material['header_offset'], value)
            mutations.append(broken)
        broken = bytearray(raw); struct.pack_into('<I', broken, material['offset']+8, 0xFFFFFFFF)
        mutations.append(broken)
        first = material['parameters'][0]
        broken = bytearray(raw); struct.pack_into('<H', broken, first['offset'], 0xFFFF)
        mutations.append(broken)
        for broken in mutations:
            with self.assertRaises(LegacyMaterialError):
                decode_legacy_material_library(broken)
        broken = bytearray(raw)
        local_table = material['offset']+12
        # Erase the terminating zero and make the actual shader offset invalid.
        start = local_table+material['shader_offset']
        broken[start+len(material['shader'])] = ord('X')
        with self.assertRaisesRegex(LegacyMaterialError, 'boundary'):
            decode_legacy_material_library(broken)

    def test_mixed_v3_native_and_unknown_inline_blocks_remain_unsupported(self):
        for version in (2, 3, 4, 99):
            with self.subTest(version=version), self.assertRaisesRegex(LegacyMaterialError, 'block version'):
                decode_legacy_material_library(specimen(names=('teeth', 'mouthbag'), block_versions=(1, version)))
        from test_material_formats import library, inline_block
        # Existing malformed guard case changes only the v3 marker to v1.
        with self.assertRaises(LegacyMaterialError):
            decode_legacy_material_library(library([inline_block(1)], ['teeth']))

    def test_unknown_types_nonfinite_floats_and_duplicate_parameters_refuse(self):
        for records in [[('value', 77, 0)], [('value', 1, math.inf)], [('value', 1, math.nan)],
                        [('value', 1, 1.0), ('value', 5, 4)]]:
            with self.subTest(records=records), self.assertRaises(LegacyMaterialError):
                decode_legacy_material_library(specimen(records=records))

    def test_duplicate_and_case_colliding_material_names_refuse(self):
        for version in (5, 6):
            for names in (('teeth', 'teeth'), ('teeth', 'Teeth')):
                with self.subTest(version=version, names=names), self.assertRaisesRegex(LegacyMaterialError, 'colliding'):
                    decode_legacy_material_library(specimen(version, names=names))

    def test_nonzero_padding_is_retained_and_never_zeroed_in_source(self):
        source = bytearray(specimen()); facts = decode_legacy_material_library(source)
        position = facts['materials'][0]['parameters'][1]['value_end']
        self.assertLess(position, facts['materials'][0]['parameters'][1]['end'])
        source[position] = 0xA5; before = bytes(source)
        facts = decode_legacy_material_library(source)
        self.assertEqual(bytes(source), before)
        self.assertTrue(any(p['raw_hex'].startswith('a5') for p in facts['nonzero_padding']))


class Material25AdapterTests(unittest.TestCase):
    def test_actual_hammer_base_preserves_all_nine_material_contracts(self):
        decoded = decode_legacy_material_library(captured('hammer_base'))
        version, materials = to_material25_library(decoded)
        self.assertEqual(version, 6)
        self.assertEqual(len(materials), 9)
        for record, material in zip(decoded['materials'], materials):
            self.assertEqual((material.name, material.shader, material.technique),
                             (record['name'], record['shader'], record['technique']))
            self.assertEqual(set(material.params), {p['name'] for p in record['parameters']})
            self.assertEqual(material.head, (0, 0, 0))
            self.assertEqual(material.source_legacy['material']['flags_raw'], record['flags_raw'])
        teeth = next(m for m in materials if m.name == 'teeth')
        self.assertEqual(teeth.types['irradianceR'], 2)
        self.assertEqual(teeth.types['colorMap'], 6)
        self.assertEqual(teeth.types['colorMap@ref'], 7)
        self.assertEqual(teeth.params['colorMap@ref'], 6591716130890221439)
        self.assertEqual(teeth.params['g_nrmMap@ref'], 2240079744191423451)

    def test_factory_is_used_and_decoded_values_are_isolated_from_mutation(self):
        calls = []
        class Contract:
            def __init__(self):
                calls.append(1)
        decoded = decode_legacy_material_library(specimen())
        material = to_material25(decoded['materials'][0], Contract)
        self.assertIsInstance(material, Contract); self.assertEqual(calls, [1])
        material.params['colorMap'] = 'other'
        material.source_legacy['material']['flags_raw'][0] = 0
        self.assertEqual(decoded['materials'][0]['flags_raw'][0], 65535)
        source_param = next(p for p in decoded['materials'][0]['parameters'] if p['name'] == 'colorMap')
        self.assertEqual(source_param['value'], 'body_color')

    def test_ycs_names_and_source_techniques_are_not_aliased(self):
        raw = specimen(5, shader='yCS_Teeth', technique='Mouthbag')
        material = to_material25(decode_legacy_material_library(raw)['materials'][0])
        self.assertEqual((material.shader, material.technique), ('yCS_Teeth', 'Mouthbag'))

    def test_unsigned_scalar_matches_opaque_type0_v3_behavior_and_cannot_become_ref(self):
        decoded = decode_legacy_material_library(specimen(records=[('g_refraction', 3, 1)]))
        material = to_material25(decoded['materials'][0])
        self.assertEqual(material.params['g_refraction'], struct.pack('<I', 1))
        self.assertEqual(material.types['g_refraction'], 0)
        self.assertEqual(material.source_legacy['material']['parameters'][0]['value'], 1)
        for kind, value in ((1, 1.0), (3, 123), (4, 'body_color')):
            bad = decode_legacy_material_library(specimen(records=[('colorMap@ref', kind, value)]))
            with self.assertRaisesRegex(LegacyMaterialError, 'reference'):
                to_material25_library(bad)

    def test_all_vectors_in_actual_source_tables_refuse_default_adaptation(self):
        for name in ('kenny_base', 'kenny_attire', 'hammer_attire'):
            decoded = decode_legacy_material_library(captured(name))
            with self.subTest(name=name), self.assertRaisesRegex(LegacyMaterialError, 'vector semantics'):
                to_material25_library(decoded)
            records = [p for m in decoded['materials'] for p in m['parameters'] if p['packed_type'] == 2]
            self.assertTrue(records)
            self.assertTrue(all(p['raw_value_hex'] == '00'*16 for p in records))

    def test_nonzero_vector_is_preserved_opaque_and_never_interpreted_as_float4(self):
        vector = struct.pack('<4f', 1.0, -2.0, .25, 3.0)
        decoded = decode_legacy_material_library(specimen(records=[('CAS', 2, vector)]))
        original = copy.deepcopy(decoded)
        with self.assertRaisesRegex(LegacyMaterialError, 'vector semantics'):
            to_material25_library(decoded)
        with self.assertRaises(LegacyMaterialError):
            to_material25_library(decoded, opaque_vector_keys=('different',))
        _, materials = to_material25_library(decoded, opaque_vector_keys=('CAS',))
        material = materials[0]
        self.assertEqual(material.params['CAS'], vector)
        self.assertEqual(material.types['CAS'], 5)
        self.assertEqual(material.source_legacy['opaque_vector_keys'], ['CAS'])
        self.assertTrue(material.source_legacy['warnings'])
        self.assertEqual(decoded, original)


if __name__ == '__main__':
    unittest.main()
