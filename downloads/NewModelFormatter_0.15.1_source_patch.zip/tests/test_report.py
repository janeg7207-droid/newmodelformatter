import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import gmf_report as reports


class ReportTests(unittest.TestCase):
    def test_complete_report_saved_at_root_and_in_opened_mod_folder(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);dst=root/'output';mod=dst/'Characters'/'123_Rey'
            report={'source':str(root/'source'),'output':str(mod),'models':[{'verify':'pass'}]}
            paths=reports.save_report(report,dst)
            self.assertEqual(len(paths),2)
            self.assertEqual(json.loads(Path(paths[0]).read_text()),report)
            self.assertEqual(json.loads(Path(paths[1]).read_text()),report)
            self.assertEqual(reports.last_report_path(),paths[0])
            self.assertFalse(list(dst.rglob('.conversion-report-*')))

    def test_output_write_error_has_verified_temp_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);dst=root/'not-a-directory';dst.write_text('preserve')
            report={'source':str(root/'source'),'output':str(dst),'models':[]}
            paths=reports.save_report(report,dst,fallback_root=root/'fallback')
            self.assertEqual(dst.read_text(),'preserve');self.assertEqual(len(paths),1)
            self.assertTrue(Path(paths[0]).is_relative_to(root/'fallback'))
            self.assertEqual(json.loads(Path(paths[0]).read_text())['report_fallback'],report['report_fallback'])

    def test_failed_conversion_writes_error_report_then_preserves_exception(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'source';src.mkdir();dst=root/'out';messages=[]
            def convert_folder(src,dst,log=print,copy_other=True,slot=None):raise ValueError('native conversion failed')
            module=types.SimpleNamespace(convert_folder=convert_folder)
            reports.install(module,fallback_root=root/'fallback')
            with self.assertRaisesRegex(ValueError,'native conversion failed'):
                module.convert_folder(str(src),str(dst),log=messages.append)
            path=reports.last_report_path();data=json.loads(Path(path).read_text())
            self.assertEqual(data['status'],'failed');self.assertEqual(data['conversion_error']['type'],'ValueError')
            self.assertTrue(any(path in message for message in messages))

    def test_unsafe_output_does_not_create_files_inside_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'source';src.mkdir();original=mock.Mock()
            def convert_folder(src,dst,log=print,copy_other=True,slot=None):return original()
            module=types.SimpleNamespace(convert_folder=convert_folder)
            reports.install(module,fallback_root=root/'fallback')
            with self.assertRaisesRegex(ValueError,'separate'):module.convert_folder(str(src),str(src/'out'),log=lambda _:None)
            original.assert_not_called();self.assertEqual(list(src.iterdir()),[])
            self.assertTrue(Path(reports.last_report_path()).is_relative_to(root/'fallback'))

    def test_success_retains_original_report_fields_and_updates_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'source';src.mkdir();dst=root/'out'
            def convert_folder(src,dst,log=print,copy_other=True,slot=None):return {'source':src,'output':dst,'problems':['unresolved physics'],'custom':'preserve'}
            module=types.SimpleNamespace(convert_folder=convert_folder);reports.install(module)
            result=module.convert_folder(str(src),str(dst),log=lambda _:None)
            self.assertEqual(result['custom'],'preserve');self.assertEqual(result['problems'],['unresolved physics'])
            self.assertTrue(Path(result['report_path']).is_file());self.assertIn('finished_at_utc',result)

    def test_atomic_failure_retains_previous_complete_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'report.json';path.write_text('{"previous": true}')
            with mock.patch.object(reports.os,'replace',side_effect=OSError('write denied')):
                with self.assertRaises(OSError):reports._atomic(path,{'new':'result'})
            self.assertEqual(json.loads(path.read_text()),{'previous':True})
            self.assertFalse(list(Path(tmp).glob('.conversion-report-*')))

    def test_legacy_and_intermediate_writes_deferred_until_final_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'source';src.mkdir();dst=root/'out'
            module=types.ModuleType('legacy_folder')
            exec('''import json, os
def convert_folder(src,dst,log=print,copy_other=True,slot=None):
    report={'source':src,'output':os.path.join(dst,'Characters','mod'),'problems':['hair flags failed']}
    with open(os.path.join(dst,'source - conversion report.json'),'w') as f:
        json.dump(report,f)
    from gmf_report import save_intermediate
    save_intermediate(report,dst)
    report['repair_wrapper_finished']=True
    return report
''',module.__dict__)
            reports.install(module)
            result=module.convert_folder(str(src),str(dst),log=lambda _:None)
            self.assertTrue(result['repair_wrapper_finished'])
            self.assertEqual(result['status'],'completed_with_problems')
            for path in result['report_paths']:
                self.assertEqual(json.loads(Path(path).read_text()),result)

    def test_original_exception_survives_even_when_temp_is_unwritable(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'source';src.mkdir();messages=[]
            def convert_folder(src,dst,log=print,copy_other=True,slot=None):
                raise ValueError('original native failure')
            module=types.SimpleNamespace(convert_folder=convert_folder)
            reports.install(module)
            with mock.patch.object(reports,'_atomic',side_effect=PermissionError('both locations denied')):
                with self.assertRaisesRegex(ValueError,'original native failure'):
                    module.convert_folder(str(src),str(root/'out'),log=messages.append)
            self.assertIsNone(reports.last_report_path())
            self.assertTrue(any('output or Temp' in text for text in messages))

    def test_path_resolution_error_also_uses_temp_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);report={'source':str(root/'source'),'output':str(root/'unavailable')}
            with mock.patch.object(Path,'resolve',side_effect=PermissionError('network path unavailable')):
                paths=reports.save_report(report,root/'unavailable',fallback_root=root/'fallback')
            self.assertTrue(Path(paths[0]).is_file())
            self.assertIn('network path unavailable',report['report_save_errors'][0]['error'])

    def test_postprocessing_failure_retains_finished_model_records(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'source';src.mkdir();dst=root/'out'
            def convert_folder(src,dst,log=print,copy_other=True,slot=None):
                report={'source':src,'output':str(Path(dst)/'Characters'/'mod'),
                        'models':[{'file':'610_Attire.mcd','verify':'fail'}],
                        'problems':['hair flags mismatch']}
                reports.save_intermediate(report,dst)
                raise ValueError('late postprocessing failure')
            module=types.SimpleNamespace(convert_folder=convert_folder);reports.install(module)
            with self.assertRaisesRegex(ValueError,'late postprocessing failure'):
                module.convert_folder(str(src),str(dst),log=lambda _:None)
            data=json.loads(Path(reports.last_report_path()).read_text())
            self.assertEqual(data['models'][0]['file'],'610_Attire.mcd')
            self.assertEqual(data['problems'],['hair flags mismatch','late postprocessing failure'])
