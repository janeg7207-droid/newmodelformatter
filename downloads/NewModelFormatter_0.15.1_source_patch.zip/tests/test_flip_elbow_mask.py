"""Exact-profile HPL-only extension guards, using the original mask writer."""
import copy
from pathlib import Path
import struct
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import gmf_flip_elbow_mask as elbow
from gmf_2k26_repair import game_folder, path_hash
from gmf_native_assets import write_library
from gmf_native_masks import envelopes, splice_mask
from test_local_textures import reference_writer
from test_mask_recovery import pure_mcd
from test_native_missing_data import container


def mesh(name, role, count, offset=0.):
    return SimpleNamespace(name=name, num_verts=count, scene_flag=128, motion_flag=10000,
        positions=np.arange(count * 3, dtype=np.float32).reshape(count, 3) + offset,
        triangles=np.asarray([[0, 1, 2]], dtype=np.uint32), vertex_remap=np.arange(count, dtype=np.uint32),
        normals=np.ones((count, 3), dtype=np.float32), tangents=np.zeros((count, 4), dtype=np.float32),
        uvs=[np.zeros((count, 2), dtype=np.float32)], colors=[],
        weights={'J_Elbow_L': np.ones(count, dtype=np.float32)}, face_groups=[(role, 0, 1)])


class FlipElbowMaskTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.writer = staticmethod(reference_writer().write_jmtl)

    def fixture(self, root, *, native=False, already=False):
        mcd = pure_mcd()
        source_root = root / 'input'; output_root = root / 'output'
        source = source_root / '931_Flip' / '931_Default_Attire' / '931_Attire.mcd'
        target = output_root / 'Characters' / '931_Flip' / '931_Default_Attire' / '931_Attire.mcd'
        source_base = source.parent.parent / 'BaseModel' / 'baseModel.mcd'
        output_base = target.parent.parent / 'BaseModel' / 'baseModel.mcd'
        for path in (source, target, source_base, output_base): path.parent.mkdir(parents=True, exist_ok=True)
        authored = mcd.build_hpl({0: [('M_Body', [0, 1])], 1: [('M_Body', [0, 1])]})
        extended = mcd.build_hpl({0: [('M_Body', [0, 1, 4])], 1: [('M_Body', [0, 1, 4])]})
        old = container(authored); new = splice_mask(old, extended)
        source.write_bytes((new if already else old) if native else b'controlled exact legacy attire source')
        target.write_bytes(new if already else old)
        source_base.write_bytes(container() if native else b'controlled exact legacy base source')
        output_base.write_bytes(container())
        source_hpl = source.with_suffix('.hpl'); source_hpl.write_bytes(b'controlled exact unchanged original sidecar')
        body = mesh('M_Body', 'body', 6)
        left = mesh('M_L_Elbowpad', 'l_elbowpad', 3, 1.)
        right = mesh('M_L_Elbowpad', 'r_elbowpad', 3, -1.)
        base_model = SimpleNamespace(version=47, meshes=[body], substreams=[])
        attire_model = SimpleNamespace(version=47, meshes=[left, right], substreams=[(b'HPL!', authored)])
        table = target.with_suffix('.mtls'); materials = target.parent / 'Materials'; materials.mkdir()
        entries = []
        for index, role in enumerate(('l_elbowpad', 'r_elbowpad')):
            data = self.writer(0x15, {'colorMap@ref': 11 + index, 'nrMap@ref': 21 + index,
                'g_specIntensity': 1., 'irradianceR': 0., 'irradianceG': 192. / 255., 'irradianceB': 192. / 255.})
            self.assertEqual(len(data), 184); (materials / (role + '.jmtl')).write_bytes(data)
            entries.append({'name': role, 'path_hash': path_hash(game_folder(table) + '/Materials/' + role + '.jmtl')})
        table.write_bytes(write_library(entries))
        record = {'source': str(source), 'output': str(target), 'verify': 'pass',
                  'status': 'preserved_2k26' if native else 'converted', 'source_version': 47 if native else '0x29',
                  'problems': [], 'notes': [], 'facts': {'hide_mask': 'mask', 'byte_identical': native,
                    'output_sha256': elbow.fingerprint(target.read_bytes())[0]}}
        recovery = {'profile': 'controlled authored restoration', 'written_hpl_sha256': elbow.fingerprint(authored)[0],
                    'coverage_generated': False, 'source_supplied_hpl_sha256': 'original authored source',
                    'source_invalid_sidecar_sha256': elbow.fingerprint(source_hpl.read_bytes())[0]}
        if not native:
            record['supplied_hide_mask_recovery'] = copy.deepcopy(recovery)
            record['facts']['supplied_hide_mask_recovery'] = copy.deepcopy(recovery)
        record['face_output_audit'] = {'output_sha256': elbow.fingerprint(target.read_bytes())[0]}
        paired = {'source': str(source_base), 'output': str(output_base), 'verify': 'pass', 'status': 'converted'}
        report = {'source': str(source_root), 'output': str(output_root), 'models': [paired, record],
                  'materials': [{'source': str(source.with_suffix('.mtls')), 'output': str(table), 'status': 'converted'}],
                  'warnings': [], 'problems': [], 'native_2k26_models_preserved': 1 if native else 0,
                  'physics_binding_audit': {'rows': [{'paired_models': [{'file': str(target),
                                                                       'sha256': elbow.fingerprint(target.read_bytes())[0]}]}]}}
        profile = {'attire_prefix': elbow.fingerprint(elbow._mask_frame(old)[1]),
                   'source_attire_allowed': [elbow.fingerprint(source.read_bytes()), elbow.fingerprint(old), elbow.fingerprint(new)],
                   'source_base_allowed': [elbow.fingerprint(source_base.read_bytes()), elbow.fingerprint(output_base.read_bytes())],
                   'output_base_allowed': [elbow.fingerprint(output_base.read_bytes())],
                   'authored_hpl': elbow.fingerprint(authored), 'extended_hpl': elbow.fingerprint(extended),
                   'extended_attire': elbow.fingerprint(new), 'body_mesh_sha256': elbow.mesh_fingerprint(body),
                   'pad_mesh_sha256': {'l_elbowpad': elbow.mesh_fingerprint(left), 'r_elbowpad': elbow.mesh_fingerprint(right)},
                   'source_hpl_allowed': [elbow.fingerprint(source_hpl.read_bytes())],
                   'selected_ids': [4], 'selected_ids_fingerprint': elbow.fingerprint(struct.pack('<I', 4)),
                   'authored_id_count': 2, 'selection_proof_sha256': 'controlled-reviewed-static-coverage-proof'}
        failure = {'staged': False, 'mutate_source': False}
        def read_model(path, **kwargs):
            path = Path(path)
            if path == output_base: return copy.deepcopy(base_model)
            if path.parent == target.parent and path.suffix == '.mcd':
                staged = path != target
                if staged and failure['staged']: raise ValueError('native staged reader refused')
                if staged and failure['mutate_source']: source.write_bytes(b'changed by another process')
                model = copy.deepcopy(attire_model)
                model.substreams = [(frame['tag'], frame['payload']) for frame in envelopes(path.read_bytes())]
                return model
            raise ValueError('unrecognized controlled native path')
        reader = SimpleNamespace(read_model=Mock(side_effect=read_model))
        return SimpleNamespace(root=root, source_root=source_root, output_root=output_root, source=source, target=target,
            source_base=source_base, output_base=output_base, source_hpl=source_hpl, authored=authored, extended=extended,
            old=old, new=new, body=body, left=left, right=right, base_model=base_model, attire_model=attire_model,
            table=table, record=record, paired=paired, report=report, profile=profile, mcd=mcd, reader=reader, failure=failure)

    def run_process(self, fixture):
        with patch.object(elbow, 'profile', return_value=copy.deepcopy(fixture.profile)):
            return elbow.process(fixture.report, fixture.source_root, fixture.output_root,
                                 fixture.reader, fixture.mcd, writer=self.writer)

    def snapshot(self, root):
        return {str(path): path.read_bytes() for path in root.rglob('*') if path.is_file()}

    def test_pending_profile_performs_no_asset_reads_or_writes(self):
        report = {'models': [{'output': 'some model'}]}
        with patch.object(elbow, 'profile', return_value=None), patch.object(Path, 'read_bytes', side_effect=AssertionError('read')):
            result = elbow.process(report, 'src', 'dst', None, None)
        self.assertEqual(result['state'], 'inactive_candidate_proof_not_frozen_no_asset_reads_or_writes')

    def test_frozen_actual_484_ids_extend_exact_authored_4378_prefix_at_both_flags_all_five_lods(self):
        import gmf_flip_supplied_mask as supplied
        p = elbow.profile(); mcd = pure_mcd()
        ids = p['selected_ids']
        self.assertEqual(len(ids), 484)
        self.assertEqual(elbow.fingerprint(struct.pack('<' + 'I' * len(ids), *ids)), tuple(p['selected_ids_fingerprint']))
        authored = mcd.build_hpl(mcd.parse_hpl(supplied.supplied_hpl())[0])
        self.assertEqual(elbow.fingerprint(authored), tuple(p['authored_hpl']))
        extended, count = elbow.extend_mask(authored, mcd, set(range(12755)), ids)
        self.assertEqual(count, 4378); self.assertEqual(elbow.fingerprint(extended), tuple(p['extended_hpl']))
        original = mcd.parse_hpl(authored); written = mcd.parse_hpl(extended)
        self.assertEqual(set(written), set(range(5)))
        for lod, flags in written.items():
            self.assertEqual(set(flags), {0, 1})
            for flag, groups in flags.items():
                self.assertEqual(groups[0][1][:4378], original[lod][flag][0][1])
                self.assertEqual(groups[0][1][4378:], ids)
                self.assertEqual(len(set(groups[0][1])), 4862)

    def test_only_existing_hpl_tail_changes_and_every_original_id_flag_and_lod_is_retained(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); before = self.snapshot(f.root); result = self.run_process(f)
            self.assertEqual(result['applied'], 1); self.assertEqual(result['refused'], 0)
            self.assertEqual(f.target.read_bytes(), f.new)
            self.assertEqual(elbow._mask_frame(f.old)[1], elbow._mask_frame(f.new)[1])
            after = self.snapshot(f.root)
            self.assertEqual({p: data for p, data in before.items() if p != str(f.target)},
                             {p: data for p, data in after.items() if p != str(f.target)})
            parsed = f.mcd.parse_hpl(elbow._mask_frame(f.target.read_bytes())[0])
            self.assertEqual(set(parsed), set(range(5)))
            for flags in parsed.values():
                self.assertEqual(set(flags), {0, 1})
                self.assertEqual(flags[0], [('M_Body', [0, 1, 4])]); self.assertEqual(flags[1], flags[0])
            proof = result['rows'][0]
            self.assertTrue(proof['every_non_hpl_byte_preserved']); self.assertTrue(proof['native_reader_passed'])
            self.assertFalse(proof['animated_pad_coverage_and_appearance_proved'])
            self.assertEqual(proof['authored_ids_preserved'], 2); self.assertEqual(proof['generated_added_ids'], 1)

    def test_historical_authored_recovery_and_current_final_hashes_are_distinguished(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); recovery = copy.deepcopy(f.record['supplied_hide_mask_recovery'])
            result = self.run_process(f); final = elbow.fingerprint(f.new)[0]
            self.assertEqual(f.record['facts']['output_sha256'], final)
            self.assertEqual(f.record['facts']['written_hpl_sha256'], elbow.fingerprint(f.extended)[0])
            for prior in (f.record['supplied_hide_mask_recovery'], f.record['facts']['supplied_hide_mask_recovery']):
                self.assertEqual(prior['written_hpl_sha256'], recovery['written_hpl_sha256'])
                self.assertFalse(prior['coverage_generated']); self.assertIn('historical', prior['output_byte_proof_stage'])
                self.assertTrue(prior['following_exact_elbow_mask_extension']['coverage_generated'])
            self.assertEqual(f.record['face_output_audit']['output_sha256'], final)
            paired = f.report['physics_binding_audit']['rows'][0]['paired_models'][0]
            self.assertEqual(paired['sha256'], final); self.assertEqual(paired['before_exact_flip_elbow_extension_sha256'], elbow.fingerprint(f.old)[0])
            self.assertEqual(f.record['verify'], 'pass'); self.assertTrue(f.report['experimental_flip_elbow_mask_game_check'])
            self.assertEqual(f.report['conversion_completeness'], 'incomplete'); self.assertTrue(f.report['problems'])

    def test_native_repeat_does_not_write_or_decrement_preservation_counters(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp), native=True, already=True); before = self.snapshot(f.root)
            with patch.object(elbow, 'staged_mask', side_effect=AssertionError('idempotent path must not stage')):
                result = self.run_process(f)
            self.assertEqual(result['already_applied'], 1); self.assertEqual(result['applied'], 0)
            self.assertEqual(self.snapshot(f.root), before)
            self.assertEqual(f.report['native_2k26_models_preserved'], 1)
            self.assertTrue(f.record['facts']['byte_identical'])

    def test_native_current_mask_repair_changes_preserved_counter_once(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp), native=True); self.run_process(f)
            self.assertEqual(f.report['native_2k26_models_preserved'], 0)
            self.assertEqual(f.report['native_2k26_masks_repaired'], 1)

    def test_known_source_changed_output_prefix_custom_mask_and_missing_mask_refuse_without_writes(self):
        for scenario in ('prefix', 'custom_mask', 'empty_mask', 'no_mask'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp))
                if scenario == 'prefix': f.target.write_bytes(f.old.replace(b'original geometry', b'replaced geometry'))
                elif scenario == 'custom_mask': f.target.write_bytes(splice_mask(f.old, f.mcd.build_hpl({0: [('M_Body', [2])]})))
                elif scenario == 'empty_mask': f.target.write_bytes(splice_mask(f.old, f.mcd.EMPTY_HPL))
                else: f.target.write_bytes(container())
                before = self.snapshot(f.root); result = self.run_process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(result['applied'], 0)
                self.assertEqual(self.snapshot(f.root), before)

    def test_unrelated_source_and_output_are_ignored_without_creating_a_mask(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); f.source.write_bytes(b'unrelated source')
            f.target.write_bytes(container()); before = self.snapshot(f.root); result = self.run_process(f)
            self.assertEqual(result['applied'], 0); self.assertEqual(result['refused'], 0)
            self.assertEqual(self.snapshot(f.root), before)

    def test_wrong_source_pair_failed_base_changed_model_geometry_or_weights_refuse(self):
        for scenario in ('source_attire', 'source_base', 'output_base', 'record_fail', 'base_fail', 'missing_base_record',
                         'body_remap', 'body_weights', 'pad_positions', 'duplicate_pad_role', 'wrong_pad_role'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp))
                if scenario == 'source_attire': f.source.write_bytes(b'other attire')
                elif scenario == 'source_base': f.source_base.write_bytes(b'other source base')
                elif scenario == 'output_base': f.output_base.write_bytes(b'other output base')
                elif scenario == 'record_fail': f.record['verify'] = 'fail'
                elif scenario == 'base_fail': f.paired['verify'] = 'fail'
                elif scenario == 'missing_base_record': f.report['models'].remove(f.paired)
                elif scenario == 'body_remap': f.body.vertex_remap[[0, 1]] = f.body.vertex_remap[[1, 0]]
                elif scenario == 'body_weights': f.body.weights['J_Elbow_L'][0] = .5
                elif scenario == 'pad_positions': f.left.positions[0, 0] += .1
                elif scenario == 'duplicate_pad_role': f.attire_model.meshes.append(copy.deepcopy(f.left))
                else: f.right.face_groups = [('l_elbowpad', 0, 1)]
                before = self.snapshot(f.root); result = self.run_process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(self.snapshot(f.root), before)

    def test_conflicting_target_sidecar_changed_source_sidecar_and_symlinks_refuse(self):
        for scenario in ('output_hpl', 'source_hpl', 'target_symlink', 'base_symlink', 'materials_symlink'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); outside = f.root / 'outside'; outside.mkdir()
                if scenario == 'output_hpl': f.target.with_suffix('.hpl').write_bytes(f.authored)
                elif scenario == 'source_hpl': f.source_hpl.write_bytes(b'custom mask')
                elif scenario in ('target_symlink', 'base_symlink'):
                    path = f.target if scenario == 'target_symlink' else f.output_base
                    actual = outside / path.name; actual.write_bytes(path.read_bytes()); path.unlink(); path.symlink_to(actual)
                else:
                    import shutil
                    path = f.target.parent / 'Materials'; shutil.move(str(path), str(outside / 'Materials'))
                    path.symlink_to(outside / 'Materials', target_is_directory=True)
                before = self.snapshot(f.root); result = self.run_process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(self.snapshot(f.root), before)

    def test_pad_alpha_material_wrong_hash_changed_scalar_or_missing_material_refuse(self):
        for scenario in ('alpha', 'scalar', 'missing', 'table_hash'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); path = f.target.parent / 'Materials' / 'l_elbowpad.jmtl'
                if scenario in ('alpha', 'scalar'):
                    params = {'colorMap@ref': 11, 'nrMap@ref': 21, 'g_specIntensity': .5 if scenario == 'scalar' else 1.,
                              'irradianceR': 0., 'irradianceG': 192. / 255., 'irradianceB': 192. / 255.}
                    if scenario == 'alpha': params['variant'] = 2
                    path.write_bytes(self.writer(0x15, params))
                elif scenario == 'missing': path.unlink()
                else:
                    from gmf_2k26_repair import read_native_library
                    entries = read_native_library(f.table.read_bytes()); entries[0]['path_hash'] = 123
                    f.table.write_bytes(write_library(entries))
                before = self.snapshot(f.root); result = self.run_process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(self.snapshot(f.root), before)

    def test_changed_selected_ids_proof_output_digest_or_mask_domains_refuse(self):
        for scenario in ('index_sha', 'index_domain', 'hpl_sha', 'model_sha'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp))
                if scenario == 'index_sha': f.profile['selected_ids_fingerprint'] = ('0' * 64, 4)
                elif scenario == 'index_domain':
                    f.profile['selected_ids'] = [99]; f.profile['selected_ids_fingerprint'] = elbow.fingerprint(struct.pack('<I', 99))
                elif scenario == 'hpl_sha': f.profile['extended_hpl'] = ('0' * 64, len(f.extended))
                else: f.profile['extended_attire'] = ('0' * 64, len(f.new))
                before = self.snapshot(f.root); result = self.run_process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(self.snapshot(f.root), before)

    def test_native_stage_refusal_or_source_change_during_stage_never_replaces_target(self):
        for scenario in ('staged', 'mutate_source'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); f.failure[scenario] = True; result = self.run_process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(f.target.read_bytes(), f.old)
                self.assertFalse(list(f.target.parent.glob('.native-mask-*')))

    def test_inconsistent_recovery_metadata_refuses_before_output_write(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); f.record['facts']['supplied_hide_mask_recovery']['written_hpl_sha256'] = 'other'
            before = self.snapshot(f.root); result = self.run_process(f)
            self.assertEqual(result['refused'], 1); self.assertEqual(self.snapshot(f.root), before)

    def test_malformed_report_containers_and_consumed_audit_metadata_refuse_before_stage(self):
        for scenario in ('models', 'materials', 'physics', 'paired_models', 'native_masks', 'counter'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp))
                if scenario in ('models', 'materials'): f.report[scenario] = {'bad': 'container'}
                elif scenario == 'physics': f.report['physics_binding_audit'] = ['bad']
                elif scenario == 'paired_models': f.report['physics_binding_audit']['rows'][0]['paired_models'] = {'bad': 'container'}
                elif scenario == 'native_masks': f.record['native_missing_data_audit'] = {'masks': ['bad']}
                else: f.report['native_2k26_models_preserved'] = 'bad'
                before = self.snapshot(f.root)
                with patch.object(elbow, 'staged_mask', side_effect=AssertionError('invalid metadata must precede writes')):
                    result = self.run_process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(self.snapshot(f.root), before)

    def test_prior_native_mask_counts_and_physics_model_sizes_describe_the_extended_output(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp), native=True)
            f.record['native_missing_data_audit'] = {'masks': {'state': 'readable_indices_valid',
                'counts': {'0': {'0': {'M_Body': 2}}}}}
            paired = f.report['physics_binding_audit']['rows'][0]['paired_models'][0]; paired['bytes'] = len(f.old)
            self.run_process(f); mask_audit = f.record['native_missing_data_audit']['masks']
            self.assertEqual(mask_audit['before_exact_flip_elbow_extension']['counts'], {'0': {'0': {'M_Body': 2}}})
            for flags in mask_audit['counts'].values():
                self.assertEqual(flags, {'0': {'M_Body': 3}, '1': {'M_Body': 3}})
            self.assertEqual(paired['bytes'], len(f.new)); self.assertEqual(paired['before_exact_flip_elbow_extension_bytes'], len(f.old))

    def test_postcommit_report_error_is_described_as_applied_with_error(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp))
            with patch.object(elbow, '_updates', side_effect=ValueError('report failed')):
                result = self.run_process(f)
            self.assertEqual(result['failed_after_write'], 1); self.assertEqual(result['refused'], 0)
            self.assertEqual(f.target.read_bytes(), f.new)
            self.assertEqual(result['rows'][0]['state'], 'applied_with_verification_or_reporting_error')

    def test_install_once_keeps_folder_io_and_saves_report(self):
        report = {'models': []}
        def convert_folder(src, dst, log=lambda text: None): return report
        folder = SimpleNamespace(convert_folder=convert_folder, vc=None, mcd=None)
        elbow.install(folder); first = folder.convert_folder; elbow.install(folder)
        self.assertIs(folder.convert_folder, first)
        with patch.object(elbow, 'profile', return_value=None), patch('gmf_report.save_intermediate') as save:
            self.assertIs(folder.convert_folder('source', 'output'), report)
        save.assert_called_once_with(report, 'output')


if __name__ == '__main__':
    unittest.main()
