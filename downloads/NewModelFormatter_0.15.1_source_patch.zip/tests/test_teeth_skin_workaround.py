"""The optional workaround recreates a real skin schema and preserves assets."""
import copy
import hashlib
from pathlib import Path
import struct
import sys
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import gmf_teeth_skin_workaround as teeth
from gmf_2k26_repair import game_folder, path_hash, read_native_library
from gmf_jmtl_audit import Table, inspect_material
from gmf_native_assets import write_library
from test_local_textures import dds, reference_writer


def sha(data):
    return hashlib.sha256(data).hexdigest()


class TeethSkinWorkaroundTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.writer_module = reference_writer()
        cls.write = staticmethod(cls.writer_module.write_jmtl)

    def setUp(self):
        teeth.set_enabled(True)
        self.addCleanup(teeth.set_enabled, False)

    def fixture(self, root, *, shader=0x1a, nested=False, native=False):
        src = root / 'source'; dst = root / 'output'
        source = src / 'BaseModel' / 'baseModel.mcd'
        target = dst / 'Characters' / 'controlled' / 'BaseModel' / 'baseModel.mcd'
        if nested:
            target = dst / 'Characters' / 'outer' / 'Characters' / 'INPUT' / 'controlled' / 'BaseModel' / 'baseModel.mcd'
        source.parent.mkdir(parents=True); target.parent.mkdir(parents=True)
        source.write_bytes(b'original model remains untouched'); target.write_bytes(b'verified native model remains untouched')
        refs = {key: path_hash(game_folder(target) + '/Textures/' + name + '.tex')
                for name, key in (('body_color', 'colorMap@ref'), ('body_nrm', 'nrMap@ref'))}
        for folder in (source.parent, target.parent):
            (folder / 'Materials').mkdir(); (folder / 'Textures').mkdir()
            for name in ('body_color.dds', 'body_nrm.dds'):
                (folder / 'Textures' / name).write_bytes(dds(width=8, height=8, mips=4, dxgi=98))
            (folder / 'Materials' / 'mouthbag.jmtl').write_bytes(self.write(0x1a, dict(refs)))
            (folder / 'Materials' / 'body.jmtl').write_bytes(self.write(0x19, dict(refs)))
            (folder / 'Materials' / 'teeth.jmtl').write_bytes(self.write(shader, {**refs,
                'irradianceR': 1., 'irradianceG': .75, 'irradianceB': .75}))
            entries = [{'name': name, 'path_hash': path_hash(game_folder(target) + '/Materials/' + name + '.jmtl')}
                       for name in ('body', 'teeth', 'mouthbag')]
            folder.joinpath('baseModel.mtls').write_bytes(write_library(entries))
        path = target.parent / 'Materials' / 'teeth.jmtl'; raw = path.read_bytes()
        row = {'source': str(source), 'output': str(target), 'verify': 'pass',
               'status': 'preserved_2k26' if native else 'converted'}
        material = {'source': str(source.with_suffix('.mtls')), 'output': str(target.with_suffix('.mtls')),
                    'status': 'preserved_2k26' if native else 'converted',
                    'materials': [{'name': 'teeth', 'shader_2k25': 'yCh_Teeth / Normal',
                                   'shader_2k26': hex(shader), 'textures': ['colorMap@ref', 'nrMap@ref']}],
                    'written_material_payload_audit': [{'name': 'teeth', 'file': str(path), 'state': 'payload_inspected',
                                                       'sha256': sha(raw), **inspect_material(raw)}],
                    'jmtl_payloads': 'byte_identical source copies',
                    'dependencies': [{'source': str(source.parent / 'Materials' / 'teeth.jmtl'),
                                      'output': str(path), 'sha256': sha(raw), 'bytes': len(raw), 'byte_identical': True}]}
        report = {'source': str(src), 'output': str(dst), 'models': [row], 'materials': [material],
                  'problems': [], 'warnings': []}
        model = SimpleNamespace(version=47, meshes=[SimpleNamespace(name='M_Teeth', num_verts=8,
            face_groups=[('teeth', 0, 6)]), SimpleNamespace(name='M_Body', num_verts=12,
            face_groups=[('body', 0, 12)])])
        reader = SimpleNamespace(read_model=Mock(return_value=model))
        return src, dst, source, target, path, refs, reader, row, material, report

    def process(self, fixture, **kwargs):
        src, dst, source, target, path, refs, reader, row, material, report = fixture
        return teeth.process(report, src, dst, reader, writer=self.write, **kwargs)

    def add_mouthbag_role(self, f, *, tongue=True):
        model = f[6].read_model.return_value
        model.meshes[1] = SimpleNamespace(name='M_MouthBag', num_verts=12, face_groups=[('mouthbag', 0, 12)])
        if tongue:
            model.meshes.append(SimpleNamespace(name='M_Tongue', num_verts=10, face_groups=[('mouthbag', 0, 8)]))
        path = f[3].parent / 'Materials' / 'mouthbag.jmtl'; raw = path.read_bytes()
        f[8]['materials'].append({'name': 'mouthbag', 'shader_2k25': 'yCh_Teeth / Normal',
                                 'shader_2k26': '0x1a', 'textures': ['colorMap@ref', 'nrMap@ref']})
        f[8]['written_material_payload_audit'].append({'name': 'mouthbag', 'file': str(path),
            'state': 'payload_inspected', 'sha256': sha(raw), **inspect_material(raw)})
        return f

    def snapshots(self, root):
        return {str(path): path.read_bytes() for path in root.rglob('*') if path.is_file()}

    def test_real_writer_recreates_skin_not_discriminator_flip_and_preserves_every_other_asset(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); path, refs, report = f[4], f[5], f[-1]
            before = self.snapshots(Path(temp)); old = path.read_bytes()
            result = self.process(f); new = path.read_bytes()
            self.assertEqual(result['applied'], 1); self.assertEqual(result['refused'], 0)
            self.assertEqual(new, self.write(0x19, refs)); self.assertNotEqual(len(new), len(old))
            self.assertEqual(inspect_material(new)['shader_byte'], 0x19)
            self.assertEqual({r['field']: r['hash'] for r in inspect_material(new)['texture_references']}, refs)
            p = Table(new, struct.unpack_from('<I', new)[0]).child(2)
            for slot in (0, 1, 6, 9, 15, 18):
                self.assertIsNotNone(p.field(slot, 8 if slot in (0, 1) else 4))
            self.assertIsNotNone(p.child(6)); self.assertIsNotNone(p.child(9)); self.assertIsNotNone(p.child(18))
            after = self.snapshots(Path(temp))
            self.assertEqual({k: v for k, v in before.items() if k != str(path)},
                             {k: v for k, v in after.items() if k != str(path)})
            evidence = result['rows'][0]
            self.assertEqual(evidence['before_sha256'], sha(old)); self.assertEqual(evidence['after_sha256'], sha(new))
            self.assertEqual(evidence['original_present_fields']['6'], {'0': 255, '1': 191, '2': 191})
            self.assertFalse(evidence['black_teeth_fix_proved']); self.assertEqual(evidence['in_game_validation'], 'not_performed')
            self.assertTrue(report['experimental_teeth_skin_game_check']); self.assertTrue(report['warnings'])

    def test_metadata_preserves_original_copy_and_shader_evidence_while_refreshing_actual_payload(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp), native=True); before = f[4].read_bytes(); material = f[8]
            original = copy.deepcopy(material); self.process(f); after = f[4].read_bytes()
            audit = material['written_material_payload_audit'][0]
            self.assertEqual(audit['sha256'], sha(after)); self.assertEqual(audit['shader_byte'], 0x19)
            self.assertEqual(audit['teeth_skin_workaround_prior_evidence']['sha256'], sha(before))
            self.assertEqual(audit['teeth_skin_workaround_prior_evidence']['shader_byte'], 0x1a)
            self.assertIn('face_texture_check', audit['teeth_skin_workaround_prior_evidence'])
            self.assertNotIn('face_texture_check', audit)
            entry = material['materials'][0]
            self.assertEqual(entry['shader_2k26'], '0x19'); self.assertEqual(entry['shader_2k25'], 'yCh_Teeth / Normal')
            self.assertEqual(entry['teeth_skin_workaround_prior_material'], original['materials'][0])
            copied = material['dependencies'][0]
            self.assertEqual(copied['source_sha256'], sha(before)); self.assertEqual(copied['output_sha256'], sha(after))
            self.assertFalse(copied['byte_identical']); self.assertEqual(copied['bytes'], len(after))
            self.assertTrue(copied['teeth_skin_workaround_prior_evidence']['byte_identical'])
            self.assertEqual(material['teeth_skin_workaround_prior_jmtl_payloads'], original['jmtl_payloads'])

    def test_existing_skin_with_same_local_refs_is_idempotent_without_invoking_writer(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); self.process(f); snapshot = self.snapshots(Path(temp))
            writer = Mock(side_effect=AssertionError('existing skin must not be rewritten'))
            result = teeth.process(f[-1], f[0], f[1], f[6], writer=writer)
            self.assertEqual(result['already_applied'], 1); self.assertEqual(result['applied'], 0)
            writer.assert_not_called(); self.assertEqual(self.snapshots(Path(temp)), snapshot)

    def test_both_body_atlas_roles_are_recreated_and_tongue_shares_only_mouthbag(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.add_mouthbag_role(self.fixture(Path(temp))); before = self.snapshots(Path(temp))
            changed = {str(f[4]), str(f[3].parent / 'Materials' / 'mouthbag.jmtl')}
            result = self.process(f); after = self.snapshots(Path(temp))
            self.assertEqual(result['applied'], 2); self.assertEqual(result['refused'], 0)
            self.assertEqual({row['role'] for row in result['rows']}, {'teeth', 'mouthbag'})
            self.assertEqual(result['rows'][1]['bound_meshes'], ['M_MouthBag', 'M_Tongue'])
            self.assertEqual({key: value for key, value in before.items() if key not in changed},
                             {key: value for key, value in after.items() if key not in changed})
            for role in ('teeth', 'mouthbag'):
                path = f[3].parent / 'Materials' / (role + '.jmtl')
                self.assertEqual(path.read_bytes(), self.write(0x19, f[5]))
                audit = next(row for row in f[8]['written_material_payload_audit'] if row['name'] == role)
                self.assertEqual(audit['shader_byte'], 0x19); self.assertEqual(audit['sha256'], sha(path.read_bytes()))
                self.assertNotIn('face_texture_check', audit)
                entry = next(row for row in f[8]['materials'] if row['name'] == role)
                self.assertEqual(entry['shader_2k26'], '0x19')
                self.assertEqual(entry['teeth_skin_workaround_prior_material']['shader_2k26'], '0x1a')
            self.assertEqual(set(f[7]['body_atlas_skin_workaround']), {'teeth', 'mouthbag'})
            self.assertNotIn('model_mtls_and_mouthbag_unchanged', result['rows'][0])

    def test_both_roles_are_idempotent_and_mixed_existing_skin_preserves_its_authored_defaults(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.add_mouthbag_role(self.fixture(Path(temp), shader=0x19))
            first_teeth = f[4].read_bytes(); result = self.process(f)
            self.assertEqual(result['applied'], 1); self.assertEqual(result['already_applied'], 1)
            self.assertEqual(f[4].read_bytes(), first_teeth)
            snapshot = self.snapshots(Path(temp)); writer = Mock(side_effect=AssertionError('skin must not be rewritten'))
            repeated = teeth.process(f[-1], f[0], f[1], f[6], writer=writer)
            self.assertEqual(repeated['already_applied'], 2); self.assertEqual(repeated['applied'], 0)
            writer.assert_not_called(); self.assertEqual(self.snapshots(Path(temp)), snapshot)

    def test_mouthbag_shared_with_arbitrary_mesh_is_refused_without_changing_that_role(self):
        for name in ('M_Body', 'M_Teeth', 'Object5'):
            with self.subTest(mesh=name), tempfile.TemporaryDirectory() as temp:
                f = self.add_mouthbag_role(self.fixture(Path(temp)))
                f[6].read_model.return_value.meshes.append(SimpleNamespace(name=name, num_verts=3,
                    face_groups=[('mouthbag', 0, 1)]))
                mouthbag = f[3].parent / 'Materials' / 'mouthbag.jmtl'; before = mouthbag.read_bytes()
                result = self.process(f); row = next(row for row in result['rows'] if row['role'] == 'mouthbag')
                self.assertEqual(row['state'], 'refused'); self.assertIn('unsupported mesh', row['reason'])
                self.assertEqual(mouthbag.read_bytes(), before)

    def test_invalid_mouthbag_shader_or_texture_pair_refuses_only_that_role(self):
        for scenario in ('wrong_shader', 'wrong_texture_pair', 'truncated', 'wrong_table_hash'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = self.add_mouthbag_role(self.fixture(Path(temp)))
                mouthbag = f[3].parent / 'Materials' / 'mouthbag.jmtl'
                if scenario == 'wrong_shader': mouthbag.write_bytes(self.write(0x12, f[5]))
                elif scenario == 'wrong_texture_pair': mouthbag.write_bytes(self.write(0x1a, {**f[5], 'colorMap@ref': 123}))
                elif scenario == 'truncated': mouthbag.write_bytes(mouthbag.read_bytes()[:-1])
                else:
                    table = f[3].with_suffix('.mtls'); entries = read_native_library(table.read_bytes())
                    entries[2]['path_hash'] = 123; table.write_bytes(write_library(entries))
                before = mouthbag.read_bytes(); result = self.process(f)
                self.assertEqual(result['applied'], 1); self.assertEqual(result['refused'], 1)
                self.assertEqual(next(row for row in result['rows'] if row['role'] == 'mouthbag')['state'], 'refused')
                self.assertEqual(mouthbag.read_bytes(), before); self.assertEqual(inspect_material(f[4].read_bytes())['shader_byte'], 0x19)

    def test_mouthbag_may_be_bound_only_by_tongue_and_no_teeth_role_is_synthesized(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.add_mouthbag_role(self.fixture(Path(temp)))
            f[6].read_model.return_value.meshes = [f[6].read_model.return_value.meshes[-1]]
            teeth_before = f[4].read_bytes(); result = self.process(f)
            self.assertEqual(result['applied'], 1); self.assertEqual(result['not_applicable'], 1)
            self.assertEqual(f[4].read_bytes(), teeth_before)
            self.assertEqual(result['rows'][1]['bound_meshes'], ['M_Tongue'])

    def test_disabled_has_no_file_reads_no_reader_calls_and_no_writer_calls(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); snapshot = self.snapshots(Path(temp)); teeth.set_enabled(False)
            writer = Mock()
            with patch.object(Path, 'read_bytes', side_effect=AssertionError('disabled reads')), \
                 patch.object(teeth, 'atomic_bytes', side_effect=AssertionError('disabled writes')):
                result = teeth.process(f[-1], f[0], f[1], f[6], writer=writer)
            self.assertEqual(result['state'], 'disabled_no_asset_reads_or_writes')
            f[6].read_model.assert_not_called(); writer.assert_not_called()
            self.assertEqual(self.snapshots(Path(temp)), snapshot)

    def test_explicit_selection_is_thread_local_and_new_threads_default_off(self):
        states = []
        def other():
            states.append(teeth.is_enabled()); teeth.set_enabled(True); states.append(teeth.is_enabled())
            teeth.set_enabled(False)
        worker = threading.Thread(target=other); worker.start(); worker.join()
        self.assertEqual(states, [False, True]); self.assertTrue(teeth.is_enabled())

    def test_innermost_characters_namespace_is_used_without_rewriting_valid_links(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp), nested=True); original = f[3].with_suffix('.mtls').read_bytes()
            result = self.process(f)
            self.assertEqual(result['applied'], 1)
            self.assertEqual(f[3].with_suffix('.mtls').read_bytes(), original)
            self.assertEqual(result['rows'][0]['local_body_textures'][0]['virtual_path'],
                             'Characters/INPUT/controlled/BaseModel/Textures/body_color.tex')

    def test_missing_invalid_wrong_bound_or_ambiguous_dds_refuses_without_asset_changes(self):
        for scenario in ('missing', 'invalid', 'wrong_refs', 'case_collision'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); texture = f[3].parent / 'Textures' / 'body_color.dds'
                if scenario == 'missing': texture.unlink()
                elif scenario == 'invalid': texture.write_bytes(b'corrupt DDS')
                elif scenario == 'wrong_refs': f[4].write_bytes(self.write(0x1a, {**f[5], 'colorMap@ref': 123}))
                else: texture.with_name('BODY_COLOR.DDS').write_bytes(texture.read_bytes())
                before = self.snapshots(Path(temp)); result = self.process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(result['applied'], 0)
                self.assertEqual(self.snapshots(Path(temp)), before)

    def test_native_table_missing_wrong_hash_inline_or_case_collision_refuses(self):
        for scenario in ('missing', 'wrong_hash', 'inline', 'case_collision', 'missing_teeth'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); table = f[3].with_suffix('.mtls')
                entries = read_native_library(table.read_bytes())
                if scenario == 'missing': table.unlink()
                elif scenario == 'inline': table.write_bytes(b'MTLs' + bytes(50))
                else:
                    if scenario == 'wrong_hash': entries[1]['path_hash'] = 123
                    elif scenario == 'case_collision': entries[1]['name'] = 'Teeth'
                    else: entries = [entry for entry in entries if entry['name'] != 'teeth']
                    table.write_bytes(write_library(entries))
                before = self.snapshots(Path(temp)); result = self.process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(self.snapshots(Path(temp)), before)

    def test_failed_unreadable_legacy_duplicate_missing_or_shared_mesh_refuses(self):
        for scenario in ('verify_fail', 'reader_fail', 'legacy', 'duplicate', 'wrong_binding', 'shared'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); model = f[6].read_model.return_value
                if scenario == 'verify_fail': f[7]['verify'] = 'fail'
                elif scenario == 'reader_fail': f[6].read_model.side_effect = ValueError('bad native model')
                elif scenario == 'legacy': model.version = 46
                elif scenario == 'duplicate': model.meshes.append(copy.deepcopy(model.meshes[0]))
                elif scenario == 'wrong_binding': model.meshes[0].face_groups = [('teeth_other', 0, 6)]
                else: model.meshes[1].face_groups = [('teeth', 0, 12)]
                before = self.snapshots(Path(temp)); result = self.process(f)
                self.assertEqual(result['refused'], 2 if scenario in ('verify_fail', 'reader_fail', 'legacy') else 1)
                self.assertEqual(self.snapshots(Path(temp)), before)

    def material_only_fixture(self, root):
        f = self.fixture(root, native=True); source, target, row, material, report = f[2], f[3], f[7], f[8], f[-1]
        source.write_bytes(target.read_bytes()); identity = sha(target.read_bytes())
        problem = "native material library: missing native JMTL for material 'body'"
        row.update(verify='fail', source_version=47, problems=[problem],
                   facts={'source_sha256': identity, 'output_sha256': identity, 'byte_identical': True,
                          'mesh_count': 7, 'bone_count': 175}, reference_weight_audit={'suspicious_vertices': 0})
        material.update(status='unsupported_native_materials', problems=[problem])
        report['problems'] = ['BaseModel/baseModel.mcd: ' + problem]; report['conversion_completeness'] = 'incomplete'
        return f, identity

    def test_exact_inspected_profile_repairs_only_teeth_without_clearing_unrelated_missing_material_failures(self):
        with tempfile.TemporaryDirectory() as temp:
            f, identity = self.material_only_fixture(Path(temp)); report = f[-1]
            problem_before = copy.deepcopy(report['problems']); row_before = copy.deepcopy(f[7]); table_before = f[3].with_suffix('.mtls').read_bytes()
            with patch.multiple(teeth, KNOWN_NATIVE_MODEL_SHA256=identity, KNOWN_NATIVE_MODEL_BYTES=len(f[3].read_bytes())):
                result = self.process(f)
            self.assertEqual(result['applied'], 1); self.assertEqual(result['refused'], 0)
            self.assertTrue(result['rows'][0]['known_material_only_profile'])
            self.assertEqual(result['rows'][0]['overall_model_verification_unchanged'], 'fail')
            self.assertEqual(f[7]['verify'], row_before['verify']); self.assertEqual(f[7]['problems'], row_before['problems'])
            self.assertEqual(report['problems'], problem_before); self.assertEqual(report['conversion_completeness'], 'incomplete')
            self.assertEqual(f[8]['status'], 'unsupported_native_materials')
            self.assertEqual(f[3].with_suffix('.mtls').read_bytes(), table_before)

    def test_exact_material_only_profile_applies_both_roles_and_preserves_overall_failed_status(self):
        with tempfile.TemporaryDirectory() as temp:
            f, identity = self.material_only_fixture(Path(temp)); self.add_mouthbag_role(f)
            before = copy.deepcopy(f[-1]['problems'])
            with patch.multiple(teeth, KNOWN_NATIVE_MODEL_SHA256=identity, KNOWN_NATIVE_MODEL_BYTES=len(f[3].read_bytes())):
                result = self.process(f)
            self.assertEqual(result['applied'], 2); self.assertEqual(result['refused'], 0)
            self.assertTrue(all(row['known_material_only_profile'] for row in result['rows']))
            self.assertEqual(f[7]['verify'], 'fail'); self.assertEqual(f[-1]['problems'], before)
            self.assertEqual(f[-1]['conversion_completeness'], 'incomplete')

    def test_material_only_exception_refuses_other_identity_changed_model_core_or_missing_teeth_errors(self):
        for scenario in ('wrong_known_sha', 'source_changed', 'output_changed', 'record_hash_changed', 'core_problem',
                         'teeth_missing_problem', 'material_problem', 'wrong_status', 'suspicious_weights'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f, identity = self.material_only_fixture(Path(temp))
                if scenario == 'wrong_known_sha': identity = '0' * 64
                elif scenario == 'source_changed': f[2].write_bytes(b'changed source geometry')
                elif scenario == 'output_changed': f[3].write_bytes(b'changed output geometry')
                elif scenario == 'record_hash_changed': f[7]['facts']['source_sha256'] = '0' * 64
                elif scenario == 'core_problem': f[7]['problems'].append('required animation root missing')
                elif scenario == 'teeth_missing_problem': f[7]['problems'] = ["native material library: missing native JMTL for material 'teeth'"]
                elif scenario == 'material_problem': f[8]['problems'].append('native texture table malformed')
                elif scenario == 'wrong_status': f[7]['status'] = 'failed'
                else: f[7]['reference_weight_audit']['suspicious_vertices'] = 1
                before = self.snapshots(Path(temp))
                with patch.multiple(teeth, KNOWN_NATIVE_MODEL_SHA256=identity, KNOWN_NATIVE_MODEL_BYTES=len(b'verified native model remains untouched')):
                    result = self.process(f)
                self.assertEqual(result['refused'], 1 if scenario == 'material_problem' else 2)
                self.assertEqual(self.snapshots(Path(temp)), before)

    def test_models_without_teeth_are_not_applicable_and_missing_assets_are_not_synthesized(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); f[6].read_model.return_value.meshes = []
            f[4].unlink(); before = self.snapshots(Path(temp)); result = self.process(f)
            self.assertEqual(result['not_applicable'], 2); self.assertEqual(result['refused'], 0)
            self.assertEqual(self.snapshots(Path(temp)), before)

    def test_ambiguous_model_provenance_refuses_all_owners_before_first_write(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); f[-1]['models'].append(copy.deepcopy(f[7]))
            before = self.snapshots(Path(temp)); result = self.process(f)
            self.assertEqual(result['refused'], 4); self.assertEqual(result['applied'], 0)
            self.assertEqual(self.snapshots(Path(temp)), before)

    def test_symlink_file_directory_and_root_paths_refuse_without_changing_target(self):
        for scenario in ('material_file', 'textures_directory', 'source_root', 'output_root', 'model_file'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = list(self.fixture(Path(temp))); outside = Path(temp) / 'outside'; outside.mkdir()
                if scenario == 'material_file':
                    original = f[4].read_bytes(); alias = outside / 'teeth.jmtl'; alias.write_bytes(original)
                    f[4].unlink(); f[4].symlink_to(alias)
                elif scenario == 'textures_directory':
                    import shutil
                    folder = f[3].parent / 'Textures'; shutil.move(str(folder), str(outside / 'Textures'))
                    folder.symlink_to(outside / 'Textures', target_is_directory=True)
                elif scenario == 'model_file':
                    alias = outside / 'model.mcd'; alias.write_bytes(f[3].read_bytes()); f[3].unlink(); f[3].symlink_to(alias)
                else:
                    index = 0 if scenario == 'source_root' else 1
                    alias = Path(temp) / 'alias'; alias.symlink_to(f[index], target_is_directory=True)
                    f[index] = alias; f[-1]['source' if index == 0 else 'output'] = str(alias)
                before = self.snapshots(Path(temp)); result = self.process(f)
                self.assertEqual(result['refused'], 2 if scenario == 'model_file' else 1)
                self.assertEqual(self.snapshots(Path(temp)), before)

    def test_overlapping_source_output_roots_refuse_before_native_read(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); f[-1]['source'] = str(Path(temp))
            before = self.snapshots(Path(temp)); result = teeth.process(f[-1], Path(temp), f[1], f[6], writer=self.write)
            self.assertEqual(result['refused'], 1); f[6].read_model.assert_not_called()
            self.assertEqual(self.snapshots(Path(temp)), before)
            self.assertTrue(f[-1]['warnings'])

    def test_malformed_report_metadata_refuses_before_any_asset_read_or_write(self):
        for field in ('models', 'materials', 'warnings', 'problems'):
            with self.subTest(field=field), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); f[-1][field] = {'unexpected': 'mapping'}
                before = self.snapshots(Path(temp))
                with patch.object(Path, 'read_bytes', side_effect=AssertionError('preflight must precede reads')):
                    result = self.process(f)
                self.assertEqual(result['refused'], 1); f[6].read_model.assert_not_called()
                self.assertEqual(self.snapshots(Path(temp)), before)

    def test_postwrite_reporting_error_is_recorded_as_written_not_refused(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp))
            with patch.object(teeth, '_metadata', side_effect=ValueError('report update failed')):
                result = self.process(f)
            self.assertEqual(result['failed_after_write'], 1); self.assertEqual(result['refused'], 0)
            self.assertEqual(result['rows'][0]['state'], 'written_with_verification_or_reporting_error')
            self.assertEqual(f[4].read_bytes(), self.write(0x19, f[5]))
            self.assertIn('write completed', f[-1]['warnings'][0])

    def test_unrelated_shader_and_unsafe_native_schema_refuse_without_change(self):
        for scenario in ('shader', 'truncate', 'noncanonical_root', 'overlap', 'nonfinite'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); data = bytearray(f[4].read_bytes())
                root = Table(data, struct.unpack_from('<I', data)[0]); payload = root.child(2)
                if scenario == 'shader': data = bytearray(self.write(0x12, f[5]))
                elif scenario == 'truncate': data = data[:-1]
                elif scenario == 'noncanonical_root':
                    at = root.position - struct.unpack_from('<i', data, root.position)[0]
                    struct.pack_into('<H', data, at + 6, 5)
                elif scenario == 'overlap':
                    at = payload.position - struct.unpack_from('<i', data, payload.position)[0]
                    struct.pack_into('<H', data, at + 6, payload.offsets[0])
                else:
                    # The writer's compact teeth policy omits optional slot7.
                    # Author that supported native scalar with its real vendor
                    # FlatBuffer builder, then test its nonfinite rejection.
                    builder = self.writer_module.flatbuffers.Builder(256); builder.ForceDefaults(True)
                    builder.StartObject(9); builder.PrependFloat32Slot(7, float('nan'), 0.)
                    builder.PrependUint64Slot(1, f[5]['nrMap@ref'], 0)
                    builder.PrependUint64Slot(0, f[5]['colorMap@ref'], 0); child = builder.EndObject()
                    builder.StartObject(3); builder.PrependUOffsetTRelativeSlot(2, child, 0)
                    builder.PrependUint16Slot(1, 0x1a, 0); native_root = builder.EndObject()
                    builder.Finish(native_root, b'Mate'); data = bytearray(builder.Output())
                f[4].write_bytes(data); before = self.snapshots(Path(temp)); result = self.process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(self.snapshots(Path(temp)), before)

    def test_additional_authored_maps_and_unknown_present_fields_are_not_discarded(self):
        # Construct actual native FlatBuffer schemas via the supplied vendor
        # builder: the curated writer intentionally omits these authored maps.
        for slot, kind, value in ((2, '<Q', 987), (3, '<Q', 987), (4, '<Q', 987), (9, '<f', .5)):
            with self.subTest(slot=slot), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); builder = self.writer_module.flatbuffers.Builder(256)
                builder.ForceDefaults(True); builder.StartObject(max(9, slot + 1))
                if kind == '<Q': builder.PrependUint64Slot(slot, value, 0)
                else: builder.PrependFloat32Slot(slot, value, 0.)
                builder.PrependUint64Slot(1, f[5]['nrMap@ref'], 0)
                builder.PrependUint64Slot(0, f[5]['colorMap@ref'], 0); payload = builder.EndObject()
                builder.StartObject(3); builder.PrependUOffsetTRelativeSlot(2, payload, 0)
                builder.PrependUint16Slot(1, 0x1a, 0); root = builder.EndObject(); builder.Finish(root, b'Mate')
                f[4].write_bytes(bytes(builder.Output())); before = self.snapshots(Path(temp)); result = self.process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(self.snapshots(Path(temp)), before)

    def test_invalid_writer_payload_or_changed_asset_during_preparation_never_commits(self):
        for scenario in ('wrong_shader', 'wrong_hash', 'writer_error', 'asset_changed'):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); original = f[4].read_bytes()
                def writer(shader, params):
                    if scenario == 'writer_error': raise RuntimeError('writer refused')
                    if scenario == 'asset_changed': f[3].with_suffix('.mtls').write_bytes(b'changed by another process')
                    return self.write(0x1a if scenario == 'wrong_shader' else shader,
                                      {**params, 'colorMap@ref': 123} if scenario == 'wrong_hash' else params)
                result = teeth.process(f[-1], f[0], f[1], f[6], writer=writer)
                self.assertEqual(result['refused'], 1); self.assertEqual(f[4].read_bytes(), original)

    def test_install_once_retains_convert_signature_and_saves_intermediate_report(self):
        report = {'models': []}; calls = []
        def convert_folder(src, dst, log=lambda text: None):
            calls.append((src, dst)); return report
        folder = SimpleNamespace(convert_folder=convert_folder, vc=object())
        teeth.install(folder); installed = folder.convert_folder; teeth.install(folder)
        self.assertIs(installed, folder.convert_folder)
        teeth.set_enabled(False)
        with patch('gmf_report.save_intermediate') as save:
            self.assertIs(folder.convert_folder('source', 'output'), report)
        self.assertEqual(calls, [('source', 'output')]); save.assert_called_once_with(report, 'output')


if __name__ == '__main__':
    unittest.main()
