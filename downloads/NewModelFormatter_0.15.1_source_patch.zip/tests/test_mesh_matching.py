"""Run the unchanged recovered Gorilla verifier with identity selection.

Controlled source/output models test real name, flag, weight, rig, geometry
and mask checks. The native AJ test is a separate read-only diagnostic.
"""
import copy
import builtins
from concurrent.futures import ThreadPoolExecutor
import functools
import marshal
import os
from pathlib import Path
import sys
import threading
import types
import unittest

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import gmf_mesh_matching as matching

MODULE_CODE=marshal.loads((Path(__file__).parent/'fixtures'/'gmf.convert.marshal').read_bytes())
RAW_CODE=next(c for c in MODULE_CODE.co_consts if isinstance(c,types.CodeType) and c.co_name=='verify')
MATCHER_CODE=next(c for c in RAW_CODE.co_consts if isinstance(c,types.CodeType) and c.co_firstlineno==514)


def mesh(name='M_Hair',flag=162,motion=10005,bone='J_Root',uv=0.):
    return types.SimpleNamespace(name=name,num_verts=3,
        positions=np.array([[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]],dtype=np.float32),
        triangles=np.array([[0,1,2]],dtype=np.int32),
        vertex_remap=None,scene_flag=flag,motion_flag=motion,
        face_groups=[('hair_ALPHA:skinned',0,1)],normals=np.tile([0.,0.,1.],(3,1)),
        tangents=None,uvs=[np.full((3,2),uv)],colors=[],shapes=[],
        weights={bone:np.ones(3,dtype=np.float32)})


class Model:
    def __init__(self,meshes):
        self.version=47;self.meshes=meshes;self.attach_points=[];self.goto_points=[]
        self.bones=[types.SimpleNamespace(name=n,parent=None,world=np.eye(4)) for n in ('J_Root','J_Entrance','J_Hood')]
    def bone_names(self):return [b.name for b in self.bones]


class Fixture:
    def __init__(self,source=None,target=None):
        source=source or [mesh(),mesh('M_Hair_Entrance',161,610050,'J_Entrance'),
            mesh('M_Hair_Entrance_HoodUp',417,610051,'J_Hood')]
        self.source=Model(copy.deepcopy(source));self.target=Model(copy.deepcopy(target if target is not None else source))
        names=self.source.bone_names()
        self.ref=types.SimpleNamespace(variants={'male':types.SimpleNamespace(names=names,
            world={n:np.eye(4) for n in names},bones=[(n,None,np.eye(4),np.eye(4)) for n in names])},
            dropped25=set(),face_joints=set(),new26=set())
        self.mask_problem=None;self.reader_hook=None
        def read_model(path):
            if self.reader_hook:self.reader_hook(path)
            return copy.deepcopy(self.target if path=='out.mcd' else self.source)
        self.vc=types.SimpleNamespace(read_model=read_model,VERSION_2K26=47)
        def check_mask(src,b,limits,problems,facts,base):
            facts['original_mask_called']=True
            if self.mask_problem:problems.append(self.mask_problem)
        ns={'vc':self.vc,'np':np,'os':os,'SKIN_TONE_MESHES':set(),'__builtins__':builtins.__dict__,
            'mcd':types.SimpleNamespace(substreams=lambda p:[('MDL!',0,b''),('HPL!',0,b'')]),
            '_check_mask':check_mask}
        classifier=next(c for c in MODULE_CODE.co_consts if isinstance(c,types.CodeType) and c.co_name=='is_base_file')
        ns['is_base_file']=types.FunctionType(classifier,ns)
        raw=types.FunctionType(RAW_CODE,ns,'verify',(0,'male',None,None))
        self.module=types.SimpleNamespace(verify=raw,vc=self.vc)
        self.raw=raw
    def install(self):matching.prepare(self.module);matching.install(self.module)
    def run(self,path='610_Attire.mcd'):return self.module.verify(path,'out.mcd',self.ref)


class OriginalVerifierTests(unittest.TestCase):
    def test_original_geometry_first_false_positive_reproduced_then_fixed(self):
        f=Fixture();before=f.run()
        self.assertFalse(before[0]);self.assertTrue(any('moved by 1.000' in p for p in before[1]))
        f.install();after=f.run()
        self.assertTrue(after[0],after[1]);self.assertTrue(after[2]['original_mask_called'])
        self.assertEqual([r['selected_name'] for r in after[2]['attire_mesh_matching']['records']],
            ['M_Hair','M_Hair_Entrance','M_Hair_Entrance_HoodUp'])

    def test_code_objects_constants_and_original_globals_unchanged(self):
        f=Fixture();before=dict(f.raw.__globals__);matching.prepare(f.module)
        self.assertIs(f.module.verify.__code__,f.raw.__code__)
        self.assertIs(f.module.verify.__code__.co_consts,f.raw.__code__.co_consts)
        self.assertEqual(before,f.raw.__globals__);self.assertNotIn('next',f.raw.__globals__)

    def test_real_wrong_name_failure_retained(self):
        f=Fixture([mesh('M_Hair_Entrance',161,610050)],[mesh('M_Hair',161,610050)])
        f.install();result=f.run();self.assertFalse(result[0])
        self.assertIn('mesh M_Hair_Entrance is named M_Hair in the output',result[1])

    def test_real_wrong_flags_failure_retained(self):
        f=Fixture();f.target.meshes[1].scene_flag=130;f.install();result=f.run()
        self.assertFalse(result[0]);self.assertTrue(any('M_Hair_Entrance flags' in p for p in result[1]))

    def test_real_wrong_weights_retained_not_used_as_identity(self):
        f=Fixture();f.target.meshes[1].weights={'J_Root':np.ones(3)};f.install();result=f.run()
        self.assertFalse(result[0]);self.assertIn('M_Hair_Entrance: weights of untouched vertices moved by 1.000',result[1])
        self.assertEqual(result[2]['attire_mesh_matching']['records'][1]['selected_name'],'M_Hair_Entrance')

    def test_real_rig_geometry_uv_remap_and_mask_checks_retained(self):
        cases=[('rig',lambda f:setattr(f.target.bones[0],'parent','J_Hood'),'parent'),
            ('triangles',lambda f:setattr(f.target.meshes[1],'triangles',np.array([[2,1,0]])),'triangles changed'),
            ('positions',lambda f:f.target.meshes[1].positions.__setitem__((0,0),1.),'not found unchanged'),
            ('uv',lambda f:f.target.meshes[1].uvs[0].__setitem__((0,0),.5),'UVs changed'),
            ('remap',lambda f:setattr(f.target.meshes[1],'vertex_remap',[2,1,0]),'vertex numbering'),
            ('mask',lambda f:setattr(f,'mask_problem','source hide mask is unsupported or unreadable'),'hide mask')]
        for label,damage,expected in cases:
            with self.subTest(label=label):
                f=Fixture();damage(f);f.install();result=f.run()
                self.assertFalse(result[0]);self.assertTrue(any(expected in p for p in result[1]),result[1])
                self.assertTrue(result[2]['original_mask_called'])

    def test_identical_duplicate_names_have_equivalent_verification_outcomes(self):
        f=Fixture([mesh(),mesh()]);f.install();result=f.run()
        self.assertTrue(result[0],result[1])
        audit=result[2]['attire_mesh_matching']
        self.assertEqual(audit['consumed_output_records'],2)
        self.assertEqual(audit['equivalent_duplicate_proofs'],1)
        self.assertFalse(audit['source_weights_used_for_pairing'])
        self.assertTrue(audit['output_weights_compared_only_for_permutation_equivalence'])

    def test_same_name_nearby_geometry_distinguished_by_exact_positions(self):
        a=mesh(bone='J_Root');b=mesh(bone='J_Entrance');b.positions[0,0]=.00001
        f=Fixture([a,b],[b,a]);f.install();result=f.run()
        self.assertTrue(result[0],result[1])
        self.assertEqual(result[2]['attire_mesh_matching']['records'][0]['selection_rule'],
            'same_name_exact_positions')

    def test_identical_output_duplicates_do_not_waive_source_weight_errors(self):
        a=mesh(bone='J_Root');b=mesh(bone='J_Entrance')
        f=Fixture([a,b],[copy.deepcopy(a),copy.deepcopy(a)]);f.install();result=f.run()
        self.assertFalse(result[0]);self.assertTrue(any('weights of untouched vertices moved' in p for p in result[1]))
        self.assertEqual(result[2]['attire_mesh_matching']['consumed_output_records'],2)

    def test_target_permutation_equivalence_includes_every_original_verifier_field(self):
        changes={
            'positions':lambda m:m.positions.__setitem__((0,0),.00001),
            'triangles':lambda m:setattr(m,'triangles',np.array([[2,1,0]],dtype=np.int32)),
            'remap':lambda m:setattr(m,'vertex_remap',np.array([0,1,2],dtype=np.int32)),
            'flags':lambda m:setattr(m,'scene_flag',161),
            'motion':lambda m:setattr(m,'motion_flag',610050),
            'materials':lambda m:setattr(m,'face_groups',[('other:skinned',0,1)]),
            'normals':lambda m:m.normals.__setitem__((0,0),.1),
            'tangents':lambda m:setattr(m,'tangents',np.tile([1.,0.,0.,1.],(3,1))),
            'uv':lambda m:m.uvs[0].__setitem__((0,0),.00001),
            'colors':lambda m:setattr(m,'colors',[np.ones((3,4))]),
            'shapes':lambda m:setattr(m,'shapes',[('blink',np.ones((3,3)))]),
            'weights':lambda m:setattr(m,'weights',{'J_Entrance':np.ones(3,dtype=np.float32)}),
        }
        a=mesh()
        self.assertTrue(matching._permutation_equivalent(a,copy.deepcopy(a)))
        for field,change in changes.items():
            with self.subTest(field=field):
                b=copy.deepcopy(a);change(b)
                self.assertFalse(matching._permutation_equivalent(a,b))

    def test_duplicate_normals_shapes_and_colors_cannot_choose_favorable_target(self):
        for field in ('normals','shape','colors'):
            with self.subTest(field=field):
                a=mesh();b=mesh()
                if field=='normals':b.normals[:]=[.1,0.,.9]
                if field=='shape':
                    a.shapes=[('blink',np.zeros((3,3)))];b.shapes=[('blink',np.ones((3,3)))]
                if field=='colors':
                    a.colors=[np.ones((3,4))];b.colors=[np.zeros((3,4))]
                f=Fixture([copy.deepcopy(a),copy.deepcopy(a)],[a,b]);f.install();result=f.run()
                self.assertFalse(result[0]);self.assertTrue(any('ambiguous same-name' in p for p in result[1]),result[1])

    def test_identical_output_duplicates_with_same_wrong_weights_still_fail(self):
        a=mesh();bad=mesh(bone='J_Entrance')
        f=Fixture([copy.deepcopy(a),copy.deepcopy(a)],[copy.deepcopy(bad),copy.deepcopy(bad)]);f.install();result=f.run()
        self.assertFalse(result[0]);self.assertTrue(any('weights of untouched vertices moved' in p for p in result[1]))

    def test_excess_identical_target_duplicate_records_fail(self):
        f=Fixture([mesh(),mesh()],[mesh(),mesh(),mesh()]);f.install();result=f.run()
        self.assertFalse(result[0]);self.assertTrue(any('excess same-name attire output records' in p for p in result[1]))

    def test_equivalent_target_weight_table_order_and_dtypes_must_match(self):
        a=mesh();b=copy.deepcopy(a)
        a.weights={'J_Root':np.full(3,.5,dtype=np.float32),'J_Entrance':np.full(3,.5,dtype=np.float32)}
        b.weights=dict(reversed(list(a.weights.items())))
        self.assertFalse(matching._permutation_equivalent(a,b))
        b=copy.deepcopy(a);b.weights['J_Root']=b.weights['J_Root'].astype(np.float64)
        self.assertFalse(matching._permutation_equivalent(a,b))

    def test_equivalent_targets_with_nonfinite_unused_data_refuse(self):
        a=mesh();b=copy.deepcopy(a);a.weights['J_Root'][0]=np.nan;b.weights['J_Root'][0]=np.nan
        self.assertFalse(matching._permutation_equivalent(a,b))

    def test_duplicate_names_distinguished_by_flags_material_remap_uv(self):
        for field in ('flags','material','remap','uv','shape'):
            with self.subTest(field=field):
                a=mesh();b=mesh(bone='J_Entrance')
                if field=='flags':b.scene_flag=161
                if field=='material':b.face_groups=[('other:skinned',0,1)]
                if field=='remap':b.vertex_remap=np.array([2,1,0])
                if field=='uv':b.uvs[0][:]=.5
                if field=='shape':b.shapes=[('Different',np.array([0]),np.array([[0.,0.,0.]]))]
                f=Fixture([a,b],[b,a]);f.install();result=f.run()
                self.assertTrue(result[0],result[1])
                self.assertEqual(result[2]['attire_mesh_matching']['consumed_output_records'],2)

    def test_same_name_targets_not_disambiguated_by_weights(self):
        a=mesh();b=mesh(bone='J_Entrance');f=Fixture([a,b],[a,b]);f.install();result=f.run()
        self.assertFalse(result[0]);self.assertTrue(any('ambiguous same-name' in p for p in result[1]))

    def test_target_cannot_be_reused_for_two_source_records(self):
        f=Fixture([mesh(),mesh()],[mesh()]);f.install();result=f.run()
        self.assertFalse(result[0]);self.assertTrue(any('would be reused' in p for p in result[1]))
        self.assertEqual(result[2]['attire_mesh_matching']['consumed_output_records'],1)

    def test_base_filename_delegates_original_rules(self):
        f=Fixture();before=f.run('baseModel.mcd');f.install();after=f.run('baseModel.mcd')
        self.assertEqual(before[1],after[1]);self.assertNotIn('attire_mesh_matching',after[2])

    def test_prepare_and_install_idempotent(self):
        f=Fixture();matching.prepare(f.module);first=f.module.verify
        matching.prepare(f.module);self.assertIs(first,f.module.verify)
        matching.install(f.module);second=f.module.verify
        matching.install(f.module);self.assertIs(second,f.module.verify)
        self.assertTrue(f.run()[0]);self.assertTrue(f.run()[0])

    def test_reject_wrong_code_and_install_before_prepare(self):
        f=Fixture();f.module.verify=lambda *args:None
        with self.assertRaisesRegex(ValueError,'exact reviewed'):matching.prepare(f.module)
        with self.assertRaisesRegex(ValueError,'prepare raw'):matching.install(f.module)

    def test_reject_changed_base_classifier(self):
        f=Fixture();f.raw.__globals__['is_base_file']=lambda *args:False
        with self.assertRaisesRegex(ValueError,'base classifier'):matching.prepare(f.module)

    def test_source_identity_invalid_metadata_denies_admission(self):
        for damage in (lambda f:f.source.meshes[0].uvs[0].__setitem__((0,0),np.nan),
                lambda f:setattr(f.source.meshes[0],'vertex_remap',np.array([0,np.nan,2])),
                lambda f:setattr(f.source,'meshes',[])):
            f=Fixture();damage(f);f.install();result=f.run()
            self.assertFalse(result[0]);self.assertTrue(any('cannot establish source identity' in p for p in result[1]))

    def test_attire_overlay_has_no_skip_and_filename_classifier_is_guarded(self):
        m=mesh('M_transB_eyeshadow');m.face_groups=[('eye_overlay:skinned',0,1)]
        f=Fixture([m]);f.install();result=f.run()
        self.assertTrue(result[0],result[1]);self.assertEqual(result[2]['attire_mesh_matching']['matching_calls'],1)

    def test_other_next_calls_have_normal_python_semantics(self):
        f=Fixture();matching.prepare(f.module);hook=f.module.verify.__globals__['next']
        self.assertEqual(hook(iter([7])),7);self.assertEqual(hook(iter([]),'default'),'default')
        with self.assertRaises(StopIteration):hook(iter([]))
        with self.assertRaises(TypeError):hook(iter([]),1,2)

    def test_unrelated_generator_even_same_geometry_delegates(self):
        f=Fixture();matching.prepare(f.module);hook=f.module.verify.__globals__['next']
        state=matching.Selection(f.source.meshes);matching._context.stack=[(f.module._mesh_matching_token,state)]
        try:
            self.assertEqual(hook((x for x in [1,2])),1)
            self.assertEqual(state.ordinal,0)
        finally:matching._context.stack=[]

    def test_cloned_gear_reader_namespace_reaches_original_raw(self):
        f=Fixture();matching.prepare(f.module);prepared=f.module.verify
        written=f.target
        def reader(path):
            model=copy.deepcopy(written if path=='out.mcd' else f.source)
            if path!='out.mcd':model.meshes[1].weights={'J_Root':np.ones(3)}
            return model
        f.target.meshes[1].weights={'J_Root':np.ones(3)}
        @functools.wraps(prepared)
        def gear(*args,**kwargs):
            ns=dict(prepared.__globals__);ns['vc']=types.SimpleNamespace(read_model=reader,VERSION_2K26=47)
            isolated=types.FunctionType(prepared.__code__,ns,prepared.__name__,prepared.__defaults__)
            return isolated(*args,**kwargs)
        f.module.verify=gear;matching.install(f.module)
        self.assertTrue(f.run()[0],f.run()[1])

    def test_nested_non_attire_does_not_consume_outer_context(self):
        f=Fixture();f.install();nested=[];busy=False
        def hook(path):
            nonlocal busy
            if path=='out.mcd' and not busy:
                busy=True
                try:nested.append(f.run('other.mcd'))
                finally:busy=False
        f.reader_hook=hook;result=f.run()
        self.assertTrue(result[0],result[1]);self.assertTrue(nested)
        self.assertNotIn('attire_mesh_matching',nested[0][2])
        self.assertFalse(nested[0][0]) # Original ambiguity remains out of scope.
        self.assertEqual(result[2]['attire_mesh_matching']['matching_calls'],3)

    def test_nested_attire_has_separate_source_and_consumption(self):
        f=Fixture();f.install();nested=[];busy=False
        def hook(path):
            nonlocal busy
            if path=='out.mcd' and not busy:
                busy=True
                try:nested.append(f.run('nested_Attire.mcd'))
                finally:busy=False
        f.reader_hook=hook;result=f.run()
        self.assertTrue(result[0],result[1]);self.assertTrue(nested[0][0],nested[0][1])
        self.assertEqual(result[2]['attire_mesh_matching']['matching_calls'],3)
        self.assertEqual(nested[0][2]['attire_mesh_matching']['matching_calls'],3)

    def test_concurrent_contexts_are_thread_local(self):
        f=Fixture();f.install();barrier=threading.Barrier(2)
        f.reader_hook=lambda path:barrier.wait(timeout=5) if path=='out.mcd' else None
        with ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(lambda n:f.run(),range(2)))
        self.assertTrue(all(r[0] for r in results),[r[1] for r in results])
        self.assertEqual([r[2]['attire_mesh_matching']['matching_calls'] for r in results],[3,3])

    def test_snapshot_callcount_geometry_mismatch_fail_closed(self):
        state=matching.Selection([mesh(),mesh()]);state.choose([mesh()])
        self.assertTrue(any('call count' in p for p in state.audit()['problems']))
        state=matching.Selection([mesh()]);bad=mesh();bad.positions+=1
        self.assertIsNone(state.choose([bad]));self.assertTrue(state.problems)


if __name__=='__main__':unittest.main()
