"""Check BC1 palette modes, used pixels and Gorilla conversion decisions."""
import io,marshal,struct,sys,tempfile,types,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import gmf_dds_alpha as alpha
from test_repair import recovered_function


def dds(width=4,height=4,block=None,dxgi=None):
    data=bytearray(128);data[:4]=b'DDS '
    struct.pack_into('<IIII',data,4,124,0x81007,height,width)
    struct.pack_into('<II4s',data,76,32,4,b'DX10' if dxgi is not None else b'DXT1')
    struct.pack_into('<I',data,108,0x1000)
    if dxgi is not None:data.extend(struct.pack('<5I',dxgi,3,0,1,0))
    data.extend(block if block is not None else struct.pack('<HHI',0,1,3))
    return bytes(data)


class AlphaTests(unittest.TestCase):
    def probe(self,data):return alpha._bc1_alpha(io.BytesIO(data))

    def test_original_bug_reproduced_then_transparent_pixel_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'jacket.dds';data=dds();path.write_bytes(data)
            old=recovered_function('gmf.materials','texture_has_transparency',{'struct':struct})
            self.assertIs(old(path),False)
            self.assertIs(alpha.texture_has_transparency(path,old),True)
            self.assertEqual(path.read_bytes(),data)

    def test_four_color_palette_stays_opaque_even_for_selector_three(self):
        self.assertEqual(self.probe(dds(block=struct.pack('<HHI',65535,0,0xffffffff))),(True,False))

    def test_three_color_palette_with_no_transparent_pixels_is_opaque(self):
        self.assertEqual(self.probe(dds(block=struct.pack('<HHI',0,65535,0xaaaaaaaa))),(True,False))

    def test_equal_color_endpoints_still_allow_transparency(self):
        self.assertEqual(self.probe(dds(block=struct.pack('<HHI',100,100,3))),(True,True))

    def test_padding_pixels_outside_image_do_not_make_texture_transparent(self):
        self.assertEqual(self.probe(dds(1,1,struct.pack('<HHI',0,1,0xfffffffc))),(True,False))

    def test_transparency_in_later_block_is_detected(self):
        blocks=struct.pack('<HHI',65535,0,0xffffffff)+struct.pack('<HHI',0,1,3)
        self.assertEqual(self.probe(dds(8,4,blocks)),(True,True))

    def test_dx10_bc1_linear_srgb_and_typeless_are_read(self):
        for dxgi in (70,71,72):
            with self.subTest(dxgi=dxgi):self.assertEqual(self.probe(dds(dxgi=dxgi)),(True,True))

    def test_bc7_is_not_misread_as_bc1(self):
        self.assertEqual(self.probe(dds(dxgi=98)),(False,None))

    def test_cube_volume_or_texture_array_are_not_certified_from_one_surface(self):
        for flag in (0x200,0x200000):
            data=bytearray(dds());struct.pack_into('<I',data,112,flag)
            self.assertEqual(self.probe(bytes(data)),(True,None))
        data=bytearray(dds(dxgi=71));struct.pack_into('<I',data,140,2)
        self.assertEqual(self.probe(bytes(data)),(True,None))

    def test_truncated_zero_dimension_and_bad_headers_remain_unknown(self):
        bad=bytearray(dds());struct.pack_into('<I',bad,4,123)
        for value in (dds()[:-1],dds(0,4),bytes(bad)):
            with self.subTest(value=value):self.assertEqual(self.probe(value),(True,None))

    def test_other_formats_retain_original_decoder(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'other.dds';data=bytearray(dds());data[84:88]=b'DXT5';path.write_bytes(data)
            calls=[]
            module=types.SimpleNamespace(texture_has_transparency=lambda p:calls.append(p) or True)
            alpha.install(module);first=module.texture_has_transparency;alpha.install(module)
            self.assertIs(first,module.texture_has_transparency);self.assertIs(module.texture_has_transparency(path),True)
            self.assertEqual(calls,[path])

    def test_original_trans_gear_receives_detected_alpha_without_changing_params(self):
        namespace=dict(SKIN=25,HEAD=23,CARUNCLE=19,EYE=18,EYELASH=20,GEAR=21,HAIR=22,TEETH=26,
            GEAR_SOLID=0,GEAR_CUTOUT=1,GEAR_SEE_THROUGH=2,GEAR_IRRADIANCE=(0,.75,.75),
            clean_name=lambda n:n,shader_for=lambda m:(21,None),
            _ref=lambda m,k:m.params.get(k),_num=lambda m,k,default:default)
        convert=recovered_function('gmf.materials','to_2k26',namespace)
        mat=types.SimpleNamespace(name='jacket',shader='yCh_trans',params={'colorMap':'jacket_color'})
        before=dict(mat.params)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'jacket_color.dds';path.write_bytes(dds())
            _,solid,_,_=convert(mat,lambda name:False)
            _,transparent,_,_=convert(mat,lambda name:alpha.texture_has_transparency(path))
        self.assertNotIn('variant',solid);self.assertEqual(transparent['variant'],2)
        self.assertEqual(mat.params,before)


if __name__=='__main__':unittest.main()
