"""Actual payload hashes distinguish standard pairs from preserved custom data."""
import hashlib,json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import gmf_jmtl_audit as audit
from test_native_missing_data import material


class FaceAuditTests(unittest.TestCase):
    def test_reference_pair_agrees_with_supplied_captured_stock_character_data(self):
        records=json.loads((Path(__file__).parent/'fixtures'/'native26_face_reference_values.json').read_text())
        stock=[r for r in records['samples'] if r['shader']=='yCh_Teeth' and '100 The Rock' in r['source_name']]
        self.assertTrue(stock)
        for row in stock:
            props=row['properties']
            check=audit.inspect_material(material(0x1a,{0:props['colorMap@ref'],1:props['nrMap@ref']}))['face_texture_check']
            self.assertTrue(check['reference_texture_pair_match'])

    def test_eye_normal_agrees_with_supplied_captured_stock_character_data(self):
        records=json.loads((Path(__file__).parent/'fixtures'/'native26_face_reference_values.json').read_text())
        stock=[r for r in records['samples'] if r['shader']=='yCh_eye' and '100 The Rock' in r['source_name'] and 'nrMap@ref' in r['properties']]
        self.assertTrue(stock)
        for row in stock:
            props=row['properties']
            check=audit.inspect_material(material(0x12,{0:props['colorMap@ref'],3:props['nrMap@ref']}))['face_texture_check']
            self.assertTrue(check['reference_normal_match'])

    def test_teeth_reference_pair_matches_actual_payload(self):
        data=material(0x1a,{0:0x7357eeb9075df170,1:0xba65216dd64f5c78})
        result=audit.inspect_material(data)['face_texture_check']
        self.assertTrue(result['reference_texture_pair_match'])
        self.assertTrue(result['required_color_and_normal_refs_present'])

    def test_nonstandard_teeth_refs_are_identified_and_kept(self):
        data=material(0x1a,{0:123,1:456});before=data
        result=audit.inspect_material(data)['face_texture_check']
        self.assertFalse(result['reference_texture_pair_match'])
        self.assertEqual((result['color_ref'],result['normal_ref']),(123,456))
        self.assertEqual(data,before)

    def test_eye_color_is_custom_and_normal_matches_reference(self):
        result=audit.inspect_material(material(0x12,{0:123,3:0xefbc052176b84e95}))['face_texture_check']
        self.assertEqual(result['color_ref'],123);self.assertTrue(result['reference_normal_match'])

    def test_missing_reference_is_not_marked_as_matching(self):
        result=audit.inspect_material(material(0x12,{0:123}))['face_texture_check']
        self.assertFalse(result['required_color_and_normal_refs_present']);self.assertFalse(result['reference_normal_match'])

    def test_written_report_reads_emitted_bytes_and_keeps_old_material_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);shader=folder/'Materials'/'teeth.jmtl';shader.parent.mkdir()
            data=material(0x1a,{0:123,1:456});shader.write_bytes(data)
            old=[{'name':'teeth','textures':['colorMap@ref','nrMap@ref']}]
            report={'output':str(folder/'baseModel.mtls'),'materials':old}
            audit.inspect_written_materials(report);row=report['written_material_payload_audit'][0]
            self.assertEqual(row['sha256'],hashlib.sha256(data).hexdigest())
            self.assertEqual(report['materials'],old);self.assertEqual(shader.read_bytes(),data)
            self.assertEqual(row['state'],'payload_inspected')

    def test_unavailable_shader_is_explicit_without_writing_a_replacement(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);report={'output':str(folder/'baseModel.mtls'),'materials':[{'name':'teeth'}]}
            audit.inspect_written_materials(report)
            self.assertEqual(report['written_material_payload_audit'][0]['state'],'payload_not_inspected')
            self.assertFalse((folder/'Materials').exists())


if __name__=='__main__':unittest.main()
