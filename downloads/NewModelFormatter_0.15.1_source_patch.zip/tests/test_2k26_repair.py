"""Native preservation checks, including the original recovered folder loop."""
import hashlib
import importlib.util
import json
import marshal
import os
from pathlib import Path
import shutil
import struct
import sys
import tempfile
import time
import types
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gmf_2k26_repair as repair

FIXTURES = Path(__file__).parent / 'fixtures'
spec = importlib.util.spec_from_file_location('native_test_mtls_writer', FIXTURES / 'mtls_writer.py')
writer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(writer)


def original_function(name, namespace):
    # Execute only these inspected functions, never the original module imports.
    code = marshal.loads((FIXTURES / 'gmf.folder.marshal').read_bytes())
    function = next(c for c in code.co_consts if isinstance(c, types.CodeType) and c.co_name == name)
    return types.FunctionType(function, namespace)


def native_model():
    mesh = types.SimpleNamespace(num_verts=3, triangles=[(0, 1, 2)],
                                 face_groups=[('hair_alpha:Skinned', 0, 1)])
    return types.SimpleNamespace(version=47, bones=[types.SimpleNamespace(name='root')], meshes=[mesh])


def folder_module(reader=None):
    def no_25_conversion(*args, **kwargs):
        raise AssertionError('native model called a 2K25 conversion/verification function')

    def carry(source, target):
        Path(target).parent.mkdir(parents=True, exist_ok=True)
        data = bytearray(Path(source).read_bytes())
        struct.pack_into('<H', data, 18, 26)
        Path(target).write_bytes(data)
        return 'test original YCL conversion', None

    module = types.SimpleNamespace()
    namespace = {
        'os': os, 'json': json, 'shutil': shutil, 'struct': struct, 'time': time,
        'engine': types.SimpleNamespace(find=lambda: True, describe=lambda: 'test engine'),
        'Reference': lambda: object(),
        'vc': types.SimpleNamespace(VERSION_2K26=47, VERSION_2K25=41, VERSION_2K24=40,
                                   read_model=reader or (lambda *args, **kwargs: native_model())),
        'mcd': types.SimpleNamespace(mdl_version=lambda path: 47 if Path(path).read_bytes().startswith(b'native') else 41),
        'convert': types.SimpleNamespace(LEFT_OUT_SIDECARS=repair.NATIVE_PHYSICS_SUFFIXES,
                                        EMBED_PHYSICS=False, convert_mcd=no_25_conversion,
                                        verify=no_25_conversion),
        'materials': types.SimpleNamespace(clean_name=lambda name: name.split(':', 1)[0],
                                          game_folder=lambda path: None),
        'ycl': types.SimpleNamespace(find_editor=lambda: None, carry=carry),
        'YCL_VERSION_2K26': 26,
        '_blank_physics': lambda *args: None, '_check_tree': lambda *args: None,
        'texture_problem': lambda *args: None,
        '_slot_plan': lambda source, slot: ('999_Test', {'873_default_attire':
                                         ('999_Default_Attire', {'873_attire': '999_Attire'})}, []),
        '_texture_moves': lambda *args: [],
        'slots': types.SimpleNamespace(find=lambda slot: ('999_Test', {'type': 'male'})),
    }
    for name in ('_mapped', '_rel_root', 'ycl_version'):
        namespace[name] = original_function(name, namespace)
    original = original_function('convert_folder', namespace)
    original.__defaults__ = (print, True, None)
    module.__dict__.update(namespace)
    module.convert_folder = original
    return module


def source_tree(root, library_name='hair_ALPHA'):
    source = root / 'input' / '873_Test'
    attire = source / '873_Default_Attire'
    materials = attire / 'Materials'
    materials.mkdir(parents=True)
    (attire / '873_Attire.mcd').write_bytes(b'native model geometry weights bones physics')
    (attire / '873_Attire.mtls').write_bytes(writer.write_mtls([library_name],
         'Characters/873_Test/873_Default_Attire/873_Attire.mtls'))
    (materials / (library_name + '.jmtl')).write_bytes(b'opaque native JMTL shader parameters and texture hashes')
    for suffix in repair.NATIVE_PHYSICS_SUFFIXES:
        (attire / ('873_Attire' + suffix)).write_bytes(('opaque original' + suffix).encode())
    return source


def inventory(root):
    return {path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in root.rglob('*') if path.is_file()}


class NativeMaterialTests(unittest.TestCase):
    def test_game_folder_matches_recovered_writer_innermost_component(self):
        code = marshal.loads((FIXTURES / 'gmf.materials.marshal').read_bytes())
        function = next(c for c in code.co_consts
                        if isinstance(c, types.CodeType) and c.co_name == 'game_folder')
        original = types.FunctionType(function, {'os': os})
        cases = (
            ('/mods/Characters/159_Bryan/BaseModel/baseModel.mtls',
             'Characters/159_Bryan/BaseModel'),
            ('/mods/Characters/archive/Characters/INPUT/159_Bryan/BaseModel/baseModel.mtls',
             'Characters/INPUT/159_Bryan/BaseModel'),
            ('/mods/cHaRaCtErS/archive/CHARACTERS/INPUT/FLIP/BaseModel/baseModel.mtls',
             'Characters/INPUT/FLIP/BaseModel'),
            (r'C:\Mods\Characters\archive\Characters\INPUT\FLIP\BaseModel\baseModel.mtls',
             'Characters/INPUT/FLIP/BaseModel'),
            ('Characters/INPUT/159_Bryan/BaseModel/baseModel.mtls',
             'Characters/INPUT/159_Bryan/BaseModel'),
        )
        for filename, expected in cases:
            with self.subTest(filename=filename):
                actual = repair.game_folder(filename)
                self.assertEqual(actual, expected)
                # The original function accepts a directory, while the native
                # repair helper accepts the library filename.
                directory = filename.replace('\\', '/').rsplit('/', 1)[0]
                self.assertEqual(actual.casefold(), original(directory).casefold())

    def test_game_folder_rejects_root_name_substrings_and_preserves_single_root(self):
        for filename in ('/mods/CharactersBackup/Test/baseModel.mtls',
                         '/mods/MyCharacters/Test/baseModel.mtls',
                         r'C:\Mods\CharactersSomething\Test\baseModel.mtls'):
            with self.subTest(filename=filename):
                self.assertIsNone(repair.game_folder(filename))
        self.assertEqual(repair.game_folder('/mods/Characters/Test/BaseModel/baseModel.mtls'),
                         'Characters/Test/BaseModel')

    def test_nested_native_hash_repair_uses_inner_namespace_only(self):
        destination = '/mods/Characters/archive/Characters/INPUT/FLIP/BaseModel/baseModel.mtls'
        data = writer.write_mtls(['eye_l', 'eye_r'], 'Characters/Old/BaseModel/baseModel.mtls')
        result, report = repair.repair_native_library(
            data, {'eye_l', 'eye_r'}, ['eye_l.jmtl', 'eye_r.jmtl'], repair.game_folder(destination))
        entries = repair.read_native_library(result)
        allowed = {i for entry in repair.read_native_library(data)
                   for i in range(entry['hash_offset'], entry['hash_offset'] + 8)}
        changed = {i for i, (a, b) in enumerate(zip(data, result)) if a != b}
        self.assertTrue(changed)
        self.assertLessEqual(changed, allowed)
        for entry in entries:
            suffix = '/Materials/' + entry['name'] + '.jmtl'
            self.assertEqual(entry['path_hash'], repair.path_hash('Characters/INPUT/FLIP/BaseModel' + suffix))
            self.assertNotEqual(entry['path_hash'], repair.path_hash('Characters/archive/Characters/INPUT/FLIP/BaseModel' + suffix))
        self.assertEqual(len(report['material_path_hash_repairs']), 2)

    def test_exact_native_library_is_byte_identical(self):
        path = 'Characters/873_Test/873_Default_Attire/873_Attire.mtls'
        data = writer.write_mtls(['hair_alpha'], path)
        result, report = repair.repair_native_library(data, {'hair_alpha'}, ['hair_alpha.jmtl'],
                                                      'Characters/873_Test/873_Default_Attire')
        self.assertEqual(result, data)
        self.assertEqual(report['bytes_changed'], 0)

    def test_case_and_slot_repair_changes_only_name_and_hash_fields(self):
        data = writer.write_mtls(['hair_ALPHA', 'body'],
                                 'Characters/873_Test/873_Default_Attire/873_Attire.mtls')
        result, report = repair.repair_native_library(data, {'hair_alpha'},
                 ['hair_ALPHA.jmtl', 'body.jmtl'], 'Characters/999_Test/999_Default_Attire')
        entries = repair.read_native_library(data)
        allowed = {index for entry in entries for index in range(entry['hash_offset'], entry['hash_offset'] + 8)}
        allowed.update(range(entries[0]['name_offset'], entries[0]['name_offset'] + entries[0]['name_bytes']))
        changed = {i for i, (before, after) in enumerate(zip(data, result)) if before != after}
        self.assertTrue(changed)
        self.assertLessEqual(changed, allowed)
        output_entries = repair.read_native_library(result)
        self.assertEqual([entry['name'] for entry in output_entries], ['hair_alpha', 'body'])
        self.assertEqual(output_entries[0]['path_hash'],
                         writer._compute_path_hash('Characters/999_Test/999_Default_Attire/999_Attire.mtls', 'hair_alpha'))
        self.assertEqual(len(report['material_path_hash_repairs']), 2)

    def test_unknown_stub_version_does_not_count_as_native(self):
        data = bytearray(writer.write_mtls(['hair_alpha'], 'Characters/Test/Attire/attire.mtls'))
        data[-32:-28] = struct.pack('<I', 99)
        with self.assertRaisesRegex(ValueError, 'not an exact empty v4 stub'):
            repair.read_native_library(bytes(data))

    def test_truncated_or_bad_name_table_is_rejected(self):
        data = writer.write_mtls(['hair_alpha'], 'Characters/Test/Attire/attire.mtls')
        for corrupt in (data[:-1], data[:15], data + b'extra', data[:8] + struct.pack('<I', 9999) + data[12:]):
            with self.subTest(data=corrupt[:12]):
                with self.assertRaises(ValueError):
                    repair.read_native_library(corrupt)

    def test_missing_or_ambiguous_jmtl_never_rewrites_a_library(self):
        data = writer.write_mtls(['hair_ALPHA'], 'Characters/Test/Attire/attire.mtls')
        for files in ([], ['hair_ALPHA.jmtl', 'hair_alpha.jmtl']):
            with self.subTest(files=files):
                with self.assertRaisesRegex(ValueError, 'native JMTL'):
                    repair.repair_native_library(data, {'hair_alpha'}, files, 'Characters/Test/Attire')
        self.assertEqual(repair.read_native_library(data)[0]['name'], 'hair_ALPHA')

    def test_colliding_bindings_are_rejected(self):
        data = writer.write_mtls(['hair_ALPHA'], 'Characters/Test/Attire/attire.mtls')
        with self.assertRaisesRegex(ValueError, 'collide by case'):
            repair.repair_native_library(data, {'hair_alpha', 'hair_ALPHA'}, ['hair_ALPHA.jmtl'],
                                         'Characters/Test/Attire')

    def test_zero_material_native_table_is_valid_but_cannot_supply_binding(self):
        data = writer.write_mtls([], 'Characters/Test/Attire/attire.mtls')
        self.assertEqual(repair.read_native_library(data), [])
        with self.assertRaisesRegex(ValueError, 'missing native material binding'):
            repair.repair_native_library(data, {'hair_alpha'}, [], 'Characters/Test/Attire')


class RecoveredFolderTests(unittest.TestCase):
    def test_original_omits_native_records_and_physics_then_patch_preserves(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = source_tree(root)
            before = inventory(source)
            original_destination = root / 'original'; original_destination.mkdir()
            module = folder_module()
            original = module.convert_folder(str(source), str(original_destination), log=lambda text: None)
            self.assertEqual(original['models'], [])
            self.assertEqual(len(original['left_out']), len(repair.NATIVE_PHYSICS_SUFFIXES))
            fixed_destination = root / 'fixed'; fixed_destination.mkdir()
            repair.install(module)
            fixed = module.convert_folder(str(source), str(fixed_destination), log=lambda text: None)
            self.assertEqual(fixed['native_2k26_models_preserved'], 1)
            self.assertEqual(fixed['native_2k26_material_libraries_repaired'], 1)
            self.assertEqual(fixed['models'][0]['status'], 'preserved_2k26')
            self.assertEqual(fixed['models'][0]['verify'], 'pass')
            self.assertEqual(fixed['left_out'], [])
            self.assertEqual(inventory(source), before)
            output = Path(fixed['models'][0]['output'])
            self.assertEqual(output.read_bytes(), (source / '873_Default_Attire/873_Attire.mcd').read_bytes())
            self.assertEqual(len(fixed['models'][0]['native_physics_companions']), 5)
            for companion in fixed['models'][0]['native_physics_companions']:
                self.assertEqual(companion['status'], 'preserved_unverified')
                self.assertEqual(companion['sha256'], companion['output_sha256'])
                self.assertEqual(companion['compatibility'], 'not_established')
            self.assertEqual((output.parent / 'Materials/hair_ALPHA.jmtl').read_bytes(),
                             (source / '873_Default_Attire/Materials/hair_ALPHA.jmtl').read_bytes())
            saved = json.loads((fixed_destination / '873_Test - conversion report.json').read_text())
            self.assertEqual(saved, fixed)

    def test_optional_copy_off_still_outputs_required_native_assets(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source = source_tree(root)
            destination = root / 'fixed'; destination.mkdir()
            module = folder_module(); repair.install(module)
            fixed = module.convert_folder(str(source), str(destination), log=lambda text: None, copy_other=False)
            self.assertEqual(fixed['models'][0]['verify'], 'pass')
            self.assertTrue(Path(fixed['models'][0]['output']).exists())
            self.assertTrue(Path(fixed['materials'][0]['output']).exists())
            self.assertEqual(len(fixed['materials'][0]['jmtl_inventory']), 1)

    def test_native_slot_move_is_rejected_before_opaque_texture_links_change(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source = source_tree(root)
            before = inventory(source)
            destination = root / 'fixed'; destination.mkdir()
            module = folder_module(); repair.install(module)
            with self.assertRaisesRegex(ValueError, 'texture hashes'):
                module.convert_folder(str(source), str(destination), log=lambda text: None, slot='999_Test')
            self.assertEqual(list(destination.iterdir()), [])
            self.assertEqual(inventory(source), before)

    def test_non_native_reader_failure_does_not_restore_omitted_companions(self):
        def failed_read(*args, **kwargs):
            raise ValueError('native reader rejected fixture')
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source = source_tree(root)
            destination = root / 'fixed'; destination.mkdir()
            module = folder_module(failed_read); repair.install(module)
            fixed = module.convert_folder(str(source), str(destination), log=lambda text: None)
            self.assertEqual(fixed['native_2k26_models_preserved'], 0)
            self.assertEqual(fixed['models'][0]['status'], 'failed_native_2k26')
            self.assertEqual(len(fixed['left_out']), 5)
            self.assertFalse(any(Path(fixed['output']).rglob('*.wdf')))
            self.assertEqual(fixed['conversion_completeness'], 'incomplete')

    def test_original_non_native_ycl_handling_is_not_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source = source_tree(root)
            for path in source.rglob('*'):
                if path.suffix in repair.NATIVE_PHYSICS_SUFFIXES:
                    path.unlink()
            ycl = bytearray(24); struct.pack_into('<H', ycl, 18, 25)
            (source / '873_Default_Attire/873_Attire.ycl').write_bytes(ycl)
            destination = root / 'fixed'; destination.mkdir()
            module = folder_module(); repair.install(module)
            fixed = module.convert_folder(str(source), str(destination), log=lambda text: None)
            companion = fixed['models'][0]['native_physics_companions'][0]
            self.assertEqual(companion['status'], 'original_physics_conversion_unverified')
            self.assertNotEqual(companion['source_sha256'], companion['output_sha256'])
            self.assertEqual(len(fixed['physics_converted']), 1)

    def test_overlap_and_source_symlink_are_rejected_before_original_write(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source = source_tree(root); before = inventory(source)
            module = folder_module(); repair.install(module)
            for destination in (source, source / 'nested', source.parent):
                with self.subTest(destination=destination):
                    with self.assertRaisesRegex(ValueError, 'separate'):
                        module.convert_folder(str(source), str(destination), log=lambda text: None)
            destination = root / 'linked'; destination.mkdir()
            (destination / 'link').symlink_to(source, target_is_directory=True)
            with self.assertRaisesRegex(ValueError, 'link into the source'):
                module.convert_folder(str(source), str(destination), log=lambda text: None)
            self.assertEqual(inventory(source), before)

    def test_install_is_idempotent(self):
        module = folder_module(); repair.install(module); installed = module.convert_folder
        repair.install(module)
        self.assertIs(module.convert_folder, installed)


if __name__ == '__main__':
    unittest.main()
