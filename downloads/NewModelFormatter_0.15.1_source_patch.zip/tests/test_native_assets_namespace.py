"""Native dependency recovery shares the bundled writer's inner namespace."""
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gmf_native_assets as assets
from gmf_2k26_repair import game_folder, path_hash, read_native_library
from test_native_missing_data import material, dds


class NativeAssetNamespaceTests(unittest.TestCase):
    def tree(self, root):
        source = root / 'source' / 'Bryan'
        output = root / 'output' / 'Characters' / 'outer_archive' / 'Characters' / 'INPUT' / 'Bryan'
        original = source / 'BaseModel' / 'baseModel.mcd'
        target = output / 'BaseModel' / 'baseModel.mcd'
        (original.parent / 'Materials').mkdir(parents=True)
        target.parent.mkdir(parents=True)
        original.write_bytes(b'unchanged native geometry')
        target.write_bytes(original.read_bytes())
        color = path_hash('Characters/INPUT/Bryan/BaseModel/Textures/eye_color.tex')
        normal = 0xefbc052176b84e95
        for name in ('eye_l', 'eye_r', 'unused_eye'):
            (original.parent / 'Materials' / (name + '.jmtl')).write_bytes(material(0x12, {0: color, 3: normal}))
        texture = original.parent / 'Textures' / 'eye_color.dds'
        texture.parent.mkdir()
        texture.write_bytes(dds())
        return source, output, original, target, texture

    def entries(self, prefix='Characters/INPUT/Bryan/BaseModel'):
        return [{'name': name, 'path_hash': path_hash(prefix + '/Materials/' + name + '.jmtl')}
                for name in ('eye_l', 'eye_r', 'unused_eye')]

    def test_virtual_file_uses_shared_inner_folder_and_keeps_the_actual_leaf(self):
        cases = (
            ('/mods/Characters/outer/Characters/INPUT/Bryan/BaseModel/Materials/eye_l.jmtl',
             'Characters/INPUT/Bryan/BaseModel/Materials/eye_l.jmtl'),
            (r'C:\Mods\Characters\outer\characters\INPUT\Bryan\BaseModel\Textures\eye_color.dds',
             'Characters/INPUT/Bryan/BaseModel/Textures/eye_color.dds'),
            ('/mods/Characters/Bryan/BaseModel/Materials/eye_l.jmtl',
             'Characters/Bryan/BaseModel/Materials/eye_l.jmtl'),
        )
        for filename, expected in cases:
            with self.subTest(filename=filename):
                self.assertEqual(assets.virtual_file(filename), expected)
                normalized = Path(filename.replace('\\', '/'))
                self.assertEqual(assets.virtual_file(filename), game_folder(normalized) + '/' + normalized.name)
        for filename in ('/mods/CharactersBackup/X/eye_l.jmtl', r'C:\Mods\MyCharacters\X\eye_l.jmtl'):
            with self.subTest(filename=filename):
                self.assertIsNone(assets.virtual_file(filename))

    def test_nested_material_and_texture_index_resolves_only_inner_namespace(self):
        with tempfile.TemporaryDirectory() as name:
            source, output, original, target, texture = self.tree(Path(name))
            index = assets.AssetIndex(source, output)
            inner_material = self.entries()[0]['path_hash']
            outer_material = self.entries('Characters/outer_archive/Characters/INPUT/Bryan/BaseModel')[0]['path_hash']
            inner_texture = path_hash('Characters/INPUT/Bryan/BaseModel/Textures/eye_color.tex')
            outer_texture = path_hash('Characters/outer_archive/Characters/INPUT/Bryan/BaseModel/Textures/eye_color.tex')
            self.assertEqual(index.by_hash['material'][inner_material], [original.parent / 'Materials/eye_l.jmtl'])
            self.assertNotIn(outer_material, index.by_hash['material'])
            self.assertEqual(index.by_hash['texture'][inner_texture], [texture])
            self.assertNotIn(outer_texture, index.by_hash['texture'])
            result = assets.recover_textures([{'binding': 'eye_l', 'output': str(target.parent / 'Materials/eye_l.jmtl'),
                'texture_references': [{'field': 'colorMap@ref', 'hash': inner_texture}]}], index)
            self.assertEqual(result[0]['state'], 'present_or_recovered')
            self.assertEqual(index.target(texture).read_bytes(), texture.read_bytes())
            unresolved = assets.recover_textures([{'binding': 'eye_l', 'output': 'unused',
                'texture_references': [{'field': 'colorMap@ref', 'hash': outer_texture}]}], index)
            self.assertEqual(unresolved[0]['state'], 'unresolved_external_or_missing_texture')

    def test_already_correct_nested_table_is_byte_preserved_including_unused_entry(self):
        with tempfile.TemporaryDirectory() as name:
            source, output, original, target, _ = self.tree(Path(name))
            correct = assets.write_library(self.entries())
            original.with_suffix('.mtls').write_bytes(correct)
            target.with_suffix('.mtls').write_bytes(correct)
            snapshot = {str(p): p.read_bytes() for p in source.rglob('*') if p.is_file()}
            result = assets.recover_materials(original, target, {'eye_l', 'eye_r'}, assets.AssetIndex(source, output))
            self.assertTrue(result['complete'])
            self.assertEqual(target.with_suffix('.mtls').read_bytes(), correct)
            self.assertFalse(any(x['kind'] == 'repair_native_material_table' for x in result['repairs']))
            self.assertTrue(any(x.get('used_by_mesh') is False for x in result['materials']))
            for filename, data in snapshot.items():
                self.assertEqual(Path(filename).read_bytes(), data)
            before = {str(p): p.read_bytes() for p in output.rglob('*') if p.is_file()}
            again = assets.recover_materials(original, target, {'eye_l', 'eye_r'}, assets.AssetIndex(source, output))
            self.assertTrue(again['complete'])
            self.assertEqual(again['repairs'], [])
            self.assertEqual(before, {str(p): p.read_bytes() for p in output.rglob('*') if p.is_file()})

    def test_missing_table_rebuild_uses_inner_hashes_and_preserves_authored_payloads(self):
        with tempfile.TemporaryDirectory() as name:
            source, output, original, target, _ = self.tree(Path(name))
            payloads = {p.name: p.read_bytes() for p in (original.parent / 'Materials').iterdir()}
            result = assets.recover_materials(original, target, {'eye_l', 'eye_r'}, assets.AssetIndex(source, output))
            self.assertTrue(result['complete'])
            self.assertTrue(any(x['kind'] == 'rebuild_missing_native_mtls' for x in result['repairs']))
            entries = read_native_library(target.with_suffix('.mtls').read_bytes())
            self.assertEqual([(e['name'], e['path_hash']) for e in entries],
                             [(e['name'], e['path_hash']) for e in self.entries()[:2]])
            for name in ('eye_l.jmtl', 'eye_r.jmtl'):
                self.assertEqual((target.parent / 'Materials' / name).read_bytes(), payloads[name])
            self.assertEqual(target.read_bytes(), original.read_bytes())

    def test_wrong_outer_table_repairs_only_hashes_and_is_idempotent(self):
        with tempfile.TemporaryDirectory() as name:
            source, output, original, target, _ = self.tree(Path(name))
            wrong = assets.write_library(self.entries('Characters/outer_archive/Characters/INPUT/Bryan/BaseModel'))
            original.with_suffix('.mtls').write_bytes(wrong)
            target.with_suffix('.mtls').write_bytes(wrong)
            result = assets.recover_materials(original, target, {'eye_l', 'eye_r'}, assets.AssetIndex(source, output))
            self.assertTrue(result['complete'])
            changed = target.with_suffix('.mtls').read_bytes()
            self.assertEqual(changed, assets.write_library(self.entries()))
            allowed = {i for e in read_native_library(wrong) for i in range(e['hash_offset'], e['hash_offset'] + 8)}
            differences = {i for i, (a, b) in enumerate(zip(wrong, changed)) if a != b}
            self.assertTrue(differences)
            self.assertLessEqual(differences, allowed)
            self.assertEqual(original.with_suffix('.mtls').read_bytes(), wrong)
            again = assets.recover_materials(original, target, {'eye_l', 'eye_r'}, assets.AssetIndex(source, output))
            self.assertEqual(again['repairs'], [])
            self.assertEqual(target.with_suffix('.mtls').read_bytes(), changed)
            self.assertEqual(target.read_bytes(), original.read_bytes())


if __name__ == '__main__':
    unittest.main()
