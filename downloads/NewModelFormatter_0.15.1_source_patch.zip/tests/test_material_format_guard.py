"""Material-format rejection must change actual folder copying and readiness."""
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gmf_repair as repair
from test_2k26_repair import folder_module
from test_material_formats import inline_block, library, STUB
from test_repair import make_material_module, material


class ConverterFormatGuardTests(unittest.TestCase):
    def test_unsupported_old_inline_tables_cannot_take_native_admission_token(self):
        for version in (1, 2, 99):
            with self.subTest(version=version), tempfile.TemporaryDirectory() as tmp:
                source = Path(tmp) / 'source.mtls'; output = Path(tmp) / 'output.mtls'
                raw = library([inline_block(version)], ['teeth']); source.write_bytes(raw)
                module = make_material_module(None); repair.patch_material_converter(module)
                result = module.convert_library(str(source), str(output), {'teeth'})
                self.assertEqual(result['status'], 'unsupported_material_format')
                self.assertTrue(result['problems']); self.assertFalse(output.exists())
                self.assertEqual(source.read_bytes(), raw)
                self.assertEqual(result['material_format']['observed_block_versions'], [version])

    def test_malformed_and_ambiguous_inputs_fail_before_any_material_writes(self):
        malformed = library([inline_block()])[:-1]
        ambiguous = library([inline_block(), STUB])
        for raw in (malformed, ambiguous):
            with tempfile.TemporaryDirectory() as tmp:
                source = Path(tmp) / 'source.mtls'; source.write_bytes(raw)
                module = make_material_module([material('teeth')]); repair.patch_material_converter(module)
                result = module.convert_library(str(source), str(Path(tmp) / 'output.mtls'), {'teeth'})
                self.assertEqual(result['status'], 'unsupported_material_format')
                self.assertEqual(list(Path(tmp).iterdir()), [source])

    def test_existing_outputs_are_preserved_but_never_marked_newly_written(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / 'source.mtls'; source.write_bytes(library([inline_block(2)]))
            output = Path(tmp) / 'output.mtls'; output.write_bytes(b'preexisting output')
            module = make_material_module(None); repair.patch_material_converter(module)
            result = module.convert_library(str(source), str(output))
            self.assertTrue(result['preexisting_output_material'])
            self.assertEqual(output.read_bytes(), b'preexisting output')
            self.assertEqual(result['output_material_state'], 'not_written_or_copied')

    def test_native_format_is_distinguished_from_shader_and_texture_readiness(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / 'source.mtls'; raw = library([STUB], ['teeth']); source.write_bytes(raw)
            output = Path(tmp) / 'output.mtls'
            module = make_material_module(None); repair.patch_material_converter(module)
            result = module.convert_library(str(source), str(output), {'teeth'})
            self.assertEqual(result['status'], 'already 2K26')
            self.assertTrue(result['material_format']['safe_as_native'])
            self.assertIn('not validated', result['material_validation_scope'])
            self.assertTrue(result['problems']); self.assertFalse(output.exists())
            self.assertEqual(source.read_bytes(), raw)

    def test_supported_inline_v3_conversion_still_emits_original_bindings(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / 'source.mtls'; raw = library([inline_block()], ['teeth']); source.write_bytes(raw)
            module = make_material_module([material('teeth')]); repair.patch_material_converter(module)
            result = module.convert_library(str(source), str(Path(tmp) / 'output.mtls'), {'teeth'})
            self.assertEqual(result['status'], 'converted')
            self.assertEqual(result['material_format']['classification'], 'supported_inline_v3')
            self.assertEqual([m['name'] for m in result['materials']], ['teeth'])
            self.assertEqual(source.read_bytes(), raw)

    def test_no_material_return_without_format_evidence_is_not_native(self):
        with tempfile.TemporaryDirectory() as tmp:
            module = make_material_module(None); repair.patch_material_converter(module)
            result = module.convert_library(str(Path(tmp) / 'absent.mtls'), str(Path(tmp) / 'output.mtls'))
            self.assertEqual(result['status'], 'unsupported_material_format')
            self.assertEqual(result['material_format']['classification'], 'source_not_inspected')

    def test_reader_disagreement_does_not_admit_an_inline_table_as_native(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / 'source.mtls'; source.write_bytes(library([inline_block()], ['teeth']))
            module = make_material_module(None); repair.patch_material_converter(module)
            result = module.convert_library(str(source), str(Path(tmp) / 'output.mtls'))
            self.assertEqual(result['material_format']['classification'], 'supported_inline_v3')
            self.assertEqual(result['status'], 'unsupported_material_format')
            self.assertIn('reader returned no materials', result['problems'][0])


def conversion_folder(material_module):
    """Use Gorilla's inspected real folder loop; stub only geometry backend."""
    folder = folder_module(); namespace = folder.convert_folder.__globals__
    def convert_model(source, target, reference, **kwargs):
        Path(target).parent.mkdir(parents=True, exist_ok=True)
        Path(target).write_bytes(b'test converted geometry')
        return {'source': source, 'output': target, 'source_version': '0x29',
                'kind': 'base model', 'bones': '209 -> 175', 'status': 'converted',
                'notes': []}
    namespace['materials'] = material_module
    namespace['mtl25'] = material_module.mtl25
    namespace['_used_materials'] = lambda path: ({'teeth'}, {'M_Teeth': 3})
    namespace['convert'] = types.SimpleNamespace(
        LEFT_OUT_SIDECARS=(), EMBEDDED_SIDECARS=(), EMBED_PHYSICS=False,
        convert_mcd=convert_model, verify=lambda *args, **kwargs: (True, [], {}))
    namespace['mcd'] = types.SimpleNamespace(mdl_version=lambda path: 41)
    repair.patch_folder_converter(folder)
    return folder


class RecoveredFolderFormatGuardTests(unittest.TestCase):
    def convert(self, root, raw):
        source = root / 'input' / '159_Bryan_Danielson'
        base = source / 'BaseModel'; base.mkdir(parents=True)
        (base / 'baseModel.mdl').write_bytes(b'actual source fixture geometry')
        table = base / 'baseModel.mtls'; table.write_bytes(raw)
        module = make_material_module(None); repair.patch_material_converter(module)
        folder = conversion_folder(module)
        report = folder.convert_folder(str(source), str(root / 'output'), log=lambda text: None, copy_other=True)
        return source, table, report

    def test_original_generic_copy_pass_cannot_emit_unsupported_table(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); raw = library([inline_block(2)], ['teeth'])
            source, table, report = self.convert(root, raw)
            self.assertEqual(len(report['models']), 1)
            self.assertEqual(report['models'][0]['verify'], 'pass')
            self.assertEqual(report['materials'][0]['status'], 'unsupported_material_format')
            self.assertFalse(Path(report['materials'][0]['output']).exists())
            self.assertEqual(report['copied'], 0)
            self.assertEqual(report['conversion_completeness'], 'incomplete')
            self.assertIn('BaseModel/baseModel.mtls: material conversion not completed', report['problems'][0])
            self.assertEqual(table.read_bytes(), raw)
            persisted = json.loads((root / 'output' / (source.name + ' - conversion report.json')).read_text())
            self.assertEqual(persisted['problems'], report['problems'])

    def test_exact_native_table_copy_is_preserved_with_unverified_dependencies(self):
        with tempfile.TemporaryDirectory() as tmp:
            raw = library([STUB], ['teeth'])
            source, table, report = self.convert(Path(tmp), raw)
            self.assertEqual(Path(report['materials'][0]['output']).read_bytes(), raw)
            self.assertEqual(table.read_bytes(), raw)
            self.assertEqual(report['materials'][0]['status'], 'already 2K26')
            self.assertEqual(report['conversion_completeness'], 'incomplete')
            self.assertTrue(any('JMTL binding and texture validation' in p for p in report['problems']))

    def test_readiness_propagation_is_idempotent_and_keeps_structural_verdict(self):
        report = {'source': '/input', 'warnings': [], 'problems': [],
                  'models': [{'verify': 'pass'}], 'materials': [
                      {'source': '/input/BaseModel/baseModel.mtls',
                       'problems': ['unsupported block version 2']} ]}
        repair.mark_readiness(report); repair.mark_readiness(report)
        self.assertEqual(report['problems'], ['BaseModel/baseModel.mtls: unsupported block version 2'])
        self.assertEqual(report['models'][0]['verify'], 'pass')
        self.assertEqual(report['conversion_completeness'], 'incomplete')


if __name__ == '__main__':
    unittest.main()
