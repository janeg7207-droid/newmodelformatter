"""Bind real named DDS dependencies without replacing external references."""
import copy
import hashlib
import importlib.util
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gmf_local_textures as local
from gmf_2k26_repair import path_hash
from gmf_jmtl_audit import inspect_material, Table
import gmf_repair
from test_material_formats import inline_block, library
from test_material_format_guard import conversion_folder
from test_repair import make_material_module, recovered_function


def dds(width=4, height=4, mips=1, *, dxgi=None, flags=0x81007, caps=0x1000, fourcc=b'DXT1'):
    """Independently construct DDS envelopes with complete BC1/BC7 payloads."""
    data = bytearray(148 if dxgi is not None else 128)
    block_bytes = 8 if dxgi == 71 or (dxgi is None and fourcc == b'DXT1') else 16
    struct.pack_into('<4sIIIIIII', data, 0, b'DDS ', 124, flags, height, width,
                     ((width + 3) // 4) * ((height + 3) // 4) * block_bytes, 0, mips)
    struct.pack_into('<II4s', data, 76, 32, 4, b'DX10' if dxgi is not None else fourcc)
    struct.pack_into('<I', data, 108, caps)
    if dxgi is not None:
        struct.pack_into('<5I', data, 128, dxgi, 3, 0, 1, 0)
    for level in range(mips):
        w, h = max(1, width >> level), max(1, height >> level)
        data.extend(bytes(((w + 3) // 4) * ((h + 3) // 4) * block_bytes))
    return bytes(data)


def mat(name='eye_l', texture='eye_color', reference=123):
    return types.SimpleNamespace(name=name, shader='yCh_eye', technique='Normal',
        params={'colorMap': texture, 'colorMap@ref': reference,
                'g_nrmMap': 'eye_nrm', 'g_nrmMap@ref': 456},
        types={'colorMap': 6, 'colorMap@ref': 7, 'g_nrmMap': 6, 'g_nrmMap@ref': 7})


def paths(root):
    source = root / 'input' / '159_Bryan_Danielson' / 'BaseModel' / 'baseModel.mtls'
    target = root / 'output' / 'Characters' / '159_Bryan_Danielson' / 'BaseModel' / 'baseModel.mtls'
    source.parent.mkdir(parents=True); (source.parent / 'Textures').mkdir()
    return source, target


def bind(materials, source, target, *, keys=lambda item: ['colorMap@ref'], used=None):
    return local.bind_named_local_textures(materials, source, target,
        game_folder=lambda folder: 'Characters/159_Bryan_Danielson/BaseModel',
        dependency_keys=keys, used_names=used)


class LocalBindingTests(unittest.TestCase):
    def test_named_existing_eye_dds_sets_destination_hash_and_copies_exact_bytes(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); texture = source.parent / 'Textures' / 'eye_color.dds'
            raw = dds(); texture.write_bytes(raw); item = mat(); before = copy.deepcopy(item.params)
            converted, evidence, problems = bind([item], source, target)
            virtual = 'Characters/159_Bryan_Danielson/BaseModel/Textures/eye_color.tex'
            self.assertEqual(converted[0].params['colorMap@ref'], path_hash(virtual))
            self.assertEqual(item.params, before); self.assertIsNot(converted[0].params, item.params)
            self.assertIsNot(converted[0].types, item.types); self.assertEqual(problems, [])
            self.assertEqual((target.parent / 'Textures' / 'eye_color.dds').read_bytes(), raw)
            self.assertEqual(texture.read_bytes(), raw)
            self.assertEqual(evidence[0]['source_sha256'], hashlib.sha256(raw).hexdigest())
            self.assertEqual(evidence[0]['destination_virtual_path'], virtual)
            self.assertEqual(evidence[0]['policy'], local.POLICY)
            self.assertEqual(converted[0].params['g_nrmMap@ref'], 456)

    def test_missing_files_and_null_bindings_preserve_existing_external_refs(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); (source.parent / 'Textures' / 'eye_color.dds').write_bytes(dds())
            for item in [mat(reference=0), mat(reference=0xffffffffffffffff), mat(texture='global_eye')]:
                before = copy.deepcopy(item.params); result, evidence, problems = bind([item], source, target)
                self.assertEqual(result[0].params, before); self.assertEqual(evidence, []); self.assertEqual(problems, [])
            self.assertFalse(target.parent.exists())

    def test_only_the_active_shader_dependencies_and_used_materials_can_change(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp))
            for name in ['eye_color', 'eye_nrm']:
                (source.parent / 'Textures' / (name + '.dds')).write_bytes(dds())
            result, evidence, _ = bind([mat(), mat('unused')], source, target, used={'eye_l'})
            self.assertEqual(result[0].params['g_nrmMap@ref'], 456)
            self.assertEqual(result[1].params['colorMap@ref'], 123)
            self.assertEqual([e['field'] for e in evidence], ['colorMap@ref'])

    def test_windows_case_collision_never_picks_an_arbitrary_texture(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp))
            for name in ['eye_color.dds', 'EYE_COLOR.DDS']:
                (source.parent / 'Textures' / name).write_bytes(dds())
            result, evidence, problems = bind([mat()], source, target)
            self.assertEqual(result[0].params['colorMap@ref'], 123); self.assertEqual(evidence, [])
            self.assertIn('ambiguous', problems[0]); self.assertFalse(target.parent.exists())

    def test_unique_case_insensitive_texture_keeps_actual_filename_and_hash_algorithm(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); texture = source.parent / 'Textures' / 'EYE_COLOR.DDS'
            texture.write_bytes(dds()); result, evidence, problems = bind([mat()], source, target)
            self.assertEqual(problems, []); self.assertTrue((target.parent / 'Textures' / texture.name).exists())
            self.assertEqual(evidence[0]['destination_virtual_path'], 'Characters/159_Bryan_Danielson/BaseModel/Textures/EYE_COLOR.tex')
            self.assertEqual(result[0].params['colorMap@ref'], path_hash(evidence[0]['destination_virtual_path'].lower()))

    def test_traversal_and_source_or_output_symlink_escape_preserve_reference(self):
        for case in ['traversal', 'source', 'output']:
            with self.subTest(case=case), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp); source, target = paths(root); outside = root / 'outside'; outside.mkdir()
                asset = outside / 'eye_color.dds'; asset.write_bytes(dds())
                item = mat(texture='../eye_color') if case == 'traversal' else mat()
                if case == 'source':
                    (source.parent / 'Textures' / 'eye_color.dds').symlink_to(asset)
                else:
                    (source.parent / 'Textures' / 'eye_color.dds').write_bytes(dds())
                if case == 'output':
                    target.parent.mkdir(parents=True); (target.parent / 'Textures').symlink_to(outside, target_is_directory=True)
                result, evidence, problems = bind([item], source, target)
                self.assertEqual(result[0].params['colorMap@ref'], 123); self.assertEqual(evidence, [])
                self.assertTrue(problems); self.assertEqual(asset.read_bytes(), dds())

    def test_overlapping_output_and_source_is_rejected_before_copy(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); texture = source.parent / 'Textures' / 'eye_color.dds'; texture.write_bytes(dds())
            result, evidence, problems = bind([mat()], source, source.parent / 'new.mtls')
            self.assertEqual(result[0].params['colorMap@ref'], 123); self.assertEqual(evidence, [])
            self.assertIn('separate output', problems[0]); self.assertEqual(texture.read_bytes(), dds())

    def test_already_bound_hash_remains_stable_and_required_dependency_still_copies(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); (source.parent / 'Textures' / 'eye_color.dds').write_bytes(dds())
            expected = path_hash('Characters/159_Bryan_Danielson/BaseModel/Textures/eye_color.tex')
            result, evidence, problems = bind([mat(reference=expected)], source, target)
            self.assertEqual(result[0].params['colorMap@ref'], expected); self.assertFalse(evidence[0]['changed'])
            self.assertEqual(problems, []); self.assertTrue((target.parent / 'Textures' / 'eye_color.dds').exists())

    def test_invalid_named_dds_does_not_emit_a_replacement_reference(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); (source.parent / 'Textures' / 'eye_color.dds').write_bytes(dds()[:-1])
            result, evidence, problems = bind([mat()], source, target)
            self.assertEqual(result[0].params['colorMap@ref'], 123); self.assertEqual(evidence, [])
            self.assertIn('mip extents', problems[0]); self.assertFalse(target.parent.exists())
            self.assertIn('eye_color.dds', problems[0]); self.assertTrue(problems[0].endswith('; reference preserved'))

    def test_sparse_caps_binding_uses_exact_supported_texture_and_preserves_all_bytes(self):
        for dxgi in (None, 98):
            with self.subTest(dxgi=dxgi), tempfile.TemporaryDirectory() as tmp:
                source, target = paths(Path(tmp)); texture = source.parent / 'Textures' / 'eye_color.dds'
                raw = dds(7, 5, 3, dxgi=dxgi, caps=0); texture.write_bytes(raw)
                item = mat(); before = copy.deepcopy(item.params)
                result, evidence, problems = bind([item], source, target)
                virtual = 'Characters/159_Bryan_Danielson/BaseModel/Textures/eye_color.tex'
                self.assertEqual(problems, []); self.assertEqual(len(evidence), 1)
                self.assertEqual(result[0].params['colorMap@ref'], path_hash(virtual))
                self.assertEqual(result[0].params['g_nrmMap@ref'], before['g_nrmMap@ref'])
                self.assertEqual(item.params, before); self.assertEqual(texture.read_bytes(), raw)
                copied = (target.parent / 'Textures' / texture.name).read_bytes()
                self.assertEqual(copied, raw); self.assertEqual(struct.unpack_from('<I', copied, 108)[0], 0)
                self.assertEqual(evidence[0]['source_sha256'], hashlib.sha256(raw).hexdigest())
                self.assertEqual(evidence[0]['output_sha256'], evidence[0]['source_sha256'])
                self.assertFalse(evidence[0]['dds']['capsTextureBitPresent'])
                self.assertTrue(evidence[0]['dds']['header_advisories'])

    def test_underdeclared_full_chain_binds_normalized_output_without_changing_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); texture = source.parent / 'Textures' / 'eye_color.dds'
            expected = dds(8, 4, 4, fourcc=b'DXT5', caps=0)
            raw = bytearray(expected); struct.pack_into('<I', raw, 28, 1); raw = bytes(raw)
            texture.write_bytes(raw); items = [mat('eye_l'), mat('eye_r')]
            before = [copy.deepcopy(item.params) for item in items]
            converted, evidence, problems = bind(items, source, target)
            self.assertEqual(problems, []); self.assertEqual(len(evidence), 2)
            self.assertEqual(texture.read_bytes(), raw)
            self.assertEqual((target.parent / 'Textures' / texture.name).read_bytes(), expected)
            for item, original, output, row in zip(items, before, converted, evidence):
                self.assertEqual(item.params, original)
                self.assertEqual(output.params['colorMap@ref'], path_hash('Characters/159_Bryan_Danielson/BaseModel/Textures/eye_color.tex'))
                self.assertEqual(row['source_sha256'], hashlib.sha256(raw).hexdigest())
                self.assertEqual(row['output_sha256'], hashlib.sha256(expected).hexdigest())
                self.assertFalse(row['dds_file_bytes_identical']); self.assertTrue(row['dds_compressed_payload_byte_identical'])
                self.assertEqual(row['dds']['mip_count_repair']['changed_header_byte_offsets'], [28])

    def test_partial_chain_binding_preserves_reference_and_names_the_rejected_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); texture = source.parent / 'Textures' / 'eye_color.dds'
            raw = bytearray(dds(8, 4, 3, fourcc=b'DXT5')); struct.pack_into('<I', raw, 28, 1); raw = bytes(raw)
            texture.write_bytes(raw); item = mat(); before = copy.deepcopy(item.params)
            output, evidence, problems = bind([item], source, target)
            self.assertEqual(output[0].params, before); self.assertEqual(item.params, before)
            self.assertEqual(evidence, []); self.assertIn('eye_color.dds', problems[0])
            self.assertFalse(target.parent.exists()); self.assertEqual(texture.read_bytes(), raw)


class DdsExtentTests(unittest.TestCase):
    def test_sparse_texture_caps_are_advisory_only_for_complete_supported_payloads(self):
        for dxgi in (None, 71, 98):
            with self.subTest(dxgi=dxgi):
                complete = local.inspect_dds(dds(7, 5, 3, dxgi=dxgi))
                sparse = local.inspect_dds(dds(7, 5, 3, dxgi=dxgi, caps=0))
                for key in ('width', 'height', 'mip_count', 'format', 'payload_bytes', 'header_and_extents_validated'):
                    self.assertEqual(sparse[key], complete[key])
                self.assertTrue(complete['capsTextureBitPresent']); self.assertEqual(complete['header_advisories'], [])
                self.assertFalse(sparse['capsTextureBitPresent']); self.assertIn('original bytes preserved', sparse['header_advisories'][0])

    def test_sparse_caps_do_not_bypass_actual_dimensions_or_required_dimension_flags(self):
        cases = [(12, 0, 'dimensions'), (16, 0, 'dimensions'), (8, 0, 'dimension flags')]
        for offset, value, expected in cases:
            with self.subTest(offset=offset):
                raw = bytearray(dds(caps=0)); struct.pack_into('<I', raw, offset, value)
                with self.assertRaises(ValueError) as caught: local.inspect_dds(bytes(raw))
                message = str(caught.exception)
                self.assertIn(expected, message)
                for detail in ('width=', 'height=', 'flags=0x', 'caps=0x0'): self.assertIn(detail, message)

    def test_sparse_caps_do_not_bypass_header_sizes_or_complete_mip_extents(self):
        base = dds(caps=0); bad_header = bytearray(base); struct.pack_into('<I', bad_header, 4, 123)
        bad_pixel_format = bytearray(base); struct.pack_into('<I', bad_pixel_format, 76, 31)
        for raw in (bytes(bad_header), bytes(bad_pixel_format), base[:-1], base + b'extra',
                    dds(4, 4, 4, caps=0), dds(dxgi=98, caps=0)[:140]):
            with self.subTest(length=len(raw)), self.assertRaises(ValueError): local.inspect_dds(raw)

    def test_sparse_caps_do_not_bypass_cube_volume_array_or_resource_dimension_guards(self):
        base = dds(dxgi=98, caps=0)
        cases = [(112, 0x200), (24, 2), (136, 4), (140, 2), (132, 4)]
        for offset, value in cases:
            with self.subTest(offset=offset):
                raw = bytearray(base); struct.pack_into('<I', raw, offset, value)
                with self.assertRaises(ValueError): local.inspect_dds(bytes(raw))

    def test_all_bc1_mips_and_nonaligned_dimensions_are_bounded(self):
        self.assertEqual(local.inspect_dds(dds(7, 5, 3))['mip_count'], 3)
        for raw in [dds()[:-1], dds() + b'extra', dds(4, 4, 4)]:
            with self.assertRaises(ValueError): local.inspect_dds(raw)

    def test_complete_bc7_with_observed_advisory_flag_omissions_remains_supported(self):
        result = local.inspect_dds(dds(8, 8, 4, dxgi=98, flags=0x20006))
        self.assertEqual(result['format'], 'DXGI_98'); self.assertTrue(result['header_and_extents_validated'])

    def test_cube_array_unknown_format_and_truncated_dx10_are_rejected(self):
        base = dds(dxgi=98)
        cube = bytearray(base); struct.pack_into('<I', cube, 136, 4)
        array = bytearray(base); struct.pack_into('<I', array, 140, 2)
        for raw in [bytes(cube), bytes(array), base[:140], dds(dxgi=28)]:
            with self.assertRaises(ValueError): local.inspect_dds(raw)


class DdsPreparationTests(unittest.TestCase):
    def test_valid_single_full_and_partial_chains_remain_byte_identical(self):
        for data in [dds(), dds(8, 4, 3, caps=0), dds(8, 4, 4, dxgi=98), dds(512, 256, 10, fourcc=b'DXT5')]:
            with self.subTest(size=len(data)):
                output, facts = local.prepare_local_dds(data)
                self.assertEqual(output, data); repair = facts['mip_count_repair']
                self.assertEqual(repair['state'], 'not_needed')
                self.assertEqual(repair['changed_header_byte_offsets'], [])
                self.assertEqual(repair['source_sha256'], repair['output_sha256'])
                self.assertTrue(repair['compressed_payload_byte_identical'])

    def test_only_count_increases_when_every_mip_through_one_by_one_exists(self):
        for dxgi, fourcc in [(None, b'DXT1'), (None, b'DXT5'), (98, b'DXT1')]:
            complete = dds(8, 4, 4, dxgi=dxgi, fourcc=fourcc, caps=0)
            for declared in (0, 1, 2, 3):
                with self.subTest(dxgi=dxgi, fourcc=fourcc, declared=declared):
                    source = bytearray(complete); struct.pack_into('<I', source, 28, declared); before = bytes(source)
                    with self.assertRaisesRegex(ValueError, 'mip extents'): local.inspect_dds(bytes(source))
                    output, facts = local.prepare_local_dds(source)
                    self.assertEqual(output, complete); self.assertEqual(bytes(source), before)
                    self.assertEqual(output[:28], before[:28]); self.assertEqual(output[32:], before[32:])
                    repair = facts['mip_count_repair']
                    self.assertEqual(repair['declared_mip_count'], declared)
                    self.assertEqual(repair['effective_declared_mip_count'], declared or 1)
                    self.assertEqual(repair['inferred_mip_count'], 4)
                    self.assertEqual(repair['changed_header_byte_offsets'], [28])
                    self.assertTrue(repair['compressed_payload_byte_identical'])
                    self.assertEqual(repair['source_sha256'], hashlib.sha256(before).hexdigest())
                    self.assertEqual(repair['output_sha256'], hashlib.sha256(output).hexdigest())
                    self.assertFalse(facts['capsTextureBitPresent'])
                    self.assertTrue(local.inspect_dds(output)['header_and_extents_validated'])

    def test_complete_chain_with_correct_zero_effective_count_is_not_rewritten(self):
        raw = bytearray(dds()); struct.pack_into('<I', raw, 28, 0)
        output, facts = local.prepare_local_dds(raw)
        self.assertEqual(output, bytes(raw)); self.assertEqual(facts['mip_count'], 1)
        self.assertEqual(facts['mip_count_repair']['state'], 'not_needed')

    def test_partial_prefix_whole_mip_truncation_and_arbitrary_trailers_are_rejected(self):
        full = bytearray(dds(8, 4, 4, fourcc=b'DXT5')); struct.pack_into('<I', full, 28, 1); full = bytes(full)
        partial = bytearray(dds(8, 4, 3, fourcc=b'DXT5')); struct.pack_into('<I', partial, 28, 1)
        for raw in (bytes(partial), full[:-16], full[:-1], full + b'x', full + bytes(16)):
            with self.subTest(size=len(raw)), self.assertRaisesRegex(ValueError, 'mip extents'):
                local.prepare_local_dds(raw)

    def test_overdeclared_and_missing_mip_counts_are_never_decreased(self):
        for physical, declared in [(1, 3), (3, 4), (4, 5)]:
            raw = bytearray(dds(8, 4, physical, fourcc=b'DXT5')); struct.pack_into('<I', raw, 28, declared)
            before = bytes(raw)
            with self.subTest(physical=physical, declared=declared), self.assertRaises(ValueError):
                local.prepare_local_dds(raw)
            self.assertEqual(bytes(raw), before)

    def test_resource_format_header_and_dimensions_guards_still_precede_inference(self):
        base = bytearray(dds(8, 4, 4, dxgi=98)); struct.pack_into('<I', base, 28, 1)
        cases = [(4, 123), (76, 31), (8, 0), (12, 0), (16, 0), (24, 2), (80, 0),
                 (112, 0x200), (128, 28), (132, 4), (136, 4), (140, 2)]
        for offset, value in cases:
            with self.subTest(offset=offset):
                raw = bytearray(base); struct.pack_into('<I', raw, offset, value); before = bytes(raw)
                with self.assertRaises(ValueError): local.prepare_local_dds(raw)
                self.assertEqual(bytes(raw), before)
        raw = bytearray(base); raw[84:88] = b'NOPE'
        with self.assertRaises(ValueError): local.prepare_local_dds(raw)

    def test_actual_uploaded_aj_eyelash_has_complete_bc3_chain_and_only_count_byte_changes(self):
        file = Path('/workspace/attachments/0e6770b3-f949-43b1-96b0-ae74929033ce/eyelash_color.dds')
        if not file.is_file(): self.skipTest('uploaded AJ eyelash DDS is unavailable in this workspace')
        raw = file.read_bytes(); digest = hashlib.sha256(raw).hexdigest()
        self.assertEqual(digest, '696ae222df96b3d4cdba2aac09cb705760f11f7991ccb000e19aade95ceaf763')
        with self.assertRaisesRegex(ValueError, 'mip extents'): local.inspect_dds(raw)
        output, facts = local.prepare_local_dds(raw)
        self.assertEqual((facts['width'], facts['height'], facts['format'], facts['mip_count']), (512, 256, 'DXT5', 10))
        self.assertEqual(facts['payload_bytes'], 174800)
        self.assertEqual(facts['mip_count_repair']['changed_header_byte_offsets'], [28])
        self.assertEqual(output[:28], raw[:28]); self.assertEqual(output[32:], raw[32:])
        self.assertEqual(file.read_bytes(), raw)
        self.assertEqual(hashlib.sha256(output).hexdigest(), '01988adde9c168db814b91ffd4ddcd4ed896e8b7cd92bd79afba896d4a904f63')
        for invalid in (raw[:-1], raw[:-16], raw + b'x'):
            with self.assertRaisesRegex(ValueError, 'mip extents'): local.prepare_local_dds(invalid)


def reference_writer():
    root = Path(__file__).resolve().parents[1] / 'reference_source' / 'WWE2K_MDL'
    vendor = root / 'Blender' / '_vendor' / 'flatbuffers'
    spec = importlib.util.spec_from_file_location('local_texture_test_fb', vendor / '__init__.py', submodule_search_locations=[str(vendor)])
    module = importlib.util.module_from_spec(spec); sys.modules[spec.name] = module; spec.loader.exec_module(module)
    prior = sys.modules.get('flatbuffers'); sys.modules['flatbuffers'] = module
    try:
        spec = importlib.util.spec_from_file_location('local_texture_reference_writer', root / 'Serialize' / 'jmtl_writer.py')
        writer = importlib.util.module_from_spec(spec); spec.loader.exec_module(writer)
    finally:
        if prior is None: sys.modules.pop('flatbuffers', None)
        else: sys.modules['flatbuffers'] = prior
    return writer


def original_shader_converter(shader):
    namespace = dict(SKIN=25, HEAD=23, CARUNCLE=19, EYE=18, EYELASH=20, GEAR=21, HAIR=22, TEETH=26,
        GEAR_SOLID=0, GEAR_CUTOUT=1, GEAR_SEE_THROUGH=2, GEAR_IRRADIANCE=(0, .75, .75),
        TEETH_IRRADIANCE=(0, .7490196, .7490196), shader_for=lambda item: (shader, None),
        _ref=lambda item, key: item.params.get(key),
        _num=lambda item, key, default=None: item.params.get(key, default), clean_name=lambda value: value.split(':', 1)[0])
    return recovered_function('gmf.materials', 'to_2k26', namespace)


class OriginalConverterBindingTests(unittest.TestCase):
    def setUp(self):
        self.writer = reference_writer()

    def converter(self, items, shader):
        module = make_material_module(items)
        converter = original_shader_converter(shader)
        module.to_2k26 = converter; module.convert_library.__globals__['to_2k26'] = converter
        module.write_jmtl = self.writer.write_jmtl; module.convert_library.__globals__['write_jmtl'] = module.write_jmtl
        module.game_folder = lambda folder: 'Characters/159_Bryan_Danielson/BaseModel'
        module.convert_library.__globals__['game_folder'] = module.game_folder
        gmf_repair.patch_material_converter(module)
        return module

    def test_recovered_eye_converter_and_reference_writer_emit_bound_color_and_global_normal(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); source.write_bytes(library([inline_block()], ['eye_l']))
            (source.parent / 'Textures' / 'eye_color.dds').write_bytes(dds())
            item = mat(); before = copy.deepcopy(item.params); module = self.converter([item], 0x12)
            report = module.convert_library(str(source), str(target), {'eye_l'})
            actual = inspect_material((target.parent / 'Materials' / 'eye_l.jmtl').read_bytes())
            self.assertEqual(actual['face_texture_check']['color_ref'], path_hash('Characters/159_Bryan_Danielson/BaseModel/Textures/eye_color.tex'))
            self.assertTrue(actual['face_texture_check']['reference_normal_match'])
            self.assertEqual(item.params, before); self.assertEqual(len(report['local_texture_bindings']), 1)
            self.assertTrue((target.parent / 'Textures' / 'eye_color.dds').exists())

    def test_custom_body_atlas_teeth_refs_and_explicit_source_irradiance_are_emitted(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); source.write_bytes(library([inline_block()], ['teeth']))
            item = mat('teeth', 'body_color'); item.shader = 'yCh_Teeth'
            item.params.update(g_nrmMap='body_nrm', irradianceR=1., irradianceG=.75, irradianceB=.75)
            for name in ['body_color', 'body_nrm']:
                (source.parent / 'Textures' / (name + '.dds')).write_bytes(dds())
            before = copy.deepcopy(item.params); module = self.converter([item], 0x1a)
            report = module.convert_library(str(source), str(target), {'teeth'})
            raw = (target.parent / 'Materials' / 'teeth.jmtl').read_bytes(); actual = inspect_material(raw)
            check = actual['face_texture_check']
            self.assertEqual(check['color_ref'], path_hash('Characters/159_Bryan_Danielson/BaseModel/Textures/body_color.tex'))
            self.assertEqual(check['normal_ref'], path_hash('Characters/159_Bryan_Danielson/BaseModel/Textures/body_nrm.tex'))
            payload = Table(raw, struct.unpack_from('<I', raw, 0)[0]).child(2)
            illumination = payload.child(6)
            self.assertEqual([illumination.number(i, '<B', 0) for i in range(3)], [255, 191, 191])
            self.assertEqual(item.params, before); self.assertEqual(len(report['local_texture_bindings']), 2)
            self.assertIn('source teeth irradiance', report['notes'][0])

    def test_recovered_folder_generic_copy_off_still_keeps_required_bound_texture(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source, target = paths(root)
            source.write_bytes(library([inline_block()], ['eye_l']))
            source.with_suffix('.mdl').write_bytes(b'original model fixture')
            texture = source.parent / 'Textures' / 'eye_color.dds'; texture.write_bytes(dds())
            module = self.converter([mat()], 0x12); folder = conversion_folder(module)
            original_namespace = folder.convert_folder.__wrapped__.__globals__
            original_namespace['_used_materials'] = lambda path: ({'eye_l'}, {'M_EYE': 3})
            report = folder.convert_folder(str(source.parent.parent), str(root / 'output'),
                                           log=lambda text: None, copy_other=False)
            table = Path(report['materials'][0]['output'])
            self.assertTrue(table.exists()); self.assertEqual(report['copied'], 0)
            self.assertEqual((table.parent / 'Textures' / 'eye_color.dds').read_bytes(), dds())
            self.assertEqual(texture.read_bytes(), dds()); self.assertEqual(report['problems'], [])
            self.assertEqual(len(report['materials'][0]['local_texture_bindings']), 1)


if __name__ == '__main__':
    unittest.main()
