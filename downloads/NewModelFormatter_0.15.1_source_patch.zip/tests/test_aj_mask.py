from pathlib import Path
import struct,sys,tempfile,types,unittest
from unittest import mock
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import gmf_aj_mask as aj
from test_mask_recovery import pure_mcd


class AJMaskTests(unittest.TestCase):
    def test_original_builder_roundtrip_flags_lods_and_real_ids(self):
        mcd=pure_mcd();data=aj.build_mask(mcd,[1108,1109,12762])
        self.assertEqual(mcd.parse_hpl(data)[4][1],[('M_Body',[1108,1109,12762])])

    def test_exact_tail_splice_preserves_all_model_payload(self):
        mcd=pure_mcd();mask=aj.build_mask(mcd,[1108,1109])
        prefix=b'original model bytes including UVs shapes weights';original=prefix+aj.TAIL
        changed=aj.replace_empty_tail(original,mask)
        self.assertEqual(changed[:-len(mask)-24],prefix)
        self.assertEqual(changed[-12:],aj.END)
        self.assertEqual(original,prefix+aj.TAIL)

    def test_existing_nonempty_or_truncated_mask_is_never_replaced(self):
        for original in [b'model'+aj.TAIL[:-1],b'model'+b'nonempty HPL'+aj.END]:
            with self.assertRaisesRegex(ValueError,'existing mask'):aj.replace_empty_tail(original,b'replacement')

    def test_unrelated_native_model_is_not_read_or_modified(self):
        record={'source_version':47,'status':'preserved_2k26','source':'absent.mcd',
                'output':'absent-target.mcd','facts':{'source_sha256':'unrelated'}}
        report={'models':[record],'problems':[]};before=dict(record)
        aj.process(report,types.SimpleNamespace(),lambda _:None)
        self.assertEqual(record,before)

    def test_missing_exact_base_fails_without_changing_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'source'/'attire'/'610_Attire.mcd';dst=root/'out'/'610_Attire.mcd'
            src.parent.mkdir(parents=True);dst.parent.mkdir();src.write_bytes(b'exact source');dst.write_bytes(b'exact source')
            record={'source_version':47,'status':'preserved_2k26','source':str(src),'output':str(dst),
                    'facts':{'source_sha256':aj.ATTIRE_SHA256}}
            report={'models':[record],'problems':[]}
            with mock.patch.object(aj,'digest',return_value=aj.ATTIRE_SHA256):aj.process(report,types.SimpleNamespace(),lambda _:None)
            self.assertEqual(dst.read_bytes(),b'exact source');self.assertTrue(report['problems']);self.assertEqual(record['verify'],'fail')

    def test_native_reader_failure_leaves_previous_output_intact(self):
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'610_Attire.mcd';target.write_bytes(b'original')
            vc=types.SimpleNamespace(read_model=lambda *a,**kw:types.SimpleNamespace(version=47,substreams=[]))
            with self.assertRaisesRegex(ValueError,'native reader'):aj._stage_model(target,b'changed',vc,b'HPL!')
            self.assertEqual(target.read_bytes(),b'original');self.assertFalse(list(Path(tmp).glob('.aj-mask-*')))

    def test_invalid_body_domain_and_weights_are_rejected(self):
        body=types.SimpleNamespace(name='M_Body',num_verts=12763,vertex_remap=np.arange(12763),
            weights={n:np.zeros(12763) for n in aj.FOOT_BONES})
        model=types.SimpleNamespace(version=47,meshes=[body])
        with self.assertRaisesRegex(ValueError,'differs'):aj.foot_ids(model)
        body.weights['J_Foot_L'][0]=np.nan
        with self.assertRaisesRegex(ValueError,'invalid'):aj.foot_ids(model)
        body.vertex_remap=None
        with self.assertRaisesRegex(ValueError,'remap'):aj.foot_ids(model)
