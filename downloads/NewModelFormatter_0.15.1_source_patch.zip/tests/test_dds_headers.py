"""Post-copy normalization of proven DDS counts with actual final-byte evidence."""
import copy
import hashlib
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gmf_dds_headers as headers
from gmf_local_textures import prepare_local_dds
from test_local_textures import dds


def underdeclared():
    data = bytearray(dds(8, 4, 4, fourcc=b'DXT5'))
    struct.pack_into('<I', data, 28, 1)
    return bytes(data)


def tree(root, raw=None):
    raw = underdeclared() if raw is None else raw
    source = root / 'input' / '100_Test'
    destination = root / 'output'
    output = destination / 'Characters' / '100_Test'
    src = source / 'BaseModel' / 'Textures' / 'eyelash_color.dds'
    dst = output / src.relative_to(source)
    src.parent.mkdir(parents=True); dst.parent.mkdir(parents=True)
    src.write_bytes(raw); dst.write_bytes(raw)
    report = {'source': str(source), 'output': str(output), 'models': [], 'materials': [], 'problems': []}
    return source, destination, output, src, dst, report


class PostCopyDdsHeaderTests(unittest.TestCase):
    def test_raw_native_copy_is_normalized_and_copy_metadata_keeps_original_proof(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp))
            raw = src.read_bytes(); prepared, facts = prepare_local_dds(raw)
            old_sha = hashlib.sha256(raw).hexdigest(); new_sha = hashlib.sha256(prepared).hexdigest()
            native_copy = {'kind': 'restore_available_native_asset', 'source': str(src), 'output': str(dst),
                           'sha256': old_sha, 'bytes': len(raw), 'byte_identical': True}
            file_row = {'source': str(src), 'output': str(dst), 'recovered': True}
            report['models'] = [{'native_missing_data_audit': {'repairs': [native_copy], 'textures': [{'files': [file_row]}]}}]
            unrelated = output / 'BaseModel' / 'baseModel.mcd'; unrelated.write_bytes(b'untouched model geometry')
            summary = headers.process(report, source, destination)
            self.assertEqual(dst.read_bytes(), prepared); self.assertEqual(src.read_bytes(), raw)
            self.assertEqual(unrelated.read_bytes(), b'untouched model geometry')
            self.assertEqual((summary['repaired'], summary['failed']), (1, 0))
            row = summary['rows'][0]
            self.assertEqual(row['changed_header_byte_offsets'], [28])
            self.assertEqual(row['source_sha256'], old_sha); self.assertEqual(row['output_sha256'], new_sha)
            self.assertTrue(row['expected_output_bytes_verified']); self.assertTrue(row['compressed_payload_byte_identical'])
            self.assertEqual(native_copy['source_sha256'], old_sha); self.assertEqual(native_copy['output_sha256'], new_sha)
            self.assertEqual(native_copy['sha256'], new_sha); self.assertFalse(native_copy['byte_identical'])
            self.assertEqual(native_copy['dds_header_normalization_prior_copy_evidence'], {'sha256': old_sha, 'byte_identical': True})
            self.assertEqual(native_copy['dds_header_repair'], facts['mip_count_repair'])
            self.assertEqual(file_row['output_sha256'], new_sha); self.assertEqual(report['problems'], [])

    def test_already_normalized_target_is_recorded_without_rewriting_or_losing_prior_evidence(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp))
            prepared, _ = prepare_local_dds(src.read_bytes()); dst.write_bytes(prepared)
            prior = {'byte_identical': True, 'sha256': hashlib.sha256(src.read_bytes()).hexdigest()}
            metadata = {'output': str(dst), 'dds_header_normalization_prior_copy_evidence': copy.deepcopy(prior)}
            report['native_repair'] = metadata
            with mock.patch.object(headers, 'atomic_bytes') as write:
                summary = headers.process(report, source, destination)
            write.assert_not_called(); self.assertEqual(summary['already_normalized'], 1)
            self.assertEqual(summary['rows'][0]['state'], 'already_normalized')
            self.assertIn('none;', summary['rows'][0]['output_file_changes'])
            self.assertEqual(metadata['dds_header_normalization_prior_copy_evidence'], prior)
            self.assertEqual(dst.read_bytes(), prepared); self.assertEqual(report['problems'], [])

    def test_unexpected_target_is_preserved_and_never_marked_as_verified(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp))
            before = src.read_bytes(); foreign = bytearray(before); foreign[-1] ^= 1; dst.write_bytes(foreign)
            summary = headers.process(report, source, destination)
            self.assertEqual(dst.read_bytes(), bytes(foreign)); self.assertEqual(src.read_bytes(), before)
            self.assertEqual((summary['repaired'], summary['failed']), (0, 1))
            row = summary['rows'][0]
            self.assertEqual(row['state'], 'normalization_failed')
            self.assertNotIn('expected_output_bytes_verified', row)
            self.assertNotIn('compressed_payload_byte_identical', row)
            self.assertIn('eyelash_color.dds', report['problems'][0])

    def test_missing_unused_output_and_unsupported_unused_source_are_not_global_problems(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp)); dst.unlink()
            (src.parent / 'unsupported.dds').write_bytes(b'unsupported original texture')
            summary = headers.process(report, source, destination)
            self.assertEqual(summary['output_not_present'], 1); self.assertEqual(summary['failed'], 0)
            self.assertEqual(summary['rows'][0]['state'], 'output_not_present_not_repaired')
            self.assertFalse(dst.exists()); self.assertEqual(report['problems'], [])

    def test_valid_declared_single_partial_full_and_sparse_caps_assets_are_untouched(self):
        for raw in (dds(), dds(8, 4, 3), dds(8, 4, 4), dds(8, 4, 4, dxgi=98, caps=0)):
            with self.subTest(size=len(raw)), tempfile.TemporaryDirectory() as tmp:
                source, destination, output, src, dst, report = tree(Path(tmp), raw)
                with mock.patch.object(headers, 'atomic_bytes') as write:
                    summary = headers.process(report, source, destination)
                write.assert_not_called(); self.assertEqual(summary['rows'], [])
                self.assertEqual(dst.read_bytes(), raw); self.assertEqual(src.read_bytes(), raw)
                self.assertEqual(report['problems'], [])

    def test_source_alias_outside_scope_is_not_inspected_or_copied(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source, destination, output, src, dst, report = tree(root)
            outside = root / 'outside.dds'; raw = src.read_bytes(); outside.write_bytes(raw)
            src.unlink(); src.symlink_to(outside)
            with mock.patch.object(headers, 'prepare_local_dds') as prepare:
                summary = headers.process(report, source, destination)
            prepare.assert_not_called(); self.assertEqual(summary['rows'], [])
            self.assertEqual(outside.read_bytes(), raw); self.assertEqual(dst.read_bytes(), raw)

    def test_output_file_and_directory_symlinks_cannot_redirect_the_write(self):
        for kind in ('file', 'directory', 'source'):
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp); source, destination, output, src, dst, report = tree(root)
                raw = src.read_bytes(); outside = root / 'outside'; outside.mkdir()
                outside_file = outside / dst.name; outside_file.write_bytes(raw)
                dst.unlink()
                if kind == 'file': dst.symlink_to(outside_file)
                elif kind == 'source': dst.symlink_to(src)
                else:
                    dst.parent.rmdir(); dst.parent.symlink_to(outside, target_is_directory=True)
                summary = headers.process(report, source, destination)
                self.assertEqual(summary['failed'], 1); self.assertEqual(summary['repaired'], 0)
                self.assertEqual(src.read_bytes(), raw); self.assertEqual(outside_file.read_bytes(), raw)

    def test_overlapping_scopes_and_report_output_outside_destination_are_rejected(self):
        for case in ('overlap', 'outside'):
            with self.subTest(case=case), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp); source, destination, output, src, dst, report = tree(root)
                raw = src.read_bytes()
                if case == 'overlap': selected_destination = source.parent.parent
                else:
                    outside = root / 'outside'; actual = outside / src.relative_to(source)
                    actual.parent.mkdir(parents=True); actual.write_bytes(raw)
                    report['output'] = str(outside); selected_destination = destination; dst = actual
                summary = headers.process(report, source, selected_destination)
                self.assertEqual(summary['failed'], 1); self.assertEqual(dst.read_bytes(), raw)
                self.assertEqual(src.read_bytes(), raw)

    def test_atomic_write_failure_preserves_original_target_and_previous_native_evidence(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp)); raw = src.read_bytes()
            metadata = {'output': str(dst), 'byte_identical': True, 'sha256': hashlib.sha256(raw).hexdigest()}
            before = copy.deepcopy(metadata); report['native_repair'] = metadata
            with mock.patch.object(headers, 'atomic_bytes', side_effect=OSError('controlled disk failure')):
                summary = headers.process(report, source, destination)
            self.assertEqual(summary['failed'], 1); self.assertEqual(summary['repaired'], 0)
            self.assertEqual(dst.read_bytes(), raw); self.assertEqual(metadata, before)

    def test_failed_final_copy_verification_does_not_update_native_metadata_or_claim_success(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp))
            metadata = {'output': str(dst), 'byte_identical': True}; report['native_repair'] = metadata
            def corrupt(path, data): Path(path).write_bytes(data[:-1])
            with mock.patch.object(headers, 'atomic_bytes', side_effect=corrupt):
                summary = headers.process(report, source, destination)
            self.assertEqual((summary['repaired'], summary['failed']), (0, 1))
            self.assertEqual(metadata, {'output': str(dst), 'byte_identical': True})
            self.assertNotIn('expected_output_bytes_verified', summary['rows'][0])

    def test_unrelated_metadata_path_remains_unchanged_and_local_binding_gets_final_facts(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp))
            untouched = {'output': str(output / 'unrelated.dds'), 'sha256': 'unrelated', 'byte_identical': True}
            legacy = {'output': str(dst), 'source_sha256': 'oldsource', 'output_sha256': 'oldcopy',
                      'dds_file_bytes_identical': True, 'dds_compressed_payload_byte_identical': True, 'dds': {}}
            report.update(unrelated=copy.deepcopy(untouched), materials=[{'local_texture_bindings': [legacy]}])
            headers.process(report, source, destination)
            self.assertEqual(report['unrelated'], untouched)
            self.assertFalse(legacy['dds_file_bytes_identical']); self.assertTrue(legacy['dds_compressed_payload_byte_identical'])
            self.assertEqual(legacy['dds']['mip_count'], 4)
            self.assertEqual(legacy['dds_header_normalization_prior_copy_evidence']['output_sha256'], 'oldcopy')

    def test_actual_uploaded_aj_texture_is_normalized_only_in_the_controlled_output(self):
        upload = Path('/workspace/attachments/0e6770b3-f949-43b1-96b0-ae74929033ce/eyelash_color.dds')
        if not upload.is_file(): self.skipTest('uploaded AJ eyelash DDS is unavailable')
        original = upload.read_bytes()
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp), original)
            summary = headers.process(report, source, destination)
            self.assertEqual(summary['repaired'], 1); self.assertEqual(summary['failed'], 0)
            self.assertEqual(summary['rows'][0]['inferred_mip_count'], 10)
            self.assertEqual(summary['rows'][0]['changed_header_byte_offsets'], [28])
            self.assertEqual(hashlib.sha256(dst.read_bytes()).hexdigest(), '01988adde9c168db814b91ffd4ddcd4ed896e8b7cd92bd79afba896d4a904f63')
            self.assertEqual(src.read_bytes(), original); self.assertEqual(upload.read_bytes(), original)

    def test_wrapper_runs_after_original_and_checkpoints_updated_report_once(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp)); calls = []
            def convert_folder(src, dst, log=lambda text: None, copy_other=True):
                calls.append((src, dst, copy_other)); return report
            folder = types.SimpleNamespace(convert_folder=convert_folder)
            headers.install(folder); wrapped = folder.convert_folder; headers.install(folder)
            self.assertIs(folder.convert_folder, wrapped)
            with mock.patch('gmf_report.save_intermediate') as checkpoint:
                actual = folder.convert_folder(str(source), str(destination), copy_other=False)
            self.assertIs(actual, report); self.assertEqual(len(calls), 1)
            self.assertEqual(actual['dds_header_normalization']['repaired'], 1)
            checkpoint.assert_called_once_with(report, str(destination))


if __name__ == '__main__':
    unittest.main()
