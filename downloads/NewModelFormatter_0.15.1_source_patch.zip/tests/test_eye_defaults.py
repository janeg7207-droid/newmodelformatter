"""The explicit Eye-only policy preserves every unrelated value and byte."""
import copy
import hashlib
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import gmf_eye_defaults as eye
from gmf_jmtl_audit import Table, inspect_material
from test_local_textures import reference_writer


def payload(data):
    return Table(data, struct.unpack_from('<I', data, 0)[0]).child(2)


def rich_params(**changes):
    values = {'colorMap@ref': 0xf123456789abcdef, 'nrMap@ref': 0xe123456789abcdef,
              'caustic': .25, 'g_eyeRoughness': .8, 'g_fFresnel': .65,
              'g_pupilLns': .62, 'g_pupilPar': .002, 'g_refraction': False,
              'g_specIntensity': 2.0, 'g_eyeWetness': 0.0,
              'eyeLidShadowDarkness': .1, 'eyeLidShadowFallOff': .15,
              'eyeShadowConeSharpness': .1, 'eyeShadowConeBgLevel': .2,
              'eyeShadowHorizontalFit': 1.8, 'eyeShadowLidZBias': .5,
              'eyeShadowVerticalBias': .13, 'eyeShadowVerticalFit': .4}
    values.update(changes)
    return values


def tree(root, raw):
    source = root / 'input' / '100_Test'
    destination = root / 'output'
    output = destination / 'Characters' / '100_Test'
    source_file = source / 'BaseModel' / 'Materials' / 'eye_l.jmtl'
    output_file = output / source_file.relative_to(source)
    source_file.parent.mkdir(parents=True); output_file.parent.mkdir(parents=True)
    source_file.write_bytes(raw); output_file.write_bytes(raw)
    report = {'source': str(source), 'output': str(output), 'materials': [], 'models': [], 'problems': []}
    return source, destination, output, source_file, output_file, report


class EyeDefaultsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.core = reference_writer()

    def write(self, params=None, shader=0x12):
        return self.core.write_jmtl(shader, rich_params() if params is None else params)

    def assert_policy(self, data):
        p = payload(data)
        self.assertEqual(p.number(12, '<f'), 1.0)
        self.assertEqual(p.number(13, '<f'), .5)

    def test_present_scalars_only_target_float_bytes_change(self):
        raw = self.write(); before = payload(raw)
        output, facts = eye.prepare_eye_defaults(raw)
        self.assert_policy(output); self.assertEqual(len(raw), len(output))
        permitted = {before.field(slot, 4) + i for slot in (12, 13) for i in range(4)}
        actual = [i for i, (a, b) in enumerate(zip(raw, output)) if a != b]
        self.assertEqual(actual, facts['changed_original_byte_offsets'])
        self.assertTrue(set(actual).issubset(permitted))
        self.assertEqual(facts['state'], 'patched_existing_eye_scalars')
        self.assertEqual(facts['values_before']['eyeLidShadowDarkness'], before.number(12, '<f'))
        self.assertEqual(facts['output_sha256'], hashlib.sha256(output).hexdigest())
        self.assertTrue(facts['texture_references_byte_identical'])
        self.assertEqual(inspect_material(raw), inspect_material(output))
        after = payload(output)
        for field in range(20):
            width = 8 if field < 4 else (1 if field == 9 else 4)
            if field in (12, 13): continue
            old = before.field(field, width); new = after.field(field, width)
            self.assertEqual(old, new)
            if old is not None: self.assertEqual(raw[old:old + width], output[new:new + width])
        self.assertEqual(after.number(9, '<B'), 0)
        self.assertEqual(after.number(0, '<Q'), 0xf123456789abcdef)
        self.assertEqual(after.number(3, '<Q'), 0xe123456789abcdef)

    def test_one_or_both_missing_scalars_append_eye_only_table_and_preserve_all_original_bytes(self):
        for missing in (('eyeLidShadowDarkness',), ('eyeLidShadowFallOff',), tuple(eye.POLICY)):
            with self.subTest(missing=missing):
                params = rich_params()
                for key in missing: del params[key]
                raw = self.write(params); root = Table(raw, struct.unpack_from('<I', raw, 0)[0])
                pointer = root.field(2, 4); old = payload(raw)
                output, facts = eye.prepare_eye_defaults(raw)
                self.assert_policy(output); new = payload(output)
                self.assertGreater(len(output), len(raw)); self.assertEqual(facts['state'], 'appended_missing_eye_scalars')
                self.assertEqual(set(facts['added_fields']), set(missing))
                self.assertEqual(raw[:pointer], output[:pointer]); self.assertEqual(raw[pointer + 4:], output[pointer + 4:len(raw)])
                self.assertEqual(facts['appended_bytes'], len(output) - len(raw))
                self.assertEqual(raw[old.position:old.position + old.size], output[old.position:old.position + old.size])
                for field in range(20):
                    if field in (12, 13): continue
                    width = 8 if field < 4 else (1 if field == 9 else 4)
                    old_at = old.field(field, width); new_at = new.field(field, width)
                    self.assertEqual(old_at is None, new_at is None)
                    if old_at is not None:
                        self.assertEqual(old_at - old.position, new_at - new.position)
                        self.assertEqual(raw[old_at:old_at + width], output[new_at:new_at + width])
                self.assertEqual(inspect_material(raw), inspect_material(output))

    def test_unknown_padding_in_original_object_is_retained_in_clone(self):
        params = rich_params(); del params['eyeLidShadowDarkness']; del params['eyeLidShadowFallOff']
        raw = bytearray(self.write(params)); p = payload(raw)
        occupied = set(range(4))
        for field in range(20):
            width = 8 if field < 4 else (1 if field == 9 else 4)
            position = p.field(field, width)
            if position is not None: occupied.update(range(position - p.position, position - p.position + width))
        padding = [i for i in range(p.size) if i not in occupied]
        self.assertTrue(padding)
        for i in padding: raw[p.position + i] = 0xa5
        output, facts = eye.prepare_eye_defaults(bytes(raw)); new = payload(output)
        for i in padding: self.assertEqual(output[new.position + i], 0xa5)
        self.assertTrue(facts['copied_eye_object_padding_preserved'])

    def test_native_four_u64_references_and_false_refraction_survive_missing_field_append(self):
        # The reference writer intentionally omits EyeInsideTex/EyeMaskTex.
        # A native payload can contain them; the output policy must preserve
        # those authored hashes without applying that writer omission rule.
        builder = self.core.flatbuffers.Builder(256); builder.ForceDefaults(True)
        refs = {0: 0xfedcba9876543210, 1: 0xeedcba9876543210,
                2: 0xdedcba9876543210, 3: 0xcedcba9876543210}
        builder.StartObject(20)
        builder.PrependFloat32Slot(19, .75, 0.)
        builder.PrependFloat32Slot(12, .25, 0.)
        builder.PrependBoolSlot(9, False, False)
        for slot in reversed(range(4)): builder.PrependUint64Slot(slot, refs[slot], 0)
        child = builder.EndObject()
        builder.StartObject(3); builder.PrependUOffsetTRelativeSlot(2, child, 0)
        builder.PrependUint16Slot(1, 0x12, 0); root = builder.EndObject(); builder.Finish(root, b'Mate')
        raw = bytes(builder.Output()); output, facts = eye.prepare_eye_defaults(raw)
        self.assert_policy(output); self.assertEqual(facts['added_fields'], ['eyeLidShadowFallOff'])
        p = payload(output)
        for slot, value in refs.items(): self.assertEqual(p.number(slot, '<Q'), value)
        self.assertEqual(p.number(9, '<B'), 0); self.assertEqual(p.number(19, '<f'), .75)
        self.assertEqual(inspect_material(raw), inspect_material(output))

    def test_policy_is_idempotent_for_present_and_previously_appended_tables(self):
        for params in (rich_params(), {'colorMap@ref': 11}):
            with self.subTest(params=params):
                once, _ = eye.prepare_eye_defaults(self.write(params))
                twice, facts = eye.prepare_eye_defaults(once)
                self.assertIs(twice, once); self.assertEqual(facts['state'], 'already_policy_values')
                self.assertTrue(facts['byte_identical']); self.assertEqual(facts['appended_bytes'], 0)

    def test_unexpected_shader_is_unchanged_without_interpreting_its_payload(self):
        for shader in (0x14, 0x19, 0x1a):
            raw = self.write({'colorMap@ref': 13}, shader)
            output, facts = eye.prepare_eye_defaults(raw)
            self.assertIs(output, raw); self.assertEqual(facts['state'], 'not_ordinary_eye')

    def test_truncation_invalid_bool_nonfinite_and_unknown_fields_fail_closed(self):
        raw = self.write(); p = payload(raw)
        invalid = [raw[:7], b'no material', raw[:-1]]
        for field, kind, value in ((9, '<B', 2), (12, '<f', float('nan')), (5, '<f', float('inf'))):
            mutated = bytearray(raw); struct.pack_into(kind, mutated, p.field(field, struct.calcsize(kind)), value)
            invalid.append(bytes(mutated))
        # Construct a canonical root with a nonzero unsupported Eye slot 20.
        builder = self.core.flatbuffers.Builder(256); builder.ForceDefaults(True)
        builder.StartObject(21); builder.PrependFloat32Slot(20, 1., 0.); child = builder.EndObject()
        builder.StartObject(3); builder.PrependUOffsetTRelativeSlot(2, child, 0)
        builder.PrependUint16Slot(1, 0x12, 0); root = builder.EndObject(); builder.Finish(root, b'Mate')
        invalid.append(bytes(builder.Output()))
        for value in invalid:
            with self.subTest(length=len(value)), self.assertRaises(ValueError):
                eye.prepare_eye_defaults(value)

    def test_overlapping_fields_invalid_alignment_and_overlapping_table_vtable_fail_closed(self):
        raw = self.write(); p = payload(raw); root = Table(raw, struct.unpack_from('<I', raw, 0)[0])
        vtable = p.position - struct.unpack_from('<i', raw, p.position)[0]
        invalid = []
        for offset in (p.offsets[12], p.offsets[12] + 1):
            changed = bytearray(raw); struct.pack_into('<H', changed, vtable + 4 + 2 * 13, offset)
            invalid.append(bytes(changed))
        changed = bytearray(raw); struct.pack_into('<I', changed, root.field(2, 4), 1)
        invalid.append(bytes(changed))
        changed = bytearray(raw); struct.pack_into('<i', changed, p.position, 2)
        invalid.append(bytes(changed))
        for value in invalid:
            with self.subTest(value=value.hex()[:30]), self.assertRaises(ValueError): eye.prepare_eye_defaults(value)

    def test_invalid_root_unknown_root_slot_and_noncanonical_positions_fail_closed(self):
        raw = self.write(); root = Table(raw, struct.unpack_from('<I', raw, 0)[0])
        vtable = root.position - struct.unpack_from('<i', raw, root.position)[0]
        invalid = []
        changed = bytearray(raw); struct.pack_into('<H', changed, vtable + 4, 4); invalid.append(bytes(changed))
        changed = bytearray(raw); struct.pack_into('<H', changed, vtable + 4 + 2, 5); invalid.append(bytes(changed))
        for value in invalid:
            with self.subTest(value=value.hex()[:30]), self.assertRaises(ValueError): eye.prepare_eye_defaults(value)

    def test_process_patches_only_output_preserves_native_source_and_updates_final_material_hashes(self):
        raw = self.write({'colorMap@ref': 11})
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp), raw)
            sha = hashlib.sha256(raw).hexdigest()
            repair = {'source': str(src), 'output': str(dst), 'sha256': sha, 'bytes': len(raw), 'byte_identical': True}
            payload_audit = {'file': str(dst), 'state': 'payload_inspected', 'sha256': sha}
            aggregate = {'output': str(output / 'BaseModel' / 'baseModel.mtls'),
                         'jmtl_payloads': 'byte_identical', 'source_sha256': 'unchanged_mtls_source',
                         'output_sha256': 'unchanged_mtls_output',
                         'written_material_payload_audit': [payload_audit], 'jmtl_inventory': [repair]}
            model_facts = {'byte_identical': True, 'output_sha256': 'unchanged_model_output'}
            report.update(native={'repairs': [repair]}, materials=[aggregate],
                          models=[{'output': str(output / 'BaseModel' / 'baseModel.mcd'), 'facts': model_facts}])
            unrelated = dst.parent / 'body.jmtl'; body = self.write({'colorMap@ref': 17}, 0x19); unrelated.write_bytes(body)
            model = output / 'BaseModel' / 'baseModel.mcd'; model.write_bytes(b'unchanged geometry')
            summary = eye.process(report, source, destination)
            self.assertEqual((summary['changed'], summary['failed'], summary['not_ordinary_eye']), (1, 0, 1))
            self.assertEqual(src.read_bytes(), raw); self.assertEqual(unrelated.read_bytes(), body)
            self.assertEqual(model.read_bytes(), b'unchanged geometry'); self.assert_policy(dst.read_bytes())
            new_sha = hashlib.sha256(dst.read_bytes()).hexdigest()
            self.assertEqual(repair['sha256'], new_sha); self.assertEqual(repair['output_sha256'], new_sha)
            self.assertEqual(repair['source_sha256'], sha)
            self.assertFalse(repair['byte_identical']); self.assertEqual(repair['bytes'], len(dst.read_bytes()))
            self.assertEqual(repair['eye_scalar_policy_prior_copy_evidence']['sha256'], sha)
            self.assertEqual(payload_audit['sha256'], new_sha)
            self.assertEqual(payload_audit['eye_scalar_policy']['values_after'], eye.POLICY)
            self.assertEqual(aggregate['eye_scalar_policy_prior_jmtl_payloads'], 'byte_identical')
            self.assertIn('explicit ordinary-eye scalar policy applied', aggregate['jmtl_payloads'])
            self.assertEqual(aggregate['source_sha256'], 'unchanged_mtls_source')
            self.assertEqual(aggregate['output_sha256'], 'unchanged_mtls_output')
            self.assertEqual(model_facts, {'byte_identical': True, 'output_sha256': 'unchanged_model_output'})
            self.assertEqual(report['problems'], [])

    def test_process_is_idempotent_without_overwriting_original_copy_evidence(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp), self.write())
            original = {'sha256': hashlib.sha256(src.read_bytes()).hexdigest(), 'byte_identical': True}
            repair = {'output': str(dst), **original}; report['native'] = repair
            eye.process(report, source, destination)
            once = dst.read_bytes(); prior = copy.deepcopy(repair['eye_scalar_policy_prior_copy_evidence'])
            with mock.patch.object(eye, 'atomic_bytes') as write: summary = eye.process(report, source, destination)
            write.assert_not_called(); self.assertEqual(dst.read_bytes(), once)
            self.assertEqual(summary['already_policy_values'], 1)
            self.assertEqual(repair['eye_scalar_policy_prior_copy_evidence'], prior)
            self.assertFalse(repair['byte_identical'])

    def test_unsupported_output_remains_unchanged_and_failure_is_recorded(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp), b'invalid JMTL')
            summary = eye.process(report, source, destination)
            self.assertEqual(summary['failed'], 1); self.assertEqual(dst.read_bytes(), b'invalid JMTL')
            self.assertIn('eye_l.jmtl', report['problems'][0]); self.assertEqual(src.read_bytes(), b'invalid JMTL')

    def test_output_symlink_and_disjoint_root_checks_prevent_source_or_outside_writes(self):
        for case in ('file', 'source', 'outside', 'overlap'):
            with self.subTest(case=case), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp); source, destination, output, src, dst, report = tree(root, self.write())
                raw = src.read_bytes(); outside = root / 'foreign.jmtl'; outside.write_bytes(raw)
                if case in ('file', 'source'):
                    dst.unlink(); dst.symlink_to(outside if case == 'file' else src)
                elif case == 'outside': report['output'] = str(source)
                else: destination = source.parent.parent
                summary = eye.process(report, source, destination)
                self.assertEqual(summary['failed'], 1)
                self.assertEqual(src.read_bytes(), raw); self.assertEqual(outside.read_bytes(), raw)

    def test_output_directory_symlink_is_not_followed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source, destination, output, src, dst, report = tree(root, self.write())
            raw = src.read_bytes(); foreign = root / 'foreign'; foreign.mkdir(); file = foreign / dst.name; file.write_bytes(raw)
            dst.unlink(); dst.parent.rmdir(); dst.parent.symlink_to(foreign, target_is_directory=True)
            with mock.patch.object(eye, 'atomic_bytes') as write: summary = eye.process(report, source, destination)
            write.assert_not_called(); self.assertEqual(file.read_bytes(), raw); self.assertEqual(summary['rows'], [])

    def test_missing_output_eye_is_not_synthesized_from_a_model_role_or_source_material(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp), self.write())
            raw = src.read_bytes(); dst.unlink()
            report['materials'] = [{'output': str(output / 'BaseModel' / 'baseModel.mtls'),
                                    'materials': [{'name': 'eye_l', 'shader_2k26': '0x12'},
                                                  {'name': 'eye_r', 'shader_2k26': '0x12'}]}]
            with mock.patch.object(eye, 'atomic_bytes') as write: summary = eye.process(report, source, destination)
            write.assert_not_called(); self.assertFalse(dst.exists()); self.assertEqual(src.read_bytes(), raw)
            self.assertEqual(summary['changed'], 0); self.assertEqual(summary['rows'], [])

    def test_output_root_symlink_is_refused_even_if_its_target_is_contained(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source, destination, output, src, dst, report = tree(root, self.write())
            raw = src.read_bytes(); alias = destination / 'alias'; alias.symlink_to(output, target_is_directory=True)
            report['output'] = str(alias)
            summary = eye.process(report, source, destination)
            self.assertEqual(summary['failed'], 1); self.assertEqual(dst.read_bytes(), raw)
            self.assertEqual(src.read_bytes(), raw)

    def test_failed_atomic_write_does_not_claim_applied_values_or_update_native_copy_hash(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp), self.write())
            raw = src.read_bytes(); row = {'output': str(dst), 'sha256': 'before', 'byte_identical': True}; report['native'] = row
            with mock.patch.object(eye, 'atomic_bytes', side_effect=OSError('controlled write failure')):
                summary = eye.process(report, source, destination)
            self.assertEqual(summary['failed'], 1); self.assertEqual(dst.read_bytes(), raw)
            self.assertEqual(row, {'output': str(dst), 'sha256': 'before', 'byte_identical': True})
            self.assertNotIn('expected_output_bytes_verified', summary['rows'][0])

    def test_final_verification_failure_is_not_reported_as_success(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp), self.write())
            metadata = {'output': str(dst), 'sha256': 'before'}; report['native'] = metadata
            def corrupt(path, data): Path(path).write_bytes(data[:-1])
            with mock.patch.object(eye, 'atomic_bytes', side_effect=corrupt): summary = eye.process(report, source, destination)
            self.assertEqual(summary['failed'], 1); self.assertEqual(summary['changed'], 0)
            self.assertEqual(metadata, {'output': str(dst), 'sha256': 'before'})

    def test_install_wraps_after_original_once_and_checkpoints_updated_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, destination, output, src, dst, report = tree(Path(tmp), self.write()); calls = []
            def convert_folder(src, dst, log=lambda text: None, copy_other=True):
                calls.append((src, dst, copy_other)); return report
            folder = types.SimpleNamespace(convert_folder=convert_folder)
            eye.install(folder); wrapped = folder.convert_folder; eye.install(folder)
            self.assertIs(folder.convert_folder, wrapped)
            with mock.patch('gmf_report.save_intermediate') as checkpoint:
                actual = folder.convert_folder(str(source), str(destination), copy_other=False)
            self.assertIs(actual, report); self.assertEqual(actual['eye_scalar_policy']['changed'], 1)
            self.assertEqual(len(calls), 1); checkpoint.assert_called_once_with(report, str(destination))


if __name__ == '__main__':
    unittest.main()
