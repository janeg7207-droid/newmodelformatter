"""Older tables must generate real native materials or refuse before writes."""
from pathlib import Path
import struct
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gmf_repair
from gmf_2k26_repair import path_hash, read_native_library
from gmf_jmtl_audit import inspect_material
from gmf_legacy_materials import decode_legacy_material_library, LegacyMaterialError
from gmf_material_formats import classify_material_library, read_legacy_source_materials
from test_legacy_materials import captured, specimen
from test_local_textures import dds, original_shader_converter, reference_writer
from test_material_format_guard import conversion_folder
from test_repair import make_material_module


def converter():
    module = make_material_module(None)
    # A valid v1 source must use the new bounded decoder, never this v3 reader.
    def wrong_reader(path):
        raise AssertionError('inline-v1 source reached the v3 reader')
    module.mtl25.read_mtls = wrong_reader
    module.to_2k26 = original_shader_converter(0x1a)
    module.write_jmtl = reference_writer().write_jmtl
    module.convert_library.__globals__.update(to_2k26=module.to_2k26,
                                             write_jmtl=module.write_jmtl)
    gmf_repair.patch_material_converter(module)
    return module


class LegacyMaterialRouteTests(unittest.TestCase):
    def test_both_actual_v1_tables_admit_all_materials_with_exact_source_identity(self):
        for name in ('hammer_base', 'hammer_attire'):
            raw = captured(name); facts = classify_material_library(raw)
            self.assertEqual(facts['classification'], 'supported_legacy_inline_v1')
            self.assertTrue(facts['supported']); self.assertFalse(facts['safe_as_native'])
            self.assertTrue(facts['payload_extents_validated'])
            version, mats, decoded = read_legacy_source_materials(raw)
            self.assertEqual(version, 6); self.assertEqual(len(mats), 9)
            for material, source in zip(mats, decoded['materials']):
                self.assertEqual((material.name, material.shader, material.technique),
                                 (source['name'], source['shader'], source['technique']))
                self.assertEqual(material.source_legacy['material'], source)

    def test_valid_v5_source_is_diagnosed_without_plain_gear_or_native_admission(self):
        for name in ('kenny_base', 'kenny_attire'):
            facts = classify_material_library(captured(name))
            self.assertEqual(facts['classification'], 'decoded_legacy_source_not_admitted')
            self.assertTrue(facts['payload_extents_validated'])
            self.assertFalse(facts['supported']); self.assertFalse(facts['safe_as_native'])
            self.assertIn('yCS shader mapping', facts['reason'])

    def test_nonzero_or_unknown_vector_and_distinct_lowercase_teeth_refuse(self):
        nonzero = bytearray(captured('hammer_attire'))
        decoded = decode_legacy_material_library(nonzero)
        vector = next(r for r in decoded['materials'][0]['parameters'] if r['packed_type'] == 2)
        nonzero[vector['value_offset']] = 1
        unknown = bytes(captured('hammer_attire')).replace(b'g_fCasParam\0', b'x_fCasParam\0')
        for raw in (bytes(nonzero), unknown, specimen(shader='yCh_teeth')):
            facts = classify_material_library(raw)
            self.assertFalse(facts['supported']); self.assertFalse(facts['safe_as_native'])
            self.assertTrue(facts['payload_extents_validated'])
            with self.assertRaises(LegacyMaterialError): read_legacy_source_materials(raw)

    def test_unknown_technique_does_not_take_existing_default_shader_fallback(self):
        facts = classify_material_library(specimen(technique='CustomUnverified'))
        self.assertFalse(facts['supported']); self.assertIn('shader/technique', facts['reason'])

    def test_full_converter_writes_native_library_and_bound_body_maps_from_v1(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source = root / 'input' / 'BaseModel' / 'baseModel.mtls'
            target = root / 'output' / 'BaseModel' / 'baseModel.mtls'
            source.parent.mkdir(parents=True); textures = source.parent / 'Textures'; textures.mkdir()
            raw = specimen(); source.write_bytes(raw)
            color, normal = dds(), dds(dxgi=98)
            (textures / 'body_color.dds').write_bytes(color)
            (textures / 'body_nrm.dds').write_bytes(normal)
            module = converter(); report = module.convert_library(str(source), str(target), {'teeth'})
            self.assertEqual(report['status'], 'converted')
            self.assertEqual(report['material_format']['classification'], 'supported_legacy_inline_v1')
            entries = read_native_library(target.read_bytes())
            self.assertEqual(entries[0]['name'], 'teeth')
            self.assertEqual(entries[0]['path_hash'], path_hash('Characters/Test/Attire/Materials/teeth.jmtl'))
            emitted = inspect_material((target.parent / 'Materials' / 'teeth.jmtl').read_bytes())
            self.assertEqual(emitted['shader_byte'], 0x1a)
            refs = {r['field']: r['hash'] for r in emitted['texture_references']}
            self.assertEqual(refs['colorMap@ref'], path_hash('Characters/Test/Attire/Textures/body_color.tex'))
            self.assertEqual(refs['nrMap@ref'], path_hash('Characters/Test/Attire/Textures/body_nrm.tex'))
            self.assertEqual(source.read_bytes(), raw)
            self.assertEqual((target.parent / 'Textures' / 'body_color.dds').read_bytes(), color)
            self.assertEqual((target.parent / 'Textures' / 'body_nrm.dds').read_bytes(), normal)
            self.assertFalse(report['legacy_source_materials']['source_bytes_changed'])

    def test_refused_older_input_leaves_output_and_source_assets_untouched(self):
        for raw in (captured('kenny_base'), specimen(shader='yCh_teeth'), specimen()[:-1]):
            with tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp); source = root / 'input' / 'baseModel.mtls'
                source.parent.mkdir(); source.write_bytes(raw)
                target = root / 'output' / 'baseModel.mtls'
                report = converter().convert_library(str(source), str(target))
                self.assertEqual(report['status'], 'unsupported_material_format')
                self.assertFalse(target.parent.exists()); self.assertEqual(source.read_bytes(), raw)

    def test_source_change_after_classification_refuses_before_target_writes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source = root / 'source.mtls'; source.write_bytes(specimen())
            target = root / 'output' / 'baseModel.mtls'; module = converter()
            module._load_writers = lambda: source.write_bytes(specimen(technique='Changed'))
            with self.assertRaisesRegex(ValueError, 'changed after format validation'):
                module.convert_library(str(source), str(target))
            self.assertFalse(target.parent.exists())

    def test_folder_geometry_preflight_uses_the_same_admitted_material_names(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); base = root / 'input' / '159_Test' / 'BaseModel'
            base.mkdir(parents=True)
            (base / 'baseModel.mdl').write_bytes(b'source geometry fixture')
            raw = specimen(); table = base / 'baseModel.mtls'; table.write_bytes(raw)
            material_module = converter(); folder = conversion_folder(material_module)
            namespace = folder.convert_folder.__wrapped__.__globals__
            original_convert = namespace['convert'].convert_mcd; seen = []
            def record_library(*args, **kwargs):
                seen.append(kwargs.get('library'))
                return original_convert(*args, **kwargs)
            namespace['convert'].convert_mcd = record_library
            report = folder.convert_folder(str(base.parent), str(root / 'output'),
                                           log=lambda text: None, copy_other=True)
            self.assertEqual(seen, [{'teeth'}])
            self.assertEqual(report['materials'][0]['status'], 'converted')
            self.assertEqual(table.read_bytes(), raw)


if __name__ == '__main__':
    unittest.main()
