"""Guard admission of genuine v40 without changing backend data or rig verdicts."""
import sys, threading, types, unittest
from pathlib import Path
from unittest import mock
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gmf_2k24_route as route


def fixture(unsupported=False, fail=False):
    raw=types.ModuleType('test_raw_mcd')
    raw.mdl_version=lambda path: {'24':40,'25':41,'26':47,'other':39}[path]
    raw.sentinel=object()
    observations=[]
    def backend(path):
        # Independent reader remains bound to the real module, as in Gorilla.
        observations.append(('backend',raw.mdl_version(path)))
        if fail:raise ValueError('native reader failure')
        result={'source_version':hex(raw.mdl_version(path)), 'verify':'pass', 'notes':[]}
        if unsupported:
            result.update(unsupported='missing required reference bones',verify='fail',problems=['unsupported rig'])
        return result
    convert=types.SimpleNamespace(convert_mcd=backend)
    folder=types.ModuleType('test_folder')
    folder.__dict__.update(mcd=raw,vc=types.SimpleNamespace(VERSION_2K25=41),convert=convert,observations=observations,threading=threading)
    exec('''
def convert_folder(src,dst,log=print):
    version=mcd.mdl_version(src)
    observations.append(('gate',version))
    outside=[]
    thread=threading.Thread(target=lambda:outside.append(mcd.mdl_version(src)))
    thread.start();thread.join()
    observations.append(('other_thread',outside[0]))
    if version not in (41,47):return {'models':[], 'source_skipped':version}
    record=convert.convert_mcd(src)
    return {'models':[record]}
''',folder.__dict__)
    return folder,raw,observations


class LegacyRoutingTests(unittest.TestCase):
    def setUp(self):
        self.saved=mock.patch('gmf_report.save_intermediate');self.writer=self.saved.start()
        self.addCleanup(self.saved.stop)

    def test_v40_gate_accepts_and_backend_reads_actual_v40(self):
        folder,raw,observations=fixture();route.install(folder)
        self.assertEqual(folder.mcd.mdl_version('24'),40)
        result=folder.convert_folder('24','output',log=lambda message:None)
        self.assertEqual(observations,[('gate',41),('other_thread',40),('backend',40)])
        self.assertEqual(result['models'][0]['source_version'],'0x28')
        self.assertEqual(result['models'][0]['source_game'],'WWE 2K24')
        self.assertFalse(result['models'][0]['legacy_2k24_conversion']['input_header_rewritten'])
        self.assertEqual(result['legacy_2k24_input_route']['model_checks_passed'],1)
        self.assertEqual(folder.mcd.mdl_version('24'),40)
        self.assertEqual(raw.mdl_version('24'),40)
        self.assertIs(folder.mcd.sentinel,raw.sentinel)
        self.writer.assert_called_once_with(result,'output')

    def test_missing_bones_original_failure_is_not_changed_to_pass(self):
        folder,raw,observations=fixture(unsupported=True);route.install(folder)
        result=folder.convert_folder('24','output',log=lambda message:None)
        model=result['models'][0]
        self.assertEqual(model['verify'],'fail');self.assertEqual(model['problems'],['unsupported rig'])
        self.assertEqual(model['original_unsupported_reason'],'missing required reference bones')
        self.assertIn('NOT ready',model['unsupported'])
        self.assertEqual(result['legacy_2k24_input_route']['model_checks_passed'],0)

    def test_backend_failure_does_not_leave_v40_alias_active(self):
        folder,raw,observations=fixture(fail=True);route.install(folder)
        with self.assertRaisesRegex(ValueError,'native reader failure'):
            folder.convert_folder('24','output',log=lambda message:None)
        self.assertEqual(folder.mcd.mdl_version('24'),40)
        self.writer.assert_not_called()

    def test_other_versions_keep_original_gate_and_report(self):
        for name,version,attempted in [('25',41,1),('26',47,1),('other',39,0)]:
            with self.subTest(name=name):
                folder,raw,observations=fixture();route.install(folder)
                result=folder.convert_folder(name,'output',log=lambda message:None)
                self.assertEqual(observations[0],('gate',version))
                self.assertEqual(len(result['models']),attempted)
                self.assertEqual(result['legacy_2k24_input_route']['models_attempted'],0)
                if attempted:self.assertNotIn('legacy_2k24_conversion',result['models'][0])

    def test_install_twice_does_not_duplicate_notes_or_wrappers(self):
        folder,raw,observations=fixture();route.install(folder);first=folder.convert_folder
        route.install(folder);self.assertIs(first,folder.convert_folder)
        result=folder.convert_folder('24','output',log=lambda message:None)
        self.assertEqual(len(result['models'][0]['notes']),1)


if __name__=='__main__':unittest.main()
