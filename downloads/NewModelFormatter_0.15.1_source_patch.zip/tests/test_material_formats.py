"""Prevent unsupported legacy material blocks from being called native."""
import struct
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from gmf_material_formats import classify_material_library


def inline_block(version=3, texture_reference=123):
    """Small independent v3 specimen with float, named texture and u64 ref."""
    strings = b'yCh_Teeth\0Normal\0roughness\0colorMap\0colorMap@ref\0teeth_color\0'
    offsets = {name: strings.index(name.encode() + b'\0')
               for name in ('roughness', 'colorMap', 'colorMap@ref', 'teeth_color')}
    block = bytearray(b'MTL!' + struct.pack('<II', version, len(strings)) + strings)
    block.extend(bytes((-len(block)) % 4))
    data_start = len(block) + 20
    arrays = (struct.pack('<3I', offsets['roughness'], offsets['colorMap'], offsets['colorMap@ref'])
              + struct.pack('<3I', 10, 20, 30) + bytes((2, 6, 7)))
    refs_offset = data_start + len(arrays)
    padding = bytes((-refs_offset) % 4)
    ref_position = refs_offset + len(padding)
    payload = (arrays + padding + struct.pack('<Q', texture_reference)
               + struct.pack('<fII', .5, offsets['teeth_color'], ref_position - data_start))
    block.extend(struct.pack('<5I', 589824, 16842752, 0, 3, len(payload)))
    block.extend(payload)
    return bytes(block)


def library(blocks, names=None, version=6):
    names = names or ['material' + str(i) for i in range(len(blocks))]
    strings = b''; offsets = []
    for name in names:
        offsets.append(len(strings)); strings += name.encode() + b'\0'
    data = bytearray(b'MTLs' + struct.pack('<II', version, len(strings)) + strings)
    data.extend(bytes((-len(data)) % 4)); data.extend(struct.pack('<I', len(blocks)))
    data.extend(struct.pack('<' + 'Q' * len(blocks), *range(1, len(blocks) + 1)))
    data.extend(struct.pack('<' + 'H' * len(blocks), *offsets))
    data.extend(bytes((-len(data)) % 4)); data.extend(b''.join(blocks))
    return bytes(data)


STUB = b'MTL!' + struct.pack('<II', 4, 1) + bytes(24)


class MaterialFormatTests(unittest.TestCase):
    def test_inline_v3_requires_valid_declared_extent_and_does_not_modify_bytes(self):
        raw = bytearray(library([inline_block(), inline_block()], ['teeth', 'mouthbag']))
        before = bytes(raw); result = classify_material_library(raw)
        self.assertEqual(result['classification'], 'supported_inline_v3')
        self.assertTrue(result['supported']); self.assertFalse(result['safe_as_native'])
        self.assertTrue(result['payload_extents_validated']); self.assertEqual(bytes(raw), before)
        self.assertEqual(result['blocks'][0]['shader'], 'yCh_Teeth')
        self.assertEqual(result['material_names'], ['teeth', 'mouthbag'])

    def test_exact_native_empty_stubs_are_recognized_by_existing_validator(self):
        result = classify_material_library(library([STUB, STUB], ['eye_l', 'teeth']))
        self.assertEqual(result['classification'], 'native_v6_stub')
        self.assertTrue(result['safe_as_native']); self.assertTrue(result['payload_extents_validated'])

    def test_outer_version_six_does_not_make_v1_or_v2_blocks_native(self):
        for version in (1, 2):
            result = classify_material_library(library([inline_block(version)]))
            self.assertEqual(result['classification'], 'unsupported_legacy_inline')
            self.assertFalse(result['supported']); self.assertFalse(result['safe_as_native'])
            self.assertTrue(result['envelope_validated']); self.assertFalse(result['payload_extents_validated'])
            self.assertEqual(result['observed_block_versions'], [version])

    def test_nonempty_or_wrong_version_stubs_never_qualify_as_native(self):
        altered = bytearray(STUB); altered[-1] = 1
        for raw in [library([bytes(altered)]), library([STUB], version=5)]:
            result = classify_material_library(raw)
            self.assertEqual(result['classification'], 'unsupported_block_layout')
            self.assertFalse(result['safe_as_native'])

    def test_truncated_tables_extents_or_trailing_data_are_rejected(self):
        valid = library([inline_block()])
        for raw in [valid[:10], valid[:-1], valid + b'junk', b'MTLs' + struct.pack('<II', 6, 0xffffffff)]:
            self.assertEqual(classify_material_library(raw)['classification'], 'malformed')

    def test_declared_parameter_size_cannot_consume_the_next_block(self):
        raw = bytearray(library([inline_block(), inline_block()]))
        first = raw.index(b'MTL!'); strings = struct.unpack_from('<I', raw, first + 8)[0]
        head = (first + 12 + strings + 3) & ~3
        struct.pack_into('<I', raw, head + 16, 0xfffffff0)
        self.assertEqual(classify_material_library(raw)['classification'], 'malformed')

    def test_bad_string_and_u64_pointers_are_not_silently_read_as_empty_or_null(self):
        valid = library([inline_block()]); first = valid.index(b'MTL!')
        strings = struct.unpack_from('<I', valid, first + 8)[0]
        head = (first + 12 + strings + 3) & ~3; data_start = head + 20
        for position in (data_start, len(valid) - 8, len(valid) - 4):
            raw = bytearray(valid); struct.pack_into('<I', raw, position, 0xfffffffc)
            self.assertEqual(classify_material_library(raw)['classification'], 'malformed')

    def test_interior_magic_is_ambiguous_for_the_original_scanning_reader(self):
        raw = bytearray(library([inline_block()]))
        # A valid raw float could spell the next-block magic. The original
        # scanner would split at this value despite the declared extent.
        raw[-12:-8] = b'MTL!'
        self.assertEqual(classify_material_library(raw)['classification'], 'ambiguous')

    def test_mixed_inline_and_native_blocks_are_ambiguous(self):
        for blocks in ([inline_block(), STUB], [STUB, inline_block()]):
            result = classify_material_library(library(blocks))
            self.assertEqual(result['classification'], 'ambiguous')
            self.assertFalse(result['supported']); self.assertFalse(result['safe_as_native'])

    def test_duplicate_material_names_do_not_create_an_arbitrary_definition_choice(self):
        self.assertEqual(classify_material_library(library([STUB, STUB], ['teeth', 'teeth']))['classification'], 'ambiguous')

    def test_zero_count_native_library_is_format_valid_without_inventing_materials(self):
        result = classify_material_library(library([]))
        self.assertEqual(result['classification'], 'native_v6_stub')
        self.assertEqual(result['material_names'], []); self.assertEqual(result['blocks'], [])

    def test_material_offsets_must_point_to_actual_string_starts(self):
        raw = bytearray(library([STUB], ['teeth']))
        strings = struct.unpack_from('<I', raw, 8)[0]
        count_offset = (12 + strings + 3) & ~3
        struct.pack_into('<H', raw, count_offset + 12, 1)
        self.assertEqual(classify_material_library(raw)['classification'], 'malformed')


if __name__ == '__main__':
    unittest.main()
