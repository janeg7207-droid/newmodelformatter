"""Verify UI branding delegates startup to the original entrypoint without Tk."""
import importlib.util
from pathlib import Path
import sys
import types
import unittest
from unittest import mock


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))
import gmf_repair


class EntrypointTests(unittest.TestCase):
    def test_worker_clears_teeth_selection_when_conversion_fails(self):
        base = types.ModuleType('gmf_gui_base')

        class OriginalApp:
            def work(self, src, dst, slot):
                raise RuntimeError('conversion failed')

        base.App = OriginalApp
        tkinter = types.ModuleType('tkinter')
        spec = importlib.util.spec_from_file_location(
            '_newmodelformatter_worker_test', PROJECT / 'newmodelformatter_gui.py')
        module = importlib.util.module_from_spec(spec)
        with mock.patch.dict(sys.modules, {'gmf_gui_base': base, 'tkinter': tkinter}):
            spec.loader.exec_module(module)
        app = module.App.__new__(module.App)
        app._gear_enabled = False
        app._teeth_enabled = True
        app._mask_enabled = False
        with mock.patch.object(module, 'set_gear_policy'), mock.patch.object(
                module, 'set_teeth_skin_workaround') as selection, mock.patch.object(
                module, 'set_clothing_masks') as masking:
            with self.assertRaisesRegex(RuntimeError, 'conversion failed'):
                app.work('input', 'output', None)
        self.assertEqual(selection.call_args_list, [mock.call(True), mock.call(False)])
        self.assertEqual(masking.call_args_list, [mock.call(False), mock.call(True)])

    def test_original_entrypoint_receives_subclass_and_returns_status(self):
        base = types.ModuleType('gmf_gui_base')

        class OriginalApp:
            pass

        base.App = OriginalApp
        calls = []
        status = 17

        def original_main():
            calls.append(('base.main', base.App))
            return status

        base.main = mock.Mock(side_effect=original_main)
        tkinter = types.ModuleType('tkinter')
        tkinter.Tk = mock.Mock(side_effect=AssertionError('Tk must not be constructed'))
        spec = importlib.util.spec_from_file_location(
            '_newmodelformatter_entrypoint_test', PROJECT / 'newmodelformatter_gui.py')
        module = importlib.util.module_from_spec(spec)
        with mock.patch.dict(sys.modules, {'gmf_gui_base': base, 'tkinter': tkinter}):
            with mock.patch.object(gmf_repair, 'install',
                                   side_effect=lambda: calls.append(('install', None))) as install:
                spec.loader.exec_module(module)
                result = module.main()

        self.assertEqual(result, status)
        self.assertIs(base.App, module.App)
        self.assertTrue(issubclass(module.App, OriginalApp))
        self.assertEqual(calls, [('install', None), ('base.main', module.App)])
        install.assert_called_once_with()
        base.main.assert_called_once_with()
        tkinter.Tk.assert_not_called()


if __name__ == '__main__':
    unittest.main()
