import copy
from contextlib import ExitStack
from pathlib import Path
import struct
import tempfile
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import gmf_tongue_anchor as anchor


def frame(tag, payload):
    value = struct.pack('<II4s', 4, len(payload), tag) + payload
    return value + bytes((-len(value)) % 4)


def chunk(tag, payload):
    return tag + struct.pack('<I', len(payload)) + payload


def fixture(extra_strings=(), duplicate_text=False, count=13, slot4=1605, other_mesh='M_Teeth', opaque_marker=b'payload-containing-GtPt-and-TEXT-as-data'):
    names = ['M_Teeth', 'M_Tongue', 'M_Head'] + ['_ag_%04d' % i for i in range(13)] + list(extra_strings)
    strings = b''; offsets = []
    for name in names:
        offsets.append(len(strings)); strings += name.encode() + b'\0'
    text = struct.pack('<I', len(names)) + struct.pack('<' + 'I' * len(names), *offsets) + strings
    text += bytes((-len(text)) % 4)
    order = [1, 3, 0, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    points = [('_ag_%04d' % i, 'M_Teeth' if i == 4 else other_mesh, i, slot4 if i == 4 else 10 + i) for i in order]
    records = b''.join(struct.pack('<HHHH', names.index(n), names.index(m), s, v) for n, m, s, v in points)
    opaque = opaque_marker + bytes(range(128))
    model = b'MDL!' + struct.pack('<II', 47, 1) + bytes(24)
    model += chunk(b'TEXT', text)
    if duplicate_text: model += chunk(b'TEXT', text)
    model += chunk(b'GtPt', struct.pack('<I', count) + records)
    model += chunk(b'MBfD', opaque) + chunk(b'END!', b'')
    data = b'MCD!' + frame(b'CTG!', b'ctg!') + frame(b'MDL!', model) + frame(b'HPL!', b'mask') + frame(b'END!', b'')
    return data, points


class TongueAnchorTests(unittest.TestCase):
    def setUp(self):
        self.data, self.points = fixture()
        self.changed, self.differences, self.after = anchor._replace_point(self.data)
        self.expected = [anchor.NEW_POINT if p[2] == 4 else p for p in self.points]

    def test_only_two_u16_fields_change_and_other_payloads_survive(self):
        self.assertEqual(self.after, self.expected)
        self.assertEqual(len(self.changed), len(self.data))
        _, _, offsets = anchor.read_points(self.data)
        position = offsets[4]
        allowed = {position + 2, position + 3, position + 6, position + 7}
        self.assertTrue(set(self.differences).issubset(allowed))
        for i, (a, b) in enumerate(zip(self.data, self.changed)):
            if i not in allowed: self.assertEqual(a, b)
        self.assertEqual(struct.unpack_from('<H', self.changed, position + 2)[0], 1)
        self.assertEqual(struct.unpack_from('<H', self.changed, position + 6)[0], 127)

    def test_unknown_full_file_fingerprint_is_refused(self):
        with self.assertRaisesRegex(ValueError, 'exact inspected profile'):
            anchor.candidate_bytes(self.data)

    def test_reviewed_candidate_and_idempotency(self):
        with patch.object(anchor, 'ORIGINAL_OUTPUT', anchor.fingerprint(self.data)), patch.object(anchor, 'PATCHED_OUTPUT', anchor.fingerprint(self.changed)):
            self.assertEqual(anchor.candidate_bytes(self.data)[0], self.changed)
            self.assertEqual(anchor.candidate_bytes(self.changed)[1], [])

    def test_changed_target_vertex_is_not_assumed_equivalent(self):
        data, _ = fixture(slot4=1606)
        with self.assertRaisesRegex(ValueError, 'differs from inspected bytes'):
            anchor._replace_point(data)

    def test_count_and_duplicate_target_chunks_are_rejected(self):
        for data in (fixture(count=12)[0], fixture(duplicate_text=True)[0]):
            with self.assertRaises(ValueError): anchor.read_points(data)

    def test_record_name_slot_collision_is_rejected(self):
        value = bytearray(self.data); _, _, offsets = anchor.read_points(value)
        struct.pack_into('<H', value, offsets[1] + 4, 1)
        with self.assertRaisesRegex(ValueError, 'record indices'):
            anchor.read_points(bytes(value))

    def test_duplicate_tongue_or_anchor_strings_are_rejected(self):
        for extra in (('M_Tongue',), ('_ag_0004',)):
            with self.assertRaises(ValueError): anchor._replace_point(fixture(extra)[0])

    def test_duplicate_untouched_mesh_names_do_not_rewrite_other_records(self):
        data, points = fixture(('M_Head',), other_mesh='M_Head')
        _, _, after = anchor._replace_point(data)
        self.assertEqual(after, [anchor.NEW_POINT if p[2] == 4 else p for p in points])

    def test_text_offset_inside_string_is_rejected(self):
        value = bytearray(self.data); begin, _ = anchor._chunks(value)[b'TEXT']
        struct.pack_into('<I', value, begin + 4, 1)
        with self.assertRaisesRegex(ValueError, 'inside a string'):
            anchor.read_points(bytes(value))

    def test_unterminated_text_and_nonzero_padding_are_rejected(self):
        value = bytearray(self.data); _, end = anchor._chunks(value)[b'TEXT']
        value[end - 1] = 65
        with self.assertRaises(ValueError): anchor.read_points(bytes(value))

    def test_truncated_outer_inner_and_invalid_version_are_rejected(self):
        for cut in (1, 12, 32):
            with self.assertRaises(ValueError): anchor.read_points(self.data[:-cut])
        value = bytearray(self.data); struct.pack_into('<I', value, 4, 3)
        with self.assertRaises(ValueError): anchor.read_points(bytes(value))
        value = bytearray(self.data); model_position = value.find(b'MDL!') + 4
        struct.pack_into('<I', value, model_position + 4, 41)
        with self.assertRaises(ValueError): anchor.read_points(bytes(value))

    def make_paths(self, root):
        source_root = root / 'input'; target_root = root / 'output'
        source_root.mkdir(); target_root.mkdir()
        source = source_root / 'baseModel.mcd'; target = target_root / 'baseModel.mcd'
        source.write_bytes(b'exact known supplied source fixture'); target.write_bytes(self.data)
        gear = target_root / 'attire.mcd'; gear.write_bytes(b'unchanged-gear-mask-weights')
        record = {'source': str(source), 'output': str(target), 'verify': 'pass', 'status': 'converted'}
        recovery = {'paired_source_base': str(source), 'paired_output_base_sha256': anchor.fingerprint(self.data)[0]}
        report = {'output': str(target_root), 'models': [record, {'supplied_hide_mask_recovery': copy.deepcopy(recovery), 'facts': {'supplied_hide_mask_recovery': copy.deepcopy(recovery)}}]}
        return source_root, target_root, source, target, gear, record, report

    def native(self, failure=False, mutate=False, data=None, points=None):
        def read_model(path, with_shapes):
            self.assertFalse(with_shapes)
            if failure: raise RuntimeError('reader refused stage')
            if mutate: Path(path).write_bytes(b'changed while staging')
            else: self.assertEqual(Path(path).read_bytes(), self.changed if data is None else data)
            return SimpleNamespace(goto_points=self.expected if points is None else points, meshes=[SimpleNamespace(name='M_Tongue', num_verts=341)])
        return SimpleNamespace(read_model=read_model)

    def run_process(self, source_root, target_root, source, report, native):
        with patch.object(anchor, 'LEGACY_SOURCE', anchor.fingerprint(source.read_bytes())), patch.object(anchor, 'ORIGINAL_OUTPUT', anchor.fingerprint(self.data)), patch.object(anchor, 'PATCHED_OUTPUT', anchor.fingerprint(self.changed)):
            anchor.process(report, source_root, target_root, native)

    def test_success_preserves_source_gear_and_updates_mask_identity_chain(self):
        with tempfile.TemporaryDirectory() as name:
            paths = self.make_paths(Path(name)); source_root, target_root, source, target, gear, record, report = paths
            source_before = source.read_bytes(); gear_before = gear.read_bytes()
            self.run_process(source_root, target_root, source, report, self.native())
            self.assertEqual(target.read_bytes(), self.changed)
            self.assertEqual(source.read_bytes(), source_before)
            self.assertEqual(gear.read_bytes(), gear_before)
            self.assertEqual(report['tongue_anchor_experiment']['applied'], 1)
            self.assertEqual(record['verify'], 'pass')
            self.assertEqual(record['experimental_tongue_anchor']['black_teeth_fixed'], 'not established')
            self.assertEqual(report['conversion_completeness'], 'incomplete')
            self.assertTrue(any('in-game teeth check' in p for p in report['problems']))
            for holder in (report['models'][1], report['models'][1]['facts']):
                chain = holder['supplied_hide_mask_recovery']
                self.assertEqual(chain['paired_output_base_sha256'], anchor.fingerprint(self.changed)[0])
                self.assertEqual(chain['paired_base_verified_before_anchor_sha256'], anchor.fingerprint(self.data)[0])

    def test_reader_failure_and_stage_mutation_leave_output_unchanged(self):
        for kwargs in ({'failure': True}, {'mutate': True}):
            with tempfile.TemporaryDirectory() as name:
                source_root, target_root, source, target, _, record, report = self.make_paths(Path(name))
                self.run_process(source_root, target_root, source, report, self.native(**kwargs))
                self.assertEqual(target.read_bytes(), self.data)
                self.assertEqual(record['experimental_tongue_anchor']['state'], 'not_applied')
                self.assertFalse(list(target_root.glob('.tongue-anchor-*')))

    def test_failed_conversion_is_not_repaired_from_stale_output(self):
        with tempfile.TemporaryDirectory() as name:
            source_root, target_root, source, target, _, record, report = self.make_paths(Path(name))
            record['verify'] = 'fail'
            self.run_process(source_root, target_root, source, report, self.native(failure=True))
            self.assertEqual(target.read_bytes(), self.data)
            self.assertNotIn('experimental_tongue_anchor', record)

    def test_output_escape_and_file_symlinks_are_refused(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name); source_root, target_root, source, target, _, record, report = self.make_paths(root)
            external = root / 'outside.mcd'; external.write_bytes(self.data)
            record['output'] = str(external)
            self.run_process(source_root, target_root, source, report, self.native(failure=True))
            self.assertEqual(external.read_bytes(), self.data)
            target.unlink(); target.symlink_to(external); record['output'] = str(target)
            self.run_process(source_root, target_root, source, report, self.native(failure=True))
            self.assertTrue(target.is_symlink()); self.assertEqual(external.read_bytes(), self.data)

    def test_unrecognized_source_is_untouched(self):
        with tempfile.TemporaryDirectory() as name:
            source_root, target_root, _, target, _, record, report = self.make_paths(Path(name))
            anchor.process(report, source_root, target_root, self.native(failure=True))
            self.assertEqual(target.read_bytes(), self.data)
            self.assertNotIn('experimental_tongue_anchor', record)

    def test_matching_source_with_unrecognized_output_is_left_unchanged(self):
        with tempfile.TemporaryDirectory() as name:
            source_root, target_root, source, target, _, record, report = self.make_paths(Path(name))
            target.write_bytes(b'unrecognized output')
            self.run_process(source_root, target_root, source, report, self.native(failure=True))
            self.assertEqual(target.read_bytes(), b'unrecognized output')
            self.assertEqual(record['experimental_tongue_anchor']['state'], 'not_applied')

    def test_install_uses_original_converter_vc_alias_and_is_idempotent(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name); source = root / 'input'; output = root / 'output'
            source.mkdir(); output.mkdir(); calls = []; saved = []
            report = {'output': str(output), 'models': []}
            def original(src, dst, log=lambda text: None):
                calls.append((src, dst)); return report
            reader = self.native(failure=True)
            convert = SimpleNamespace(vc=reader)
            folder = SimpleNamespace(convert_folder=original)
            fake_report = SimpleNamespace(save_intermediate=lambda value, dst: saved.append((value, dst)))
            with patch.dict(sys.modules, {'gmf_report': fake_report}):
                anchor.install(convert, SimpleNamespace(), folder)
                first = folder.convert_folder
                anchor.install(convert, SimpleNamespace(), folder)
                self.assertIs(first, folder.convert_folder)
                result = folder.convert_folder(str(source), str(output))
            self.assertIs(result, report)
            self.assertEqual(len(calls), 1)
            self.assertEqual(report['tongue_anchor_experiment']['applied'], 0)
            self.assertEqual(saved, [(report, str(output))])

    def test_native_preservation_facts_describe_final_anchor_patched_bytes(self):
        with tempfile.TemporaryDirectory() as name:
            source_root, target_root, source, target, _, record, report = self.make_paths(Path(name))
            source.write_bytes(self.data)
            record.update(status='preserved_2k26', facts={
                'source_sha256': anchor.fingerprint(self.data)[0],
                'output_sha256': anchor.fingerprint(self.data)[0],
                'byte_identical': True, 'geometry_weights_bones_and_embedded_streams': 'byte_identical'})
            report['native_2k26_models_preserved'] = 1
            self.run_process(source_root, target_root, source, report, self.native())
            self.assertEqual(target.read_bytes(), self.changed)
            facts = record['facts']
            self.assertEqual(facts['source_sha256'], anchor.fingerprint(self.data)[0])
            self.assertEqual(facts['output_sha256'], anchor.fingerprint(self.changed)[0])
            self.assertEqual(facts['output_sha256_before_experimental_anchor'], anchor.fingerprint(self.data)[0])
            self.assertFalse(facts['byte_identical'])
            self.assertIn('only GtPt slot 4', facts['geometry_weights_bones_and_embedded_streams'])
            self.assertEqual(report['native_2k26_models_preserved'], 0)

    def test_bad_facts_refuses_before_writing_and_logger_failure_cannot_deny_commit(self):
        with tempfile.TemporaryDirectory() as name:
            source_root, target_root, source, target, _, record, report = self.make_paths(Path(name))
            record['facts'] = 'invalid facts'
            self.run_process(source_root, target_root, source, report, self.native(failure=True))
            self.assertEqual(target.read_bytes(), self.data)
            self.assertEqual(record['experimental_tongue_anchor']['state'], 'not_applied')
            record['facts'] = {}
            def failed_log(text): raise RuntimeError('logging unavailable')
            with patch.object(anchor, 'LEGACY_SOURCE', anchor.fingerprint(source.read_bytes())), patch.object(anchor, 'ORIGINAL_OUTPUT', anchor.fingerprint(self.data)), patch.object(anchor, 'PATCHED_OUTPUT', anchor.fingerprint(self.changed)):
                anchor.process(report, source_root, target_root, self.native(), failed_log)
            self.assertEqual(target.read_bytes(), self.changed)
            self.assertEqual(record['experimental_tongue_anchor']['state'], 'applied_experimental_anchor_test')
            self.assertEqual(record['experimental_tongue_anchor']['logging_error'], 'logging unavailable')

    def test_already_applied_native_input_preserves_true_byte_identity_but_requires_game_check(self):
        with tempfile.TemporaryDirectory() as name:
            source_root, target_root, source, target, _, record, report = self.make_paths(Path(name))
            source.write_bytes(self.changed); target.write_bytes(self.changed)
            record.update(status='preserved_2k26', facts={'byte_identical': True})
            report['native_2k26_models_preserved'] = 1
            self.run_process(source_root, target_root, source, report, self.native(failure=True))
            self.assertEqual(target.read_bytes(), self.changed)
            self.assertTrue(record['facts']['byte_identical'])
            self.assertEqual(report['native_2k26_models_preserved'], 1)
            self.assertEqual(record['experimental_tongue_anchor']['state'], 'already_applied')
            self.assertEqual(record['experimental_tongue_anchor']['old_point'], list(anchor.NEW_POINT))
            self.assertEqual(report['conversion_completeness'], 'incomplete')

    def flip_fixture(self):
        data, points = fixture(slot4=1603, opaque_marker=b'different-flip-model-payload')
        changed, _, expected = anchor._replace_point(data, anchor.profiles()[1])
        return data, changed, points, expected

    def mock_profiles(self, source_bryan=None, source_flip=None):
        flip, changed, _, _ = self.flip_fixture()
        values = {'ORIGINAL_OUTPUT': anchor.fingerprint(self.data),
                  'PATCHED_OUTPUT': anchor.fingerprint(self.changed),
                  'FLIP_ORIGINAL_OUTPUT': anchor.fingerprint(flip),
                  'FLIP_PATCHED_OUTPUT': anchor.fingerprint(changed)}
        if source_bryan is not None: values['LEGACY_SOURCE'] = anchor.fingerprint(source_bryan)
        if source_flip is not None: values['FLIP_LEGACY_SOURCE'] = anchor.fingerprint(source_flip)
        stack = ExitStack()
        for name, value in values.items(): stack.enter_context(patch.object(anchor, name, value))
        return stack

    def test_flip_exact_candidate_and_idempotence_preserve_other_records(self):
        data, changed, points, expected = self.flip_fixture()
        with self.mock_profiles():
            actual, offsets, after = anchor.candidate_bytes(data)
            self.assertEqual(actual, changed)
            self.assertEqual(after, [anchor.FLIP_NEW_POINT if p[2] == 4 else p for p in points])
            self.assertEqual(after, expected)
            self.assertTrue(offsets)
            self.assertEqual(anchor.candidate_bytes(changed)[1], [])
            self.assertEqual(anchor.source_profile(anchor.fingerprint(data))['name'], 'Flip Gordon')

    def test_profile_selection_rejects_bryan_flip_cross_application(self):
        flip, changed, _, _ = self.flip_fixture()
        with self.mock_profiles():
            bryan_profile, flip_profile = anchor.profiles()
            for data, profile in ((flip, bryan_profile), (changed, bryan_profile),
                                  (self.data, flip_profile), (self.changed, flip_profile)):
                with self.assertRaisesRegex(ValueError, 'exact inspected profile'):
                    anchor.candidate_bytes(data, profile)

    def test_flip_process_has_its_own_metadata_and_final_mask_sha_chain(self):
        data, changed, _, expected = self.flip_fixture()
        with tempfile.TemporaryDirectory() as name:
            source_root, target_root, source, target, gear, record, report = self.make_paths(Path(name))
            target.write_bytes(data); source_before = source.read_bytes(); gear_before = gear.read_bytes()
            for holder in (report['models'][1], report['models'][1]['facts']):
                holder['supplied_hide_mask_recovery']['paired_output_base_sha256'] = anchor.fingerprint(data)[0]
            with self.mock_profiles(source_flip=source_before):
                anchor.process(report, source_root, target_root, self.native(data=changed, points=expected))
            self.assertEqual(target.read_bytes(), changed)
            self.assertEqual(source.read_bytes(), source_before)
            self.assertEqual(gear.read_bytes(), gear_before)
            trial = record['experimental_tongue_anchor']
            self.assertEqual(trial['profile'], 'Flip Gordon')
            self.assertEqual(trial['profile_original_point'], list(anchor.FLIP_OLD_POINT))
            self.assertIn('Flip Gordon', trial['provenance']['scope'])
            self.assertEqual(report['tongue_anchor_experiment']['matched_profiles'], ['Flip Gordon'])
            self.assertTrue(any('Experimental Flip Gordon' in p for p in report['problems']))
            for holder in (report['models'][1], report['models'][1]['facts']):
                recovery = holder['supplied_hide_mask_recovery']
                self.assertEqual(recovery['paired_output_base_sha256'], anchor.fingerprint(changed)[0])
                self.assertEqual(recovery['paired_base_verified_before_anchor_sha256'], anchor.fingerprint(data)[0])

    def test_flip_native_repair_and_reuse_keep_byte_identity_facts_truthful(self):
        data, changed, _, expected = self.flip_fixture()
        with tempfile.TemporaryDirectory() as name:
            source_root, target_root, source, target, _, record, report = self.make_paths(Path(name))
            source.write_bytes(data); target.write_bytes(data)
            record.update(status='preserved_2k26', facts={'source_sha256': anchor.fingerprint(data)[0],
                'output_sha256': anchor.fingerprint(data)[0], 'byte_identical': True})
            report['native_2k26_models_preserved'] = 1
            with self.mock_profiles():
                anchor.process(report, source_root, target_root, self.native(data=changed, points=expected))
                self.assertFalse(record['facts']['byte_identical'])
                self.assertEqual(record['facts']['output_sha256'], anchor.fingerprint(changed)[0])
                self.assertEqual(record['facts']['source_sha256'], anchor.fingerprint(data)[0])
                self.assertEqual(report['native_2k26_models_preserved'], 0)
                source.write_bytes(changed)
                record.update(status='preserved_2k26', facts={'source_sha256': anchor.fingerprint(changed)[0],
                    'output_sha256': anchor.fingerprint(changed)[0], 'byte_identical': True})
                report['native_2k26_models_preserved'] = 1
                anchor.process(report, source_root, target_root, self.native(failure=True))
            self.assertEqual(target.read_bytes(), changed)
            self.assertTrue(record['facts']['byte_identical'])
            self.assertEqual(report['native_2k26_models_preserved'], 1)
            self.assertEqual(record['experimental_tongue_anchor']['state'], 'already_applied')
            self.assertEqual(report['conversion_completeness'], 'incomplete')

    def test_process_rejects_cross_profile_pairs_before_native_staging(self):
        flip, _, _, _ = self.flip_fixture()
        bryan_source = b'known-only-bryan-legacy-input'; flip_source = b'known-only-flip-legacy-input'
        for source_bytes, target_bytes in ((bryan_source, flip), (flip_source, self.data)):
            with self.subTest(source=source_bytes), tempfile.TemporaryDirectory() as name:
                source_root, target_root, source, target, _, record, report = self.make_paths(Path(name))
                source.write_bytes(source_bytes); target.write_bytes(target_bytes)
                with self.mock_profiles(source_bryan=bryan_source, source_flip=flip_source):
                    anchor.process(report, source_root, target_root, self.native(failure=True))
                self.assertEqual(source.read_bytes(), source_bytes)
                self.assertEqual(target.read_bytes(), target_bytes)
                self.assertEqual(record['experimental_tongue_anchor']['state'], 'not_applied')
                self.assertIn('exact inspected profile', record['experimental_tongue_anchor']['reason'])
                self.assertEqual(report['tongue_anchor_experiment']['applied'], 0)


if __name__ == '__main__': unittest.main()
