import copy
import math
from pathlib import Path
import random
import sys
import types
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from gmf_surface_transfer import Surface,transfer_weights
from gmf_surface_math import _closest_point_bary


def mesh(name,positions,triangles,weights):
    return types.SimpleNamespace(name=name,num_verts=len(positions),positions=positions,triangles=triangles,weights=weights)


class SurfaceTransferTests(unittest.TestCase):
    def test_projection_matches_analytic_face_edge_and_corner(self):
        s=Surface([(0,0,0),(1,0,0),(0,1,0)],[(0,1,2)])
        _,bary,d2=s.nearest((.2,.3,2))
        for actual,expected in zip(bary,(.5,.2,.3)):self.assertAlmostEqual(actual,expected)
        self.assertAlmostEqual(d2,4.)
        _,bary,d2=s.nearest((2,0,0));self.assertEqual(bary,(0.,1.,0.));self.assertAlmostEqual(d2,1.)
        _,bary,d2=s.nearest((.5,-1,0));self.assertEqual(bary,(.5,.5,0.));self.assertAlmostEqual(d2,1.)

    def test_acceleration_matches_exhaustive_reference_math(self):
        rng=random.Random(13)
        positions=[tuple(rng.uniform(-2,2) for _ in range(3)) for _ in range(90)]
        triangles=[(i,i+1,i+2) for i in range(0,90,3)]
        s=Surface(positions,triangles)
        for _ in range(30):
            point=tuple(rng.uniform(-3,3) for _ in range(3))
            candidates=[(_closest_point_bary(point,*(positions[j] for j in t))[1],i) for i,t in enumerate(triangles)]
            expected=min(candidates);tri,bary,d2=s.nearest(point)
            self.assertEqual(tri,expected[1]);self.assertAlmostEqual(d2,expected[0],places=10)

    def test_surface_transfer_interpolates_and_preserves_all_geometry(self):
        donor=mesh('M_Body',[(0,0,0),(1,0,0),(0,1,0)],[(0,1,2)],{'J_A':[1.,0.,0.],'J_B':[0.,1.,1.]})
        target=mesh('M_Wings',[(.2,.3,.5),(0,0,0)],[(0,1,1)],{'removed':[1.,1.]})
        original=copy.deepcopy(target);donor_before=copy.deepcopy(donor)
        report=transfer_weights(target,donor,{'J_A','J_B'})
        self.assertAlmostEqual(target.weights['J_A'][0],.5);self.assertAlmostEqual(target.weights['J_B'][0],.5)
        self.assertEqual(target.positions,original.positions);self.assertEqual(target.triangles,original.triangles)
        self.assertEqual(donor.weights,donor_before.weights);self.assertEqual(report['verts_changed'],2)

    def test_cutoff_removes_ghost_influence_then_normalizes(self):
        donor=mesh('M_Body',[(0,0,0),(1,0,0),(0,1,0)],[(0,1,2)],{'J_A':[.999]*3,'J_B':[.001]*3})
        target=mesh('M_Tops',[(.3,.2,0)],[],{})
        transfer_weights(target,donor,{'J_A','J_B'})
        self.assertEqual(list(target.weights),['J_A']);self.assertAlmostEqual(target.weights['J_A'][0],1.)

    def test_native_influence_budget_is_explicit_and_normalized(self):
        names=['J_'+str(i) for i in range(12)]
        donor=mesh('M_Body',[(0,0,0),(1,0,0),(0,1,0)],[(0,1,2)],{n:[1/12]*3 for n in names})
        target=mesh('M_Tops',[(.3,.2,0)],[],{})
        report=transfer_weights(target,donor,set(names))
        self.assertEqual(len(target.weights),8);self.assertEqual(report['vertices_capped_to_native_budget'],1)
        self.assertAlmostEqual(sum(float(w[0]) for w in target.weights.values()),1.)

    def test_failure_is_transactional_for_invalid_donor_and_unknown_bone(self):
        for weights in [{'J_bad':[1.,1.,1.]},{'J_A':[float('nan'),1.,1.]},{'J_A':[-1.,1.,1.]}]:
            donor=mesh('M_Body',[(0,0,0),(1,0,0),(0,1,0)],[(0,1,2)],weights)
            target=mesh('M_Tops',[(.3,.2,0)],[],{'original':[1.]})
            before=copy.deepcopy(target.weights)
            with self.assertRaises(ValueError):transfer_weights(target,donor,{'J_A'})
            self.assertEqual(target.weights,before)

    def test_rejects_out_of_domain_triangles_and_nonfinite_positions(self):
        with self.assertRaises(ValueError):Surface([(0,0,0),(1,0,0),(0,1,0)],[(0,1,3)])
        with self.assertRaises(ValueError):Surface([(float('nan'),0,0)],[(0,0,0)])

    def test_degenerate_donor_faces_are_reported_and_not_used(self):
        s=Surface([(0,0,0),(1,0,0),(0,1,0)],[(0,0,0),(0,1,2)])
        self.assertEqual(s.degenerate_triangles,1);self.assertEqual(s.nearest((.3,.2,0))[0],1)
        with self.assertRaises(ValueError):Surface([(0,0,0)],[(0,0,0)])
