"""Exercise embedded fallback through the inspected original Gorilla HPL functions."""
import copy
import hashlib
from pathlib import Path
import tempfile
import types
import unittest
from unittest import mock

import gmf_embedded_masks as repair
import gmf_mask_recovery as supplied_rey
from test_mask_recovery import RecoveryFixture


class EmbeddedFixture(RecoveryFixture):
    def __init__(self, root):
        super().__init__(root)
        self.mask = self.mcd.build_hpl({0: [('M_Body', [1, 2, 3]), ('M_Head', [2])],
                                      1: [('M_Body', [1, 2, 3]), ('M_Head', [2])]})
        self.source_attire = types.SimpleNamespace(version=41, meshes=[], substreams=[(b'HPL!', self.mask)])
        self.original_namespace = self.module.convert_mcd.__globals__
        self.original_expected = self.original_namespace['expected_mask']
        self.original_sidecar = self.original_namespace['_sidecar_streams']
        self.module.vc.read_model = self.read_model

    def read_model(self, path):
        if Path(path) == self.src_base: return self.source_base
        if Path(path) == self.src_model: return self.source_attire
        return self.output_base

    def run(self):
        repair.install(self.module, self.folder)
        return self.folder.convert_folder(str(self.source), str(self.root/'out'))


class EmbeddedMaskTests(unittest.TestCase):
    def test_readable_embedded_mask_recovered_and_original_verifier_checks_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = EmbeddedFixture(Path(tmp))
            report = f.run()
            self.assertTrue(report['verification'][0])
            self.assertEqual(report['verification'][2]['hide_mask'], 'mask')
            record = report['models'][1]['embedded_hide_mask_recovery']
            self.assertFalse(record['coverage_generated'])
            self.assertTrue(record['original_source_unchanged'])
            self.assertEqual(record['method'], 'existing_source_embedded_hpl_through_original_parser_filter_writer')
            self.assertEqual(f.streams, [(b'HPL!', f.mask)])
            self.assertEqual({p: p.read_bytes() for p in f.before}, f.before)
            self.assertIs(f.original_namespace['expected_mask'], f.original_expected)
            self.assertIs(f.original_namespace['_sidecar_streams'], f.original_sidecar)
            # Scoped bytes/existence never replace process or original consumer APIs.
            self.assertEqual(f.module.expected_mask(str(f.src_hpl), {}, f.body_limits)[1], 'unreadable')

    def test_absent_sidecar_is_virtualized_only_for_the_original_parser(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = EmbeddedFixture(Path(tmp)); f.src_hpl.unlink()
            report = f.run()
            self.assertTrue(report['verification'][0])
            self.assertIn('embedded_hide_mask_recovery', report['models'][1])
            self.assertFalse(f.src_hpl.exists())
            self.assertEqual(f.module.expected_mask(str(f.src_hpl), {}, f.body_limits)[1], 'none')

    def test_readable_sidecar_including_intentional_empty_wins(self):
        for empty in (False, True):
            with self.subTest(empty=empty), tempfile.TemporaryDirectory() as tmp:
                f = EmbeddedFixture(Path(tmp))
                sidecar = f.mcd.EMPTY_HPL if empty else f.mcd.build_hpl({0: [('M_Body', [5])]})
                f.src_hpl.write_bytes(sidecar)
                report = f.run()
                self.assertNotIn('embedded_hide_mask_recovery', report['models'][1])
                self.assertEqual(f.streams, [(b'HPL!', sidecar)])

    def test_failed_or_unrun_base_verification_blocks_fallback(self):
        for mode in ('failed', 'unrun'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                f = EmbeddedFixture(Path(tmp))
                f.base_verify_failure = mode == 'failed'; f.skip_base_verification = mode == 'unrun'
                report = f.run()
                self.assertNotIn('embedded_hide_mask_recovery', report['models'][1])
                self.assertEqual(report['verification'][2]['hide_mask'], 'unreadable')
                self.assertEqual(f.streams, [(b'HPL!', f.mcd.EMPTY_HPL)])

    def test_changed_remap_topology_bounds_or_base_file_blocks_fallback(self):
        for mode in ('remap', 'triangles', 'bounds', 'base_bytes'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                f = EmbeddedFixture(Path(tmp))
                if mode == 'remap':
                    table = f.output_base.meshes[0].vertex_remap; table[1], table[2] = table[2], table[1]
                elif mode == 'triangles': f.output_base.meshes[0].triangles = [[0, 2, 1]]
                elif mode == 'bounds': f.after_base = lambda: f.body_limits.update(M_Body=12754)
                else: f.after_base = lambda: f.dst_base.write_bytes(b'stale converted base')
                report = f.run()
                self.assertNotIn('embedded_hide_mask_recovery', report['models'][1])

    def test_embedded_empty_unreadable_duplicate_and_outside_domains_are_rejected(self):
        for mode in ('empty', 'unreadable', 'duplicate', 'outside', 'unknown_mesh', 'nonuniform'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                f = EmbeddedFixture(Path(tmp))
                if mode == 'empty': f.source_attire.substreams = [(b'HPL!', f.mcd.EMPTY_HPL)]
                elif mode == 'unreadable': f.source_attire.substreams = [(b'HPL!', b'HPL!bad')]
                elif mode == 'duplicate': f.source_attire.substreams.append((b'HPL!', f.mask))
                elif mode == 'outside': f.source_attire.substreams = [(b'HPL!', f.mcd.build_hpl({0: [('M_Body', [12755])]}))]
                elif mode == 'unknown_mesh': f.source_attire.substreams = [(b'HPL!', f.mcd.build_hpl({0: [('OtherBody', [1])]}))]
                else:
                    original_parse = f.mcd.parse_hpl
                    def nonuniform(data):
                        parsed = original_parse(data)
                        if data == f.mask: parsed[1][0][0][1].append(6)
                        return parsed
                    f.mcd.parse_hpl = nonuniform
                report = f.run()
                self.assertNotIn('embedded_hide_mask_recovery', report['models'][1])

    def test_native_attire_does_not_enter_the_legacy_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = EmbeddedFixture(Path(tmp)); f.source_attire.version = 47
            self.assertNotIn('embedded_hide_mask_recovery', f.run()['models'][1])

    def test_known_invalid_sidecar_diagnosis_requires_exact_fingerprint(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = EmbeddedFixture(Path(tmp)); f.source_attire.substreams = []
            digest = hashlib.sha256(f.src_hpl.read_bytes()).hexdigest()
            with mock.patch.object(repair, 'KNOWN_INVALID_SHA256', digest), mock.patch.object(repair, 'KNOWN_INVALID_BYTES', f.src_hpl.stat().st_size):
                report = f.run()
            diagnosis = report['models'][1]['hide_mask_source_diagnosis']
            self.assertEqual(diagnosis['state'], 'known_invalid_shared_hpl')
            self.assertEqual(diagnosis['sidecar_sha256'], digest)
            self.assertEqual(diagnosis['embedded_mask_state'], 'absent')
            self.assertEqual(diagnosis['source_model'], str(f.src_model))
            self.assertEqual(diagnosis['matching_source_base'], str(f.src_base))
            self.assertFalse(diagnosis['coverage_generated'])

    def test_wrapper_closure_consumers_are_isolated_too(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = EmbeddedFixture(Path(tmp))
            original = f.module.convert_mcd
            def wrap(function):
                import functools
                @functools.wraps(function)
                def convert_mcd(*args, **kwargs): return function(*args, **kwargs)
                return convert_mcd
            f.module.convert_mcd = wrap(original)
            report = f.run()
            self.assertIn('embedded_hide_mask_recovery', report['models'][1])
            self.assertIs(original.__globals__['expected_mask'], f.original_expected)

    def test_existing_exact_rey_recovery_keeps_precedence(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = EmbeddedFixture(Path(tmp))
            # Only the existing Rey profile's synthetic fixture fingerprints
            # are substituted. Generic fallback hashes these real test files.
            with mock.patch.object(supplied_rey, '_fingerprint', f.fingerprint):
                supplied_rey.install(f.module, f.folder)
                report = f.run()
            self.assertTrue(report['verification'][0])
            self.assertIn('hide_mask_recovery', report['models'][1])
            self.assertNotIn('embedded_hide_mask_recovery', report['models'][1])
            self.assertEqual(f.streams[0][1], f.mcd.build_hpl(f.mcd.parse_hpl(supplied_rey.replacement_hpl())[0]))

    def test_changed_source_attire_after_conversion_does_not_verify_as_recovered(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = EmbeddedFixture(Path(tmp))
            original_verify = f.module.verify
            namespace = dict(original_verify.__globals__)
            namespace['original_verify'] = original_verify
            exec('''
def verify(src_path, dst_path, ref=None, body_limits=None):
    if Path(src_path)==fixture.src_model:
        fixture.src_model.write_bytes(b'changed source attire')
    return original_verify(src_path,dst_path,ref,body_limits)
''', namespace)
            f.module.verify = namespace['verify']
            report = f.run()
            self.assertIn('embedded_hide_mask_recovery', report['models'][1])
            self.assertNotIn('embedded_hide_mask_recovery', report['verification'][2])
            self.assertEqual(report['verification'][2]['hide_mask'], 'unreadable')

    def test_previous_job_context_is_restored_on_failure(self):
        sentinel = {'bases': {}, 'attires': {}}
        old = getattr(repair._context, 'job', None); repair._context.job = sentinel
        try:
            with tempfile.TemporaryDirectory() as tmp:
                f = EmbeddedFixture(Path(tmp)); f.job_callback = lambda: (_ for _ in ()).throw(ValueError('stop job'))
                with self.assertRaisesRegex(ValueError, 'stop job'): f.run()
                self.assertIs(repair._context.job, sentinel)
        finally: repair._context.job = old


if __name__ == '__main__': unittest.main()
