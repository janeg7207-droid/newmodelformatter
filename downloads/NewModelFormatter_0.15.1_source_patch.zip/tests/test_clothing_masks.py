"""Generic material/scene/atomic mask guards with actual native HPL/JMTL writers."""
import copy
import hashlib
from pathlib import Path
import struct
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import gmf_clothing_masks as masks
from gmf_2k26_repair import game_folder, path_hash
from gmf_native_assets import write_library
from gmf_native_masks import envelopes, splice_mask
from gmf_mask_lods import EMPTY_HPL
from test_clothing_coverage import grid, rectangle
from test_local_textures import reference_writer
from test_mask_recovery import pure_mcd


def frame(tag, data):
    result = struct.pack('<II4s', 4, len(data), tag) + data
    return result + bytes((-len(result)) % 4)


def native(mesh_count, mask=None):
    segment = struct.pack('<I', mesh_count) + b'controlled native geometry segment' + b'ENDM' + bytes(4)
    lods = struct.pack('<I', 4) + segment * 4
    model = b'MDL!' + struct.pack('<II', 47, 1) + bytes(24)
    model += b'LODs' + struct.pack('<I', len(lods)) + lods + b'END!' + bytes(4)
    result = b'MCD!' + frame(b'MDL!', model) + frame(b'WDF!', b'unchanged physics payload')
    if mask is not None:
        result += frame(b'HPL!', mask)
    return result + frame(b'END!', b'')


def mask_payload(data):
    return next((f['payload'] for f in envelopes(data) if f['tag'] == b'HPL!'), None)


class ClothingMaskTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.writer = staticmethod(reference_writer().write_jmtl)

    def setUp(self):
        masks.set_enabled(True)

    def tearDown(self):
        masks.set_enabled(True)

    def fixture(self, root, *, character='Custom_Clothes', scene=128, mask='authored', full=False):
        mcd = pure_mcd(); src_root = root / 'original'; dst_root = root / 'converted'
        source = src_root / character / 'Attire_A' / 'costume.mcd'
        target = dst_root / 'Characters' / character / 'Attire_A' / 'costume.mcd'
        source_base = source.parent.parent / 'BaseModel' / 'baseModel.mcd'
        output_base = target.parent.parent / 'BaseModel' / 'baseModel.mcd'
        for p in (source, target, source_base, output_base):
            p.parent.mkdir(parents=True, exist_ok=True)
        body = grid(); body.name = 'M_Body'; body.scene_flag = 128
        body.weights = {'H_Root': np.ones(body.num_verts)}; body.face_groups = [('body', 0, len(body.triangles))]
        cloth = rectangle(-2.1 if full else -1.2, 2.1 if full else 1.2,
                          -2.1 if full else -1.2, 2.1 if full else 1.2, .04, name='M_Garment')
        cloth.vertex_remap = np.arange(cloth.num_verts, dtype=np.uint32)
        cloth.weights = {'H_Root': np.ones(cloth.num_verts)}; cloth.scene_flag = scene
        cloth.face_groups = [('custom_gear', 0, 2)]
        bones = [SimpleNamespace(name='H_Root', parent=None, world=np.eye(4))]
        base_model = SimpleNamespace(version=47, meshes=[body], bones=bones, substreams=[])
        attire_model = SimpleNamespace(version=47, meshes=[cloth], bones=copy.deepcopy(bones), substreams=[])
        current = (mcd.build_hpl({0: [('M_Body', [0])], 1: [('M_Body', [0])]})
                   if mask == 'authored' else EMPTY_HPL if mask == 'empty' else None if mask == 'absent' else mask)
        source.write_bytes(b'controlled original legacy geometry, not a full conversion fixture')
        source_base.write_bytes(b'controlled original same-character base')
        target.write_bytes(native(1, current)); output_base.write_bytes(native(1))
        source_hpl = source.with_suffix('.hpl'); source_hpl.write_bytes(b'preserved original source sidecar')
        table = target.with_suffix('.mtls'); materials = target.parent / 'Materials'; materials.mkdir()
        jmtl = materials / 'custom_gear.jmtl'
        jmtl.write_bytes(self.writer(0x15, {'colorMap@ref': 123456, 'nrMap@ref': 987654}))
        table.write_bytes(write_library([{'name': 'custom_gear',
            'path_hash': path_hash(game_folder(table) + '/Materials/custom_gear.jmtl')}]))
        record = {'source': str(source), 'output': str(target), 'verify': 'pass', 'status': 'converted',
                  'problems': [], 'notes': [], 'facts': {'hide_mask': 'readable'}}
        base_record = {'source': str(source_base), 'output': str(output_base), 'verify': 'pass',
                       'status': 'converted', 'problems': [], 'facts': {}}
        report = {'source': str(src_root), 'output': str(dst_root), 'models': [base_record, record],
                  'materials': [], 'problems': [], 'warnings': []}
        fail = {'reader': False, 'change_source': False, 'change_material': False}
        def read_model(path, **kwargs):
            path = Path(path)
            if path == output_base:
                return copy.deepcopy(base_model)
            if path.parent == target.parent and path.suffix == '.mcd':
                if path != target:
                    if fail['reader']:
                        raise ValueError('controlled native stage refused')
                    if fail['change_source']:
                        source.write_bytes(b'concurrent source modification')
                    if fail['change_material']:
                        jmtl.write_bytes(b'concurrent material modification')
                model = copy.deepcopy(attire_model)
                model.substreams = [(f['tag'], f['payload']) for f in envelopes(path.read_bytes())]
                return model
            raise ValueError('unknown controlled native fixture path')
        return SimpleNamespace(root=root, src_root=src_root, dst_root=dst_root, source=source, target=target,
            source_base=source_base, output_base=output_base, source_hpl=source_hpl, body=body, cloth=cloth,
            base_model=base_model, attire_model=attire_model, table=table, jmtl=jmtl, materials=materials,
            report=report, record=record, base_record=base_record, mcd=mcd, fail=fail,
            reader=SimpleNamespace(read_model=Mock(side_effect=read_model)))

    def process(self, f):
        return masks.process(f.report, f.src_root, f.dst_root, f.reader, f.mcd)

    def files(self, root):
        return {str(p): p.read_bytes() for p in root.rglob('*') if p.is_file()}

    def parsed(self, f):
        return f.mcd.parse_hpl(mask_payload(f.target.read_bytes()))

    def test_default_enabled_and_disabled_has_no_asset_reads(self):
        self.assertTrue(masks.is_enabled()); masks.set_enabled(False)
        report = {'models': [{'source': '/unknown', 'output': '/unknown'}]}
        with patch.object(Path, 'read_bytes', side_effect=AssertionError('asset read')):
            result = masks.process(report, '/src', '/dst', None, None)
        self.assertEqual(result['state'], 'disabled_no_asset_reads_or_writes')

    def test_different_characters_use_their_own_geometry_without_profile_whitelist(self):
        for character in ('Flip', 'Never_Seen_Before', 'Other_Creator'):
            with self.subTest(character=character), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp), character=character); before = self.files(f.root)
                result = self.process(f)
                self.assertEqual(result['applied'], 1, result['rows'])
                for flags in self.parsed(f).values():
                    self.assertEqual(flags, {0: [('M_Body', [0, 12])], 1: [('M_Body', [0, 12])]})
                after = self.files(f.root)
                self.assertEqual({p: d for p, d in before.items() if p != str(f.target)},
                                 {p: d for p, d in after.items() if p != str(f.target)})
                old_other = [(e['tag'], e['payload']) for e in envelopes(before[str(f.target)]) if e['tag'] != b'HPL!']
                new_other = [(e['tag'], e['payload']) for e in envelopes(after[str(f.target)]) if e['tag'] != b'HPL!']
                self.assertEqual(old_other, new_other)

    def test_scene_flags_mask_ring_or_entrance_only_without_touching_other_author_scene(self):
        for scene, expected in ((129, 1), (130, 0)):
            with self.subTest(scene=scene), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp), scene=scene); result = self.process(f)
                self.assertEqual(result['applied'], 1, result['rows'])
                for flags in self.parsed(f).values():
                    self.assertEqual(flags[expected], [('M_Body', [0, 12])])
                    self.assertEqual(flags[1 - expected], [('M_Body', [0])])

    def test_unknown_scene_modifier_is_reported_and_preserves_mask(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp), scene=136); before = self.files(f.root); result = self.process(f)
            self.assertEqual(result['skipped'], 1); self.assertEqual(self.files(f.root), before)
            self.assertEqual(result['rows'][1]['clothing_material_checks'][0]['state'], 'unproved_scene_flag')

    def test_identical_two_scene_mesh_sets_compute_coverage_once(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp))
            with patch.object(masks, 'select_covered_vertices', wraps=masks.select_covered_vertices) as selector:
                result = self.process(f)
            self.assertEqual(result['applied'], 1); self.assertEqual(selector.call_count, 1)

    def test_repeat_is_byte_identical_and_performs_no_staging(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); self.assertEqual(self.process(f)['applied'], 1)
            before = self.files(f.root)
            with patch.object(masks, 'staged_mask', side_effect=AssertionError('rewrite')):
                repeated = self.process(f)
            self.assertEqual(repeated['already_covered'], 1); self.assertEqual(self.files(f.root), before)

    def test_empty_or_absent_core_pass_masks_generate_only_proven_body_ids(self):
        for state in ('empty', 'absent'):
            with self.subTest(state=state), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp), mask=state); result = self.process(f)
                self.assertEqual(result['applied'], 1, result['rows'])
                self.assertFalse(result['rows'][1]['mask_union']['had_authored_mask'])
                for flags in self.parsed(f).values():
                    self.assertEqual(flags, {0: [('M_Body', [12])], 1: [('M_Body', [12])]})

    def test_mask_only_failed_geometry_trial_retains_failed_verify_and_source_problem(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp), mask=b'HPL!broken original mask')
            f.record.update(verify='fail', problems=[masks._MASK_FAILURE], status='converted_with_problems')
            f.report['problems'] = ['costume.mcd: ' + masks._MASK_FAILURE]
            result = self.process(f)
            self.assertEqual(result['applied'], 1, result['rows']); self.assertEqual(f.record['verify'], 'fail')
            self.assertEqual(f.record['problems'], [masks._MASK_FAILURE])
            self.assertEqual(f.record['status'], 'converted_with_problems')
            self.assertTrue(result['rows'][1]['unknown_original_coverage_not_recovered'])
            self.assertTrue(any(masks._MASK_FAILURE in p for p in f.report['problems']))

    def test_rig_weight_duplicate_or_material_failure_cannot_be_waived_as_mask_failure(self):
        for problem in ('bone missing', 'weights invalid', 'ambiguous duplicate beard', 'missing native body JMTL'):
            with self.subTest(problem=problem), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); f.record.update(verify='fail', problems=[masks._MASK_FAILURE, problem])
                before = self.files(f.root); result = self.process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(self.files(f.root), before)

    def test_unreadable_current_mask_on_pass_record_is_preserved_by_refusal(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp), mask=b'HPL!unreadable'); before = self.files(f.root)
            result = self.process(f); self.assertEqual(result['refused'], 1); self.assertEqual(self.files(f.root), before)

    def test_readable_authored_out_of_domain_mask_is_never_replaced_under_mask_only_admission(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); bad = f.mcd.build_hpl({0: [('M_Body', [9999])]})
            f.target.write_bytes(native(1, bad)); f.record.update(verify='fail', problems=[masks._MASK_FAILURE])
            before = self.files(f.root); result = self.process(f)
            self.assertEqual(result['refused'], 1); self.assertEqual(self.files(f.root), before)

    def test_alpha_pixelmask_missing_unlinked_or_corrupt_materials_cannot_generate_mask(self):
        cases = ('alpha', 'pixelmask', 'missing', 'unlinked', 'corrupt', 'skin')
        for case in cases:
            with self.subTest(case=case), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); params = {'colorMap@ref': 123456, 'nrMap@ref': 987654}
                if case == 'alpha': f.jmtl.write_bytes(self.writer(0x15, {**params, 'variant': 2}))
                elif case == 'pixelmask': f.jmtl.write_bytes(self.writer(0x15, {**params, 'g_mPixMsk@ref': 77}))
                elif case == 'missing': f.jmtl.unlink()
                elif case == 'unlinked': f.table.write_bytes(write_library([{'name': 'custom_gear', 'path_hash': 99}]))
                elif case == 'corrupt': f.jmtl.write_bytes(b'Mate corrupted')
                else: f.jmtl.write_bytes(self.writer(0x19, params))
                before = self.files(f.root); result = self.process(f)
                self.assertEqual(result['skipped'], 1, result['rows']); self.assertEqual(self.files(f.root), before)
                self.assertEqual(result['rows'][1]['clothing_material_checks'][0]['state'], 'clothing_faces_skipped')

    def test_material_facegroups_select_only_opaque_triangle_subset(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp), full=True)
            f.cloth.face_groups = [('custom_gear', 0, 1), ('alpha_gear', 1, 1)]
            alpha = f.materials / 'alpha_gear.jmtl'
            alpha.write_bytes(self.writer(0x15, {'colorMap@ref': 3, 'nrMap@ref': 4, 'variant': 2}))
            f.table.write_bytes(write_library([{'name': role, 'path_hash': path_hash(game_folder(f.table) + '/Materials/' + role + '.jmtl')}
                                               for role in ('custom_gear', 'alpha_gear')]))
            result = self.process(f)
            if result['applied']:
                ids = result['rows'][1]['coverage']['0']['selected_remap_ids']
                self.assertLess(len(ids), 25); self.assertTrue(all(f.body.positions[i, 0] >= f.body.positions[i, 1] for i in ids))
            checks = result['rows'][1]['clothing_material_checks']
            self.assertEqual(checks[0]['state'], 'eligible_opaque_clothing_faces')
            self.assertEqual(checks[1]['state'], 'clothing_faces_skipped')

    def test_overlapping_material_faces_refuse_instead_of_guessing_ownership(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); f.cloth.face_groups.append(('another', 0, 1))
            before = self.files(f.root); result = self.process(f)
            self.assertEqual(result['refused'], 1); self.assertIn('overlap', result['rows'][1]['reason'])
            self.assertEqual(self.files(f.root), before)

    def test_body_or_face_meshes_and_material_roles_are_excluded(self):
        for case in ('mesh', 'material', 'canonical_eyelash', 'skin'):
            with self.subTest(case=case), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp))
                if case == 'mesh': f.cloth.name = 'M_Beard'
                elif case == 'canonical_eyelash': f.cloth.name = 'M_transB_eyelash'
                elif case == 'skin': f.cloth.name = 'M_Skin'
                else: f.cloth.face_groups = [('mouthbag', 0, 2)]
                before = self.files(f.root); result = self.process(f)
                self.assertEqual(result['skipped'], 1); self.assertEqual(self.files(f.root), before)

    def test_native_nonfinite_geometry_invalid_weights_bind_frames_or_duplicate_body_refuse(self):
        for case in ('position', 'weight', 'bone', 'bind', 'body'):
            with self.subTest(case=case), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp))
                if case == 'position': f.cloth.positions[0, 0] = np.nan
                elif case == 'weight': f.cloth.weights['H_Root'][0] = .2
                elif case == 'bone': f.cloth.weights = {'missing': np.ones(4)}
                elif case == 'bind': f.attire_model.bones[0].world[0, 3] = 1.
                else:
                    f.base_model.meshes.append(copy.deepcopy(f.body)); f.output_base.write_bytes(native(2))
                before = self.files(f.root); result = self.process(f)
                self.assertEqual(result['refused'], 1, result['rows']); self.assertEqual(self.files(f.root), before)

    def test_noncloned_geometry_lods_refuse_without_header_retag_or_rewrite(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); raw = bytearray(f.target.read_bytes())
            found = raw.find(b'controlled native geometry segment'); second = raw.find(b'controlled native geometry segment', found + 1)
            raw[second] ^= 1; f.target.write_bytes(raw); before = self.files(f.root); result = self.process(f)
            self.assertEqual(result['refused'], 1); self.assertIn('byte-identical', result['rows'][1]['reason'])
            self.assertEqual(self.files(f.root), before)

    def test_duplicate_output_claims_both_refuse_before_any_write(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); f.report['models'].append(copy.deepcopy(f.record))
            before = self.files(f.root); result = self.process(f)
            self.assertEqual(result['refused'], 2); self.assertEqual(self.files(f.root), before)

    def test_mismatched_character_base_and_overlapping_roots_refuse(self):
        for case in ('pair', 'roots'):
            with self.subTest(case=case), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp))
                if case == 'pair': f.base_record['source'] = str(f.source.parent / 'BaseModel' / 'baseModel.mcd')
                else: f.report['output'] = str(f.src_root)
                before = self.files(f.root); result = self.process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(self.files(f.root), before)

    def test_symlink_material_is_skipped_and_symlink_source_model_refused(self):
        for case in ('material', 'source'):
            with self.subTest(case=case), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); path = f.jmtl if case == 'material' else f.source
                other = path.with_name(path.name + '.original'); path.rename(other); path.symlink_to(other.name)
                old = f.target.read_bytes(); result = self.process(f)
                self.assertEqual(result['skipped' if case == 'material' else 'refused'], 1)
                self.assertEqual(f.target.read_bytes(), old)

    def test_invalid_report_metadata_refuses_before_atomic_commit(self):
        for field in ('warnings', 'physics', 'nested', 'nonfinite'):
            with self.subTest(field=field), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp))
                if field == 'warnings': f.report['warnings'] = None
                elif field == 'physics': f.report['physics_binding_audit'] = {'rows': [{'paired_models': None}]}
                elif field == 'nested': f.record['facts']['supplied_hide_mask_recovery'] = []
                else: f.record['facts']['invalid'] = float('nan')
                before = self.files(f.root); result = self.process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(self.files(f.root), before)

    def test_stage_reader_or_concurrent_source_material_change_preserves_target_and_cleans_stage(self):
        for field in ('reader', 'change_source', 'change_material'):
            with self.subTest(field=field), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); f.fail[field] = True; old = f.target.read_bytes(); result = self.process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(result['failed_after_write'], 0)
                self.assertEqual(f.target.read_bytes(), old); self.assertFalse(list(f.target.parent.glob('.native-mask-*')))

    def test_current_hashes_and_historical_authored_recovery_remain_truthful(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); old = f.target.read_bytes(); old_sha = hashlib.sha256(old).hexdigest()
            recovery = {'written_hpl_sha256': hashlib.sha256(mask_payload(old)).hexdigest(), 'coverage_generated': False}
            f.record['supplied_hide_mask_recovery'] = copy.deepcopy(recovery)
            f.record['facts']['supplied_hide_mask_recovery'] = copy.deepcopy(recovery)
            f.record['face_output_audit'] = {'output_sha256': old_sha}
            f.record['native_missing_data_audit'] = {'masks': {'counts': 'historical mask counts'}}
            pair = {'path': str(f.target), 'sha256': old_sha, 'bytes': len(old), 'side': 'output'}
            f.report['physics_binding_audit'] = {'rows': [{'paired_models': [pair]}]}
            result = self.process(f); current_sha = hashlib.sha256(f.target.read_bytes()).hexdigest()
            self.assertEqual(result['applied'], 1); self.assertEqual(f.record['facts']['output_sha256'], current_sha)
            self.assertEqual(f.record['face_output_audit']['output_sha256'], current_sha); self.assertEqual(pair['sha256'], current_sha)
            self.assertEqual(f.record['supplied_hide_mask_recovery']['written_hpl_sha256'], recovery['written_hpl_sha256'])
            self.assertFalse(f.record['supplied_hide_mask_recovery']['coverage_generated'])
            self.assertIn('historical', f.record['supplied_hide_mask_recovery']['output_byte_proof_stage'])
            self.assertEqual(f.record['verify'], 'pass'); self.assertEqual(f.report['conversion_completeness'], 'incomplete')

    def test_nonuniform_authored_lods_extra_scene_flags_and_nonbody_records_are_preserved(self):
        from test_mask_lods import PerLODMaskTests
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); other = copy.deepcopy(f.body); other.name = 'M_Custom'
            f.base_model.meshes.append(other); f.output_base.write_bytes(native(2))
            helper = PerLODMaskTests(); helper.mcd = f.mcd
            authored = helper.different_lods([{0: [('M_Custom', [2, 3]), ('M_Body', [lod])],
                1: [('M_Body', [1])], 7: [('M_Custom', [4, lod])]} for lod in range(5)])
            f.target.write_bytes(native(1, authored)); original = f.mcd.parse_hpl(authored)
            result = self.process(f); self.assertEqual(result['applied'], 1, result['rows'])
            self.assertTrue(result['rows'][1]['mask_union']['nonuniform_authored_lods_preserved'])
            for lod, flags in self.parsed(f).items():
                self.assertEqual(flags[0], [('M_Custom', [2, 3]), ('M_Body', [lod, 12])])
                self.assertEqual(flags[1], [('M_Body', [1, 12])]); self.assertEqual(flags[7], original[lod][7])

    def test_render_alias_to_uncovered_skin_blocks_generated_logical_id(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); f.body.vertex_remap[0] = f.body.vertex_remap[12]
            before = self.files(f.root); result = self.process(f)
            self.assertEqual(result['skipped'], 1); self.assertEqual(self.files(f.root), before)
            evidence = result['rows'][1]['coverage']['0']['evidence']
            self.assertEqual(evidence['eligible_vertices_excluded_by_alias'], 1)

    def test_changed_body_geometry_and_scale_choose_its_actual_remap_ids(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); f.body.positions *= 12.; f.cloth.positions *= 12.
            f.body.vertex_remap = np.roll(np.arange(25, dtype=np.uint32), 3)
            result = self.process(f); self.assertEqual(result['applied'], 1, result['rows'])
            generated = int(f.body.vertex_remap[12])
            for flags in self.parsed(f).values():
                self.assertEqual(flags[0], [('M_Body', [0, generated])])

    def test_case_duplicate_material_paths_and_table_names_skip_without_crossbinding(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); f.jmtl.with_name('CUSTOM_GEAR.jmtl').write_bytes(f.jmtl.read_bytes())
            before = self.files(f.root); result = self.process(f)
            self.assertEqual(result['skipped'], 1); self.assertEqual(self.files(f.root), before)
            self.assertIn('ambiguous', result['rows'][1]['clothing_material_checks'][0]['reason'])

    def test_native_scalar_overlap_and_unknown_present_material_fields_are_not_opaque_proofs(self):
        from gmf_jmtl_audit import Table
        for case in ('overlap', 'unknown'):
            with self.subTest(case=case), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); raw = bytearray(f.jmtl.read_bytes())
                root = Table(raw, struct.unpack_from('<I', raw)[0]); payload = root.child(2)
                vtable = payload.position - struct.unpack_from('<i', raw, payload.position)[0]
                if case == 'overlap':
                    struct.pack_into('<H', raw, vtable + 4 + 12 * 2, payload.offsets[9])
                else:
                    struct.pack_into('<H', raw, vtable + 4 + 1 * 2, payload.offsets[9])
                f.jmtl.write_bytes(raw); before = self.files(f.root); result = self.process(f)
                self.assertEqual(result['skipped'], 1); self.assertEqual(self.files(f.root), before)
                self.assertIn('overlap' if case == 'overlap' else 'unknown', result['rows'][1]['clothing_material_checks'][0]['reason'])

    def test_conflicting_separate_output_mask_is_preserved_by_refusal(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); f.target.with_suffix('.hpl').write_bytes(mask_payload(f.target.read_bytes()))
            before = self.files(f.root); result = self.process(f)
            self.assertEqual(result['refused'], 1); self.assertEqual(self.files(f.root), before)

    def test_postcommit_unexpected_reporting_failure_is_not_misreported_as_no_write(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); old = f.target.read_bytes(); original = masks._update
            calls = []
            def update(*args, **kwargs):
                calls.append(1)
                if len(calls) == 2:
                    raise RuntimeError('unexpected final report failure')
                return original(*args, **kwargs)
            with patch.object(masks, '_update', side_effect=update):
                result = self.process(f)
            self.assertEqual(result['failed_after_write'], 1); self.assertEqual(result['refused'], 0)
            self.assertNotEqual(f.target.read_bytes(), old)
            self.assertEqual(result['rows'][1]['state'], 'applied_with_verification_or_reporting_error')

    def test_install_is_idempotent_and_persists_complete_postmask_report(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp))
            def convert_folder(src, dst, log=lambda text: None):
                return f.report
            folder = SimpleNamespace(convert_folder=convert_folder, vc=f.reader, mcd=f.mcd)
            masks.install(folder); wrapped = folder.convert_folder; masks.install(folder)
            self.assertIs(folder.convert_folder, wrapped)
            with patch('gmf_report.save_intermediate') as save:
                report = folder.convert_folder(f.src_root, f.dst_root)
            self.assertIs(report, f.report); self.assertEqual(report['clothing_mask_coverage']['applied'], 1)
            save.assert_called_once_with(f.report, f.dst_root)

    def test_all_existing_recovery_kinds_and_native_byte_preservation_scope_become_historical(self):
        for key in masks._RECOVERIES:
            with self.subTest(key=key), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); old_mask_sha = hashlib.sha256(mask_payload(f.target.read_bytes())).hexdigest()
                prior = {'written_hpl_sha256': old_mask_sha, 'coverage_generated': False, 'restoration': 'authored data'}
                f.record[key] = copy.deepcopy(prior); f.record['facts'][key] = copy.deepcopy(prior)
                f.record['verification_scope'] = 'native_reader_and_byte_preservation'
                result = self.process(f); self.assertEqual(result['applied'], 1)
                self.assertEqual(f.record['verification_scope_before_clothing_mask_coverage'], 'native_reader_and_byte_preservation')
                self.assertIn('non-HPL', f.record['verification_scope'])
                for record in (f.record[key], f.record['facts'][key]):
                    self.assertEqual(record['written_hpl_sha256'], old_mask_sha)
                    self.assertFalse(record['coverage_generated']); self.assertIn('historical', record['output_byte_proof_stage'])
                    self.assertEqual(record['following_clothing_mask_coverage']['after_mcd_sha256'], hashlib.sha256(f.target.read_bytes()).hexdigest())

    def test_contradictory_duplicate_recovery_metadata_refuses_before_write(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); f.record['hide_mask_recovery'] = {'written_hpl_sha256': 'one'}
            f.record['facts']['hide_mask_recovery'] = {'written_hpl_sha256': 'another'}
            before = self.files(f.root); result = self.process(f)
            self.assertEqual(result['refused'], 1); self.assertEqual(self.files(f.root), before)

    def test_finite_authored_gear_uv_scroll_does_not_change_opaque_variant(self):
        from gmf_jmtl_audit import Table
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); data = self.writer(0x15,
                {'colorMap@ref': 123456, 'nrMap@ref': 987654, 'PbrUvScroll': [.25, .5]})
            child = Table(data, struct.unpack_from('<I', data)[0]).child(2).child(14)
            self.assertAlmostEqual(child.number(0, '<f', 0), .25)
            self.assertAlmostEqual(child.number(1, '<f', 0), .5)
            f.jmtl.write_bytes(data); result = self.process(f)
            self.assertEqual(result['applied'], 1, result['rows']); self.assertEqual(f.jmtl.read_bytes(), data)

    def add_child_joint(self, f, name='J_Eye_L', delta=2.):
        base_bone = SimpleNamespace(name=name, parent='H_Root', world=np.eye(4))
        attire_bone = copy.deepcopy(base_bone); attire_bone.world[0, 3] = delta
        f.base_model.bones.append(base_bone); f.attire_model.bones.append(attire_bone)

    def test_unused_facial_joint_changes_allow_static_mask_with_explicit_animation_limit(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); self.add_child_joint(f)
            result = self.process(f); self.assertEqual(result['applied'], 1, result['rows'])
            proof = result['rows'][1]['bind_frame_verification']
            self.assertEqual(proof['matched_root_names'], ['H_Root'])
            self.assertEqual(proof['unused_shared_child_bind_mismatch_count'], 1)
            self.assertEqual(proof['unused_shared_child_bind_mismatches'][0]['name'], 'J_Eye_L')
            self.assertEqual(proof['unused_shared_child_bind_mismatches'][0]['maximum_world_delta'], 2.)
            self.assertFalse(proof['unused_shared_child_bind_mismatches'][0]['body_positive_weight_joint'])
            self.assertFalse(proof['unused_shared_child_bind_mismatches'][0]['eligible_clothing_positive_weight_joint'])
            self.assertIn('not established', proof['animation_and_deformation_equivalence'])

    def test_positive_body_or_opaque_clothing_weighted_child_matrix_difference_still_refuses(self):
        for target in ('body', 'clothing'):
            with self.subTest(target=target), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); self.add_child_joint(f, 'J_Arm', 1.)
                mesh = f.body if target == 'body' else f.cloth
                mesh.weights = {'J_Arm': np.ones(mesh.num_verts)}
                before = self.files(f.root); result = self.process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(self.files(f.root), before)
                self.assertIn('positive-weight', result['rows'][1]['reason']); self.assertIn('J_Arm', result['rows'][1]['reason'])

    def test_missing_crosspair_weighted_joint_refuses_even_when_both_models_own_weights_are_valid(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); self.add_child_joint(f, 'J_Arm', 0.)
            f.base_model.bones = [b for b in f.base_model.bones if b.name != 'J_Arm']
            f.cloth.weights = {'J_Arm': np.ones(f.cloth.num_verts)}
            before = self.files(f.root); result = self.process(f)
            self.assertEqual(result['refused'], 1); self.assertEqual(self.files(f.root), before)
            self.assertIn('missing from the paired rig', result['rows'][1]['reason'])

    def test_mismatching_joint_used_only_by_excluded_beard_does_not_bind_the_clothing_frame(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp)); self.add_child_joint(f, 'J_Hair', 1.)
            beard = copy.deepcopy(f.cloth); beard.name = 'M_Beard'; beard.weights = {'J_Hair': np.ones(beard.num_verts)}
            f.attire_model.meshes.append(beard); f.target.write_bytes(native(2, mask_payload(f.target.read_bytes())))
            result = self.process(f); self.assertEqual(result['applied'], 1, result['rows'])
            proof = result['rows'][1]['bind_frame_verification']
            self.assertEqual(proof['eligible_clothing_positive_weight_joints'], ['H_Root'])
            self.assertEqual(proof['unused_shared_child_bind_mismatches'][0]['name'], 'J_Hair')

    def test_vertices_exclusive_to_alpha_faces_do_not_bind_eligible_opaque_triangle_frame(self):
        with tempfile.TemporaryDirectory() as temp:
            f = self.fixture(Path(temp), full=True); self.add_child_joint(f, 'J_Face', 2.)
            f.cloth.face_groups = [('custom_gear', 0, 1), ('alpha_gear', 1, 1)]
            f.cloth.weights = {'H_Root': np.asarray([1., 1., 1., 0.]), 'J_Face': np.asarray([0., 0., 0., 1.])}
            (f.materials / 'alpha_gear.jmtl').write_bytes(self.writer(0x15,
                {'colorMap@ref': 3, 'nrMap@ref': 4, 'variant': 2}))
            f.table.write_bytes(write_library([{'name': role, 'path_hash': path_hash(game_folder(f.table) + '/Materials/' + role + '.jmtl')}
                                               for role in ('custom_gear', 'alpha_gear')]))
            result = self.process(f); self.assertEqual(result['applied'], 1, result['rows'])
            self.assertEqual(result['rows'][1]['bind_frame_verification']['eligible_clothing_positive_weight_joints'], ['H_Root'])

    def test_global_root_frame_change_or_root_parent_disagreement_still_hard_refuses(self):
        for case in ('global_translation', 'root_parent'):
            with self.subTest(case=case), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp))
                if case == 'global_translation': f.attire_model.bones[0].world[1, 3] = .01
                else:
                    self.add_child_joint(f, 'OtherRoot', 0.)
                    f.base_model.bones[-1].parent = None; f.attire_model.bones[0].parent = 'OtherRoot'
                    f.attire_model.bones[-1].parent = None
                before = self.files(f.root); result = self.process(f)
                self.assertEqual(result['refused'], 1); self.assertEqual(self.files(f.root), before)
                self.assertIn('root/global', result['rows'][1]['reason'])

    def test_no_eligible_faces_skip_before_crosspair_weighted_frame_trial(self):
        for case in ('unknown_scene', 'alpha'):
            with self.subTest(case=case), tempfile.TemporaryDirectory() as temp:
                f = self.fixture(Path(temp)); self.add_child_joint(f, 'J_Arm', 2.)
                f.body.weights = {'J_Arm': np.ones(f.body.num_verts)}
                if case == 'unknown_scene': f.cloth.scene_flag = 136
                else: f.jmtl.write_bytes(self.writer(0x15, {'colorMap@ref': 123456, 'nrMap@ref': 987654, 'variant': 2}))
                before = self.files(f.root); result = self.process(f)
                self.assertEqual(result['skipped'], 1); self.assertEqual(result['refused'], 0)
                self.assertNotIn('bind_frame_verification', result['rows'][1]); self.assertEqual(self.files(f.root), before)


if __name__ == '__main__':
    unittest.main()
