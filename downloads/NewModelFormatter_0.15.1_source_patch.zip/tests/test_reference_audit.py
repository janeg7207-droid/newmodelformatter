import copy
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import gmf_reference_audit as audit


def model(weights, bones=None):
    return types.SimpleNamespace(bones=[types.SimpleNamespace(name=n) for n in (bones or ['J_Chest','J_Head'])],
        meshes=[types.SimpleNamespace(name='M_Tops',num_verts=len(next(iter(weights.values()),[])),weights=weights)])


class ReferenceAuditTests(unittest.TestCase):
    def test_valid_weights_do_not_change_input(self):
        mesh=model({'J_Chest':[1.,.5],'J_Head':[0.,.5]});before=copy.deepcopy(mesh)
        result=audit.audit_model(mesh)
        self.assertEqual(result['suspicious_vertices'],0)
        self.assertEqual(mesh.meshes[0].weights,before.meshes[0].weights)
        self.assertEqual(mesh.meshes[0].name,before.meshes[0].name)

    def test_invalid_negative_nan_and_infinite_are_not_ignored(self):
        result=audit.audit_model(model({'J_Head':[-.5,float('nan'),float('inf')],'J_Chest':[1.,1.,1.]}))
        self.assertEqual(result['meshes'][0]['counts']['invalid'],3)
        self.assertEqual(result['suspicious_vertices'],3)

    def test_driver_and_absent_deform_targets_expose_unweighted_vertices(self):
        result=audit.audit_model(model({'J_Cam':[1.,0.],'J_Missing':[0.,1.]},['J_Chest','J_Cam']))
        counts=result['meshes'][0]['counts']
        self.assertEqual(counts['driver'],1);self.assertEqual(counts['missing_bone'],1)
        self.assertEqual(counts['unweighted'],2)
        self.assertEqual(result['meshes'][0]['positive_weight_groups_absent_from_rig'],['J_Missing'])

    def test_unknown_non_j_positive_groups_report_without_mapping_guess(self):
        result=audit.audit_model(model({'unknown':[1.],'J_Chest':[0.]}))
        self.assertEqual(result['meshes'][0]['positive_weight_groups_absent_from_rig'],['unknown'])
        self.assertEqual(result['meshes'][0]['counts']['unweighted'],1)

    def test_normalization_and_over_eight_are_separate_checks(self):
        bones=['J_'+str(i) for i in range(9)]
        result=audit.audit_model(model({n:[1/9,.2] for n in bones},bones))
        counts=result['meshes'][0]['counts']
        self.assertEqual(counts['excessive'],2);self.assertEqual(counts['nonunit'],1)
        self.assertEqual(counts['unweighted'],0)

    def test_zero_missing_group_is_not_positive_missing_target(self):
        result=audit.audit_model(model({'J_Chest':[1.],'J_Missing':[0.]}))
        self.assertEqual(result['suspicious_vertices'],0)
        self.assertEqual(result['meshes'][0]['positive_weight_groups_absent_from_rig'],[])

    def test_wrong_weight_domain_rejects_without_changing_mesh(self):
        mesh=model({'J_Chest':[1.,1.],'J_Head':[1.]})
        with self.assertRaisesRegex(ValueError,'length differs'):audit.audit_model(mesh)
        self.assertEqual(mesh.meshes[0].weights['J_Head'],[1.])

    def test_folder_hook_adds_report_without_rewriting_model_and_retains_arguments(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);src=root/'source';src.mkdir();dst=root/'out';dst.mkdir()
            output=dst/'model.mcd';output.write_bytes(b'native payload must remain unchanged')
            def convert_folder(src,dst,log=print,copy_other=True,slot=None):
                self.assertFalse(copy_other);self.assertIsNone(slot)
                return {'source':src,'models':[{'output':str(output)}],'problems':[]}
            module=types.SimpleNamespace(convert_folder=convert_folder,vc=types.SimpleNamespace(read_model=lambda p:model({'J_Missing':[1.]})))
            audit.install(module);hook=module.convert_folder;audit.install(module)
            self.assertIs(module.convert_folder,hook)
            result=module.convert_folder(str(src),str(dst),copy_other=False,slot=None)
            self.assertEqual(output.read_bytes(),b'native payload must remain unchanged')
            self.assertEqual(result['conversion_completeness'],'incomplete')
            saved=json.loads((dst/'source - conversion report.json').read_text())
            self.assertEqual(saved['models'][0]['reference_weight_audit']['suspicious_vertices'],1)
            self.assertFalse(saved['reference_source_integration']['full_reference_engine_rebuilt'])

    def test_reader_failure_keeps_original_conversion_and_reports_unrun_audit(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);output=root/'out.mcd';output.write_bytes(b'unchanged')
            def convert_folder(src,dst,log=print,copy_other=True,slot=None):
                return {'source':src,'models':[{'output':str(output)}],'problems':['original failure']}
            def failed_reader(path):raise ValueError('native read failed')
            module=types.SimpleNamespace(convert_folder=convert_folder,vc=types.SimpleNamespace(read_model=failed_reader))
            audit.install(module);result=module.convert_folder(str(root/'source'),str(root))
            self.assertEqual(result['problems'],['original failure'])
            self.assertEqual(result['models'][0]['reference_weight_audit']['status'],'not_audited')
            self.assertEqual(output.read_bytes(),b'unchanged')
