"""Split large attachments into <=30 MiB parts, preserving the originals."""
import argparse
import hashlib
import json
from pathlib import Path


def split(path, destination):
    path = Path(path).resolve()
    # A new per-file folder prevents accidental overwrites on repeated runs.
    folder = Path(destination) / (path.name + '.parts')
    folder.mkdir(parents=True, exist_ok=False)
    digest = hashlib.sha256()
    parts = []
    with path.open('rb') as stream:
        index = 1
        while block := stream.read(30 * 1024 * 1024):
            digest.update(block)
            name = f'{path.name}.part{index:04d}'
            with (folder/name).open('xb') as output:
                output.write(block)
            parts.append({'name': name, 'bytes': len(block),
                          'sha256': hashlib.sha256(block).hexdigest()})
            index += 1
    manifest = {'name': path.name, 'sha256': digest.hexdigest(), 'parts': parts}
    (folder/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    return folder


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('files', nargs='+')
    parser.add_argument('--output', default='upload-parts')
    args = parser.parse_args()
    for file in args.files:
        print('Upload every part and manifest from:', split(file, args.output))
