"""Preserve finite legacy per-character teeth irradiance for the native writer.

Gorilla replaces even explicitly authored source RGB with a fixed tuple whose
red value is zero. The reference writer accepts per-character components. This
adapter retains only supplied values in the existing normalized range; shader,
texture references and geometry are unaffected. Game appearance is unverified.
"""
import math


def preserve_source_irradiance(material, result):
    shader, parameters, used, note = result
    if shader != 0x1a:
        return result
    source = material.params
    restored = {}
    for key in ('irradianceR', 'irradianceG', 'irradianceB'):
        value = source.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            continue
        value = float(value)
        if math.isfinite(value) and 0.0 <= value <= 1.0 and parameters.get(key) != value:
            restored[key] = value
    if not restored:
        return result
    parameters = dict(parameters)
    parameters.update(restored)
    detail = 'preserved explicit source teeth irradiance (' + ', '.join(restored) + '); in-game shading unverified'
    return shader, parameters, used, (str(note) + '; ' + detail if note else detail)
