"""Pair attire meshes by identity inside Gorilla's unchanged verifier.

Integration has two phases, because the gear verifier clones raw globals:
``prepare(convert)`` AFTER patch_mask_checks and BEFORE gear/partial wrappers,
then ``install(convert)``
AFTER gear/partial and BEFORE mask wrappers. The original verifier code and
its geometry generator are unchanged. Only that generator's ``next`` call
uses the selector; ordinary next calls retain Python's normal semantics.

Scope is explicit *Attire* filenames. Base rename/overlay rules are untouched.
Source weights never determine pairing. Identical output duplicates qualify
only when every verifier-observed field, including their output weight tables,
is exactly equal; any permutation then has the same verification outcome.
Missing, ambiguous, reused or excess duplicate targets fail. The original rig,
material, geometry, flag, weight and mask checks run unchanged.
"""
import builtins
import functools
import hashlib
import inspect
import json
import os
import threading
import types

import numpy as np

PATCH_VERSION = 'identity-and-equivalent-duplicates-attire-original-verifier-2'
# Canonical fingerprint includes all bytecode, constants, nested code,
# exception tables and source-loop metadata, not only the matching expression.
RAW_VERIFY_DIGEST = 'b4f3478bea18a4e6e1d5cacfa9cd6f168f7ac9ad756506ebec7a0e61f45b2efd'
BASE_CLASSIFIER_DIGEST = '15373e7dcee965b2d3b4d369b382dcbfd3a081efee0aa24ace8fec8fd435888c'
_context = threading.local()


def _code_digest(code):
    def value(item):
        if isinstance(item, types.CodeType):
            return ['code', item.co_name, item.co_filename, item.co_firstlineno,
                item.co_argcount, item.co_posonlyargcount, item.co_kwonlyargcount,
                item.co_flags, item.co_code.hex(), item.co_exceptiontable.hex(),
                item.co_linetable.hex(), item.co_names, item.co_varnames,
                item.co_freevars, item.co_cellvars, [value(v) for v in item.co_consts]]
        if isinstance(item, tuple):return ['tuple', [value(v) for v in item]]
        if isinstance(item, bytes):return ['bytes', item.hex()]
        if isinstance(item, slice):return ['slice', value(item.start), value(item.stop), value(item.step)]
        if item is None or isinstance(item, (str, int, float, bool)):
            return [type(item).__name__, item]
        raise ValueError('unrecognized original code constant')
    return hashlib.sha256(json.dumps(value(code), separators=(',', ':'),
        ensure_ascii=True).encode('ascii')).hexdigest()


def _equal_array(left, right, tolerance=0.):
    a=np.asarray(left);b=np.asarray(right)
    if a.shape!=b.shape:return False
    if not np.isfinite(a).all() or not np.isfinite(b).all():return False
    return bool(np.array_equal(a,b) if not tolerance else np.allclose(a,b,atol=tolerance,rtol=0))


def _remap(mesh):
    return np.arange(mesh.num_verts) if mesh.vertex_remap is None else mesh.vertex_remap


def _stable_identity(source, target):
    """Disambiguate same-name records without reading either weight table."""
    if (source.scene_flag,source.motion_flag)!=(target.scene_flag,target.motion_flag):return False
    if [tuple(g) for g in source.face_groups]!=[tuple(g) for g in target.face_groups]:return False
    if not _equal_array(_remap(source),_remap(target)):return False
    a=np.asarray(source.triangles);b=np.asarray(target.triangles)
    if a.shape!=b.shape:return False
    if not _equal_array(a[np.lexsort(a.T[::-1])],b[np.lexsort(b.T[::-1])]):return False
    if len(source.uvs)!=len(target.uvs):return False
    # Same tolerance as the original UV verifier, solely as a tie breaker.
    if any(not _equal_array(a,b,.0001) for a,b in zip(source.uvs,target.uvs)):return False
    # Shape names/order/size identify records without choosing on moved deltas.
    if [(s[0],len(s[1])) for s in source.shapes]!=[(s[0],len(s[1])) for s in target.shapes]:return False
    return True


def _exact_value(left, right):
    """Exact finite native values; preserve sequence/dict order and dtypes.

    This compares output candidates with each other, never source weights.
    Identical dictionary iteration order also preserves the original verifier's
    floating-point influence sums. Unknown objects do not establish equivalence.
    """
    if isinstance(left,np.ndarray) or isinstance(right,np.ndarray):
        if not isinstance(left,np.ndarray) or not isinstance(right,np.ndarray):return False
        return left.dtype==right.dtype and _equal_array(left,right)
    if isinstance(left,np.generic) or isinstance(right,np.generic):
        if type(left) is not type(right):return False
        return bool(np.isfinite(left) and np.isfinite(right) and left==right)
    if isinstance(left,dict) or isinstance(right,dict):
        if not isinstance(left,dict) or not isinstance(right,dict):return False
        return list(left)==list(right) and all(_exact_value(left[k],right[k]) for k in left)
    if isinstance(left,(tuple,list)) or isinstance(right,(tuple,list)):
        if type(left) is not type(right) or len(left)!=len(right):return False
        return all(_exact_value(a,b) for a,b in zip(left,right))
    if left is None or right is None:return left is right
    if type(left) is not type(right) or not isinstance(left,(str,int,float,bool)):return False
    if isinstance(left,float) and (not np.isfinite(left) or not np.isfinite(right)):return False
    return left==right


def _permutation_equivalent(left, right):
    """Equal all fields read by the fingerprinted raw verifier for attire.

    Choosing between these outputs cannot hide a wrong flag, shape or weight:
    the unchanged verifier sees exactly the same candidate data either way.
    Native source/output preservation is still checked by that verifier.
    """
    fields=('name','num_verts','positions','triangles','vertex_remap',
        'scene_flag','motion_flag','face_groups','normals','tangents',
        'uvs','colors','shapes','weights')
    return all(_exact_value(getattr(left,name),getattr(right,name)) for name in fields)


class Selection:
    """One call's ordered source records and one-to-one target consumption."""
    def __init__(self, meshes):
        self.meshes=list(meshes);self.ordinal=0;self.consumed=set()
        self.observed={};self.equivalence_proofs=0
        self.problems=[];self.records=[]
        if not self.meshes:raise ValueError('empty attire source mesh list')
        for mesh in self.meshes:
            if not isinstance(mesh.name,str) or not mesh.name or mesh.num_verts<=0:
                raise ValueError('invalid attire source mesh identity')
            if np.asarray(mesh.positions).shape!=(mesh.num_verts,3):
                raise ValueError('invalid attire source position metadata: '+mesh.name)
            if not np.isfinite(mesh.positions).all():
                raise ValueError('non-finite attire source positions: '+mesh.name)
            if not _stable_identity(mesh,mesh):
                raise ValueError('inconsistent or non-finite attire source identity metadata: '+mesh.name)

    def choose(self, candidates):
        if self.ordinal>=len(self.meshes):
            self.problems.append('attire matcher has more calls than source records')
            return None
        index=self.ordinal;source=self.meshes[index];self.ordinal+=1
        # These are ONLY candidates emitted by the unchanged native geometry
        # generator. Cross-check the snapshot before using its ordinal identity.
        for target in candidates:
            if target.num_verts!=source.num_verts or len(target.triangles)!=len(source.triangles) or \
                    not _equal_array(source.positions,target.positions,.05):
                self.problems.append('attire source-loop identity differs: '+source.name)
                return None
            self.observed[id(target)]=target
        available=[m for m in candidates if id(m) not in self.consumed]
        exact=[m for m in available if m.name==source.name]
        choice=None;rule=None;exact_positions_count=None;equivalent_count=0
        if len(exact)==1:choice=exact[0];rule='unique_expected_name'
        elif len(exact)>1:
            identified=[m for m in exact if _stable_identity(source,m)]
            if len(identified)==1:choice=identified[0];rule='same_name_stable_identity'
            elif len(identified)>1:
                # The original candidate generator tolerates small positional
                # differences. Exact untouched positions can distinguish
                # authored records without looking at translated weights.
                same_positions=[m for m in identified if _equal_array(source.positions,m.positions)]
                exact_positions_count=len(same_positions)
                if len(same_positions)==1:
                    choice=same_positions[0];rule='same_name_exact_positions'
                else:
                    equivalent=same_positions or identified
                    if all(_permutation_equivalent(equivalent[0],m) for m in equivalent[1:]):
                        choice=equivalent[0];rule='permutation_equivalent_duplicate'
                        equivalent_count=len(equivalent);self.equivalence_proofs+=1
                    else:self.problems.append('ambiguous same-name attire mesh: '+source.name)
            else:self.problems.append('ambiguous same-name attire mesh: '+source.name)
        elif len(available)==1:
            # Preserve the original concrete name-error diagnosis. An unrelated
            # alias is never accepted: the unchanged verifier checks the name.
            choice=available[0];rule='unique_geometry_name_mismatch'
        elif available:self.problems.append('ambiguous attire mesh without expected name: '+source.name)
        elif candidates:self.problems.append('attire output mesh would be reused: '+source.name)
        if choice is not None:self.consumed.add(id(choice))
        self.records.append({'source_index':index,'source_name':source.name,
            'geometry_candidates':len(candidates),'selected_name':None if choice is None else choice.name,
            'selection_rule':rule,'exact_position_candidates':exact_positions_count,
            'permutation_equivalent_output_candidates':equivalent_count})
        return choice

    def audit(self):
        if self.ordinal!=len(self.meshes):
            self.problems.append('attire matcher source-loop call count differs: %d/%d' %
                (self.ordinal,len(self.meshes)))
        # The original attire route has one written record per source record.
        # Never accept extra same-name duplicates by consuming only a subset.
        source_counts={name:sum(m.name==name for m in self.meshes) for name in {m.name for m in self.meshes}}
        for name,expected in source_counts.items():
            observed=[m for m in self.observed.values() if m.name==name]
            if len(observed)>expected:
                self.problems.append('excess same-name attire output records: %s (%d -> %d)' %
                    (name,expected,len(observed)))
        return {'patch':PATCH_VERSION,'scope':'explicit attire filename; original geometry candidates',
            'source_records':len(self.meshes),'matching_calls':self.ordinal,
            'consumed_output_records':len(self.consumed),'weights_used_for_selection':False,
            'source_weights_used_for_pairing':False,
            'equivalent_duplicate_proofs':self.equivalence_proofs,
            'output_weights_compared_only_for_permutation_equivalence':bool(self.equivalence_proofs),
            'records':self.records,'problems':list(self.problems)}


def prepare(convert):
    """Clone raw verify after mask-check updates, before gear captures globals."""
    if getattr(convert,'_mesh_matching_prepared',None)==PATCH_VERSION:return
    original=convert.verify
    if not isinstance(original,types.FunctionType) or _code_digest(original.__code__)!=RAW_VERIFY_DIGEST:
        raise ValueError('attire matcher requires the exact reviewed original raw verifier')
    classifier=original.__globals__.get('is_base_file')
    if not isinstance(classifier,types.FunctionType) or _code_digest(classifier.__code__)!=BASE_CLASSIFIER_DIGEST:
        raise ValueError('attire matcher requires the exact reviewed base classifier')
    generators=[c for c in original.__code__.co_consts if isinstance(c,types.CodeType)
        and c.co_name=='<genexpr>' and c.co_firstlineno==514 and c.co_freevars==('m',)]
    if len(generators)!=1:raise ValueError('original attire matcher generator is not unique')
    matcher=generators[0];token=object()
    def matching_next(iterator,*default):
        if len(default)>1:return builtins.next(iterator,*default)
        stack=getattr(_context,'stack',())
        current=stack[-1] if stack else None
        if getattr(iterator,'gi_code',None) is not matcher or current is None or current[0] is not token:
            return builtins.next(iterator,*default)
        try:selected=current[1].choose(list(iterator))
        except (ValueError,TypeError,AttributeError,IndexError) as error:
            current[1].problems.append('attire matcher cannot resolve record identity: '+str(error))
            selected=None
        if selected is None:
            if default:return default[0]
            raise StopIteration
        return selected
    namespace=dict(original.__globals__);namespace['next']=matching_next
    cloned=types.FunctionType(original.__code__,namespace,original.__name__,
        original.__defaults__,original.__closure__)
    functools.update_wrapper(cloned,original)
    cloned.__kwdefaults__=original.__kwdefaults__
    convert.verify=cloned
    convert._mesh_matching_token=token
    convert._mesh_matching_prepared=PATCH_VERSION


def install(convert):
    """Add outer call context after gear/partial, before all mask wrappers."""
    if getattr(convert,'_mesh_matching_installed',None)==PATCH_VERSION:return
    if getattr(convert,'_mesh_matching_prepared',None)!=PATCH_VERSION:
        raise ValueError('prepare raw attire matcher before installing verifier wrappers')
    original=convert.verify;token=convert._mesh_matching_token;vc=convert.vc
    @functools.wraps(original)
    def verify(*args,**kwargs):
        bound=inspect.signature(original).bind(*args,**kwargs)
        src=bound.arguments['src_path']
        name=os.path.basename(os.fspath(src)).lower()
        # For this filename the exact original is_base_file is false for BOTH
        # source and output names. Thus there are no skipped overlay records,
        # no misnamed-body remaps and one matching call per source mesh.
        eligible='attire' in name and 'basemodel' not in name
        state=None;failure=None
        if eligible:
            try:state=Selection(vc.read_model(src).meshes)
            except (ValueError,TypeError,AttributeError,IndexError) as error:
                failure='attire matcher cannot establish source identity: '+str(error)
        stack=getattr(_context,'stack',None)
        if stack is None:stack=[];_context.stack=stack
        # A failed/disabled nested call must not inherit an outer source list.
        stack.append((token,state) if state is not None else (None,None))
        try:result=original(*args,**kwargs)
        finally:stack.pop()
        if not eligible:return result
        audit=state.audit() if state is not None else {'patch':PATCH_VERSION,'problems':[failure]}
        problems=list(result[1])+audit['problems'];facts=dict(result[2])
        facts['attire_mesh_matching']=audit
        return bool(result[0] and not audit['problems']),problems,facts
    convert.verify=verify
    convert._mesh_matching_installed=PATCH_VERSION
