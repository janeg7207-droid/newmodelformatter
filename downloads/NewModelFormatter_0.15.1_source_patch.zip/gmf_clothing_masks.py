"""Per-model static Body coverage under verified opaque clothing.

Only an embedded HPL is changed. Native geometry, weights, LODs, material
bindings and scene declarations are checked before using the conservative
coverage selector. Authored mask records are retained independently per LOD.
This experiment cannot prove animation coverage or texture alpha in the game.
"""
import copy
import functools
import hashlib
import inspect
import json
import math
from pathlib import Path
import re
import struct
import threading
from types import SimpleNamespace

import numpy as np
from gmf_2k26_repair import game_folder, path_hash, read_native_library
from gmf_clothing_coverage import select_covered_vertices
from gmf_jmtl_audit import Table, inspect_material
from gmf_mask_lods import EMPTY_HPL, merge_mask, verify_cloned_lods
from gmf_native_masks import envelopes, splice_mask, staged_mask


PATCH_VERSION = 'per-model-opaque-clothing-static-body-masks-1'
_selection = threading.local()
_MASK_FAILURE = ('source hide mask is unsupported or unreadable; '
                 'an empty output does not validate skin hiding')
_GAME_CHECK = ('Experimental clothing masking uses static opaque-clothing coverage; '
               'animated clipping and game visibility require entrance/gameplay checks.')
_SCENES = {128: (0, 1), 129: (1,), 130: (0,)}
_NULL = (None, 0, 0xffffffffffffffff)
_RECOVERIES = ('hide_mask_recovery', 'embedded_hide_mask_recovery', 'supplied_hide_mask_recovery')


def set_enabled(enabled):
    """Set the current conversion thread's choice; the default is enabled."""
    _selection.enabled = bool(enabled)


def is_enabled():
    return bool(getattr(_selection, 'enabled', True))


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _safe_file(path, root):
    path, root = Path(path), Path(root)
    current = path
    while True:
        if current.is_symlink():
            raise ValueError('clothing masking refuses file or directory symlinks')
        if current == current.parent:
            break
        current = current.parent
    if not path.resolve().is_relative_to(root.resolve()) or not path.is_file():
        raise ValueError('clothing masking asset is missing or outside its selected folder: ' + path.name)
    return path.read_bytes()


def _roots(report, selected_source, selected_output):
    paths = [Path(report.get('source') or selected_source), Path(report.get('output') or selected_output),
             Path(selected_source), Path(selected_output)]
    for path in paths:
        current = path
        while True:
            if current.is_symlink():
                raise ValueError('clothing masking refuses source/output root symlinks')
            if current == current.parent:
                break
            current = current.parent
    src, dst, chosen_src, chosen_dst = [path.resolve() for path in paths]
    if (not src.is_relative_to(chosen_src) or not dst.is_relative_to(chosen_dst)
            or chosen_src.is_relative_to(chosen_dst) or chosen_dst.is_relative_to(chosen_src)):
        raise ValueError('clothing masking requires separate contained source/output folders')
    return paths[0], paths[1]


def _preflight(report):
    for key in ('models', 'materials', 'problems', 'warnings'):
        if key in report and type(report[key]) is not list:
            raise ValueError('clothing masking report ' + key + ' metadata is malformed')
    for row in report.get('models', []):
        if type(row) is not dict:
            raise ValueError('clothing masking model record is malformed')
        for key in ('facts', 'face_output_audit', 'native_missing_data_audit', 'supplied_hide_mask_recovery'):
            if key in row and type(row[key]) is not dict:
                raise ValueError('clothing masking model ' + key + ' metadata is malformed')
        for key in ('problems', 'notes', 'repairs'):
            if key in row and type(row[key]) is not list:
                raise ValueError('clothing masking model ' + key + ' metadata is malformed')
        for key in _RECOVERIES:
            top = row.get(key); nested = row.get('facts', {}).get(key)
            if ((top is not None and type(top) is not dict) or (nested is not None and type(nested) is not dict)
                    or (top is not None and nested is not None and top != nested)):
                raise ValueError('clothing masking authored-mask provenance is malformed or inconsistent: ' + key)
        native = row.get('native_missing_data_audit', {}).get('masks')
        if native is not None and type(native) is not dict:
            raise ValueError('clothing masking preceding native mask audit is malformed')
    for key in ('native_2k26_models_preserved', 'native_2k26_masks_repaired'):
        if key in report and (type(report[key]) is not int or report[key] < 0):
            raise ValueError('clothing masking preceding repair counter is malformed')
    physics = report.get('physics_binding_audit')
    if physics is not None and (type(physics) is not dict or type(physics.get('rows', [])) is not list
            or any(type(row) is not dict or type(row.get('paired_models', [])) is not list
                   or any(type(pair) is not dict for pair in row.get('paired_models', []))
                   for row in physics.get('rows', []))):
        raise ValueError('clothing masking preceding physics audit is malformed')
    # Reject predictable persistence failures before any asset write.
    json.dumps(report, default=str, allow_nan=False)


def _admission(record):
    problems = record.get('problems', [])
    if record.get('verify') == 'pass' and not problems:
        return 'model_core_verification_passed'
    if record.get('verify') == 'fail' and problems and all(problem == _MASK_FAILURE for problem in problems):
        return 'verified_geometry_mask_only_trial_original_failure_retained'
    raise ValueError('clothing masking requires passed model checks or solely the exact unreadable-source-mask failure')


def _geometry(model, clone):
    if int(model.version) != 47 or len(model.meshes) != clone['mesh_count']:
        raise ValueError('native reader version or mesh count disagrees with complete clone-LOD proof')
    bones = list(model.bones)
    names = [bone.name for bone in bones]
    if not names or len(set(names)) != len(names):
        raise ValueError('native rig bone names are empty or ambiguous')
    rig = {bone.name: bone for bone in bones}
    for bone in bones:
        world = np.asarray(bone.world)
        if (world.shape != (4, 4) or world.dtype.kind not in 'fiu' or not np.isfinite(world).all()
                or not np.allclose(world[3], (0, 0, 0, 1), atol=1e-5, rtol=0)
                or abs(float(np.linalg.det(world[:3, :3]))) < 1e-6):
            raise ValueError('native rig bind matrix is invalid: ' + bone.name)
        visited = {bone.name}; parent = bone.parent
        while parent is not None:
            if parent not in rig or parent in visited:
                raise ValueError('native rig parent is missing or cyclic')
            visited.add(parent); parent = rig[parent].parent
    domains = {}; counts = []
    for mesh in model.meshes:
        positions = np.asarray(mesh.positions); triangles = np.asarray(mesh.triangles)
        count = int(mesh.num_verts)
        if (count <= 0 or count > 500000 or positions.shape != (count, 3)
                or positions.dtype.kind not in 'fiu' or not np.isfinite(positions).all()
                or triangles.ndim != 2 or triangles.shape[1:] != (3,) or not len(triangles)
                or len(triangles) > 500000 or triangles.dtype.kind not in 'iu'
                or triangles.min() < 0 or triangles.max() >= count):
            raise ValueError('native mesh geometry domain is invalid: ' + mesh.name)
        remap = np.arange(count, dtype=np.uint32) if mesh.vertex_remap is None else np.asarray(mesh.vertex_remap)
        if (remap.shape != (count,) or remap.dtype.kind not in 'iu'
                or remap.min() < 0 or remap.max() > 0xffffffff):
            raise ValueError('native mesh remap domain is invalid: ' + mesh.name)
        for name in ('normals', 'tangents'):
            value = getattr(mesh, name, None)
            if value is not None:
                array = np.asarray(value)
                if (array.ndim != 2 or array.shape[0] != count or array.dtype.kind not in 'fiu'
                        or not np.isfinite(array).all()):
                    raise ValueError('native mesh ' + name + ' domain is invalid: ' + mesh.name)
        for name in ('uvs', 'colors'):
            for value in getattr(mesh, name, []):
                array = np.asarray(value)
                if (array.ndim != 2 or array.shape[0] != count or array.dtype.kind not in 'fiu'
                        or not np.isfinite(array).all()):
                    raise ValueError('native mesh ' + name + ' domain is invalid: ' + mesh.name)
        total = np.zeros(count); influences = np.zeros(count, dtype=np.int32)
        if not isinstance(mesh.weights, dict):
            raise ValueError('native mesh weight vectors are unavailable')
        for name, vector in mesh.weights.items():
            values = np.asarray(vector)
            if (values.shape != (count,) or values.dtype.kind not in 'fiu'
                    or not np.isfinite(values).all() or (values < 0).any()
                    or (name not in rig and (values > 1e-7).any())):
                raise ValueError('native mesh weight vector or bone is invalid: ' + mesh.name)
            total += values; influences += values > 1e-7
        if not np.isfinite(total).all() or (np.abs(total - 1) > .03).any() or (influences > 8).any():
            raise ValueError('native mesh weight budgets are not normalized within eight influences')
        if mesh.name in domains:
            # Duplicate garment names are allowed; their face roles identify
            # them. Duplicate paired-base mask domains are not guessed below.
            domains[mesh.name] = None
        else:
            domains[mesh.name] = set(map(int, remap))
        counts.append({'mesh': mesh.name, 'vertices_checked': count, 'triangles_checked': len(triangles)})
    return rig, domains, counts


def _opaque_material(data):
    """Bound the actual ordinary-gear schema; never infer opacity by filename."""
    facts = inspect_material(data)
    if facts['shader_byte'] != 0x15:
        raise ValueError('material is not ordinary native gear shader 0x15')
    root = Table(data, struct.unpack_from('<I', data)[0])
    if (root.position % 4 or root.field(1, 2) != root.position + 6
            or root.field(2, 4) != root.position + 8
            or any(offset for index, offset in enumerate(root.offsets) if index not in (1, 2))):
        raise ValueError('ordinary gear material root is noncanonical')
    payload = root.child(2)
    schema = {0: '<B', 3: '<B', 4: '<I', 5: '<f', 8: '<B', 9: '<Q', 10: '<f',
              11: '<I', 12: '<Q', 13: '<Q', 14: '<I', 15: '<I', 16: '<f', 17: '<B',
              18: '<f', 19: '<f', 20: '<f', 21: '<f'}
    children = {4: ['<B'] * 3, 11: ['<B'] * 4, 14: ['<f'] * 2, 15: ['<B'] * 3}
    tables = [root, payload]
    def check(table, kinds):
        if table.position % 4 or any(off for i, off in enumerate(table.offsets) if i not in kinds):
            raise ValueError('ordinary gear material has unknown fields or misaligned table')
        spans = []
        for slot, kind in kinds.items():
            width = struct.calcsize(kind); position = table.field(slot, width)
            if position is None:
                continue
            span = (position, position + width)
            if position % width or any(max(span[0], other[0]) < min(span[1], other[1]) for other in spans):
                raise ValueError('ordinary gear material fields overlap or are misaligned')
            spans.append(span); value = table.number(slot, kind)
            if kind == '<f' and not math.isfinite(value):
                raise ValueError('ordinary gear scalar is nonfinite')
            if slot in (3, 8, 17) and table is payload and value not in (0, 1):
                raise ValueError('ordinary gear bool is invalid')
    check(payload, schema)
    for slot, kinds in children.items():
        child = payload.child(slot)
        if child is not None:
            tables.append(child); check(child, dict(enumerate(kinds)))
    regions = [((0, 8), 'header')]
    for table in tables:
        vtable = table.position - struct.unpack_from('<i', data, table.position)[0]
        if vtable % 2:
            raise ValueError('ordinary gear vtable is misaligned')
        regions.extend((((table.position, table.position + table.size), 'table'),
                        ((vtable, vtable + struct.unpack_from('<H', data, vtable)[0]), 'vtable')))
    for index, (region, kind) in enumerate(regions):
        for other, other_kind in regions[index + 1:]:
            if max(region[0], other[0]) < min(region[1], other[1]) and not (kind == other_kind == 'vtable' and region == other):
                raise ValueError('ordinary gear material table/vtable regions overlap')
    if payload.number(0, '<B', 0) != 0:
        raise ValueError('ordinary gear alpha/other variant is not opaque variant 0')
    if payload.number(13, '<Q') not in _NULL:
        raise ValueError('ordinary gear authored pixel-mask texture has unproved coverage')
    if any(payload.number(slot, '<Q') in _NULL for slot in (9, 12)):
        raise ValueError('ordinary gear color/normal references are missing')
    return {**facts, 'variant': 0, 'serialized_opaque_declaration_verified': True,
            'texture_pixels_and_game_alpha': 'not established'}


def _excluded(name):
    name = str(name).casefold().split(':', 1)[0]
    if name.startswith('m_'):
        name = name[2:]
    tokens = re.split(r'[_\s-]+', name)
    return (any(token in ('body', 'head', 'skin') for token in tokens) or
            any(token.startswith(role) for token in tokens for role in
                ('hair', 'beard', 'eye', 'mouth', 'tongue', 'teeth', 'face', 'cornea', 'caruncle')))


def _clothing(attire, target, output_root):
    table = target.with_suffix('.mtls'); data = _safe_file(table, output_root)
    entries = read_native_library(data); virtual = game_folder(table)
    if virtual is None or len({entry['name'].casefold() for entry in entries}) != len(entries):
        raise ValueError('clothing material library namespace or case-insensitive names are ambiguous')
    bindings = {entry['name'].casefold(): entry for entry in entries}
    snapshots = [(table, data, output_root)]; rows = []; cache = {}; scenes = {0: [], 1: []}
    directory = target.parent / 'Materials'
    for index, mesh in enumerate(attire.meshes):
        if _excluded(mesh.name):
            rows.append({'mesh': mesh.name, 'mesh_index': index, 'state': 'excluded_body_or_face_role'}); continue
        scene = mesh.scene_flag
        if type(scene) not in (int, np.int32, np.int64, np.uint32, np.uint64) or int(scene) not in _SCENES:
            rows.append({'mesh': mesh.name, 'mesh_index': index, 'state': 'unproved_scene_flag', 'scene_flag': str(scene)}); continue
        triangles = np.asarray(mesh.triangles); owner = np.full(len(triangles), -1, dtype=np.int32)
        groups = list(mesh.face_groups)
        for group_index, group in enumerate(groups):
            if not isinstance(group, (list, tuple)) or len(group) != 3:
                raise ValueError('clothing material face-group record is malformed')
            name, start, count = group
            if (isinstance(start, (bool, np.bool_)) or isinstance(count, (bool, np.bool_))
                    or not isinstance(start, (int, np.integer)) or not isinstance(count, (int, np.integer))
                    or start < 0 or count < 0 or start + count > len(triangles)):
                raise ValueError('clothing material face-group triangle extent is invalid')
            if (owner[start:start + count] != -1).any():
                raise ValueError('clothing material face groups overlap ambiguously')
            owner[start:start + count] = group_index
        eligible = []
        for group_index, (name, start, count) in enumerate(groups):
            role = str(name).split(':', 1)[0]
            row = {'mesh': mesh.name, 'mesh_index': index, 'material': role, 'triangle_start': int(start),
                   'triangle_count': int(count), 'scene_flag': int(scene), 'hpl_scene_flags': list(_SCENES[int(scene)])}
            try:
                if _excluded(role):
                    raise ValueError('body or face material role excluded')
                if role.casefold() not in cache:
                    entry = bindings.get(role.casefold())
                    if entry is None:
                        raise ValueError('native MTLS lacks the clothing face material')
                    matches = [] if not directory.is_dir() else [path for path in directory.iterdir()
                                                               if path.name.casefold() == role.casefold() + '.jmtl']
                    if len(matches) != 1:
                        raise ValueError('local clothing JMTL is missing or ambiguous')
                    path = matches[0]; raw = _safe_file(path, output_root)
                    if entry['path_hash'] != path_hash(virtual + '/Materials/' + path.name):
                        raise ValueError('native MTLS does not bind the actual local clothing JMTL')
                    facts = _opaque_material(raw)
                    cache[role.casefold()] = {'file': str(path), 'sha256': _sha(raw), 'bytes': len(raw), **facts}
                    snapshots.append((path, raw, output_root))
                row.update(cache[role.casefold()], state='eligible_opaque_clothing_faces')
                eligible.extend(range(int(start), int(start + count)))
            except (ValueError, OSError, struct.error) as error:
                row.update(state='clothing_faces_skipped', reason=str(error))
            rows.append(row)
        if eligible:
            view = SimpleNamespace(name=str(mesh.name), num_verts=mesh.num_verts,
                positions=mesh.positions, normals=mesh.normals, triangles=triangles[eligible],
                vertex_remap=mesh.vertex_remap, weights=mesh.weights)
            for flag in _SCENES[int(scene)]:
                scenes[flag].append(view)
    return scenes, snapshots, rows


def _bind_frames(base_rig, attire_rig, body, scenes):
    """Prove common roots and every weight-used Body/opaque-face joint frame.

    Native files legitimately vary unused facial/helper rest joints. These
    differences are recorded and never used as clothing coordinate transforms.
    Positive Body weights and vertices referenced by eligible clothing faces
    must instead have an actual matching joint in both verified native rigs.
    """
    shared = set(base_rig).intersection(attire_rig)
    roots = sorted(name for name in shared if base_rig[name].parent is None and attire_rig[name].parent is None)
    root_disagreement = [name for name in shared if (base_rig[name].parent is None) != (attire_rig[name].parent is None)]
    if not roots or root_disagreement or any(not np.allclose(base_rig[name].world, attire_rig[name].world,
                                    atol=1e-5, rtol=0) for name in roots):
        raise ValueError('paired native root/global bind frames disagree; Body/clothing coverage is unproved')
    body_used = {name for name, values in body.weights.items() if (np.asarray(values) > 1e-7).any()}
    clothing_used = set(); seen = set()
    for meshes in scenes.values():
        for mesh in meshes:
            if id(mesh) in seen:
                continue
            seen.add(id(mesh)); vertices = np.unique(mesh.triangles)
            clothing_used.update(name for name, values in mesh.weights.items()
                                 if (np.asarray(values)[vertices] > 1e-7).any())
    used = body_used | clothing_used
    missing = sorted(used - shared)
    if missing:
        raise ValueError('positive-weight Body/eligible-clothing joint is missing from the paired rig: ' + ', '.join(missing))
    changed = sorted(name for name in used if not np.allclose(base_rig[name].world, attire_rig[name].world,
                                                       atol=1e-5, rtol=0))
    if changed:
        raise ValueError('positive-weight Body/eligible-clothing bind frames disagree: ' + ', '.join(changed))
    mismatches = [{'name': name, 'base_parent': base_rig[name].parent, 'attire_parent': attire_rig[name].parent,
                   'maximum_world_delta': float(np.abs(np.asarray(base_rig[name].world) - attire_rig[name].world).max()),
                   'body_positive_weight_joint': name in body_used,
                   'eligible_clothing_positive_weight_joint': name in clothing_used}
                  for name in sorted(shared) if not np.allclose(base_rig[name].world, attire_rig[name].world,
                                                            atol=1e-5, rtol=0)]
    return {'state': 'common_roots_and_all_weight_used_body_clothing_world_frames_verified',
            'matrix_absolute_tolerance': 1e-5, 'relative_tolerance': 0,
            'matched_root_names': roots, 'body_positive_weight_joints': sorted(body_used),
            'eligible_clothing_positive_weight_joints': sorted(clothing_used),
            'clothing_weight_domain': 'only vertices referenced by eligible opaque material face groups',
            'unused_shared_child_bind_mismatch_count': len(mismatches), 'unused_shared_child_bind_mismatches': mismatches,
            'base_unshared_root_names': sorted(name for name, bone in base_rig.items() if bone.parent is None and name not in shared),
            'attire_unshared_root_names': sorted(name for name, bone in attire_rig.items() if bone.parent is None and name not in shared),
            'scope': 'actual shared native rest-coordinate roots and positive-weight joint world matrices; unused facial/helper differences retained',
            'animation_and_deformation_equivalence': 'not established; entrance/gameplay validation required'}


def _current_mask(data, model):
    frames = envelopes(data); masks = [frame['payload'] for frame in frames if frame['tag'] == b'HPL!']
    if len(masks) > 1 or [raw for tag, raw in model.substreams if tag == b'HPL!'] != masks:
        raise ValueError('native reader and envelope masks disagree or are ambiguous')
    return masks[0] if masks else None


def _update(report, record, target, proof, mask, mcd):
    facts = record.setdefault('facts', {})
    facts.setdefault('before_clothing_mask_coverage', {key: copy.deepcopy(facts[key]) for key in
        ('output_sha256', 'byte_identical', 'model_bytes_preserved', 'hide_mask') if key in facts})
    facts.update(output_sha256=proof['after_mcd_sha256'], written_hpl_sha256=proof['after_hpl_sha256'])
    if proof['asset_changed']:
        facts.update(byte_identical=False, model_bytes_preserved=False,
            geometry_weights_bones_and_embedded_streams=('every non-HPL byte preserved; readable current authored records retained and static covered Body IDs added; '
                + ('unreadable original coverage remains unknown' if proof['unknown_original_coverage_not_recovered'] else 'no authored coverage discarded')))
        if 'experimental_static_clothing_body_mask' not in record.setdefault('repairs', []):
            record['repairs'].append('experimental_static_clothing_body_mask')
        if record.get('status') == 'preserved_2k26':
            report['native_2k26_models_preserved'] = max(0, report.get('native_2k26_models_preserved', 0) - 1)
            report['native_2k26_masks_repaired'] = report.get('native_2k26_masks_repaired', 0) + 1
        if record.get('verify') == 'pass':
            record['status'] = 'repaired_experimental_static_clothing_mask'
    record['clothing_mask_coverage'] = copy.deepcopy(proof); facts['clothing_mask_coverage'] = copy.deepcopy(proof)
    for key in _RECOVERIES:
        for recovery in (record.get(key), facts.get(key)):
            if recovery is not None:
                recovery['output_byte_proof_stage'] = 'historical authored restoration before per-model clothing coverage'
                recovery['following_clothing_mask_coverage'] = copy.deepcopy(proof)
    record.setdefault('verification_scope_before_clothing_mask_coverage', record.get('verification_scope', 'original model conversion checks'))
    record['verification_scope'] = ('original model verification retained before HPL extension; every non-HPL byte preserved; '
                                    'current native HPL structure, paired domains and static coverage checked; game appearance unverified')
    native = record.get('native_missing_data_audit', {}).get('masks')
    if native is not None:
        native.setdefault('before_clothing_mask_coverage', copy.deepcopy(native))
        parsed = mcd.parse_hpl(mask)
        native.update(mask_sha256=proof['after_hpl_sha256'],
            state='readable_indices_valid_after_experimental_static_clothing_coverage',
            counts={str(lod): {str(flag): {name: len(ids) for name, ids in groups}
                              for flag, groups in flags.items()} for lod, flags in parsed.items()},
            following_clothing_mask_coverage=copy.deepcopy(proof),
            output_byte_proof_stage='current mask facts refreshed; prior restoration repairs are historical before static extension')
    audit = record.get('face_output_audit')
    if audit is not None:
        audit.setdefault('before_clothing_mask_coverage_output_sha256', audit.get('output_sha256'))
        audit['output_sha256'] = proof['after_mcd_sha256']
        audit['output_byte_proof_stage'] = 'geometry/material observations retained; HPL-only coverage follows'
    for row in report.get('physics_binding_audit', {}).get('rows', []):
        for pair in row.get('paired_models', []):
            if (pair.get('path') or pair.get('file')) == str(target):
                pair.setdefault('before_clothing_mask_coverage_sha256', pair.get('sha256'))
                pair.update(sha256=proof['after_mcd_sha256'], bytes=proof['after_mcd_bytes'], following_hpl_only_extension=True)
    if proof['asset_changed']:
        for key in ('problems', 'warnings'):
            if _GAME_CHECK not in report.setdefault(key, []):
                report[key].append(_GAME_CHECK)
        report['experimental_clothing_mask_game_check'] = True; report['conversion_completeness'] = 'incomplete'


def process(report, selected_source, selected_output, vcmodel, mcd, log=lambda text: None):
    summary = {'version': PATCH_VERSION, 'enabled': is_enabled(), 'applied': 0, 'already_covered': 0,
               'skipped': 0, 'refused': 0, 'failed_after_write': 0, 'attires_checked': 0,
               'rows': [], 'source_files_changed': False,
               'in_game_validation': 'not_performed', 'scope': 'per-model static Body coverage under linked opaque clothing'}
    report['clothing_mask_coverage'] = summary
    if not summary['enabled']:
        summary['state'] = 'disabled_no_asset_reads_or_writes'; return summary
    try:
        _preflight(report); source_root, output_root = _roots(report, selected_source, selected_output)
    except (ValueError, TypeError) as error:
        summary.update(state='requires_attention', refused=1)
        summary['rows'].append({'state': 'not_applied', 'reason': str(error), 'output_file_changes': 'none'}); return summary
    outputs = [str(Path(row['output']).resolve()) for row in report.get('models', []) if row.get('output')]
    for record in report.get('models', []):
        row = {'source': record.get('source'), 'output': record.get('output'), 'output_file_changes': 'none'}
        committed = False
        if record.get('output') and Path(record['output']).parent.name.casefold() == 'basemodel':
            row['state'] = 'base_model_not_applicable'; summary['rows'].append(row); continue
        summary['attires_checked'] += 1
        try:
            if not record.get('source') or not record.get('output'):
                raise ValueError('clothing masking requires recorded source and output models')
            source, target = Path(record['source']), Path(record['output'])
            if outputs.count(str(target.resolve())) != 1:
                raise ValueError('clothing masking output is claimed by multiple model records')
            admission = _admission(record)
            source_bytes = _safe_file(source, source_root); before = _safe_file(target, output_root)
            if target.with_suffix('.hpl').exists() or target.with_suffix('.hpl').is_symlink():
                raise ValueError('clothing masking preserves a conflicting separate output HPL by refusal')
            output_base = target.parent.parent / 'BaseModel' / 'baseModel.mcd'
            bases = [base for base in report['models'] if base.get('output')
                     and Path(base['output']).resolve() == output_base.resolve()]
            if len(bases) != 1 or not bases[0].get('source'):
                raise ValueError('clothing masking needs one current-job same-character paired BaseModel')
            _admission(bases[0]); source_base = Path(bases[0]['source'])
            if (source_base.parent.name.casefold() != 'basemodel'
                    or source_base.parent.parent.resolve() != source.parent.parent.resolve()):
                raise ValueError('clothing masking paired source BaseModel belongs to a different character')
            source_base_bytes = _safe_file(source_base, source_root); base_bytes = _safe_file(output_base, output_root)
            snapshots = [(source, source_bytes, source_root), (target, before, output_root),
                         (source_base, source_base_bytes, source_root), (output_base, base_bytes, output_root)]
            for sidecar in (source.with_suffix('.hpl'), source_base.with_suffix('.hpl')):
                if sidecar.exists() or sidecar.is_symlink():
                    snapshots.append((sidecar, _safe_file(sidecar, source_root), source_root))
            base_clone = verify_cloned_lods(base_bytes); attire_clone = verify_cloned_lods(before)
            base = vcmodel.read_model(str(output_base), with_shapes=False)
            attire = vcmodel.read_model(str(target), with_shapes=False)
            base_rig, domains, base_geometry = _geometry(base, base_clone)
            attire_rig, _, attire_geometry = _geometry(attire, attire_clone)
            bodies = [mesh for mesh in base.meshes if mesh.name == 'M_Body']
            if len(bodies) != 1 or domains.get('M_Body') is None:
                raise ValueError('paired base has no unique native M_Body remap domain')
            domains = {name: ids for name, ids in domains.items() if ids is not None}
            current = _current_mask(before, attire)
            scenes, materials, material_rows = _clothing(attire, target, output_root)
            row['clothing_material_checks'] = material_rows; snapshots.extend(materials)
            if not any(scenes.values()):
                row.update(state='no_proven_covered_body_ids', coverage={},
                           reason='no eligible linked opaque clothing faces for a proven scene')
                summary['skipped'] += 1; summary['rows'].append(row)
                try:
                    log('Clothing masking: ' + target.name + '; no eligible opaque clothing; see report details.')
                except Exception:
                    pass
                continue
            bind_frames = _bind_frames(base_rig, attire_rig, bodies[0], scenes)
            row['bind_frame_verification'] = bind_frames
            additions = {}; coverage = {}; coverage_cache = {}
            for flag, meshes in scenes.items():
                if meshes:
                    identity = tuple(id(mesh) for mesh in meshes)
                    if identity not in coverage_cache:
                        coverage_cache[identity] = select_covered_vertices(bodies[0], meshes)
                    result = coverage_cache[identity]
                    coverage[str(flag)] = result; additions[flag] = result['selected_remap_ids']
            row['coverage'] = coverage
            if not any(additions.values()):
                row.update(state='no_proven_covered_body_ids', reason='no eligible opaque faces or no complete incident-triangle coverage')
                summary['skipped'] += 1; summary['rows'].append(row)
                try:
                    log('Clothing masking: ' + target.name + '; no proven coverage; see clothing-mask report details.')
                except Exception:
                    pass
                continue
            lost = False
            try:
                mask, merge = merge_mask(current, mcd, domains, additions)
            except ValueError as error:
                if admission != 'verified_geometry_mask_only_trial_original_failure_retained':
                    raise
                # A readable authored mask with unsupported LODs/domains is
                # preserved; only genuinely unreadable coverage may be lost.
                if current is not None and (current == EMPTY_HPL or mcd.hpl_is_whole(current)):
                    raise
                mask, merge = merge_mask(None, mcd, domains, additions); lost = True
                row['unknown_original_mask_reason'] = str(error)
            changed = before if mask == current else splice_mask(before, mask)
            def non_hpl(data):
                frames = envelopes(data)
                return data[:4] + b''.join(data[frame['start']:frames[index + 1]['start'] if index + 1 < len(frames) else len(data)]
                    for index, frame in enumerate(frames) if frame['tag'] != b'HPL!')
            if non_hpl(changed) != non_hpl(before):
                raise ValueError('clothing masking candidate changed non-HPL envelope payloads')
            proof = {'version': PATCH_VERSION, 'state': 'applied_experimental_static_mask' if changed != before else 'already_covered',
                'asset_changed': changed != before, 'admission': admission, 'original_model_verify': record.get('verify'),
                'original_model_problems_retained': list(record.get('problems', [])),
                'before_mcd_sha256': _sha(before), 'after_mcd_sha256': _sha(changed),
                'before_mcd_bytes': len(before), 'after_mcd_bytes': len(changed),
                'before_hpl_sha256': None if current is None else _sha(current), 'after_hpl_sha256': _sha(mask),
                'mask_union': merge, 'coverage': coverage, 'materials': material_rows,
                'paired_base_sha256': _sha(base_bytes), 'base_lod_clone_proof': base_clone,
                'attire_lod_clone_proof': attire_clone, 'base_native_geometry_checks': base_geometry,
                'attire_native_geometry_checks': attire_geometry, 'every_non_hpl_payload_preserved': True,
                'bind_frame_verification': bind_frames,
                'every_non_hpl_byte_preserved': True,
                'paired_base_domains': {name: len(ids) for name, ids in domains.items()},
                'source_files_changed': False, 'unknown_original_coverage_not_recovered': lost or admission.startswith('verified_geometry_mask_only'),
                'coverage_generated': True, 'coverage_scope': 'positive-depth front-facing clothing footprint union; all incident Body triangles covered',
                'in_game_validation': 'not_performed', 'animated_clipping_and_visibility_proved': False}
            # Prepare all predictable metadata changes before committing bytes.
            planned_report = copy.deepcopy(report); planned_record = copy.deepcopy(record)
            _update(planned_report, planned_record, target, proof, mask, mcd)
            json.dumps(planned_report, default=str, allow_nan=False); json.dumps(planned_record, default=str, allow_nan=False)
            def recheck():
                for path, data, root in snapshots:
                    if _safe_file(path, root) != data:
                        raise ValueError('paired clothing-mask asset changed during staging; output preserved')
            recheck()
            if changed != before:
                def read_stage(path, **kwargs):
                    model = vcmodel.read_model(path, **kwargs); recheck(); return model
                staged_mask(target, changed, mask, SimpleNamespace(read_model=read_stage)); committed = True
            if _safe_file(target, output_root) != changed:
                raise ValueError('final clothing-mask output differs from its staged candidate')
            for path, data, root in snapshots:
                if path != target and _safe_file(path, root) != data:
                    raise ValueError('clothing masking source/base/material preservation failed')
            proof['native_reader_passed'] = True
            _update(report, record, target, proof, mask, mcd)
            row.update(proof, output_file_changes='only embedded HPL' if committed else 'none')
            summary['applied' if committed else 'already_covered'] += 1
            try:
                log('Clothing masking: ' + target.name + '; ' + proof['state'] + '; game checks required.')
            except Exception:
                pass
        except Exception as error:
            row.update(state='applied_with_verification_or_reporting_error' if committed else 'not_applied', reason=str(error),
                       output_file_changes='HPL committed; final validation/reporting failed' if committed else 'none')
            summary['failed_after_write' if committed else 'refused'] += 1
            try:
                log('Clothing masking: ' + str(row.get('output')) + '; ' + row['state'] + ': ' + str(error))
            except Exception:
                pass
        summary['rows'].append(row)
    summary['state'] = 'requires_attention' if summary['refused'] or summary['failed_after_write'] else 'checked_static_coverage_game_validation_required'
    return summary


def install(folder):
    """Install after authored-mask recovery, before final face/physics reports."""
    if getattr(folder, '_clothing_mask_coverage_patch', None) == PATCH_VERSION:
        return
    original = folder.convert_folder
    @functools.wraps(original)
    def convert_folder(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs); bound.apply_defaults()
        report = original(*args, **kwargs)
        process(report, bound.arguments['src'], bound.arguments['dst'], folder.vc, folder.mcd,
                bound.arguments.get('log', lambda text: None))
        from gmf_report import save_intermediate
        save_intermediate(report, bound.arguments['dst'])
        return report
    folder.convert_folder = convert_folder
    folder._clothing_mask_coverage_patch = PATCH_VERSION
