"""Bounded source readers for sequential v5 and v6/inline-v1 material tables.

These layouts were recovered from the supplied native ModelFormat reader and
checked against both uploaded Kenny22 and Hammerstone24 table pairs.  This
module never rewrites a header, writes a file or chooses a destination shader.
It preserves exact source shader/technique names and all parameter records.

Packed type 2 consumes sixteen bytes in the native reader, whose vector
semantics are not established.  Decoding retains those bytes.  The Material25
adapter refuses them by default; an explicitly reviewed unused-key allowlist
can retain them as opaque bytes without claiming a semantic vector conversion.
Source layout support does not establish rig, physics or game compatibility.
"""
import copy
import hashlib
import math
import struct
from types import SimpleNamespace


PATCH_VERSION = 'bounded-v5-and-inline-v1-source-material-reader-1'
_MAX_MATERIALS = 4096
_MAX_PARAMETERS = 65535
_VALUE_KINDS = {1: 'float32', 2: 'opaque_vector16', 3: 'uint32',
                4: 'string', 5: 'hash64'}


class LegacyMaterialError(ValueError):
    """The source layout or its requested semantic adaptation is unsupported."""


class _Cursor:
    def __init__(self, data):
        self.data = data
        self.offset = 0
        self.padding = []

    def take(self, count, context):
        if count < 0 or count > len(self.data) - self.offset:
            raise LegacyMaterialError(context + ': truncated source at offset ' + str(self.offset))
        start = self.offset
        self.offset += count
        return self.data[start:self.offset]

    def unpack(self, fmt, context):
        values = struct.unpack('<' + fmt, self.take(struct.calcsize('<' + fmt), context))
        return values[0] if len(values) == 1 else values

    def align(self, context, phase=0):
        # The v5 native parameter reader uses (pointer + 0xFE) & 3,
        # i.e. phase 2, while inline-v1 uses pointer & 3 (phase 0).
        count = (phase - self.offset) % 4
        start = self.offset
        raw = self.take(count, context)
        if count:
            self.padding.append({'offset': start, 'end': self.offset,
                                 'raw_hex': raw.hex()})


def _string(table, offset, context, allow_empty=False):
    if not 0 <= offset < len(table):
        raise LegacyMaterialError(context + ': string offset is outside its declared table')
    if offset and table[offset - 1] != 0:
        raise LegacyMaterialError(context + ': string offset is not an entry boundary')
    end = table.find(b'\0', offset)
    if end < 0:
        raise LegacyMaterialError(context + ': string is not NUL terminated')
    value = table[offset:end].decode('latin1')
    if not value and not allow_empty:
        raise LegacyMaterialError(context + ': empty identifier')
    return value


def _count(cursor, fmt, maximum, minimum_bytes, context):
    count = cursor.unpack(fmt, context)
    if count > maximum or count > (len(cursor.data) - cursor.offset) // minimum_bytes:
        raise LegacyMaterialError(context + ': count exceeds the remaining source extent')
    return count


def _header(cursor, strings):
    start = cursor.offset
    shader_offset, flag0, technique_offset = cursor.unpack('HHH', 'material header')
    flag1, flag2, flag3 = cursor.unpack('BBB', 'material flags')
    flag4 = cursor.unpack('H', 'material flag4')
    header_end = cursor.offset
    cursor.align('material header padding')
    return {'header_offset': start, 'header_end': header_end,
            'header_raw_hex': cursor.data[start:header_end].hex(),
            'shader_offset': shader_offset, 'technique_offset': technique_offset,
            'shader': _string(strings, shader_offset, 'material shader'),
            'technique': _string(strings, technique_offset, 'material technique'),
            'flags_raw': [flag0, flag1, flag2, flag3, flag4]}


def _parameters(cursor, strings, count, phase):
    records = []
    names = set()
    for _ in range(count):
        start = cursor.offset
        name_offset, packed_type = cursor.unpack('Hh', 'parameter header')
        name = _string(strings, name_offset, 'parameter name')
        if name in names:
            raise LegacyMaterialError('duplicate parameter name: ' + name)
        names.add(name)
        value_start = cursor.offset
        if packed_type == 1:
            value = cursor.unpack('f', 'float parameter ' + name)
            if not math.isfinite(value):
                raise LegacyMaterialError('non-finite float parameter: ' + name)
        elif packed_type == 2:
            raw = cursor.take(16, 'opaque vector parameter ' + name)
            # This is a byte-preservation observation, not float4 decoding.
            value = {'raw_hex': raw.hex(),
                     'native_low_u16_pair': [v & 0xffff for v in struct.unpack('<QQ', raw)]}
        elif packed_type == 3:
            value = cursor.unpack('I', 'uint parameter ' + name)
        elif packed_type == 4:
            string_offset = cursor.unpack('H', 'string parameter ' + name)
            value = _string(strings, string_offset, 'string parameter ' + name, True)
        elif packed_type == 5:
            value = cursor.unpack('Q', 'hash parameter ' + name)
        else:
            raise LegacyMaterialError('unsupported packed parameter type ' + str(packed_type)
                                      + ' for ' + name + ' at offset ' + str(start))
        value_end = cursor.offset
        cursor.align('parameter padding', phase)
        record = {'name': name, 'name_offset': name_offset,
                  'packed_type': packed_type, 'kind': _VALUE_KINDS[packed_type],
                  'value': value, 'offset': start, 'value_offset': value_start,
                  'value_end': value_end, 'end': cursor.offset,
                  'raw_value_hex': cursor.data[value_start:value_end].hex()}
        if packed_type == 4:
            record['string_offset'] = string_offset
        records.append(record)
    return records


def _finish_material(material, cursor, strings, phase):
    count_offset = cursor.offset
    count = _count(cursor, 'H', _MAX_PARAMETERS, 6, 'parameter count')
    if phase == 0:
        cursor.align('parameter table padding')
    records = _parameters(cursor, strings, count, phase)
    material.update(parameter_count=count, parameter_count_offset=count_offset,
                    parameters=records, end=cursor.offset,
                    bytes=cursor.offset-material['offset'],
                    unverified_vector_parameters=[r['name'] for r in records if r['packed_type'] == 2])
    return material


def decode_legacy_material_library(data):
    """Read the two measured legacy source layouts into serializable facts.

    Only outer v5 sequential records and outer v6 with exclusively inline-v1
    blocks are supported.  Complete file consumption, identifier boundaries,
    counts, typed extents and duplicate names are checked.  Unknown parameter
    types, mixed blocks, native stubs and header-retagged v3 payloads refuse.
    Nonzero padding is retained in facts rather than overwritten as the native
    source reader does.  Source-year and destination-shader admission are the
    caller's responsibility.
    """
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError('legacy material data must be bytes-like')
    data = bytes(data)
    cursor = _Cursor(data)
    if cursor.take(4, 'library magic') != b'MTLs':
        raise LegacyMaterialError('not an MTLs material library')
    version, string_bytes = cursor.unpack('II', 'library header')
    if version not in (5, 6):
        raise LegacyMaterialError('unsupported legacy outer library version ' + str(version))
    strings = cursor.take(string_bytes, 'library string table')
    cursor.align('library string padding')
    count_offset = cursor.offset
    count = _count(cursor, 'I', _MAX_MATERIALS, 16 if version == 5 else 12,
                   'material count')
    if not count:
        raise LegacyMaterialError('empty legacy material library')
    materials = []
    if version == 6:
        # Later outer v6 adds hashes and name-offset arrays before each v1
        # material's own string table.  v5 has neither array.
        hashes = [cursor.unpack('Q', 'material path hashes') for _ in range(count)]
        name_offsets = [cursor.unpack('H', 'material name offsets') for _ in range(count)]
        names = [_string(strings, o, 'material name') for o in name_offsets]
        cursor.align('material table padding')
        for name, name_offset, path_hash in zip(names, name_offsets, hashes):
            start = cursor.offset
            if cursor.take(4, 'inline material magic') != b'MTL!':
                raise LegacyMaterialError('missing next inline MTL! block at offset ' + str(start))
            block_version, block_string_bytes = cursor.unpack('II', 'inline block header')
            if block_version != 1:
                raise LegacyMaterialError('legacy v6 decoder requires inline block version 1, found '
                                          + str(block_version))
            block_strings = cursor.take(block_string_bytes, 'inline string table')
            cursor.align('inline string padding')
            material = _header(cursor, block_strings)
            material.update(name=name, name_offset=name_offset, path_hash=path_hash,
                            offset=start, block_version=1, string_bytes=block_string_bytes)
            materials.append(_finish_material(material, cursor, block_strings, 0))
    else:
        for _ in range(count):
            start = cursor.offset
            name_offset = cursor.unpack('H', 'sequential material name')
            name = _string(strings, name_offset, 'material name')
            material = _header(cursor, strings)
            material.update(name=name, name_offset=name_offset, path_hash=None,
                            offset=start, block_version=None)
            materials.append(_finish_material(material, cursor, strings, 2))
    # Case variants collide when original writer emits files on Windows.
    folded = [m['name'].casefold() for m in materials]
    if len(set(folded)) != len(folded):
        raise LegacyMaterialError('duplicate or case-colliding material names')
    if cursor.offset != len(data):
        raise LegacyMaterialError('unaccounted trailing bytes after legacy material records')
    return {'version': PATCH_VERSION, 'library_version': version,
            'layout': 'v5_sequential' if version == 5 else 'v6_inline_v1',
            'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'string_bytes': string_bytes, 'material_count': count,
            'count_offset': count_offset, 'material_names': [m['name'] for m in materials],
            'materials': materials, 'walk_end': cursor.offset,
            'envelope_validated': True, 'payload_extents_validated': True,
            'nonzero_padding': [p for p in cursor.padding if any(bytes.fromhex(p['raw_hex']))],
            'unverified_vectors': [{'material': m['name'], 'parameter': r['name']}
                                   for m in materials for r in m['parameters'] if r['packed_type'] == 2],
            'validation_scope': 'source layout and typed extents only; target shaders, textures, rig and game appearance unverified'}


def to_material25(material, material25_factory=None, *, opaque_vector_keys=()):
    """Adapt decoded fields to the recovered Material25 attribute contract.

    Float/string/hash values use the original reader's types 2/6/7.  A source
    uint32 maps to type0/raw4 bytes, matching its original v3 reader behavior;
    its typed integer remains in source_legacy metadata.  No uint32 can thereby
    masquerade as a u64 texture reference.  A *@ref key must have packed type5.

    No shader alias or header-flag packing is invented.  The compatibility
    .head tuple is neutral because the active converter never consults it;
    exact raw source flags remain in source_legacy.  Unknown vector semantics
    refuse by default.  Explicitly allowlisted, independently proved unused
    vector keys can be retained as opaque type5/raw16 bytes, with a warning.
    Those bytes must never be interpreted as float4 by a destination writer.
    """
    allowed = frozenset(opaque_vector_keys)
    params, types = {}, {}
    opaque = []
    for record in material['parameters']:
        name, kind = record['name'], record['packed_type']
        if name in params:
            raise LegacyMaterialError('duplicate adapter parameter name: ' + name)
        if name.endswith('@ref') and kind != 5:
            raise LegacyMaterialError('texture reference has unsupported source type: ' + name)
        if kind == 1:
            value = record['value']
            if type(value) is not float or not math.isfinite(value):
                raise LegacyMaterialError('invalid adapted float parameter: ' + name)
            param_type = 2
        elif kind == 2:
            if name not in allowed:
                raise LegacyMaterialError('unverified packed vector semantics for '
                                          + material['name'] + '/' + name)
            value = bytes.fromhex(record['raw_value_hex'])
            if len(value) != 16:
                raise LegacyMaterialError('invalid opaque vector extent: ' + name)
            param_type = 5
            opaque.append(name)
        elif kind == 3:
            value = bytes.fromhex(record['raw_value_hex'])
            if len(value) != 4:
                raise LegacyMaterialError('invalid uint32 extent: ' + name)
            param_type = 0
        elif kind == 4:
            value = record['value']
            if type(value) is not str:
                raise LegacyMaterialError('invalid adapted string parameter: ' + name)
            param_type = 6
        elif kind == 5:
            value = record['value']
            if type(value) is not int or not 0 <= value <= 0xffffffffffffffff:
                raise LegacyMaterialError('invalid adapted hash parameter: ' + name)
            param_type = 7
        else:
            raise LegacyMaterialError('unsupported adapted parameter type ' + str(kind))
        params[name], types[name] = value, param_type
    result = material25_factory() if material25_factory is not None else SimpleNamespace()
    result.name, result.shader, result.technique = material['name'], material['shader'], material['technique']
    result.head, result.params, result.types = (0, 0, 0), params, types
    result.source_legacy = {'version': PATCH_VERSION,
                            'material': copy.deepcopy(material),
                            'header_flags': 'raw source preserved; destination semantics not transposed',
                            'opaque_vector_keys': opaque,
                            'warnings': ['uninterpreted source vector retained as opaque bytes: ' + key for key in opaque]}
    return result


def to_material25_library(decoded, material25_factory=None, *, opaque_vector_keys=()):
    """Return (original_outer_version, materials); adaptation is all-or-error."""
    return decoded['library_version'], [to_material25(m, material25_factory,
        opaque_vector_keys=opaque_vector_keys) for m in decoded['materials']]
