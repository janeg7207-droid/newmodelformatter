"""Route native v40 inputs to the native reader/core, retaining rig guards.

Only the folder selection gate is broadened while conversion is active.
No input header/version is rewritten. Older rigs remain explicitly unverified
when the original converter reports missing compatibility requirements.
"""
import functools
import inspect
import threading
import types

PATCH_VERSION='native-2k24-format-route-with-rig-guards-1'
_context=threading.local()


def source_version(value):
    try:return int(value,0) if isinstance(value,str) else int(value)
    except (TypeError,ValueError):return None


def install(folder,convert=None):
    if getattr(folder,'_legacy24_route_patch',None)==PATCH_VERSION:return
    if convert is None:convert=folder.convert
    actual_mcd=folder.mcd;actual_version=actual_mcd.mdl_version
    original=folder.convert_folder
    original_model=convert.convert_mcd

    def folder_version(path):
        version=actual_version(path)
        # The native core still reads actual v40 bytes and records source v40.
        # This adapter only admits that source through the existing folder gate.
        if getattr(_context,'active',False) and version==40:return folder.vc.VERSION_2K25
        return version

    proxy=types.SimpleNamespace(**{**vars(actual_mcd),'mdl_version':folder_version})
    folder.mcd=proxy
    seen=set();function=original
    while isinstance(function,types.FunctionType) and id(function) not in seen:
        seen.add(id(function))
        if function.__globals__.get('mcd') is actual_mcd:function.__globals__['mcd']=proxy
        function=getattr(function,'__wrapped__',None)

    @functools.wraps(original_model)
    def convert_mcd(*args,**kwargs):
        report=original_model(*args,**kwargs)
        if source_version(report.get('source_version'))==40:
            report['source_game']='WWE 2K24'
            report['legacy_2k24_conversion']={'version':PATCH_VERSION,
                'source_version':40,'input_header_rewritten':False,
                'backend':'original native v40 reader and Gorilla conversion core',
                'rig_checks':'original compatibility checks retained',
                'validation':'see per-model verify; materials, hide masks, physics and in-game checks remain separate'}
            if report.get('unsupported'):
                report['original_unsupported_reason']=report['unsupported']
                report['unsupported']='2K24 rig is outside the current conversion reference; this output is NOT ready for use. '+report['unsupported']
            report.setdefault('notes',[]).append('2K24 source format routed without changing input bytes; rig/material/physics validation is still required.')
        return report

    @functools.wraps(original)
    def convert_folder(*args,**kwargs):
        bound=inspect.signature(original).bind(*args,**kwargs);bound.apply_defaults()
        before=getattr(_context,'active',False);_context.active=True
        try:report=original(*args,**kwargs)
        finally:_context.active=before
        models=[r for r in report.get('models',[]) if source_version(r.get('source_version'))==40]
        report['legacy_2k24_input_route']={'version':PATCH_VERSION,'models_attempted':len(models),
            'model_checks_passed':sum(r.get('verify')=='pass' and not r.get('unsupported') for r in models),
            'input_headers_rewritten':False,'in_game_validation':'not_performed',
            'validation_scope':'native model structural checks; materials, hide masks and physics reported separately'}
        if models:
            message='2K24 conversion is experimental; original rig checks retained and in-game validation required.'
            report.setdefault('warnings',[]).append(message)
            bound.arguments['log'](message)
        from gmf_report import save_intermediate
        save_intermediate(report,bound.arguments['dst'])
        return report

    convert.convert_mcd=convert_mcd
    folder.convert_folder=convert_folder
    folder._legacy24_route_patch=PATCH_VERSION
