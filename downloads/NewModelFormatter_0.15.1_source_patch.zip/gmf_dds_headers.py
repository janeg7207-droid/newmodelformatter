"""Normalize proven complete mip counts in separate, existing DDS outputs.

The source is never modified. Unsupported or unused textures do not become
conversion failures. A qualifying full-chain repair is committed only when
the contained output still equals the source bytes or the prepared result.
"""
import copy
import functools
import hashlib
import inspect
from pathlib import Path

from gmf_local_textures import prepare_local_dds
from gmf_native_assets import atomic_bytes


PATCH_VERSION = 'verified-output-only-complete-mip-header-normalization-1'


def _digest(data):
    return hashlib.sha256(data).hexdigest()


def _safe_paths(source, target, source_root, output_root, selected_source, selected_output):
    if source.is_symlink() or target.is_symlink():
        raise ValueError('DDS header repair refuses source/output file symlinks')
    src = source.resolve(); dst = target.resolve()
    actual_source = source_root.resolve(); actual_output = output_root.resolve()
    selected_source = Path(selected_source).resolve(); selected_output = Path(selected_output).resolve()
    if (not actual_source.is_relative_to(selected_source)
            or not actual_output.is_relative_to(selected_output)
            or not src.is_relative_to(actual_source)
            or not dst.is_relative_to(actual_output)):
        raise ValueError('DDS header repair leaves the selected source/output folders')
    if (selected_source == selected_output
            or selected_source.is_relative_to(selected_output)
            or selected_output.is_relative_to(selected_source)
            or actual_source.is_relative_to(actual_output)
            or actual_output.is_relative_to(actual_source)
            or dst.is_relative_to(selected_source) or src == dst):
        raise ValueError('DDS header repair requires disjoint source/output folders')


def _metadata_updates(report, target, facts):
    """Retain old copy evidence while marking the actual final header bytes."""
    expected = target.resolve(); seen = set(); changed = 0
    repair = facts['mip_count_repair']
    prior_keys = ('sha256', 'source_sha256', 'output_sha256', 'byte_identical',
                  'dds_file_bytes_identical', 'dds_compressed_payload_byte_identical')

    def visit(value):
        nonlocal changed
        if not isinstance(value, (dict, list)) or id(value) in seen:
            return
        seen.add(id(value))
        if isinstance(value, list):
            for item in value: visit(item)
            return
        recorded = value.get('output')
        match = False
        if isinstance(recorded, str) and recorded:
            try: match = Path(recorded).resolve() == expected
            except (OSError, ValueError): pass
        if match:
            if 'dds_header_normalization_prior_copy_evidence' not in value:
                value['dds_header_normalization_prior_copy_evidence'] = {
                    key: copy.deepcopy(value[key]) for key in prior_keys if key in value}
            value.update(source_sha256=repair['source_sha256'],
                         output_sha256=repair['output_sha256'], byte_identical=False,
                         compressed_payload_byte_identical=True,
                         dds_header_repair=copy.deepcopy(repair))
            if 'sha256' in value: value['sha256'] = repair['output_sha256']
            if 'dds_file_bytes_identical' in value: value['dds_file_bytes_identical'] = False
            if 'dds_compressed_payload_byte_identical' in value:
                value['dds_compressed_payload_byte_identical'] = True
            if isinstance(value.get('dds'), dict): value['dds'] = copy.deepcopy(facts)
            changed += 1
        # Newly attached evidence has no output path; snapshots preserve the
        # original hashes rather than being rewritten recursively.
        for key, item in list(value.items()):
            if key not in ('dds_header_normalization_prior_copy_evidence', 'dds_header_repair'):
                visit(item)

    visit(report)
    return changed


def process(report, selected_source, selected_output, log=lambda text: None):
    """Repair only equivalent, existing output DDS files beneath this report."""
    source_root = Path(report.get('source') or selected_source)
    output_root = Path(report.get('output') or selected_output)
    summary = {'version': PATCH_VERSION, 'scope': 'existing equivalent output paths; full physical chain only',
               'source_files_changed': False, 'in_game_validation': 'not_performed',
               'repaired': 0, 'already_normalized': 0, 'output_not_present': 0,
               'failed': 0, 'rows': []}
    rows = summary['rows']
    try: sources = sorted(source_root.rglob('*'))
    except OSError:
        # A source that could not be inspected does not establish an eligible
        # header repair. Existing conversion/audit errors remain untouched.
        sources = []
    for source in sources:
        if source.suffix.casefold() != '.dds' or not source.is_file(): continue
        # Do not follow source aliases outside the user's selected folder.
        try:
            if (source.is_symlink() or not source.resolve().is_relative_to(source_root.resolve())
                    or not source_root.resolve().is_relative_to(Path(selected_source).resolve())):
                continue
            raw = source.read_bytes(); prepared, facts = prepare_local_dds(raw)
        except (OSError, ValueError):
            continue  # Unsupported/unused DDS data is not globally promoted.
        repair = facts['mip_count_repair']
        if repair['state'] != 'output_header_count_repaired': continue
        target = output_root / source.relative_to(source_root)
        row = {'source': str(source), 'output': str(target),
               'source_sha256': repair['source_sha256'],
               'expected_output_sha256': repair['output_sha256'],
               'declared_mip_count': repair['declared_mip_count'],
               'inferred_mip_count': repair['inferred_mip_count'],
               'changed_header_byte_offsets': list(repair['changed_header_byte_offsets']),
               'expected_compressed_payload_byte_identical': True,
               'header_repair': copy.deepcopy(repair),
               'in_game_validation': 'not_performed'}
        committed = False
        try:
            _safe_paths(source, target, source_root, output_root, selected_source, selected_output)
            if not target.is_file():
                row.update(state='output_not_present_not_repaired', output_file_changes='none')
                summary['output_not_present'] += 1; rows.append(row); continue
            before = target.read_bytes(); row['output_sha256_before'] = _digest(before)
            if before not in (raw, prepared):
                raise ValueError('existing output DDS differs from both source and prepared header; output preserved')
            if source.read_bytes() != raw:
                raise ValueError('source DDS changed during header inspection; output preserved')
            if before == prepared:
                row['state'] = 'already_normalized'
            else:
                if target.read_bytes() != before:
                    raise ValueError('output DDS changed during header inspection; output preserved')
                atomic_bytes(target, prepared)
                committed = True; row['state'] = 'output_header_count_repaired'
            final = target.read_bytes()
            if final != prepared or source.read_bytes() != raw:
                raise ValueError('DDS header normalization failed final source/output verification')
            row.update(output_sha256=_digest(final), source_unchanged=True,
                       byte_identical=False,
                       output_file_changes='none; expected normalized header already present' if before == prepared
                           else 'only mip-count header u32 at offset 28',
                       compressed_payload_byte_identical=True, expected_output_bytes_verified=True)
            row['metadata_records_updated'] = _metadata_updates(report, target, facts)
            summary['already_normalized' if row['state'] == 'already_normalized' else 'repaired'] += 1
        except (OSError, ValueError) as error:
            row.update(state='normalization_failed', reason=str(error),
                       output_file_changes='normalization write attempted; final verification failed' if committed else 'none')
            summary['failed'] += 1
            message = str(source.relative_to(source_root)) + ': DDS header normalization not completed: ' + str(error)
            problems = report.setdefault('problems', [])
            if message not in problems: problems.append(message)
            try: log(message)
            except Exception: pass
        rows.append(row)
    summary['state'] = 'requires_attention' if summary['failed'] else 'recorded_output_header_checks'
    report['dds_header_normalization'] = summary
    return summary


def install(folder):
    """Wrap after copy/recovery passes, before final face audit and reporting."""
    if getattr(folder, '_dds_header_normalization_patch', None) == PATCH_VERSION: return
    original = folder.convert_folder

    @functools.wraps(original)
    def convert_folder(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs); bound.apply_defaults()
        report = original(*args, **kwargs)
        process(report, bound.arguments['src'], bound.arguments['dst'], bound.arguments.get('log', lambda text: None))
        from gmf_report import save_intermediate
        save_intermediate(report, bound.arguments['dst'])
        return report

    folder.convert_folder = convert_folder
    folder._dds_header_normalization_patch = PATCH_VERSION
