"""Preserve native 2K26 models and repair narrowly supported material links.

This module extends the recovered folder workflow. Native model bytes never
pass through the 2K25 skeleton, weight, model, or physics writers. A native
reader must successfully read a model before its omitted WDF/YWA companions
are restored. Their preservation does not establish physics compatibility.
"""
import functools
import hashlib
import inspect
import json
import os
from pathlib import Path
import shutil
import struct

PATCH_VERSION = 'native-2k26-preservation-and-material-links-1'
NATIVE_PHYSICS_SUFFIXES = ('.wdf', '.hair_ywa', '.hair_corr_ywa',
                          '.other_ywa', '.other_corr_ywa')
_STUB = b'MTL!' + struct.pack('<II', 4, 1) + bytes(24)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _safe_name(name):
    if (not name or name in ('.', '..') or name[-1] in ' .'
            or any(c in name for c in '/\\<>:"|?*') or any(ord(c) < 32 for c in name)):
        raise ValueError(f'unsafe material name: {name!r}')
    return name


def read_native_library(data):
    """Read only the exact v6 empty-stub layout; reject other material formats.

    The old reader's ``mats is None`` result also covers unknown block
    versions, so it must not be used to establish this format.
    """
    if len(data) < 16 or data[:4] != b'MTLs':
        raise ValueError('not a complete native material library')
    version, table_size = struct.unpack_from('<II', data, 4)
    if version != 6:
        raise ValueError(f'native 2K26 requires a v6 stub library, found v{version}')
    table_end = 12 + table_size
    count_offset = (table_end + 3) & ~3
    if count_offset + 4 > len(data):
        raise ValueError('native material string table is truncated')
    count = struct.unpack_from('<I', data, count_offset)[0]
    hashes_offset = count_offset + 4
    offsets_offset = hashes_offset + count * 8
    blocks_offset = (offsets_offset + count * 2 + 3) & ~3
    if blocks_offset + count * len(_STUB) != len(data):
        raise ValueError('native material tables or stub blocks have an unsupported length')
    if any(data[blocks_offset + i * 36:blocks_offset + (i + 1) * 36] != _STUB
           for i in range(count)):
        raise ValueError('native material block is not an exact empty v4 stub')
    names_blob = data[12:table_end]
    entries = []
    seen = set()
    for index in range(count):
        offset = struct.unpack_from('<H', data, offsets_offset + index * 2)[0]
        if offset >= len(names_blob) or (offset and names_blob[offset - 1] != 0):
            raise ValueError('native material name offset is not a string boundary')
        end = names_blob.find(b'\0', offset)
        if end < 0:
            raise ValueError('native material name is not NUL terminated')
        try:
            name = _safe_name(names_blob[offset:end].decode('utf-8'))
        except UnicodeDecodeError as error:
            raise ValueError('native material name is not UTF-8') from error
        if name in seen:
            raise ValueError(f'duplicate native material name: {name!r}')
        seen.add(name)
        entries.append({'name': name, 'name_offset': 12 + offset,
                        'name_bytes': end - offset,
                        'hash_offset': hashes_offset + index * 8,
                        'path_hash': struct.unpack_from('<Q', data, hashes_offset + index * 8)[0]})
    return entries


def path_hash(path):
    """Match the bundled MTLS writer's lowercase virtual-path FNV-1a hash."""
    value = 0xcbf29ce484222325
    for char in path.replace('\\', '/').lower():
        value ^= ord(char) & 0xff
        value = value * 0x100000001b3 & 0xffffffffffffffff
    return value


def game_folder(path):
    """Use the innermost Characters component, matching the bundled writer.

    This helper accepts the library filename. The original material writer
    receives its parent directory and searches for the last /Characters/.
    Outer archive/output folders can also be named Characters; including
    those would disagree with the emitted material and texture hashes.
    """
    parts = Path(str(path).replace('\\', '/')).parts
    for index in range(len(parts) - 2, -1, -1):
        if parts[index].casefold() == 'characters':
            return '/'.join(('Characters', *parts[index + 1:-1]))
    return None


def repair_native_library(data, used_names, jmtl_names, destination_game_folder):
    """Patch only native table name-case bytes and local JMTL path hashes.

    Return bytes and a report without writing files. No JMTL is decoded or
    reserialized. Missing, ambiguous, or unsafe names fail before any write.
    """
    entries = read_native_library(data)
    requested = sorted({_safe_name(name) for name in used_names if name != 'lambert1'})
    names = {entry['name']: entry for entry in entries}
    buckets = {}
    for name in names:
        buckets.setdefault(name.casefold(), []).append(name)
    if any(len(candidates) > 1 for candidates in buckets.values()):
        raise ValueError('native material definitions collide by case')
    for name in requested:
        if sum(other.casefold() == name.casefold() for other in requested) > 1:
            raise ValueError(f'native mesh material bindings collide by case: {name!r}')
    file_buckets = {}
    for filename in jmtl_names:
        if Path(filename).name != filename or not filename.lower().endswith('.jmtl'):
            continue
        file_buckets.setdefault(filename[:-5].casefold(), []).append(filename)
    if destination_game_folder is None:
        raise ValueError('native material output is outside a Characters folder')
    virtual = destination_game_folder.replace('\\', '/').strip('/')
    if not virtual.lower().startswith('characters/') or '..' in virtual.split('/'):
        raise ValueError('unsafe native material game path')
    result = bytearray(data)
    aliases = []
    remapped = []
    # Validate every referenced material, including unused library entries:
    # the unchanged native library still contains their runtime references.
    for entry in entries:
        name = entry['name']
        candidates = file_buckets.get(name.casefold(), [])
        if len(candidates) != 1:
            kind = 'missing' if not candidates else 'ambiguous'
            raise ValueError(f'{kind} native JMTL for material {name!r}')
        target_hash = path_hash(virtual + '/Materials/' + candidates[0])
        if entry['path_hash'] != target_hash:
            struct.pack_into('<Q', result, entry['hash_offset'], target_hash)
            remapped.append({'material': name, 'jmtl': candidates[0],
                             'before': entry['path_hash'], 'after': target_hash})
    for requested_name in requested:
        if requested_name in names:
            continue
        candidates = buckets.get(requested_name.casefold(), [])
        if len(candidates) != 1:
            kind = 'missing' if not candidates else 'ambiguous'
            raise ValueError(f'{kind} native material binding: {requested_name!r}')
        source_name = candidates[0]
        entry = names[source_name]
        # ASCII case-only edits preserve all table offsets and unknown bytes.
        if not source_name.isascii() or not requested_name.isascii():
            raise ValueError('native material case repair requires ASCII names')
        encoded = requested_name.encode('ascii')
        if len(encoded) != entry['name_bytes']:
            raise ValueError('native material case alias changes string length')
        start = entry['name_offset']
        result[start:start + len(encoded)] = encoded
        aliases.append({'source': source_name, 'binding': requested_name})
    repaired = bytes(result)
    read_native_library(repaired)
    return repaired, {'materials': [{'name': e['name']} for e in read_native_library(repaired)],
                      'material_binding_aliases': aliases,
                      'material_path_hash_repairs': remapped,
                      'bytes_changed': sum(a != b for a, b in zip(data, repaired))}


def _overlap(a, b):
    return a == b or a in b.parents or b in a.parents


def require_separate_output(src, dst):
    """Prevent the recovered copy workflow from modifying its source tree."""
    source = Path(src).resolve()
    destination = Path(dst).resolve()
    if _overlap(source, destination):
        raise ValueError('output must be outside and separate from the source folder')
    if destination.exists():
        for directory, dirs, files in os.walk(destination):
            for name in dirs + files:
                candidate = Path(directory) / name
                if candidate.is_symlink() and _overlap(source, candidate.resolve()):
                    raise ValueError('output contains a link into the source folder')
    return source, destination


def _target(output_root, relative, source_root):
    target = output_root / relative
    resolved = target.resolve()
    if not resolved.is_relative_to(output_root.resolve()) or resolved.is_relative_to(source_root):
        raise ValueError('mapped native output leaves the separate output folder')
    return target


def _copy_required(source, target, report):
    """Copy required native assets even when optional generic copying is off."""
    target.parent.mkdir(parents=True, exist_ok=True)
    if not target.exists() or sha256(source) != sha256(target):
        shutil.copy2(source, target)
        report['copied'] = report.get('copied', 0) + 1
    return {'source': str(source), 'output': str(target), 'bytes': source.stat().st_size,
            'sha256': sha256(source), 'output_sha256': sha256(target)}


def _models(source):
    jobs = sorted(path for path in source.rglob('*')
                  if path.is_file() and path.suffix.lower() in ('.mcd', '.mdl'))
    mcd_stems = {str(path.with_suffix('')).casefold() for path in jobs if path.suffix.lower() == '.mcd'}
    return [path for path in jobs if path.suffix.lower() != '.mdl'
            or str(path.with_suffix('')).casefold() not in mcd_stems]


def process_native_models(module, source, output_root, plan, report, log=print):
    """Audit/copy native sources after the original converter has finished."""
    preserved = repaired_libraries = 0
    for source_model in _models(source):
        if module.mcd.mdl_version(str(source_model)) != module.vc.VERSION_2K26:
            continue
        relative = os.path.relpath(source_model, source)
        mapped = module._mapped(relative, plan)
        if mapped is None:
            continue
        target = _target(output_root, mapped, source)
        model_report = {'source': str(source_model), 'output': str(target),
                        'source_version': module.vc.VERSION_2K26,
                        'status': 'preserved_2k26', 'notes': [], 'problems': [],
                        'verification_scope': 'native_reader_and_byte_preservation',
                        'in_game_validation': 'not_performed', 'repairs': []}
        try:
            # Do not call the 2K25 verifier, which recomputes converted weights.
            model = module.vc.read_model(str(source_model), with_shapes=True)
            if model.version != module.vc.VERSION_2K26:
                raise ValueError('native reader disagrees with source 2K26 version')
            copied = _copy_required(source_model, target, report)
            if copied['sha256'] != copied['output_sha256']:
                raise ValueError('native model bytes were not preserved')
            facts = {'source_sha256': copied['sha256'], 'output_sha256': copied['output_sha256'],
                     'byte_identical': True, 'mesh_count': len(model.meshes),
                     'bone_count': len(model.bones),
                     'vertices': sum(mesh.num_verts for mesh in model.meshes),
                     'triangles': sum(len(mesh.triangles) for mesh in model.meshes),
                     'geometry_weights_bones_and_embedded_streams': 'byte_identical'}
            model_report['facts'] = facts
            companions = []
            for suffix in NATIVE_PHYSICS_SUFFIXES:
                sidecar = source_model.with_suffix(suffix)
                if not sidecar.is_file():
                    continue
                sidecar_target = _target(output_root, os.path.relpath(target.with_suffix(suffix), output_root), source)
                companion = _copy_required(sidecar, sidecar_target, report)
                companion['status'] = 'preserved_unverified'
                companion['compatibility'] = 'not_established'
                companions.append(companion)
                omitted = os.path.relpath(sidecar, source) + ' (2K25 physics data)'
                if omitted in report.get('left_out', []):
                    report['left_out'].remove(omitted)
            source_ycl = source_model.with_suffix('.ycl')
            if source_ycl.is_file() and hasattr(module, 'ycl_version'):
                ycl_source_version = module.ycl_version(str(source_ycl))
                ycl_target = _target(output_root, os.path.relpath(target.with_suffix('.ycl'), output_root), source)
                if ycl_source_version == 26:
                    companion = _copy_required(source_ycl, ycl_target, report)
                    companion.update(status='preserved_unverified', compatibility='not_established',
                                     source_version=ycl_source_version)
                else:
                    companion = {'source': str(source_ycl), 'output': str(ycl_target),
                                 'source_version': ycl_source_version,
                                 'status': 'original_physics_conversion_unverified',
                                 'compatibility': 'not_established',
                                 'source_sha256': sha256(source_ycl),
                                 'output_sha256': sha256(ycl_target) if ycl_target.is_file() else None}
                    model_report['notes'].append('A non-2K26 YCL companion followed the original '
                                                 'formatter physics handling; native-model '
                                                 'acceptance does not validate that conversion.')
                companions.append(companion)
            model_report['native_physics_companions'] = companions
            for suffix in ('.hpl', '.ctg'):
                sidecar = source_model.with_suffix(suffix)
                if sidecar.is_file():
                    _copy_required(sidecar, _target(output_root, os.path.relpath(
                                   target.with_suffix(suffix), output_root), source), report)
            model_report['notes'].append('Native model bytes preserved; geometry, weights, bones, '
                                         'and embedded physics were not rewritten. Native physics '
                                         'compatibility and in-game behavior remain unverified.')
            used = {module.materials.clean_name(name) for mesh in model.meshes
                    for name, _, _ in mesh.face_groups}
            source_library = source_model.with_suffix('.mtls')
            target_library = _target(output_root, os.path.relpath(target.with_suffix('.mtls'), output_root), source)
            material_report = {'source': str(source_library), 'output': str(target_library),
                               'status': 'preserved_native_2k26', 'notes': [], 'materials': [],
                               'jmtl_payloads': 'byte_identical', 'problems': []}
            try:
                # Preserve a supplied native table even when its reference
                # layout/payloads cannot be audited. The later missing-data
                # pass may restore verified dependencies; never drop the table.
                if source_library.is_file():
                    _copy_required(source_library,target_library,report)
                original = source_library.read_bytes()
                entries = read_native_library(original)
                materials_dir = source_library.parent / 'Materials'
                jmtls = sorted(path.name for path in materials_dir.iterdir()
                               if path.is_file() and path.suffix.lower() == '.jmtl')
                repaired, details = repair_native_library(original, used, jmtls,
                                                          game_folder(target_library))
                # Validate and copy the whole referenced JMTL set before changing the library.
                file_index = {name.casefold(): name for name in jmtls}
                payloads = []
                for entry in entries:
                    filename = file_index[(entry['name'] + '.jmtl').casefold()]
                    source_jmtl = materials_dir / filename
                    if source_jmtl.stat().st_size == 0:
                        raise ValueError(f'empty native JMTL: {filename}')
                    payloads.append(_copy_required(source_jmtl,
                                    _target(output_root, os.path.relpath(target.parent / 'Materials' / filename,
                                                                        output_root), source), report))
                target_library.parent.mkdir(parents=True, exist_ok=True)
                target_library.write_bytes(repaired)
                material_report.update(details)
                material_report['jmtl_inventory'] = payloads
                material_report['source_sha256'] = hashlib.sha256(original).hexdigest()
                material_report['output_sha256'] = sha256(target_library)
                if repaired != original:
                    material_report['status'] = 'repaired_native_2k26_bindings'
                    model_report['repairs'].append('native_material_table_bindings')
                    repaired_libraries += 1
            except (OSError, ValueError, struct.error) as error:
                problem = 'native material library: ' + str(error)
                material_report['status'] = 'unsupported_native_materials'
                material_report['problems'].append(problem)
                model_report['problems'].append(problem)
            report['materials'].append(material_report)
            model_report['verify'] = 'fail' if model_report['problems'] else 'pass'
            preserved += 1
            log(f'  {relative}: native 2K26 model bytes preserved; material links audited')
        except Exception as error:
            model_report['status'] = 'failed_native_2k26'
            model_report['verify'] = 'fail'
            model_report['problems'].append('native preservation audit failed: ' + str(error))
        report['models'].append(model_report)
        for problem in model_report['problems']:
            report['problems'].append(relative + ': ' + problem)
    report['native_2k26_models_preserved'] = preserved
    report['native_2k26_material_libraries_repaired'] = repaired_libraries
    if preserved:
        report['warnings'].append('Native 2K26 model and physics preservation does not validate '
                                  'an older port in game. Unsupported skeleton, weight, and physics '
                                  'repairs were not inferred.')
    report['native_2k26_patch'] = PATCH_VERSION


def patch_folder_converter(module):
    """Install outermost, preserving all original folder arguments and gates."""
    if getattr(module, '_native_2k26_patch', None) == PATCH_VERSION:
        return
    original = module.convert_folder

    @functools.wraps(original)
    def convert_folder(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs)
        bound.apply_defaults()
        source, destination = require_separate_output(bound.arguments['src'], bound.arguments['dst'])
        slot = bound.arguments['slot']
        if slot and any(module.mcd.mdl_version(str(path)) == module.vc.VERSION_2K26
                        for path in _models(source)):
            raise ValueError('Existing 2K26 repairs must retain their original folder layout. '
                             'Select "Keep the mod\'s own folder name"; native JMTL texture '
                             'hashes cannot yet be remapped safely to another wrestler.')
        plan = module._slot_plan(str(source), slot)[1] if slot else {}
        report = original(*args, **kwargs)
        process_native_models(module, source, Path(report['output']), plan, report,
                              bound.arguments['log'])
        report['conversion_completeness'] = ('incomplete' if report['problems']
                                              else 'structural_checks_only')
        report['in_game_validation'] = 'not_performed'
        from gmf_report import save_intermediate
        save_intermediate(report,destination)
        return report

    module.convert_folder = convert_folder
    module._native_2k26_patch = PATCH_VERSION


def install(folder_module=None):
    """Call after existing runtime folder patches, before launching the GUI."""
    if folder_module is None:
        from gmf import folder as folder_module
    patch_folder_converter(folder_module)
