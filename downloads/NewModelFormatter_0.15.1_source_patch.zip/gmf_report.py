"""Always attempt a complete atomic report, including conversion failures.

Keep the original root filename, mirror beside converted output, and expose
actual saved paths to the UI. A denied output directory uses a Temp fallback.
"""
from datetime import datetime, timezone
import builtins
import functools
import inspect
import io
import json
import os
from pathlib import Path
import tempfile
import threading

_lock=threading.Lock()
_last_path=None
_state=threading.local()


def last_report_path():
    with _lock:return _last_path


def _set_last(path):
    global _last_path
    with _lock:_last_path=str(path) if path is not None else None


def _atomic(path, report):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    data=json.dumps(report,indent=2,default=str)
    handle,name=tempfile.mkstemp(prefix='.conversion-report-',suffix='.tmp',dir=path.parent)
    stage=Path(name)
    try:
        with os.fdopen(handle,'w',encoding='utf-8') as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        os.replace(stage,path)
    finally:
        if stage.exists():stage.unlink()


def save_intermediate(report, destination):
    """Standalone helper support; full conversions commit once at the end."""
    if getattr(_state,'deferred',False):
        _state.checkpoint=report
    else:
        path=Path(destination).absolute()/(os.path.basename(report['source'])+' - conversion report.json')
        _atomic(path,report)


def save_report(report, destination, *, safe_destination=True, fallback_root=None):
    """Record only paths actually saved; never write in unsafe source output."""
    source_name=os.path.basename(os.path.abspath(report.get('source') or 'conversion')) or 'conversion'
    filename=source_name+' - conversion report.json'
    candidates=[];errors=[]
    if safe_destination:
        try:
            destination=Path(destination).resolve()
            candidates.append(destination/filename)
        except OSError as exc:
            errors.append({'path':str(destination),'error':str(exc)})
        else:
            try:
                output=Path(report.get('output') or destination).resolve()
                if output.is_relative_to(destination) and output!=destination:
                    candidates.append(output/filename)
            except OSError as exc:
                errors.append({'path':str(report.get('output')),'error':str(exc)})
    report['report_paths']=[]
    for path in candidates:
        trial={**report,'report_paths':[*report['report_paths'],str(path)]}
        trial['report_path']=trial['report_paths'][0]
        try:_atomic(path,trial)
        except OSError as exc:errors.append({'path':str(path),'error':str(exc)})
        else:
            report.update(trial)
    if not report['report_paths']:
        root=Path(fallback_root) if fallback_root is not None else Path(tempfile.gettempdir())/'NewModelFormatter'/'Reports'
        path=root/(source_name+' - '+os.urandom(6).hex()+' - conversion report.json')
        report['report_paths']=[str(path)];report['report_path']=str(path)
        report['report_fallback']='output report location unavailable; saved in Temp'
        report['report_save_errors']=errors
        _atomic(path,report)
    else:
        if errors:report['report_save_errors']=errors
        # Update copies with the same complete path list, so the root copy can
        # point to the actual folder opened by the original GUI.
        for path in report['report_paths']:
            try:_atomic(path,report)
            except OSError:pass  # The initial atomic copy remains complete.
    _set_last(report['report_path'])
    return report['report_paths']


def install(folder_module=None, *, fallback_root=None):
    if folder_module is None:
        from gmf import folder as folder_module
    if getattr(folder_module,'_durable_report_patch',False):return
    original=folder_module.convert_folder
    legacy_open=getattr(folder_module,'open',builtins.open)

    class CheckpointBuffer(io.StringIO):
        def __exit__(self,*args):
            try:_state.checkpoint=json.loads(self.getvalue())
            except (ValueError,TypeError):pass
            return super().__exit__(*args)

    def report_open(file, mode='r', *args, **kwargs):
        # The original folder function writes its report before repair wrappers
        # finish. Buffer only that write, leaving all model/texture I/O intact.
        if (getattr(_state,'deferred',False) and mode=='w'
                and isinstance(file,(str,os.PathLike))
                and os.fspath(file).endswith(' - conversion report.json')):
            return CheckpointBuffer()
        return legacy_open(file,mode,*args,**kwargs)

    folder_module.open=report_open

    @functools.wraps(original)
    def convert_folder(*args,**kwargs):
        bound=inspect.signature(original).bind(*args,**kwargs);bound.apply_defaults()
        source,destination=bound.arguments['src'],bound.arguments['dst']
        started=datetime.now(timezone.utc).isoformat()
        safe=False;_set_last(None)
        previous=getattr(_state,'deferred',False)
        previous_checkpoint=getattr(_state,'checkpoint',None)
        _state.checkpoint=None
        try:
            from gmf_2k26_repair import require_separate_output
            require_separate_output(source,destination);safe=True
            _state.deferred=True
            report=original(*args,**kwargs)
        except Exception as exc:
            report=dict(getattr(_state,'checkpoint',None) or {})
            report.setdefault('source',os.path.abspath(source));report.setdefault('output',os.path.abspath(destination))
            report.setdefault('models',[]);report.setdefault('materials',[]);report.setdefault('warnings',[])
            report['problems']=[*report.get('problems',[]),str(exc)]
            report.update({'status':'failed',
                    'conversion_completeness':'incomplete','in_game_validation':'not_performed',
                    'conversion_error':{'type':type(exc).__name__,'message':str(exc)},
                    'started_at_utc':started,'finished_at_utc':datetime.now(timezone.utc).isoformat()})
            try:
                paths=save_report(report,destination,safe_destination=safe,fallback_root=fallback_root)
                bound.arguments['log']('Report saved: '+paths[0])
            except Exception as report_error:
                try:bound.arguments['log']('Report could not be saved at output or Temp: '+str(report_error))
                except Exception:pass
            raise
        finally:
            _state.deferred=previous
            _state.checkpoint=previous_checkpoint
        report['started_at_utc']=started
        report['finished_at_utc']=datetime.now(timezone.utc).isoformat()
        report.setdefault('status','completed_with_problems' if report.get('problems') else 'completed')
        paths=save_report(report,destination,safe_destination=safe,fallback_root=fallback_root)
        try:bound.arguments['log']('Report saved: '+paths[0])
        except Exception:pass
        return report

    folder_module.convert_folder=convert_folder
    folder_module._durable_report_patch=True
