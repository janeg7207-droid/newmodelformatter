"""Bounded, read-only material dependency reader for supported 2K26 shaders."""
import hashlib
from pathlib import Path
import struct
from gmf_jmtl_fields import TEXTURE_FIELDS, SOURCE_SHA256


class Table:
    def __init__(self,data,position):
        self.data=data;self.position=position
        if position<8 or position+4>len(data):raise ValueError('JMTL table outside file')
        vtable=position-struct.unpack_from('<i',data,position)[0]
        if vtable<8 or vtable+4>len(data):raise ValueError('JMTL vtable outside file')
        size,self.size=struct.unpack_from('<HH',data,vtable)
        if size<4 or size%2 or vtable+size>len(data) or self.size<4 or position+self.size>len(data):
            raise ValueError('JMTL table is truncated')
        self.offsets=struct.unpack_from('<'+'H'*((size-4)//2),data,vtable+4)
        if any(off and (off<4 or off>=self.size) for off in self.offsets):
            raise ValueError('JMTL field offset leaves table')

    def field(self,index,width):
        if index>=len(self.offsets) or not self.offsets[index]:return None
        offset=self.offsets[index]
        if offset+width>self.size:raise ValueError('JMTL field leaves table')
        return self.position+offset

    def child(self,index):
        position=self.field(index,4)
        if position is None:return None
        offset=struct.unpack_from('<I',self.data,position)[0]
        if not offset:raise ValueError('JMTL child pointer is null')
        return Table(self.data,position+offset)

    def number(self,index,kind,default=None):
        position=self.field(index,struct.calcsize(kind))
        return default if position is None else struct.unpack_from(kind,self.data,position)[0]


def inspect_material(data):
    if len(data)<8 or data[4:8]!=b'Mate':raise ValueError('not a recognizable 2K26 JMTL')
    root=Table(data,struct.unpack_from('<I',data,0)[0])
    shader=root.number(1,'<H',0)
    if not 1<=shader<=0x1d:raise ValueError('JMTL shader discriminator is unsupported')
    payload=root.child(2)
    if payload is None:raise ValueError('JMTL material payload is missing')
    fields=TEXTURE_FIELDS.get(shader)
    refs=[]
    def collect(table,mapping):
        for field,key in mapping.items():
            value=table.number(field,'<Q')
            if value not in (None,0,0xffffffffffffffff):refs.append({'field':key,'hash':value})
    if fields is not None:collect(payload,fields)
    hair_type=None
    if shader==0x16:
        hair_type=payload.number(0,'<H',1)
        inner=payload.child(1)
        if hair_type==3 and inner is not None:collect(inner,{14:'nrMap@ref',15:'colorMap@ref'})
    result={'shader_byte':shader,'hair_type':hair_type,'texture_references':refs,
            'texture_schema_supported':fields is not None,'schema_source_sha256':SOURCE_SHA256,
            'shader_and_texture_values':'preserved; read-only inspection'}
    if shader in (0x12,0x1a):
        values={r['field']:r['hash'] for r in refs}
        check={'scope':'reference-writer hash comparison; in-game asset resolution not verified',
            'color_ref':values.get('colorMap@ref'),'normal_ref':values.get('nrMap@ref'),
            'required_color_and_normal_refs_present':all(key in values for key in ('colorMap@ref','nrMap@ref'))}
        if shader==0x12:
            check.update(reference_normal_ref=0xefbc052176b84e95,
                reference_normal_match=values.get('nrMap@ref')==0xefbc052176b84e95)
        else:
            check.update(reference_color_ref=0x7357eeb9075df170,reference_normal_ref=0xba65216dd64f5c78,
                reference_texture_pair_match=values.get('colorMap@ref')==0x7357eeb9075df170 and values.get('nrMap@ref')==0xba65216dd64f5c78)
        check['custom_or_legacy_refs']='preserved; verify actual textures if reference hashes differ'
        result['face_texture_check']=check
    return result


def inspect_written_materials(report):
    """Record actual emitted dependencies; never modify shaders or infer assets."""
    rows=[];directory=Path(report['output']).parent/'Materials'
    for material in report.get('materials',[]):
        name=material['name']
        if not name or any(char in name for char in '/\\\x00'):
            rows.append({'name':name,'state':'unsafe_material_name_not_inspected'});continue
        path=directory/(name+'.jmtl');row={'name':name,'file':str(path)}
        try:
            data=path.read_bytes();row.update(inspect_material(data))
            row.update(state='payload_inspected',sha256=hashlib.sha256(data).hexdigest())
        except (OSError,ValueError,struct.error) as error:
            row.update(state='payload_not_inspected',reason=str(error))
        rows.append(row)
    report['written_material_payload_audit']=rows
