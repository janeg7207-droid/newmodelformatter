"""Lossless supplied Flip HPL for one exact verified legacy model pair.

This module restores existing authored coverage; it never creates new mask IDs.
The caller must verify the actual current source/output paired Body/Head remap,
triangle topology and index domains before using the profile through the original
parser, mask filter, writer and verifier. Already-native inputs are excluded by
that caller. Visual boot coverage still needs an in-game check.
"""
import base64
import hashlib
import zlib

PROFILE_VERSION = 'verified-supplied-flip-gordon-hpl-1'
MODEL_SHA256 = '017a44865267d32d99b639d5b245d5ea3afde60f3c46852721420e18c3e1b2ec'
MODEL_BYTES = 1204548
BASE_SHA256 = '6670af89dc43b0d95e44d70f715bb9033cf449010f3430de2978fd63884b495c'
BASE_BYTES = 6043100
INVALID_HPL_SHA256 = '57abd17dd82782bcd4c1509c311d3f70227af707e7975a2e1b3fcbf1eae2c3dd'
INVALID_HPL_BYTES = 81408
SUPPLIED_HPL_SHA256 = '8a280ab3add1727a763796e9556d7a99b55cfae8ead98448fc82fd2183b927fc'
SUPPLIED_HPL_BYTES = 70188

# Exact bytes of the newly supplied 931_Attire.hpl, compressed losslessly.
_PAYLOAD = (
    b'c-rmUV-px><G115v2EM7t)?;C*tXRaG1?@JZL^J?Hnwfs_H%TekMZA~Ic7h=Ucb5a)mgr3#S|5*lui-CQ@TXW692s`m8nra?0@e@B|A0m6Cy;y7$'
    b'HKu4;3QB2R`zN&wSx4-v|*pM2P<pl2C*u3}FdJcp?yyNJJ(IQHe%$Vi1#9#3l|2Nkn3jkd$O3Cj}`<MQYNJiOggnE7{0S4sw!<+~grI`N&TJ3Q~x'
    b'|6rm`^C{77VQi{@)p)BPnPbDf-g{oAeIyI<CEo#$%hBTrvO=wCpn$v=ow4ya_XiGcV(}9k3qBC9SN;kUGgP!!FH+|?!Kl<|%1NfO=_?6!n$RGwYg'
    b'rN*$I3pOzD1PS;Ml*)7{K+`RGl7XrVlq>h$~2}kgPF`?HglNEJm#~2g)Cw*OIXS>ma~GDtYS5P@i%K&%R1JxfsJfpGh5ioHny{ao&3YU>|!^2*vm'
    b'flbAW>!;xI=z$}x^}f|H!$G-o)=InHx|i(KL|SGdYGu5*K%+~PKOxXV56^MHpu;xSKn$}^txf|tDFHE(#!JKpnwk9^`YU--&5LWHqdLK2G5gdr^9'
    b'2u}ne5{bw}Au7>`P7Goai`c{=F7b#@0uqvl#3Ugp$w*ELQj&_)q#-ToNKXbbl8MY@AuHL)P7ZRCi`?WPFZsw%0SZ!x!W5w>#b`+@TGNKMw4*&8=t'
    b'w6z(}k{dqdPt5NiTZShraZqKR+>mpZSGf`Hg`LVlYD($}omAf{~2kcm7~BV;IYyjAJ|#n8+k1Gli*4V>&aK$t-3whq=sSJ_}gLA{MiRr7UAPD_F@'
    b'YR`VBsvxc>-V?9^6$~CTYgPYvqHg~woJ?`^>hdkmjPk72Rp7Vm2yy7))c*{H9^MQ|i;xk|P$~Qu|wEjm(LJ^uUge4r|i9kdm5t%4NB^uF*K}=#1n'
    b'>fTJ9`Q*)LK2afBqSvn$w@&<QjwZ8q$M5c$v{Rjk(n%HB^%kvK~8d!n>^$tANeUjK?+frA{3<<#VJ8aN>Q3Jl%*X1UFzRaf$ynEB`Q;es#K#oHK<'
    b'7~YEy?F_>sEQqdpC2NFy54gr+p3IW1^OD_YZrwzQ)?9q33WI@5)&bfY^x=t(bn(}%wFqdz|}fS>t=U-^xJ3}P@t7|Jk)GlG$f;&=XFG-DXcpNwNX'
    b'6PU;(CNqVpOk+ATn8_?=Gl#j%V?GO5$RZZAgrzKFIV)JnDpvCsf3t?QtYbYJ*vKX}vxTi}V>>(8$v^zdE_Snrz3gK@2RO(f4s(Q~9OF1AILRqabB'
    b'42=<2)C*$R#dwg{xfSIybn<EpBs%yWHbG4|vEU9`l5!JmWbpc*!eX^M<#)<2@hv$R|GYg|B@3?}s&<{S%T<geDAO2}gJ$5RphkCJIrBMs#8jlUT$'
    b'i4snS`d=ik5L?k8&Nl8X>Qjn5Vq$Uk%Nk@7zkdaJeCJR}~Ms{+LlU(E`4|&N)ehN^KLKLP5MJYycN>Gwgl%@=2DMxv}qXOSkkxEpi3RS5_b!t$PT'
    b'GXZvKX5;iZ^%O)@t7w(<r&X;!AoB8nm4@V9q;+TM?UeHuYBWwk$pQt5t=ZBB^=?2Ktv)DnJ7dh8qtYCOkxq6IK(492}wj^l8}^SBqs$aNkwYXkd}'
    b'0$Cj%MDL}s#(m26}u2RX?_Zt{?qeB`G91t~;ficpkd6sH6wDMe|@P?vhtrvVLVL}QxJlx8%i1ubbsYueD3cC@Dh9qB}8y3mzwbf*VB=|yk)(3gJn'
    b'=O+d*j`2)jB9oZR6s9tb>C9jzvzW~s<}#1@EMOsvSj-ZZvW(@dU?r<q&0qY@8rHIo^=x1xo7l`2wz7@w>|iJV@GraA%^vo$kNq6rAcr{25sq?<<D'
    b'B3mr#Q_S&T@|PT;L*?xXcx<a*gZU;3l`Y%^mJ?kNZ5}A&+>>6Q1&n=e*!0uXxQH-tvz3eBdLW_{<l+@{JHt?23?tA~azLOE|(4frvyRGEs<1G@=u'
    b'On8YGBafnMi;*)@cBqA|MNJ=u2lY*3_A~k79OFGh%fsAA#Gg-(=HnNk0oa7=mdB{sX@>76<6rwOiC`vJkQ-YF|qBLbFOF7E(9ToVVid3R9Rj5ies'
    b'#AlS)S@<Z_<<j(OFin-fQB@pF->SnGn&(amb9WZZD>n7+S7rKbfPm|=t?)b(}SM$qBni$OF#Pa69f2}U-*^Z7|0+7GlZcGV>lxi$tZs34@NVFvHZ'
    b'z6#xsG5Oky%qn94M!GlQATVm5P_%RJ_@fQ2k#F-us=GM2M~m8@blfAKeKSj#%rvw@9lVl!LV$~LyMgPr`tzwBZ+d)Ui9_H%%P9O5uXILa}ObApqc'
    b';xuPC%Q?<-fs0(?GFQ0DHLi1mo80>EOvZL5DM3j}QJON8r5xq?jtYEFMJiF5DpaK!)u};EYEhdy{77BuQJ)4hq!Ep2LQ|U2oEEgC6|HGQTiVfqj&'
    b'!0kUFb?Ty3>Q6^rAO?=u1EP^AiL3nP2#o-x$as1~Y`A3}ZMW7|AI9U^HVG%b$#6JQJA6BqlS3sZ3)!GnmON<}jCe%x3`$S;S(Nu#{yiX9X)+#cKZ'
    b'IZ`QDub*yIt8`;EWwy>3LY-a~M`G<em#cuYnmwoK#00%k5VUBQ=V;tuMCppDw&Ty7<oaX`;xx{6zaFuIZ=LR>q#cl3zmwVjj0S|e^W1jGoXFTTxF'
    b'L}jl-td-pyypWS`NU_w@Re_bh~o|-B%ugR7{U^c@I)XYk%&wbq7seh#2_ZIh)o>g5|8*KAR&oJOcIikjO3&sC8<bF8q$)E^kg6-naE5QvXYJL<RB'
    b'-x$W0#dl8^ippdf`POc9DwjN+7_B&8@#8Ol<Q@_a`HzNaFUs7w{AQjO}=peD7bO&xyVN9t0K`ZS;+jc800n$nEsw4f!eXiXd1(vJ3Ypd+2=Oc%P+'
    b'jqdcIC%x!RANtad{`|xMe&!c`<u?X0h`|hDD8m@e2u3oB-}!^ljA1N)GLG>~U?P*4%oL_Fjp@u_CbO8$9Og2Q`7B@|i&)GOma>fHtY9UpSj}Jj%^'
    b'KFSj`eI{Bb(UF7PhjD?d)JD|L`xn*v%gHvXA{7;2?)M%n^=qjN_c(B&Rsd8P0N!^IYH}m$=Lou5yj*+~6j+xXm5za*z8w;31EA%oCpSjOV=IC9in'
    b'R8{YDc_k7?ZpZLrdzVeL_aqXXwgd#Ly2unD^6M=|CA~I2kN;IMqgP6o3HgSkcJmQmpgd`#{Nk~dEl9Pgzq#`wGNJ~1>lYxw6A~RXYN;a~SgPi0dH'
    b'+jfQKJrt5f)t`KMJP%!ic^A;l%h0cC`&oY^BooVo{ChWGF7NbHL6pCn$)5;b@+iFsY^ZT(}0FFqA^WqN;8_%f|j&q4QpA)dN#0;O>AZhTiM2TcCe'
    b'Fw_?KPmW)FMW$9@iQkV72i2uC@_aZYfOQ=H}uXF11tE^v`cT;>W_xyE&FaFbiy<_>qc$9*2~kVib`2~T;(b6)V0SG?v8Z+XXiKJbxGeC7*Z`9_F%'
    b'&NLwjMQFkhmT-h80uhNsWTFt2XhbIlF^NTN;t-d3#3um>Nkn3jkd$O3Cj}`<MQYNJmUN^i0~yIgX0ni#Y-A?~ImtzC@{pH&<fi}yDMVq4P?Ta6rv'
    b'xP_MH$Lcj`CDs0u!0UWTr5cX-sDZGnvI~<}jCe%x3`$S;S(Nu#{yiX9X)+#cKZIZ`QDub*yIt8`;EWwy>3LY-a~M`G<em#cuYnmwoK#00%k5VUBQ'
    b'=V;tuMCppDw&Ty7<oaX`;xx{6zaFuIZ=LR>q#cl3zmwVjj0S|e^W1jGoXFTTxFL}jl-td-pyypWS`NU_w@Re_bi0?cTl2C*u3}FdJcp?yyNJJ(IQ'
    b'He%$Vi1#9#3l}LiAQ`AkdQ<qCJ9MNMsiY+l2oK74QWY7dNPoaOk^etS;<Cra*&f;<R%Y!$wz()P>@0trU*qTMsZ3|l2VkW3}q=tdA_3p-&2uFRHh'
    b'15sYZ2bP?K8JrVc;wBXy}qeHze^Ml_}gO=(7RTF{bKw5APhX-9iH(2-7brVCx^Mt6G9lV0?u4}IxJe|};BKl2N}@*4vg#9)Rnlwk~K1S1*6@BG1N'
    b'#xRyY8OL}gFp)`2W(rf8#&l*dlUdAW4s)5ud={{fMJ#3sOIgNpR<M#)tmZHNW({ju$9gufkxgu73tQR7c6P9nfB2VO>}C&p*~fkkaF9bB<_JeQ#&'
    b'J$?l2e@K3}-pVc`k5~OI+p(SGmS@Zg7)Z+~y8<xyOAT@Q_D5<_S-E#&cfql2^Ru4R3kJdp_`yPye0Gbj~Jq_<<j(OFin-fQB@pF->SnGn&(amb9W'
    b'ZZD>n7+S7rKbfPm|=t?)b(}SM$qBni$OF#Pa69f2}U-*^Z7|0+7GlZcGV>lxi$tZs34@NVFvHZz6#xsG5Oky%qn94M!GlQATVm5P_%RJ_@fQ2k#F'
    b'-us=GM2M~m8@blfAKeKSj#%rvw@9lVl!LV$~LyMgPr`tzwBZ+d)Ui9_H%%P9O4K^InD`Aa*ETO;VkDk&jl`WiOXE!Iybn<ZSHWFd)(&%k9f=zp7M'
    b'<6yx=9Tc+DH$@{ad>;3J>-%oo1$jS%VGL4+g}p$S7+!V#VbL?jZCi9%GO5uF&sBo?uWLtNq!p9CZ%5s67cQj(FJ6r>~-sYydx(vhAFWF!-r$wF4L'
    b'k)0gmBp12KLtgTcp8^!55QQm1QHoKV5|pGAr71&M%2A&0sKEDBq!N{>LRG3!of_1n7PYCv5Bx}7>QSEtG^7!YX+l$)(VP~vq!q1cLtEO>o(^=R6P'
    b'@WoSGv)i9`vLaz3D?=`ZIu^`GsHkje!heFhdy1ForXNk&I$AV;IXg#xsG5Oky%qnZ|TxFq7HLVJ`ES&jJ>*h{Y^nDa%;S3Rbd;)%?ZZtYIzdSkDG'
    b'FvWd-XVJq9%&JK3+5C5`@-Rxm6``FI`4swXY9N{R(IL--9a*ETO;VkDk&jl`WiOXE!D%ZHq4Q_Ia+uY$U_qfjk9`cCCJmD$Nc+Lx6@`~5I;VtiY&'
    b'j&v8iO+oDE8hr_!Nv(mC_)p4u!JK#5r{}6A`^wEL?b#eh)FDB6Nk9OBR&a8NFoxGgrp=RIVng<DpHe%w4@_F8OTT`GLwa@WFtE{$Vo18lZU+IBR>'
    b'TwNFfSSgrXFqI3*}aDN0j@vXrAd-%)|@sYoR%Q-!KjqdGOHNiAwqhadQny40gS4QNOs8q<WPG^05!Xh|zt(}uRRqdgtyNGCeeg|2j?J3Z)0FM895'
    b'zVxF%KQVxx`GsHkje!heFhdy1ForXNk&NPZ{$Mm?7|WlGV>}a>$Rs8+g{e$qIy0EbEM_x@xy)le3s}e^7PEw<EMqw<Sjj3@^A~@!hPA9?Jsa4_CN'
    b'{H$t!!gEJJ`uT{L3zOvxmLxV?PHt$RQ4MgrgkeI43yCDNb{Svz+5R7r4kJE^~#eT;n=7xXCSUbBDX!<30~~$Ri%}gr_{?IWKt0D_--4x4h#$ANa^'
    b'8KJ$gId?Q3g`zIu!2u&Em5{~dhAR>{7OcbILjp)Q6Cb5W39O4p>_#_}9iAYQml9G(%q#z}!NKG2jl8*FbAS0Q`Oct_|jqKzgC%MQ?9`cfp{1l)dg'
    b'(yrBic*Z?l%OP~C`}p4QjYR`M+Ls8B9*926{=E=>eQenwWv)Ue&9#yQjhvHpdpQDOcR>YjOMhUC9P;p8`{#2_H>{lo#;##y3&pA^q?ob=uIE`(vS'
    b'Z9!~lNg7k=e81~Q1j3}Gn47|sYrGK$~%gVBs(EPpbN@l0SMlbFmDrZSD`%wQ(7n9UsKGLQKzU?GcG%o3KejODCgC97D?U;ND)*0PTEY+xgs*vuBT'
    b'vW@NRU?>0ZFT2>y9`>@2{T$#Rhd9g;j&h9SoZuv<IL#T(a*p#{;3Ai}%oVP3jqBXtCbziF9qw|E`#j(wk9f=zp7M<6yx=9Tc+DH$@{ad>;3J>-%o'
    b'o1$jS!japOAziG+_u!IKmTwh(sbXQHV-3q7#Fd#3D9vh)X=;lYoRIA~8uwN-~m@f|R5pHEBpoI?|JYjASA+S;$H@vXg_H<RUkD$V)!*Q-FdLqA*1'
    b'$N->I4f|8V?G-W7DIm+`L75JWtRH8Cfs7f`eQ-hk+qBeE-fgh<$J?hhdhBTrvO=wCpn$v=ow4ya_XiGcV(}9k3qBC9SN;kUGgP!!FH+|?!Kl<|%1'
    b'NfO=_?6!n$RGwYgrN*$I3pOzD1PS;Ml*)7{K+`RGl9uWWhRSQ#u_%Tg&pk4Y-j9aKL<F-Ar5ndqa5QnCpgI|PIHE{oZ~zfxX2|gbA_v1<2pCE$t`'
    b'Ykhr8V4J`Z@vBOddFr#$01FL=o-Uh{^xyyHC|_{b+d^M$W`BSaQEBP5{+O&G!wj_^bvB9Vwp6rvK1=)@o<v4~9^;u4SeBp@M)NK6uvl8oe}ASJ0t'
    b'O&ZdYj`U<8Bbmrd7P69!?BpOPxyVf(@{*7I6rdo5C`=KGQjFr1pd_UzO&Q8kj`Dm*1-_>um8eV=s#1;W)SxD{s7)Py;796GkNPyAA&qEE6PnVD=C'
    b'q(Ct!Paf+R~2pbf6=h=u8*7(v9x)peMcPO&|KwkN*6`0Dk5de&sg?GKj$pVJO2G&Im>_ir@Kz(Trg%e=?5oOkg6Dn9LNWGL7lXU?#Je%^c=3kNGT'
    b'MA&Xed5|*-z<*Z;Ot60rn{LLEHvX1p^U?ZE@%oet?jqU7UC;#v-yV%Vh_Og%t9N-{_ILr}_a*X4g;3TIw%^A*ej`LjLBA2+#6|QoP>)hZbx46w6?'
    b'sAX&Jm4XZc+3-?@{H%a;3cnk%^TkGj`w`vBcJ%p7rye15LxY?kc1*MVF*h&!V`grL?SX#h)Oh~6N8w<A~tb|OFZI}fP^F>F-b^DGLn;ml%ygxX-G'
    b'>t(vyLVWFj+J$VxV{lY^Y(A~$)+OFr^bfPxgFFhwXzF^W@yl9Zw}WhhHI%JUr+_@0VXqB2#eN;RregPPQ$Hg))cAE`?{>eGORG@>z0Xi77h(}I??'
    b'qBU)3OFP=rfsS;dGhOIPH@ee<p7f$OedtR+`tuV5_?ch$mERc1AO<spp$ua<BN)jje&-KHGlsGJ$vDO{fr(6FGE<n!G^R6ynapA~bC}CK7O;@ztY'
    b'Z_~*uw#iaEw#gY>hLV<s9d^z(p=`nJZl78rQkOO>S|UJKW_S_j$lW9`TqbJmneBdBICw@tQZh<sI+&z(+punJ;|h8zHjW8X*ZqXu=SdaD*oU5s5@'
    b'(q7ap6L?;F@iA8MU5SMtwCjkjbL}HSVlw>3)1u02IYSNIFbfhN(8OcOuvXGT*WG4qX$whARke7VqrvL>hL}7|hlwuU81SKg&Y06NRa+K#gD)2oOs'
    b'YGR}P?c&_rv^2tMQ!Tv13yxideo-@4QWJUn$VPHG^YhEX+>+=(3W<zrvn}7L}$9tm2PyW2R-RUZ~D-ee)Q)j2Jkb#@GHMDkU<P)2tygha7HkaQT)'
    b'yyjAjgD`IB*sX95$M#AK#0m1#_81~Zw(Z00bRdCX@43t7Zsmavp%EN2BPS;cDp;&0ZlmUXOW0~^`IX11`EZER-;JNbuy*~M=5u$O)8=Ku#e#9@wb'
    b'lw%y{1SdJgY0hw#bDZY_7rDe`u5guWT;~Qixy5bnaF=`B=K&9S#ABZDlxIBW1uuEUYu@mdcf98VANj;*zVMZAgveq4gd`N92}4-I5uOM{BodK{LR'
    b'6v=ofyO<7O{y#T;dU*1SBL8iAh3Il98Mgq$CxoNkdxFk)8}>Bomp*LRPYoogCyO7rDtpUh<Kj0u-bWg(*T&icy>rl%y1;DMMMxQJ(Lp!1q+75|yb'
    b'!RjN^)8q}l~wW-4o{77BuQJ)4hq!Ep2LQ|U2oEEgC6|HGQTiVf{4s@gwo#{eXy3w5;^rRQP=|f-o(Vw3fz|Z``ul&Y91~Hf+3}qO@8No<K@jHJon'
    b'lX&!PsTBx2~1=XlbOO)rZJrv%w!g`nZsP>F`or2WD$#5!cvy8oE5BO6|4D+zgfdt*0G)qY-AIg*}_(~v7H_4<RAWJ7rWWRUiPt{103WKhdIJgj&Y'
    b'n5oXqk68zlb=8YDr3BxsNX4U(Wi5;RDH21(E$2^u6pgCuB>1Pzj)K@v1bf(A*@APE{IL4zb{kOU2qpg|HeNP-4Q&>#sKBte5DXpjUAlAu8nG)RI5'
    b'Nzfn(8YDr3BxsNX4U(Wi5;RDH21(E$2^u6pgCuB>1Pzj)K@v1bf(A*@APE{IL4zb{kOU2qpg|HeNP-4Q&>#sKBte5DXpjUAlAu8nG)RI5Nzfn(8Y'
    b'Dr3BxsQQpKXv-tWr9~e+`oVS|lNY7D><|30fpUizH}~1TB)FMG~|~f)+{8A_-a~L5n14kpwN0phXh2NP-qg&>{(1BteTLXpsahlAuKrv`B&$Nzft'
    b'*S|mY>BxsQYEs~%`60}Hy7D><|30fpUizH}~1TB)FMG~|~f)+{8A_-a~L5n14kpwN0phXh2NP-qg&>{(1BteTLXpsahlAuKrv`B&$Nzft*S|mY>B'
    b'xsQYEs~%`60}Hy7D><|30froXImuyHAwy!G)RI5Nzfn(8YDr3BxsNX4U(Wi5;RDH21(E$2^u6pgCuB>1Pzj)K@v1bf(A*@APE{IL4zb{kOU2qpg|'
    b'HeNP-4Q&>#sKBte5DXpjUAlAu8nG)RI5Nzfn(8YDr3BxsNX4U(Wi5;RDH21(E$2^u6pgCuB>1Pzj)K@v1bf(A*@APE{IL4zb{kOU2qpg|HeNP-4Q'
    b'&>#sKBte5DXpjUAlAu8nG)RI5NzfqqKieQFQ@L~siwg1o0D!5cum'
 )


def supplied_hpl():
    data = zlib.decompress(base64.b85decode(_PAYLOAD))
    if len(data) != SUPPLIED_HPL_BYTES or hashlib.sha256(data).hexdigest() != SUPPLIED_HPL_SHA256:
        raise ValueError('verified supplied Flip HPL payload failed its integrity check')
    return data


def select_profile(model_fingerprint, base_fingerprint, sidecar_fingerprint):
    """Require the exact legacy pair and exact invalid same-stem sidecar."""
    if (model_fingerprint != (MODEL_SHA256, MODEL_BYTES)
            or base_fingerprint != (BASE_SHA256, BASE_BYTES)
            or sidecar_fingerprint != (INVALID_HPL_SHA256, INVALID_HPL_BYTES)):
        return None
    return {'data': supplied_hpl(), 'profile': PROFILE_VERSION,
            'supplied_hpl_sha256': SUPPLIED_HPL_SHA256,
            'supplied_hpl_bytes': SUPPLIED_HPL_BYTES,
            'scope': 'original user-supplied Flip mask verified against the exact paired Body/Head remap and topology; no generated coverage'}
