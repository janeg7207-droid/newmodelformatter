"""Read BC1 alpha accurately; keep Gorilla's decoder for other formats.

DXT1/BC1 contains one-bit transparency when color0 <= color1 and a used
pixel selects palette entry 3. Texture bytes and material parameters are kept.
"""
import functools
import struct

PATCH_VERSION='bc1-used-pixel-alpha-check-1'


def _bc1_alpha(stream):
    header=stream.read(128)
    if len(header)!=128 or header[:4]!=b'DDS ':return False,None
    fourcc=header[84:88]
    if fourcc not in (b'DXT1',b'DX10'):return False,None
    if struct.unpack_from('<I',header,4)[0]!=124 or struct.unpack_from('<I',header,76)[0]!=32:
        return True,None
    if not struct.unpack_from('<I',header,80)[0]&4:return True,None
    height,width=struct.unpack_from('<II',header,12)
    if not height or not width or struct.unpack_from('<I',header,112)[0]&0x20FE00:
        return True,None  # cube/volume surfaces need a separate sampler
    if fourcc==b'DX10':
        extension=stream.read(20)
        if len(extension)!=20:return True,None
        format_id,dimension,misc,array_size,_=struct.unpack('<5I',extension)
        if format_id not in (70,71,72):return False,None  # BC7 etc remain unknown
        if dimension!=3 or array_size!=1 or misc&4:return True,None
    start=stream.tell();blocks_x=(width+3)//4;blocks_y=(height+3)//4
    stream.seek(0,2);length=stream.tell();stream.seek(start)
    if blocks_x*blocks_y*8>length-start:return True,None
    for by in range(blocks_y):
        for bx in range(blocks_x):
            block=stream.read(8)
            if len(block)!=8:return True,None
            color0,color1,selectors=struct.unpack('<HHI',block)
            if color0>color1:continue  # four opaque entries
            for y in range(min(4,height-by*4)):
                for x in range(min(4,width-bx*4)):
                    if selectors>>(2*(y*4+x))&3==3:return True,True
    return True,False


def texture_has_transparency(path,fallback=None):
    try:
        with open(path,'rb') as stream:handled,result=_bc1_alpha(stream)
    except (OSError,ValueError,struct.error):return None
    return result if handled or fallback is None else fallback(path)


def install(materials):
    if getattr(materials,'_bc1_alpha_patch',None)==PATCH_VERSION:return
    original=materials.texture_has_transparency
    @functools.wraps(original)
    def checked(path):return texture_has_transparency(path,original)
    materials.texture_has_transparency=checked
    materials._bc1_alpha_patch=PATCH_VERSION
