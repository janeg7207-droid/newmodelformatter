"""Closest-triangle math copied from uploaded WWE2K_MDL physics_patcher.py.

The original source and SHA256 are in reference_source/manifest.json.
Blender, physics embedding, donor fallbacks, and scene operators are not loaded.
"""
def _v3_sub(a, b): return (a[0]-b[0], a[1]-b[1], a[2]-b[2])

def _v3_add(a, b): return (a[0]+b[0], a[1]+b[1], a[2]+b[2])

def _v3_scl(a, s): return (a[0]*s, a[1]*s, a[2]*s)

def _v3_dot(a, b): return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]

def _closest_point_bary(p, a, b, c):
    """Returns ((u, v, w), squared_distance) for closest point on triangle (a,b,c)."""
    ab = _v3_sub(b, a); ac = _v3_sub(c, a); ap = _v3_sub(p, a)
    d1 = _v3_dot(ab, ap); d2 = _v3_dot(ac, ap)
    if d1 <= 0.0 and d2 <= 0.0:
        diff = _v3_sub(p, a)
        return (1.0, 0.0, 0.0), _v3_dot(diff, diff)

    bp = _v3_sub(p, b); d3 = _v3_dot(ab, bp); d4 = _v3_dot(ac, bp)
    if d3 >= 0.0 and d4 <= d3:
        diff = _v3_sub(p, b)
        return (0.0, 1.0, 0.0), _v3_dot(diff, diff)

    vc = d1*d4 - d3*d2
    if vc <= 0.0 and d1 >= 0.0 and d3 <= 0.0:
        v = d1 / (d1 - d3) if (d1 - d3) != 0 else 0.0
        cp = _v3_add(a, _v3_scl(ab, v))
        diff = _v3_sub(p, cp)
        return (1.0 - v, v, 0.0), _v3_dot(diff, diff)

    cp_ = _v3_sub(p, c); d5 = _v3_dot(ab, cp_); d6 = _v3_dot(ac, cp_)
    if d6 >= 0.0 and d5 <= d6:
        diff = _v3_sub(p, c)
        return (0.0, 0.0, 1.0), _v3_dot(diff, diff)

    vb = d5*d2 - d1*d6
    if vb <= 0.0 and d2 >= 0.0 and d6 <= 0.0:
        w = d2 / (d2 - d6) if (d2 - d6) != 0 else 0.0
        cp = _v3_add(a, _v3_scl(ac, w))
        diff = _v3_sub(p, cp)
        return (1.0 - w, 0.0, w), _v3_dot(diff, diff)

    va = d3*d6 - d5*d4
    if va <= 0.0 and (d4 - d3) >= 0.0 and (d5 - d6) >= 0.0:
        denom = (d4 - d3) + (d5 - d6)
        w = (d4 - d3) / denom if denom != 0 else 0.0
        cp = _v3_add(b, _v3_scl(_v3_sub(c, b), w))
        diff = _v3_sub(p, cp)
        return (0.0, 1.0 - w, w), _v3_dot(diff, diff)

    denom = va + vb + vc
    inv = 1.0 / denom if denom != 0 else 0.0
    v = vb * inv; w = vc * inv; u = 1.0 - v - w
    cp = _v3_add(a, _v3_add(_v3_scl(ab, v), _v3_scl(ac, w)))
    diff = _v3_sub(p, cp)
    return (u, v, w), _v3_dot(diff, diff)
