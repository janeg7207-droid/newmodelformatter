"""Read-only face coverage checks for every recorded conversion output.

Checks actual model domains and resolved MTLS/JMTL dependencies. Missing game
assets are never inferred from absent local files. No geometry, shader, UV,
texture or anchor correction is performed by this audit.
"""
import functools
import copy
import hashlib
import inspect
import os
from pathlib import Path
import struct
import numpy as np

from gmf_2k26_repair import read_native_library, path_hash
from gmf_jmtl_audit import inspect_material
from gmf_local_textures import inspect_dds


PATCH_VERSION = 'all-recorded-model-output-face-audit-1'
SHARED_EYE_NORMAL = 0xefbc052176b84e95
SHARED_TEETH_PAIR = (0x7357eeb9075df170, 0xba65216dd64f5c78)
REFERENCE_SCOPE = 'supplied native 2K26 face schema and writer references; identical topology or appearance is not required'
NATIVE_FACE_BASELINE = {
    'name': 'earlier_supplied_native_2k26_cena_face_schema',
    'source_model_sha256': 'bb0176e86fc2e74cebc61058acac1fa3103c7a859f2e54a2196947fe95ee4a1c',
    'source_model_version': 47,
    'observed_anchor_slots': list(range(13)),
    'observed_eye_material_roles': {'eye_l': 'left', 'eye_r': 'right'},
    'observed_eye_shape_names': ['PupilContract', 'PupilExpand'],
    'observed_eye_weight_bones': ['J_Eye_L', 'J_Eye_R'],
    'known_global_eye_normal_ref': SHARED_EYE_NORMAL,
    'normal_reference_provenance': 'supplied comparison writer and stored native material observations; game asset resolution not verified',
    'topology_and_anchor_target_policy': 'schema observation only; vertex counts, UVs, shapes and anchor mesh names are not copied or required identical',
    'additional_139_John_Cena_2019_archive': 'not inspected for this baseline',
}


def _clean(name):
    return str(name).split(':', 1)[0]


def _kind(mesh):
    name = str(mesh.name).lower()
    if name in ('m_eye', 'eye_l', 'eye_r'): return 'eye'
    if name in ('m_teeth', 'teeth'): return 'teeth'
    if name in ('m_mouthbag', 'mouthbag'): return 'mouthbag'
    bindings = {_clean(g[0]).lower() for g in mesh.face_groups}
    if bindings.intersection(('eye_l', 'eye_r')): return 'eye'
    if 'teeth' in bindings: return 'teeth'
    if 'mouthbag' in bindings: return 'mouthbag'
    return None


def _virtual(path, folder):
    value = folder.materials.game_folder(str(Path(path).parent))
    return None if not value else value.replace('\\', '/').rstrip('/') + '/' + Path(path).name


class Assets:
    def __init__(self, root, folder, report):
        self.root = Path(root).resolve(); self.folder = folder
        self.index = {}; self.copied = {}
        for row in report.get('materials', []):
            for binding in row.get('local_texture_bindings', []):
                if binding.get('output') and binding.get('output_sha256'):
                    self.copied[str(Path(binding['output']).resolve())] = binding['output_sha256']
        for row in report.get('dds_header_normalization', {}).get('rows', []):
            if (row.get('state') in ('output_header_count_repaired', 'already_normalized')
                    and row.get('expected_output_bytes_verified') is True
                    and row.get('source_unchanged') is True
                    and row.get('output') and row.get('output_sha256')):
                self.copied[str(Path(row['output']).resolve())] = row['output_sha256']
        for directory, dirs, files in os.walk(self.root, followlinks=False):
            dirs[:] = [name for name in dirs if not (Path(directory) / name).is_symlink()]
            for name in files:
                path = Path(directory) / name
                if path.suffix.lower() not in ('.jmtl', '.dds', '.tex'):
                    continue
                if not path.resolve().is_relative_to(self.root):
                    continue
                hashed = path.with_suffix('.tex') if path.suffix.lower() == '.dds' else path
                virtual = _virtual(hashed, folder)
                if virtual:
                    self.index.setdefault(path_hash(virtual), []).append(path)

    def material(self, entry, model_path):
        candidates = [p for p in self.index.get(entry['path_hash'], []) if p.suffix.lower() == '.jmtl']
        expected = Path(model_path).parent / 'Materials' / (entry['name'] + '.jmtl')
        virtual = _virtual(expected, self.folder)
        own_hash = path_hash(virtual) if virtual else None
        if len(candidates) > 1:
            return {'state': 'ambiguous_local_material_hash', 'path_hash': entry['path_hash']}
        if not candidates:
            return {'state': 'missing_required_local_jmtl' if entry['path_hash'] == own_hash else 'external_material_not_available_for_audit',
                    'path_hash': entry['path_hash'], 'expected_local_file': str(expected),
                    'unbound_local_file_present': expected.is_file(),
                    'scope': 'no local path guess or assumption about game asset availability'}
        path = candidates[0]
        try:
            data = path.read_bytes(); facts = inspect_material(data)
            return {'state': 'payload_inspected', 'file': str(path),
                    'sha256': hashlib.sha256(data).hexdigest(), **facts}
        except (OSError, ValueError, struct.error) as error:
            return {'state': 'invalid_local_jmtl', 'file': str(path), 'reason': str(error)}

    def texture(self, value, shader, field):
        paths = [p for p in self.index.get(value, []) if p.suffix.lower() in ('.dds', '.tex')]
        result = {'field': field, 'hash': value, 'in_game_resolution': 'not_verified'}
        shared = ((shader == 0x12 and field == 'nrMap@ref' and value == SHARED_EYE_NORMAL)
                  or (shader == 0x1a and ((field == 'colorMap@ref' and value == SHARED_TEETH_PAIR[0])
                                        or (field == 'nrMap@ref' and value == SHARED_TEETH_PAIR[1]))))
        if not paths:
            return {**result, 'state': 'known_shared_game_reference' if shared else 'unresolved_external_or_local_texture',
                    'scope': 'game asset presence not established from selected local output'}
        extensions = [p.suffix.lower() for p in paths]
        if len(extensions) != len(set(extensions)):
            return {**result, 'state': 'ambiguous_local_texture_hash', 'files': [str(p) for p in paths]}
        inspected = []
        for path in paths:
            try:
                data = path.read_bytes(); digest = hashlib.sha256(data).hexdigest()
                facts = inspect_dds(data) if path.suffix.lower() == '.dds' else {'baked_texture_layout': 'not_parsed'}
                if not data: raise ValueError('empty texture asset')
                inspected.append({'file': str(path), 'sha256': digest, **facts,
                                  'copied_bytes_verified': self.copied.get(str(path.resolve())) == digest})
            except (OSError, ValueError, struct.error) as error:
                return {**result, 'state': 'local_texture_not_validated', 'file': str(path), 'reason': str(error)}
        return {**result, 'state': 'copied_local_dds_verified' if any(p.get('copied_bytes_verified') and 'format' in p for p in inspected)
                else 'matching_local_asset_present', 'files': inspected}


def _geometry(mesh, kind):
    row = {'mesh': mesh.name, 'kind': kind, 'vertices': int(mesh.num_verts), 'problems': [], 'warnings': []}
    row['scene_flag'] = int(mesh.scene_flag) if getattr(mesh, 'scene_flag', None) is not None else None
    row['motion_flag'] = int(mesh.motion_flag) if getattr(mesh, 'motion_flag', None) is not None else None
    row['game_flag_policy'] = 'observed; no shader or motion flags are forced'
    count = int(mesh.num_verts); triangles = np.asarray(mesh.triangles)
    positions = np.asarray(mesh.positions)
    if count <= 0 or positions.shape != (count, 3) or not np.isfinite(positions).all():
        row['problems'].append('face positions or vertex domain are invalid')
    if triangles.ndim != 2 or triangles.shape[1:] != (3,) or triangles.dtype.kind not in 'iu' or (triangles < 0).any() or (triangles >= count).any():
        row['problems'].append('face triangle indices are outside the vertex domain or malformed')
    row['triangles'] = len(triangles) if triangles.ndim else 0
    uv_rows = []
    for index, channel in enumerate(mesh.uvs):
        values = np.asarray(channel); facts = {'channel': index, 'shape': list(values.shape)}
        if values.shape != (count, 2) or not np.isfinite(values).all():
            row['problems'].append('UV channel ' + str(index) + ' is malformed or nonfinite')
            facts['state'] = 'invalid'
        else:
            facts.update(state='finite', minimum=values.min(axis=0).tolist(), maximum=values.max(axis=0).tolist())
            if (values < 0).any() or (values > 1).any():
                facts['outside_unit_interval'] = True
                row['warnings'].append('UV channel ' + str(index) + ' uses values outside 0..1; tiling intent is unverified')
        uv_rows.append(facts)
    row['uv_channels'] = uv_rows
    if not uv_rows: row['problems'].append('textured face mesh has no UV channel')
    for attribute in ('normals', 'tangents'):
        values = getattr(mesh, attribute, None)
        if values is not None:
            values = np.asarray(values)
            row[attribute] = {'shape': list(values.shape), 'finite': bool(np.isfinite(values).all())}
            if len(values) != count or not row[attribute]['finite']:
                row['problems'].append(attribute + ' have an invalid domain or nonfinite values')
    row['color_channels'] = []
    for index, channel in enumerate(getattr(mesh, 'colors', [])):
        values = np.asarray(channel); facts = {'channel': index, 'shape': list(values.shape)}
        if values.ndim != 2 or len(values) != count or values.shape[1] not in (3, 4) or not np.isfinite(values).all():
            facts['state'] = 'invalid'; row['problems'].append('face vertex-color channel is malformed or nonfinite')
        else:
            facts.update(state='finite', minimum=values.min(axis=0).tolist(), maximum=values.max(axis=0).tolist())
        row['color_channels'].append(facts)
    row['face_groups'] = []; ranges = []
    for name, first, size in mesh.face_groups:
        row['face_groups'].append({'material': _clean(name), 'first_triangle': int(first), 'triangle_count': int(size)})
        if not isinstance(first, (int, np.integer)) or not isinstance(size, (int, np.integer)) or first < 0 or size <= 0 or first + size > row['triangles']:
            row['problems'].append('face material triangle range is invalid')
        else: ranges.append((int(first), int(first + size)))
    if not ranges: row['problems'].append('face mesh has no valid material binding range')
    elif sorted(ranges)[0][0] != 0 or sorted(ranges)[-1][1] != row['triangles'] or any(a[1] != b[0] for a, b in zip(sorted(ranges), sorted(ranges)[1:])):
        row['problems'].append('face material ranges overlap or do not cover all triangles')
    return row


def _anchors(model):
    result = {'records': [], 'problems': [], 'warnings': [], 'scope': 'mesh/string/index validity; anatomical placement unverified'}
    meshes = {}
    for mesh in model.meshes: meshes.setdefault(mesh.name, []).append(mesh)
    seen = set()
    for point in getattr(model, 'goto_points', []):
        if len(point) != 4:
            result['problems'].append('malformed shading anchor record'); continue
        name, group, slot, vertex = point
        row = {'name': name, 'mesh': group,
               'slot': int(slot) if isinstance(slot, (int, np.integer)) else str(slot),
               'vertex': int(vertex) if isinstance(vertex, (int, np.integer)) else str(vertex)}
        key = (name, slot)
        if key in seen: result['problems'].append('duplicate shading anchor name and slot')
        seen.add(key); targets = meshes.get(group, [])
        if len(targets) != 1:
            result['problems'].append('shading anchor target mesh is missing or ambiguous: ' + str(group))
        elif not isinstance(vertex, (int, np.integer)) or not 0 <= vertex < targets[0].num_verts:
            result['problems'].append('shading anchor vertex is outside its target mesh domain')
        if not isinstance(slot, (int, np.integer)) or not 0 <= slot <= 65535 or not str(name).startswith('_ag_'):
            result['problems'].append('shading anchor slot or name is invalid')
        result['records'].append(row)
    result['count'] = len(result['records'])
    if result['count'] != 13:
        result['warnings'].append('shading anchor count differs from the 13-record stock face schema; eye detail is not established')
    return result


def audit_model(record, folder, assets):
    result = {'version': PATCH_VERSION, 'output': record.get('output'), 'problems': [], 'warnings': [],
              'file_changes': 'none; read-only audit', 'reference_scope': REFERENCE_SCOPE,
              'reference_baseline_name': NATIVE_FACE_BASELINE['name'],
              'in_game_validation': 'not_performed', 'original_model_verify': record.get('verify')}
    target = Path(record.get('output') or '')
    if not record.get('output') or not target.is_file():
        result.update(state='output_unavailable', applicability='unknown')
        result['problems'].append('recorded output model is unavailable for face inspection'); return result
    if not target.resolve().is_relative_to(assets.root):
        result.update(state='output_outside_selected_scope', applicability='unknown')
        result['problems'].append('recorded output model leaves the selected output folder; it was not inspected'); return result
    if record.get('status') in ('failed', 'error', 'skipped') or record.get('verify') == 'fail':
        result['output_provenance'] = 'failed_or_skipped_conversion; existing output does not establish a successful new conversion'
        result['warnings'].append('existing output of a failed or skipped conversion was inspected; successful new conversion was not established')
    try: model = folder.vc.read_model(str(target))
    except Exception as error:
        result.update(state='model_unreadable', applicability='unknown', reason=str(error))
        result['problems'].append('recorded output model could not be read for face inspection'); return result
    result['output_sha256'] = hashlib.sha256(target.read_bytes()).hexdigest()
    result['output_version'] = int(model.version)
    relevant = [(mesh, _kind(mesh)) for mesh in model.meshes if _kind(mesh)]
    if not relevant:
        result.update(state='not_applicable', applicability='no_eye_teeth_or_mouthbag_meshes'); return result
    result['applicability'] = 'face_meshes_present'; result['meshes'] = []; result['materials'] = []
    if int(model.version) != 47:
        result['problems'].append('face output is not a native 2K26 model; native material interpretation is unsupported')
    for mesh, kind in relevant:
        row = _geometry(mesh, kind); result['meshes'].append(row)
        result['problems'].extend(str(mesh.name) + ': ' + p for p in row['problems'])
        result['warnings'].extend(str(mesh.name) + ': ' + p for p in row['warnings'])
    result['anchors'] = _anchors(model)
    result['problems'].extend(result['anchors']['problems']); result['warnings'].extend(result['anchors']['warnings'])
    table = target.with_suffix('.mtls')
    try:
        library_bytes = table.read_bytes()
        entries = read_native_library(library_bytes)
    except (OSError, ValueError, struct.error) as error:
        result['material_library'] = {'file': str(table), 'state': 'unavailable_or_unsupported', 'reason': str(error)}
        result['problems'].append('face material link table is unavailable or not a supported native layout')
        result['state'] = 'requires_attention'; return result
    result['material_library'] = {'file': str(table), 'state': 'native_v6_stub_validated',
        'entries': len(entries), 'bytes': len(library_bytes),
        'sha256': hashlib.sha256(library_bytes).hexdigest(),
        'recorded_bindings': [{'name': entry['name'], 'path_hash': entry['path_hash']}
                              for entry in entries]}
    by_name = {entry['name']: entry for entry in entries}
    body_refs = None
    if 'body' in by_name:
        body = assets.material(by_name['body'], target)
        if body['state'] == 'payload_inspected' and body['shader_byte'] == 0x19:
            values = {v['field']: v['hash'] for v in body['texture_references']}
            if all(key in values for key in ('colorMap@ref', 'nrMap@ref')):
                body_refs = values['colorMap@ref'], values['nrMap@ref']
    checked = set()
    for mesh, kind in relevant:
        for raw_name, _, _ in mesh.face_groups:
            name = _clean(raw_name); key = (name, kind)
            if key in checked: continue
            checked.add(key); row = {'binding': name, 'face_kind': kind}
            if name not in by_name:
                row['state'] = 'required_material_binding_missing'
                result['problems'].append('face material binding is absent from native MTLS: ' + name)
                result['materials'].append(row); continue
            row.update(assets.material(by_name[name], target)); result['materials'].append(row)
            if row['state'] == 'external_material_not_available_for_audit':
                result['warnings'].append(name + ': external material path is unresolved in selected output; game availability was not inferred'); continue
            if row['state'] != 'payload_inspected':
                result['problems'].append(name + ': ' + row['state']); continue
            actual_shader = row['shader_byte']
            if kind == 'eye' and actual_shader != 0x12:
                result['problems'].append(name + ': face shader differs from supported eye 0x12 layout'); continue
            if kind in ('teeth', 'mouthbag') and actual_shader not in (0x1a, 0x19):
                row['face_shader_validation'] = 'unsupported_face_layout_unverified'
                result['warnings'].append(name + ': teeth/mouthbag shader ' + hex(actual_shader) +
                    ' is outside the inspected face layouts; shader/appearance validity was not inferred')
                continue
            refs = {value['field']: value['hash'] for value in row['texture_references']}
            if 'colorMap@ref' not in refs or 'nrMap@ref' not in refs:
                result['problems'].append(name + ': required face color or normal reference is absent')
            if kind in ('teeth', 'mouthbag'):
                pair = refs.get('colorMap@ref'), refs.get('nrMap@ref')
                if actual_shader == 0x19:
                    if body_refs is not None and pair == body_refs:
                        row['texture_pair_classification'] = 'shared_body_atlas'
                        row['face_shader_validation'] = 'comparison_style_skin_body_atlas_refs_confirmed'
                    else:
                        row['texture_pair_classification'] = 'skin_face_pair_body_atlas_unverified'
                        row['face_shader_validation'] = 'skin_face_body_atlas_comparison_unverified'
                        result['warnings'].append(name + ': skin-shader face material is preserved; a matching inspected body-atlas pair was not available to verify this face workflow')
                else:
                    row['texture_pair_classification'] = ('known_shared_2k26_teeth_pair' if pair == SHARED_TEETH_PAIR
                        else 'shared_body_atlas' if body_refs is not None and pair == body_refs
                        else 'explicit_custom_face_pair')
                    row['face_shader_validation'] = 'native_teeth_layout_inspected'
            row['texture_resolution'] = [assets.texture(value, actual_shader, field) for field, value in refs.items()]
            for texture in row['texture_resolution']:
                if texture['state'] == 'unresolved_external_or_local_texture':
                    result['warnings'].append(name + ': texture reference is unresolved in selected output; external game assets were not checked')
                elif texture['state'] in ('ambiguous_local_texture_hash', 'local_texture_not_validated'):
                    result['problems'].append(name + ': ' + texture['state'])
    result['eye_color_policy'] = 'left and right colors may differ; equality is not required or enforced'
    result['state'] = 'requires_attention' if result['problems'] else 'structural_face_checks_with_unverified_external_data' if result['warnings'] else 'selected_output_face_checks_passed'
    return result


def process(report, folder, log=lambda text: None):
    summary = {'version': PATCH_VERSION, 'records_total': len(report.get('models', [])), 'records_audited': 0,
               'face_models': 0, 'not_applicable': 0, 'unavailable_or_unreadable': 0,
               'problems': [], 'warnings': [], 'in_game_validation': 'not_performed', 'file_changes': 'none',
               'reference_baseline': copy.deepcopy(NATIVE_FACE_BASELINE),
               'coverage_scope': 'all recorded model outputs; source models absent from report.models are not claimed inspected'}
    assets = Assets(report['output'], folder, report)
    for record in report.get('models', []):
        try: audit = audit_model(record, folder, assets)
        except Exception as error:
            audit = {'version': PATCH_VERSION, 'state': 'audit_not_completed', 'applicability': 'unknown',
                     'problems': ['face audit did not complete: ' + str(error)], 'warnings': [],
                     'file_changes': 'none', 'in_game_validation': 'not_performed'}
        record['face_output_audit'] = audit; summary['records_audited'] += 1
        if audit['applicability'] == 'face_meshes_present': summary['face_models'] += 1
        elif audit['state'] == 'not_applicable': summary['not_applicable'] += 1
        else: summary['unavailable_or_unreadable'] += 1
        identity = record.get('source', record.get('output', 'model'))
        for key in ('problems', 'warnings'):
            for message in audit[key]:
                text = str(identity) + ': face audit: ' + message
                summary[key].append(text)
                if text not in report.setdefault(key, []): report[key].append(text)
    summary['coverage_complete'] = summary['records_audited'] == summary['records_total']
    summary['state'] = 'requires_attention' if summary['problems'] else 'checked_with_unverified_items' if summary['warnings'] else 'recorded_output_checks_passed'
    report['face_output_check'] = summary
    report['conversion_completeness'] = 'incomplete' if report.get('problems') else 'structural_checks_only'
    log('Face checks: ' + str(summary['records_audited']) + ' recorded outputs audited; ' + str(summary['face_models']) + ' contain face meshes; in-game appearance not verified.')


def install(folder):
    if getattr(folder, '_face_output_audit', None) == PATCH_VERSION: return
    original = folder.convert_folder
    @functools.wraps(original)
    def convert_folder(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs); bound.apply_defaults()
        report = original(*args, **kwargs)
        process(report, folder, bound.arguments.get('log', lambda text: None))
        from gmf_report import save_intermediate
        save_intermediate(report, bound.arguments['dst'])
        return report
    folder.convert_folder = convert_folder
    folder._face_output_audit = PATCH_VERSION
