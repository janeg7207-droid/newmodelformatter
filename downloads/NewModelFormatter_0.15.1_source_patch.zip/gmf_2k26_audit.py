"""Missing-data audit and evidence-backed recovery for already-ported models.

No new input/output method. Native model payloads, shaders and rig/weight data
are preserved. Recovery uses actual available assets, not invented defaults.
"""
import functools
import hashlib
import inspect
import os
from pathlib import Path
import struct
from gmf_native_assets import AssetIndex,recover_materials,recover_textures
from gmf_native_masks import audit_mask

PATCH_VERSION='native-2k26-missing-data-audit-1'
COMPANIONS=('.wdf','.hair_ywa','.hair_corr_ywa','.other_ywa','.other_corr_ywa')


def _ycl_check(data,module):
    if len(data)<32 or struct.unpack_from('<HH',data,16)!=(1,26):
        raise ValueError('provided YCL is not a readable 2K26 header')
    if struct.unpack_from('<I',data,8)[0]!=len(data):raise ValueError('YCL size header does not match file')
    nodes=module.ycl.ycl_own._nodes(data,32,len(data))
    if nodes is None or len(nodes)!=struct.unpack_from('<I',data,12)[0]:
        raise ValueError('YCL tree is invalid')
    return module.ycl._real_names(data)


def audit_physics(source,target,model,folder,index):
    source,target=Path(source),Path(target)
    result={'findings':[],'repairs':[],'companions':[],
            'compatibility':'presence/references audited; WDF/YWA compatibility and in-game motion not established'}
    simulation=[m.name for m in model.meshes if m.name.startswith('S_')]
    result['simulation_meshes']=simulation
    for suffix in COMPANIONS:
        original=source.with_suffix(suffix);written=target.with_suffix(suffix)
        if original.is_file():
            if not written.is_file():
                repair=index.copy(original,written)
                if repair:result['repairs'].append(repair)
            result['companions'].append({'file':str(written),'state':'preserved_unverified','bytes':written.stat().st_size})
    original=source.with_suffix('.ycl');written=target.with_suffix('.ycl')
    embedded=[data for tag,data in model.substreams if tag==b'YCL!']
    if written.is_file():data=written.read_bytes();location=str(written)
    elif original.is_file():
        try:
            from gmf_ycl_repair import checked_translation
            repair=checked_translation(folder,original,written)
            result['repairs'].append({'kind':'restore_or_translate_available_ycl','source':str(original),
                                     'output':str(written),**repair})
            data=written.read_bytes();location=str(written)
        except Exception as error:
            result['findings'].append({'category':'physics','state':'available_ycl_not_recovered','file':str(original),'reason':str(error)})
            return result
    elif len(embedded)==1:data=embedded[0];location='embedded YCL!'
    else:
        if simulation:
            result['findings'].append({'category':'physics','state':'simulation_ycl_not_provided',
                'expected_file':str(original),'simulation_meshes':simulation,
                'action':'compatible YCL not present in selected files; physics was not invented'})
        result['ycl_state']='not_provided'
        return result
    try:names=_ycl_check(data,folder)
    except ValueError as error:
        result['ycl_state']='invalid_or_legacy'
        result['findings'].append({'category':'physics','state':'ycl_not_validated','file':location,'reason':str(error)})
        return result
    known={m.name for m in model.meshes}
    base=target.parent.parent/'BaseModel'/'baseModel.mcd'
    if base.is_file():known.update(m.name for m in folder.vc.read_model(str(base)).meshes)
    unmatched=sorted(n.decode('ascii') for n in names if n.startswith((b'M_',b'S_')) and n.decode('ascii') not in known)
    result.update(ycl_state='header_and_tree_valid',unmatched_mesh_names=unmatched)
    if unmatched:
        result['findings'].append({'category':'physics','state':'ycl_mesh_references_need_review','file':location,
            'names':unmatched,'action':'names are absent from supplied models; active/unused references not guessed or removed'})
    return result


def _clear_recovered_material_errors(record,report,source):
    removed=[p for p in record.get('problems',[]) if p.startswith('native material library:')]
    record['problems']=[p for p in record.get('problems',[]) if p not in removed]
    relative=os.path.relpath(record['source'],source)
    report['problems']=[p for p in report.get('problems',[]) if p not in {relative+': '+error for error in removed}]


def process(report,folder,source,log):
    summary={'version':PATCH_VERSION,'models_checked':0,'repairs_applied':0,'findings':[],
             'in_game_validation':'not_performed','unavailable_data':'reported; never synthesized'}
    records=[r for r in report.get('models',[]) if r.get('source_version')==47]
    if not records:
        summary['state']='not_applicable_no_native_inputs';report['native_2k26_missing_data_check']=summary;return
    output=Path(report['output']);index=AssetIndex(source,output)
    for record in records:
        src=Path(record['source']);dst=Path(record['output'])
        audit={'version':PATCH_VERSION,'repairs':[],'findings':[]}
        record['native_missing_data_audit']=audit
        if not dst.is_file() or record.get('status') not in ('preserved_2k26','repaired_2k26_foot_mask'):
            audit.update(state='output_model_unavailable')
            audit['findings'].append({'category':'model','state':'output_model_unavailable','file':str(dst)})
            summary['findings'].extend(audit['findings']);continue
        try:
            if hashlib.sha256(src.read_bytes()).hexdigest()!=record.get('facts',{}).get('source_sha256'):
                raise ValueError('native source model changed after preservation audit')
            model=folder.vc.read_model(str(dst))
            if model.version!=47:raise ValueError('written model is not native 2K26')
            summary['models_checked']+=1
            used={folder.materials.clean_name(name) for mesh in model.meshes for name,_,_ in mesh.face_groups}
            materials=recover_materials(src,dst,used,index)
            audit['materials']=materials;audit['findings'].extend(materials['findings']);audit['repairs'].extend(materials['repairs'])
            if materials['complete']:
                _clear_recovered_material_errors(record,report,index.source)
                for old in report.get('materials',[]):
                    if Path(old.get('output',''))==dst.with_suffix('.mtls'):
                        old['problems']=[];old['status']='native_dependencies_verified_or_recovered'
                        old['missing_data_audit']=materials
            if any(r['kind'] in ('rebuild_missing_native_mtls','repair_native_material_table') for r in materials['repairs']):
                report['native_2k26_material_libraries_repaired']=report.get('native_2k26_material_libraries_repaired',0)+1
            textures=recover_textures(materials['materials'],index);audit['textures']=textures
            for item in textures:
                if item['state']!='present_or_recovered':audit['findings'].append({'category':'texture',**item})
            if any(not m['texture_schema_supported'] for m in materials['materials']):
                audit['findings'].append({'category':'texture','state':'shader_texture_schema_unverified',
                    'action':'unsupported shader references were not guessed'})
            audit['masks']=audit_mask(src,dst,model,folder)
            audit['findings'].extend(audit['masks']['findings']);audit['repairs'].extend(audit['masks']['repairs'])
            if audit['masks']['repairs']:
                record['status']='repaired_2k26_missing_mask'
                record['verification_scope']='native_model_payload_preserved_and_sidecar_mask_verified'
                record['notes']=[n for n in record.get('notes',[]) if not n.startswith('Native model bytes preserved;')]
                record.setdefault('facts',{}).update(byte_identical=False,output_sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),
                    geometry_weights_bones_and_embedded_streams='model and other streams byte-identical; mask restored')
                report['native_2k26_models_preserved']=max(0,report.get('native_2k26_models_preserved',0)-1)
                report['native_2k26_masks_repaired']=report.get('native_2k26_masks_repaired',0)+1
                # This exact older skip is resolved by the now-validated sidecar.
                skip=src.name+': AJ foot mask not applied: separate HPL present; existing mask was preserved'
                record['problems']=[p for p in record.get('problems',[]) if p!=skip]
                report['problems']=[p for p in report.get('problems',[]) if p!=skip]
            audit['physics']=audit_physics(src,dst,model,folder,index)
            audit['findings'].extend(audit['physics']['findings']);audit['repairs'].extend(audit['physics']['repairs'])
            # Texture repairs from exact source hashes are shared dependencies.
            for repair in index.repairs:
                if repair not in audit['repairs'] and any(f.get('output')==repair['output'] for t in textures for f in t.get('files',[])):
                    audit['repairs'].append(repair)
            blockers=[f for f in audit['findings'] if f['state'] in
                      ('missing_material_definition','missing_mtls','invalid_jmtl','ambiguous_jmtl','ambiguous_definitions',
                       'invalid_texture','ambiguous_texture_hash','ycl_not_validated')]
            for finding in blockers:
                message=src.name+': native missing-data check: '+finding['state']
                if message not in record.setdefault('problems',[]):record['problems'].append(message)
                if message not in report.setdefault('problems',[]):report['problems'].append(message)
            record['verify']='fail' if record.get('problems') else 'pass'
            audit['state']='needs_files_or_review' if audit['findings'] else 'supported_asset_checks_passed'
            if audit['repairs']:record.setdefault('repairs',[]).append('native_missing_data_recovery')
            for finding in audit['findings']:
                summary['findings'].append({'model':str(src),**finding})
            summary['repairs_applied']+=len(audit['repairs'])
            log('  '+src.name+': already-ported 2K26 check; '+str(len(audit['repairs']))+' repair(s), '+str(len(audit['findings']))+' item(s) need files or review')
        except Exception as error:
            audit.update(state='audit_not_completed',error=str(error))
            finding={'model':str(src),'category':'audit','state':'audit_not_completed','reason':str(error)}
            audit['findings'].append(finding);summary['findings'].append(finding)
            report.setdefault('warnings',[]).append(src.name+': native missing-data audit did not complete: '+str(error))
    summary['state']='needs_files_or_review' if summary['findings'] else 'supported_asset_checks_passed'
    report['native_2k26_missing_data_check']=summary
    report['conversion_completeness']='incomplete' if report.get('problems') else 'structural_checks_only'
    if summary['findings']:
        report.setdefault('warnings',[]).append('Already-ported 2K26 missing-data check has unresolved items; see native_2k26_missing_data_check and each model audit.')
    log('Already-ported 2K26: '+str(summary['models_checked'])+' model(s) checked, '+str(summary['repairs_applied'])+' repair(s), '+str(len(summary['findings']))+' unresolved item(s).')


def install(folder):
    if getattr(folder,'_native_missing_data_patch',None)==PATCH_VERSION:return
    original=folder.convert_folder
    @functools.wraps(original)
    def convert_folder(*args,**kwargs):
        bound=inspect.signature(original).bind(*args,**kwargs);bound.apply_defaults()
        report=original(*args,**kwargs)
        process(report,folder,bound.arguments['src'],bound.arguments['log'])
        from gmf_report import save_intermediate
        save_intermediate(report,bound.arguments['dst'])
        return report
    folder.convert_folder=convert_folder
    folder._native_missing_data_patch=PATCH_VERSION
