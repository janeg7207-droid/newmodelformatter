"""Inspected weight-audit functions copied from supplied ModelFormatter.

Source: reference_source/ModelFormatter/__init__.py, SHA-256 recorded in manifest.
Only these functions and their constant are imported; Blender startup and operators
are not executed. Native model adapters are in gmf_reference_audit.py.
"""
import math
WWE_NONDEFORM_DRIVER_MARKERS = (
    "_goal", "_plane", "_start", "_rbf_", "footik", "_cam", "cam_",
)


def is_wwe_nondeform_driver_bone(name):
    
    compact = str(name or "").lower().replace(" ", "")
    return (
        compact in {"j_dock", "j_opponent", "j_anim_origin"}
        or compact.endswith(("_stub", "_up", "_s", "_fov"))
        or any(marker in compact for marker in WWE_NONDEFORM_DRIVER_MARKERS)
    )


def _attachment_weight_problem_indices(obj, armature):
    if obj is None or armature is None:
        return [], {}
    group_names = {int(group.index): str(group.name) for group in obj.vertex_groups}
    bones = {str(bone.name): bone for bone in armature.data.bones}
    problem_indices = []
    counts = {
        "unweighted": 0,
        "nonunit": 0,
        "excessive": 0,
        "driver": 0,
        "missing_bone": 0,
        "invalid": 0,
    }
    for vertex in obj.data.vertices:
        deform_weights = []
        has_driver = False
        has_missing_bone = False
        has_invalid = False
        for assignment in getattr(vertex, "groups", ()) or ():
            weight = float(getattr(assignment, "weight", 0.0))
            if not math.isfinite(weight) or weight < 0.0:
                has_invalid = True
                continue
            if weight <= 0.0000001:
                continue
            name = group_names.get(int(assignment.group), "")
            bone = bones.get(name)
            if is_wwe_nondeform_driver_bone(name):
                has_driver = True
                continue
            if bone is not None and bool(getattr(bone, "use_deform", True)):
                deform_weights.append(weight)
            elif name.lower().startswith(("j_", "x_")):
                has_missing_bone = True
        unweighted = not deform_weights
        nonunit = bool(deform_weights) and abs(sum(deform_weights) - 1.0) > 0.02
        excessive = len(deform_weights) > 8
        if unweighted:
            counts["unweighted"] += 1
        if nonunit:
            counts["nonunit"] += 1
        if excessive:
            counts["excessive"] += 1
        if has_driver:
            counts["driver"] += 1
        if has_missing_bone:
            counts["missing_bone"] += 1
        if has_invalid:
            counts["invalid"] += 1
        if unweighted or nonunit or excessive or has_driver or has_missing_bone or has_invalid:
            problem_indices.append(int(vertex.index))
    return problem_indices, counts
