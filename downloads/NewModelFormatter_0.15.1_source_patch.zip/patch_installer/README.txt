NewModelFormatter 0.15.1 experimental

INSTALL

1. Right-click this ZIP and choose Extract All into a NEW empty folder.
2. Open that folder and double-click Install.cmd.
3. Choose your ORIGINAL Gorilla Model Formatter 1.0 EXE.
4. Wait for "Created successfully", then open NewModelFormatter.exe.

Do not run Install.cmd inside the ZIP. Keep its extracted files together.
Choose the original Gorilla EXE, not an older experimental NewModelFormatter.
No Python or Blender installation is required. The original EXE is unchanged.
Existing output EXEs are never overwritten; use a fresh installer folder.

CONVERT

Keep each wrestler's BaseModel, attire, Materials and Textures folders together.
Use your usual source folder, CakeView workflow and a new empty output folder.
To audit an already-ported 2K26 model, choose Keep the mod's own folder name.
After conversion click Open conversion report. The log shows its saved path.
Final reports save at the output root and inside the converted mod, with a
Temp fallback when the selected output cannot be written. Conversion failures
also produce reports; forced termination cannot guarantee a completed report.

RELEASE STATUS

This is a limited experimental release of the supported, tested changes.
Moxley's four YWA bindings remain unresolved; no motion fix is claimed.
Other missing/rejected textures and unreadable masks remain report problems.
All appearance and movement checks still require in-game validation.

WHAT 0.15.1 ADDS

Per-model Body masking beneath supported opaque clothes, boots and pads.
The calculation uses each model's actual geometry and material links; it has
no wrestler whitelist. It preserves existing mask IDs, custom groups and
different authored coverage at each LOD. Entrance and ring outfits are checked
separately. Native bind frames, geometry LOD domains and material opacity must
be proved; skipped or unsupported surfaces stay visible in the report.
The mask option is enabled by default and can be disabled for comparison.
Missing masks can receive partial static coverage after independent model
checks. Unknown original coverage is not declared recovered. Only the embedded
HPL changes; geometry, weights, shaders, textures and YCL stay preserved.
Rebake the complete fresh output and check moving/bent poses in-game.

Duplicate attire names now use one-to-one geometry and complete output-data
matching. Hammerstone's 12 supplied meshes pass the original native verifier;
changed weights, flags, missing and excess duplicate controls still fail.

The teeth shader rule below is unchanged from 0.15. AJ's newly supplied teeth
and mouthbag payloads match it, but all seven links in his uploaded MTLS point
to a different material namespace. A separate target-specific table correction
is available. Future face audits record the actual written MTLS fingerprint
and links. In-game tooth appearance still needs checking after the rebake.

WHAT 0.15 ADDS

Bounded decoding of supported older 2K24 inline-v1 material libraries. This
fixes the material path that previously omitted both MTLS tables and could
leave a baked model invisible. Known shader identities and typed texture maps
use the existing Gorilla target writer. Original files, folder input/output,
CakeView and YCL conversion stay preserved.

Use your original BigBoomAJ_2K24 folder and a fresh output for a direct port.
Its intermediate formatted-2K25 copy contains an invalid hide-mask placeholder.
Check the new report, then rebake the complete new Materials/Textures output.
BigBoom's report confirms the direct raw24 material route ran, but the exact
raw24 MTLS pair has not been inspected here. His teeth remain unresolved.

Seven exact-candidate native folder checks and 33 assertions passed under Wine.
Both supplied raw24 material tables generated linked native materials; source,
model and mask bytes stayed preserved. Existing duplicate attire mesh failures
remain visible. No missing textures, authored masks or physics are invented.
V5/yCS source material mapping and direct 2K22/2K23 remain unsupported in 0.15.

WHAT 0.14.2 ADDS

"Body-atlas teeth/mouthbag: use skin shader (experimental)" is selected by
default in this app; it can be disabled. Eligible teeth and mouthbag materials
are recreated as native yCh_skin (0x19), retaining their local body_color and
body_nrm references. The complete native skin schema is
written, following the supplied CakeView workaround and comparison code.
Geometry, UVs, vertex masks, other materials and DDS pixels stay preserved.
Existing native material-link recovery runs first.
Missing/wrong links, invalid textures, extra authored texture maps or failed
model checks refuse this trial. Read teeth_skin_workaround in the report.
The exact verified BigBoomAJ native model can receive this material-only rule when
unrelated body/eye/head materials are missing. Those failures remain reported;
no unrelated material is generated and the partial mod stays incomplete.

The supplied working Gorilla 2K24 report writes both teeth and mouthbag as
0x19 because their teeth are painted in body_color. This matches that rule;
direct 2K24 input alone is not established as the reason its teeth worked.
Repeat eligible native skin inputs are not rewritten. Rebake the complete
output with CakeView and check teeth in-game; a visual fix is not proven here.

The supplied BigBoomAJ atlas has opaque non-black tooth pixels aligned to UV0.
Its body normal-map metallic alpha is only 0-1/255. No automatic alpha inversion
is added. The uploaded MTLS does not match the report namespace, and that
report lacks its hash, so the origin of that library remains uncertain.

WHAT 0.14.1 ADDS

Nested Characters folders now use the same material namespace as Gorilla's
original writer. This repairs the safety-check rejection seen for Bryan/Flip
in the supplied bulk report. Wrong actual material bindings still fail.
Input/output folders, texture colors and the original conversion methods stay
preserved. Actual eye appearance remains an in-game check.

A plain .ywa companion now triggers the original checked translator for its
readable paired YCL. The unknown companion remains omitted and unverified;
no physics is invented. Actual Jeff Hat/Ponytail and Matt failed YCL files
have not been supplied, so their motion is not declared fixed.

Failed source-core reasons also appear in each rejected model's problem list.
Unreadable masks and missing animation roots remain separate failures.

WHAT 0.14 ADDS

Read-only physics binding checks distinguish translated YCL format from actual
mesh bindings and motion validation. Known exposed names/indices are compared
with paired source and output models; unknown layouts and solver semantics
stay unverified. Missing YCL object names alone do not prove a solver failure.
Moxley's hair data declares 6,572 vertices for a named 1,060-vertex mesh, and
other corrective data declares 6,452 for a named 4,358-vertex mesh. The four YWA
companions remain omitted; no invented remapping or zero bindings are used.

The exact inspected Moxley profile can receive a supported WDF layout repair:
authored LOD0 records are retained and repeated for proven identical target
LOD regions. Model, hide mask and other streams stay identical. This is a WDF
layout correction, not a confirmed movement fix or universal companion port.
Inspect its report. Invalid WDF and unknown profiles remain unsupported.

AJ's supplied eyelash DDS has ten complete mip levels but declares one.
Only the output mip-count field is corrected after proving the entire chain
exactly fills the payload. Every compressed pixel byte and all ten decoded
levels stay identical; originals and other header fields stay unchanged.
Incomplete/trailing data and underdeclared partial chains remain rejected.
Inspect mip_count_repair and dds_header_normalization. Unexpected different
output bytes are preserved and reported. CakeView/game appearance is unverified.

The attire verifier now distinguishes unique named ring/entrance meshes that
share geometry, and uses each target once. Genuine name/flag/weight failures
and ambiguous duplicate records still fail. This changes verification only.
AJ's uploaded files are already-native outputs; original legacy weight fidelity
still needs its original source MCD. Unreadable AJ HPL and unsupplied rejected
hair/elbow DDS files remain unresolved. Missing mask/physics data is not invented.

Kenny's supplied source has 68 tights vertices with positive totals below one.
The partial-rig check now permits the original writer to normalize those
budgets only after all packed/written weights and the complete rig are verified.
Original source totals are recorded; input vectors remain unchanged. Missing
core joints, invalid weights and corrupt output still fail. His unreadable
HPL remains a separate failure; no hiding or physics data is invented.

Requested eye defaults: every ordinary converted eye uses
 eyeLidShadowDarkness = 1.00
 eyeLidShadowFallOff = 0.50
These two fields override earlier authored values; other settings, references,
textures and model data stay preserved. Existing supported native Eye JMTLs
receive the same output-only policy. Missing material files are not synthesized.
Bryan previously emitted 0.10/0.15. In-game appearance remains unverified.

Exact Bryan/Flip ocular reference correction: Cena's full caruncle chart
maps eight ocular anchors to existing authored head vertices. Only the eight
vertex-index fields change; preceding tongue/other anchors and model data stay
preserved. Exact file-profile and valid paired base eye materials are required.
Unknown files and missing/failed materials are refused. The available Flip
geometry-only fixture lacks actual base materials and remains incomplete.
Appearance still needs an in-game eye check. No eye colors or shapes are copied.

WHAT 0.13 ADDS

Authored eye shading settings are preserved through supported legacy material
conversion, following the supplied Blender formatter's ordinary WWE path.
Only proven same-key finite float fields are retained, including explicit
zeros. Missing values, shader, color/normal references, geometry, UVs and color
pixels remain unchanged. Unknown aliases are excluded. This is a supported
data-preservation fix; in-game eye appearance still needs checking. An older
native port that lost the original settings cannot recover them by guessing.

Exact supplied Bryan and Flip tongue-anchor experiments: the supplied native 2K26
reference anchors slot 4 to the tongue, while Gorilla selects teeth. A verified
topology match locates Bryan's corresponding tongue vertex. Only this exact
inspected models are eligible; three bytes in each base MCD change. All gear,
masks, weights, UVs, materials and textures remain identical to 0.12. Other
models are unaffected. Already-ported exact matching 2K26
data can receive the same trial; repeat processing is safe.

Flip's newly supplied readable HPL fits his actual paired Body/Head domains.
It hides all 2,097 foot/toe-dominant body vertices. The exact inspected legacy
Flip pair with the exact old invalid sidecar receives guarded restoration of
that supplied data. The writer preserves all 4,378 supplied IDs in both modes
and all five LODs. No shoe weights or estimated coverage are substituted.
Native 2K26 inputs do not receive this legacy fallback. Use a readable matching
sidecar in the complete input when available. Inspect supplied_hide_mask_recovery.
In-game boot coverage still needs testing.

For the exact already-ported Flip model: the ZIP includes
Optional_Flip_HPL\931_Attire.hpl. Make a COPY of the complete input wrestler
folder, then place this HPL beside 931_Default_Attire\931_Attire.mcd in that
copy. Convert the copy into a fresh output using Keep the mod's own folder
name. Keep the original folder/HPL. This supplied mask is only for the exact
inspected Flip pair; do not apply it to other models. The complete native
Materials/Textures/MTLS must be present for a complete conversion check.

Vynx HeatSeeking rebuilds selected attire weights and applies HPL separately.
Flip's shoe bones already survive conversion; the current proven mask repair
keeps those weights. Broad automatic gear reweighting is not established here.

Inspect experimental_tongue_anchor. The report deliberately requires an
in-game teeth check. This is NOT a confirmed black-teeth fix. Convert the
complete original supplied Bryan folder into a fresh output, rebake everything
with CakeView, then check his teeth. The previous working gear is preserved.

Complete supported compressed DDS files may omit the advisory texture-cap bit.
The supplied Blender importer handles this header quirk. The formatter now
accepts those files only after the remaining header, dimension, format,
resource and full mip payload checks pass. Other accepted DDS files stay byte-identical; 0.14 corrects only the proven
underdeclared full-chain mip count described above. Failed bindings now name the actual texture file and invalid
header values. Appearance and CakeView baking still require testing.

Hammerstone's actual rejected DDS files are not available, so their errors
are not claimed fixed yet. His known unreadable HPL is a separate unresolved
issue. Bryan's mask is not substituted for Hammerstone's different model.

EXISTING 0.12 CHECKS

Recognized compact male legacy rigs keep Gorilla's full target bone builder,
custom bones and mapped skin weights. The shorter source rig can pass only
after all written bones, parents, bind matrices and every skin influence are
verified. Missing animation joints or malformed rigs remain unsupported.
Inspect partial_legacy_rig. No extra surface reweighting is forced by this route.

Every recorded output gets eye/teeth geometry, anchor, actual material-binding
and available texture checks. Inspect face_output_audit and face_output_check.
Custom eye colors and tooth atlases are preserved. Unavailable external game
assets stay unverified. These checks do not prove in-game brightness/rendering.

Existing repairs include named local DDS bindings, preserved valid authored
teeth irradiance, strict matching Rey/Bryan mask recovery, BC1 alpha detection,
material case matching and supported existing-data recovery for native2K26.
Original model/texture inputs, Gorilla UI logic, CakeView gate and Gorilla's
YCL translator are retained. Vynx/PWM surface math and comparison formatter
material handling are used where supported; the full Blender pipeline is not
active. Attribution is retained in the app and source package.

REMAINING LIMITS

Unreadable or unavailable hide-mask data is not replaced with an invented mask.
Unrelated models still need their own matching readable mask. General clipping, beard, belt,
blood, eye and tooth appearance need entrance/gameplay checks. No universal
visual repair is claimed. Billie YCL translates, but WDF/YWA companion
conversion remains unsupported; moving hair/cloth still needs a game check.
Unsupported older material layouts remain explicit problems. Bryan's reported
loading crash has not been reproduced or established fixed.

VALIDATION

469 regression tests pass. Exact 0.14.2 payloads passed Wine/native DLL checks
for your six supplied files with the workaround off/on, an unchanged repeat
run, complete Bryan 2K25 conversion off/on and the UI. Only teeth.jmtl and
mouthbag.jmtl change
between the off/on conversions. Saved reports match returned results.
Earlier 0.14.1 checks covered nested material paths and unknown YWA; earlier
0.14 checks covered Rey gear/masks, Billie YCL and Moxley WDF layout.
Unsupported companion omissions remain explicit.
Binary patch reconstruction and ZIP CRCs passed. The Windows PowerShell
installer and in-game appearance have not been executed/tested here.

Accepted original Gorilla EXE SHA-256:
ece4729f2ac3fc707c69550d4a79df7866c11a61463d8eb529ae927e04f377f2

Optional Windows PowerShell command:
.\Apply-FormatterPatch.ps1 -OriginalExe "C:\path\Gorilla Model Formatter.exe"
The optional -OutputExe selects another NEW output filename.
