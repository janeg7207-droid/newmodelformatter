@echo off
setlocal
cd /d "%~dp0"
echo NewModelFormatter experimental patch installer
echo This creates a new EXE. Your original EXE is kept.
echo.
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Apply-FormatterPatch.ps1" %*
set "PATCH_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %PATCH_EXIT%
