param(
    [string]$OriginalExe = '',
    [string]$OutputExe = ''
)

# Uses Windows PowerShell and .NET only. The formatter EXEs are never executed.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$originalStream = $null
$outputStream = $null
$temporaryPath = $null
$success = $false

function Get-StreamSha256([System.IO.Stream]$Stream) {
    $hash = [System.Security.Cryptography.SHA256]::Create()
    try {
        $Stream.Position = 0
        $bytes = $hash.ComputeHash($Stream)
        return ([System.BitConverter]::ToString($bytes)).Replace('-', '').ToLowerInvariant()
    }
    finally { $hash.Dispose() }
}

try {
    if ([string]::IsNullOrWhiteSpace($OriginalExe)) {
        Add-Type -AssemblyName System.Windows.Forms
        $picker = New-Object System.Windows.Forms.OpenFileDialog
        try {
            $picker.Title = 'Select your ORIGINAL Gorilla Model Formatter.exe'
            $picker.Filter = 'Gorilla Model Formatter.exe|*.exe'
            $picker.CheckFileExists = $true
            $picker.Multiselect = $false
            if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
                throw 'Cancelled. No formatter files were changed.'
            }
            $OriginalExe = $picker.FileName
        }
        finally { $picker.Dispose() }
    }
    $OriginalExe = [System.IO.Path]::GetFullPath($OriginalExe)
    if ([string]::IsNullOrWhiteSpace($OutputExe)) {
        $OutputExe = Join-Path $PSScriptRoot 'NewModelFormatter.exe'
    }
    $OutputExe = [System.IO.Path]::GetFullPath($OutputExe)
    if ([string]::Equals($OriginalExe, $OutputExe, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw 'Choose a different output filename. The original is never overwritten.'
    }
    if ([System.IO.File]::Exists($OutputExe) -or [System.IO.Directory]::Exists($OutputExe)) {
        throw "Output already exists: $OutputExe`nRename or move that existing output first. It was not overwritten."
    }
    $outputDirectory = [System.IO.Path]::GetDirectoryName($OutputExe)
    if (-not [System.IO.Directory]::Exists($outputDirectory)) {
        throw "Output folder does not exist: $outputDirectory"
    }

    $patchPath = Join-Path $PSScriptRoot 'formatter.patch.json.gz'
    $patchFile = [System.IO.File]::OpenRead($patchPath)
    $gzip = $null
    $reader = $null
    try {
        $gzip = New-Object System.IO.Compression.GZipStream($patchFile, [System.IO.Compression.CompressionMode]::Decompress)
        $reader = New-Object System.IO.StreamReader($gzip, [System.Text.Encoding]::UTF8)
        $patch = $reader.ReadToEnd() | ConvertFrom-Json
    }
    finally {
        if ($null -ne $reader) { $reader.Dispose() }
        if ($null -ne $gzip) { $gzip.Dispose() }
        $patchFile.Dispose()
    }
    if ($patch.format -ne 'gmf-copy-literal-v1') { throw 'Unsupported patch format.' }
    if ($patch.original_sha256 -notmatch '^[0-9a-f]{64}$' -or $patch.target_sha256 -notmatch '^[0-9a-f]{64}$') {
        throw 'Invalid patch SHA-256 metadata.'
    }
    $sourceSize = [long]$patch.original_bytes
    $targetSize = [long]$patch.target_bytes
    if ($sourceSize -le 0 -or $targetSize -le 0) { throw 'Invalid patch file sizes.' }

    Write-Host 'Checking your original EXE...'
    # FileShare.Read prevents modification while the original is checked/copied.
    $originalStream = [System.IO.File]::Open($OriginalExe, [System.IO.FileMode]::Open,
        [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
    if ($originalStream.Length -ne $sourceSize -or (Get-StreamSha256 $originalStream) -ne $patch.original_sha256) {
        throw 'This EXE does not match the supplied Gorilla Model Formatter 1.0 build. Select the ORIGINAL Gorilla Model Formatter.exe. No files were changed.'
    }

    $temporaryPath = Join-Path $outputDirectory ('.NewModelFormatter.' + [guid]::NewGuid().ToString('N') + '.tmp')
    $outputStream = [System.IO.File]::Open($temporaryPath, [System.IO.FileMode]::CreateNew,
        [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
    $buffer = New-Object byte[] 1048576
    Write-Host 'Building NewModelFormatter.exe...'
    foreach ($operation in $patch.operations) {
        $names = @($operation.PSObject.Properties.Name)
        if ($names.Count -eq 2 -and $names -contains 'offset' -and $names -contains 'length') {
            $offset = [long]$operation.offset
            $remaining = [long]$operation.length
            if ($offset -lt 0 -or $remaining -lt 0 -or $offset -gt $sourceSize -or $remaining -gt ($sourceSize - $offset)) {
                throw 'Patch copy operation exceeds the original EXE.'
            }
            if ($remaining -gt ($targetSize - $outputStream.Position)) { throw 'Patch exceeds expected output size.' }
            $originalStream.Position = $offset
            while ($remaining -gt 0) {
                $count = [int][Math]::Min([long]$buffer.Length, $remaining)
                $read = $originalStream.Read($buffer, 0, $count)
                if ($read -le 0) { throw 'Unexpected end of original EXE.' }
                $outputStream.Write($buffer, 0, $read)
                $remaining -= $read
            }
        }
        elseif ($names.Count -eq 1 -and $names -contains 'literal') {
            $bytes = [Convert]::FromBase64String([string]$operation.literal)
            if ($bytes.LongLength -gt ($targetSize - $outputStream.Position)) { throw 'Patch exceeds expected output size.' }
            $outputStream.Write($bytes, 0, $bytes.Length)
        }
        else { throw 'Invalid patch operation.' }
    }
    $outputStream.Flush()
    if ($outputStream.Length -ne $targetSize -or (Get-StreamSha256 $outputStream) -ne $patch.target_sha256) {
        throw 'Output integrity check failed. The partial output will be removed.'
    }
    $outputStream.Dispose()
    $outputStream = $null
    # Two-argument Move refuses an existing destination, including a late race.
    [System.IO.File]::Move($temporaryPath, $OutputExe)
    $temporaryPath = $null
    $success = $true
    Write-Host ''
    Write-Host 'Created successfully:' -ForegroundColor Green
    Write-Host $OutputExe
    Write-Host 'Your original EXE is unchanged. Open the new EXE and use your usual CakeView workflow.'
    Write-Host 'This is an experimental build; hair/cloth still require the stated validation and in-game checks.'
}
catch {
    Write-Host ''
    Write-Host ('Patch failed: ' + $_.Exception.Message) -ForegroundColor Red
}
finally {
    if ($null -ne $outputStream) { $outputStream.Dispose() }
    if ($null -ne $originalStream) { $originalStream.Dispose() }
    if ($null -ne $temporaryPath -and [System.IO.File]::Exists($temporaryPath)) {
        [System.IO.File]::Delete($temporaryPath)
    }
}
if (-not $success) { exit 1 }
exit 0
