"""Verified user-supplied HPL profiles; never estimated whole-body masks.

The original v40 Bryan and supplied formatted v41 Bryan were inspected with
native readers. Their Body/Head positions, remaps, triangles, UVs and material
bindings matched. This profile is only a data source: the caller must still
verify the actual current source-to-converted paired base and all mask IDs.
"""
import base64
import hashlib
import zlib

PROFILE_VERSION = 'verified-supplied-bryan-roh-hpl-1'
MODEL_SHA256 = 'f8116337693256b46c92036132af5c356ec3c70fb745967ba97d3283e7fc986c'
MODEL_BYTES = 9768676
BASE_SHA256 = '343eede12271859708f75b52deb28c92fae9fe5983dcbb7d37cd0684378d4f67'
BASE_BYTES = 5881276
INVALID_HPL_SHA256 = '57abd17dd82782bcd4c1509c311d3f70227af707e7975a2e1b3fcbf1eae2c3dd'
INVALID_HPL_BYTES = 81408
SUPPLIED_HPL_SHA256 = '3c4b880b325f1f424d8d0b8dae88f9f38d7263751b23654d2906fa6123dc00be'
SUPPLIED_HPL_BYTES = 67580

# Lossless compressed bytes of the already supplied original 159_Attire.hpl.
_PAYLOAD = (
    b'c-rmUMH3ZgfQC^9cXxMphX_t^NPyrF+}+(RgdoA45D4z>?(XjH?lLDe|6x{rt4{U4`+NIV_2Ma2sa%S36^o|`;a9v!l_LLL%a^EJD(rvPdPUnd'
    b'>K-CQ*XSWa{1qWYh;fW(0u!0UWTr5cX-sDZGnvI~{$>vUFqe7!%X}8FkVPzJ2}@bVa#paCRjg(WYgxy7Hn5RRY-S5v*~WHuu#;WvW)FMW$9@iQ'
    b'kV72i2uC@_aZYfOQ=H}uXF11tE^v`cT;>W_xyE&FaFbiy<_>qc$9*2~kVib`2~T;(b6)V0SG?v8Z+XXiKJbxGeC7*Z`9_F{Awv8QAqhoj!Vs2l'
    b'geL+Ki9}?g5S3^|Ck8QzMQq{_mw3b{0SQS&Vv>-QWF#jADM>|Y(vX&Pq$dLz$wX$dkd<s?CkHvnMQ-wtmwe=>00sGu@A-irDMVq4P?Ta6rvxSW'
    b'iBgoN3}q=tc`8tmO8m?(RHh15`ITx^rv^2tMQ!R(mwNn0eHze^Ml_}gO=(7RTF{bKw5APhX-9iH(2-7brVCx^Mt6G9lV0?u4}IxJe+Dp+K@4UH'
    b'Lm9?!erE)KFp@tR#c0MbmcJOscqTBBNla!6Q<=teW-yak%;s<A@DFpD$G^;H0Sj5gVwSL!Wh`d}D_O;A*07d!tY-ro*~DhHu$66WX9qjk#cuYn'
    b'mwoK#00%k5VUBQ=V;tuMCppDw&Ty7<oaX`;xx{6zaFuIZ=LR>q#cl3zmwVjj0S|e^W1jGoXFTTxFL}jl-td-pyypWS`NU_w@Re_bh-CkSBov_u'
    b'Ls-HQkw`=(8Zn4TEMgOfxWpqNiAYQml97Uxq#`wGNJ~1>lYxw6A~RXYN;a~SgPi0dH+jfQKJrt5f)u7G#VAfm%2J++oaPK?ImdY}aFI(~<_cH2'
    b'&JFHxmwVjj0S|e^W1jGoXFTTxFL}jl-td-pyypWS`NU_w@Re_bi0nBKl2C*u3}FdJcp?yyNJJ(IQHe%$Vi1#9#3l}LiAQ`AkdQ<qCJ9MNMsiY+'
    b'l2oK74QWY7dNPoaOk^etS;<Cra*&f;<R%Y!$wz()P>}EVo*(#;LKLP5MJYycN>GxYC`D<?P?mC(rvg=}Ms;dXlUmfK4t1$d0~*qZCN!lP&1peP'
    b'TG5&|w51*G=|D$1(U~rEr5oMpK~H+on?CfVKZ6<02u3o7v5aQ|lm2@yQ9KtClZ2!sBRMHZNh(s4hIFJSGg-(=HnNk0oa7=mdB{sX@>76<e8>0v'
    b'z>gH7FhwXzF^W@ylKey|N>hfil%qTqs7NJ#<`*hcg{u5YHL6pCn$)5;b*M`{exp7OXh<U((}bopqd6^TNh?~@hPJe$Jss#sCpy!Gu5_b2J?Kd<'
    b'deeu#^rJrm7|0+7GlZcGV>rJvf<G9^pNwKOV;IX{jAJ|#n8+k1Gli*4V>&aK$t-5`H*@%hxy<8V=Cgo>EMhTBSjsY%vx1eZVl``6%R1JxfsJfp'
    b'Gh5ioHny{ao$O*ad)Ui9_H%%P9O5uXILa}ObApqc;xuPC%Q?<-fs0(?GFQ0DHLi1mo800yceu+v?(=|$JmN7=c*--L^MaSW;x%u0%RAolfscIR'
    b'Ghg`1H$p`99wsEA2u&Em5{~dhAR>{7OcbILjp)Q6Cb5W39O4p>_#_}9iAYQml9G(%q#z}!NKG2jl8*FbAS0Q`Oct_|jqKzgC%MQ?9`cfp{1l)d'
    b'-|;;^@FRsNOc9DwjN+7_BtKD#(v+br<tR@DDpHA``Gv|<p(?*pjq22(Cbg(d9qLk#->6Rm8q$cyG@&WYXif`S(u&r!p)KubPX{{EiOzJPE8XZ$'
    b'4|>vz-t?g_{pimC1~Q1j3}Gn47|!pE;15RfC!-k67{>A!;~38bCNhc1Okpb1n9dAlGK<;#%^dz=F7x=8`7B@|i&)GOma>fHtY9UpSj`&NvX1p^'
    b'U?ZE@%oet?jqU7UC%f3q9`>@2{T$#Rhd9g;j&h9SoZuv<IL#T(a*p#{;3Ai}%oVP3jqBXtCbziF9qw|E`#j(wk9f=zp7M<6yx=9Tc+DH$@{ad>'
    b';3J>-%oo1$jS$i7pOAziG+_u!IKmTwh(sbXQHV-3q7#Fd#3D9vh)X=;lYoRIA~8uwN-~m@f|R5pHEBpoI?|JYjASA+S;$H@vXg_H<RUkD$V)!*'
    b'Q-Fee$M^iej})RXMJP%!ic^A;{6r~AQ--pXqdXO;NF{#e7b;VQs{Beds#AlS)S@<Zs7pP5qdpC2NFy54gr+p3IW1^OD_YZrwzQ)?9q33WI@5)&'
    b'bfY^x=t(bn(}%wFqdx-}$RGwYgrN*$IKMN3KN!iMjAArn7|UObV>}a>$Rs8+g{e$qIy0EbEN1gJbNGk3%;R6?vw(#xVlhit$}*O-f|aadHEUSQ'
    b'I@Ys+jcj5wTiD7rwzGqs>|!^2*vmflbAW>!;xI=z$}x^}f|H!$G-o)=InHx|i(KL|SGdYGu5*K%+~PKOxXV56^MHpu;xSKn$}^txf|tDFHE(#!'
    b'JKpnwk9^`YU--&5LPWQJLK2G5gdr^92u}ne5{bw}Au7>`P7Goai`c{=F7b#@0uqvl#3Ugp$w*ELQj&_)q#-ToNKXbbl8MY@AuHL)P7ZRCi`?WP'
    b'FZsw%0SfXR-}3`MQi#G7p(w>DP6<l#6Qw9k8Ol<Q@>HNAmH3%os7w{A@+;M-P7P{Oi`vwoF7^10`ZS;+jc800n$nEsw4f!eXiXd1(vJ3Ypd+2='
    b'Oqb~Y_l>$6-RVJ3deNIc^ravD8NfgWF_<9?Wf;Txoe})ONd9CLqZz~4|GtMaj`2)jB9oZR6s9tb>C9jzvzX1_%;6vAGLL_m&jJ>*h{Y^nDa%;S'
    b'3Rbd;)vRGH>sZeQHnNG$Y+)<g*v<}ivWwm9VK4jG&jAi{h{GJ=D91R?2~Ki~)12Wf=Qz&=E^>*>T;VF$xXul3a*NyC;V$>M&jTLvh{rtPDbIM$'
    b'3tsYy*Sz5^?|9D#KJtmreBmqK2ob~n2}vkI6Na#aBRmm^NF*W?g{VX$Ix&bzEMgOfxWpqq2}npH5|f0aBqKQ~NJ%PElZLdUBRv_&NG39qg{)*F'
    b'J2}WnE^?EHtEt^zu5*K%+~PKOxXV56^MHpu;xSKn$}^txf|tDFHE(#!JKpnwk9^`YU--&5LZoqj2}vkI6Na#aBRmm^NF*W?g{VX$Ix&bzEMgOf'
    b'xWpqq2}npH5|f0aBqKQ~NJ%PElZLdUBRv_&NG39qg{)*FJ2}WnE^?EHyyPQ41t`dOe9sU3NFfSSgrXFqI3*~_Pn4oGWhhHI%2R=gRN`lTp)ysd'
    b'%CA(TIyI<CEoxJTy42%0>eGORG@>z0Xi77h(}I??qBU)3OFP=rfsS;dGhOIPH@ee<p7f$OedtR+`ZIum3}P@t7|Jk)^E)H>gOU8nC`L1evHZn2'
    b'#xsG5Oky%qn94M!GlQATVm5y>hkuyMJpN@q3s}e^7PEw<EMqw<Sjj3@vxc>-V?7(#$R;+kg{^F3J3H9PE_Snrz3gK@2RO(f4s(Q~9OF1AILRqa'
    b'bB42=<2)C*$R#dwg{xfSIybn<EpBs%yWHbG4|vEU9`l5!JmWbpc*!eX^M<#)<2@hv$R|GYg|B=gL|XeNB%ugR7{U^c@I)XYk%&wbq7seh#2_ZI'
    b'h)o>g5|8*KAR&oJOcIikjO3&sC8<bF8q$)E^kg6-naE5QvXYJL<RB-x$W0#dl8^ippdjDzJwNaxg(yrBic*Z?l%OO(QHs)(p)BPnPX#JciJ$p}'
    b'%2c5$zfz6r)SxD{s7)Q}Qjg!LPXij#h{iObDa~k33tG~O*0iB5?PyO2I?{>GbfGKV=uQuM(u>~op)dXD&j1E8h`|hDD8m@e?~LFNM)D`47|j^Q'
    b'@)zS6&jcniiOEc1D$|(G3}!Nm+5F8M{$Vcj_?P)CU?GcG%o3KejODCgC97D?8rHIo^=x1xo7l`2wz7@w>|iIm*v%gHvXA{7;2?)M%n^=qjN_c('
    b'B&Rsd8P0N!^IYH}m$=Lou5yj*+~6j+xXm5za*z8w;31EA%oCpSjOV=IC9inR8{YDc_k7?ZpZLrdzVeL_>Fl47gd#Ly2unD^6M=|CA~I2kN;IMq'
    b'gP6o3HgSkcJmQmpgd`#{Nk~dEl9Pgzq#`wGNJ~1>lYxw6A~RXYN;a~SgPi0dH+jfQKJrt5f_%sK{J@VCqA*1$N->I4f|C41DN0j@vXrAd6{tuh'
    b'e&!b{Q-!MhN;RregPPQ$Hg%{=J$|D;4QNOs8q<WPG^05!Xh|zt(}uRRqdgtyNGCeeg|2j?J3Z)0FM895zVxF%0~p941~Y`A3}ZOIGlD-D$)Aj3'
    b'G-DXcUyNfs6PU;(CNqVpOk+ATn8_?=^EY$&hq=t-U*@xbg)Cw*OIXS>ma~GDtYS55Sj#%rvw@9lVl!LV$~LyMgPrVRH+$I2KK65fgB;>8M>xtc'
    b'j&p*OoZ>WRILkTCbAgLo;xbpb$~CTYgPYvqHg~woJ?`^>hdkmjPk72Rp7Vm2yy7))c*{H9^MQ|i;xk|P$~Qu!w|_zsiqM21Ea3=G1R@fN$V4G3'
    b'(TGkAViJqk#33&6h))6%l8D44At}j7P6|?ziqxbbE$K*41~QU~%w!=e*~m@~a*~VO<RLHl$WH+Z@*Usv13yxT!W5w>#VAe*O7at>C`}p4QjYRe'
    b'pdyv{nO~?(6{_+p)u>JlYEp~Z)S)i*_>KBBpdpQDOcR>YjOMhUC9P;p8`{#2_H>{lo#;##y3&pA^q?ob=uIE`(vSWOU?77S%n*h$jN$yw2>xIs'
    b'e=>^EjA1N)F^=&}U?P*4%oL_Fjp@u_CbO8$-^}43<}#0ena=_ivWUejVJXX4&I(qtiq))PE$dj%1~#&Z&1_*S+t|(ycCw4z>|rna*v|nDa)`qm'
    b';V8#A&IwL(iqo9oEay1S1uk-l%Ut0q*SO9NZgPv;+~F?wxX%L~@`%Sg;VI8}&I?}hir2j1E$?{G2R`zN&wSx4-w2Vx{s~DaLKB9tgd;o=h)5(N'
    b'6NRWmBRVmNNi1R$hq%NeJ_$%jA`+8?q$DFbDM(2wQj><Xq$52U$VetKlZC8gBRe_BNiK3zh{6=11SKg&Y06NJ@>HY}Kl2NfsX|qLr5e?#K}~8='
    b'n>y5`9=}na1~jA*jcGztn$esVw4@cSX+vAu(Vh-;q!XR#LRY%cogVb04}Iy!00uIM!3<$2!x_OSMl+Vb7|&#;GM$;sVh(ee$9xvDh;?lI?`&jp'
    b'HV91^!V-?~L?9xOh)fis5{>A@ASSVhO&sD9kN6}YA&E&sQj(FJ6r>~-sYydx(vhAFWF!-r$wF4Lk)0gmBp12KLtgTcp8^!*JHF=!exwkEDMC?-'
    b'QJfN#<R?l|nlhB79ObD%MJn+#zfhSfROMHyQJospq!zWQLtX0e8}(^GLmJVTCN!lP&1pePTG5&|w51*G=|D$1(U~rEr5oMpK~H+on?CfVAN?7?'
    b'Kn5|GAq-_0!}*;N{J}{6WE7(r!&v@e9OIe5L?$trDNJP=)0x3cW-*(;nZrNKWgh=Bp9L&r5sO*EQkJot6|7_xt69TZ*0G)qY-AIg*}_(~v7H_4'
    b'WEZ>H!(R5Wp937^5QjO!QI2t(6P)A}r#Zt}&T*a#T;vj$xx!Vhah)67<QBKN!(Hxip9ehT5s!JoQ=ajh7rf*ZuX)2;-tnFfeB=|K`NCJe5hAny'
    b'1ws;v(1al@;RsIzA`*$nL?J5Ch)xV*5{uZxAujQVPXZE>h{PlzDalAq3R04a)TALT=}1ooGLnhRWFafr$W9J&l8fBrAusvJPXP+@9pCc<KT?Ro'
    b'6rm`^C{77V@)M;fO&Q8kj`CEXB9-`=U#LtKs`4w<s7?)PQj6Nup)U3Kjrug8A&qEE6PnVD=Cq(Ct!Paf+R~2pbf6=h=u8*7(v9x)peMcPO&|Kw'
    b'kNyl`AcGjp5QZ|0;rz}B{$M13GK$fRVJzdAz(gi7g=tJ@2D6yWd={{f#Vlbd%UI3|R<erKtYIzdSkDGFvWd-XVJq9%&JK36i{0#DFZ<Zf0S<DA'
    b'!yMr#$2iUjPI8LVoZ&3zIL{?6bA@YM=LR>q#cl3#kH<XW8P9piTi)}L&wSx4-w2V#9tlY(>Sc9Cs80hL(ul@1p()L1P77Mniq^EDE$wJe2RhP;'
    b'&UB$G-RVJ3deNIc^ravD8NfgWF_<9?Wf;Txoe})ONd9CLqZz|k{$d>CnZQIQF_|e$Wg63&!Axc`o4=XEKg?ww|1zHiEMyUjS;A75v78mGWEHDf'
    b'!&=s{o(*hd6Pww>R<^O79qeQmyV=8D_OYJ>9OMv(Il@tnahwyJ<P@hl!&%O8o(o*$5|_EcRjzTJ8{Fg;x4FYz?s1<7Jme9NdBRhk@thaD<Q1=Z'
    b'!&~0*o)3KF6QB9QSH2M<oAXFWLJ^uUge4r|i9kdm5t%4NB^uF*K}=#1n>fTJ9`Q*)LK2afBqSvn$w@&<QjwZ8q$M5c$v{Rjk(n%HB^%kvK~8d!'
    b'n>^$tANeUjLB8XAe&9z6QJ5kWr5MF2K}mk16s0LcS;|qK3RI*LKl2NfsX|qLr5e?#K}~8=n>y5`9=}na1~jA*jcGztn$esVw4@cSX+vAu(Vh-;'
    b'q!XR#LRY%cogVb07rp62U;5FX0SsgigBik5hB2Jq8NnZn<WEL1nlX&!FUB#R2~1=XlbOO)rZJrv%w!g``I|ZX!(8U^FY{TzLKd-@B`jqb%UQun'
    b'R<W8jtYsbR*}z6Nv6(GwWgFYs!A^Fun?3AhANx7LK@M@4BOK)z$2q}CPH~zuoaG$nxxhs(ahWSz<r>$y!A)*)n>*a)9`|{`Lmu&%Cp_gD&w0U1'
    b'Uh$eYyyYG5`M^g$@tH4t<r^Wg+dm-*MQFkhmT-h80uhNsWTFt2XhbIlF^NTN;t-d3#3um>Nkn3jkd$O3Cj}`<MQYNJmUN^i0~yIgX0ni#Y-A?~'
    b'ImtzC@{pH&<fi}y`Ht`TfgdSEVTw?cViczYCHaX`l%@=2DMxuKP?1Xf%r8`?3RU@)YE-8NHK|2y>QI+@{6>8m(2zznrU^}HMsr%wl2){)4Q**h'
    b'dpgjOPIRUVUFk-5deD<z^rjDe=|_JCFpxnEW(Y$W#&CXT1b;A+KN-bn#xRz@7{_=fFp)`2W(rf8#&l*dlUdB>Z|3k1bD77#%x3`$S;S(Nu#{yi'
    b'X9X)+#cI~DmUXOW0~^`IX11`EZER-;JK4o<_OO?I?B@UnImBU(aFk;l=L9D?#c9rPmUEov0vEZ&Wv+0QYh33BH@U@a?r@iT+~)xgdBkI$@RVmf'
    b'=LIi$#cSU1mUq1810VUsXTI>2Z-mHU|AZtIp$S7+!V#VbL?jZCi9%GO5uF&sBo?uWLtNq!p9CZ%5s67cQj(FJ6r>~-sYydx(vhAFWF!-r$wF4L'
    b'k)0gmBp12KLtgTcp8^!*JHF=!exwkEDMC?-QJfN#<R?l|nlhB79ObD%MJn+#zfhSfROMHyQJospq!zWQLtX0e8}(^GLmJVTCN!lP&1pePTG5&|'
    b'w51*G=|D$1(U~rEr5oMpK~H+on?CfVAN?7?Kn5|GAq-_0!}*;N{J}{6WE7(r!&v@e9OIe5L?$trDNJP=)0x3cW-*(;nZrNKWgh=Bp9L&r5sO*E'
    b'QkJot6|7_xt69TZ*0G)qY-AIg*}_(~v7H_4WEZ>H!(R5Wp937^5QjO!QI2t(6P)A}r#Zt}&T*a#T;vj$xx!Vh<@mqu!~X=`hoJiqbRUB5L(qK)'
    b'x(`A3A?Q8?-G`w25Og1c?nBUh2)YkJ_aW#$1l@<A`w(;=g6>1meF(Y_LH8l(J_Ox|p!*PXAA;^f(0vHH4?*`K=spD9hoJiqbRUB5L(qK)x(`A3'
    b'A?Q8?-G`w25Og1c?nBUh2)YkJ_aW#$1l@<A`w(;=g6>1meF(Y_LH8l(J_Ox|p!*PXAA;^f(0vHH4?*`K=spD9hyVBPL%E8@Q~cL`_^<yEBIrK^'
    b'{fD6c5cD5{{zK4z2>K5}{~_o<1pSAg{}A*ag8oC$e+c>yLH{A>KLq`Up#Ko`AA<fv(0>T}4?+JS=syJghoJuu^dEx$L(qQ+`VT?>A?QB@{fD6c'
    b'5cD5{{zK4z2>K5}{~_o<1pSAg{}A*ag8oC$e+c>yLH{A>KLq`Up#Ko`AA<fv(0>T}4?+JS=syJghoJuu^dEx$L(qQ+`VT?>A?QE+zxN;h>puKX'
    b'(0vHH4?*`K=spD9hoJiqbRUB5L(qK)x(`A3A?Q8?-G`w25Og1c?nBUh2)YkJ_aW#$1l@<A`w(;=g6>1meF(Y_LH8l(J_Ox|p!*PXAA;^f(0vHH'
    b'4?*`K=spD9hoJiqbRUB5L(qK)x(`A3A?Q8?-G`w25Og1c?nBUh2)YkJ_aW#$1l@<A`w(;=g6>1meF(Y_LH8l(J_Ox|p!*PXAA;^f(0%xS?>>~M'
    b'P&|bdhWKC34Ye@'
 )


def supplied_hpl():
    data = zlib.decompress(base64.b85decode(_PAYLOAD))
    if len(data) != SUPPLIED_HPL_BYTES or hashlib.sha256(data).hexdigest() != SUPPLIED_HPL_SHA256:
        raise ValueError('verified supplied Bryan HPL payload failed its integrity check')
    return data


def select_profile(model_fingerprint, base_fingerprint, sidecar_fingerprint):
    """Select an exact legacy pair and exact invalid same-stem sidecar."""
    if (model_fingerprint != (MODEL_SHA256, MODEL_BYTES)
            or base_fingerprint != (BASE_SHA256, BASE_BYTES)
            or sidecar_fingerprint != (INVALID_HPL_SHA256, INVALID_HPL_BYTES)):
        from gmf_flip_supplied_mask import select_profile as select_flip
        return select_flip(model_fingerprint, base_fingerprint, sidecar_fingerprint)
    return {'data': supplied_hpl(), 'profile': PROFILE_VERSION,
            'supplied_hpl_sha256': SUPPLIED_HPL_SHA256,
            'supplied_hpl_bytes': SUPPLIED_HPL_BYTES,
            'scope': 'original user-supplied mask for the verified identical Bryan geometry; no generated coverage'}
