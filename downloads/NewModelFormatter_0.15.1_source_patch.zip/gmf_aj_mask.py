"""Exact-pair experimental AJ foot mask; never rebuild geometry or physics.

The supplied native 2K26 pair has empty embedded masks. Change only the exact
empty-HPL tail, using real paired-body foot/toe remap IDs. No broad mask guess.
"""
import functools
import hashlib
import os
from pathlib import Path
import struct
import tempfile

PATCH_VERSION='exact-aj-foot-mask-1'
ATTIRE_SHA256='3e8097ef504724d688fe526868f876f27c3174ed6f574cc3239ada5eb7c80ceb'
BASE_SHA256='765e2c10231bb5a15920b85cc4a3959ac90e0c7f527133a8ba3d5f0aa843f0f7'
IDS_SHA256='a44eb2f78ee8d9e32c97e1394ac1a6c7552569a16410abeeb4f601614e615150'
EMPTY_HPL=b'HPL!END!\0\0\0\0'
END=struct.pack('<II4s',4,0,b'END!')
TAIL=struct.pack('<II4s',4,len(EMPTY_HPL),b'HPL!')+EMPTY_HPL+END
FOOT_BONES=('J_Foot_L','J_Toe_L','J_Foot_R','J_Toe_R')


def digest(data):return hashlib.sha256(data).hexdigest()


def foot_ids(model):
    import numpy as np
    if model.version!=47:raise ValueError('AJ paired base must be native 2K26')
    bodies=[m for m in model.meshes if m.name=='M_Body']
    if len(bodies)!=1:raise ValueError('AJ paired base must have exactly one M_Body')
    body=bodies[0]
    if body.num_verts!=12763:raise ValueError('AJ body vertex domain changed')
    remap=np.asarray(body.vertex_remap)
    if remap.shape!=(body.num_verts,) or len(set(map(int,remap)))!=body.num_verts:
        raise ValueError('AJ body remap domain is missing or ambiguous')
    total=np.zeros(body.num_verts,dtype=np.float64)
    for name in FOOT_BONES:
        if name not in body.weights:raise ValueError('AJ body lacks '+name)
        weights=np.asarray(body.weights[name],dtype=np.float64)
        if weights.shape!=total.shape or not np.isfinite(weights).all() or (weights<0).any():
            raise ValueError('AJ foot weights are invalid')
        total+=weights
    ids=sorted(set(map(int,remap[total>.5])))
    packed=struct.pack('<'+'I'*len(ids),*ids)
    if len(ids)!=2108 or digest(packed)!=IDS_SHA256:
        raise ValueError('AJ paired foot/toe mask domain differs from inspected input')
    return ids


def build_mask(mcd,ids):
    expected={0:[('M_Body',ids)],1:[('M_Body',ids)]}
    data=mcd.build_hpl(expected)
    if not mcd.hpl_is_whole(data):raise ValueError('generated AJ foot mask is incomplete')
    parsed=mcd.parse_hpl(data)
    if set(parsed)!=set(range(5)) or any(v!=expected for v in parsed.values()):
        raise ValueError('generated AJ foot mask did not preserve both flags at five LODs')
    return data


def replace_empty_tail(data,mask):
    if not data.endswith(TAIL):raise ValueError('AJ empty HPL tail differs; existing mask was preserved')
    return data[:-len(TAIL)]+struct.pack('<II4s',4,len(mask),b'HPL!')+mask+END


def _stage_model(target,data,vc,mask):
    handle,name=tempfile.mkstemp(prefix='.aj-mask-',suffix='.mcd',dir=target.parent)
    stage=Path(name)
    try:
        with os.fdopen(handle,'wb') as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        read=vc.read_model(str(stage),with_shapes=True)
        streams=[payload for tag,payload in read.substreams if tag==b'HPL!']
        if read.version!=47 or streams!=[mask]:raise ValueError('native reader rejected embedded AJ foot mask')
        os.replace(stage,target)
    finally:
        if stage.exists():stage.unlink()


def process(report,folder,log):
    for record in report.get('models',[]):
        if record.get('source_version')!=47 or record.get('status')!='preserved_2k26':continue
        if record.get('facts',{}).get('source_sha256')!=ATTIRE_SHA256:continue
        source=Path(record['source']);target=Path(record['output'])
        try:
            original=source.read_bytes()
            if digest(original)!=ATTIRE_SHA256:raise ValueError('AJ source changed after preservation audit')
            base=source.parent.parent/'BaseModel'/'baseModel.mcd'
            if digest(base.read_bytes())!=BASE_SHA256:raise ValueError('exact paired AJ BaseModel/baseModel.mcd is required')
            if source.with_suffix('.hpl').exists() or target.with_suffix('.hpl').exists():raise ValueError('separate HPL present; existing mask was preserved')
            if target.read_bytes()!=original:raise ValueError('AJ output changed before mask repair')
            ids=foot_ids(folder.vc.read_model(str(base)))
            mask=build_mask(folder.mcd,ids)
            changed=replace_empty_tail(original,mask)
            if changed[:-len(mask)-24]!=original[:-len(TAIL)]:raise ValueError('AJ model payload changed')
            _stage_model(target,changed,folder.vc,mask)
            record['status']='repaired_2k26_foot_mask'
            record['verification_scope']='byte_preserved_model_payload_and_native_mask_reader'
            record['notes']=[n for n in record.get('notes',[]) if not n.startswith('Native model bytes preserved;')]
            record['notes'].append('Exact-pair experimental AJ foot-only hide mask generated; model geometry, rig, shapes and weights unchanged. No full outfit mask or beard repair.')
            record.setdefault('repairs',[]).append('exact_aj_foot_mask')
            facts=record.setdefault('facts',{})
            facts.update(output_sha256=digest(changed),byte_identical=False,
                         geometry_weights_bones_and_embedded_streams='model payload byte-identical; empty HPL replaced')
            record['aj_foot_mask']={'patch':PATCH_VERSION,'body_indices':len(ids),'flags':[0,1],
                'lods':list(range(5)),'paired_base_sha256':BASE_SHA256,'indices_sha256':IDS_SHA256,
                'mask_sha256':digest(mask),'mask_bytes':len(mask),'model_payload_byte_identical':True,
                'native_reader_passed':True,'in_game_validation':'required'}
            report['native_2k26_models_preserved']=max(0,report.get('native_2k26_models_preserved',0)-1)
            report['native_2k26_masks_repaired']=report.get('native_2k26_masks_repaired',0)+1
            message=str(source.name)+': experimental AJ foot mask generated; in-game boot coverage check required'
            report.setdefault('problems',[]).append(message)
            log('  '+message)
        except Exception as error:
            message=source.name+': AJ foot mask not applied: '+str(error)
            report.setdefault('problems',[]).append(message)
            record.setdefault('problems',[]).append(message);record['verify']='fail'
            log('  '+message)
    report['conversion_completeness']='incomplete' if report.get('problems') else 'structural_checks_only'


def install(folder):
    if getattr(folder,'_aj_foot_mask_patch',None)==PATCH_VERSION:return
    import inspect
    original=folder.convert_folder
    @functools.wraps(original)
    def convert_folder(*args,**kwargs):
        bound=inspect.signature(original).bind(*args,**kwargs);bound.apply_defaults()
        report=original(*args,**kwargs)
        process(report,folder,bound.arguments['log'])
        from gmf_report import save_intermediate
        save_intermediate(report,bound.arguments['dst'])
        return report
    folder.convert_folder=convert_folder
    folder._aj_foot_mask_patch=PATCH_VERSION
