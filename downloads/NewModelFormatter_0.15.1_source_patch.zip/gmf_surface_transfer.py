"""Standalone nearest-surface weights, using inspected PWM triangle math.

BVH acceleration and native-model adaptation are new. This is a guarded
comparative gear policy, not an assertion of Blender Heat Seek equivalence.
"""
import hashlib
import heapq
import math

from gmf_surface_math import _closest_point_bary


def _point(value):
    point=tuple(float(x) for x in value)
    if len(point)!=3 or not all(math.isfinite(x) for x in point):
        raise ValueError('surface positions must be finite 3D coordinates')
    return point


def _area_squared(a,b,c):
    ab=[b[i]-a[i] for i in range(3)];ac=[c[i]-a[i] for i in range(3)]
    cross=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]]
    return sum(x*x for x in cross)


class Surface:
    def __init__(self, positions, triangles):
        self.positions=[_point(p) for p in positions]
        self.triangles=[]
        for row in triangles:
            indices=tuple(int(x) for x in row)
            if len(indices)!=3 or any(x<0 or x>=len(self.positions) for x in indices):
                raise ValueError('surface triangle index outside donor positions')
            self.triangles.append(indices)
        valid=[i for i,t in enumerate(self.triangles)
               if _area_squared(*(self.positions[j] for j in t))>1e-20]
        self.degenerate_triangles=len(self.triangles)-len(valid)
        if not valid:raise ValueError('donor has no usable surface triangles')
        self.nodes=[]
        self._build(valid)

    def _build(self, ids):
        points=[self.positions[j] for i in ids for j in self.triangles[i]]
        lower=tuple(min(p[k] for p in points) for k in range(3))
        upper=tuple(max(p[k] for p in points) for k in range(3))
        node=len(self.nodes);self.nodes.append(None)
        if len(ids)<=8:
            self.nodes[node]=(lower,upper,tuple(sorted(ids)),None)
        else:
            axis=max(range(3),key=lambda k:upper[k]-lower[k])
            ids.sort(key=lambda i:(sum(self.positions[j][axis] for j in self.triangles[i]),i))
            mid=len(ids)//2
            children=(self._build(ids[:mid]),self._build(ids[mid:]))
            self.nodes[node]=(lower,upper,None,children)
        return node

    @staticmethod
    def _distance(point, node):
        lower,upper=node[:2]
        return sum(max(lower[k]-point[k],0.0,point[k]-upper[k])**2 for k in range(3))

    def nearest(self, point):
        point=_point(point);best=float('inf');result=None;queue=[(0.,0)]
        while queue:
            bound,node_id=heapq.heappop(queue)
            if bound>best+1e-12:continue
            node=self.nodes[node_id]
            if node[2] is not None:
                for i in node[2]:
                    bary,d2=_closest_point_bary(point,*(self.positions[j] for j in self.triangles[i]))
                    if d2<best or (d2==best and (result is None or i<result[0])):
                        best=d2;result=(i,bary,d2)
            else:
                for child in node[3]:
                    d2=self._distance(point,self.nodes[child])
                    if d2<=best+1e-12:heapq.heappush(queue,(d2,child))
        if result is None:raise ValueError('no donor projection')
        return result


def transfer_weights(mesh, donor, allowed_bones, *, cache=None, donor_sha256=None):
    """Project every target vertex; mutate weights only after full validation.

    Cleanup follows the reference 1% cutoff and normalization. Native format's
    eight-influence budget is enforced explicitly; ties use bone name order.
    Geometry/UVs/remaps/materials and the donor are never changed.
    """
    import numpy as np
    count=mesh.num_verts
    positions=np.asarray(mesh.positions)
    if positions.shape!=(count,3):raise ValueError('target positions differ from vertex count')
    allowed=set(allowed_bones)
    key=donor_sha256
    if cache is not None and key in cache:
        surface,names,weights=cache[key]
    else:
        names=sorted(donor.weights)
        if not names:raise ValueError('paired body donor has no weights')
        weights=np.asarray([donor.weights[n] for n in names],dtype=np.float64).T
        if weights.shape!=(donor.num_verts,len(names)) or len(donor.positions)!=donor.num_verts:
            raise ValueError('donor weight domain differs from positions')
        if not np.isfinite(weights).all() or (weights<0).any():raise ValueError('invalid donor weights')
        if (weights.sum(axis=1)<=1e-7).any():raise ValueError('paired body donor has unweighted vertices')
        unknown=[n for i,n in enumerate(names) if n not in allowed and weights[:,i].max()>1e-7]
        if unknown:raise ValueError('donor weighted bones are absent from attire rig: '+', '.join(unknown))
        surface=Surface(donor.positions,donor.triangles)
        if cache is not None:cache[key]=(surface,names,weights)
    # Recheck a cached donor against this target's allowed rig.
    if any(n not in allowed and weights[:,i].max()>1e-7 for i,n in enumerate(names)):
        raise ValueError('cached donor weighted bones are absent from attire rig')
    projected=np.zeros((count,len(names)),dtype=np.float64)
    distances=[];capped=0
    for i,p in enumerate(positions):
        triangle,bary,d2=surface.nearest(p)
        row=np.asarray(bary)@weights[list(surface.triangles[triangle])]
        row[row<.01]=0.
        keep=sorted(np.flatnonzero(row),key=lambda k:(-row[k],names[k]))
        if len(keep)>8:
            row[keep[8:]]=0.;capped+=1
        total=float(row.sum())
        if total<=1e-7:raise ValueError('surface cleanup left target vertex unweighted: '+str(i))
        projected[i]=row/total;distances.append(math.sqrt(max(0.,d2)))
    if not np.isfinite(projected).all() or (projected<0).any():raise ValueError('invalid surface output')
    if count and not np.allclose(projected.sum(axis=1),1.,rtol=0,atol=1e-6):
        raise ValueError('surface output influence budgets are not normalized')
    result={name:projected[:,i].astype(np.float32) for i,name in enumerate(names) if projected[:,i].max()>1e-7}
    mesh.weights=result
    return {'mesh':mesh.name,'old_groups':0,'verts_changed':count,'kept_own_part':0,
            'policy':'paired_body_nearest_surface_reference_math',
            'reference_cleanup_threshold':.01,'max_influences':8,
            'vertices_capped_to_native_budget':capped,
            'donor_sha256':donor_sha256,'donor_mesh':donor.name,
            'max_distance_to_paired_body':max(distances,default=0.),
            'mean_distance_to_paired_body':sum(distances)/max(1,len(distances)),
            'ignored_degenerate_donor_triangles':surface.degenerate_triangles,
            'blender_heat_seek_equivalence':'not_claimed',
            'in_game_validation':'required'}
