"""Audit existing native masks and embed only a validated matching sidecar."""
import hashlib
from pathlib import Path
import os
import struct
import tempfile


def envelopes(data):
    if data[:4]!=b'MCD!':raise ValueError('native mask repair supports framed MCD containers only')
    frames=[];position=4
    while position<len(data):
        if position+12>len(data):raise ValueError('MCD envelope is truncated')
        version,size,tag=struct.unpack_from('<II4s',data,position)
        if version!=4:raise ValueError('unsupported MCD envelope version')
        end=position+12+size
        if end>len(data):raise ValueError('MCD envelope payload is truncated')
        payload=data[position+12:end]
        frames.append({'tag':tag,'start':position,'end':end,'payload':payload})
        if tag==b'END!':
            if size or end!=len(data):raise ValueError('MCD terminal envelope is invalid')
            break
        position=end
        if position%4:
            aligned=(position+3)&~3
            if data[position:aligned]!=bytes(aligned-position):raise ValueError('MCD alignment bytes are unsupported')
            position=aligned
    if not frames or frames[0]['tag']!=b'MDL!' or frames[-1]['tag']!=b'END!':
        raise ValueError('MCD model or terminal envelope is missing')
    if sum(f['tag']==b'MDL!' for f in frames)!=1:raise ValueError('MCD has ambiguous model envelopes')
    return frames


def splice_mask(data,mask):
    frames=envelopes(data);masks=[f for f in frames if f['tag']==b'HPL!']
    if len(masks)>1:raise ValueError('multiple embedded HPL streams; mask not guessed')
    frame=masks[0] if masks else frames[-1]
    start=frame['start'];end=frame['end'] if masks else start
    if end%4 and masks:end=(end+3)&~3
    changed=data[:start]+struct.pack('<II4s',4,len(mask),b'HPL!')+mask+data[end:]
    after=envelopes(changed)
    original_other=[(f['tag'],f['payload']) for f in frames if f['tag']!=b'HPL!']
    written_other=[(f['tag'],f['payload']) for f in after if f['tag']!=b'HPL!']
    if original_other!=written_other:raise ValueError('native model or non-mask substream changed')
    return changed


def body_domains(model):
    result={}
    for mesh in model.meshes:
        if mesh.name not in ('M_Body','M_Head'):continue
        if mesh.name in result:raise ValueError('paired base has ambiguous '+mesh.name)
        remap=mesh.vertex_remap
        ids=list(range(mesh.num_verts)) if remap is None else [int(i) for i in remap]
        if len(ids)!=mesh.num_verts or any(i<0 for i in ids):
            raise ValueError('paired base has invalid remap domain')
        result[mesh.name]=set(ids)
    if not result:raise ValueError('paired base has no body/head domains')
    return result


def validate_mask(data,mcd,domains):
    if data==b'HPL!END!\0\0\0\0':raise ValueError('hide mask is empty')
    if not mcd.hpl_is_whole(data):raise ValueError('hide-mask structure is unreadable or incomplete')
    parsed=mcd.parse_hpl(data)
    if not parsed or not any(ids for flags in parsed.values() for groups in flags.values() for name,ids in groups):
        raise ValueError('hide mask is empty')
    for lod,flags in parsed.items():
        for flag,groups in flags.items():
            for name,ids in groups:
                if name not in domains:raise ValueError('hide mask names an unavailable paired-base mesh: '+name)
                if any(int(i) not in domains[name] for i in ids):raise ValueError('hide mask index is outside actual paired-base domain: '+name)
    return parsed


def paired_domains(source,target,vc):
    for suffix in ('.mcd','.mdl'):
        original=Path(source).parent.parent/'BaseModel'/('baseModel'+suffix)
        written=Path(target).parent.parent/'BaseModel'/('baseModel'+suffix)
        if not original.is_file():continue
        if not written.is_file() or original.read_bytes()!=written.read_bytes():
            raise ValueError('matching native paired base was not preserved')
        model=vc.read_model(str(written))
        if model.version!=47:raise ValueError('matching paired base is not native 2K26')
        return body_domains(model),str(written)
    raise ValueError('matching BaseModel/baseModel.mcd or .mdl is absent')


def staged_mask(target,data,mask,vc):
    target=Path(target)
    handle,name=tempfile.mkstemp(prefix='.native-mask-',suffix='.mcd',dir=target.parent)
    stage=Path(name)
    try:
        with os.fdopen(handle,'wb') as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        model=vc.read_model(str(stage),with_shapes=True)
        streams=[payload for tag,payload in model.substreams if tag==b'HPL!']
        if model.version!=47 or streams!=[mask]:raise ValueError('native reader rejected recovered mask')
        if stage.read_bytes()!=data:raise ValueError('staged native mask bytes changed')
        os.replace(stage,target)
    finally:
        if stage.exists():stage.unlink()


def audit_mask(source,target,model,folder):
    result={'state':'not_required_on_base_model','findings':[],'repairs':[]}
    if Path(target).parent.name.casefold()=='basemodel':return result
    streams=[data for tag,data in model.substreams if tag==b'HPL!']
    result['embedded_stream_count']=len(streams)
    result['embedded_mask_state']='absent' if not streams else 'present'
    if len(streams)==1:
        parsed={} if streams[0]==b'HPL!END!\0\0\0\0' else folder.mcd.parse_hpl(streams[0]) if folder.mcd.hpl_is_whole(streams[0]) else None
        result['embedded_mask_state']=('unreadable' if parsed is None else
            'nonempty' if any(ids for flags in parsed.values() for groups in flags.values() for name,ids in groups) else 'empty')
    try:domains,base=paired_domains(source,target,folder.vc)
    except ValueError as error:
        result.update(state='paired_base_unavailable',paired_base_error=str(error))
        result['findings'].append({'category':'mask','state':'paired_base_unavailable',
            'expected_file':str(Path(source).parent.parent/'BaseModel'/'baseModel.mcd'),
            'action':'supply the matching native paired base to validate mask indices'})
        return result
    result['paired_base']=base;result['base_domains']={name:len(ids) for name,ids in domains.items()}
    if len(streams)>1:
        result['state']='ambiguous_embedded_masks';result['findings'].append({'category':'mask','state':result['state']});return result
    issue=None
    if not streams:issue='embedded_mask_absent'
    else:
        try:
            parsed=validate_mask(streams[0],folder.mcd,domains)
            result.update(state='readable_indices_valid',lods=sorted(parsed),
                counts={str(l):{str(f):{n:len(ids) for n,ids in groups} for f,groups in flags.items()} for l,flags in parsed.items()})
            result['coverage_validation']='index domains checked; outfit coverage and in-game visibility not established'
            return result
        except ValueError as error:issue=str(error)
    sidecar=Path(source).with_suffix('.hpl')
    if not sidecar.is_file():
        result.update(state='empty_missing_or_invalid_mask',reason=issue)
        result['findings'].append({'category':'mask','state':'valid_mask_not_available','expected_file':str(sidecar),
            'reason':issue,'action':'no usable sidecar in selected files; no whole-body mask generated'})
        return result
    try:
        supplied=sidecar.read_bytes();parsed=validate_mask(supplied,folder.mcd,domains)
        if 0 not in parsed or any(flags!=parsed[0] for flags in parsed.values()):
            raise ValueError('nonuniform sidecar LOD masks require a known matching LOD map')
        mask=folder.mcd.build_hpl(parsed[0]);checked=validate_mask(mask,folder.mcd,domains)
        if set(checked)!=set(range(5)) or any(flags!=parsed[0] for flags in checked.values()):
            raise ValueError('sidecar normalization changed flags or indices')
        before=Path(target).read_bytes();changed=splice_mask(before,mask)
        staged_mask(target,changed,mask,folder.vc)
        result.update(state='recovered_from_matching_sidecar',lods=list(range(5)))
        result['repairs'].append({'kind':'restore_native_embedded_hide_mask','source':str(sidecar),
            'output':str(target),'mask_sha256':hashlib.sha256(mask).hexdigest(),
            'output_sha256':hashlib.sha256(changed).hexdigest(),'source_sidecar_unchanged':sidecar.read_bytes()==supplied,
            'model_and_other_substreams_byte_identical':True,'native_reader_passed':True,
            'scope':'existing paired mask indices restored; in-game coverage still requires checking'})
    except (ValueError,OSError,struct.error) as error:
        result.update(state='sidecar_recovery_unsupported')
        result['findings'].append({'category':'mask','state':'sidecar_recovery_unsupported','file':str(sidecar),'reason':str(error)})
    return result
