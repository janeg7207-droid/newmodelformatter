"""Restore the supplied Moxley WDF with verified clone-LOD segmentation.

This is an exact-file structural repair, not general WDF/YWA conversion.
Native writer controls preserve the authored first 4,358 records and repeat
them for each exported clone LOD. The actual Gorilla output has FOUR model
LODs; the five HPL mask slots do not determine that count. No constraints,
weights, displacement records, solver meshes or missing physics are created.
"""
import functools
import hashlib
import inspect
import math
import os
from pathlib import Path
import struct
import tempfile

from gmf_native_masks import envelopes


PATCH_VERSION = 'exact-moxley-authored-wdf-clone-lod-layout-1'
PROFILE = {
    'source_attire': ('b5ecca7b5e15a9820f866e33922d091b3f837e64d873ba9b24bd69925953085a', 13856864),
    'source_base': ('b1a52a2f77bf5fc3cbec7e04eba1f83a1cd3c7ecee6740316c55ac04013f343a', 6660548),
    'target_attire': ('a8f71547f04f69cc7b347a00f5dd9109bd5e09fbb1caeb03d585d426d619a2b6', 14298204),
    'target_base': ('8f0f50818d0ed160fcbb059b242299e835a3cdc86a9734f1525392eec07f3dec', 7039964),
    'source_wdf': ('0ede85be46899dfbbae361fa1a2c1c81c972f09d96fd8604a02fad04b965e59b', 391100),
    'driven_mesh': 'M_Combinations', 'source_lod0_vertices': 4358,
    'source_wdf_records': 8147, 'head_vertices': 4382,
    'target_lods': 4, 'lod_mesh_count': 6, 'lod_segment_bytes': 216692,
    'lod_segment_sha256': 'aa7653f3947073f2641dd86d7f121cd6681a0db35a2a2c729195ea1d14ec633a',
    'authored_lod0_sha256': '04e8ed684457e69330ac2ad8212c72b06dfce6021af43cf3b28ffd7a3e447473',
}


def fingerprint(data):
    return hashlib.sha256(data).hexdigest(), len(data)


def parse_wdf(data):
    """Read the complete measured v1 format; refuse native raw-fallback cases."""
    if len(data) < 16 or data[:4] != b'WDF!' or struct.unpack_from('<I', data, 4)[0] != 1:
        raise ValueError('WDF requires a complete version 1 header')
    cursor = 8; meshes = []; names = set(); terminal = False
    while cursor < len(data):
        if cursor + 8 > len(data): raise ValueError('WDF tag or count is truncated')
        tag = data[cursor:cursor + 4]; cursor += 4
        if tag == b'END!':
            if data[cursor:] != bytes(4): raise ValueError('WDF terminal padding or trailing data is invalid')
            terminal = True; cursor += 4; break
        if tag != b'MESH': raise ValueError('WDF has an unsupported block tag')
        length = struct.unpack_from('<I', data, cursor)[0]; cursor += 4
        if not 1 <= length <= 256 or cursor + length > len(data):
            raise ValueError('WDF mesh name is truncated or exceeds the bounded format')
        raw_name = data[cursor:cursor + length]
        try: name = raw_name.decode('ascii')
        except UnicodeDecodeError as error: raise ValueError('WDF mesh name is not ASCII') from error
        if (not name or any(ord(c) < 32 for c in name) or any(c in name for c in '/\\')
                or name in ('.', '..') or name in names):
            raise ValueError('WDF mesh name is unsafe or duplicated')
        names.add(name); cursor += length; aligned = (cursor + 3) & ~3
        if aligned + 4 > len(data) or data[cursor:aligned] != bytes(aligned - cursor):
            raise ValueError('WDF name alignment or entry count is invalid')
        cursor = aligned; count_offset = cursor
        count = struct.unpack_from('<I', data, cursor)[0]; cursor += 4
        if not 1 <= count <= 500000 or count * 48 > len(data) - cursor:
            raise ValueError('WDF 48-byte entry extent is invalid or truncated')
        end = cursor + count * 48
        meshes.append({'name': name, 'count': count, 'count_offset': count_offset,
                       'records': data[cursor:end]})
        cursor = end
        if len(meshes) > 128: raise ValueError('WDF contains too many mesh blocks')
    if not terminal or cursor != len(data) or not meshes:
        raise ValueError('WDF does not have a complete terminal block')
    return meshes


def cloned_lods(data, profile=None):
    """Prove all actual levels equal the independently inspected geometry bytes."""
    profile = PROFILE if profile is None else profile
    frame = next(f for f in envelopes(data) if f['tag'] == b'MDL!')
    model = frame['payload']
    if len(model) < 36 or model[:4] != b'MDL!' or struct.unpack_from('<II', model, 4) != (47, 1):
        raise ValueError('WDF target model is not the measured native 2K26 layout')
    cursor = 36; lods = None; terminal = False; chunks = 0
    while cursor < len(model):
        if cursor + 8 > len(model): raise ValueError('WDF target model chunk is truncated')
        tag, size = struct.unpack_from('<4sI', model, cursor); start = cursor + 8; end = start + size
        if end > len(model): raise ValueError('WDF target model chunk leaves its envelope')
        chunks += 1
        if chunks > 512: raise ValueError('WDF target model has too many chunks')
        if tag == b'LODs':
            if lods is not None: raise ValueError('WDF target has ambiguous LOD chunks')
            lods = model[start:end]
        if tag == b'END!':
            if size or end != len(model): raise ValueError('WDF target inner terminal is invalid')
            terminal = True; break
        cursor = end
    if not terminal or lods is None or len(lods) < 4:
        raise ValueError('WDF target LOD framing is incomplete')
    count = struct.unpack_from('<I', lods)[0]
    if count != profile['target_lods'] or len(lods) != 4 + count * profile['lod_segment_bytes']:
        raise ValueError('WDF target LOD count or complete segment extent differs from inspected output')
    levels = [lods[4 + i * profile['lod_segment_bytes']:4 + (i + 1) * profile['lod_segment_bytes']]
              for i in range(count)]
    for level in levels:
        if (hashlib.sha256(level).hexdigest() != profile['lod_segment_sha256']
                or struct.unpack_from('<I', level)[0] != profile['lod_mesh_count']
                or level[-8:] != b'ENDM' + bytes(4)):
            raise ValueError('WDF target contains an unproved or nonidentical model LOD')
    if any(level != levels[0] for level in levels):
        raise ValueError('WDF target LOD geometry bytes are not exact clones')
    return count


def splice_wdf(data, payload):
    frames = envelopes(data)
    if any(f['tag'] == b'WDF!' for f in frames):
        raise ValueError('WDF target already has a deformation stream; existing bindings preserved')
    position = frames[-1]['start']
    added = struct.pack('<II4s', 4, len(payload), b'WDF!') + payload
    added += bytes((-len(added)) % 4)
    result = data[:position] + added + data[position:]
    after = envelopes(result)
    if [(f['tag'], f['payload']) for f in frames] != [(f['tag'], f['payload']) for f in after if f['tag'] != b'WDF!']:
        raise ValueError('WDF splice changed an original model or non-WDF substream')
    return result


def prepare(source, target, wdf, source_base, target_base):
    """Prepare only the exact source/pair backed by native correspondence proof."""
    for key, value in (('source_attire', source), ('target_attire', target),
                       ('source_base', source_base), ('target_base', target_base), ('source_wdf', wdf)):
        if fingerprint(value) != PROFILE[key]: raise ValueError('WDF repair requires exact inspected ' + key + ' bytes')
    count = cloned_lods(target)
    meshes = parse_wdf(wdf)
    if len(meshes) != 1 or meshes[0]['name'] != PROFILE['driven_mesh'] or meshes[0]['count'] != PROFILE['source_wdf_records']:
        raise ValueError('WDF driven mesh or authored record extent differs from inspected source')
    mesh = meshes[0]; n = PROFILE['source_lod0_vertices']; records = mesh['records'][:n * 48]
    if len(records) != n * 48 or hashlib.sha256(records).hexdigest() != PROFILE['authored_lod0_sha256']:
        raise ValueError('WDF authored LOD0 prefix is incomplete or differs from native writer proof')
    for row in struct.iter_unpack('<16e8H', records):
        if not all(math.isfinite(value) for value in row[:16]): raise ValueError('WDF authored half scalars are nonfinite')
        if any(index >= PROFILE['head_vertices'] for index in (*row[16:19], *row[20:23])):
            raise ValueError('WDF referenced head vertex is outside the verified paired domain')
    payload = wdf[:mesh['count_offset']] + struct.pack('<I', n * count) + records * count + b'END!' + bytes(4)
    rebuilt = parse_wdf(payload)
    if rebuilt[0]['records'] != records * count: raise ValueError('WDF authored records changed during LOD rebuild')
    changed = splice_wdf(target, payload)
    return changed, payload, {
        'version': PATCH_VERSION, 'profile': 'supplied Jon Moxley AEW Debut',
        'state': 'prepared_authored_wdf_clone_lod_layout', 'source_wdf_sha256': fingerprint(wdf)[0],
        'source_model_sha256': fingerprint(source)[0], 'output_model_sha256_before': fingerprint(target)[0],
        'output_model_sha256': fingerprint(changed)[0], 'output_wdf_sha256': fingerprint(payload)[0],
        'authored_lod0_records_sha256': fingerprint(records)[0], 'source_records': mesh['count'],
        'records_per_lod': n, 'target_model_lods': count, 'output_records': n * count,
        'all_target_lod_geometry_bytes_identical': True, 'all_authored_lod0_record_bytes_preserved': True,
        'paired_head_geometry_topology_and_remap_correspondence': 'exact byte profiles backed by actual native source/target array comparison',
        'model_hpl_and_all_other_substreams_byte_identical': True,
        'native_writer_control': 'bounded v47 serializer WDF rebuild; one/five level controls match these authored records',
        'ycl_and_four_ywa_files_changed': False, 'synthetic_binding_records_created': False,
        'compatibility_scope': 'WDF clone-LOD layout only; authored binding semantics and in-game facial deformation unverified',
        'in_game_validation': 'not_performed',
    }


def _safe_file(path, root):
    if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('WDF file leaves its selected folder or uses a symlink')
    current = path.absolute().parent
    while current != root.absolute():
        if current.is_symlink() or current == current.parent:
            raise ValueError('WDF file contains an unsupported directory alias')
        current = current.parent


def _problem(report, message):
    if 'problems' not in report: report['problems'] = []
    if type(report.get('problems')) is list:
        report['problems'].append(message)
    else:
        report['wdf_layout_repair_metadata_error'] = message


def _record_report(report, relative_wdf, relative_ycl, relative_target, sidecar, target, detail):
    """Optional report links follow the mandatory current-file identity update."""
    report['left_out'] = [item for item in report.get('left_out', [])
                          if item.split(' (', 1)[0].replace('\\', '/') != relative_wdf]
    revised = []
    for item in report.get('problems', []):
        if (item.split(': ', 1)[0].replace('\\', '/') == relative_ycl
                and ': YCL converted; WDF/YWA companion conversion is incomplete (' in item):
            item = item.replace('WDF/YWA companion', 'YWA companion').replace(', .wdf)', ')')
        revised.append(item)
    report['problems'] = revised
    report.setdefault('physics_converted', []).append({
        'source': str(sidecar), 'output': str(target), 'file': relative_target,
        'kind': 'wrap_deformation_layout', 'embedded_tag': 'WDF!', **detail,
        'state': 'authored_wdf_clone_lod_layout_restored', 'native_reader_passed': True,
    })
    message = relative_target + ': WDF authored records restored for four verified model LODs; YWA conversion and facial deformation remain unverified'
    if message not in report.setdefault('warnings', []): report['warnings'].append(message)
    return message


def process(report, source_root, output_root, vc, log=lambda message: None):
    source_root = Path(source_root).absolute(); output_root = Path(output_root).absolute()
    if source_root.is_symlink() or output_root.is_symlink():
        raise ValueError('WDF repair refuses selected folder aliases')
    source_root = source_root.resolve(); output_root = output_root.resolve()
    if (source_root == output_root or source_root.is_relative_to(output_root)
            or output_root.is_relative_to(source_root)):
        raise ValueError('WDF repair requires separate source/output folders')
    summary = {'version': PATCH_VERSION, 'scope': 'exact supplied Moxley WDF layout; no YWA conversion',
               'applied': 0, 'refused': 0, 'rows': [], 'in_game_validation': 'not_performed'}
    for model in report.get('models', []):
        source = Path(model.get('source', '')); target = Path(model.get('output', ''))
        if not source.is_file() or not target.is_file() or source.suffix.casefold() != '.mcd': continue
        try:
            _safe_file(source, source_root); _safe_file(target, output_root)
        except ValueError:
            continue  # No unproved source alias is read to decide eligibility.
        raw_source = source.read_bytes()
        if fingerprint(raw_source) != PROFILE['source_attire']: continue
        row = {'source': str(source), 'output': str(target), 'state': 'not_applied', 'file_changes': 'none'}
        committed = False
        try:
            if model.get('verify') != 'pass': raise ValueError('WDF repair requires the original model verifier to pass')
            if type(model.get('facts', {})) is not dict:
                raise ValueError('WDF report facts must be a plain dictionary before any file write')
            for field in ('left_out', 'problems', 'warnings', 'physics_converted'):
                if type(report.get(field, [])) is not list:
                    raise ValueError('WDF report field ' + field + ' must be a plain list before any file write')
                if field != 'physics_converted' and any(type(item) is not str for item in report.get(field, [])):
                    raise ValueError('WDF report field ' + field + ' contains nonstring metadata')
            recorded_output = Path(report['output']).resolve()
            if not recorded_output.is_relative_to(output_root) or not target.resolve().is_relative_to(recorded_output):
                raise ValueError('WDF report output leaves the selected output folder')
            source_base = source.parent.parent / 'BaseModel' / 'baseModel.mcd'
            target_base = target.parent.parent / 'BaseModel' / 'baseModel.mcd'
            sidecar = source.with_suffix('.wdf')
            for path, root in ((source, source_root), (source_base, source_root), (sidecar, source_root),
                               (target, output_root), (target_base, output_root)):
                _safe_file(path, root)
            relative_wdf = sidecar.resolve().relative_to(source_root).as_posix()
            relative_ycl = source.with_suffix('.ycl').resolve().relative_to(source_root).as_posix()
            relative_target = os.path.relpath(target.resolve(), recorded_output)
            facts = model.setdefault('facts', {})
            before = target.read_bytes(); raw_wdf = sidecar.read_bytes()
            base_before = source_base.read_bytes(); base_after = target_base.read_bytes()
            changed, payload, detail = prepare(raw_source, before, raw_wdf, base_before, base_after)
            if (source.read_bytes() != raw_source or sidecar.read_bytes() != raw_wdf
                    or source_base.read_bytes() != base_before or target_base.read_bytes() != base_after
                    or target.read_bytes() != before):
                raise ValueError('WDF source/pair/output changed during inspection; output preserved')
            handle, name = tempfile.mkstemp(prefix='.wdf-layout-', suffix='.mcd', dir=target.parent)
            stage = Path(name)
            try:
                with os.fdopen(handle, 'wb') as stream:
                    stream.write(changed); stream.flush(); os.fsync(stream.fileno())
                native = vc.read_model(str(stage), with_shapes=True)
                streams = [raw for tag, raw in native.substreams if tag == b'WDF!']
                if native.version != 47 or streams != [payload] or stage.read_bytes() != changed:
                    raise ValueError('native reader did not retain the complete prepared WDF stream')
                if (source.read_bytes() != raw_source or sidecar.read_bytes() != raw_wdf
                        or source_base.read_bytes() != base_before or target_base.read_bytes() != base_after
                        or target.read_bytes() != before):
                    raise ValueError('WDF inputs/output changed while staging; output preserved')
                os.replace(stage, target); committed = True
            finally:
                if stage.exists(): stage.unlink()
            row.update(detail, state='authored_wdf_clone_lod_layout_restored', source_files_unchanged=True,
                       native_reader_passed=True, file_changes='one rebuilt WDF envelope added; all original envelopes retained')
            model['wdf_layout_repair'] = dict(row)
            facts['output_sha256_before_wdf_layout_repair'] = fingerprint(before)[0]
            facts['output_sha256'] = fingerprint(changed)[0]
            facts['byte_identical'] = False
            facts['model_payload_and_hpl_preserved_by_wdf_layout_repair'] = True
            facts['wdf_layout_repair'] = dict(row)
            facts['substreams'] = [f['tag'].decode('ascii') for f in envelopes(changed) if f['tag'] != b'END!']
            summary['applied'] += 1
            if target.read_bytes() != changed:
                facts['output_sha256'] = fingerprint(target.read_bytes())[0]
                row['observed_output_sha256_after_concurrent_change'] = facts['output_sha256']
                raise ValueError('WDF output changed after atomic replacement; recorded prepared identity requires review')
            message = _record_report(report, relative_wdf, relative_ycl, relative_target, sidecar, target, detail)
            try: log('  ' + message)
            except Exception: pass
        except Exception as error:
            row.update(state='written_with_reporting_error' if committed else 'not_applied', reason=str(error))
            summary['refused'] += 1
            if committed:
                model['wdf_layout_repair'] = dict(row)
                facts['wdf_layout_repair'] = dict(row)
            _problem(report, str(source) + ': WDF layout repair ' + ('written but reporting requires review: ' if committed else 'not completed: ') + str(error))
        summary['rows'].append(row)
    report['wdf_layout_repair'] = summary
    report['conversion_completeness'] = 'incomplete' if report.get('problems') or summary['refused'] else 'structural_checks_only'


def install(folder_module=None):
    if folder_module is None:
        from gmf import folder as folder_module
    if getattr(folder_module, '_wdf_layout_repair', None) == PATCH_VERSION: return
    original = folder_module.convert_folder
    @functools.wraps(original)
    def convert_folder(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs); bound.apply_defaults()
        report = original(*args, **kwargs)
        process(report, bound.arguments['src'], bound.arguments['dst'], folder_module.vc,
                bound.arguments.get('log', lambda message: None))
        from gmf_report import save_intermediate
        save_intermediate(report, bound.arguments['dst'])
        return report
    folder_module.convert_folder = convert_folder
    folder_module._wdf_layout_repair = PATCH_VERSION
