"""Admit a recognized partial legacy rig after checking the actual target.

Gorilla already fills its 175 stock target bones and retains custom bones.
This patch preserves that builder and its weight conversion. It supersedes
the missing-source-helper guard only after independently checking the complete
written rig and every written weight, and retaining the original verifier.
It does not create masks, physics, geometry, or new skin projections.
"""
import copy
import functools
import hashlib
import inspect
import os
import threading
import types

import numpy as np

from gmf_surface_verification import check_written_weights

PATCH_VERSION = 'validated-partial-legacy-core-original-writer-normalization-2'
CORE_NAMES = frozenset(('J_Root','J_Hips','J_Spine1','J_Spine2','J_Chest','J_Neck','J_Head') +
    tuple('J_'+part+'_'+side for side in ('L','R')
          for part in ('Clavicle','Shoulder','Elbow','Wrist','Leg','Knee','Foot','Toe')) +
    tuple('J_'+finger+str(j)+'_'+side for side in ('L','R')
          for finger in ('IndexF','MiddleF','RingF','PinkyF') for j in range(4)) +
    tuple('J_ThumbF'+str(j)+'_'+side for side in ('L','R') for j in range(1,4)))
CORE_POSE_TOLERANCE = .05
CORE_LINEAR_TOLERANCE = .001
WRITTEN_MATRIX_TOLERANCE = .001
_context = threading.local()


def _path(value):
    return os.path.normcase(os.path.abspath(os.fspath(value)))


def _sha256(path):
    digest=hashlib.sha256()
    with open(path,'rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def _hierarchy(bones):
    names=[bone.name for bone in bones]
    if len(set(names))!=len(names):raise ValueError('duplicate rig bone names')
    by_name={bone.name:bone for bone in bones}
    for bone in bones:
        world=np.asarray(bone.world,dtype=np.float64)
        if world.shape!=(4,4) or not np.isfinite(world).all():raise ValueError('invalid bind matrix: '+bone.name)
        if not np.allclose(world[3],(0,0,0,1),atol=1e-5,rtol=0):raise ValueError('non-affine bind matrix: '+bone.name)
        if abs(float(np.linalg.det(world[:3,:3])))<1e-6:raise ValueError('singular bind matrix: '+bone.name)
        visited=set();parent=bone.parent
        while parent is not None:
            if parent not in by_name:raise ValueError('rig parent is absent: '+str(parent))
            if parent==bone.name or parent in visited:raise ValueError('rig parent cycle: '+bone.name)
            visited.add(parent);parent=by_name[parent].parent
    return by_name


def _weights(mesh,rig,*,allow_writer_normalization=False):
    count=mesh.num_verts
    total=np.zeros(count,dtype=np.float64)
    if count<=0:raise ValueError('empty mesh: '+mesh.name)
    for name,vector in mesh.weights.items():
        values=np.asarray(vector,dtype=np.float64)
        if values.shape!=(count,) or not np.isfinite(values).all() or (values<0).any():
            raise ValueError('invalid mesh weight vector: '+mesh.name+'/'+name)
        if name not in rig and (values>1e-7).any():raise ValueError('weighted bone is absent: '+mesh.name+'/'+name)
        with np.errstate(over='ignore'):
            total+=values
    if not np.isfinite(total).all():raise ValueError('invalid summed source weights: '+mesh.name)
    if (total<=1e-7).any():raise ValueError('unweighted source vertices: '+mesh.name)
    nonunit=int((np.abs(total-1)>.03).sum())
    if nonunit and not allow_writer_normalization:
        raise ValueError('unnormalized source weights: '+mesh.name)
    return {'mesh':mesh.name,'vertices_checked':count,
        'weight_sum_minimum':float(total.min()),'weight_sum_maximum':float(total.max()),
        'nonunit_over_three_percent_vertices':nonunit,
        'writer_normalization_required':bool(nonunit),
        'source_vectors_modified':False,
        'policy':'original_Gorilla_writer_normalization_and_top_eight_packing'}


def source_plan(model,ref,skeleton,body_label=None):
    """Recognize stock animation joints; never infer a missing core joint."""
    if model.version not in (40,41):raise ValueError('source is not native legacy v40/v41')
    source=_hierarchy(model.bones)
    absent=sorted(CORE_NAMES-set(source))
    if absent:raise ValueError('source animation core is incomplete: '+', '.join(absent[:5]))
    variant,offset=skeleton.pick_variant(model.bones,ref)
    if variant!='male':raise ValueError('partial-rig admission is validated for the male reference only')
    if body_label and body_label!=variant:raise ValueError('source and selected body variants differ')
    reference=ref.variants[variant]
    if len(reference.names)!=175 or len(set(reference.names))!=175:
        raise ValueError('reference is not the complete 175-bone target')
    table={name:(parent,np.asarray(world,dtype=np.float64)) for name,parent,local,world in reference.bones}
    worst=0.;worst_linear=0.
    for name in CORE_NAMES:
        parent,world=table[name]
        # Missing secondary helpers must not have changed the animated chain.
        source_parent=source[name].parent
        while source_parent is not None and source_parent not in CORE_NAMES:
            source_parent=source[source_parent].parent
        while parent is not None and parent not in CORE_NAMES:parent=table[parent][0]
        if source_parent!=parent:raise ValueError('source animation parent differs: '+name)
        difference=float(np.max(np.abs(np.asarray(source[name].world)-world)))
        worst=max(worst,difference)
        if difference>CORE_POSE_TOLERANCE:raise ValueError('source core bind pose differs: '+name)
        linear=float(np.max(np.abs(np.asarray(source[name].world)[:3,:3]-world[:3,:3])))
        worst_linear=max(worst_linear,linear)
        if linear>CORE_LINEAR_TOLERANCE:raise ValueError('source core rotation or scale differs: '+name)
    budgets=[]
    for mesh in model.meshes:
        budgets.append(_weights(mesh,source,allow_writer_normalization=True))
        for name,values in mesh.weights.items():
            if not (np.asarray(values)>1e-7).any():continue
            ancestor=name
            while ancestor is not None and ancestor not in CORE_NAMES:ancestor=source[ancestor].parent
            if ancestor is None:raise ValueError('weighted bone has no animation-core ancestor: '+mesh.name+'/'+name)
    expected,inherit,bone_report=skeleton.convert_bones(model.bones,ref,variant)
    _hierarchy(expected)
    if [bone.name for bone in expected[:175]]!=list(reference.names):
        raise ValueError('original builder did not create the complete target core')
    return {'variant':variant,'expected_bones':copy.deepcopy(expected),
        'core_pose_maximum_error':worst,'variant_offset_share':float(offset),
        'core_rotation_scale_maximum_error':worst_linear,
        'missing_source_standard_bones':sorted(set(ref.set26)-set(ref.new26)-set(source)),
        'source_bone_names':list(source),'target_bone_names':[bone.name for bone in expected],
        'source_weight_budgets':budgets,
        'bone_report':bone_report}


def verify_written_rig(actual,plan,ref):
    """Check all target bones, including preserved custom and physics bones."""
    written=_hierarchy(actual.bones);expected=plan['expected_bones']
    if [bone.name for bone in actual.bones]!=[bone.name for bone in expected]:
        raise ValueError('written target bone order or custom bones changed')
    reference=ref.variants[plan['variant']]
    if [bone.name for bone in actual.bones[:175]]!=list(reference.names):
        raise ValueError('written target does not contain the complete 175-bone core')
    worst=0.
    for want in expected:
        got=written[want.name]
        if got.parent!=want.parent:raise ValueError('written bone parent changed: '+want.name)
        error=float(np.max(np.abs(np.asarray(want.world)-np.asarray(got.world))))
        worst=max(worst,error)
        if error>WRITTEN_MATRIX_TOLERANCE:raise ValueError('written bind matrix changed: '+want.name)
    return {'stock_core_bones':175,'custom_bones_retained':len(expected)-175,
        'total_bones_checked':len(expected),'maximum_bind_matrix_error':worst,
        'checks':'all ordered names, parents, finite affine invertible matrices and expected original-builder poses'}


def packed_expected(mesh,bones,vc):
    """The original writer's top-eight packing is part of its existing policy."""
    names=[bone.name for bone in bones];index={name:i for i,name in enumerate(names)}
    _weights(mesh,index,allow_writer_normalization=True)
    packed_indices,packed_weights,facts=vc.pack_weights(mesh,index)
    if facts.get('unweighted'):raise ValueError('original packing produced unweighted vertices: '+mesh.name)
    if facts.get('dropped_groups'):
        # A zero-valued unused group is harmless; no positive target may vanish.
        for name in facts['dropped_groups']:
            if (np.asarray(mesh.weights[name])>1e-7).any():raise ValueError('original packing drops a weighted bone: '+name)
    indices=np.asarray(packed_indices).reshape(mesh.num_verts,-1)
    values=np.asarray(packed_weights).reshape(mesh.num_verts,-1)
    if (indices.shape!=values.shape or not 1<=indices.shape[1]<=8
            or not np.issubdtype(indices.dtype,np.integer)
            or (indices<0).any() or (indices>=len(names)).any()):
        raise ValueError('original packing produced invalid influence indices or budget: '+mesh.name)
    if not np.isfinite(values).all() or (values<0).any():
        raise ValueError('original packing produced invalid weight values: '+mesh.name)
    table=np.zeros((mesh.num_verts,len(names)),dtype=np.float32)
    np.add.at(table,(np.arange(mesh.num_verts)[:,None],indices),values)
    expected=types.SimpleNamespace(name=mesh.name,num_verts=mesh.num_verts,
        weights={name:table[:,i].copy() for i,name in enumerate(names) if (table[:,i]>1e-7).any()})
    _weights(expected,index)
    return expected


def install(convert,skeleton):
    """Install after the gear wrapper and before mask wrappers.

    The gear verifier must capture the raw verifier so its deliberately
    projected source-weight view reaches that verifier's native reader.
    This outer wrapper remains transparent for non-partial inputs.
    """
    if getattr(convert,'_partial_rig_patch',None)==PATCH_VERSION:return
    original_model=convert.convert_mcd;original_verify=convert.verify
    original_weights=skeleton.convert_weights;vc=convert.vc

    @functools.wraps(original_weights)
    def convert_weights(mesh,*args,**kwargs):
        result=original_weights(mesh,*args,**kwargs)
        current=getattr(_context,'current',None)
        if current is not None:
            try:current['expected_meshes'].append(packed_expected(mesh,current['plan']['expected_bones'],vc))
            except ValueError as error:
                # Recording a stronger check must not interrupt the original
                # converter's existing write/report flow. Deny admission later.
                current['capture_failure']=str(error)
        return result

    @functools.wraps(original_model)
    def convert_mcd(*args,**kwargs):
        bound=inspect.signature(original_model).bind(*args,**kwargs);bound.apply_defaults()
        source=bound.arguments['src_path'];target=bound.arguments['dst_path'];ref=bound.arguments['ref']
        # A previous unverified conversion must never authorize a later write
        # to the same output, including nonmatching or failed conversions.
        getattr(_context,'pending',{}).pop(_path(target),None)
        model=vc.read_model(source)
        current=None;failure=None
        if model.version in (40,41) and convert.rig_family(model.bone_names(),ref)=='older':
            try:
                plan=source_plan(model,ref,skeleton,bound.arguments.get('body_label'))
                current={'plan':plan,'source':_path(source),'source_sha256':_sha256(source),
                    'target':_path(target),'ref':ref,'expected_meshes':[]}
            except ValueError as error:failure=str(error)
        previous=getattr(_context,'current',None);_context.current=current
        try:report=original_model(*args,**kwargs)
        finally:_context.current=previous
        if current is not None:
            current['report']=report
            pending=getattr(_context,'pending',None)
            if pending is None:_context.pending=pending={}
            pending[_path(target)]=current
            report['partial_legacy_rig']={'version':PATCH_VERSION,'status':'awaiting_written_verification',
                'source_core':'stock animation joints and bind pose checked',
                'missing_source_standard_bones':plan['missing_source_standard_bones'],
                'source_variant':plan['variant'],
                'source_model_sha256':current['source_sha256'],
                'source_core_pose_maximum_error':plan['core_pose_maximum_error'],
                'source_core_rotation_scale_maximum_error':plan['core_rotation_scale_maximum_error'],
                'source_core_pose_tolerances':{'matrix_translation_cm':CORE_POSE_TOLERANCE,'matrix_rotation_scale':CORE_LINEAR_TOLERANCE},
                'source_weight_budgets':plan['source_weight_budgets'],
                'writer_only_budget_normalization':any(row['writer_normalization_required'] for row in plan['source_weight_budgets']),
                'source_weight_vectors_modified':False,
                'weight_policy':'original Gorilla mapped weights, writer normalization and top-eight packing preserved',
                'new_surface_projection':False,'new_physics':False,'in_game_validation':'required'}
        elif failure:
            report['partial_legacy_rig']={'version':PATCH_VERSION,'status':'unsupported_source_core','reason':failure}
        return report

    @functools.wraps(original_verify)
    def verify(*args,**kwargs):
        bound=inspect.signature(original_verify).bind(*args,**kwargs);bound.apply_defaults()
        target=_path(bound.arguments['dst_path'])
        current=getattr(_context,'pending',{}).pop(target,None)
        # Run the original verifier with real source geometry and weights.
        # The default policy makes no additional weight changes to exempt.
        result=original_verify(*args,**kwargs)
        if current is None:return result
        profile=current['report']['partial_legacy_rig']
        try:
            if _path(bound.arguments['src_path'])!=current['source'] or _sha256(current['source'])!=current['source_sha256']:
                raise ValueError('source changed after conversion')
            if current.get('capture_failure'):raise ValueError('original converted-weight capture failed: '+current['capture_failure'])
            actual=vc.read_model(bound.arguments['dst_path'])
            if actual.version!=vc.VERSION_2K26:raise ValueError('written target is not native 2K26')
            rig_check=verify_written_rig(actual,current['plan'],current['ref'])
            if len(actual.meshes)!=len(current['expected_meshes']):raise ValueError('written mesh count changed after conversion')
            weight_checks=[];rig={bone.name for bone in actual.bones}
            for expected,written in zip(current['expected_meshes'],actual.meshes):
                if expected.name!=written.name:raise ValueError('written mesh order changed after conversion')
                check=check_written_weights(expected,written,rig)
                check['policy']='original_Gorilla_mapped_weights_normalization_and_top_eight_packing'
                weight_checks.append(check)
            profile.update(status='target_rig_and_weights_verified',rig_verification=rig_check,
                written_weight_verification=weight_checks,original_model_verification='pass' if result[0] else 'fail',
                original_model_problems=list(result[1]),source_unchanged=True)
            result[2]['partial_legacy_rig']=profile
            # A mask error cannot invalidate a proven rig, nor can this patch
            # turn that mask failure into a successful model conversion.
            only_source_mask_failure=bool(result[1]) and all(str(problem).startswith(
                'source hide mask is unsupported or unreadable;') for problem in result[1])
            if result[0] or only_source_mask_failure:
                previous_guard=current['report'].pop('unsupported',None)
                if previous_guard:profile['superseded_source_rig_guard']=previous_guard
                current['report'].setdefault('notes',[]).append(
                    'Partial legacy rig admitted after all 175 target bones, retained custom bones and every written skin weight were checked. '
                    'Original geometry/rig/mask verification retained; no additional surface reweighting or physics created. In-game validation required.')
            else:profile['admission']='blocked_by_original_model_verification'
        except ValueError as error:
            profile.update(status='written_verification_failed',reason=str(error))
            problems=list(result[1]);problems.append('partial legacy rig validation: '+str(error))
            result=(False,problems,result[2]);result[2]['partial_legacy_rig']=profile
        return result

    skeleton.convert_weights=convert_weights
    convert.convert_mcd=convert_mcd
    convert.verify=verify
    convert._partial_rig_patch=PATCH_VERSION
