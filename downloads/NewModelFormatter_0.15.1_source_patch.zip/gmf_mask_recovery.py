"""Recover only the supplied Rey mask after validating its actual paired base.

The replacement is an unchanged, user-supplied HPL. It is passed through the
original expected_mask parser/filter and original sidecar writer. No source
file, geometry, physics sidecar, or process-wide open function is changed.
"""
import base64
import builtins
import functools
import hashlib
import inspect
import io
import operator
import os
import threading
import types
import zlib


REY_MODEL_SHA256 = 'c181b2889e01a8ebb76f020457de7466a099ae327d87514e1cd44b36b3f6245c'
REY_MODEL_BYTES = 10506864
SOURCE_HPL_SHA256 = '57abd17dd82782bcd4c1509c311d3f70227af707e7975a2e1b3fcbf1eae2c3dd'
SOURCE_HPL_BYTES = 81408
SOURCE_BASE_SHA256 = '6ac7de4ecdc79c598c3bfb6b1ea96679e5f656bae2e372053ba487eb3513155f'
SOURCE_BASE_BYTES = 6248492
REPLACEMENT_HPL_SHA256 = 'b00ba528b83157ff028cd85f542734b3e46780ebfcde68c708f6c56934d1bbf7'
REPLACEMENT_HPL_BYTES = 196220
PROFILE_VERSION = 'supplied-rey-hpl-1'
_BODY_MESHES = ('M_Body', 'M_Head')
_context = threading.local()

# Lossless zlib/base85 encoding of the verified, supplied 196,220-byte HPL.
# All LOD0/LOD1 index arrays, both flags, and both meshes compare equal.
_PAYLOAD = (
    b'c-k!8V-'
    b'W31*DlcaY}>YN+qP}nwr$(CZQHhOd*5;HcTzPfKhs%VPgg3dGiR}KrQ(+=TPXhj9EI{%%Kz`Vbm5A{g8X}~TcB;D?*IGW{S^QE|HnTBARxgBK}bRonlOYVB9'
    b'Vwp6rvK1=)@o<v4~9^;u4R42a$k;BqA|MNJ=u2^Y2hnl8V%%AuZ`hPX;oQi7aF#8#%~DZt{?qeEfUE1t|FM{Zp7C6r~u&DM3j}{rj6xhO(5SJQb)&B`Q;es#'
    b'K#oHK<7~8qkQwG@&WYXif`S(u&r!;R;u|&JAvIi`(4cF88?410M2-$2|G>nkKCt^=Uv;n$esVw4x1dX-9iH(wQ!Fr5oMpK~H+on?CfVAN?7?Kn5|GAq-'
    b'_0!x_OyMlqT(jAb0-nZQIQF_|e$Wg63&!Axc`n>oy79`jkiLKd-'
    b'@B`jqb%UQunR<W8jtYsbR*}z6Nv6(GwWgFYs!A^Fun?3AhANx7LK@M@4BOK)z$2q}CPH~zuoaG$nxxhs(ahWSz<r>$y!A)*)n>*a)9`|{`Lmu&%Cp_gD&w0U'
    b'1Uh$eYyyYG5`M^g$@tH4t<s0Am!B2kin?L;hZ&CP%00blufeAuTf)Sh$gd`MU2unD^6M=|CA~I2kN;IMqgP6o3HgSkcJmQmpgd`#{Nk~dEl9Pgzq#`wGNJ~1'
    b'>lYxw6A~RXYN;a~SgPi0dH+jfQKJrt5f)t`KMJP%!ic^A;l%h0cC`&oYQ-'
    b'O+9qB2#eN;RregPPQ$Hg%{=J?hhdhBTrvO=wCpn$v=ow4ya_XiGcV(}9k3qBC9SN;kUGgP!!FH+|?!Kl(F(fed0WLm0|1hBJbZjAArn7|S@uGl7XrVlq>h$~'
    b'2}kgPF`?HglNEJm#~2g)Cw*OIXS>ma~GDtYS55Sj#%rvw@9lVl!LV$~LyMgPrVRH+$I2KK65fgB;>8M>xtcj&p*OoZ>WRILkTCbAgLo;xbpb$~CTYgPYvqHg'
    b'~woJ?`^>hdkmjPk72Rp7Vm2yy7))c*{H9^MQ|i;xk|P$~V6AgP;83H-Gs1-^0K^1Rx-'
    b'R2uu)y5{%%4AS9s(O&G!wj_^bvB9Vwp6rvK1=)@o<v4~9^;u4SeBp@M)NK6uvl8oe}ASJ0tO&ZdYj`U<8Bbmrd7P69!?BpOPxyVf(@{*7I6rdo5C`=KGQjFr'
    b'1pd_UzO&Q8kj`CEXB9*926{=E=>eQenwWv)U>QayTG@v1kXiO8D(v0S`pe3znO&i+Mj`nn*Bc13>7rN4o?)0E1z35FJ`qGd73}7IG7|alcGK}GjU?ig$%^1c'
    b'qj`2)jB9oZROlC2gIm~4q^I61Vmavp%EN2BPS;cDBu$FbKX9FAA#Addzm2GTi2RqrtZuYR3{T$#RhdIhIj&p*OoZ>WRILkTCbAgLo;xbpb$~CTYgPYvqHg~w'
    b'oJ?`^>hdkmjPkF@~-tvz3eBdLW_{<l+@{RBO;3vQM%^&{$`yd}kehEN80uh)X1SJ^32|-'
    b'9g5t=ZBB^=?2Ktv)DnJ7dh8qtYCOkxq6IK(9$@ku~J5|NlBBqbTiNkK|dk(xB5B^~L>Kt?i=nJi=_8`;T0PI8f(Jme)G`6)m_3Q?FM6r~u&DM3j}QJON8r5x'
    b'p{Kt(E1nJQGJ8r7*mO=?k_I@F~e^=Uvu8qt_0G^H8MX+cX`(V8~2r5)|*Ku0>!nJ#pt8{O$aPkPatKJ=v@{TaYO1~Hf+3}qO@8No<KF`6-'
    b'qWgO#~z(gi7nJG+V8q=A<OlC2gIm~4q^I5<`7O|KmEM*zXS;0zHv6?lkWgY9;z(zK)nJsK(8{65zPIj@IJ?v#4`#Hct4sn<x9OW3tIl)Ozahfxn<s9d^z(p='
    b'`nJZl78rQkOO>S|UJKW_S_j$lW9`TqbJmneBdBICw@tQZh<sI+&z(+punJ;|h8{hfCPk!;6Km6r?f#sh71SAlF2|`eU5u6Z&Bov_uLs-HQo(M!F5|N2QRH6}'
    b'`7{nwNv57-m;t`(&BqR}uNkUSRk(?ByBo(PiLt4_2o(yCp6Pd|ER<e<u9ONVyxyeIb@{ykc6r>P^DMC?-'
    b'QJfN#q!gtoLs`mEo(fc?5|yb!RjN^)8q}l~wW&j0>QSEtG^7!YX+l$)(VP~vq!q1cLtEO>o(^=R6P@WoSGv)i9`vLaz3D?=`q7^O3}g_48NyJ8F`N;MWE7(r'
    b'!&t^Ko(W835|f$2RHiYV8O&rBvzfzO<}sfIEMyUjS;A75v78mGWEHDf!&=s{o(*hd6Pww>R<^O79qeQmyV=8D_OYJ>9OMv(Il@tnahwyJ<P@hl!&%O8o(o*$'
    b'5|_EcRjzTJ8{Fg;x4FYz?s1<7Jme9NdBRhk@thaD<Q1=Z!&~0*o)3KF6QB9QSHAI`AN=GOzxl&o{uf042|z#s5ttwZB^bd8K}bRonlOYV9N~#TL?RKHC`2V1'
    b'(TPD!ViB7-#3df_NkBppk(eYTB^k*{K}u4Qnlz*(9qGwHMlz9^EMz4c*~vjpa*>-'
    b'n<Ru^ZDL_FAQJ5kW<=+>f#VJ8aN>Q3Jl%*WysX#?4QJE@Kr5e?#K}~8=n>y5`9`$KJLmJVTCN!lP&1pePTG5&|w51*G=|D$1(U~rEr5oMpK~H+on?CfVAN?7'
    b'?Kn5|GAq-_0!x_OyMlqT(jAb0-nZQIQF_|e$Wg63&!Axc`n>oy79`jkiLKd-'
    b'@B`jqb%UQunR<W8jtYsbR*}z6Nv6(GwWgFYs!A^Fun?3AhANx7LK@M@4BOK)z$2q}CPH~zuoaG$nxxhs(ahWSz<r>$y!A)*)n>*a)9`|{`Lmu&%Cp_gD&w0U'
    b'1Uh$eYyyYG5`M^g$@tH4t<s0Am!B2kin?L;h_a%Q&`6mDY2}EFm5R_m9Cj=o0MQFkhmT-h80uhNsWTFt2XhbIlF^NTN;t-'
    b'd3#3um>Nkn3jkd$O3Cj}`<MQYNJmUN^i0~yIgX0ni#Y-A?~ImtzC@{pH&<fi}yDMVq4P?Ta6rvxP_MQO@VmU5J*0u`x5WvWn>YE-'
    b'8NHK|2y>QSEtG^7!YX+l$)(VP~vq!q1cLtEO>o(^=R6P@WoSGv)i9`vLaz3D?=`q7^O3}g_48NyJ8F`N;MWE7(r!&t^Ko(W835|f$2RHiYV8O&rBvsu7G7O|'
    b'M;yx=9Tc+H!C=O>sspcus|NhwNGhO(5SJQb)&B`Q;es#K#oHK<7~YEy^0)T2HPXh<U((}bopqd6^TNh?~@hPJe$Jss#sCpy!Gu5_b2J?Kd<deeu#^rJrm7|0'
    b'+7GlZcGV>lxi$tXrMhOvxeJQJA6BqlS3sZ3)!GnmONW;2Jm%ws+aSjZw4vxKEAV>v5W$tqT}hPA9?Jsa4_CN{H$t!!gEJJ`uCcC&}Q>|;L%ILILmbA+QD<2W'
    b'Zc$tg~AhO?aGJQujgB`$M?t6bwcH@L|yZgYpb+~YnEc*r9j^Mt27<2f&Q$tzy-hPS-qJs<eUCqDCquYBV>KlsTne)EUF!T#@0)PD#-'
    b'Kmrk%AOs~C!3jY~LJ^uUge4r|i9kdm5t%4NB^uF*K}=#1n>fTJ9`Q*)LK2afBqSvn$w@&<QjwZ8q$M5c$v{Rjk(n%HB^%kvK~8d!n>^$tANeUjK?+frA{3<<'
    b'#VJ8aN>Q3Jl%*WysX#?4QJE@Kr5e?#K}~8=n>y5`9`$KJLmJVTCN!lP&1pePTG5&|w51*G=|D$1(U~rEr5oMpK~H+on?CfVAN?7?Kn5|GAq-'
    b'_0!x_OyMlqT(jAb0-nZQIQF_|e$Wg63&!Axc`n>oy79`jkiLKd-'
    b'@B`jqb%UQunR<W8jtYsbR*}z6Nv6(GwWgFYs!A^Fun?3AhANx7LK@M@4BOK)z$2q}CPH~zuoaG$nxxhs(ahWSz<r>$y!A)*)n>*a)9`|{`Lmu&%Cp_gD&w0U'
    b'1Uh$eYyyYG5`M^g$@tH4t<s0Am!B2kin?L;hZv(|Y1Rx-'
    b'R2uu)y5{%%4AS9s(O&G!wj_^bvB9Vwp6rvK1=)@o<v4~9^;u4SeBp@M)NK6uvl8oe}ASJ0tO&ZdYj`U<8Bbmrd7P69!?BpOPxyVf(@{*7I6rdo5C`=KGQjFr'
    b'1pd_UzO&Q8kj`CEXB9*926{=E=>eQenwWv)U>QayTG@v1kXiO8D(v0S`pe3znO&i+Mj`nn*Bc13>7rN4o?)0E1z35FJ`qGd73}7IG7|alcGK}GjU?ig$%^1c'
    b'qj`2)jB9oZR6s9tb>C9jzvzW~s<}#1@EMOsvSj-ZZvW(@dU?r<q%^KFSj`eI{Bb(UF7PhjD?d)JDyV%Vh_Og%t9N-'
    b'{_ILr}_a*X4g;3TIw%^A*ej`LjLBA2+#6|QoP>)hZbx46w6?sAX&Jm4XZc+3-'
    b'?@{H%a;3cnk%^TkGj`w`vBcJ%p7rye1@BH8=zxd4`{{FXl>K_6SkU#_`2tf%(a6%B0P=qE7VF^cgA`p>CL?#MRiAHo{5R+KMCJu3lM|={HkVGUV2}wyta#E0'
    b'zRHP;iX-'
    b'P+VGLVr>WF`w)$wqc^kds{GCJ%YZM}7)WkU|uu2t_GIaY|5<Qk13)WhqB_Do~M1RHh15sYZ2bP?K8JrVe$fM|~R5kVZ772~BB6b6U`nR<x!KZD~h)I?$0$bf'
    b'ybk=|*>Y(34*DrVoATM}Gz|kU<P)2tygha7HkaQH*8`V;RSICNPmnOlAsGnZ|TxFq2u#W)5?i$9xvBm?bP_8OvG0N>;I&HLPVF>)F6YHnEv4Y-'
    b'JnU*}+bBv70^YWgq)Fz(Edim?IqJ7{@umNltN^Go0ld=efW|E^(PFT;&?qxxr0tahp5b<q?m0!c(5{oEN<06|Z^2Ti)@W4}9bkpZUU9zVV$O{NxwE`NQA;Hc'
    b'0+M00I(-zyu*E!3a(WLK2G5gdr^92u}ne5{bw}Au7>`P7Goai`c{=F7b#@0uqvl#3Ugp$w*ELQj&_)q#-'
    b'ToNKXbbl8MY@AuHL)P7ZRCi`?WPFZsw%0SZ!x!W5w>#VAe*N>Yl_l%Xu;C{G0{Qi;k`p(@p=P7P{Oi`vwoF7>ES0~*qZ#x$WR&1g;wTGEQvw4p8SXio<^(uv'
    b'M=p)1|!P7iw0i{A91Fa7Ax00uIM!3<$2!x+v8Mly=gjA1O}7|#SIGKtAdVJg#@&J1QUi`mR!F7uer0v57}#Vlbd%UI3|R<erKtYIzdSkDGFvWd-XVJq9%&JK'
    b'36i{0#DFZ<Zf0S<DA!yMr#$2iUjPI8LVoZ&3zIL`$xa*4}a;VRd-&JAvIi`(4cF88?410M2-'
    b'$2{RF&v?!YUh<09yx}eHc+Uqu@`=xU;Va+x&JTX_i{Jd=?|+-4{~-VY2}EFm5R_m9Cj=o0MQFkhmT-h80uhNsWTFt2XhbIlF^NTN;t-'
    b'd3#3um>Nkn3jkd$O3Cj}`<MQYNJmUN^i0~yIgX0ni#Y-A?~ImtzC@{pH&<fi}yDMVq4P?Ta6rvxP_MQO@VmU5J*0u`x5WvWn>YE-'
    b'8NHK|2y>QI+@)TaRrX+&e1(3EC0rv)u(MQhs7mUgtK10Cr^XS&dpZgi&yJ?TYn`p}nt^k)DA8N^_QFqB~oX9Ob|#c0MbmT`<{0u!0UWTr5cX-sDZGnvI~<}j'
    b'Ce%x3`$S;S(Nu#{yiX9X)+#cI~DmUXOW0~^`IX11`EZER-'
    b';JK4o<_OO?I?B@UnImBU(aFk;l=L9D?#c9rPmUEov0vEZ&Wv+0QYh33BH@U@a?r@iT+~)xgdBkI$@RVmf=OwRr%^TkGj`w`vBcJ%p7rye1@BH8=zxd4`{{Ht'
    b'-#6JWeAb|)%P=XPh5QHQYp$S7+!V#VbL?jZCi9%GO5uF&sBo?uWLtNq!p9CZ%5s67cQj(E^RHP;iX-'
    b'P+VGLVr>WF`w)$wqc^kds{GCJ%YZM}7)WkU|uu2t_GIaY|5<Qk13)WhqB_Do~M1RHh15sYZ2bP?K8JrVe$fM|~R5kVZ74IW1^OD_YZrwzQ)?9q33WI@5)&bf'
    b'Y^x=*dlPahp5b<sSEWz(XGKm?u2t8P9paOJ4DnZ+zzmKl#OP{_vNkVU3^Ww4oin7{p+PFqB~oX9S}d%^1cqj`2)jB9oZR6s9tb>C9jzvzW~s<}#1@EMOsvSj'
    b'-ZZvW(@dU?r<q%^KFSj`eI{Bb(UF7PhjD?d)JDyV%Vh_Og%t9N-{_ILr}_a*X4g;3TIw%^A*ej`LjLBA2+#6|QoP>)hZbx46w6?sAX&Jm4XZc+3-'
    b'?@{H%a;3cnk%^TkGj`w`vBcJ%p7rye1@BH8=zxd4`{{H(>RXFPi0SHJS0uzLw1S2>h2uUbH6Na#aBRmm^NF*W?g{VX$Ix&bzEMgOfxWpqq2}npH5|f0aBqKQ'
    b'~NJ%PElZLdUBRv_&NG39qg{)*FJ2}WnE^?EHyyPQ41t>@%3R8rl6r(sLC`l<wQ--pXqdXO;NF^#$g{oAeIyI<CEoxJTy40gS4QNOs8q<WPG^05!Xh|zt(}uR'
    b'RqdgtyNGCeeg|2j?J3Z)0FM895zVxF%0~p941~Y`A3}ZMW7|AF`GlsE@V>}a>$Rs8+g{e$qIy0EbEM_x@xy)le3s}e^7PEw<EMqw<Sjj3@vxc>-'
    b'V?7(#$R;+kg{^F3J3H9PE_Snrz3gK@2RO(f4s(Q~9OF1AILRqabB42=<2)C*$R#dwg{xfSIybn<EpBs%yWHbG4|vEU9`l5!JmWbpc*!eX^M<#)<2@hv$R|GY'
    b'g|B?$J3sizFMjifzx*$}{1bqH1R^j&2ud)56M~S0A~azLOE|(4frvyRGEs<1G@=uOn8YGBafnMi;*)@cBqA|MNJ=u2lY*3_A~k79OFGh%fsAA#Gg-'
    b'(=HnNk0oa7=mdB{sX@>76<6rwOiC`vJkQ-'
    b'YF|qBLbFOF7C@fr?b3GF7NbHL6pCn$)5;b*M`{>eGORG@>z0Xi77h(}I??qBU)3OFP=rfsS;dGhOIPH@ee<p7f$OedtR+`ZIum3}P@t7|Jk)GlG$fVl-nI%Q'
    b'(g}fr(6FGE<n!G^R6ynapA~bC}CK=Cgo>EMhTBSjsY%vx1eZVl``6%R1JxfsJfpGh5ioHny{ao$O*ad)Ui9_H%%P9O5uXILa}ObApqc;xuPC%Q?<-'
    b'fs0(?GFQ0DHLi1mo800yceu+v?(=|$JmN7=c*--L^MaSW;x%u0%RAolfscIRGhg`1H@@?OpZwxCfB4J)BFH}h2uL6T6NI1yBRC-lNhm@ShOmSqJQ0XUBq9@q'
    b's6-<=F^EYlViSkB#3MclNJt_QlZ2!sBRMHZNh(s4hP0$3JsHSICNh(StYjlQImk&aa+8O=<Rd=?C`cg+Q-'
    b'q=vqc|lfNhwNGhO(5SJQb)&B`Q;es#K#oHK<7~YEy^0)T2HPXh<U((}bopqd6^TNh?~@hPJe$Jss#sCpy!Gu5_b2J?Kd<deeu#^rJrm7|0+7GlZcGV>lxi$t'
    b'XrMhOvxeJQJA6BqlS3sZ3)!GnmONW;2Jm%ws+aSjZw4vxKEAV>v5W$tqT}hPA9?Jsa4_CN{H$t!!gEJJ`uCcC&}Q>|;L%ILILmbA+QD<2WZc$tg~AhO?aGJQ'
    b'ujgB`$M?t6bwcH@L|yZgYpb+~YnEc*r9j^Mt27<2f&Q$tzy-hPS-qJs<eUCqDCquYBV>KlsTne)EUF5&o~J!aoEcAb|)>5P}kn;DjI~p$JVF!V-'
    b'?~L?9xOh)fis5{>A@ASSVhO&sD9kN6}YA&E##5|WaP<fI@asYp#4(vpt!WFRA%$V?Wpl8x--ASb!VO&;=+kNgy%AcZJQ5sFfb;*_8yr6^4q%2JN<RG=c2s7w'
    b'{AQjO}=peD7bO&#h|kNPyAA&qEE6PnVD=Cq(Ct!Paf+R~2pbf6=h=u8*7(v9x)peMcPO&|KwkNyl`AcGjp5QZ|0;f!D;qZrK?#xjoaOkg6Dn9LNWGL7lXU?#'
    b'Je%^c=3kNGTMA&Xed5|*-'
    b'z<*Z;Ot60q%*0PTEY+xgs*vwY8v7H_4WEZ>H!(R5Wp937^5QjO!QI2t(6P)A}r#Zt}&T)Z@T;eiUxXLxIbAy}Q;x>1<%RTP%fQLNdF;95PGoJH;m%QRNZ+Oc'
    b')KJbxGeC7*Z`NnsC@RMKs<_~}WE28ob0SHJS0uzLw1S2>h2uUbH6Na#aBRmm^NF*W?g{VX$Ix&bzEMgOfxWpqq2}npH5|f0aBqKQ~NJCoEk)8}>Bomp*LRPY'
    b'oogCyO7rDtpUh<Kj0u-bWg(*T&icy>rl%y1;DMMMxQJxA^q!N{>LRG3!of_1n7PYBEUFuPv1~jA*jcGztn$esVw4@cSX+vAu(Vh-'
    b';q!XR#LRY%cogVb07rp62U;5FX0SsgigBik5hB2HGjARs}8N*n{F`fxbWD=8^!c?X)of*tz7PFbdT;?&K1uSF{i&?@_ma&`_tYj6dS;Jb^v7QZVWD}d&!dAA'
    b'iogM6C7rWWRUiPt{103WKhdIJgj&Yn5oa7XzIm21bah?lY<Pw*;!d0$uog3Wb7Pq;>UG8z82R!5vk9opVp7ER)yyO+HdBa=Y@tzNS<P)Fy!dJfWoge(<7r*('
    b'#-'
    b'~Wmx{X+l(5{SSAAt=EJP6$F0iqM21Ea3=G1R@fN$V4G3(TGkAViJqk#33&6h))6%l8D44At}j7P6|?ziqxbbE$K*41~QU~%w!=e*~m@~a*~VO<RLHl$WH+ZQ'
    b'i#G7p(w>DP6<j<iqe#!EafOq1u9aB%2c5$)u>JlYEp~Z)S)i*s80hL(ul@1p()L1P77Mniq^EDE$wJe2RhP;&UB$G-'
    b'RMpadeV#D^r0{P=+6KKGKj$pVJO2G&Im>_iqVW=EaMo@1ST?x$xLA?)0oZ-W-'
    b'^P}%waC`n9l+hvWUejVJXX4&I(qtiq))PE$dj%1~#&Z&1_*S+t|(ycCw4z>|rna*v|nDa)`qm;V8#A&IwL(iqo9oEay1S1uk-'
    b'l%Ut0q*SO9NZgPv;+~F?wxX%L~@`%Sg;VI8}&I?}hir2j1E$?{G2R`zN&wSx4-}ufCe)5ao{Ne9^1=Ic^009X^V1f{oU<4-'
    b'wAqhoj!Vs2lgeL+Ki9}?g5S3^|Ck8QzMQq{_mw3b{0SQS&Vv>-QWF#jADM>|Y(vX&Pq$dLz$wX$dkd<s?CkHvnMQ-'
    b'wtmwe=>00k*TVTw?cViczYB`HN|%21Yal&1m}sYGR}P?c&_rv^2tMQ!R(mwMEv0S#$HW17&EW;CY-Eont-'
    b'+R&DEw5J0d=|pF`(3Ng<rw2XhMQ{4hmwxnT00SAsV1_W1VGL&kBN@eL#xRy~jAsH9nZ#tKFqLUcX9hEw#cbv<mwC)*0Sj5gVwSL!Wh`d}D_O;A*07d!tY-'
    b'ro*~DhHu$66WX9qjk#cuYnmwoK#00%k5VUBQ=V;tuMCppDw&Ty7<oaX`;xx{6zaFuIZ=LR>q#cl3zmwVjj0S|e^W1jGoXFTTxFL}jl-td-pyypWS`NU_w@Re'
    b'_T=LbLe#c%%b_rGF^{}6zH1R^j&2ud)56M~S0A~azLOE|(4frvyRGEs<1G@=uOn8YGBafnMi;*)@cBqA|MNJ=u2lY*3_A~k79OFGh%fsAA#Gg-'
    b'(=HnNk0oa7=mdB{sX@>76<6rwOiC`vJkQ-'
    b'YF|qBLbFOF7C@fr?b3GF7NbHL6pCn$)5;b*M`{>eGORG@>z0Xi77h(}I??qBU)3OFP=rfsS;dGhOIPH@ee<p7f$OedtR+`ZIum3}P@t7|Jk)GlG$fVl-nI%Q'
    b'(g}fr(6FGE<n!G^R6ynapA~bC}CK=Cgo>EMhTBSjsY%vx1eZVl``6%R1JxfsJfpGh5ioHny{ao$O*ad)Ui9_H%%P9O5uXILa}ObApqc;xuPC%Q?<-'
    b'fs0(?GFQ0DHLi1mo800yceu+v?(=|$JmN7=c*--'
    b'L^MaSW;x%u0%RAolfscIRGhg`1H@@?OpZwxCfB5@fq11l}KtKW!m>>it7{LiaNJ0^sFoY!>;fX**A`zJ=L?s&0i9t+a5t}%~B_8ofKtd9cm?R`68OcdON>Y)'
    b'UG^8aR>B&GwGLe}qWF;Hf$w5wXk()f^B_H`IKtT#om?9LV7{w_;NlH<gGL)qp<*7hLDp8p#RHYi#sX<L@QJXr{r5^QZKtmeQm?ku(8O>=yOIp#IHngQ3?dd>'
    b'AI?<Ufbfp{J=|N9=(VIT>r62tnz(58um>~>h7{eLCNJcT5F^pv#<C(xjCNY^QOl2C=nZZnEF`GHeWghccz(N+Wm?bP_8OvG0N>;I&HLPVF>)F6YHnEv4Y-'
    b'JnU*}+bBv70^YWgq)Fz(Edim?IqJ7{@umNltN^Go0ld=efW|E^(PFT;&?qxxr0tahp5b<sSEWz(XGKm?u2t8P9paOJ4DsH@xK?@A<$-'
    b'KJl3^eB~S8`N2<q@#o*HN0)U16NI1yBRC-lNhm@ShA2cO8qtYCOkxq6IK(9$@ku~J5|NlBBqbTiNkK|dk(xB5B^~L>Kt?i=nJi=_8`;T0PI8f(Jme)G`6)m_'
    b'3Q?FM6r~u&DM3j}QJON8r5xp{Kt(E1nJQGJ8r7*mO=?k_I@F~e^=Uvu8qt_0G^H8MX+cX`(V8~2r5)|*Ku0>!nJ#pt8{O$aPkPatKJ=v@{Ta*<hBAVYjAArn'
    b'7|S@uGl7XrVlq>h$~2}kgPF`?HglNEJm#~2g)Cw*OIXS>ma~GDtYS55Sj#%rvw@9lVl!LV$~LyMgPrVRH+$K~ehzSuLmcJ^M>)oEPH>V_oaPK?ImdY}aFI(~'
    b'<_cH2#&vFRlUv;84tKf7eID?TM?B^UPkF|3UhtAvyygvWdB=M`@R3h^<_ll>#&>@3lVAMi4}bqFZ2k`c2uL6T6NI1yBRC-lNhm@ShOmSqJQ0XUBq9@qs6-'
    b'<=F^EYlViSkB#3MclNJt_QlZ2!sBRMHZNh(s4hP0$3JsHSICNh(StYjlQImk&aa+8O=<Rd=?C`cg+Q-'
    b'q=vqc|lfNhwNGhO(5SJQb)&B`Q;es#K#oHK<7~YEy^0)T2HPXh<U((}bopqd6^TNh?~@hPJe$Jss#sCpy!Gu5_b2J?Kd<deeu#^rJrm7|0+7GlZcGV>lxi$t'
    b'XrMhOvxeJQJA6BqlS3sZ3)!GnmONW;2Jm%ws+aSjb|Qu#DBLVJ+)e&jvQKiOp<bE8E!44tBDO-'
    b'R$86XE@6_&U1l_T;eiUxXLxIbAy}Q;x>1<%RTP%fQLNdF;95PGoJH;m%QRNZ+Oc)-t&QveBv`-'
    b'_{wko@b|xl1OE_!fCM5iK?q7Pf)j#}gd#Ly2unD^6M=|CA~I2kN;IMqgJrR-vFu_ud)Ui9_H%%P9O5uXILa}ObApqc;xuPC%Q?<-'
    b'fs0(?GFQ0D7b3?tCZZCJ=)@o<v4~9^;u4Se+>T?th%57CA~RXYN;Yzmivkp+5QQm52})6#GL)qp<*7hLDp8p#RHYi#sX<L@QJXr{r5^QZKtmeQm?ku(8O>=y'
    b'OIp#IHngQ3?dd>AI?<Ufbfp{J=|N9=(VIT>r62tnz(58um>~>h7{eLCNJcT5F^pv#<C(xjCNY^QOl2C=nZZnEF`GHeWghccz(N+Wm?bP_8OvG0N>;I&HLPVF'
    b'>)F6YHnEv4Y-JnU*}+bBv70^YWgq)Fz(Edim?IqJ7{@umNltN^Go0ld=efW|E^(PFT;&?qxxr0tahp5b<sSEWz(XGKm?u2t8P9paOJ4DsH@xK?@A<$-'
    b'KJl3^eB~S8`N2<q@tZ&V{jU+pKLj8kfe1_xf)b42gdilL2u&Em5{~dhAR>{7OcbILjp)Q6Cb5W39O4p>_#_}9iAYQml9G(%q#z}!NKG2jl8*FbAS0Q`Oct_|'
    b'jqKzgC%MQ?9`cfp{1l)dg(yrBic*Z?l%OP~C`}p4QjYRepdyv1Ockn9jq22(Cbg(d9qLk#`ZS;+jc800n$nEsw4f!eXiXd1(vJ3Ypd+2=Oc%P+jqdcIC%x!R'
    b'ANtad{tRFsgBZ*ZhBA!dj9?_A7|j^QGLG>~U?P*4%oL_Fjp@u_CbO8$9Og2Q`7B@|i&)GOma>fHtY9UpSj`&NvX1p^U?ZE@%oet?jqU7UC%f3q9`>@2{T$#R'
    b'hd9g;j&h9SoZuv<IL#T(a*p#{;3Ai}%oVP3jqBXtCbziF9qw|E`#j(wk9f=zp7M<6yx=9Tc+DH$@{ad>;3J>-'
    b'%oo1$jqm*6C%^d3AO8N=gy<gv5RgCwCI~?ZMsPw9l2C*u3}FdJcp?yyNJJ(IQHe%$Vi1#9#3l}LiAQ`AkdQ<qCJ9MNMsiY+l2oK74QWY7dNPoaOk^etS;<Cr'
    b'a*&f;<R%Y!$wz()P>_E+Llve7MJYycN>Gwgl%@=2DMxuKP?1VhrV3T5Ms;dXlUmfK4t1$VeHze^Ml_}gO=(7RTF{bKw5APhX-9iH(2-'
    b'7brVCx^Mt6G9lV0?u4}IxJe+Dp+K@4UHLm9?!Mlh05jAjgD8OL}gFp)`2W(rf8#&l*dlUdAW4s)5ud={{fMJ#3sOIgNpR<M#)tY!^sS;u-du#rt{W(!-'
    b'{#&&kFlU?j)4}00iehzSuLmcJ^M>)oEPH>V_oaPK?ImdY}aFI(~<_cH2#&vFRlUv;84tKf7eID?TM?B^UPkF|3UhtAvyygvWdB=M`@R3h^<_ll>#&>@3lVAM'
    b'i4}bq_K=uy-2uL6T6NI1yBRC-lNhm@ShOmSqJQ0XUBq9@qs6-'
    b'<=F^EYlViSkB#3MclNJt_QlZ2!sBRMHZNh(s4hP0$3JsHSICNh(StYjlQImk&aa+8O=<Rd=?C`cg+Q-'
    b'q=vqc|lfNhwNGhO(5SJQb)&B`Q;es#K#oHK<7~YEy^0)T2HPXh<U((}bopqd6^TNh?~@hPJe$Jss#sCpy!Gu5_b2J?Kd<deeu#^rJrm7|0+7GlZcGV>lxi$t'
    b'XrMhOvxeJQJA6BqlS3sZ3)!GnmONW;2Jm%ws+aSjZw4vxKEAV>v5W$tqT}hPA9?Jsa4_CN{H$t!!gEJJ`uCcC&}Q>|;L%ILILmbA+QD<2WZc$tg~AhO?aGJQ'
    b'ujgB`$M?t6bwcH@L|yZgYpb+~YnEc*r9j^Mt27<2f&Q$tzy-hPS-qJs<eUCqDCquYBV>KlsTne)EUF|1}@{hX4d55P=CoP=XPh5QHQYp$S7+!V#VbL?jZCi9'
    b'%GO5uF&sBo?uWLtNq!p9CZ%5s67cQj(FJ6r>~-sYydx(vhAFWF!-'
    b'r$wF4Lk)0gmBp12KLtgTcp8^!55QQm1QHoKV5|pGAr71&M%2A#QRHPD>sX|q%QJospq!zWQLtW}op9VCf5shg=Q<~A77PO=lt!YDB+R>g4bfgoV=|We!(VZU'
    b'jq!+#ELtpyQp8*VH5Q7=QP=+y_5sYLMqZz|k#xb4=Ok@(1nZi`2F`XIAWEQiT!(8Sup9L&r5sO*EQkJot6|7_xt69TZ*0G)qY-AIg*}_(~v7H_4WEZ>H!(R5'
    b'Wp937^5QjO!QI2t(6P)A}r#Zt}&T*a#T;vj$xx!Vhah)67<QBKN!(Hxip9ehT5s!JoQ=ajh7rf*ZuX)2;-'
    b'tnFfeB=|K`NCJe@tq(1<QKpB!{7fJkN!gd0uqS81R*HF2u=t>5{l4-AuQntPXr<oiO57DD$$5e3}O<C*u)_&@rX|X5|W6-'
    b'Bq1ruNKOh;l8V%%AuZ`hPX;oQiOggnE7{0S4sw!<+~grI`N&TJ3Q~x|6rm`^C{77VQi{@)p)BPnPX#JciON)=D%Ge?4Qf)0+SH*g^{7t+8q$cyG@&WYXif`S'
    b'(u&r!p)KubPX{{EiOzJPE8XZ$4|>vz-'
    b't?g_{pimC1~Q1j3}Gn47|sYrGK$fRVJzbq&jcniiOEc1D$|(G3}!Nm+00=s^O(;97P5%NEMY0jSk4MovWnHLVJ+)e&jvQKiOp<bE8E!44tBDO-'
    b'Rxm6``FI`4swXY9N{R(IL--9a*ETO;VkDk&jl`WiOXE!D%ZHq4Q_Ia+uY$U_qfjk9`cCCJmD$Nc+Lx6@`~5I;VtiY&j&v8iO+oDE8qCe4}S8C-'
    b'~8e4e@%z~ApijhL|}ptlwbrW1R)7UXu=SdaD*oU5s5@(q7ap6L?;F@iA8MU5SMtwCjkjbL}HSVlw>3)1u02IYSNIFbfhN(8OcOuvXGT*WG4qX$whARke7Vqr'
    b'y#{BP6<j<iqe#!EafOq1u9aLTGXZvb*V>v8qknNG^PnnX-'
    b'0Ee(2`cPrVVXrM|(QZkxq1`3tj0(cY4s1Ui799ed$Mk1~8C83}y&J8OCr%Fp^P>W(;E)$9N_%kx5Ku3R9WJbY?J<S<Ge*bD76{7O;>-'
    b'EM^HyS;lf!u##1*W({ju$9gufkxgu73tQR7c6P9nUF>ELd)db!j&O|QoZuv<IL#T(a*p#{;3Ai}%oVP3jqBXtCbziF9qw|E`#j(wk9f=zp7M<6yx=9Tc+DH$'
    b'@{ad>;3J>-%oo1$jqm*6C%^c^-'
    b'~Sqg|3d%*5{SSAAt=EJP6$F0iqM21Ea3=G1R@fN$V4G3(TGkAViJqk#33&6h))6%l8D44At}j7P6|?ziqxbbE$K*41~QU~%w!=e*~m@~a*~VO<RLHl$WH+ZQ'
    b'i#G7p(w>DP6<j<iqe#!EafOq1u9aB%2c5$)u>JlYEp~Z)S)i*s80hL(ul@1p()L1P77Mniq^EDE$wJe2RhP;&UB$G-'
    b'RMpadeV#D^r0{P=+6KKGKj$pVJO2G&Im>_iqVW=EaMo@1ST?x$xLA?)0oZ-W-'
    b'^P}%waC`n9l+hvWUejVJXX4&I(qtiq))PE$dj%1~#&Z&1_*S+t|(ycCw4z>|rna*v|nDa)`qm;V8#A&IwL(iqo9oEay1S1uk-'
    b'l%Ut0q*SO9NZgPv;+~F?wxX%L~@`(S(-dzRDd2ZQ))e$pWl0~-20*fWf7Be$5Gcz+YGcz+YGcz+YGxu=R?zq10s=8IDtD|m5w<5-a-'
    b'jcq|+;h$K=UtxglxIBW1uuEUYu@mdcf98VANj;*zVMZAf1cIE&MFa!L}a26l^=*kbYk!$F^NTN;t-'
    b'dg_?dXbCjkjb#4jW!2}w!DuOuf0DM>|Y(vX&Pq~|v>kcF&dBRe_BNiK4ehrHw?KLsdAAqrE3q7<VzB`8TLN>hfil%qTqs7NI$Q-'
    b'!KjqdGOHNiAwqhq~0GJ`HF{BO23$rZl5DEoezATGNKMw4*&8=tw6z(}k{dqdPt5NiTZShraZqKLZ%ZAO<spp$ua<BN)jjMl*)7jAJ|#n8+k1Gli*4V>&aK$t'
    b'-3whq=sSJ_}gLA{MiRr7UAPD_F@YR<nk+tYbYJ*vKX}vxTi}V>>(8$u4%YhrR4$KL<F-'
    b'Ar5ndqa5QnCpgI|PIHE{oZ~zfxX2|gbA_v1<2pCE$t`Ykhr8V4J`Z@vBOddFr#$01FL=o-'
    b'Uh{^xyyHC|_{b+d^M$W`<2!+p_*^D1K?q7Pf)j#}gd#Ly2unD^6M=|CA~I2k$`3>%Ix+Z>n8YGBafr)L{7gLJlYoRI;ujK=grp?nSCW&0l%ygxX-'
    b'G>t((@Y`_?<t<NG39qg{)*FJ2}WnE^?EHyyPQ41t>@%3R8rl6r(sLC`l<wQ--pXqdXO;NF^#$g{oAeIyI<CEoxJTy40gS4QNOs8q<WPG^05!Xh|zt(}uRRqd'
    b'gtyNGCeeg|2j?J3Z)0FM895zVxF%0~p941~Y`A3}ZMW7|AF`GlsE@V>}a>$Rs8+g{e$qIy0EbEM_x@xy)le3s}e^7PEw<EMqw<Sjj3@vxc>-'
    b'V?7(#$R;+kg{^F3J3H9PE_Snrz3gK@2RO(f4s(Q~9OF1AILRqabB42=<2)C*$R#dwg{xfSIybn<EpBs%yWHbG4|vEU9`l5!JmWbpc*!eX^M<#)<2@hv$R|GY'
    b'g|B?$JAslq{{$uoK?z21LJ*QrgeDAO2}gJ$5RphkCJIscfoMc020s#$Si~j{arud#iAQ`AkdQ?DLSmATlw|x$a#E0zRHP;iX-'
    b'P+Vej@|F^9LEpL}s#(m26}u2RX?_Zt{?qeB`G91t~;ficpkd6sH6wDMe|@P?mC(rveqJL}jW_m1<O{1~sWgZR${$deo-'
    b'@4QWJUn$VPHG^YhEX+>+=(3W<zrvn}7L}$9tm2PyW2R-RUZ~D-'
    b'ee)MMm0~y3%hA@<23}*x*8O3PEFqUzQX95$M#AK#0m1#_81~Zw(Z00bRdCX@43t7Zsmavp%EN2BPS;cDBu$FbKX9FAA#Addzm2GTi2RqrtZuYR3eeCA|2RX!'
    b'Hj&PJ?9OnclImKztaF%nN=K>eG#AU8<m1|t*1~<9IZSHWFd)(&%4|&96p74}sJm&>3dBtnq@RoPH=K~-'
    b'4#Am+nm2Z3}P%`JAzyu*E!3a(WLK2G5gdr^92u}ne5{bw}Au2x*jp)SSM`99-*u)_&Kk+m1h))6%l89eOOcIikj9*Dk3R04a)TALT=}6CSWZ-xHAS0Q`Oct_'
    b'|jqKzgC%MQ?9`cfp{1l)dg(yrBic*Z?l%OP~C`}p4QjYRepdyv1Ockn9jq22(Cbg(d9qLk#`ZS;+jc800n$nEsw4f!eXiXd1(vJ3Ypd+2=Oc%P+jqdcIC%x!'
    b'RANtad{tRFsgBZ*ZhBA!dj9?_A7|j^QGLG>~U?P*4%oL_Fjp@u_CbO8$9Og2Q`7B@|i&)GOma>fHtY9UpSj`&NvX1p^U?ZE@%oet?jqU7UC%f3q9`>@2{T$#'
    b'Rhd9g;j&h9SoZuv<IL#T(a*p#{;3Ai}%oVP3jqBXtCbziF9qw|E`#j(wk9f=zp7M<6yx=9Tc+DH$@{ad>;3J>-'
    b'%oo1$jqe2d)%hndK?q7Pf)j#}gd#Ly2unD^6M=|CA~I2k$`3>%Ix+Z>n8YGBafr)L{7gLJlYoRI;ujK=grp?nSCW&0l%ygxX-'
    b'G>t((@Y`_?<t<NG39qg{)*FJ2}WnE^?EHyyPQ41t>@%3R8rl6r(sLC`l<wQ--pXqdXO;NF^#$g{oAeIyI<CEoxJTy40gS4QNOs8q<WPG^05!Xh|zt(}uRRqd'
    b'gtyNGCeeg|2j?J3Z)0FM895zVxF%0~p941~Y`A3}ZMW7|AF`GlsE@V>}a>$Rs8+g{e$qIy0EbEM_x@xy)le3s}e^7PEw<EMqw<Sjj3@vxc>-'
    b'V?7(#$R;+kg{^F3J3H9PE_Snrz3gK@2RO(f4s(Q~9OF1AILRqabB42=<2)C*$R#dwg{xfSIybn<EpBs%yWHbG4|vEU9`l5!JmWbpc*!eX^M<#)<2@hv$R|GY'
    b'g|B?$JAslr{{$uoK?z21LJ*QrgeDAO2}gJ$5RphkCJIscfoMc020s#$Si~j{arud#iAQ`AkdQ?DLSmATlw|x$a#E0zRHP;iX-'
    b'P+Vej@|F^9LEpL}s#(m26}u2RX?_Zt{?qeB`G91t~;ficpkd6sH6wDMe|@P?mC(rveqJL}jW_m1<O{1~sWgZR${$deo-'
    b'@4QWJUn$VPHG^YhEX+>+=(3W<zrvn}7L}$9tm2PyW2R-RUZ~D-'
    b'ee)MMm0~y3%hA@<23}*x*8O3PEFqUzQX95$M#AK#0m1#_81~Zw(Z00bRdCX@43t7Zsmavp%EN2BPS;cDBu$FbKX9FAA#Addzm2GTi2RqrtZuYR3eeCA|2RX!'
    b'Hj&PJ?9OnclImKztaF%nN=K>eG#AU8<m1|t*1~<9IZSHWFd)(&%4|&96p74}sJm&>3dBtnq@RoPH=K~-'
    b'4#Am+nm2Z3}PzvXtzyu*E!3a(WLK2G5gdr^92u}ne5{bw}Au2x*jp)SSM`99-*u)_&Kk+m1h))6%l89eOOcIikj9*Dk3R04a)TALT=}6CSWZ-xHAS0Q`Oct_'
    b'|jqKzgC%MQ?9`cfp{1l)dg(yrBic*Z?l%OP~C`}p4QjYRepdyv1Ockn9jq22(Cbg(d9qLk#`ZS;+jc800n$nEsw4f!eXiXd1(vJ3Ypd+2=Oc%P+jqdcIC%x!'
    b'RANtad{tRFsgBZ*ZhBA!dj9?_A7|j^QGLG>~U?P*4%oL_Fjp@u_CbO8$9Og2Q`7B@|i&)GOma>fHtY9UpSj`&NvX1p^U?ZE@%oet?jqU7UC%f3q9`>@2{T$#'
    b'Rhd9g;j&h9SoZuv<IL#T(a*p#{;3Ai}%oVP3jqBXtCbziF9qw|E`#j(wk9f=zp7M<6yx=9Tc+DH$@{ad>;3J>-'
    b'%oo1$jqe0X>HHIzAOs~C!3jY~LJ^uUge4r|i9kdm5t%4N<p-'
    b'h>of!N`Okxq6IK<^AekLCANkBpp@e7GbLQ<0PE6GVgN>Y)UG^8aR>G_Qe{LUX_Bomp*LRPYoogCyO7rDtpUh<Kj0u-'
    b'bWg(*T&icy>rl%y1;DMMMxQJxA^q!N{>LRG3!of_1n7PYBEUFuPv1~jA*jcGztn$esVw4@cSX+vAu(Vh-'
    b';q!XR#LRY%cogVb07rp62U;5FX0SsgigBik5hB2HGjARs}8N*n{F`fxbWD=8^!c?X)of*tz7PFbdT;?&K1uSF{i&?@_ma&`_tYj6dS;Jb^v7QZVWD}d&!dAA'
    b'iogM6C7rWWRUiPt{103WKhdIJgj&Yn5oa7XzIm21bah?lY<Pw*;!d0$uog3Wb7Pq;>UG8z82R!5vk9opVp7ER)yyO+HdBa=Y@tzNS<P)Fy!dJfWoj|Fae*zP'
    b'Ppadg0AqYt*LKB9tgd;o=h)5(N6NRY!Ks2HggCB`WEMgOfxctP=#3MclNJt`nAu&lvN-'
    b'};WIVng<DpHe%w4@_Fzmb98`GbsPA~RXYN;a~SgPi0dH+jfQKJrt5f)t`KMJP%!ic^A;l%h0cC`&oYQ-'
    b'O+9qB2#eN;RregPPQ$Hg%{=J?hhdhBTrvO=wCpn$v=ow4ya_XiGcV(}9k3qBC9SN;kUGgP!!FH+|?!Kl(F(fed0WLm0|1hBJbZjAArn7|S@uGl7XrVlq>h$~'
    b'2}kgPF`?HglNEJm#~2g)Cw*OIXS>ma~GDtYS55Sj#%rvw@9lVl!LV$~LyMgPrVRH+$I2KK65fgB;>8M>xtcj&p*OoZ>WRILkTCbAgLo;xbpb$~CTYgPYvqHg'
    b'~woJ?`^>hdkmjPk72Rp7Vm2yy7))c*{H9^MQ|i;xk|P$~V3fD7EuXV1f{oU<4-wAqhoj!Vs2lgeL+Ki9}?g5S1T@Ms#BEBQc3ZY~m1?pZJ-'
    b'0#3um>NyINCCJ9MN#;+tN1u02IYSNIFbfo7uGVnWpkdaJeCJR}~Ms{+LlU(E`4|&N)ehN^KLKLP5MJYycN>Gwgl%@=2DMxuKP?1VhrV3T5Ms;dXlUmfK4t1$'
    b'VeHze^Ml_}gO=(7RTF{bKw5APhX-9iH(2-'
    b'7brVCx^Mt6G9lV0?u4}IxJe+Dp+K@4UHLm9?!Mlh05jAjgD8OL}gFp)`2W(rf8#&l*dlUdAW4s)5ud={{fMJ#3sOIgNpR<M#)tY!^sS;u-du#rt{W(!-'
    b'{#&&kFlU?j)4}00iehzSuLmcJ^M>)oEPH>V_oaPK?ImdY}aFI(~<_cH2#&vFRlUv;84tKf7eID?TM?B^UPkF|3UhtAvyygvWdB=M`@R3h^<_ll>#&-'
    b'gxasCNR5P}kn;DjI~p$JVF!V-?~L?9xOh)fis@&nO`P7Hn|Cb5W39OCj5KNFAmBp@M)_=UtIAt}lDmE@!#C8<bF8q$)E^!!E!e&-'
    b'J|l8MY@AuHL)P7ZRCi`?WPFZsw%0SZ!x!W5w>#VAe*N>Yl_l%Xu;C{G0{Qi;k`p(@p=P7P{Oi`vwoF7>ES0~*qZ#x$WR&1g;wTGEQvw4p8SXio<^(uvM=p)1'
    b'|!P7iw0i{A91Fa7Ax00uIM!3<$2!x+v8Mly=gjA1O}7|#SIGKtAdVJg#@&J1QUi`mR!F7uer0v57}#Vlbd%UI3|R<erKtYIzdSkDGFvWd-XVJq9%&JK36i{0'
    b'#DFZ<Zf0S<DA!yMr#$2iUjPIBtc*G1ma1%f+LMXML6TeFUH7u0Lg|I?F^Ok}1A#VAe*N>ZBIw4fF9S-?UTv6v++Wf{v^$!gZJfsJfpGh5ioP7ZL8lbqr-'
    b'XE@6_&U1l_T;eiUxXCT<@|+jE<Q1=Z!&~0*o)3KF6QB9QSHAI`!2j?bLr{VdoDhU06rl-2Si%vW2t*_jk%>Z7ejpmr$w@BqQ-Fe$qXHGFL}jW_m4>vU4YQfU'
    b'T;?&K1uSF{i&@HYR<fEktYsbR*}z7&ahM|<<rv2~!AVYWnlqf`92dCA74C7L2R!5vk9opVp7ER)yyO+HdBa=Y@rloT;Va+x{*ON&eDCuFCI~?ZMsPw9l2C*u'
    b'3}FdJcp?yq$VBA_QjnT7{6Qu%lZA4Wr#}N2$RGwYgrN*$I3pO%7{)S=iA-'
    b'k}vzfyZma?3K9O5uXILa}ObApqc<2)C*$R#dwg{xfSIybn<EpBs%yWHbG4|vEU9`l5!JmWbpc*!eX^M<#)<2@hv%$GkOzaSnvq7j?8{KU`1;}0^@fQB@pF-'
    b'>SnGn&(amb9TQ?PyPDdeNJK3}QBOn9Drovw(#xVlm5E!Ae%Knl-Ft9qZY^MmDjTEo@~Q+u6ZRcCnj1>}4POIlw^<ahM|<<rv2~!AZ_=mJ9sD`)7C}5RoJ#B^'
    b'kexoD`%a6{$%>+CSfS8N*n{F`fxbWD=8^!c?X)i`mR!9`jkiLKd-'
    b'{73^j&$2q}CPH~zuoaG$nxxhs(@r56PdG3ivd=ik5MEpWxl8}^S{7Q0CkdjoSCJkvxM|yrE1HbbJ8OcOuvXGT*<RB-'
    b'x$W0#dl8?d^p(w>DP6<j;nlhB79ObD%MJiF5DpaK!)u};EYEhdy)TJKvX+T37(U>MQr5Vj>K}%ZEnl`kh9qs8rM>^4&E_9_E-'
    b'RVJ3deNIc^ravD8NfgWF_<9?Wf;R5!AM3inlX%J9OIe5L?$trDNJP=)0x3cW-*&N%w-<)S-?UTv6v++Wf{v^!4ZyeoD-bmJ7Imv2uFAlkdR+UOcIikj9*Dk3'
    b'R04a)C^%L!x+v8Mly=gjA1O3n9LNWF`XIAWEKn9#AddzkNq6rAcr{25sq?<<DB3m7rD+W!h~?Yh)xWCBqp(lO&sF#6F(D=_#_}9iTH)YBq1ru_?6_OASJ0tO'
    b'&ZdYj`U>Ucm5zFnaE5Ia*~VO<RLHlDL_FAQJ5kWr5MF2K}kwcnlhB79ObD%MJiF5DpaK!)u};EYEhdy)TJKvX+T37(U>MQr5Vj>K}%ZEnl`kh9qs8rM>^4&E'
    b'_9_E-RVJ3deNIc^ravD8NfgWF_<9?Wf;R5!AM3inlX%J9OIe5L?$trDNJP=)0x3cW-*&N%w-'
    b'!p*vT#q@`@lKeXk)HAqYuMa&eCHT;L*?xXcx<a*gZU;3l`Y!(Hxip9j3+HE(#!JKpnwk9^`YU--(mKW|GYw}nuICM@B|!0-G)Mlw-'
    b'>id3R9Rj5ies#AlS)S@<Zs7pQS(}0FFqA^WqN;8_%f|j(RHEn21JK8gVfed08!x_z2z7Zs}$CzNGqA^WqN;8_%f|j(RHEn21JKEEMj&!0kUFb?Ty3>Q6^rAO'
    b'?=u1EPGk}2%VlYD($}omAf{~13G-'
    b'DXcI3_WfDXd{Fo7l`2wz7@w>|iIm*v%gHvXA{7;2?)M%n^=qjN_c(B&Rsd8P0N!^IYH}m$=Lou5yj*+~6j+xXm5za*z8w;31EA%oCpSjOV=IC9inR8{YDc_k'
    b'7?ZpZLrdzVeOl1PbFj7=Z~wP=XPh5QHQYp$S7+!V#VbL?jZCi9%F<AR5t$!H>iw4Qa_t7P69)JmjSsUFk+Ideeu#^rJrm7|0-'
    b'|FqLUcX9hEw#cbv<mwC)*0ZUoN#Xs+NSht<XL?J3a5RC#9Vj-8f%oVP3jqBXtCbziF9qw|E`#j_kk9op7-t&QveBv`-_{ulF6DXY9Mqt7amT-'
    b'h8B9X{MX0ni#DpaK!)u};EYEhdy)TJKvX+T37(U>MQr5Vj>K}%ZEnl`kh9qs8rANtadfed0W!}-'
    b'WJz7r_C&uywxgPPQ$Hg%{=J?hhdhBTrvO=wCpn$v=ow4ya_XiGcV(}9k3qBC9SN;kUGgP!!FH+|?!Kl(F(fed9B!<o+lma>fHtY9UpSj`&NvX1p^U?ZE@%oe'
    b't?jqU7UC%f3q9`>@2{T$#Rhd9g;j&h9SoZuv<IL#T(a*p#{;3Ai}%oVP3jqBXtCbziF9qw|E`#j(wk9f=zp7M<6yx=9Tc+DH$@{ad>;3J>-'
    b'%oo1$jqe1C;5ANQf)JEo1SbR`2}Nka5SDNxAR#G8MLJ5*jOMha4Q**hdpgjOPIP7{!x+v8Mly=gjA1O}7|#SIk|$@GKO?BW<bS!E*Xj5#z5YM{1;j6b{7D<g'
    b'M`)mcx7I)b$2m~IT@DoRlhT0#er7UIz|Tzu3i$boKQEIXC^m73OTgu@0|i_bGf=?gu>u8LZX-'
    b'~@dT*eBHJ?BMb>Bb%wVyx%<G(*g0D;m5`X5<k27c#{fXp%rS;<Cra*&f;<R%Y!$wz()P>@0t4#+!;{wtYhses(G3}q=tc`8tmN>ru_wWvc~>QSEtG^7!YX+l'
    b'$){Uz7@d!~7nYh35XUoy_y+zH4!?*;motgr?(sYQJn1Z0PeXhJiZ(}I??rY-GgPX{{EiOzJPE8XZ$4|>vz-'
    b't?g_{pimC1~Q1j3}Gn47|sYrGK$fRVJzbq&jcniiOEc1D$|(G3}!OxKbV6q3CKd11>~VC0y5E6|BGC76Pww>)_|OJJ3H9PE_Snrz3gK@2RO)~e<D{s|Cem_5'
    b'|;xq)~j6OIybn<EpBs%yZ=Qw?0Y`&@xM5e{Xg^Ah=0jsqx>b8jYf20@FOvaMQq{_m!J5Vc*G|G2}#5+Bqj+-Nye`v56FB|lIkznZ(7okp5Ms8?*W-'
    b'`#=qslS;<Cra*&f;<R%Y!$wz()P>@0trU*qTMsZ3|l2VkW3}ye4Jy)P2m8eV=s#1;W)SxD{s7)Q}QjhvHpdpQDOcR>YjOMhUC9P;p8`{#2_H>{lo#;##y3&p'
    b'A^q?ob=uIE`((gZ!n~!AFzmlJiXF@=ZK8eXpVJg!Cvh^9v{9DF8mwC)*0Sj5g;=knY%K|d^6|7_xt69TZ*0G)qY-AIg*}_(~v7H_4WEZ>H!(R5Wp9BBFoc|Q'
    b'3Im6li&2s;beELiN|CMii5BM_h4+0Z}padg0AqYt*LKB9tgd;o=h)AR$|1wjELe#&^7NQe_ABjn<fO$ile`V$np9CZ%5x<a_BqSvnzml93q$CxoNkdxFk)Ge'
    b'k!0&&VWn>~VS;$H@vXg_H<RUkD$V)!*Q-FdLqA*1$N->I4f|8V?G-'
    b'W7DIm%Okid3R9Rj5ies#AlS)S@<Zs7pQS|0iZJt!VwP%wjswkxl_~nJ#pt8{O$a&%exT`p}nt^k=|dW;lZx!cc}WoDqy<6r&l#SSB-'
    b'tsZ3)!Gnn}wm;)_gDa-zgW<r0R2kre&&Vf#G`Y-dKbDR&D3ti+Am$|}Ku5q0k+~gLwxx-'
    b'!V^Mq$S=LIi$#cSU1mUq1810VUsXTI>2Z+!pri+s?3nNI~K2tf%(a6%B0P=qE7VF~xQc~&GM6NRXM&WDIbbYk!$F^NTN;t-'
    b'dg_?dXbCjkjb#4jZNCuU{o`Hc+x&L3nX6Pd|ER<e<u9ONVyxyeIb@{ykc6r>P^DMC?-'
    b'QJfN#q!gtoLs`mEo(fc?5|yb!RjN^)8q}l~wW&j0>QSEtG^7!YX+l$)(VP~vq!q1cLtEO>o(^=R6P@WoSGv)i9`vLaz3D?=`q7^O3}g_48NyJ8F`N;MWE7+S'
    b'le5a{%wXo<=9Y8+joIa5mavp%f0<>jWEHDf!&=s{o(*hd6Pww>R<^O79qeRRz)W;cz+7}6`#Hct4sn<x9Oc+QF+07?6|QoP>)hZbx46w6?sAX&Jm4XZc+3-'
    b'?@{H%a;3cnk%^TkGj`w^B`Y-*RPkauT-+tvA-w71V`6n<z2ud)56M~S0A~a$CoY@hM@I)XYk%&wbq6YgP^Wo^k;74K-'
    b'i`c{=E<f?}f8!iE`~PB=oSy;|q|m=JTQ2$k&zJvO=gTWu#cI~DmUXOW0~^`IX11`EZER-'
    b';JK4o<_OO?I?B@UnImF?BS@zMt&9hH(iqo9oY`~2BJQujgB`$M?t6bwcH@L|yZgYpb+~YnEc*r9j^Mt27<2f&Q$tzy-hPS-qJs<eUCqDCquY3!b!3PTN{1cc'
    b'U1SJ^32|-9g5&F;BcJTjsW*>owL?SX#h{_K{BRVnok(k6HHgSl{Py9?g;{T-skmx_z14u(!(vhCu$iVOXK}Ir>nJi=_8`;T0PI8f(Jme)G`S~*lEl42>Q-'
    b'q=vqc|lfNhwNGhO(5SJQb)&B`Q;es#K#oHK<7~YEy^0)T2HPXh<U((}bopqd6^TNh?~@hPJe$Jss#sCpy!Gu5_b2J?Kd<deeu#^rJrm7|0+7|0g;Z;~38bCj'
    b'PC1G4<c*Va#R@bD78dfNsV@7O|KmEM*zXS;0zHv6?lkWgY9;z{bDzJGQco?d)JDyV%Vh_WlzckW-xI3}-'
    b'pVc`gL>LoRWdD_rGTKxgCzH@U@a?r@iT+~)xgdBkI$@RVmf=LIhVx+kxB!&~0*o)3KF6QB9QSHAK6&yYWa^H1PEdj|w17{LiaNJ0@h#Q*5Fgd;o=h)5(N6NR'
    b'Y!K(znH4$N==P7fvvS;<EBf2S9d@BiU$%>P$AF@NvCJme9NdBRhk{rUWa^c+xtf)u6*MJYycN>Gwgl%@=2DMxuKP?1VhrV3T5Ms;dXlUmfK4t1$VeHze^Ml_'
    b'}gO=(7RTF{bKw5APhX-9iH(2-'
    b'7brVCx^Mt6G9lV0?u4}IxJe+Dp+K@4UHLm9?!Mlh05jAjgD8OL}gFp)`2W(rf8#&l*dlUdAW4s)5ud={{fMJ#3sOIgNpR<M#)tY!^sS;u-du#rt{W(!-'
    b'{#&&kFlU?j)4}00iehzSuLmcJ^M>)oEPH>V_oaPK?|H+Qj?SG>u^^iwA<_S-E#&cfq@}KNdeGmCBL)3o|_|HBPK?z3iQ2*DiRhYl@t-'
    b'=$5h(sbXQHaV9L?b#e_>q{zA~tb|%TN4FJmQmpge2k@5|f0aB;!|-lY*3_A~k79OFGi?+rQBV%S;xsl8x--ASb!VO&;=+kNgy%AcZJQ5sFfb;*_8yr6^4q%2'
    b'JN<{~L7BI?$0$bfybk=|*>Y(34*DrVoATNB_Td*akC%p?~SKjbJ3B0=jKu7|S@uGl7XrVlq>h$~2}kgPF`?HglNEJm#~2g)Cw*OIXS>ma~GDtYS55Sj#%rvw'
    b'@9lVl!LV$~LyMgPrVRH+$I2KK65fgB;>8M>xtcj&p*OoZ>WRILkTCbAgLo;xbpb$~CTYgPYvqHg~woJ?`^>hdkmjPk72Rp7Vm2yy7))c*{H9^MQ|i;xk|V(m'
    b'(tjP@wn+fkXe#eZ=5|AS9s(O&G!wj_^bvB9Vwp6r%D2(TGkAek3Nbh)o>g@)JK3kN6}YA&K~f#3Ugp$@rDzq#$KLXEHTuNJ~1>^BWoXoj=G(CNh(StYjlQIm'
    b'k&aa+8O=<Rd=?C`cg+Q-'
    b'q=vqc|lfNhwNGhO(5SJQb)&B`Q;es#K#oHK<7~YEy^0)T2HPXh@^~7xqKPGl7YJ>xxcg8q=A<OlC2gIm~4q^I5<`7O|KmEM*zXS;0zHvHCAP)OD<90~`PUUh'
    b'4lAz0_F5CJu4=iJyr_d=ik5MEpWxl8}^S{7Q0CkdjoS{!8CA9qIXv4E)X?WF*ty`mou^PL6<XY%X&Dr6Ze<{1l)dg(yrBic*Z?l%OP~C`}p4QjYRepdyv1Oc'
    b'kmIba1OvgPPQ$Hg%{=J?hhdhBTrvO=wCpn$v=ow4ya_XiGcV(}9k3qBC9o(*5mD4|@Iwd%%Mk!cc}WoDqy<6r&l#SjI7)2~1=Xlm8c8;=gx@7qW=OEcr{Pcs'
    b'VOr$tqT}hPA9?Jsa4_CN{H$t!!gEJJ`uCcC&}Q>|;L%ILILmbA+QD<2WZc$tg~AhO?aGJQo7G&zHE&6|QoP>)hck_qfjk9`cCCJmD$Nc+Lx6@`~5I;VtiY&j'
    b'&v8iO+oDE8qAYP>}qyhaH$81SJ^32|-'
    b'9g5t=ZBB^=?2K*WEi!yTO%{76h<5t}%~<tKh79`Q*)LK5){iAh3IlJP6aNkK|dk(xB5B^~McjST$GA7msGnaM&{vXPw}<Rlll$wOZ9kw2h^UNE4GUYH^jr5M'
    b'F2K}kwcnlhB79ObD%MJiF5DpaK!)u};EYEhdy)TJKvX+T37(U>MQr5Vj>K}%ZEnl`kh9qs8rM>^4&E_9_E-RVJ3deNIc^ravD8NfgWF_<9?Wf;R5!AM3inlX'
    b'%J9OIe5L?$trDNJP=)0x3cW-*&N%w-'
    b'<)SrD)Tu!zMhVJXX4&I(qtiq))PE$dj%1~#&Z&1_*S+t|(ycCw4z>|rna*v|nDa)`qm;V8#A&IwL(iqo9oEay1S1up*I*kO3^uk0~A<r&X;!AoB8nm4@tCwC'
    b'o!5R_m9Cj=o0Md*KJ7b3!6_8}q@g{b^MG@=uOABjmUViSkB{KU`1BR&a8NFshAF-'
    b'b^DGJYjFDM(2wQj><Xq$54Qk%8a&gN*;mzD72(lY^Y(A~$)+OFr^bfPxgFFhwXzF^W@yl9Zw}WhhHI%2R=gRHE{K)1F92I?<Ufbfp{J=|N9=(fe;ZCH)!jx8'
    b'0H<3}slrp2-MCGK$fRVJzbq&jcniiOEc1D$|(G3}!Nm+00=s^O(;97P5%NEMY0jSk4MovWnHLVJ+)e&jvQKiOp<bE8E!44tBDO-Rxm6``FI`4swXY9N{R(IL'
    b'--9a*ETO;VkDk&jl`WiOXE!D%ZHq4Q_Ia+uY$U_qfjk9`cwcJmneBdBICw@tQZh<sI+&5U>aIiO+oD>)-'
    b'Z*{y|`Z5R~AAAS9s(O&G!wj_^bvB9Vwp6r%D2(TGkAek3Nbh)o>g@)JK3kN6}YA&CO^loFGKWF#jADM>|Y(vX&Pq~|v>@H>BykxXPJ3t7oVc5;xDT;wJXdC5'
    b'n93Q&+j6s8D8DMoQhP?A!VrVM2%M|mnxkxEpi3RS80@9bawSMOZ?SM3}9NA`&7M{xUT7_bA>f-dx-Fa7Ax00uIMA^+qK&?F`^g{e$qIy0EbEM_x@xy)le3s}'
    b'e^7PEw<EMqw<Sjj3@vxc>-'
    b'V?7(#$R;+kg{^F3J3H9PE_Snrz3gK@2RO(f4s(Q~9OF1AILRqabB42=<2)C*$R#dwg{xfSIybn<EpBs%yWHbG4|vEU9`l5!JmWbpc*!eX^M<#)<2@hv$R|GY'
    b'g|B?$`=3iy5xtKPm>>it7{LiaNJ0^sFoY!>;fX**A`zJ=MCAvf5uF(PNK9f8n>fVfCw?X#@ku~J67dU(NkUSR@hizmK}u4Qnlz*(9qIXv4E)X?WF!-'
    b'r$wF4Lk)0gmBp12KLtgTcp8^!55QQm1QHoKV5|pGAr71&M%2A#QRHPD>sX|q%QJospq!zWQLtW}op9VCf5shg=Q<~A77PO=lt!YDB+R>g4bfgoV=|We!(VZU'
    b'jq!+#ELtpyQp8*VH5Q7=QP=+y_5sYLMqZz|k#xb4=Ok@(1nZi`2F`XIAWEQiT!(8Sup9L&r5sO*EQkJot6|7_xt69TZ*0G)qY-AIg*}_(~v7H_4WEZ>H!(R5'
    b'Wp937^5QjO!QI2t(6P)A}r#Zt}&T*a#T;vj$xx!Vhah)67<QBKN!(Hxip9ehT5s!JoQ=ajh7rf*ZuX)2;-'
    b'tnFfeB=|K`NCJe@tr`CoPPongrEc?I3Wm0C_)p4u!JK#5r{}6A`^wE{6I9K6N4X#Ni1R$hq(O2&%`4>2}npHejzbQNJ=t(B{?ZbNh(s4hP0$3J-?BG-'
    b'}!@#WFj+J$VxV{lY^Y(A~$)+OFr^bfPxgFFhwXzF^W@yl9Zw}WhhHI%2R=gRH8Cfs7f`eQ-hk+qBeD?OFin-fQB@pF-'
    b'>SnGn&(amb9WZZD>n7+S7rKbfPm|=t?)b(}SM$qBni$OF#NEfPoBRFhdy1ForXNk&I$AV;IXg#xsG5Oky%qn94M!GlQATVm5P_%RJ_@fQ2k#F-'
    b'us=GM2M~m8@blYgo%V*0X_)Y+^H8*vdAxvxA-NVmEu(%RcsVfP)<3Fh@AbF^+SBlbqr-XE@6_&U1l_T;eiUxXLxIbAy}Q;x>1<%RTP%fQLNdF;95PGoJH;m%'
    b'QRNZ+Oc)-t&QveBv`-_{ulF6DYFtPhf%&lwbrW1R)7UXu=SdaD*oU5s5@(q7aoIh(>f`@FOvaMQq{_m!J5Vc*G|G2}#5+Bqj+-'
    b'Nye`vCj}`<MQYNJmUN`&H!|=$e~^((WF`w)$wqc^kds{GCJ%YZM}7)WkU|uu2t_GIaY|5<Qk13)WhqB_Do~M1RHh15sYZ2bP?K8JrVe$fM|~R5kVZ772~BB6'
    b'b6U`nR<x!KZD~h)I?$0$bfybk=|*>Y(34*DrVoATM}Gz|kU<P)2tygha7HkaQH*8`V;RSICNPmnOlAsGnZ|TxFq2u#W)5?i$9xvBkVPzJ2}@bVa#paCRjg(W'
    b'Ygxy7Hn5RRY-'
    b'S5v*~WHuu#;WvW)FMW$9@iQkV72i2uC@_aZYfOQ=H}uXF11tE^v`cT;>W_xyE&FaFbiy<_>qc$9*2~kVib`2~T;(b6)V0SG?v8Z+XXiKJbxGeC7*Z`NsFi|8'
    b'h}<e-M};1SJ^32|-9g5t=ZBB^=?2Ktv)DnJ7f%2ci+382m^~ViB7-'
    b'#N{V`CLZxgKtdAn3yDcWQj+m2$w@&<QjwZ8q$M5c`Hc+x&L3nX6Pd|ER<e<u9ONVyxyeIb@{ykc6r>P^DMC?-'
    b'QJfN#q!gtoLs`mEo(fc?5|yb!RjN^)8q}l~wW&j0>QSEtG^7!YX+l$)(VP~vq!q1cLtEO>o(^=R6P@WoSGv)i9`vLaz3D?=`q7^O3}g_48NyJ8F`N;MWE7(r'
    b'!&t^Ko(W835|f$2RHiYV8O&rBvzfzO<}sfIEMyUjS;A75v78mGWEHDf!&=s}fsJfpGh5ioHny{ao$O*ad)Ui9_H%%P9O5uXILa}ObAnTx<_u>!$9XPrkxN|W'
    b'3Rk(tb#8EzTioUjce%%X9`KMyJmv{cdB$^I@QT;G;VtiY&j&v8iO+oDE8qAYa1oV%5SSnYB^bd8K}bRonlOYV9N~#TL?RKHC`9E4q7j`K{76h<5t}%~<tKh7'
    b'9`Q*)LK5){iAh3Il97^Bq$Uk%Nk@8qBLlzl2N}skX0ni#Y-A?~ImtzC@{pH&<fi}yDMVq4P?Ta6rvxP_MQO@VmU5J*0u`x5WvWn>YE-'
    b'8NHK|2y>QI+@)TaRrX+&e1(3EC0rv)u(MQhs7mUgtK10Cr^XS&dpZgi&yJ?TYn`p}nt^k)DA8N^_QFqB~oX9Ob|#c0MbmT`<{0u!0UWTr5cX-sDZGnvI~<}j'
    b'Ce%x3`$S;S(Nu#{yiX9X)+#cI~DmUXOW0~^`IX11`EZER-'
    b';JK4o<_OO?I?B@UnImBU(aFk;l=L9D?#c9rPmUEov0vEZ&Wv+0QYh33BH@U@a?r@iT+~)xgdBkI$@RVmf=LIi$#cSU1mUq1810VUsXTI>2Z+s89Xwp9jOb~('
    b'+jNpVIB%ugR7{U^c@I)XYk%&wbqVfaLh)xWCBqp(lO&sF#6F(D=_#_}9iTH)YBq1ru_?6_OASJ0tO&ZdYj`aLS27c!cGLnhRWFafr$W9J&l8fBrAusvJPXP*'
    b'2h{6=1D8(pF2})9m(v+br<tR@DDpHBcRG})>s7?)PQj6Nup)U2PPXij#h{iObDa~k33tG~O*0iB5?PyO2I?{>GbfGKV=uQuM(u>~op)dXD&j1E8h`|hDD8m@'
    b'e2u3oB(Trg%;~38bCNhc1Okpb1n9dAlGK<;FVJ`ES&jJ>*h{Y^nDa%;S3Rbd;)vRGH>sZeQHnNG$Y+)<g*v<}ivWwm9VK4jG&jAi{h{GJ=D91R?2~Ki~)12W'
    b'f=Qz&=E^>*>T;VF$xXul3a*NyC;V$>M&jTLvh{rtPDbIM$3tsYy*Sz5^?|9D#KJtmreBmqK_#SY<w0{toAOs~C!3jY~LJ^uUge4r|i9kdm5t%4N<p-'
    b'h>of!N`Okxq6IK<^AekLCANkBpp@e7GbLQ<0PE6GVgN>Y)UG^8aR>G_Qe{LUX_Bomp*LRPYoogCyO7rDtpUh<Kj0u-'
    b'bWg(*T&icy>rl%y1;DMMMxQJxA^q!N{>LRG3!of_1n7PYBEUFuPv1~jA*jcGztn$esVw4@cSX+vAu(Vh-'
    b';q!XR#LRY%cogVb07rp62U;5FX0SsgigBik5hB2HGjARs}8N*n{F`fxbWD=8^!c?X)of*tz7PFbdT;?&K1uSF{i&?@_ma&`_tYj6dS;Jb^v7QZVWD}d&!dAA'
    b'iogM6C7rWWRUiPt{103WKhdIJgj&Yn5oa7XzIm21bah?lY<Pw*;!d0$uog3Wb7Pq;>UG8z82R!5vk9opVp7ER)yyO+HdBa=Y@tzNS<P)Fy!dJfWJ>X)A{~$0'
    b'y{tx!<G1#)S?-O)BY1_`qtV*-eW~FW0wr$(CZQHhO+nTH5&55pgqPwTxj-Kd=m^l&Ghx2W%z4yKLI=|oltee0DAt=EJP6$F0iqM21Ea3=G1R@fN$V4G3(TGk'
    b'AViJqk#33&6h))83BO!_Soj*uS5|WaP<fI@asYp#4(vprpNlykcl8MY@AuHL)P7ZRCi`?WPFZsw%0sf*Og(yrBic*Z?l%OP~C`}p4QjYRepdyv1Ockn9jq22'
    b'(Cbg(d9qLk#`ZS;+jc800n$nEsw4f!eXiXd1(vJ3Ypd+2=Oc%P+jqdcIC%x!RANtad{tRFsgBZ*ZhBA!dj9?_A7|j^QGLG>~U?P*4%oL_Fjp@u_CbO8$9Og2'
    b'Q`7B@|i&)GOma>fHtY9UpSj`&NvX1p^U?ZE@%oet?jqU7UC%f3q9`>@2{T$#Rhd9g;j&h9SoZuv<IL#T(a*p#{;3Ai}%oVP3jqBXtCbziF9qw|E`#j(wk9f='
    b'zp7M<6yx=9Tc+DH$@{ad>;3J>-%oo1$jqm*6=dTB){)>PFA}~P+N-%;Gf{=tFG+_u!IKmTwh(sbXQHV-3q7#Fd#3D9vh)X=;lYrkyNFsjc4-'
    b'%7vq$DFbDM(2wQj><Xq~lN0lYxw6A~RXYN;a~SgPi0dH+jfQKJrt5zbHr{3R8rl6r(sLC`l<wQ--pXqdXO;NF^#$g{oAeIyI<CEoxJTy40gS4QNOs8q<WPG^'
    b'05!Xh|zt(}uRRqdgtyNGCeeg|2j?J3Z)0FM895zVxF%0~p941~Y`A3}ZMW7|AF`GlsE@V>}a>$Rs8+g{e$qIy0EbEM_x@xy)le3s}e^7PEw<EMqw<Sjj3@vx'
    b'c>-'
    b'V?7(#$R;+kg{^F3J3H9PE_Snrz3gK@2RO(f4s(Q~9OF1AILRqabB42=<2)C*$R#dwg{xfSIybn<EpBs%yWHbG4|vEU9`l5!JmWbpc*!eX^M<#)<2@hv$R|GY'
    b'g|B?$$KPu`hP6%*f)b42gdilL2u&Em5|wB~Ck8QzMQq{_mw3b{0l$%uMEuSlBqj+-Nk(!~kdjoSCJkvx$DgDp0~yIgX0ni#Y-'
    b'A?~ImtzC@{pH&<fj0CQIJ9urU*qTMsZ3|l2VkW3}q=tc`8tmN>ru_RjEdGYEY9})TRz~sYiVp(2zznrU^}HMsr%wl2){)4Q**hdpgjOPIRUVUFk-'
    b'5deD<z^rk-p7|0NYGK}GjU?ig$%^1cqj`2)jB9oZR6s9tb>C9jzvzW~s<}#1@EMOsvSj-ZZvW(@dU?r<q%^KFSj`eI{Bb(UF7PhjD?d)V1yV=8D_OYJ>9OMv'
    b'(Il@tnahwyJ<P@hl!&%O8o(o*$5|_EcRjzTJ8{Fg;x4FYz?s1<7Jme9NdBRhk@thaD<Q1=Z!&~0*o)3KF6QB9QSHAI`AN>6FVDo<wkU#_`2tf%(a6%B0P=qE'
    b'7VF^cgA`p>CL?#MRiAHo{5R+KMCJu3lM|=|S8wp9o@BBexl8}^SBqs$aNkwYXkd}1(NqRDnkxXPJ3t7oVc5;xDT;wJXdC5n93h);NDMVq4P?Ta6rvxP_MQO@'
    b'VmU5J*0u`x5WvWn>YE-'
    b'8NHK|2y>QI+@)TaRrX+&e1(3EC0rv)u(MQhs7mUgtK10Cr^XS&dpZgi&yJ?TYn`p}nt^k)DA8N^_QFqB~oX9Ob|#c0MbmT`<{0u!0UWTr5cX-sDZGnvI~<}j'
    b'D}EMO7KS;0zHv6?lkWgY9;z(zK)nJsK(8{65z5l(QDQ=H}uXF11tE^v`cT;>W_xyE&FaFbiy<_>qc$9*2~kVib`2~T;(b6)V0SG?v8Z+XXiKJbz6{NU%W4F~'
    b'>3Kmrk%AOs~C!3jY~LJ^uUge4r|i9kdm5t%4NB^uF*K};6Kc8z5l+u6ZRcCnj1>}4POIlw^<ahM|<<rv2~!AVYWnlqf`9Ot>fMLrNEj$<Mk(TPD!ViB7-'
    b'#3df_Nx=2Et{3sFdD4@CjASA+*~m^_@{ykc6ru>lC{77VQi{@)p)BPnPX#JciON)=D%Ge?4Qf)0+SH*g^{7t+8q$cyG@&WYXif`S(u&r!p)KubPX{{EiOzJP'
    b'E8XZ$4|>vz-'
    b't?g_{pimC1~Q1j3}Gn47|sYrGK$fRVJzbq&jcniiOEc1D$|(G3}!Nm+00=s^O(;97P5%NEMY0jSk4MovWnHLVJ+)e&jvQKiOp<bE8E!44tBDO-'
    b'Rxm6``FI`4swXY9N{R(IL--9a*ETO;VkDk&jl`WiOXE!D%ZHq4Q_Ia+uY$U_qfjk9`cCCJmD$Nc+Lx6@`~5I;VtiY&j&v8iO+oDE8qCe4}SjIh~!@cBoKiKL'
    b'QsMcoDhU06rl-'
    b'2Si%vW2t*_jk%>Z7q7j`K#3UB6i9=lC5uXJ7MnV$tJAaUvBqSvn$w@&<QjwZ8q$M4HlAa7?Bomp*LRPYoogCyO7rDtpUh<Kj0{lfm3Q?FM6r~u&DM3j}QJON'
    b'8r5xp{Kt(E1nJQGJ8r7*mO=?k_I@F~e^=Uvu8qt_0G^H8MX+cX`(V8~2r5)|*Ku0>!nJ#pt8{O$aPkPatKJ=v@{TaYO1~Hf+3}qO@8No<KF`6-'
    b'qWgO#~z(gi7nJG+V8q=A<OlC2gIm~4q^I5<`7O|KmEM*zXS;0zHv6?lkWgY9;z(zK)nJsK(8{65zPIj@IJ?v#4`#Hct4sn<x9OW3tIl)Ozahfxn<s9d^z(p='
    b'`nJZl78rQkOO>S|UJKW_S_j$lW9`TqbJmneBdBICw@tQZh<sI+&z(+punJ;|h8{hfC&tIDm{fmGEA}~P+N-%;Gf{=tFG+_u!IKmTwh(sbXQHV-'
    b'3q7#Fd#3D9vh)X=;lYrkyNFsjc4-%7vq$DFbDM(2wQj><Xq~lN0lYxw6A~RXYN;a~SgPi0dH+jfQKJrt5zbHr{3R8rl6r(sLC`l<wQ--pXqdXO;NF^#$g{oA'
    b'eIyI<CEoxJTy40gS4QNOs8q<WPG^05!Xh|zt(}uRRqdgtyNGCeeg|2j?J3Z)0FM895zVxF%0~p941~Y`A3}ZMW7|AF`GlsE@V>}a>$Rs8+g{e$qIy0EbEM_x'
    b'@xy)le3s}e^7PEw<EMqw<Sjj3@vxc>-'
    b'V?7(#$R;+kg{^F3J3H9PE_Snrz3gK@2RO(f4s(Q~9OF1AILRqabB42=<2)C*$R#dwg{xfSIybn<EpBs%yWHbG4|vEU9`l5!JmWbpc*!eX^M<#)<2@hv$R|GY'
    b'g|B?$J3sjOYXh=>5s*LxCI~?ZMsPw9l2C*u3}FdJcp?yyNJJ(IQHe%$Vi1#9#3l}LiAQ`A@EZw9#P9q;Vv>-'
    b'QWF#jADM>|Y(vX&P{7HH;kdaJeCJR}~Ms{+LlU(E`4|&N)ehTmx1t~;ficpkd6sH6wDMe|@P?mC(rveqJL}jW_m1<O{1~sWgZR${$deo-'
    b'@4QWJUn$VPHG^YhEX+>+=(3W<zrvn}7L}$9tm2PyW2R-RUZ~D-'
    b'ee)MMm0~y3%hA@<23}*x*8O3PEFqUzQX95$M#AK#0m1#_81~Zw(Z00bRdCX@43t7Zsmavp%EN2BPS;cDBu$FbKX9FAA#Addzm2GTi2RqrtZuYR3eeCA|2RX!'
    b'Hj&PJ?9OnclImKztaF%nN=K>eG#AU8<m1|t*1~<9IZSHWFd)(&%4|&96p74}sJm&>3dBtnq@RoPH=K~-'
    b'4#Am+nm2Z6K2S0ypKKL&J5{SSAAt=EJP6$F0iqM21Ea3=G1R@fN$V4G3(TGkAViJqk#33&6h))83BO!_Soj*uS5|WaP<fI@asYp#4(vprpNlykcl8MY@AuHL'
    b')P7ZRCi`?WPFZsw%0sf*Og(yrBic*Z?l%OP~C`}p4QjYRepdyv1Ockn9jq22(Cbg(d9qLk#`ZS;+jc800n$nEsw4f!eXiXd1(vJ3Ypd+2=Oc%P+jqdcIC%x!'
    b'RANtad{tRFsgBZ*ZhBA!dj9?_A7|j^QGLG>~U?P*4%oL_Fjp@u_CbO8$9Og2Q`7B@|i&)GOma>fHtY9UpSj`&NvX1p^U?ZE@%oet?jqU7UC%f3q9`>@2{T$#'
    b'Rhd9g;j&h9SoZuv<IL#T(a*p#{;3Ai}%oVP3jqBXtCbziF9qw|E`#j(wk9f=zp7M<6yx=9Tc+DH$@{ad>;3J>-'
    b'%oo1$jqm*6=dX=N|3yFo5ttwZB^bd8K}bRonlOYV9N~#TL?RKHC`2V1(TPD!ViB7-#3df_Nx*L;BoV*!2Z>2SQj(FJ6r>~-'
    b'sYydx((xzh$v{Rjk(n%HB^%kvK~8d!n>^$tANeW3UlgPeg(*T&icy>rl%y1;DMMMxQJxA^q!N{>LRG3!of_1n7PYBEUFuPv1~jA*jcGztn$esVw4@cSX+vAu'
    b'(Vh-'
    b';q!XR#LRY%cogVb07rp62U;5FX0SsgigBik5hB2HGjARs}8N*n{F`fxbWD=8^!c?X)of*tz7PFbdT;?&K1uSF{i&?@_ma&`_tYj6dS;Jb^v7QZVWD}d&!dAA'
    b'iogM6C7rWWRUiPt{103WKhdIJgj&Yn5oa7XzIm21bah?lY<Pw*;!d0$uog3Wb7Pq;>UG8z82R!5vk9opVp7ER)yyO+HdBa=Y@tzNS<P)Fy!dJfWoge)CwdwG'
    b'`2uL6T6NI1yBRC-lNhm@ShOmSqJQ0XUBq9@qs6-<=F^EYlViSkB#3Mcl_>F`l;&=WaF-b^DGLn;ml%ygxX-'
    b'G>t{v<sa$VetKlZC8gBRe_BNiK4ehkO*GFhwXzF^W@yl9Zw}WhhHks!^R9)T9=*sY6}rQJ)4hq!Ep2LQ|U2oEEgC6|HGQTiVf{4s@gwo#{eXy3w5;^rRQP=|'
    b'f-'
    b'o(VqbfWDtWH!cc}WoDqy<6r&l#SjI7)2~1=XlbOO)rZJrv%w!g`nZsP>F`or2WD$#5!cvy8oE5BO6{}gpTGp|i4Qyl+o7uuvwy~WZ>|_`FIKUwebA+QD<2WZ'
    b'c$tg~AhO?aGJQujgB`$M?t6bwcH@L|yZgYpb+~YnEc*r9j^Mt27<2f&Q$tzy-hPS-qJs<eUCqDCquYBVNKYwi${x1R&h`<CPD8UF$2tpEy(1al@;RsIzA`*$'
    b'nL?J5Ch)xV*5{uZxAujQVPXc};A&K~%KS)dxl9G(%q#z}!NKG2jl8!$~PX;oQiOggnE7{0S4sw!<+~grI`N&TJ{-Pj-'
    b'C`=KGQjFr1pd_UzO&Q8kj`CEXB9*926{=E=>eQenwWv)U>QayTG@v1kXiO8D(v0S`pe3znO&i+Mj`nn*Bc13>7rN4o?)0E1z35FJ`qGd73}7IG7|alcGK}Gj'
    b'U?ig$%^1cqj`2)jB9oZR6s9tb>C9jzvzW~s<}#1@EMOsvSj-ZZvW(@dU?r<q%^KFSj`eI{Bb(UF7PhjD?d)JDyV%Vh_Og%t9N-'
    b'{_ILr}_a*X4g;3TIw%^A*ej`LjLBA2+#6|QoP>)hZbx46w6?sAX&JmWbpc*!eX^M<#)<2@hv$R|GYg|B?$J3szjtBI{u!V`grL?SX#h)Oh~6N8w<A~tb|OFZ'
    b'I}fZs?+B7Wx&5|f0aBqKQ~NJ%PElZLdU<4@9)fsAA)2RX?_Zt{?qeB`G9e^HP^6s8D8DMoQhP?A!VrVM2%M|mnxkxEpi3RS5_b!t$PTGXZvb*V>v8qknNG^P'
    b'nnX-0Ee(2`cPrVVXrM|(QZkxq1`3tj0(cY4s1Ui799ed$Mk1~8C83}y&J8OCr%Fp^P>W(;E)$9N_%kx5Ku3R9WJbY?J<S<Ge*bD76{7O;>-'
    b'EM^HyS;lf!u##1*W({ju$9gufkxgu73tQR7c6P9nUF>ELd)dc+4seh|9Oei|ImU5LaFSD;<_u>!$9XPrkxN|W3Rk(tb#8EzTioUjce%%X9`KMyJmv{cdB$^I'
    b'@RC=&<_&Lo$9q2TkxzW)3t#!hcYg4b07-l=6OcdzCI~?ZMsPw9l2C*u3}FdJcp?yyNJJ(IQHe%$Vi1#9#3l}LiAQ`A@EZw9#P9q;Vv>-'
    b'QWF#jADM>|Y(vX&P{7HH;kdaJeCJR}~Ms{+LlU(E`4|&N)ehTmx1t~;ficpkd6sH6wDMe|@P?mC(rveqJL}jW_m1<O{1~sWgZR${$deo-'
    b'@4QWJUn$VPHG^YhEX+>+=(3W<zrvn}7L}$9tm2PyW2R-RUZ~D-'
    b'ee)MMm0~y3%hA@<23}*x*8O3PEFqUzQX95$M#AK#0m1#_81~Zw(Z00bRdCX@43t7Zsmavp%EN2BPS;cDBu$FbKX9FAA#Addzm2GTi2RqrtZuYR3eeCA|2RX!'
    b'Hj&PJ?9OnclImKztaF%nN=K>eG#AU8<m1|t*1~<9IZSHWFd)(&%4|&96p74}sJm&>3dBtnq@RoPH=K~-'
    b'4#Am+nm2Z6K2R{jr)cPkNfe1_xf)b42gdilL2u&Em5{~dhAR>{7OcbILjp)Q6Cb5W39O4p>_$1&r5|W7D`GdqHAt}j7P6|?ziqxbbE$R4^^kg6-'
    b'naE5QvXYJL<RB-'
    b'x$W0#dl8^ip;4cbNh{6=1D8(pF2})9m(v+br<tR@DDpHBcRG})>s7?)PQj6Nup)U2PPXij#h{iObDa~k33tG~O*0iB5?PyO2I?{>GbfGKV=uQuM(u>~op)dX'
    b'D&j1E8h`|hDD8m@e2u3oB(Trg%;~38bCNhc1Okpb1n9dAlGK<;FVJ`ES&jJ>*h{Y^nDa%;S3Rbd;)vRGH>sZeQHnNG$Y+)<g*v<}ivWwm9VK4jG&jAi{h{GJ'
    b'=D91R?2~Ki~)12Wf=Qz&=E^>*>T;VF$xXul3a*NyC;V$>M&jTLvh{rtPDbIM$3tsYy*Sz5^?|9D#KJtmreBmqK_|6Z05+IrNPe1|@m>>it7{LiaNJ0^sFoY!'
    b'>;fX**A`zJ=L?s&0i9t+a5t}%~B_8ofz;7fZ5x?^XiAh3Il98Mgq$CxoNkdxF@h9oYKt?i=nJi=_8`;T0PI8f(Jme)G`6<9(6r>P^DMC?-'
    b'QJfN#q!gtoLs`mEo(fc?5|yb!RjN^)8q}l~wW&j0>QSEtG^7!YX+l$)(VP~vq!q1cLtEO>o(^=R6P@WoSGv)i9`vLaz3D?=`q7^O3}g_48NyJ8F`N;MWE7(r'
    b'!&t^Ko(W835|f$2RHiYV8O&rBvzfzO<}sfIEMyUjS;A75v78mGWEHDf!&=s{o(*hd6Pww>R<^O79qeQmyV=8D_OYJ>9OMv(Il@tnahwyJ<P@hl!&%O8o(o*$'
    b'5|_EcRjzTJ8{Fg;x4FYz?s1<7Jme9NdBRhk@thaD<Q1=Z!&~0*o)3KF6QB9QSHAI`AN(Xha_gUf1R^j&2ud)56M~S0A~azLOE|(4frvyRGEs<1G@=uOn8YGB'
    b'afnMi;*)^iNJt`n=MNH-grp=RIVng<DpHe%w4~!t(vyLVWFj+J$VxV{lY^Y(A~$)+OFr^bfWIh6AqrE3q7<VzB`8TLN>hfil%qTqs7NI$Q-'
    b'!KjqdGOHNiAwqhq~0GJ`HF{BO23$rZl5DEoezATGNKMw4*&8=tw6z(}k{dqdPt5NiTZShraZqKLZ%ZAO<spp$ua<BN)jjMl*)7jAJ|#n8+k1Gli*4V>&aK$t'
    b'-3whq=sSJ_}gLA{MiRr7UAPD_F@YR<nk+tYbYJ*vKX}vxTi}V>>(8$u4%YhrR4$KL<F-'
    b'Ar5ndqa5QnCpgI|PIHE{oZ~zfxX2|gbA_v1<2pCE$t`Ykhr8V4J`Z@vBOddFr#$01FL=o-Uh{^xyyHC|_{b+d^M$W`<2yh2Nq`jAKLH6uV1f{oU<4-'
    b'wAqhoj!Vs2lgeL+Ki9}?g5S3^|Ck8QzMQq{_mw3b{0l$%uMEuSlBqj+-Nk(!~kdjoSCJkvx$DgDp0~yIgX0ni#Y-'
    b'A?~ImtzC@{pH&<fj0CQIJ9urU*qTMsZ3|l2VkW3}q=tc`8tmN>ru_RjEdGYEY9})TRz~sYiVp(2zznrU^}HMsr%wl2){)4Q**hdpgjOPIRUVUFk-'
    b'5deD<z^rjDe=|_JCFpxnEW(Y$W#&AY3l2MFi3}YF`cqTBBNla!6Q<=teW-yak%w`UAna6w<u#iP8W(iAK#&TA$l2xo`4QpA)dN#0;O>AZhTiM2TcCeFO>}C&'
    b'p*~fkkaF9bB<_JeQ#&J$?l2e@K3}-pVc`k5~OI+p(SGmS@Zg7)Z+~y8<xyOAT@Q_D5<_S-E#&cfql2^Ru4R3kJdp_`yPkiPJU-'
    b'`y&e(;k3DXo735{SSAAt=EJP6$F0iqM21Ea3=G1R@fN$V4G3(TGkAViJqk#33&6h))83BO!_Soj*uS5|WaP<fI@asYp#4(vprpNlykcl8MY@AuHL)P7ZRCi`'
    b'?WPFZsw%0sf*Og(yrBic*Z?l%OP~C`}p4QjYRepdyv1Ockn9jq22(Cbg(d9qLk#`ZS;+jc800n$nEsw4f!eXiXd1(vJ3Ypd+2=Oc%P+jqdcIC%x!RANtad{t'
    b'RFsgBZ*ZhBA!dj9?_A7|j^QGLG>~U?P*4%oL_Fjp@u_CbO8$9Og2Q`7B@|i&)GOma>fHtY9UpSj`&NvX1p^U?ZE@%oet?jqU7UC%f3q9`>@2{T$#Rhd9g;j&'
    b'h9SoZuv<IL#T(a*p#{;3Ai}%oVP3jqBXtCbziF9qw|E`#j(wk9f=zp7M<6yx=9Tc+DH$@{ad>;3J>-%oo1$jqm*6CjnAf{{$oufeAuTf)Sh$gd`N92}4-'
    b'I5uOM{BodK{LR6v=ofyO<7O{y#T;dU*1pG!q67f5KkeDPSB^k*{K}u4Qnlz*(9e<LZ3}hq|naM&{vXPw}<Rlll$wOZ9k)HzmML`Ntm?9LV7{w_;NlH<gGL)q'
    b'p<*7hLDp8p#RHYi#sX<L@QJXr{r5^QZKtmeQm?ku(8O>=yOIp#IHngQ3?dd>AI?<Ufbfp{J=|N9=(VIT>r62tnz(58um>~>h7{eLCNJcT5F^pv#<C(xjCNY^'
    b'QOl2C=nZZnEF`GHeWghccz(N+Wm?bP_8OvG0N>;I&HLPVF>)F6YHnEv4Y-'
    b'JnU*}+bBv70^YWgq)Fz(Edim?IqJ7{@umNltN^Go0ld=efW|E^(PFT;&?qxxr0tahp5b<sSEWz(XGKm?u2t8P9paOJ4DsH@xK?@A<$-'
    b'KJl3^eB~S8`N2;Dq_+MENFV|egrEc?I3Wm0C_)p4u!JK#5r{}6A`^wEL?b#eh)FDB6Nk9OBR&cEjf5oPcm5zTNk~dEl9Pgzq#`wGNJ~2YBt03(NG39qg{)*F'
    b'J2}WnE^?EHyyPQ41^A1C6rwOiC`vJkQ-'
    b'YF|qBLbFOF7C@fr?b3GF7NbHL6pCn$)5;b*M`{>eGORG@>z0Xi77h(}I??qBU)3OFP=rfsS;dGhOIPH@ee<p7f$OedtR+`ZIum3}P@t7|Jk)GlG$fVl-nI%Q'
    b'(g}fr(6FGE<n!G^R6ynapA~bC}CK=Cgo>EMhTBSjsY%vx1eZVl``6%R1JxfsJfpGh5ioHny{ao$O*ad)Ui9_H%%P9O5uXILa}ObApqc;xuPC%Q?<-'
    b'fs0(?GFQ0DHLi1mo800yceu+v?(=|$JmN7=c*--L^MaSW;x%u0%RAolfscIRGhg`1H@@?Op9Dx_{S%Nt1SSYU2}W>25Ry=YCJbQ-M|dI-kw`=)3Q>thbYc*b'
    b'Si~j{afwHK67U-'
    b'dNyP8`L1L1Slw>3)1u02IYSNIFbo@zrGLVr>WF`w)$wqc^kds{GCJ%YZM}7+M7X>LqVTw?cViczYB`HN|%21Yal&1m}sYGR}P?c&_rv^2tMQ!R(mwMEv0S#$'
    b'HW17&EW;CY-Eont-'
    b'+R&DEw5J0d=|pF`(3Ng<rw2XhMQ{4hmwxnT00SAsV1_W1VGL&kBN@eL#xRy~jAsH9nZ#tKFqLUcX9hEw#cbv<mwC)*0Sj5gVwSL!Wh`d}D_O;A*07d!tY-'
    b'ro*~DhHu$66WX9qjk#cuYnmwoK#00%k5VUBQ=V;tuMCppDw&Ty7<oaX`;xx{6zaFuIZ=LR>q#cl3zmwVjj0S|e^W1jGoXFTTxFL}jl-td-pyypWS`NU_w@Re'
    b'_T=LbItkk<MqAb|)>5P}kn;DjI~p$JVF!V-?~L?9xOh)fis5{>A@ASSVhO&sD9kN70uHxiPF-'
    b'}!^YBq1ruNKOh;l8V%%AuZ|nlk{XDBbmrd7P69!?BpOPxyVf(@{*7I6yPrkQi#G7p(w>DP6<j<iqe#!EafOq1u9aB%2c5$)u>JlYEp~Z)S)i*s80hL(ul@1p'
    b'()L1P77Mniq^EDE$wJe2RhP;&UB$G-RMpadeV#D^r0{P=+6KKGKj$pVJO2G&Im>_iqVW=EaMo@1ST?x$xLA?)0oZ-W-'
    b'^P}%waC`n9l+hvWUejVJXX4&I(qtiq))PE$dj%1~#&Z&1_*S+t|(ycCw4z>|rna*v|nDa)`qm;V8#A&IwL(iqo9=`*TsCY@wi*RPmaH>esGk-'
    b'39iU^m}@;kd<r{qXZ=>MQO@XmsYf4A&Xed5|*-z<*Z;Ot69r>HnEv4Y-'
    b'JnU+07vibDA@p<s9d^z(p=`nJZl78n?N_eO~g4*Sz5^?|9D#KJtmreBmqK_|6Z067XNHF$5+EK?z21LJ*QrgeDAO2}gJ$5RphkCJIrBMjrA~kU|uu0+pyt6{'
    b'=E=>NKVe?U>6v=Cgo>EMhTBSjuu%vYNH5V?7(#$R;+kgQFbdI43yCDNb{Svz+5R7r4Y_uJM3}JmN7=c*--'
    b'L^MaSW;x%u0%RAolfiHaJ8{hfC&wu^>;=9fhkU#_`2tf%(a6%B0P=qE7VF^bBA`+P>q$CY#$xK$Vk(~-'
    b'uWFUhW%n*h$jNy!6B%>J1IL0%9$;@O9bD767ma~$>9N{R(IL--9a*ESj;3Ai}%oVP3jqBXtCbziF9qw|E`#j(wk9f=zp7M<6yx=9Tc+DH$@{ad>;3J>-'
    b'%D2B?zd&9)q7s|9#3Mcl$V?U*(U>MQr5Vj>K}%ZEns&6O10Cr~ANn$wA<ShS^I5<`7O|KmEM+CDSj`&NvX1p^U?ZE@%oet?jqU7UC%f3q9`>@2{T$#Rhd9g;'
    b'j&h9SoZuv<IL$fEbBTYseugC+;YmVLl98Mgq$CxoNkdxF{e9hK9OIe5L?$trDNJP=)0x2><}!~3EMyUjS;9(Iv6uav<P@hl!&%O8o(o*$5|_EcH=+db-'
    b'jjgeNJt`n=MNH-grp=RIVng<DpHe%w4~!t(vyLVWFj+J$VxV{lY^Y(CJ%YZM}7+M7ey&XaY|5<Qk0=A<tR@DDpHBcRG})>s7?)PQj6Nup)U2PPXij#h{iObD'
    b'a~k33tG~O*0iB5?PyO2I?{>GbfGKV=uQuM(u>~op)dXD&j1E8h`|hDD8m@e2u3oB(Trg%;~38bCNhc1Okpb1n9dAlGK<;FVJ`ES&jJ>*h{Y^nDa%;S3Rbd;W'
    b'1Qe5r?|jRLc7TbLs$}$h(Ab75|WaP<fI@asYp#4hB2HGjARs}8N*n{F`g+*Wg0V>$t-'
    b'3whed2*E8950K@M@4BOK)z$2q}CPH~#c+~f_Rf;lgu5uF&sBo?uWLtNq!p9K6yLK5*ie~_3YBqbTiNkK|dk(xB5B^`f~o{VH7Gg-'
    b'(=Hgc1PyyPQ41t>@%3R8rl6r(sLC`l<wQ--pXqdXO;NF^#$g{oAeIyI<CEoxJTy40gS4QNOs8q<WPG^05!Xh|zt(}uRRqdgtyNGCeeg|2j?J3Z)0FM895zVx'
    b'F%0~p941~Y`A3}ZMW7|AF`GlsE@V>}a>$Rs8+g{e$qIy0EbEM_x@xy)leJJ`i;_HdXt1PboHh9CqZIC;p+1uk-'
    b'l%Ut0q*SO9NZgPv;+~FSgdB8&+@rJj&<2@hv$R|GYg|B?$J3szDmJp7G5QHQ&VaP}(GLwa@RH8Cfs7f`eQ-hk+qBeD?OFin-fQB@pF-'
    b'>SnGn&(amb9WZZD>n7+S7rK3}P@t7{N%!@|_<93h6Z_2&rjGGn&(amb9WZZD>n7+S7rKbfPm|=t?)b(}SM$qBni$OF#NEfPoBRFhdy1ForXNk&I$AV;IXg#x'
    b'sE_Ol2DDSkD%=vW@NRU?;oS%^vo$kNq6rAcr{25sq?<<DB3mr#Q_S&T@|PT;L*?xXcx<a*gZU;3l`Y%^mJ?kNZ5}A&+>>6Q1&n=e*!0uXxQH-tvz3eBdLW_{'
    b'<l+@{RBO;3ok>xd$U4fe1_xf)b42gdilL2u&Em5{~dhAR>{7OcbILjp)Q6CTU4WHnNk0JmjYUHRw(c`p}nt^k)DA8N^_QFpcTVU?#Je%^c=3kNGTMA&Xef3N'
    b'HVB-k}{k5s5@(q7aor6k#z}xXLxIbAy}Q;x>1<%RTP%fQLNh2~T;(2R`zN&wSx4-'
    b'}ufCei9&zV<RA;2u&Em5}pWTB^%kvK{cvVgPPQ$Hg%{=J?hhdhBTrvO=wCpn$v=ow4ya_XiGcV(}9k3q96Skz+i?jl#zVq2R{iA*7r6wsYPw-'
    b'P?vhtrvVLVL}QxJlx8%i1ubbsYueD3cC@Dh9qB}8y3mzwbf*VB=|yk)(3gJnX8;2k#9)Rqf{`p_5zAS@N>;I&HLPVF>)F6YHnEv4Y-'
    b'JnU*}+bBv70^YWgq)Fz(Edim?IqJ7{@umNltN^Go0ld=efW|E^(PFT;&?qxxr0tahp5b<sSEWz(XGKm?u2t8P9paOJ4DsH@xK?@A<$-'
    b'KJl3^eB~S8`N2;Dg!36EAb|)>5P}kn;DjI~p$JVF5|W6Nq~=db(Snw=r5)|*Ku0>!nJ#o?I3pOzC`L1ev5aFp6PU;(CR40r{sezVEcx@4%M&2LKXbsmE$emu'
    b'kNN(;e}2U<0sLtjz*lL2UzgYbzm|1?U#A}6*VfVjer-'
    b'1y;McZO0e)>`@%Q8M1H>i{aryOF>;S(Wj~U?CW3mGLdhAAkU;pMC;Mc$V1o$=f8{pUYPk>)F;NMk1fOG-=OJ<poOl1C*U1lc-ImtzC{yyQn<oo;lDZpP8q!5'
    b'KELeXEjXYv0^_F3jv{#lOlRG=c2s7w{AQjI#)qdpC2NFy54gr+p3IW7K?Z~l9>d7T^F<kmm3&b!?Em3cl0@E@6BEoxJThBW$>AvU2IEoezATGN*Hbf6=h=u8'
    b'*7(v9x)peMcPO&|KwkNyl`AcGjp5QZ|0;f!D;qZrK?#xjoaOkg6Dn9LNWGL7lXU?#Je&7A+iJapNwOmxMsTy)j1Y;?{4O+LDXt!!iaue@|8yV%Vh_Og%t9N-'
    b'{_ILwj%iG20qKQh)UT>X``Ugrikxy5bnaF=`B|6i2He&iFM{}*So|7R{6{vX+Fq<`eIQHe%$Vi1#9#3l}LiAQ`A@EZw9#P9q;Vv>-'
    b'QWF#lWuk1G!ssE7yr{ho3lYxw6`jri5`L}#H2RX?_Zt{?qeB`G9e^HP^6s8D8DMoQhP?A!VrVM2%NBMtb(3Pl66{=E=>eQenwWv)U>QayTG@v1kXiO8D(v0S'
    b'`pe3znO&i+Mj`nn*Bc13>7rN4o?)0E1z35FJ`qGd74ERsv=c5_(U&+xYGU-'
    b'>IK82}FV>&Z_W$d$<{cl<Od={{fMJ#3sOaGC>ulSY4uVOW8Sj#%rvw@9lVl!LV$~LyMgPrVRH+$I2KK65fgB<!F%=^!9mUEo{e_8(jnJ@q70lxEtpTBMf{zX'
    b'6n5ttwZB^bd8K}bRonlOYV9N~!&=s&uJNJRce#}JL^#2_ZIe)SG<{wv+XZzLoUzw-x)NkUSRk(?ByBo(PiLt4`DC+W#RMl$`Q)5uCTvXg_H<RUkD$V)!*Q-'
    b'HrHNFfSSgrXFqI3*}aDN0j@vXrAd6{tuhDpQ53RHHgIs7WnqQ-`|LqdpC2_@C%v+R*mD(#dq9GhKf5Gu`M;4|>vz-'
    b'v8)r`q7^O3}nzhx}2d5V>lxi$tXrMhOvxeJX4v*bY?J<S<L<)=!2HAoE86zx}kseLi_)deb5=s{-'
    b'YPVz{Owv&}FW0m1|t*1~<9IZSHWFd)((C&v?O0Uh$eYyyYG5`M^g$@tH4t<s0Am!Oy>M<OBalPZf|r1SSYU2}W>25Ry=YCd|L}S`mmyBqIOa6A_hYL?;F@iA'
    b'8MU5SMtwCjq~akVO2>A0+;t=*-fSfsAA#Gg-(=HnNk0oa7=mdB{sX@>77nC`cg+Q-'
    b'q=vqc|lfNhwNGhO(5SJQb)&B`Q;es#K#oHK<7~YEy^0)T2HPXh<U((}bopqd6^TNh?~@hPJe$Jss#sCpy!Gu5_b2J?Kd<deeu#^rJrm7|0+7GlZcGV>lxi$t'
    b'XrMhOz(2&T=NRnEh}4<^2Cfhq;txEN8_(I?dIrVJ+)e&jvQKiOp<bE8E!44tBDO-'
    b'R$|*jqdx^j~?J4hd9g;j&h9SocN#UP_J^0>)hZbx46w6?sAX&Jm4XZc+3-'
    b'?@{H%a;3cnk%^TkGj`w`vBcB5Q#~jZWzW(ZQzw?8i1PEgN6OcdzCI~?ZMsPw9l2CtlcZ4A<;RsIzA`*$nLH<im9F6G2ASSVhO&sD9kNE!^`{Z2zH=S}p3Q?F'
    b'M|DBGx^#9*8|8MP?SF?t-tYbYJ*vKX}vxTi}V>>(8$u4%YhrR4$KL<F-'
    b'Ar5ndqrW=s<NwxcpXLl_Imh{5UH3&UahWSz<r>$y!A)*)n>*a)9`|{`Lmu&%Cp_gD&w0U1Uh$eYyyYG5`M^g$@tH4t<s0Am@vDmu5Y+l7Ab|)>5P}kn;DjLL'
    b'-yL_*|7&+2j_^bvB9Vwp6rvK1=)@o<v4~9^;u4SeB;dDy%mV!WpPUCsOFI4}JsHSICNh(StYjlQImk&aa+8O=<Rd=?_=|%49fTI92t_GIaY|5<Qk13)WhqB_'
    b'Do~M1RHh15sYZ2bP?K8JrVe$fM|~R5kVZ772~BB6b6U`nR<x!KZD~h)I?$0$bfybk=|*>Y(34*DrVoATM}Gz|kU<P)2t)r9vlkPX$RsBJ+bqWP|HeGVT;?&K'
    b'1uXnEqp_GJEM*zXS;0zHv6?lkWgY9;z(zK)`QPR|wzGqs>|!^2*vmfl|4+<<oZ&3zIL`$xa_QHc$Q7<~jqBX_H9K;P+uY$U_qfjk9`cCCJmD$Nc+Lx6@`~5L'
    b'W>DVpj`w`vBcJ%p7rye1@BHBB-ywf6>z{ys&mRz&AOs~C!3jagVE<*tB@AH+M|dI-kw`=)3Q_+z&cbB)@65wwCkHvn_1~F~`Ro7T8JYjD&c^)vEX-'
    b'q`@RVmf=f&UePjK%6g(yr>icy>rl%y1;DMMMxQJxA^q!N{>LRG3!of_1n7PYBEUFuPv1~jA*jcGztn$esVw4@cSX+vAu(Vh-'
    b';q!XR#LRY%cogVb07rp62U;5FX0SsgigBik5hB2HGjARs}8N*n{F`fxbWD=8^!c?X)of*tz7PFbdT;?&K1uSF{i&?@_ma&`_tYj6dS;JcX5BBaMXxFt{(Coj'
    b'LZQHhO+qP}nwr$(CZQHiB*Q#+McjK>9nOPZG8Btjg)foM^GoP>VUGtus*vuBTvW@NRU?;oS%^vo$kNq6rAcr{25sq?<<DB3mr#Q_S&T@|PT;L*?xcooaN<I8'
    b'<^it1x!AoB8nm4@V9q<1qo2oy-{>wj6|02MDbV&pvFhPR<Uz@9t|JGfFAuQntPXr<oiO57DD$$5e3}O<C*u)_&@rX|X5|W6-'
    b'Bq1ruNKOh;l8V%%AuZ`hPX;oQiOm0vE-WXx$W0#dl8^ippdf`POc9DwjN+7_B&8@#8Ol<Q@>HNAm8eV=s{U`#qIIJ?J?Kd<deeu#^rJrm7|0+7GlZf4sbw3<'
    b'C`SKV*EWvvO!%j9o5W<MFqLUcX9hEw#cbv<mwC)*0Sj5gVwSL!Wh`d}D_O;A*07d!tY-'
    b'ro*~DhHu$66WX9qjk#cuYnmwoK#00%k5VUBQ=V;tuMCppDw&Ty7<oaX`;xx{6zaFuIZ=LR>q#cl3zmwVjj0S|e^W1jGoXFTTxFL}jl-td-pyypWS`NU_w@Re'
    b'_T=LbLe^=}>GpML_1zX%ZG|J)@8At=EJP6$F0iqM21Ea3=G1R@fN$V4G3(TGkAViJqk#33&6h))6%l8D44At}j7P6|?ziqxd}r=3hkdNPoaOk^etS;<Cra*&'
    b'f;<R%Y!$wz()P>@0trU*qTMsZ3|l2VkW3}q=tc`8tmN>ru_RjEdGYEY9})TRz~sYiVp(2zznrU^}HMsr&Hf3Ops$~30`r)G3EbC}CK=Cgo>EMhTBSjsY%vx1'
    b'eZVl``6%R1JxfsOyxqi$g<+t~j9_o@F|^r<n4MQq{_mw3b{0SQS&Vv>-QWF#jADM>|Y(vX&P|JJ=`Bomp*LRPYoogDwEi_Jq`^8M4u7NFq2wX#JhN-'
    b'>I4f|8V?G-'
    b'W7DIm%Okid3R9Rj5ies#AlS)S~u3EpA=vQJ)4hq!Ep2LQ|U2oEEgC6|HGQTiVf{4s@gwo#{eXy3w5;^rY9nHNbu8NB{r99(W|97|j^QGLG>~U?P*4%oL_Fjp'
    b'@u_=KoDo{GVIm<*Z;OtNyJmUduYxvw@9lVl!LV$~LyMgPrVRH+$I2KK65fgB;>8M>xtcj&p*OoZ>WRILkTCbAgLo;xbpb%C&zQ=o{SR7Pq;>T^{k6Cp_gD&w'
    b'0U1Uh$eYyyYG5`M^g$@tH4t<s0Am!B2kiH^2GwPaydpJ$3*B5{SSAAt=EJP6$F0iqM21EaCn;Eq7F+5uF&sBo?uWLtNq!p9CZ%5s67cQj(FJ6r>~-'
    b'sYydx(vhAFWF!-r$wF4Lk)0gmBp12KLtgTcp8^!55QQm1(SLgM;{P=1B`HN|%21Yal&1m}sYGR}P?c&_rv^2tMQ!R(mwMEv0S#$HW17&EW;CY-Eont-'
    b'+R&DEw5J0d=|pF`(3Ng<rw2XhMQ{4hmwxnT00SAsV1_W1VGL&kBN@eL#xRy~jAsH9nZ#tKFqLUcX9hEw#cbv<mwC)*0Sj5gVwSL!W&i8~tY9UpSj`&NvX1p^'
    b'U?ZE@%oet?jqU7UC%f3q9`>@2{T$#Rhd9g;j&h9SoZuv<IL#T(a*p#{;3Ai}%oVP3jqCppb{U@iSN0iR^M<#)<2@hv$R|GkPwqSfBoKiKLQsMcoDlz&ortji'
    b'wigkBh(sbXQHV-3q7#Fd#3D9vh)X=;lYoRIA~8uwN-'
    b'~m@f|R5pHEBpoI?|JYjASA+S;$H@vj121Hu8{{eB`G91t~;ficpkd6sH6wDMe|@P?mC(rveqJL}jW_m1<O{1~va*+860g4|>vz-'
    b't?g_{pimC2L7krlA#RyPdg@~7|ob}_D#kyo(W835|f$2RHiYV8O&rBvzfzO<}sfIEMyUjS;A75v78mGWEHDf!&=s{o(*hd6Pww>R<^O79qeQmyV=8D_OYJ>9'
    b'OMv(Il@tnahwyJ<P@hl!&%O8o(o*$5|_EcRjzTJ8{Fg;x4FYz?s1<7Jme9NdBRhk@tl{u;x%u0%RAolfscIRGhg`1w}1A5e(;lD{QaNygZ?4_0SQD9f)b42g'
    b'dilL2u&Em5{~dhAR>{7OcbILjp)Q6Cb5W39O4p>_#_}9iAem<zEV<>k%CmDCJkvxM|v`lkxXPJ3t7oVc5;xDT;wJXdC5n93Q&+j6s8D8DMoQhP?A!VrVM2%M'
    b'|mnxkxEpi3RS5_b!t$PTGXb_e`gQtfA#Lw|Ej&C|B-#7reXbln*Xy4)Q(;ZVlYD($}omAf>HmIyFfFT$t-'
    b'3whq=sSJ_}gLA{MiRr7UAPD_F@YR<nk+tYbYJ*vKX}vxTi}V>>(8$u4%YhrR4$KL<F-'
    b'Ar5ndqa5QnCpgI|PIHE{oZ~zfxX2|gbA_v1<2pCE$t`Ykhr8V4J`Z@vBOddFr#$01FL=o-Uh{^xyyHC|_{b+d^M$W`<2yh2$uIuqH-'
    b'G+PsVbcB2muI4AOaJFpadg0AqYt*LKB9tgd;o=h)5(N6NRWmBRVmNNi1R$hq%NeJ_$%jA`+8?q$DFbDM(2wQj><Xq$52U$VetKlZC8gBRe_BNiK4ehrHw?KL'
    b'sdAAqrE3q7<VzB`8TLN>hfil%qTqs7NI$Q-'
    b'!KjqdGOHNiAwqhq~0GJ`HF{BO23$rZl5DEoezATGNKMw4*&8=tw6z(}k{dqdPt5NiTZShraZqKLZ%ZAO<spp$ua<BN)jjMl*)7jAJ|#n8+k1Gli*4V>&aK$t'
    b'-3whq=sSJ_}gLA{MiRr7UAPD_F@YR<nk+tYbYJ*vKX}vxTi}V>>(8$u4%YhrR4$KL<F-'
    b'Ar5ndqa5QnCpgI|PIHE{oZ~zfxX2|gbA_v1<2pCE$t`Ykhr8V4J`Z@vBOddFr#$01FL=o-Uh{^xyyHC|_{b+d^M$W`<2yh2$uIuqH-Gq7c=JyH0uqS81R*HF'
    b'2u=t>5{l4-AuQntPXr<oiO57DD$$5e3}O<C*u)_&@rX|X5|W6-'
    b'Bq1ruNKOh;l8V%%AuZ`hPX;oQiOggnE7{0S4sw!<+~grI`N&TJ3Q~x|6rm`^C{77VQi{@)p)BPnPX#JciON)=D%Ge?4Qf)0+SH*g^{7t+8q$cyG@&WYXif`S'
    b'(u&r!p)KubPX{{EiOzJPE8XZ$4|>vz-'
    b't?g_{pimC1~Q1j3}Gn47|sYrGK$fRVJzbq&jcniiOEc1D$|(G3}!Nm+00=s^O(;97P5%NEMY0jSk4MovWnHLVJ+)e&jvQKiOp<bE8E!44tBDO-'
    b'Rxm6``FI`4swXY9N{R(IL--9a*ETO;VkDk&jl`WiOXE!D%ZHq4Q_Ia+uY$U_qfjk9`cCCJmD$Nc+Lx6@`~5I;VtiY&j&v8iO+oDE8qCe4}S8CzxmA{{uROe6'
    b'M%pOA}~P+N-%;Gf{=tFG+_u!IKmTwh(sbXQHV-3q7#Fd#3D9vh)X=;lYoRIA~8uwN-~m@f|R5pHEBpoI?|JYjASA+S;$H@vXg_H<RUkD$V)!*Q-'
    b'FdLqA*1$N->I4f|8V?G-'
    b'W7DIm%Okid3R9Rj5ies#AlS)S@<Zs7pQS(}0FFqA^WqN;8_%f|j(RHEn21JKEEMj&!0kUFb?Ty3>Q6^rAO?=u1EPGk}2%VlYD($}omAf{~13G-'
    b'DXcIL0%9iA-WLQ<%y$rZa<?%wjfkn9Drovw(#xVlhit$}*O-f|aadHEUSQI@Ys+jcj5wTiD7rwzGqs>|!^2*vmflbAW>!;xI=z$}x^}f|H!$G-'
    b'o)=InHx|i(KL|SGdYGu5*K%+~PKOxXV56^MHpu;xSKn$}^txf|tDFHE(#!JKpnwk9^`YU--&5zVm~h{NitZ^C!Z8c~s#q0uYcu1SSYU2}W>25Ry=YCJbQ-'
    b'M|dI-kw`=)3Q>thbYc*bSi~j{afwHK5|EHYBqj+-'
    b'Nk(!~kdjoSCJkvxM|v`lkxXPJ3t7oVc5;xDT;wJXdC5n93Q&+j6s8D8DMoQhP?A!VrVM2%M|mnxkxEpi3RS5_b!t$PTGXZvb*V>v8qknNG^PnnX-'
    b'0Ee(2`cPrVVXrM|(QZkxq1`3tj0(cY4s1Ui799ed$Mk1~8C83}y&J8OCr%Fp^P>W(;E)$9N_%kx5Ku3R9WJbY?J<S<Ge*bD76{7O;>-'
    b'EM^HyS;lf!u##1*W({ju$9gufkxgu7E8E!44tBDO-Rxm6``FI`4swXY9N{R(IL--9a*ETO;VkF4z(p=`nJZl78rQkOO>S|UJKW_S_j$lW9`TqbJmneBdBICw'
    b'@tQZh<sBdR$R|GYg|B?$J3sizFaG8?fBtzy<u3vdkU#_`2tf%(a6%B0P=qE7VF^cgA`p>CL?#MRiAHo{5R+KMCJu3lM|={HkVGUV2}wyta#E0nw4@_F8OTT`'
    b'GLwa@WFtE{$Vo18lZU+IBR>TwNFfSSgrXFqI3*}aDN0j@vXrAd6{tuhDpQ53RHHgIs7WnqQ-'
    b'`|LqdpC2NFy54gr+p3IW1^OD_YZrwzQ)?9q33WI@5)&bfY^x=t(bn(}%wFqdx-'
    b'}$RGwYgrN*$I3pOzC`L1ev5aFp6PU;(CNqVpOk+ATn8_?=Gl#j%V?GO5$RZZAgrzKFIV)JnDps?GwX9=38`#JuHnWATY-2k+*vT$-'
    b'vxmLxV?PHt$RQ4MgrgkeI43yCDNb{Svz+5R7r4kJE^~#eT;n=7xXCSUbBDX!<30~~$Ri%}gr_{?IWKt0D_--'
    b'4x4h#$ANa^8KJ$gIeB(Pm_{lH+<~M)-c{J%S0uYcu1SSYU2}W>25Ry=YCJbQ-M|dI-kw`=)3Q>thbYc*bSi~j{afwHK5|EHYBqj+-'
    b'Nk(!~kdjoSCJkvxM|v`lkxXPJ3t7oVc5;xDT;wJXdC5n93Q&+j6s8D8DMoQhP?A!VrVM2%M|mnxkxEpi3RS5_b!t$PTGXZvb*V>v8qknNG^PnnX-'
    b'0Ee(2`cPrVVXrM|(QZkxq1`3tj0(cY4s1Ui799ed$Mk1~8C83}y&J8OCr%Fp^P>W(;E)$9N_%kx5Ku3R9WJbY?J<S<Ge*bD76{7O;>-'
    b'EM^HyS;lf!u##1*W({ju$9gufkxgu73tQR7c6P9nUF>ELd)dc+4seh|9Oei|ImU5LaFSD;<_u>!$9XPrkxN|W3Rk(tb#8EzTioUjce%%X9`KMyJmv{cdB$^I'
    b'@RC=&<_&Lo$9q2TkxzW)3t#!hcYg4bU;NE){`~V`+Ft}9Ab|)>5P}kn;DjI~p$JVF!V-'
    b'?~L?9xOh)fis5{>A@ASSVhO&sD9kN6}YA&E##5|WaP<fI@asYp#4(vpt!WFRA%$V?Wpl8x--ASb!VO&;=+kNgy%AcZJQ5sFfb;*_8yr6^4q%2JN<RG=c2s7w'
    b'{AQjO}=peD7bO&#h|kNPyAA&qEE6PnVD=Cq(Ct!Paf+R~2pbf6=h=u8*7(v9x)peMcPO&|KwkNyl`AcGjp5QZ|0;f!D;qZrK?#xjoaOkg6Dn9LNWGL7lXU?#'
    b'Je%^c=3kNGTMA&Xed5|*-'
    b'z<*Z;Ot60q%*0PTEY+xgs*vuBTvW@NRU?;oS%^vo$kNq6rAcr{25sq?<<DB3mr#Q_S&T@|PT;L*?xXcx<a*gZU;3l`Y%^mJ?kNZ5}A&+>>6Q1&n=e*!0uXxQ'
    b'H-tvz3eBdLW_{<l+@{RBO;3vQMo8SET=dr}U2tYsr5ttwZB^bd8K}bRonlOYV9N~#TL?RKHC`2V1(TPD!ViB7-'
    b'#3df_NkBppk(eYTB^k*{K}u4Qnlz*(9qGwHMlz9^EMz4c*~vjpa*>-'
    b'n<Ru^ZDL_FAQJ5kWr5MF2K}kwcnlhB79ObD%MJiF5DpaK!)u};EYEhdy)TJKvX+T37(U>MQr5Vj>K}%ZEnl`kh9qs8rM>^4&E_9_E-'
    b'RVJ3deNIc^ravD8NfgWF_<9?Wf;R5!AM3inlX%J9OIe5L?$trDNJP=)0x3cW-*&N%w-<)S-?UTv6v++Wf{v^!Ae%Knl-Ft9qZY^MmDjTEo@~Q+u6ZRcCnj1>'
    b'}4POIlw^<ahM|<<rv2~!AVYWnlqf`9Ot>fMJ{ofD_rFo*SWz>ZgHDC+~pqkdB8&+@t7w(<r&X;!AoB8nm4@V9q;+TM?UeHFMQ=2-'
    b'}%8$e(^WI`SZ_1seciGfCM5iK?q7Pf)j#}gd#Ly2unD^6M=|CA~I2kN;IMqgP6o3HgSkcJmQmpgd`#{Nk~dEl9Pgzq#`wGNJ~1>lYxw6A~RXYN;a~SgPi0dH'
    b'+jfQKJrt5f)t`KMJP%!ic^A;l%h0cC`&oYQ-'
    b'O+9qB2#eN;RregPPQ$Hg%{=J?hhdhBTrvO=wCpn$v=ow4ya_XiGcV(}9k3qBC9SN;kUGgP!!FH+|?!Kl(F(fed0WLm0|1hBJbZjAArn7|S@uGl7XrVlq>h$~'
    b'2}kgPF`?HglNEJm#~2g)Cw*OIXS>ma~GDtYS55Sj#%rvw@9lVl!LV$~LyMgPrVRH+$I2KK65fgB;>8M>xtcj&p*OoZ>WRILkTCbAgLo;xbpb$~CTYgPYvqHg'
    b'~woJ?`^>hdkmjPk72Rp7Vm2yy7))c*{H9^MQ|i;xk|P$~V6AgP;83_kYZKbhA!if)JEo1SbR`2}Nka5QV5jBRVmNNi1R$hq%NeJ_$%jA`+8?q$DFbDM(2wQj'
    b'><Xq$52U$VetKlZC8gBRe_BNiK4ehrHw?KLsdAAqrE3q7<VzB`8TLN>hfil%qTqs7NI$Q-'
    b'!KjqdGOHNiAwqhq~0GJ`HF{BO23$rZl5DEoezATGNKMw4*&8=tw6z(}k{dqdPt5NiTZShraZqKZ6;<P)0D4QH*8`V;RSICNPmnOlAsGnZ|TxFq2u#W)5?i$9'
    b'xvBkVPzJ2}@bVa#paCRjg(WYgxy7Hn5RRY-S5v*~WHuu#;WvW-'
    b't5L&jAi{h{GJ=D91R?2~Ki~)12Wf=Qz&=E^>*>T;VF$xXul3a*NyC;V$>M&jTLvh{rtPDbIM$3tsYy*Sz5^?|9D#KJtmreBmqK_|6Z0@{7Ou&7XfBHvfwN1S'
    b'AlF2|`eU5u6Z&Bov_uLs-HQo(M!F5|N2QRH6}`7{nwNv57-m;t`(&BqR}uNkUSRk(?ByBo(PiLt4_2o(yCp6Pd|ER<e<u9ONVyxyeIb@{ykc6r>P^DMC?-'
    b'QJfN#q!gtoLs`mEo(fc?5|yb!RjN^)8q}l~wW&j0>QSEtG^7!YX+l$)(VP~vq!q1cLtEO>o(^=R6P@WoSGv)i9`vLaz3D?=`q7^O3}g_48NyJ8F`N;MWE7(r'
    b'!&t^Ko(W835|f$2RHiYV8O&rBvzfzO<}sfIEMzfDSjKABu$FbKX9FAA#Addzm2GTi2RqrtZuW43Go0ld=efW|E^(PFT;&?qxxr0tahp5b<sSEWz(XGKm?u2t'
    b'8P9paOJ4DsH@xK?@A<$-KJl3^eC2O`^XH#~1Ah^KfCM5iK?q7Pf)j#}gd#Ly2unD^6M=|CA~I2kN;IMqgJrRNW7)-'
    b'S_OO?I?B@UnImBU(aFk;l=L9D?#c9rPmUEov0vEZ&Wv+0QFGP;*HxZR+L?;F@iA8MU5SMtw=XM<5i@0W<Ok^etS;<CDa#4VS6rwQ2C_yPoQ--pXqdXO;NF^#'
    b'$g{oAeIyI<CEoxJTy40gS4QNOs8q<WPG^05!Xh|zt(}uRRqdgtyNGCeeg|2j?J3Z)0FM895zVxF%0~p941~Y`A3}ZMW7|AF`GlsE@V>}a>$Rs8+g{e$qIy0E'
    b'bEM_x@xy)le3s}e^7PEw<EMqw<Sjj3@vxc>-'
    b'V?7(#$R;+kg{^F3J3H9PE_Snrz3gK@2RO(f4s(Q~9OF1AILRqabB42=<2)C*$R#dwg{xfSIybn<EpBs%yWHbG4|vEU9`l5!JmWbpc*!eX^M<#)<2@hv$R|GY'
    b'g|B?$J3sizFaG8?fBrc{@)rRJNFV|egrEc?I3Wm0C_)p4u!JK#5r{}6A`^wEL?b#eh)FDB6Nk9OBR&a8NFoxGgrp=RIVng<DpHe%w4@_F8OTT`GLwa@WFtE{'
    b'$Vo18lZU+IBR>TwNFfSSgrXFqI3*}aDN0j@vXrAd6{tuhDpQ53RHHgIs7WnqQ-'
    b'`|LqdpC2NFy54gr+p3IW1^OD_YZrwzQ)?9q33WI@5)&bfY^x=t(bn(}%wFqdx-'
    b'}$RGwYgrN*$I3pOzC`L1ev5aFp6PU;(CNqVpOk+ATn8_?=Gl#j%V?GO5$RZZAgrzKFIV)JnDps?GwX9=38`#JuHnWATY-2k+*vT$-'
    b'vxmLxV?PHt$RQ4MgrgkeI43yCDNb{Svz+5R7r4kJE^~#eT;n=7xXCSUbBDX!<30~~$Ri%}gr_{?IWKt0D_--4x4h#$ANa^8KJ$gIeB(Pm_{lH+<~M)-'
    b'IYRUo0SHJS0uzLw1S2>h2uUbH6Na#aBRmm^NF*W?g{VX$Ix&bzEMgOfxWpqq2}npH5|f0aBqKQ~NJ%PElZLdUBRv_&NG39qg{)*FJ2}WnE^?EHyyPQ41t>@%'
    b'3R8rl6r(sLC`l<wQ--pXqdXO;NF^#$g{oAeIyI<CEoxJTy40gS4QNOs8q<WPG^05!Xh|zt(}uRRqdgtyNGCeeg|2j?J3Z)0FM895zVxF%0~p941~Y`A3}ZMW'
    b'7|AF`GlsE@V>}a>$Rs8+g{e$qIy0EbEM_x@xy)le3s}e^7PEw<EMqw<Sjj3@vxc>-'
    b'V?7(#$R;+kg{^F3J3H9PE_Snrz3gK@2RO(f4s(Q~9OF1AILRqabB42=<2)C*$R#dwg{xfSIybn<EpBs%yWHbG4|vEU9`l5!JmWbpc*!eX^M<#)<2@hv$R|GY'
    b'g|B?$J3sizFaG8?fBrc@_7?#NNFV|egrEc?I3Wm0C_)p4u!JK#5r{}6A`^wEL?b#eh)FDB6Nk9OBR&a8NFoxGgrp=RIVng<DpHe%w4@_F8OTT`GLwa@WFtE{'
    b'$Vo18lZU+IBR>TwNFfSSgrXFqI3*}aDN0j@vXrAd6{tuhDpQ53RHHgIs7WnqQ-'
    b'`|LqdpC2NFy54gr+p3IW1^OD_YZrwzQ)?9q33WI@5)&bfY^x=t(bn(}%wFqdx-'
    b'}$RGwYgrN*$I3pOzC`L1ev5aFp6PU;(CNqVpOk+ATn8_?=Gl#j%V?GO5$RZZAgrzKFIV)JnDps?GwX9=38`#JuHnWATY-2k+*vT$-'
    b'vxmLxV?PHt$RQ4MgrgkeI43yCDNb{Svz+5R7r4kJE^~#eT;n=7xXCSUbBDX!<30~~$Ri%}gr_{?IWKt0D_--4x4h#$ANa^8KJ$gIeB(Pm_{lH+<~M)-'
    b'IX?Io0SHJS0uzLw1S2>h2uUbH6Na#aBRmm^NF*W?g{VX$Ix&bzEMgOfxWpqq2}npH5|f0aBqKQ~NJ%PElZLdUBRv_&NG39qg{)*FJ2}WnE^?EHyyPQ41t>@%'
    b'3R8rl6r(sLC`l<wQ--pXqdXO;NF^#$g{oAeIyI<CEoxJTy40gS4QNOs8q<WPG^05!Xh|zt(}uRRqdgtyNGCeeg|2j?J3Z)0FM895zVxF%0~p941~Y`A3}ZMW'
    b'7|AF`GlsE@V>}a>$Rs8+g{e$qIy0EbEM_x@xy)le3s}e^7PEw<EMqw<Sjj3@vxc>-'
    b'V?7(#$R;+kg{^F3J3H9PE_Snrz3gK@2RO(f4s(Q~9OF1AILRqabB42=<2)C*$R#dwg{xfSIybn<EpBs%yWHbG4|vEU9`l5!JmWbpc*!eX^M<#)<2@hv$R|GY'
    b'g|B?$J3sizFaG8?fBrc<`WFERNFV|egrEc?I3Wm0C_)p4u!JK#5r{}6A`^wEL?b#eh)FDB6Nk9OBR&a8NFoxGgrp=RIVng<DpHe%w4@_F8OTT`GLwa@WFtE{'
    b'$Vo18lZU+IBR>TwNFfSSgrXFqI3*}aDN0j@vXrAd6{tuhDpQ53RHHgIs7WnqQ-'
    b'`|LqdpC2NFy54gr+p3IW1^OD_YZrwzQ)?9q33WI@5)&bfY^x=t(bn(}%wFqdx-'
    b'}$RGwYgrN*$I3pOzC`L1ev5aFp6PU;(CNqVpOk+ATn8_?=Gl#j%V?GO5$RZZAgrzKFIV)JnDps?GwX9=38`#JuHnWATY-2k+*vT$-'
    b'vxmLxV?PHt$RQ4MgrgkeI43yCDNb{Svz+5R7r4kJE^~#eT;n=7xXCSUbBDX!<30~~$Ri%}gr_{?IWKt0D_--4x4h#$ANa^8KJ$gIeB(Pm_{lH+<~M)-'
    b'IXe6o0SHJS0uzLw1S2>h2uUbH6Na#aBRmm^NF*W?g{VX$Ix&bzEMgOfxWpqq2}npH5|f0aBqKQ~NJ%PElZLdUBRv_&NG39qg{)*FJ2}WnE^?EHyyPQ41t~^x'
    b'N>Gwgl%@=2DMxuKP?4I{qBeD?OFin-fQB@pF-'
    b'>SnGn&(amb9WZZD>n7+S7rKbfPm|=t?)b(}SM$qBni$OF#NEfPoBRFhdy1ForXNk&I$AV;IXg#xsG5Oky%qn94M!GlQATVm5P_%RJ_@fQ2k#F-'
    b'us=GM2M~m8@blYgo%V*0X_)Y+^H8*vdAxvxA-NVmEu(%RUZqgkv1%1SdJgY0hw#bDZY_7rDe`u5guWT;~Qixy5bnaF=`B=K&9S#ABZDlxIBW1uuEUYu@mdcf'
    b'98VANj;*zVMZAeCG#0`NePk{BtP$F9HydKm;ZTK?z21LJ*QrgeDAO2}gJ$5RphkCJIrBMs#8jlUT$i4snS`d=ik5L?k8&Nl8X>Qjn5Vq$Uk%Nk@7zkdaJeCJ'
    b'R}~Ms{+LlU(E`4|&N)ehN^KLKLP5MJYycN>Gwgl%@=2DMxuKP?1VhrV3T5Ms;dXlUmfK4t1$VeHze^Ml_}gO=(7RTF{bKw5APhX-9iH(2-'
    b'7brVCx^Mt6G9lV0?u4}IxJe+Dp+K@4UHLm9?!Mlh05jAjgD8OL}gFp)`2W(rf8#&l*dlUdAW4s)5ud={{fMJ#3sOIgNpR<M#)tY!^sS;u-du#rt{W(!-'
    b'{#&&kFlU?j)4}00iehzSuLmcJ^M>)oEPH>V_oaPK?ImdY}aFI(~<_cH2#&vFRlUv;84tKf7eID?TM?B^guX)2;-'
    b'tnFfeB=|K`NCJe@tq(1<QISQ`#)wisaYi);fX**A`zJ=L?s&0i9t+a5t}%~B_8ofKtd9cm?R`68OcdON>Y)UG^8aR>B&GwGLe}q<RUkD$V)!*Q-'
    b'FdLqA*1$N->I4f|8V?G-'
    b'W7DIm%Okid3R9Rj5ies#AlS)S@<Zs7pQS(}0FFqA^WqN;8_%f|j(RHEn21JKEEMj&!0kUFb?Ty3>Q6^rAO?=u1EPGk}2%VlYD($}omAf{~13G-'
    b'DXcIL0%9iA-WLQ<%y$rZa<?%wjfkn9Drovw(#xVlhit$}*O-f|aadHEUSQI@Ys+jcj5wTiD7rwzGqs>|!^2*vmflbAW>!;xI=z$}x^}f|H!$G-'
    b'o)=InHx|i(KL|SGdYGu5*K%+~PKOxXV56^MHpu;xSKn$}^txf|tDFHE(#!JKpnwk9^`YU--&5zVm~h{NitZ^M`*W^LLp51SAlF2|`eU5u6Z&Bov_uLs-HQo('
    b'M!F5|N2QRH6}`7{nwNv57-m;t`(&BqR}uNkUSRk(?ByBo(PiLt4_2o(yCp6Pd|ER<e<u9ONVyxyeIb@{ykc6r>P^DMC?-'
    b'QJfN#q!gtoLs`mEo(fc?5|yb!RjN^)8q}l~wW&j0>QSEtG^7!YX+l$)(VP~vq!q1cLtEO>o(^=R6P@WoSGv)i9`vLaz3D?=`q7^O3}g_48NyJ8F`N;MWE7(r'
    b'!&t^Ko(W835|f$2RHiYV8O&rBvzfzO<}sfIEMyUjS;A75v78mGWEHDf!&=s{o(*hd6Pww>R<^O79qeQmyV=8D_OYJ>9OMv(Il@tnahwyJ<P@hl!&%O8o(o*$'
    b'5|_EcRjzTJ8{Fg;x4FYz?s1<7Jme9NdBRhk@thaD<Q1=Z!&~0*o)3KF6QB9QSHAI`AN=GOfAgC^{42TnCjbEnL|}ptlwbrW1R)7UXu=SdaD*oU5s5@(q7ap6'
    b'L?;F@iA8MU5SMtwCjkjbL}HSVlw>3)1u02IYSNIFbfhN(8OcOuvXGT*WG4qX$whARke7VqrvL>hL}7|hlwuU81SKg&Y06NRa+Ie66{$pJs!)|`RHp_tsYPw-'
    b'P?vhtrvVLVL}QxJlx8%i1ubbsYueD3cC@Dh9qB}8y3mzwbf*VB=|yk)(3gJnX8;2k#9)Rnlwk~K1S1*6XvQ#>ag1jI6Pd(hrZAOhOlJl&nZ<18Fqe7EX8{XY'
    b'#A24Plw~Yu1uI#_YSyrpb*yIt8`;EWwy>3LY-'
    b'a~M*~M=5u$O)8=Ku#e#9@wblw%y{1SdJgY0hw#bDZY_7rDe`u5guWT;~Qixy5bnaF=`B=K&9S#ABZDlxIBW1uuEUYu@mdcf98VANj;*zVMZAeCG#0`NiM-'
    b'<`4f$Vg3m~Kmrk%AOs~C!3jY~LJ^uUge4r|i9kdm5t%4NB^uF*K}=#1n>fTJ9`Q*)LK2afBqSvn$w@&<QjwZ8q$M5c$v{Rjk(n%HB^%kvK~8d!n>^$tANeUj'
    b'K?+frA{3<<#VJ8aN>Q3Jl%*WysX#?4QJE@Kr5e?#K}~8=n>y5`9`$KJLmJVTCN!lP&1pePTG5&|w51*G=|D$1(U~rEr5oMpK~H+on?CfVAN?7?Kn5|GAq-'
    b'_0!x_OyMlqT(jAb0-nZQIQF_|e$Wg63&!Axc`n>oy79`jkiLKd-'
    b'@B`jqb%UQunR<W8jtYsbR*}z6Nv6(GwWgFYs!A^Fun?3AhANx7LK@M@4BOK)z$2q}CPH~zuoaG$nxxhs(ahWSz<r>$y!A)*)n>*a)9`|{`Lmu&%Cp_gD&w0U'
    b'1Uh$eYyyYG5`M^g$@tH4t<s0Am!B2kiH^2GAzfzii0uYcu1SSYU2}W>25Ry=YCJbQ-M|dI-kw`=)3Q>thbYc*bSi~j{afwHK5|EHYBqj+-'
    b'Nk(!~kdjoSCJkvxM|v`lkxXPJ3t7oVc5;xDT;wJXdC5n93Q&+j6s8D8DMoQhP?A!VrVM2%M|mnxkxEpi3RS5_b!t$PTGXZvb*V>v8qknNG^PnnX-'
    b'0Ee(2`cPrVVXrM|(QZkxq1`3tj0(cY4s1Ui799ed$Mk1~8C83}y&J8OCr%Fp^P>W(;E)$9N_%kx5Ku3R9WJbY?J<S<Ge*bD76{7O;>-'
    b'EM^HyS;lf!u##1*W({ju$9gufkxgu73tQR7c6P9nUF>ELd)dc+4seh|9Oei|ImU5LaFSD;<_u>!$9XPrkxN|W3Rk(tb#8EzTioUjce%%X9`KMyJmv{cdB$^I'
    b'@RC=&<_&Lo$9q2TkxzW)3t#!hcYg4bU;NE){_w9<=AQrrBoKiKLQsMcoDhU06rl-'
    b'2Si%vW2t*_jk%>Z7q7j`K#3UB6i9=lC5uXGkBoT>8LQ;~EoD`%a6{$%>TGEl83}hq|naM&{vXPw}<Rlll$wOZ9k)Hw-'
    b'q!5KELQ#rQoD!6z6s0LcS;|qK3RI*Lm8n8is!^R9)T9=*sY6}rQJ)4hq!Ep2LQ|U2oEEgC6|HGQTiVf{4s@gwo#{eXy3w5;^rRQP=|f-'
    b'o(VqbfWDtWH!cc}WoDqy<6r&l#SjI7)2~1=XlbOO)rZJrv%w!g`nZsP>F`or2WD$#5!cvy8oE5BO6{}gpTGp|i4Qyl+o7uuvwy~WZ>|__a*~4D;v7ZAR<Pe8'
    b'B!cmTKoD-bn6sI}ES<Z2u3tZ$9m$|}Ku5q0k+~gLwxx-!Vai0e~<Pnc~!c(5{oEN<06|Z^2Ti)@W4}9bkpZUU9zVV$O{NxvZ^P4~XE4BG2009X^V1f{oU<4-'
    b'wAqhoj!Vs2lgeL+Ki9}?g5S3^|Ck8QzMQq{_mw3b{0SQS&Vv>-QWF#jADM>|Y(vX&Pq$dLz$wX$dkd<s?CkHvnMQ-'
    b'wtmwe=>00k*TVTw?cViczYB`HN|%21Yal&1m}sYGR}P?c&_rv^2tMQ!R(mwMEv0S#$HW17&EW;CY-Eont-'
    b'+R&DEw5J0d=|pF`(3Ng<rw2XhMQ{4hmwxnT00SAsV1_W1VGL&kBN@eL#xRy~jAsH9nZ#tKFqLUcX9hEw#cbv<mwC)*0Sj5gVwSL!Wh`d}D_O;A*07d!tY-'
    b'ro*~DhHu$66WX9qjk#cuYnmwoK#00%k5VUBQ=V;tuMCppDw&Ty7<oaX`;xx{6zaFuIZ=LR>q#cl3zmwVjj0S|e^W1jGoXFTTxFL}jl-td-pyypWS`NU_w@Re'
    b'_T=LbLe#ozqq5C2MI{s}-p0uh)X1SJ^32|-'
    b'9g5t=ZBB^=?2Ktv)DnJ7dh8qtYCOkxq6IK(9$@ku~J5|NlBBqbTiNkK|dk(xB5B^~L>Kt?i=nJi=_8`;T0PI8f(Jme)G`6)m_3Q?FM6r~u&DM3j}QJON8r5x'
    b'p{Kt(E1nJQGJ8r7*mO=?k_I@F~e^=Uvu8qt_0G^H8MX+cX`(V8~2r5)|*Ku0>!nJ#pt8{O$aPkPatKJ=v@{TaYO1~Hf+3}qO@8No<KF`6-'
    b'qWgO#~z(gi7nJG+V8q=A<OlC2gIm~4q^I5<`7O|KmEM*zXS;0zHv6?lkWgY9;z(zK)nJsK(8{65zPIj@IJ?v#4`#Hct4sn<x9OW3tIl)Ozahfxn<s9d^z(p='
    b'`nJZl78rQkOO>S|UJKW_S_j$lW9`TqbJmneBdBICw@tQZh<sI+&z(+punJ;|h8{hfCPk!+?zxl(z(wct)5RgCwCI~?ZMsPw9l2C*u3}FdJcp?yyNJJ(IQHe%'
    b'$Vi1#9#3l}LiAQ`AkdQ<qCJ9MNMsiY+l2oK74QWY7dNPoaOk^etS;<Cra*&f;<R%Y!$wz()P>@0trU*qTMsZ3|l2VkW3}q=tc`8tmN>ru_RjEdGYEY9})TRz'
    b'~sYiVp(2zznrU^}HMsr%wl2){)4Q**hdpgjOPIRUVUFk-5deD<z^rjDe=|_JCFpxnEW(Y$W#&AY3l2MFi3}YF`cqTBBNla!6Q<=teW-yak%w`UAna6w<u#iP'
    b'8W(iAK#&TA$l2xo`4QpA)dN%wY?A=w6UDui}SXs<$F-'
    b'x{(83YzHGcz+YGcz+YGcz+YGcz+|568)l>+3#Mx9W6t)a~e2#CXu#+B^4Lx%2zKITx!~%^KFSj`eI{Bb(UF7PhjD?d)JDyV%Vh_Og%t9N-'
    b'{_ILr}_a*X4g;3TIw%^A*ej`LjLBA2+#6|QoP>)hZbx46w6?sAX&Jm4XZc+3-'
    b'?@{H%a;3cnk%^TkGj`w`vBcJ%p7rye1Kq;($0uzLw1S2>h2uUbH6Na#aBRmm^NF*W?g{XW_G@=uOn8YGBafnMi;*)@cBqA|M_<<k!iKP5YGJfG#e&ctNlY*3'
    b'_;tx`jhP0$3JsHSICNh(StYjlQImk&aa+8O=<Rd=?C`cg+Q-'
    b'q=vqc|lfNhwNGhO(5SJQb)&B`Q;es#K#oHK<7~YEy^0)T2HPXh<U((}bopqd6^TNh?~@hPJe$Jss#sCpy!Gu5_b2J?Kd<deeu#^rJrm7|0+7GlZcGV>lxi$t'
    b'XrMhOvxeJQJA6BqlS3sZ3)!GnmONW;2Jm%ws+aSjZw4vxKEAV>v5W$tqT}hPA9?Jsa4_CN{H$t!!gEJJ`uCcC&}Q>|;L%ILILmbA+QD<2WZc$tg~AhO?aGJQ'
    b'ujgB`$M?t6bwcH@L|yZgYpb+~YnEc*r9j^Mt27<2f&Q$tzy-hPS-qJs<eUCqDCquY4m=O6#A%1R*HF2u=t>5{l4-'
    b'AuQntPXr<oiO57DD&G^0=)@o<v4~9^;u4SeBp@M)NK6ub;75KUDL<2pU-'
    b'*^Z_?_gWASJ2zgVdxUE$K*41~QU~%w!=e*~m@~a*~VO<RLHl$WH+ZQi#G7p(w>DP6<j<iqe#!EafOq1u9aB%2c5$)u>JlYEp~Z)S)i*s80hL(ul@1p()L1P7'
    b'7Mniq^EDE$wJe2RhP;&UB$G-RMpadeV#D^r0{P=+6KKGKj$pVJO2G&Im>_iqVW=EaMo@1ST?x$xLA?)0oZ-W-'
    b'^P}%waC`n9l+hvWUejVJXX4&I(qtiq))PE$dj%1~#&Z&1_*S+t|(ycCw4z>|rna*v|nDa)`qm;V8#A&IwNb`MJnbDt~ZGsz|l`b!ybM?t=PE`hRLNkdaIjrY'
    b'OZIP6<j;i{`Xs9`jkiLKd-@B`jqbD_F%E*0X_)Y+^H8*uj1daDtPZ;xuPC%Q?<-fs0(?GB>!%9iH)=7rf*ZuX)2;-'
    b'tnFfeB=|K`NCJe5%@dz7=jXv;DjI~p$JVF!V-'
    b'?~L?9xOh)fis@;%XrP7ZRCkNgy%Eaj;{MJiF5Dm0)at(nDa<}jCe%x3`$S;P{Sv4T~sW({ju$9gufl|vln2uC@_aZYfOQ=H}uXF1OWE_0WA+~)xgdBkI$@RV'
    b'mf=LIi$#cSU1mXCbmGhg`1x9|RZ^WEnOOb~(+jNpVIB%ugR7{U^c@I)XIk%`Lp{6-2=lAerYA~R(vM?d;AfPoBRFhdy1ForXV(Trg%6PU(KW-'
    b'*(^EMXZ3ILILmbA+QD<2WZc%Q?<-fs0(?GFQ0DHLi1mo800yceu+v?(=|$JmN7=c*--'
    b'L^MaSW;x%u0%RAoliO+w&e?h!=L?aIIh))6%lAa9IrvVLVL}QxJlx8%i1+8gATiVfyp7de>1DVBa<}jCe%x3`$S;R7yvx1eZVl``6%R1JxfsJfpGh5ioHny{'
    b'ao$O*ad)Ui9_H%%P9O5uXILa}ObAr>H;XL2De}*Rl5lPC=B;yx;<u`sOIVng<sz2|$jAjgD8OL}gFp)`2W(rf8$t-'
    b'3wmwC)*0Sj5ia(1zYV;tuMCppDw&Ty7<oaX`;`ONph{On0cA`+8?ANY}<NXpM7;}?GAH-'
    b'0BMDM(2w{vb7JNJ~1>lYxw6A~RXYN_KLPlU(E`4|yp>VTw?cVicz&r6^4q%2JN<RG=c2s7w{AQjO}=peD7bO&#h|kNPyAA&qEE6PnVD=Cq(Ct!Paf+R~2pbf'
    b'6=h=u8*7(v9x)peMcPO&|KwkNyl`AcGjp5QZ|0;f!D;qZrK?#xjoaOkg6Dn9LNWGL7lXU?#Je%^c=3kNGTMA&Xed5|*-z<s9ZH$2iVez7f`!jBtb}F-'
    b'iE5pGeBjB;yx;<u`sOIVl*-5QZ|0;f!D;qZrK?CNhc1Ol2C=nZZovvyn|~W-'
    b't5L&jAi{h{GJ=D91R?2`+GrmxKx7brGEy#3UB6i9=lC5uXGkBoT>8!Vmn&PbB4MlJN__@*BUCoD`%a6@QSLw4@_F8OTT`vXg_H<RUkD$VYw(P>@0trU*qTMs'
    b'Z3|l2VkW3}q=tc`8tmN>ru_RjEdGYEY9})TRz~sYiVp(2zznrU^}HMsr%wl2){)4Q**hdpgjOPIRUVUFk-'
    b'5deD<z^rjDe=|_JCFpxnEW(Y$W#&AY3l2MFi3}YF`cqTBBNla!6Q<=teW-yak%w`T-'
    b'+0G7ja)6fv3F&(c!3aS}a*&g=oZ~zfxX2|gbA_v1<2pCE$!+d%mwVjjC9inR8{YDc_k7?ZpZLrdzW#YFp<D~02u)bRk(P9%Cj%KNPX#JciON)=D%Ge?4Qf)0'
    b'+SH*g^{7t+8q$cyG@&WYXif`S(u&r!p)Kv`&j1E8lwpkG3ttHm+IvhelGBLBG@&WYXif`S(u&r!p)KubPX{{EiOzJPE8XZ$4|>vz-'
    b't?g_{pimC1~Q1j3}Gn47|sYrGK$fRVJs7w#AH^phK+1uGh5ioHny{ao$O*ad)Ui9_H%%P9O5uXILa}ObApqc;xuPC%Q?<-'
    b'fs0(?GFQ0DHLi1mo800yceu+v?(=|$JmN7=c*--L^MaSW;x%u0%RAolfscIRGhg`1Hv)z69gM&PAt=EJP6$F0iqM21Ea3=G1R@fN$V4G3-'
    b'xH1K#2_ZINJ%O(k(n&yAUAoaN*B7)lV0?u4}IxJe+Dp+$xLA?)0oZ-W-^P}%waC`n9mZHa^cU{9oDrInJ7f%d!mt_f-K-'
    b'7m$=Lou5yj*+~6j+xXm5za*qc*<Pnc~%RAolfscIRGhg`1Hv)xoZ3HF^VF^cgA`*#=WFj+Js7w{AQjO}=peD7bO&#h|kNPyAA&qEE6PnVD=Cq(Ct!Paf+R~2'
    b'p^rjDe8NfgWF^ms<<r{&*`@Kyys#AlS)S@<Zs7pQS(}0FFqA^WqN;8_%f|j(RHEn21JKEEMj&!0kUFb?Ty3>Q6^rAO?=u1EPGk_rsWf=3A&k~lhjODCgC97D'
    b'?8rHIo^=x1xo7l`2wz7@w>|iIm*v%gHvXA{7;2?)M%n^=qjN_c(B&Rsd8P0N!^IYH}m$=Lou5yj*+~6j+xXm5za*z8w;31EA%oCpSjOV=IC9inR8{YDc_k7?'
    b'ZpZLrdzVeMg5q!o8Ob~(+jNpVIB%ugR7{U^c#3bQ2lJf_}X-YF%(V8~2r5)|*Ku0<;grN*$I3pOzC`L1ev5aFp6Ud#T^q&#bU-G}4&1!e}N3Z|Se*y7JAb-'
    b'*Z@+&k@z^ye<z;X^0@R9=sJW@JPz+)x@1w3vlP{89W{yZi>P#oeCkAUN_0|gw587Sa*tUv+BZ3GI~-'
    b'Ww=jn@^yCx^JL>+E1W>@!y{#fIz7N{g13NE$K)fkXdFX3t7oVc5;xDT;wJXdC5n93Q&+j0eNSUf0B8Y49Go8Q--pXqdXO;NF^#$liJjwF7>ES0~*qZ#x$YnU'
    b'vkaAXPQ^I$~CV4CF8us?SQQFZlHf;h1ID+P3loUAUkYGW17;8=Cq&{ZD>n7+S7rKbfPm|=t?)b(}SM$qBni$OF#NEfPoBRFhdy1ForXNk&I$AV;IXg#xsG5O'
    b'ky%qn94M!GlQA`!5nmPKo+_*AP-$0kcqDRU*w`2*~DhH1mvXK*v<}ivWwm9VK4jG&jAkp3%TmKzhtWyxfGDGUg0X&xXul3a*NyC`7g?0-'
    b'|?Og|HYZ?|Cz@|{7WVq<uAExG@=uOn8YGBafnMi;*)@cBqA|M_<<k!iKP5YGJfILfXw%IlK&<9O~oIiCJkvx7mx{O_**WVg{)*FJ2}WnE^?EHyyPQ41t>@%3'
    b'R8rl6r(sLC`l<wQ|2$(b9pLIkxEpi3RS5_b!t$PTGXZvb*V>v8qknNG^PnnX-0Ee(2`cPrVVXrM|(QZkxq1`3tj0(cY4s1Ui799eg6}=`3Oe-'
    b'll*)f;{$T^iA-WLQ<xf%txsph-!k?&%w-<)S-?UT{Uv{28j!&+X9X)+#cI~DmUXOW0~^`IX11`EZER-'
    b';JK4o<_OO?I?Eequ{3kiZY0ms_mivF;<6rXsFMQ=&z?XsV2uu)y5{%%4AS9s(O&G!wj_^bvB9VgpW2O*=sDGI)L?;F@iAC&yc|+WPGIK~oVv_I!Kk^ev`I%('
    b'=!ms?s?<6M$DM`g2q$Uk%N%xmoMn*D`nJi=_8`;T0PI8f(Jme)G`6)m_3Q?FM6r~u&DM3j}QJON8r5xp{Kt(E1nJQGJ8r7*mO=?k_I@G1!e_{sHl2-'
    b'p@7So;%bPSlwbfybk=|*>Y{AFI#n?CfVAN~I_!x_Y2hA@<23}*x*8O3PEFp0@bVJg#@&W!)S9B461So&Wy6Z-'
    b'2sXwQFg4s?=Jf0+lJ<y^pA=mHnH#AU8<m1|t*1~<9IZSHW7$2{d3&w0U1Uh$eYyyYG5`M^g$@tH4t<=dZM<b(cWJ{6cC1SJ^32|-'
    b'9g5t=ZBCEVZUS&@iL6r%n)A0isji9t+a5t}%~B_8ofKtd9cm?ZqbkNos6%*s-ehP0$3JsHSICNh(StYjlQImk&aa+8O=<Rd=?C`cg+Q-'
    b'q=vqc|lfNhwNGhO(5SJQb)&B`Q;es#K#oHK<7~YEy^0)T2HPXh<U((}bopqd6^TNh?~@hPJe$Jss#sCpy!Gu5_b2J?Kd<deeu#^rJrm7|0+7GlZcGV>lxi$*'
    b'BM2ta2LDnen%|<(z+GcDabfEMe(iW|=Ek$tqT}hPA9?Jsa4_CN{H$t!!gEJJ=a86Wtv!7v0M~_H%%P9O5uXIQlQlPA_qpD_rFo*SWz>ZgHDC+~pqkdB8&+@t'
    b'7w(<r&X;!AoB8nm4@V9q)twqrdZ!PXY7WFMQ=2fr4581SSYU2}W>25Ry=YCd{8RJHip32t*_jk%>aoVE<!29Gw`%Bo?uWLtNq!p9KGnbL4FQi&=6$@>76<|I'
    b'Tc=#Q#5E{%@TxuV5vsSj`&NvX1p^U?ZE@%oet?jqU7UC%f3q9`>@2{T$#RhXQ8VNB%a?KEX*&ahfv$GwySo=K>eG#AU8<m1|t*1~<9IZSHWFd)(&%4|&96p7'
    b'4}sJm&>3dBtnq@RoPH=K~-4#Am+nHDCrGD7f`cV1f{oU<4-wAqhq3KWE#)|L2)~1R@fN$V4G3-'
    b'xH1K#2_ZIh)o>g5|8*KAR&qV(gFD4KiLCFNh<yzHEBpoI?|JYjASA+S;$H@vXg_H<RUkD$V)!{3_=S~kU|uu2t_GIaY|5<Qk13)WhqB_Do~M1RHh15sYZ2bP'
    b'?K8JrVe$fM|~R5kVZ772~BB6b6U`nR<x!KZD~h)I?$0$bfybk=|*>Y(34*DrVoATM}Gz|kU{^6&c#^9F`fy3>tIazH+mSen9UsKGB2Q;v4DjvVlhit$}*O-'
    b'f|aadHEUSQI@Yt{Z~cxfY-JnU*}+bBv70^rLI>m|r#Q_S&T@|P0sWART;eiUxEjzIxy}u4a*NyC;V$>M&jTLvh{rtPDbIM$i-7LQD_--4x4h#$ANa^8KJ$gI'
    b'eET!x4`KZi_|M(}K?z21LJ*QrgbwjPx-'
    b'H=dPXr<oiO57DD&G_Bzp(?8=HKbTWF`w)$@cH`V)Fh!+>QDFYA5FJ9he6^<Pnc~!qY#0J|X=K$WH+ZQJ5kWr5MF2K}kwcnlhB79ObD%MJiF5DpaK!)u};EYE'
    b'hdy)TJKvX+T37(U>MQr5Vj>K}%ZEnl`kh9qs8rM>^4&E_9_E-'
    b'RVJ3deNIc^ravD8NfgWF_<9?Wf;R5!AM3inlX%J9OIe5L?$trDNJP=)0x3cW-*&N%w-<)S-?UTv6v++Wf{v^!Ae%Knl-Ft9qZY^MmDjTEo@~Q+u6ZRcCnj1>'
    b'}4POIlw^<ahM|<<rv2~!AVYWnlt}mN9xwU(UW?>Lmu&%Cp_gD&w24LcB#IF{KpXWI|BdNM<OV}2p;PH+O-'
    b'Pvm%deaA`p>CL?#MR`JQM*Ck8QzMQq{_mw3b{0SQS&Vv_I!Kk^ev`I%(=!ms?s?<6M$DM`g2q$bV3(Fe;!X0ni#Y-'
    b'A?~ImtzC@{pH&<fi}yDMVq4P?Ta6rvxP_MQO@VmU90abkN$<fsS;dGhOIPH@ee<p7f$OedtTSzjfFKF_<BL>9Y-'
    b'I1S12wZKD~(SjI7)2~1=XlbOO)rZJrv%w!g`nZsP>F`or2WD$#5!cvy8oE5BO6{}gpTGp|i4Qyl+o7uuvwy~WZ>|__a*~4D;v7ZAR<Pe8B!cmTKoD-bn6sI}'
    b'ES<Z2u3tZ$9m$|}Ku5q0k+~gLwxx-'
    b'!Vai0e~<Pnc~!c(5{oEN<06|Z^2Ti)@W4}9bkpa0T7{1#B4_>RD#|K~npa6%B0P=qE7VF^cgA`p>CL?#MR`JQM*Ck8QzMQq{_mw3b{0SQS&Vv_I!Kk^ev`I%'
    b'(=!ms?s?*X036r>~-'
    b'e~_9qq$M5c$v{Rjk(n%HB^%kvK~8d!n>^$tANeUjK?+frA{3<<#VJ8aN>Q3Jl%*WysX#?4QJE@Kr5e?#K}~8=n>y5`9`$KJ!~YldL&q_m34iN~PGKt3n9dAl'
    b'GK<;FVJ`ES&jJ>*h{Y^nDa%;S3Rbe}FFn+?tYbYJ{{LR;{}#Q}*u)_&@rX|X5|W6-B;f~s<R_ByGs*acU-^ySNluEt^j-'
    b'fTHEBpoI?|JYjDPFHW+fZh1G=#}$@Q0xY+mw_p8^!55QQm1QHoKV5|pGAr71&M%2A#QRHPD>sS?n^twwcfP?K8JrVe$fM|~R5kVZ772~BB6b6U`nR<x!KZD~'
    b'h)I?$0$bpA{Cw;SE*@gM8~4`MJw7|Jk)GlG$fVl-nI%Q(g}fr(7|Uv!E8-XUJVLKd<3FP-'
    b'9LEN2BPS;cDBu$FbKX9FAA#Addzm2GTi2RqrtZuYR3eeCA|2RX!Hj&PJ?9OnclImKztaF%nN59mH$<Pw*;!d0$un>*a)9`|{`Lmu&%Cp_gD&w0U1Uh$eYyyY'
    b'G5`M^g$@tH4t<y$~O^3NW2V1f{oU<4-'
    b'wAqhoj!Vs2lgeL+K|D6tZbYc*bSi~j{afwHK5|EHYBqj+z@FPEwl%Gk)FZ{}H{7!OGkdjpVL2A;FmUN^i0~yIgX0ni#Y-'
    b'A?~ImtzC@{pH&0X_5r0bTS$6s8D8DMoQhP?A!VrVM2%M|mnxkxEpi3RS5_b!t$PTGXZvb*V>v8qknNG^PnnX-'
    b'0Ee(2`cPrVVXrM|(QZkxq1`3tj0(cY4s1Ui799ed$Mk1~8C83}y&J8OCr%Fp^P>W(;E)$9N_%kx5Ku3R9WJbY?J<S<Ge*bD78dfIR>US;S(Nu#{yiX9X)+#c'
    b'I~DmUXOW0~^`IX11`EZER-'
    b';JK4o<_OO?I?B@UnImBU(aFk;l=L9D?#c9rPmUEov!vBpu4EO)ZK87be<r&X;!AoB8nm7OAUWXtAB^bd8K}bRo`k(BDi13&F5Rr*ORK6z~(TPD!ViB7-'
    b'#3df_NkBppk(ea>z>oYyQhp{Gzwj%+@jJ;$K}u5b2dPOzTGEl84F6=mMpm+sogCyO7rDtpUh<Kj0u-'
    b'bWg(*T&icy>rl%y1;DMMMxQJxA^q|$%WK9LS|q!XR#LRY%cogVb0*WdP(^rQdZ_LdB02txz*nG9zHBN@eL#xRy~jAsH9nZ#tKFqLUcX9hEw#cbv<mwC)*0Sj'
    b'5gVwSL!Wh`d}D_O;A*07d!tY-'
    b'ro*~DhHu$66WX9qjk#cuYnmwoK#00%k5VUBQ=V;tuMCppDw&Ty7<oaX`;xx{6zaFuIZ=LR>q#cl3zmwVjj0grgh6Q1&n=e*!0uXxQH-tvz30sDYH@`=xU`P;'
    b'sr?+8o~f)bn%gd`N92}4-I5uOM{BodK{LR7vd8qtYCOkxq6IK(9$@ku~J5|NlB{1C8D=_itsj9>YU-'
    b'$_miQj&^4NKG2jl8*FbAS0Q`Oct_|jqKzgC%MQ?9`cfp{1l)dg(yrBic*Z?l%OP~C`}p4QjYRepdyv1OckpBJNvKxtM^>}SM4|YkL)9=7s2(@AYczrb2`(TK'
    b'J=v@{TaYO2LFqDfF?4D$xLA?)0oZ-W-'
    b'^P}%waC`n9l+hvWUejVJXX4&I(qtiq))PE$dj%1~#&Z&1_*S+t|(ycCw4z>|rna*v|nDa)`qm;V8#A&IwL(iqo9oEay1S1uk-'
    b'l%Ut0q*SO9NZgPv;+~F?wxX%L~@`%Sg;VI8}&I?}hir2j1E$?{G2R`zN&wSx4-'
    b'~QZG714c!zyu*E!3a(WLK2G5gdr^92u}ne5{bw}Au8V!jp)Q6Cb5W39O4p>_#_}9iAYQme&9!bA}K$Uj9>Vb-'
    b'}s&6q#z}!_=D7>AuZ`hPX;oQiOggnE7{0S4sw!<+~grI`N&TJ3Q~x|6rm`^C{77VQi{@)p)BPnPX#JciON)=D%Ge?4Qf)0+SH*g^{7t+8q$cyG@&WYXif`S('
    b'u&r!p)KubPX{{EiOzJPE8XZ$4|>vz-'
    b't?g_{pimC1~Q1j3}Gn47|sYrGK$fRVJzbq&jcniiOEc1D$|(G3}!Nm+00=s^O(;97P5%NEMY0jSk4MovWnHLVJ+)e&jvQKiOp<bE8E!44tBDO-'
    b'Rxm6``FI`4swXY9N{R(IL--9a*ETO;VkDk&jl`WiOXE!D%ZHq4Q_Ia+uY$U_qfjk9`cCCJmD$Nc+Lx6@`~5I;VtiY&j&v8iO+oDE8hqd$@(WSK?q7Pf)j#}g'
    b'd#Ly2unD^6M=|CA~I2k%J)PgIx&bzEMgOfxWpqq2}npH5|e}<_>rGT%FiU@7k=e8ekVC8NJ%RGAT?=7OFGh%fsAA#Gg-'
    b'(=HnNk0oa7=mdB{sX@>76<6rwOiC`vJkQ-'
    b'YF|qBLbFOF7C@fr?b3GF7NbHL6pCn$)5;b*M`{>eGORG@>z0Xi77h(}I??qBU)3OFP=rfsS;dGhOIPH@ee<p7f$OedtR+`ZIum3}P@t7|Jk)GlG$fVl-nI%Q'
    b'(g}fr(6FGE<n!G^R6ynapA~bC}CK=Cgo>EMhTBSjsY%vx1eZVl``6%R1JxfsJfpGh5ioHny{ao$O*ad)Ui9_H%%P9O5uXILa}ObApqc;xuPC%Q?<-'
    b'fs0(?GFQ0DHLi1mo800yceu+v?(=|$JmN7=c*--'
    b'L^MaSW;x%u0%RAolfscIRGhg`1Hv&br{s~MFf)b42gdilL2u&Em5{~dhAR>{7OcbK>J<*6x3}O<C*u)_&@rX|X5|W6-B;f~s<R_ByGs*acU-'
    b'^ySNlpq<l8Qe_O&ZdYj`U<8Bbmrd7P69!?BpOPxyVf(@{*7I6rdo5C`=KGQjFr1pd_UzO&Q8kj`CEXB9*926{=E=>eQenwWv)U>QayTG@v1kXiO8D(v0S`pe'
    b'3znO&i+Mj`nn*Bc13>7rN4o?)0E1z35FJ`qGd73}7IG7|alcGK}GjU?ig$%^1cqj`2)jB9oZR6s9tb>C9jzvzW~s<}#1@EMOsvSj-ZZvW(@dU?r<q%^KFSj`'
    b'eI{Bb(UF7PhjD?d)JDyV%Vh_Og%t9N-{_ILr}_a*X4g;3TIw%^A*ej`LjLBA2+#6|QoP>)hZbx46w6?sAX&Jm4XZc+3-'
    b'?@{H%a;3cnk%^TkGj`w`vBcJ%p7ryc>@;?q$_>RB?At=EJP6$F0iqM21Ea3=G1R@fN$V4G3-xH1K#2_ZIh)o>g5|8*KAR&oJOcH+JM}8tHKa-'
    b'4K_?6%Io#dn-'
    b'C8_v>)TALT=}1ooGLnhRWFafr$W9J&l8fBrAusvJPXP*2h{6=1D8(pF2})9m(v+br<tR@DDpHBcRG})>s7?)PQj6Nup)U2PPXij#h{iObDa~k33tG~O*0iB5'
    b'?PyO2I?{>GbfGKV=uQuM(u>~op)dXD&j1E8h`|hDD8m@e2u3oB(Trg%;~38bCNhc1Okpb1n9dAlGK<;FVJ`ES&jJ>*h{Y^nDa%;S3Rbd;)vRG1>)F6YHnEv4'
    b'Y-'
    b'JnU*}+bBv70^YWgq)Fz(Edim?IqJ7{@uuDNb{Svz+5R7r4kJE^~#eT;n=7xXCSUbBDX!<30~~$Ri%}gr_{?IWKv|Yu@mdcf98VANj;*zVMZA0f(r3M__^wlw'
    b'brW1R)7UXu=SdaD*oU5s5@(q7aquiAHo{5R+KMCJu3lM|={HkVGUV2|w^7KarH5NyhIaCj}`<#UG?54QWY7dNPoaOk^etS;<Cra*&f;<R%Y!$wz()P>@0trU'
    b'*qTMsZ3|l2VkW3}q=tc`8tmN>ru_RjEdGYEY9})TRz~sYiVp(2zznrU^}HMsr%wl2){)4Q**hdpgjOPIRUVUFk-'
    b'5deD<z^rjDe=|_JCFpxnEW(Y$W#&AY3l2MFi3}YF`cqTBBNla!6Q<=teW-yak%w`UAna6w<u#iP8W(iAK#&TA$l2xo`4QpA)dN#0;O>AZhTiM2TcCeFO>}C&'
    b'p*~fkkaF9bB<_JeQ#&J$?l2e@K3}-pVc`k5~OI+p(SGmS@Zg7)Z+~y8<xyOAT@Q_D5<_S-E#&cfql2^Ru4R3kJdp_`yPkiPJU-'
    b'=erXwr8CCI~?ZMsPw9l2C*u3}FdJcp?yyNJJ(IQTd)|L?;F@iA8MU5SMtwCjkjbL}HTg13&T;N%@&%{KBvN#_uF21u03zAEYJ?X-'
    b'P+VGLVr>WF`w)$wqc^kds{GCJ%YZM}7)WkU|uu2t_GIaY|5<Qk13)WhqB_Do~M1RHh15sYZ2bP?K8JrVe$fM|~R5kVZ772~BB6b6U`nR<x!KZD~h)I?$0$bf'
    b'ybk=|*>Y(34*DrVoATM}Gz|kU<P)2tygha7HkaQH*8`V;RSICNPmnOlAsGnZ|TxFq2u#W)5?i$9xvBkVPzJ2}@bVa#paCRjg(WYgxy7Hn5RRY-'
    b'S5v*~WHuu#;WvW)FMW$9@iQkV72i2uC@_aZYfOQ=H}uXF11tE^v`cT;>W_xyE&FaFbiy<_>qc$9*2~kVib`2~T;(b6)V0SG?v8Z+XXiKJbxGeC7*Z`4(_s+I'
    b'Ivd2tf%(a6%B0P=qE7VF^cgA`p>CL?#MR`JQM*Ck8QzMQq{_mw3b{0SQS&Vv_I!Kk^ev`I%(=!ms?s?<6M$DM`g2q$Uk%Nk@7zkdaJeCJR}~Ms{+LlU(E`4|'
    b'&N)ehN^KLKLP5MJYycN>Gwgl%@=2DMxuKP?1VhrV3T5Ms;dXlUmfK4t1$VeHze^Ml_}gO=(7RTF{bKw5APhX-9iH(2-'
    b'7brVCx^Mt6G9lV0?u4}IxJe+Dp+K@4UHLm9?!Mlh05jAjgD8OL}gFp)`2W(rf8#&l*dlUdAW4s)5ud={{fMJ#3sOIgNpR<M#)tY!^sS;u-du#rt{W(!-'
    b'{#&&kFlU?j)4}00iehzSuLmcJ^M>)oEPH>V_oaPK?ImdY}aFI(~<_cH2#&vFRlUv;84tKf7eID?TM?B^UPkF|3UhtAvyygvWdB=M`@R3h^<_ll>7I0YNcLXK'
    b'~K?z21LJ*QrgeDAO2}gJ$5RphkCJIsco@hiT1~G|6Y~m1?c*G|G2}wj^lJEmR@)Jq<nPmLJul&aEBqs$aNyQ(eCJkvxM|v`lkxXPJ3t7oVc5;xDT;wJXdC5n'
    b'93Q&+j6s8D8DMoQhP?A!VrVM2%M|mnxkxEpi3RS5_b!t$PTGXZvb*V>v8qknNG^PnnX-'
    b'0Ee(2`cPrVVXrM|(QZkxq1`3tj0(cY4s1Ui799ed$Mk1~8C83}y&J8OCr%Fp^P>W(;E)$9N_%kx5Ku3R9WJbY?J<S<Ge*bD76{7O;>-'
    b'EM^HyS;lf!u##1*W({ju$9gufkxgu73tQR7c6P9nUF>ELd)dc+4seh|9Oei|ImU5LaFSD;<_u>!$9XPrkxN|W3Rk(tb#8EzTioUjce%%X9`KMyJmv{cdB$^I'
    b'@RC=&<_&Lo$9q2TkxzW)3t#yba8T-Z1SSYU2}W>25Ry=YCJbQ-M|dI-kw`=)3Q_r<XhbIlF^NTN;t-'
    b'd3#3um>Nkn3j@B=^c6G{1*Wc<Rf{KoGjCj}`<#UG?54QWY7dNPoaOk^etS;<Cra*&f;<R%Y!$wz()P>@0trU*qTMsZ3|l2VkW3}q=tc`8tmN>ru_RjEdGYEY'
    b'9})TRz~sYiVp(2zznrU^}HMsr%wl2){)4Q**hdpgjOPIRUVUFk-5deD<z^rjDe=|_JCFpxnEW(Y$W#&AY3l2MFi3}YF`cqTBBNla!6Q<=teW-yak%w`UAna6'
    b'w<u#iP8W(iAK#&TA$l2xo`4QpA)dN#0;O>AZhTiM2TcCeFO>}C&p*~fkkaF9bB<_JeQ#&J$?l2e@K3}-'
    b'pVc`k5~OI+p(SGmS@Zg7)Z+~y8<xyOAT@Q_D5<_S-'
    b'E#&cfql2^Ru4R3kJdp_`yPkiR<pKCp)wN5aC6M~S0A~azLOE|(4jp)Q6Cb5W39O4p>_#_}9iAYQme&9!bA}K$Uj9>Vb-'
    b'}s&6q#z}!_=D7>AuZ`hPX;oQiOggnE7{0S4sw!<+~grI`N&TJ3Q~x|6rm`^C{77VQi{@)p)BPnPX#JciON)=D%Ge?4Qf)0+SH*g^{7t+8q$cyG@&WYXif`S('
    b'u&r!p)KubPX{{EiOzJPE8XZ$5BkuTehg#~gBik5hB2HGjARs}8N*n{F`fxbWD=8^!c?X)of*tz7PFbdT;?&K1uSF{i&?@_ma&`_tYj6dS;Jb^v7QZVWD}d&!'
    b'Zx<EgPrVRH+$I2KK65fgB;>8M>xtcj&p*OoZ>WRILkTCbAgLo;xbpb$~CTYgPYvqHg~woJ?`^>hdkmjPk72Rp7Vm2yy7))c*{H9^MQ|i;xk|P%C~@n&A%fsK'
    b'?q7Pf)j#}gd#Ly2unD^6M=|CA~I2k%J)PgIx&bzEMgOfxWpqq2}npH5|e}<_>rGT%FiU@7k=e8ekVC8NJ%RGAT?=7OFGh%fsAA#Gg-'
    b'(=HnNk0oa7=mdB{sX@>76<6rwOiC`vJkQ-'
    b'YF|qBLbFOF7C@fr?b3GF7NbHL6pCn$)5;b*M`{>eGORG@>z0Xi77h(}I??qBU)3OFP=rfsS;dGhOIPH@ee<p7f$OedtR+`ZIum3}P@t7|Jk)GlG$fVl-nI%Q'
    b'(g}fr(6FGE<n!G^R6ynapAibD7T)ma>fHtY9UpSj`&NvX1p^U?ZE@%oetCkfR*qI43yCDNb{Svz+5R7r4kJE^~#eT;n=7xXCSUbBDX!<30~~$Ri%}gr_{?IW'
    b'Kt0D_--4x4h#EU-=gBz=7`wOb~(+jNpVIB%ugR7{U^c@I)XYk%&wbqVhe_h)xV*5{vn9++*3y7PhjD?d)JDyV%Vh_Og%t9N-'
    b'{_ILr}_a*X4g;3TIw%^A*ej<<Xt*EJEH7{nwNv57-m;t`(&B;-'
    b'mw_lx+}JgG@TTGEl8Ok^e}xyVf(@>7t)6rm`^C{77VQi{@)p)BPnPX#JciON)=D%Ge?4Qf)0+SH*g^{7t+8q$cyG@&WYXif`S(u&r!p)KubPX{{EiOzJPE8X'
    b'Z$4|>vz-t?g_{pimC1~Q1j3}Gn47|sYrGK$fRVJzbq&jcniiOEc1D$|(G3}!Nm+00=s^O(;97P5%NEMY0jSk4MovWnHLVJ+)e&jvQKiOp<bE8E!44tBDO-'
    b'Rxm6``FI`4swXY9N{R(IL--'
    b'9a*ETO;VkDk&jl`WiOXE!D%ZHq4Q_Ia+uY$U_qfjk9`cCCJmD$Nc+Lx6@`~5I;VtiY&j&v8iO+oDE8hYhMDiVh2|`eU5u6Z&Bov_uLs-HQo(M!F5|N2QRK6z'
    b'~(TPD!ViB7-#3df_NkBppk(ea>z>oYyQhp{Gzwj%+@jJ;$K}u5b2dPOzTGEl83}hq|naM&{vXPw}<Rlll$wOZ9k)Hw-'
    b'q!5KELQ#rQoD!6z6s0LcS;|qK3RI*Lm8n8is!^R9)T9=*sY6}rQJ)4hq!Ep2LQ|U2oEEgC6|HGQTiVf{4s@gwo#{eXy3w5;^rRQP=|f-'
    b'o(VqbfWDtWH!cc}WoDqy<6r&l#SjI7)2~1=XlbOO)rZJrv%w!g`nZsP>F`or2WD$#5!cvy8oE5BO6{}gpTGp|i4Qyl+o7uuvwy~WZ>|__a*~4D;v7ZAR<Pe8'
    b'B!cmTKoD-bn6sI}ES<Z2u3tZ$9m$|}Ku5q0k+~gLwxx-!Vai0e~<Pnc~!c(5{oEN<06|Z^2Ti)@W4}9bkpZUU9z6Csl=sN-vgrEc?I3Wm0C_)p4u!JK#5r{}'
    b'6A`^wEd`~o@6N8w<A~tb|OFZI}fP^F>F-iD=ANh%-'
    b'{7f=_;a7g+caoEWl%(PhQj><Xq$52U$VetKlZC8gBRe_BNiK4ehrHw?KLsdAAqrE3q7<VzB`8TLN>hfil%qTqs7NI$Q-'
    b'!KjqdGOHNiAwqhq~0GJ`HF{BO23$rZl5DEoezATGNKMw4*&8=tw6z(}k{dqdPt5NiTZShraZqKLZ%ZAO<spp$ua<BN)jjMl*)7jAJ|#n8+k1Gli*4V>&aK$t'
    b'-3whq=sSJ_}gLA{MiRr7UAPD_F@YR<nk+tYbYJ*vKX}vxTi}V>>(8$u4%YhrR4$KL<F-'
    b'Ar5ndqa5QnCpgI|PIHE{oZ~zfxX2|gbA_v1<2pCE$t`Ykhr8V4J`Z@vBOddFr#$01FL=o-'
    b'Uh{^xyyHC|_{b+d^M$W`3wQw8cLXK~K?z21LJ*QrgeDAO2}gJ$5RphkCJIsco@hiT1~G|6Y~m1?c*G|G2}wj^lJEmR@)Jq<nPmLJul&aEBqs$aNyQ(eCJkvx'
    b'M|v`lkxXPJ3t7oVc5;xDT;wJXdC5n93Q&+j6s8D8DMoQhP?A!VrVM2%M|mnxkxEpi3RS5_b!t$PTGXZvb*V>v8qknNG^PnnX-'
    b'0Ee(2`cPrVVXrM|(QZkxq1`3tj0(cY4s1Ui799ed$Mk1~8C83}y&J8OCr%Fp^P>W(;E)$9N_%kx5Ku3R9WJbY?J<S<Ge*bD76{7O;>-'
    b'EM^HyS;lf!u##1*W({ju$9gufkxgu73tQR7c6P9nUF>ELd)dc+4seh|9Oei|ImU5LaFSD;<_u>!$9XPrkxN|W3Rk(tb#8EzTioUjce%%X9`KMyJmv{cdB$^I'
    b'@RC=&<_&Lo$9q2TkxzW)3t#yb@bJO!2uu)y5{%%4AS9s(O&G!wj_^bvB9Vwp6r%Dy(TGkAViJqk#33&6h))6%l8D44;Rk-'
    b'?CzA3r$@qm|`HkO6P6|?zia$tA8q$)E^kg6-naE5QvXYJL<RB-'
    b'x$W0#dl8^ippdf`POc9DwjN+7_B&8@#8Ol<Q@>HNAm8eV=s#1;W)SxD{s7)Q}QjhvHpdpQDOcR>YjOMhUC9P;p8`{#2_H>{lo#;##y3&pA^q?ob=uIE`(vSW'
    b'OU?77S%n*h$jNy!6B%>J37{)S=@l0SMlbFmDrZSD`%wQ(7n9UsKGLQKzU?GcG%o3KejODCgC97D?8rHIo^=x1xo7l`2wz7@w>|iIm*v%gHvXA{7;2?)M%n^='
    b'qjN_c(B&Rsd8P0N!^IYH}m$=Lo{*RXKAqtRX*#c<4wr$(CZQHhO+qP}nwr$(C`|rEfAM8QRBBSy|<*4#5_qfjk9`cCCJmD$Nc+Lx6@`~5I;VtiY&j&v8iO+o'
    b'DE8qCe4}S8C-'
    b'~8b(|Nj5t(f<*UKm;ZTK?z21LJ*QrgeDAO2}gJ$5RphkCJIrBMs#8jlUT$i4snS`d=ik5L?k8&Nl8X>Qjn5Vq$Uk%Nk@7zkdaJeCJR}~Ms{+LlU(E`4|&N)e'
    b'hN^KLKLP5MJYycN>Gwgl%@=2DMxuKP?1VhrV3T5Ms;dXlUmfK4t1$VeHze^Ml_}gO=(7RTF{bKw5APhX-9iH(2-'
    b'7brVCx^Mt6G9lV0?u4}IxJe+Dp+K@4UHLm9?!Mlh05jAjgD8OL}gFp)`2W(rf8#&l*dlUdAW4s)5ud={{fMJ#3sOIgNpR<M#)tY!^sS;u-du#rt{W(!-'
    b'{#&&kFlU?j)4}00iehzSuLmcJ^M>)oEPH>V_oaPK?ImdY}aFI(~<_cH2#&vFRlUv;84tKf7eID?TM?B^UPkF|3UhtAvyygvWdB=M`@R3h^<_ll>#&>@3lVAM'
    b'i4}bah|CbK`kAMUsFhK}PFoF|;kc1*MVF*h&!V`grL?SX#h)Oh~6N8w<A~tb|OFZI}fP^F>F-b^DGLn;ml%ygxX-'
    b'G>t(vyLVWFj+J$VxV{lY^Y(A~$)+OFr^bfI<|f1SKg&Y06NRa+Ie66{$omYEy^0)T2HPXh<U((}bopqd6^TNh?~@hPJe$Jss#sCpy!Gu5_b2J?Kd<deeu#^r'
    b'Jrm7|0+7GlZcGV>lxi$tXrMhOvxeJQJA6BqlS3sZ3)!GnmONW;2Jm%ws+aSjZw4vxKEAV>v5W$tqT}hPA9?Jsa4_CN{H$t!!gEJJ`uCcC&}Q>|;NNIm&TPaF'
    b'SD;<_u>!$9XPrkxN|W3Rk(tb#8EzTioUjce%%X9`KMyJmv{cdB$^I@RC=&<_&Lo$9q2TkxzW)3t#!hcYg4bU;O4T|Nj4?@c$8zKm;ZTK?z21LJ*QrgeDAO2}'
    b'gJ$5RphkCJIrBMs#8jlUT$i4snS`d=ik5L?k8&Nl8X>Qjn5Vq$Uk%Nk@7zkdaJeCJR}~Ms{+LlU(E`4|&N)ehN^KLKLP5MJYycN>Gwgl%@=2DMxuKP?1VhrV'
    b'3T5Ms;dXlUmfK4t1$VeHze^Ml_}gO=(7RTF{bKw5APhX-9iH(2-'
    b'7brVCx^Mt6G9lV0?u4}IxJe+Dp+K@4UHLm9?!Mlh05jAjgD8OL}gFp)`2W(rf8#&l*dlUdAW4s)5ud={{fMJ#3sOIgNpR<M#)tY!^sS;u-du#rt{W(!-'
    b'{#&&kFlU?j)4}00iehzSuLmcJ^M>)oEPH>V_oaPK?ImdY}aFI(~<_cH2#&vFRlUv;84tKf7eID?TM?B^UuX)2;-'
    b'tnFfeB=|K`NCJe@tq(1<QKpB!{7h1noL#+PXr<oiO57DD$$5e3}O<C*u)_&@rX|X5|W6-Bq1ruNKOh;l8V%%AuZ`hPX;oQiOggnE4j%-Uh<Kj0u-'
    b'bWg(*T&icy>rl%y1;DMMMxQJxA^q!N{>LRG3!of_1n7PYBEUFuPv1~jA*jcGztn$esVw4@cSX+vAu(Vh-'
    b';q!XR#LRY%cogVb07rp62U;5FX0SsgigBik5hB2HGjARs}8N*n{F`fxbWD=8^!c?X)of*tz7PFbdT;?&K1uSF{i&?@_ma&`_tYj6dS;Jb^v7QZVWD}d&!dAA'
    b'iogM6C7rWWRUiPt{103WKhdIJgj&Yn5oa7XzIm21bah?lY<Pw*;!d0$uog3Wb7Pq;>UG8z82R!5vk9opVp7ER)yyO+HdBa=Y@tzNS<P)Fy!dJfWoge(<7r*('
    b'#U;Yswx$iOo2}EFm5R_m9Cj=o0MQFkhmT-h80uhNsWTFt2XhbIlF^NTN;t-d3#3um>Nkn3jkd$O3Cj}`<MQYNJmUN^i0~yIgX0ni#Y-'
    b'A?~ImtzC@{pH&<fi}yDMVq4P?Ta6rvxP_MQO@VmU5J*0u`x5WvWn>YE-'
    b'8NHK|2y>QI+@)TaRrX+&e1(3EC0rv)u(MQhs7mUgtK10Cr^XS&dpZgi&yJ?TYn`p}nt^k)DA8N^_QFqB~oX9Ob|#c0MbmT`<{0u!0UWTr5cX-sDZGnvI~<}j'
    b'Ce%x3`$S;S(Nu#{yiX9X)+#cI~DmUXOW0~^`IX11`EZER-'
    b';JK4o<_OO?I?B@UnImBU(aFk;l=L9D?#c9rPmUEov0vEZ&Wv+0QYh33BH@U@a?r@iT+~)xgdBkI$@RVmf=LIi$#cSU1mUq1810VUsXTI>2Z+zzmKl#OP{_vN'
    b'71V|zO1SAlF2|`eU5u6Z&Bov_uLs-HQo(M!F5|N2QRH6}`7{nwNv57-'
    b'm;t`(&BqR}uNkUSRk(?ByBo(PiLt4_2o(yCp6Pd|ER<e<u9ONVyxyeIb@{ykc6r>P^DMC?-'
    b'QJfN#q!gtoLs`mEo(fc?5|yb!RjN^)8q}l~wW&j0>QSEtG^7!YX+l$)(VP~vq!q1cLtEO>o(^=R6P@WoSGv)i9`vLaz3D?=`q7^O3}g_48NyJ8F`N;MWE7(r'
    b'!&t^Ko(W835|f$2RHiYV8O&rBvzfzO<}sfIEMyUjS;A75v78mGWEHDf!&=s{o(*hd6Pww>R<^O79qeQmyV=8D_OYJ>9OMv(Il@tnahwyJ<P@hl!&%O8o(o*$'
    b'5|_EcRjzTJ8{Fg;x4FYz?s1<7Jme9NdBRhk@thaD<Q1=Z!&~0*o)3KF6QB9QSHAI`AN=GOzxl&o{t+Oh{1cEs1SSYU2}W>25Ry=YCJbQ-M|dI-kw`=)3Q>th'
    b'bYc*bSi~j{afwHK5|EHYBqj+-'
    b'Nk(!~kdjoSCJkvxM|v`lkxXPJ3t7oVc5;xDT;wJXdC5n93Q&+j6s8D8DMoQhP?A!VrVM2%M|mnxkxEpi3RS5_b!t$PTGXZvb*V>v8qknNG^PnnX-'
    b'0Ee(2`cPrVVXrM|(QZkxq1`3tj0(cY4s1Ui799ed$Mk1~8C83}y&J8OCr%Fp^P>W(;E)$9N_%kx5Ku3R9WJbY?J<S<Ge*bD76{7O;>-'
    b'EM^HyS;lf!u##1*W({ju$9gufkxgu73tQR7c6P9nUF>ELd)dc+4seh|9Oei|ImU5LaFSD;<_u>!$9XPrkxN|W3Rk(tb#8EzTioUjce%%X9`KMyJmv{cdB$^I'
    b'@RC=&<_&Lo$9q2TkxzW)3t#!hcYg4bU;O3|fB8p%RPs+i0uh)X1SJ^32|-'
    b'9g5t=ZBB^=?2Ktv)DnJ7dh8qtYCOkxq6IK(9$@ku~J5|NlBBqbTiNkK|dk(xB5B^~L>Kt?i=nJi=_8`;T0PI8f(Jme)G`6)m_3Q?FM6r~u&DM3j}QJON8r5x'
    b'p{Kt(E1nJQGJ8r7*mO=?k_I@F~e^=Uvu8qt_0G^H8MX+cX`(V8~2r5)|*Ku0>!nJ#pt8{O$aPkPatKJ=v@{TaYO1~Hf+3}qO@8No<KF`6-'
    b'qWgO#~z(gi7nJG+V8q=A<OlC2gIm~4q^I5<`7O|KmEM*zXS;0zHv6?lkWgY9;z(zK)nJsK(8{65zPIj@IJ?v#4`#Hct4sn<x9OW3tIl)Ozahfxn<s9d^z(p='
    b'`nJZl78rQkOO>S|UJKW_S_j$lW9`TqbJmneBdBICw@tQZh<sI+&z(+punJ;|h8{hfCPk!;6Km6q%0aD990SQE4f)JEo1SbR`2}Nka5SDO+Cjt?PL}a26m1sm'
    b'K1~G|6Y~m1?c*G|G2}wj^l8}^SBqs$aNkwYXkd}0$Cj%MDL}s#(m26}u2RX?_Zt{?qeB`G91t~;ficpkd6sH6wDMe|@P?mC(rveqJL}jW_m1<O{1~sWgZR${'
    b'$deo-@4QWJUn$VPHG^YhEX+>+=(3W<zrvn}7L}$9tm2PyW2R-RUZ~D-'
    b'ee)MMm0~y3%hA@<23}*x*8O3PEFqUzQX95$M#AK#0m1#_81~Zw(Z00bRdCX@43t7Zsmavp%EN2BPS;cDBu$FbKX9FAA#Addzm2GTi2RqrtZuYR3eeCA|2RX!'
    b'Hj&PJ?9OnclImKztaF%nN=K>eG#AU8<m1|t*1~<9IZSHWFd)(&%4|&96p74}sJm&>3dBtnq@RoPH=K~-'
    b'4#Am+nm2Z6K2S546Z~pL?e*{P){{$oufeAuTf)Sh$gd`N92}4-'
    b'I5uOM{BodK{LR6v=ofyO<7O{y#T;dU*1SBL8iAh3Il98Mgq$CxoNkdxFk)8}>Bomp*LRPYoogCyO7rDtpUh<Kj0u-'
    b'bWg(*T&icy>rl%y1;DMMMxQJxA^q!N{>LRG3!of_1n7PYBEUFuPv1~jA*jcGztn$esVw4@cSX+vAu(Vh-'
    b';q!XR#LRY%cogVb07rp62U;5FX0SsgigBik5hB2HGjARs}8N*n{F`fxbWD=8^!c?X)of*tz7PFbdT;?&K1uSF{i&?@_ma&`_tYj6dS;Jb^v7QZVWD}d&!dAA'
    b'iogM6C7rWWRUiPt{103WKhdIJgj&Yn5oa7XzIm21bah?lY<Pw*;!d0$uog3Wb7Pq;>UG8z82R!5vk9opVp7ER)yyO+HdBa=Y@tzNS<P)Fy!dJfWoge(<7r*('
    b'#U;Yswt^5;^Km;ZTK?z21LJ*QrgeDAO2}gJ$5RphkCJIrBMs#8jlUT$i4snS`d=ik5L?k8&Nl8X>Qjn5Vq$Uk%Nk@7zkdaJeCJR}~Ms{+LlU(E`4|&N)ehN^'
    b'KLKLP5MJYycN>Gwgl%@=2DMxuKP?1VhrV3T5Ms;dXlUmfK4t1$VeHze^Ml_}gO=(7RTF{bKw5APhX-9iH(2-'
    b'7brVCx^Mt6G9lV0?u4}IxJe+Dp+K@4UHLm9?!Mlh05jAjgD8OL}gFp)`2W(rf8#&l*dlUdAW4s)5ud={{fMJ#3sOIgNpR<M#)tY!^sS;u-du#rt{W(!-'
    b'{#&&kFlU?j)4}00iehzSuLmcJ^M>)oEPH>V_oaPK?ImdY}aFI(~<_cH2#&vFRlUv;84tKf7eID?TM?B^UPkF|3UhtAvyygvWdB=M`@R3h^<_ll>#&>@3lVAM'
    b'i4}bYbfOPUtKmrk%AOs~C!3jY~LJ^uUge4r|i9kdm5t%4NB^uF*K}=#1n>fTJ9`Q*)LK2afBqSvn$w@&<QjwZ8q$M5c$v{Rjk(n%HB^%kvK~8d!n>^$tANeU'
    b'jK?+frA{3<<#VJ8aN>Q3Jl%*WysX#?4QJE@Kr5e?#K}~8=n>y5`9`$KJLmJVTCN!lP&1pePTG5&|w51*G=|D$1(U~rEr5oMpK~H+on?CfVAN?7?Kn5|GAq-'
    b'_0!x_OyMlqT(jAb0-nZQIQF_|e$Wg63&!Axc`n>oy79`jkiLKd-'
    b'@B`jqb%UQunR<W8jtYsbR*}z6Nv6(GwWgFYs!A^Fun?3AhANx7LK@M@4BOK)z$2q}CPH~zuoaG$nxxhs(ahWSz<r>$y!A)*)n>*a)9`|{`Lmu&%Cp_gD&w0U'
    b'1Uh$eYyyYG5`M^g$@tH4t<s0Am!B2kin?L;J9|6+KKLH6uV1f{oU<4-wAqhoj!Vs2lgeL+Ki9}?g5S3^|Ck8QzMQq{_mw3b{0SQS&Vv>-'
    b'QWF#jADM>|Y(vX&Pq$dLz$wX$dkd<s?CkHvnMQ-wtmwe=>00k*TVTw?cViczYB`HN|%21Yal&1m}sYGR}P?c&_rv^2tMQ!R(mwMEv0S#$HW17&EW;CY-Eont'
    b'-+R&DEw5J0d=|pF`(3Ng<rw2XhMQ{4hmwxnT00SAsV1_W1VGL&kBN@eL#xRy~jAsH9nZ#tKFqLUcX9hEw#cbv<mwC)*0Sj5gVwSL!Wh`d}D_O;A*07d!tY-'
    b'ro*~DhHu$66WX9qjk#cuYnmwoK#00%k5VUBQ=V;tuMCppDw&Ty7<oaX`;xx{6zaFuIZ=LR>q#cl3zmwVjj0S|e^W1jGoXFTTxFL}jl-td-pyypWS`NU_w@Re'
    b'_T=LbLe#c%%bmwyDvApZm;5P=CoP=XPh5QHQYp$S7+!V#VbL?jZCi9%GO5uF&sBo?uWLtNq!p9CZ%5s67cQj(FJ6r>~-sYydx(vhAFWF!-'
    b'r$wF4Lk)0gmBp12KLtgTcp8^!55QQm1QHoKV5|pGAr71&M%2A#QRHPD>sX|q%QJospq!zWQLtW}op9VCf5shg=Q<~A77PO=lt!YDB+R>g4bfgoV=|We!(VZU'
    b'jq!+#ELtpyQp8*VH5Q7=QP=+y_5sYLMqZz|k#xb4=Ok@(1nZi`2F`XIAWEQiT!(8Sup9L&r5sO*EQkJot6|7_xt69TZ*0G)qY-'
    b'AIg*}_(~v7H_4WEZ>H!(R5Wp937^5QjO!QI2t(6P)A}r#Zt}&T*a#T>Nie6sc4^s7RHmSG-As#&Q?fp7flV9ONVyr724}%2R<#G@?BnS;lf!u##1*W({ju#|'
    b'AdBh3)KMC%f3q9u9Dv6I|dTm$=Lou5yj*+~6j+xXl9|@`QK1=K~-4#Am+nm2Z6K2S546Z~pL?e+2xW8AD)#5R_m9Cj=o0MQFkhmT-'
    b'h80uhNsWTFt2XcV9z#VAe*s#2XA)T9=*sY44o(wRjpW(iAK#&TA$l2xo>9UIuhX11`EZER-'
    b';dpX5v&Ty7<oaX`;xx{6zaFy%a;5JWr#&cfql2^Ru4R3kJdp_`yPkiPJU-'
    b'`)|e)EUF{QKX3%{S)>NFV|egrEc?I3Wm0C_)p4u!JK55s6F`(vY4EWG5%N$W2wMF^u7iU?ig$%^1cqj`2)lGE<n!4Cb+rMJ#4DYgoq#PI8LVoZ&3zIL`&Ha*'
    b'gZU;3l`Y%^mJ?kNZ5}A&+>>6Q1&n=e*!0uXxQH-tvz3eBdLW_{<l+@{RBO;`e|33#4~MB{p%1M|={Hog6f$1ubbsYueD3cC@Dho#{eXy3vb)3}OT$S;S(Nu#'
    b'{yiX9X)+#X8orfsJfpGh5ioHny{ao$O*ad)Ui9_H%%P9O5uXILa}ObApqc;xuPC%Q?<-fy-RsI{!02!xE10Bqs$aNkwYXkd}0$Cj%M(o4ZVA3R9WJbY?J<S<'
    b'Ge*b6LnD7PFLPEN2BPS;u+~afEZ6=K>eG#AU8<m1|t*1~>Ullpx+c2}npH5|f0aBqKQ~NJ%PElZLdUBRv_&NG39qg{)*FJ2}WnE^?EHyyT|<1t~;ficpkNl%'
    b'@=2DMxuKQi;k`p(@p=P7P{Oi`vwoF7>ES0~*qZ#x$WR&1g;wTGEQvw4p8SXio<^(uvM=p)1|!P7iw0i{A91Fa7Ax00uIM!3<$2!x+v8Mly=gjA1O}7|#SIGK'
    b'tAdVJg#@&J1QUi`mR!F7uer0v57}#Vlbd%UI3|R<erKtYIzdSkGzBa*p#{<sYFPGQtp+L?k9D$w*ELQj&_)q#-ToNY7}-'
    b'FqUzQX95$M#AK#0lUdAWF7uer0v58Io$O*aM>)oEPH>V_oaPK?ImdY}aD#h%Bvdf#A{x<&K}=#1n>fTJ9`Q*)LK2afBqSvn$w@&<QjwZ8q$M5c$v{Rjk(sPy'
    b'BRe_BNiOnJfPxgFFhwXvaY|5<Qk13)WhqB_Do~M1RHh15sYZ2bP?K8JrVe$fM|~R5kVZ772~BB6b6U`nR<x!KZD~h)I?$0$bfybk=|*>Y(34*DrVoATM}Gz|'
    b'kU<P)2tygha7HkaQH*8`V;RSICNPmnOlAsGnZ|TxFq2u#W)5?i$9xvBkVPzJ347Vk0S<D4j|2+tTtg6o5u5@P<SN&=&JAvIi`(4cF88?410M32Cp_gD&-'
    b'utFKJ$gIeB(Pm_{lGR^M}9x)e=H2gdilL2}4%0k)0gmq&hXINiAwqhq~0GJ`HF{BO23$rZl5DEoezATGNKMw4*&8=tw6z(}k{dV>lxi$ymlQi9h@$P)I!{2<'
    b'd1=YueD3cC@Dh9qB}8y3mzwbf*VB=|yk)(3gJnX8;2k#9)Rnlwk~K1S1*6XvQ#>ag1jI6Pd(hrZAP6%wjg1*}_hCv70^YWgq)Fz(Edim?IqJ7{@umNltN^Go'
    b'0ld=efW|E^(PFT;&?qxxr0tahp5b<sSEWz(XGKm?u2t8P9paOJ4DsH@xK?@A<$-'
    b'KJl3^eB~S8`N2<q@tZ&V<sSh;IfD_9Km;ZTK?z21LJ*QrgeDAO2}gJ$5RphkCJIrBMs#8jlMG}e7rDtp0SZ%uy7Zwh0~y3%hA@<23}*x*nav#LGLQKzU?GcG'
    b'%o3KejODChEjRvKcWAW}kw`=)3Q;LeNmg)^TioUjce%%X9`KMyJmv{cdBzJ~@`~4d<s0Am!B2kin?L;J9|6LsjevwAG+_u!cp{LKT;wJXwW&j0>QSEtG^7!Y'
    b'X+l$)(VP~vq!q1cLtEO>o(^=R6P@WoSGv)i!3<$2BN)jj#_@x{{3AeE-)-'
    b'tqp9VCf5shg=Q<~A77PO=lt!YDB+R>g4bfgoV=|We!(VZUjq!+#ELtpyQp8*VH5Q7=QP=+y_5sYCh<5<RW*07d!tY-'
    b'ro*~DhHu$66WX9qjk#cuYnmwoK#00%k5VUBQ=V;tuMCppDw&Ty7<oaX`;xx{6zaFuIZ=LR>q#cl3zmwVjj0S|e^W1jGoXFTTxFL}jl-td-pyypWS`NU_w@Re'
    b'_T=LbLe#c%%bmwyBZXO9z*Km;ZTK?z21LJ*QrgeDA$NK6{ik%{uOr5&B<Oc%P+jqdcIC%qWMSjI7)2~1=XlbOO)rZJrv6e;`PUswYK_&;_))yx'
)


@functools.lru_cache(maxsize=1)
def replacement_hpl():
    data = zlib.decompress(base64.b85decode(_PAYLOAD))
    if len(data) != REPLACEMENT_HPL_BYTES or hashlib.sha256(data).hexdigest() != REPLACEMENT_HPL_SHA256:
        raise ValueError('embedded supplied Rey HPL failed its integrity check')
    return data


def _path(path):
    return os.path.normcase(os.path.abspath(os.fspath(path)))


def _character(path):
    # Matches folder.convert_folder's source char_dir, including slot mapping.
    return os.path.dirname(os.path.dirname(_path(path)))


def _fingerprint(path):
    digest = hashlib.sha256()
    size = 0
    with builtins.open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
            size += len(block)
    return digest.hexdigest(), size


def _array(value):
    """Compare every element/shape without adding a numpy dependency."""
    if hasattr(value, 'shape') and hasattr(value, 'tobytes'):
        return (tuple(value.shape), str(value.dtype), value.tobytes(order='C'))
    if isinstance(value, (list, tuple)):
        return tuple(_array(item) for item in value)
    return value


def _mapping(mesh):
    count = operator.index(mesh.num_verts)
    if count <= 0:
        raise ValueError('mask mesh has no vertices')
    table = mesh.vertex_remap
    if table is None:
        values = tuple(range(count))
    else:
        if len(table) != count:
            raise ValueError('vertex-remap length differs from vertex count')
        values = tuple(operator.index(value) for value in table)
        if any(value < 0 or value >= 2**32 for value in values):
            raise ValueError('vertex-remap index is outside its uint32 domain')
    # The original converter nudges coincident face vertices by 0.02 mm.
    # HPL addresses the remap domain, so topology/order must remain identical
    # while those documented position adjustments remain allowed.
    triangles = tuple(tuple(operator.index(index) for index in row)
                      for row in mesh.triangles)
    if any(len(row) != 3 for row in triangles):
        raise ValueError('paired base triangle layout is unsupported')
    return count, values, triangles


def _body_mappings(model):
    result = {}
    for name in _BODY_MESHES:
        meshes = [mesh for mesh in model.meshes if mesh.name == name]
        if not meshes:
            raise ValueError('paired base has no ' + name)
        result[name] = tuple(_mapping(mesh) for mesh in meshes)
    return result


def _domains(mappings):
    return {name: set(value for mesh in meshes for value in mesh[1])
            for name, meshes in mappings.items()}


def _mask_limits(limits):
    return {name: operator.index(limits[name]) for name in _BODY_MESHES}


def validated_paired_base(source_path):
    """Return the current exact-Rey base only after rechecking the real pair.

    Used by the optional reference surface policy. Never a nearest-file search
    or a donor from another conversion job.
    """
    job = getattr(_context, 'job', None)
    if job is None or _fingerprint(source_path) != (REY_MODEL_SHA256, REY_MODEL_BYTES):
        raise ValueError('reference surface weights require the exact supplied Rey attire in a folder conversion')
    record = job['bases'].get(_character(source_path))
    if record is None or not record.get('verified'):
        raise ValueError('reference surface weights require the verified paired BaseModel/baseModel.mcd')
    if _fingerprint(record['source']) != (SOURCE_BASE_SHA256, SOURCE_BASE_BYTES):
        raise ValueError('paired source base changed after conversion')
    if _fingerprint(record['output']) != record['output_fingerprint']:
        raise ValueError('paired converted base changed after verification')
    vc, limits = job['vc'], job['mask_limits']
    source, output = vc.read_model(record['source']), vc.read_model(record['output'])
    if output.version != vc.VERSION_2K26 or _body_mappings(source) != record['mapping'] or _body_mappings(output) != record['mapping']:
        raise ValueError('paired base topology changed after verification')
    if _mask_limits(limits(source)) != record['limits'] or _mask_limits(limits(output)) != record['limits']:
        raise ValueError('paired base remap domain changed after verification')
    return output, record['output_fingerprint'][0]


def _clone(function, namespace):
    clone = types.FunctionType(function.__code__, namespace, function.__name__,
                               function.__defaults__, function.__closure__)
    clone.__kwdefaults__ = function.__kwdefaults__
    return clone


def _functions(function):
    seen = set()
    while isinstance(function, types.FunctionType) and id(function) not in seen:
        seen.add(id(function))
        yield function
        function = getattr(function, '__wrapped__', None)


def install(convert_module, folder_module, vcmodel_module=None):
    """Install after gear wrappers and before the inventory/report wrapper.

    Recovery is available only inside one convert_folder job that has already
    converted the exact supplied source base through the original converter.
    Nonmatching inputs retain the original unreadable-mask handling.
    """
    if getattr(convert_module, '_mask_recovery_patch', None) == PROFILE_VERSION:
        return
    original_expected = convert_module.expected_mask
    original_convert = convert_module.convert_mcd
    original_verify = convert_module.verify
    original_folder = folder_module.convert_folder
    original_limits = convert_module.mask_limits
    vc = vcmodel_module if vcmodel_module is not None else convert_module.vc
    mcd = convert_module.mcd

    def register_base(bound, report):
        job = getattr(_context, 'job', None)
        if job is None or not isinstance(report, dict) or not report.get('kind', '').startswith('base model'):
            return
        src, dst = bound.arguments['src_path'], bound.arguments['dst_path']
        key = _character(src)
        # A different subsequently selected base invalidates an earlier pair.
        job['bases'].pop(key, None)
        try:
            if _path(src) == _path(dst) or _fingerprint(src) != (SOURCE_BASE_SHA256, SOURCE_BASE_BYTES):
                return
            source, output = vc.read_model(src), vc.read_model(dst)
            if output.version != vc.VERSION_2K26:
                return
            source_mapping, output_mapping = _body_mappings(source), _body_mappings(output)
            if source_mapping != output_mapping:
                return
            source_limits = _mask_limits(original_limits(source))
            output_limits = _mask_limits(original_limits(output))
            # Eye splitting and overlay removal change unrelated base meshes.
            if source_limits != output_limits or _mask_limits(report.get('mask_limits', {})) != output_limits:
                return
            job['bases'][key] = {'source': _path(src), 'output': _path(dst),
                                 'output_fingerprint': _fingerprint(dst),
                                 'limits': output_limits, 'mapping': source_mapping,
                                 'verified': False}
        except Exception:
            # Native read/mapping failures cannot broaden this exact override.
            return

    def recovery(hpl_path, body_limits):
        current, job = getattr(_context, 'current', None), getattr(_context, 'job', None)
        if current is None or job is None or _path(hpl_path) != current['hpl']:
            return None
        try:
            if _fingerprint(current['source']) != (REY_MODEL_SHA256, REY_MODEL_BYTES):
                return None
            if _fingerprint(hpl_path) != (SOURCE_HPL_SHA256, SOURCE_HPL_BYTES):
                return None
            record = job['bases'].get(_character(current['source']))
            if record is None or not record.get('verified') or body_limits is None or _mask_limits(body_limits) != record['limits']:
                return None
            if _fingerprint(record['source']) != (SOURCE_BASE_SHA256, SOURCE_BASE_BYTES):
                return None
            if _fingerprint(record['output']) != record['output_fingerprint']:
                return None
            source, output = vc.read_model(record['source']), vc.read_model(record['output'])
            if output.version != vc.VERSION_2K26:
                return None
            source_mapping, output_mapping = _body_mappings(source), _body_mappings(output)
            if source_mapping != record['mapping'] or output_mapping != source_mapping:
                return None
            if _mask_limits(original_limits(source)) != record['limits'] or _mask_limits(original_limits(output)) != record['limits']:
                return None
            data = replacement_hpl()
            if not mcd.hpl_is_whole(data):
                return None
            masks = mcd.parse_hpl(data)
            if set(masks) != {0, 1} or masks[0] != masks[1]:
                return None
            domains = _domains(source_mapping)
            entries = [entry for lod in masks.values() for entries in lod.values() for entry in entries]
            if not entries or any(name not in domains or not indices or
                                  any(index not in domains[name] for index in indices)
                                  for name, indices in entries):
                return None
            return data, record
        except Exception:
            return None

    @functools.wraps(original_expected)
    def expected_mask(*args, **kwargs):
        bound = inspect.signature(original_expected).bind(*args, **kwargs)
        bound.apply_defaults()
        path = bound.arguments['hpl_path']
        selected = recovery(path, bound.arguments['body_limits'])
        if selected is None:
            return original_expected(*args, **kwargs)
        data, base = selected
        namespace = dict(original_expected.__globals__)
        original_open = namespace.get('open', builtins.open)

        def supplied_open(file, mode='r', *open_args, **open_kwargs):
            if mode == 'rb' and _path(file) == _path(path):
                return io.BytesIO(data)
            return original_open(file, mode, *open_args, **open_kwargs)

        namespace['open'] = supplied_open
        result = _clone(original_expected, namespace)(*args, **kwargs)
        if result[1] == 'mask' and not result[2]:
            current = _context.current
            current['recovery'] = {
                'profile': PROFILE_VERSION,
                'source_sha256': SOURCE_HPL_SHA256, 'source_bytes': SOURCE_HPL_BYTES,
                'replacement_sha256': REPLACEMENT_HPL_SHA256, 'replacement_bytes': REPLACEMENT_HPL_BYTES,
                'source_model_sha256': REY_MODEL_SHA256,
                'paired_source_base_sha256': SOURCE_BASE_SHA256,
                'selected_converted_base_sha256': base['output_fingerprint'][0],
                'runtime_mask_limits': dict(base['limits']),
                'source_to_converted_vertex_remap': 'all_body_head_mappings_and_topology_equal',
                'supplied_mask_lod_arrays': 'LOD0_and_LOD1_all_flags_all_indices_equal',
                'original_source_unchanged': True,
                'method': 'verified_supplied_hpl_through_original_parser_filter_writer',
                'in_game_validation': 'required',
            }
        return result

    def run_scoped(function, args, kwargs):
        bound = inspect.signature(function).bind(*args, **kwargs)
        bound.apply_defaults()
        src = bound.arguments['src_path']
        previous = getattr(_context, 'current', None)
        current = {'source': _path(src), 'hpl': _path(os.path.splitext(os.fspath(src))[0] + '.hpl')}
        _context.current = current
        try:
            return function(*args, **kwargs), current, bound
        finally:
            _context.current = previous

    @functools.wraps(original_convert)
    def convert_mcd(*args, **kwargs):
        report, current, bound = run_scoped(original_convert, args, kwargs)
        register_base(bound, report)
        if current.get('recovery') is not None and isinstance(report, dict):
            report['hide_mask_recovery'] = current['recovery']
            report.setdefault('notes', []).append(
                'Restored this exact Rey hide mask from the verified user-supplied HPL; '
                'the selected paired base and every Body/Head vertex-remap index were checked. '
                'Original source files were retained. Entrance/gameplay validation is required.')
        return report

    @functools.wraps(original_verify)
    def verify(*args, **kwargs):
        bound = inspect.signature(original_verify).bind(*args, **kwargs)
        job = getattr(_context, 'job', None)
        key = _character(bound.arguments['src_path'])
        record = job['bases'].get(key) if job is not None else None
        paired = (record is not None and record['source'] == _path(bound.arguments['src_path'])
                  and record['output'] == _path(bound.arguments['dst_path']))
        if paired:
            record['verified'] = False
        try:
            result, current, _bound = run_scoped(original_verify, args, kwargs)
        except Exception:
            if paired:job['bases'].pop(key, None)
            raise
        if paired:
            if isinstance(result, tuple) and len(result) == 3 and result[0]:
                record['verified'] = True
            else:
                job['bases'].pop(key, None)
        if current.get('recovery') is not None and isinstance(result, tuple) and len(result) == 3 and isinstance(result[2], dict):
            result[2]['hide_mask_recovery'] = current['recovery']
        return result

    @functools.wraps(original_folder)
    def convert_folder(*args, **kwargs):
        previous_job = getattr(_context, 'job', None)
        previous_current = getattr(_context, 'current', None)
        _context.job, _context.current = {'bases': {}, 'vc': vc, 'mask_limits': original_limits}, None
        try:
            return original_folder(*args, **kwargs)
        finally:
            _context.job, _context.current = previous_job, previous_current

    # Original consumers resolve expected_mask in their defining globals.
    # Follow existing functools wrappers, including isolated cloned namespaces.
    for consumer in (original_convert, original_verify,
                     getattr(convert_module, '_sidecar_streams', None),
                     getattr(convert_module, '_check_mask', None)):
        for function in _functions(consumer):
            function.__globals__['expected_mask'] = expected_mask
            for name in ('_sidecar_streams', '_check_mask'):
                for nested in _functions(function.__globals__.get(name)):
                    nested.__globals__['expected_mask'] = expected_mask
    convert_module.expected_mask = expected_mask
    convert_module.convert_mcd = convert_mcd
    convert_module.verify = verify
    folder_module.convert_folder = convert_folder
    convert_module._mask_recovery_patch = PROFILE_VERSION
