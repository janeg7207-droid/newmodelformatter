"""Exact supplied Bryan/Flip ocular anchor correspondence, appearance unverified.

All 446 Cena caruncle UV coordinates occur exactly once in the supplied heads.
Their 672-face oriented charts are accounted for by 352 identical triangles
and 160 quad diagonal swaps preserving every oriented surface boundary.
Only eight existing GtPt vertex fields change; no mesh, color, material,
texture, mask, weight or physics data is created or modified.
"""
import copy
import functools
import inspect
import os
from pathlib import Path
import struct
import tempfile

from gmf_tongue_anchor import fingerprint, read_points, _safe_output
from gmf_material_formats import classify_material_library
from gmf_jmtl_audit import inspect_material
from gmf_eye_defaults import prepare_eye_defaults
from gmf_2k26_repair import read_native_library, game_folder, path_hash


PATCH_VERSION = 'exact-supplied-bryan-flip-cena-ocular-anchors-1'
REFERENCE_SHA256 = 'bb0176e86fc2e74cebc61058acac1fa3103c7a859f2e54a2196947fe95ee4a1c'
REFERENCE_VERTICES = (127, 263, 294, 295, 148, 361, 392, 393)
REFERENCE_UVS = (
    (.9703190922737122, .9826304316520691),
    (.5854731202125549, .647385835647583),
    (.5885218977928162, .6375324726104736),
    (.6163280010223389, .6428414583206177),
    (.029505789279937744, .9826304316520691),
    (.4140169024467468, .647385835647583),
    (.4109681248664856, .6375324726104736),
    (.3831620216369629, .6428414583206177),
)
BRYAN_LEGACY = ('343eede12271859708f75b52deb28c92fae9fe5983dcbb7d37cd0684378d4f67', 5881276)
BRYAN_BEFORE_TONGUE = ('9727b9f46c18eb54d4eb11a40fdf98a25d8b3ca4aac135c2b26be2714e9fad60', 6688516)
BRYAN_BEFORE_EYE = ('19956b0ba487d68f90999d86a3837d695b3b14c0c79763d46cebc5814a1ac4ba', 6688516)
BRYAN_COMPLETE = ('c3edf08a7b65f4d3a4f327cba3b156435465d9724b4f8068a35c5b88b1cf6208', 6688516)
BRYAN_OLD_VERTICES = (4118, 4102, 4105, 4111, 3944, 4266, 4269, 4276)
BRYAN_NEW_VERTICES = (3910, 3997, 4053, 4057, 3945, 4161, 4219, 4222)
FLIP_LEGACY = ('6670af89dc43b0d95e44d70f715bb9033cf449010f3430de2978fd63884b495c', 6043100)
FLIP_BEFORE_TONGUE = ('1ec8da39b5d85554b6fbcb3aa71782ebbaf665868f35e30734aa6a30c8a128dc', 6800912)
FLIP_BEFORE_EYE = ('8ef00213999d1921c7b0adea4dc4afa9389ea71579b43556a9ce9f84e2e0ae0b', 6800912)
FLIP_COMPLETE = ('32fe8b4697cf01fd1068191fde7f9b9be6cc979ccd7a5fffc2896e6345c31302', 6800912)
FLIP_OLD_VERTICES = (3914, 4108, 4108, 4118, 3949, 4279, 4306, 4314)
FLIP_NEW_VERTICES = (3916, 4001, 4059, 4063, 3951, 4169, 4231, 4234)


def profiles():
    return (
        {'name': 'Bryan', 'legacy': BRYAN_LEGACY, 'before_tongue': BRYAN_BEFORE_TONGUE,
         'before_eye': BRYAN_BEFORE_EYE, 'complete': BRYAN_COMPLETE,
         'old_vertices': BRYAN_OLD_VERTICES, 'new_vertices': BRYAN_NEW_VERTICES,
         'head_vertices': 4375, 'authored_cross_boundary_triangles': 17},
        {'name': 'Flip Gordon', 'legacy': FLIP_LEGACY, 'before_tongue': FLIP_BEFORE_TONGUE,
         'before_eye': FLIP_BEFORE_EYE, 'complete': FLIP_COMPLETE,
         'old_vertices': FLIP_OLD_VERTICES, 'new_vertices': FLIP_NEW_VERTICES,
         'head_vertices': 4382, 'authored_cross_boundary_triangles': 0},
    )


def source_profile(identity):
    matches = [p for p in profiles() if identity in
               (p['legacy'], p['before_tongue'], p['before_eye'], p['complete'])]
    if len(matches) > 1:
        raise ValueError('ocular source profile is ambiguous')
    return matches[0] if matches else None


def provenance(profile):
    return {'native_cena_reference_sha256': REFERENCE_SHA256,
            'native_reference_mesh': 'M_Head_Caruncle', 'target_existing_mesh': 'M_Head',
            'slots': list(range(5, 13)), 'reference_vertices': list(REFERENCE_VERTICES),
            'target_vertices': list(profile['new_vertices']),
            'exact_unique_uv_vertex_correspondence': 446,
            'oriented_chart_triangles': 672, 'identical_oriented_triangles': 352,
            'quad_diagonal_swaps_with_identical_oriented_boundaries': 160,
            'all_remaining_triangles_consumed_once': True,
            'entire_chart_oriented_boundary_identical': True,
            'authored_cross_boundary_triangles_preserved': profile['authored_cross_boundary_triangles'],
            'scope': 'selected caruncle chart correspondence; full-head topology identity and in-game appearance are not established',
            'selection': 'unique exact chart UV identity, complete oriented surface proof; no raw reference index copy or nearest-position guess'}


def _replace_points(data, profile):
    points, strings, offsets = read_points(data)
    by_slot = {p[2]:i for i,p in enumerate(points)}
    if points[by_slot[4]] != ('_ag_0004', 'M_Tongue', 4, 127):
        raise ValueError('ocular correction requires the reviewed tongue anchor first')
    old = [('_ag_%04d' % slot, 'M_Head', slot, vertex)
           for slot,vertex in zip(range(5,13), profile['old_vertices'])]
    new = [('_ag_%04d' % slot, 'M_Head', slot, vertex)
           for slot,vertex in zip(range(5,13), profile['new_vertices'])]
    actual = [points[by_slot[slot]] for slot in range(5,13)]
    if actual == new:
        return data, [], points
    if actual != old:
        raise ValueError('ocular points differ from the reviewed profile')
    changed = bytearray(data)
    permitted = set()
    expected = list(points)
    for point in new:
        index = by_slot[point[2]]
        position = offsets[index] + 6
        struct.pack_into('<H', changed, position, point[3])
        permitted.update((position, position+1))
        expected[index] = point
    changed = bytes(changed)
    after, _, _ = read_points(changed)
    differences = [i for i,(a,b) in enumerate(zip(data,changed)) if a != b]
    if after != expected or len(data) != len(changed) or not set(differences).issubset(permitted):
        raise ValueError('ocular correction changed non-target records or bytes')
    return changed, differences, after


def candidate_bytes(data, profile=None):
    identity = fingerprint(data)
    if profile is None:
        matches = [p for p in profiles() if identity in (p['before_eye'], p['complete'])]
        if len(matches) != 1:
            raise ValueError('ocular output is not an exact inspected profile')
        profile = matches[0]
    if identity not in (profile['before_eye'], profile['complete']):
        raise ValueError('ocular output does not match its exact source profile')
    changed, differences, points = _replace_points(data, profile)
    if fingerprint(changed) != profile['complete']:
        raise ValueError('ocular result does not match its reviewed fingerprint')
    return changed, differences, points


def _validate_native(model, points, profile):
    if [tuple(p) for p in model.goto_points] != points:
        raise ValueError('native reader disagrees with ocular records')
    heads = [m for m in model.meshes if m.name == 'M_Head']
    tongues = [m for m in model.meshes if m.name == 'M_Tongue']
    if len(heads) != 1 or heads[0].num_verts != profile['head_vertices'] or not heads[0].uvs:
        raise ValueError('native reader did not validate the existing head domain')
    if len(tongues) != 1 or tongues[0].num_verts != 341:
        raise ValueError('native reader did not validate the preserved tongue domain')
    for vertex, uv in zip(profile['new_vertices'], REFERENCE_UVS):
        if not 0 <= vertex < heads[0].num_verts or tuple(map(float,heads[0].uvs[0][vertex])) != uv:
            raise ValueError('native reader did not validate the exact ocular UV target')


def _preflight_metadata(report, record):
    if type(record.get('facts', {})) is not dict:
        raise ValueError('ocular model facts are not a dictionary')
    for field in ('problems','warnings'):
        if field in report and type(report[field]) is not list:
            raise ValueError('ocular report ' + field + ' is not a list')
    if record.get('status') == 'preserved_2k26' and type(report.get('native_2k26_models_preserved',0)) is not int:
        raise ValueError('ocular native preservation counter is invalid')
    if 'experimental_tongue_anchor' in record and not isinstance(record['experimental_tongue_anchor'],dict):
        raise ValueError('ocular preceding tongue proof is malformed')


def _path_key(path):
    return os.path.normcase(str(Path(path).resolve()))


def _material_file(path, root):
    path = Path(path)
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('ocular paired material leaves the output folder')
    if path.is_symlink() or any(parent.is_symlink() for parent in path.parents if parent != root.parent):
        raise ValueError('ocular paired material path contains a symlink')
    if not path.is_file():
        raise ValueError('ocular paired material is missing: ' + path.name)
    return path.read_bytes()


def _material_guard(report, source, output, profile, source_identity):
    """Require real supported paired output data; never synthesize materials."""
    root = Path(report['output'])
    mtls = output.with_suffix('.mtls')
    raw = _material_file(mtls, root)
    library = classify_material_library(raw)
    if not library.get('safe_as_native'):
        raise ValueError('ocular paired Base MTLS is unsupported: ' + library['classification'])
    if not all(library.get('material_names', []).count(name) == 1 for name in ('eye_l', 'eye_r')):
        raise ValueError('ocular paired Base MTLS is missing unique eye_l/eye_r entries')
    virtual = game_folder(mtls)
    if virtual is None:
        raise ValueError('ocular paired Base MTLS has no contained Characters virtual path')
    bindings = {entry['name']: entry['path_hash'] for entry in read_native_library(raw)}
    for name in ('eye_l', 'eye_r'):
        if bindings[name] != path_hash(virtual + '/Materials/' + name + '.jmtl'):
            raise ValueError('ocular paired Base MTLS does not bind the actual local ' + name + ' payload')
    rows = [row for row in report.get('materials', []) if isinstance(row, dict)
            and row.get('output') and _path_key(row['output']) == _path_key(mtls)]
    if len(rows) > 1:
        raise ValueError('ocular paired Base MTLS report is ambiguous')
    legacy = source_identity == profile['legacy']
    if legacy and not rows:
        raise ValueError('ocular paired Base MTLS conversion report is missing')
    row = rows[0] if rows else None
    if row is not None:
        if row.get('problems') or str(row.get('status', '')).startswith(('unsupported', 'failed')):
            raise ValueError('ocular paired Base MTLS conversion failed: ' + str(row.get('status', 'unknown')))
        if legacy and (row.get('status') != 'converted' or not row.get('source')
                       or _path_key(row['source']) != _path_key(source.with_suffix('.mtls'))):
            raise ValueError('ocular paired Base MTLS has no successful matching source conversion')
    directory = output.parent / 'Materials'
    for policy in report.get('eye_scalar_policy', {}).get('rows', []):
        if (isinstance(policy, dict) and policy.get('output')
                and _path_key(Path(policy['output']).parent) == _path_key(directory)
                and policy.get('state') == 'eye_policy_not_applied'):
            raise ValueError('ocular paired Base eye scalar policy failed: ' + str(policy.get('reason', 'unknown')))
    snapshots = [(mtls, raw)]
    facts = {'scope': 'actual paired native Base MTLS and ordinary-eye payloads; in-game texture resolution and appearance not established',
             'mtls': str(mtls), 'mtls_sha256': fingerprint(raw)[0],
             'mtls_classification': library['classification'],
             'legacy_paired_conversion_required': legacy,
             'local_eye_material_table_bindings_verified': True, 'eye_payloads': []}
    for name in ('eye_l', 'eye_r'):
        path = directory / (name + '.jmtl')
        data = _material_file(path, root)
        inspected = inspect_material(data)
        if (inspected['shader_byte'] != 0x12 or not inspected['texture_schema_supported']
                or not inspected.get('face_texture_check', {}).get('required_color_and_normal_refs_present')):
            raise ValueError('ocular paired ' + name + ' is not a supported ordinary-eye payload with color/normal references')
        prepared, policy = prepare_eye_defaults(data)
        if prepared != data or policy.get('state') != 'already_policy_values':
            raise ValueError('ocular paired ' + name + ' has not completed the required eye scalar policy')
        if legacy:
            audited = [item for item in row.get('written_material_payload_audit', [])
                       if isinstance(item, dict) and item.get('name') == name]
            if (len(audited) != 1 or audited[0].get('state') != 'payload_inspected'
                    or audited[0].get('shader_byte') != 0x12
                    or audited[0].get('texture_schema_supported') is not True
                    or not audited[0].get('file') or _path_key(audited[0]['file']) != _path_key(path)
                    or audited[0].get('sha256') != fingerprint(data)[0]):
                raise ValueError('ocular paired ' + name + ' emitted payload audit is missing, failed or stale')
        snapshots.append((path, data))
        facts['eye_payloads'].append({'name': name, 'file': str(path), 'sha256': fingerprint(data)[0],
                                     'shader_byte': 0x12, 'eye_scalar_policy': dict(policy['values_after'])})
    return snapshots, facts


def _materials_unchanged(snapshots, root):
    if any(_material_file(path, root) != data for path, data in snapshots):
        raise ValueError('ocular paired material changed during validation')


def _provenance_updates(report, record, source, before_sha, after_sha):
    """Retain pre-patch proofs and explicitly link their following byte stage."""
    updates = []
    previous_tongue = record.get('experimental_tongue_anchor')
    link = {'version':PATCH_VERSION, 'before_sha256':before_sha, 'after_sha256':after_sha,
            'slot4_and_all_other_non_target_bytes_preserved':True,
            'slots_changed':list(range(5,13)), 'geometry_weights_masks_and_other_substreams_preserved':True}
    if previous_tongue is not None:
        if previous_tongue.get('after_sha256') != before_sha:
            raise ValueError('ocular preceding tongue proof does not match the current byte stage')
        updates.append((previous_tongue, {'output_byte_proof_stage':'before following ocular-only correction',
                                        'following_ocular_anchor_correction':copy.deepcopy(link)}))
    source_key = os.path.normcase(str(source.resolve()))
    for row in report.get('models',[]):
        if not isinstance(row,dict):continue
        for holder in (row,row.get('facts',{})):
            if not isinstance(holder,dict):continue
            recovery = holder.get('supplied_hide_mask_recovery')
            if not isinstance(recovery,dict):continue
            paired = recovery.get('paired_source_base')
            if not paired or os.path.normcase(str(Path(paired).resolve())) != source_key:
                continue
            if recovery.get('paired_output_base_sha256') != before_sha:
                raise ValueError('ocular paired mask proof does not match the current byte stage')
            old_patch = recovery.get('paired_base_anchor_only_patch')
            if old_patch is not None and not isinstance(old_patch,dict):
                raise ValueError('ocular paired anchor proof is malformed')
            chain = []
            values = {'paired_output_base_sha256':after_sha,
                      'paired_base_verified_before_ocular_sha256':before_sha}
            if old_patch is not None:
                values['paired_base_anchor_only_patch_before_ocular'] = copy.deepcopy(old_patch)
                chain.append(copy.deepcopy(old_patch))
            chain.append(copy.deepcopy(link))
            values['paired_base_anchor_only_patch'] = {
                'version':PATCH_VERSION, 'final_sha256':after_sha,
                'all_non_target_bytes_preserved':True,
                'body_head_mask_domains_and_geometry_preserved':True,
                'scope':'mask verification preceded the recorded anchor-only stages; all paired body/head geometry and mask-domain bytes remain unchanged',
                'chain':chain}
            updates.append((recovery,values))
    return updates


def _require_game_check(report, name):
    message = 'Experimental ' + name + ' ocular anchors require an in-game eye check; a visual fix has not been established.'
    problems = report.setdefault('problems',[])
    if message not in problems:problems.append(message)
    report['conversion_completeness'] = 'incomplete'
    report['experimental_ocular_anchor_game_check'] = 'required; appearance not validated'
    # An already-combined native input still contains the preceding tongue
    # experiment. This records its unverified appearance without claiming that
    # the tongue helper ran or rewrote its bytes during this conversion.
    report.setdefault('experimental_tongue_anchor_game_check','required; appearance not validated')


def _warning(report, message):
    warnings = report.setdefault('warnings',[])
    if not isinstance(warnings,list):
        warnings = report.setdefault('ocular_anchor_reporting_warnings',[])
    if message not in warnings:warnings.append(message)


def _log(log, message, detail):
    try:log(message)
    except Exception as error:detail['logging_error'] = str(error)


def process(report, selected_source, selected_output, vcmodel, log=lambda text:None):
    summary = {'version':PATCH_VERSION, 'scope':'exact supplied Bryan/Flip source-output pairs only; existing caruncle chart correspondence',
               'applied':0, 'already_applied':0, 'matched_profiles':[],
               'dark_eyes_fixed':'not established', 'in_game_validation':'not_performed'}
    for record in report.get('models',[]):
        if not isinstance(record,dict):continue
        source = Path(record.get('source',''))
        if not source.is_file():continue
        source_identity = fingerprint(source.read_bytes())
        profile = source_profile(source_identity)
        if profile is None or record.get('verify') != 'pass':continue
        committed = False; detail = None
        try:
            source, output = _safe_output(source, record['output'], selected_source, selected_output, report['output'])
            _preflight_metadata(report,record)
            material_snapshots, material_facts = _material_guard(report,source,output,profile,source_identity)
            before = output.read_bytes()
            changed, differences, expected_points = candidate_bytes(before,profile)
            before_sha = fingerprint(before)[0];after_sha = fingerprint(changed)[0]
            updates = _provenance_updates(report,record,source,before_sha,after_sha) if differences else []
            detail = {'version':PATCH_VERSION, 'profile':profile['name'], 'provenance':provenance(profile),
                      'source_sha256':source_identity[0], 'before_sha256':before_sha, 'after_sha256':after_sha,
                      'old_vertex_indices':list(profile['old_vertices'] if differences else profile['new_vertices']),
                      'new_vertex_indices':list(profile['new_vertices']), 'slots':list(range(5,13)),
                      'fields_written':['vertex_index'], 'wire_format':'one unsigned 16-bit vertex field per target record',
                      'permitted_wire_bytes':16, 'changed_byte_offsets':differences,
                      'all_non_target_bytes_preserved':True, 'other_five_records_preserved':True,
                      'slot4_preserved':['M_Tongue',127], 'geometry_colors_materials_textures_weights_masks_and_physics_preserved':True,
                      'original_verification_scope':'original model/gear/mask checks preceded ocular-only correction; native record syntax and exact authored head UV targets separately checked',
                      'paired_material_verification':material_facts,
                      'in_game_validation':'not_performed', 'dark_eyes_fixed':'not established'}
            if not differences:
                inspected = vcmodel.read_model(str(output),with_shapes=False)
                _validate_native(inspected,expected_points,profile)
                _materials_unchanged(material_snapshots,Path(report['output']))
                if output.read_bytes() != before or fingerprint(source.read_bytes()) != source_identity:
                    raise ValueError('ocular input/output changed during validation')
                detail['state'] = 'already_applied';summary['already_applied'] += 1
            else:
                handle,name = tempfile.mkstemp(prefix='.ocular-anchor-',suffix='.mcd',dir=output.parent)
                stage = Path(name)
                try:
                    with os.fdopen(handle,'wb') as stream:
                        stream.write(changed);stream.flush();os.fsync(stream.fileno())
                    inspected = vcmodel.read_model(str(stage),with_shapes=False)
                    _validate_native(inspected,expected_points,profile)
                    _materials_unchanged(material_snapshots,Path(report['output']))
                    if stage.read_bytes() != changed or output.read_bytes() != before or fingerprint(source.read_bytes()) != source_identity:
                        raise ValueError('ocular input/output changed during staging')
                    os.replace(stage,output);committed = True
                finally:
                    if stage.exists():stage.unlink()
                detail['state'] = 'applied_existing_ocular_anchor_correction';summary['applied'] += 1
                facts = record.setdefault('facts',{})
                facts['output_sha256_before_ocular_anchor_correction'] = before_sha
                facts['output_sha256'] = after_sha
                facts['byte_identical'] = False;facts['model_bytes_preserved'] = False
                facts['geometry_weights_bones_and_embedded_streams'] = 'geometry, colors, weights, bones, masks and every non-target byte preserved; ocular-only stage changes eight GtPt vertex fields'
                if record.get('status') == 'preserved_2k26':
                    record['status'] = 'repaired_2k26_experimental_ocular_anchors'
                    report['native_2k26_models_preserved'] = max(0,report.get('native_2k26_models_preserved',0)-1)
                elif record.get('status') == 'repaired_2k26_experimental_tongue_anchor':
                    record['status'] = 'repaired_2k26_experimental_tongue_and_ocular_anchors'
                # Record committed bytes before optional prior-proof links.
                # A later reporting error must not retain a false final hash.
                for holder,values in updates:holder.update(values)
                message = 'Supplied ' + profile['name'] + ' ocular anchors matched to existing Cena-corresponding chart vertices; in-game eye appearance requires a check.'
                _warning(report,message);_log(log,message,detail)
            _require_game_check(report,profile['name'])
            record['experimental_ocular_anchor'] = detail
            if profile['name'] not in summary['matched_profiles']:summary['matched_profiles'].append(profile['name'])
        except Exception as error:
            if committed:
                detail = detail or {'version':PATCH_VERSION}
                detail.update(state='applied_with_reporting_error',reason=str(error),
                              file_changes='only reviewed ocular GtPt vertex fields committed')
                record['experimental_ocular_anchor'] = detail
                message = 'Supplied ' + profile['name'] + ' ocular anchor correction was written, but reporting failed: ' + str(error)
                _require_game_check(report,profile['name'])
            else:
                record['experimental_ocular_anchor'] = {'version':PATCH_VERSION,'state':'not_applied',
                    'reason':str(error),'file_changes':'none','in_game_validation':'not_performed'}
                message = 'Supplied ' + profile['name'] + ' ocular anchor correction was not applied: ' + str(error)
                # This is a recognized supplied source whose intended repair
                # was refused, rather than an unrelated unknown model.
                problems = report.setdefault('problems',[])
                if type(problems) is list and message not in problems:problems.append(message)
                report['conversion_completeness'] = 'incomplete'
            _warning(report,message);_log(log,message,record['experimental_ocular_anchor'])
    report['ocular_anchor_correction'] = summary


def install(convert, folder):
    """Install after tongue corrections, before final face audit and reporting."""
    if getattr(folder,'_ocular_anchor_correction',None) == PATCH_VERSION:return
    original = folder.convert_folder
    @functools.wraps(original)
    def convert_folder(*args,**kwargs):
        bound = inspect.signature(original).bind(*args,**kwargs);bound.apply_defaults()
        report = original(*args,**kwargs)
        process(report,bound.arguments['src'],bound.arguments['dst'],convert.vc,
                bound.arguments.get('log',lambda text:None))
        from gmf_report import save_intermediate
        save_intermediate(report,bound.arguments['dst'])
        return report
    folder.convert_folder = convert_folder
    folder._ocular_anchor_correction = PATCH_VERSION
