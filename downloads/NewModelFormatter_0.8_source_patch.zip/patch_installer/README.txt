NewModelFormatter 0.8 experimental -- small patch installer

1. Right-click this downloaded ZIP and choose Extract All into a FRESH folder.
2. Open the extracted folder and double-click Install.cmd.
3. In the file picker, choose your ORIGINAL Gorilla Model Formatter.exe
   from the Gorilla Model Formatter 1.0 folder.
4. Wait for "Created successfully". NewModelFormatter.exe appears in
   this installer folder. Open that new EXE.

Keep every installer file together after extracting. Do not run Install.cmd
from inside the ZIP. No Python, Blender, or extra installer is needed.

The original Gorilla EXE is never overwritten. An existing NewModelFormatter.exe
is never overwritten either: move or rename it first to apply a newer build.
The patch accepts only the exact supplied Gorilla 1.0 EXE (SHA-256 below).
Selecting a different EXE stops the patch without changing it.

Original SHA-256:
ece4729f2ac3fc707c69550d4a79df7866c11a61463d8eb529ae927e04f377f2

The new tool retains the original CakeView selection/checks and input/output
methods. Continue using your usual source folder, output folder, and CakeView
workflow. The installer never opens or runs either EXE.

This is an EXPERIMENTAL build, not a completed repair of every mod. Existing
documented limits and required in-game checks still apply. Teeth are deferred
unless a current problem is reproduced. No new blood or belt fix is included
in this patch merely because the comparison formatter has related options.

Verification: the generated binary patch reconstructs the current experimental
EXE byte for byte, and verifies both source and output SHA-256 hashes. ZIP CRCs
were checked. The Windows PowerShell installer has not been executed in this
Linux workspace; see patch-validation.json for the exact output hash.

No administrator account is required when extracted to a writable folder.

Optional command-line use (Windows PowerShell):
.\Apply-FormatterPatch.ps1 -OriginalExe "C:\path\Gorilla Model Formatter.exe"
The optional -OutputExe parameter selects another NEW output filename.

For existing 2K26 models, select Keep the mod's own folder name.
This audits material bindings and preserves model/physics bytes. It does not
rebuild old geometry or certify physics compatibility. Rey mask recovery is
guarded and passed the actual paired-base native check; an in-game check
is still required.

Copied reference weight checks are integrated as read-only report diagnostics.
The complete reference source is preserved in the source ZIP. The full
Blender scene pipeline is not active in this release. Gorilla YCL is unchanged.

0.6: readable YCL now converts even alongside unsupported WDF/YWA companions.
The original Gorilla YCL translator is unchanged. Billie actual-file checks
passed; converted YCL matched an independent reference-editor round-trip.
Companion conversion and in-game motion are still unverified/incomplete.
The supplied WWE2K_MDL source is now available; full Blender scene processing
has not replaced the native conversion engine in this release.

0.7: final/error reports save at the output root and inside the converted mod.
Use Open conversion report; the log prints its exact path. If output is
unwritable, Temp is used. JSON association failures use Notepad.

Rey gear checkbox now tests nearest-surface weights from his verified paired
body on tights, belt, tops, pads and wings. Actual model checks passed; the
see-through issue still needs an in-game check. No Rey physics is created.
The exact supplied native 2K26 AJ pair also receives an automatic foot-only
mask test without a separate HPL. Keep his BaseModel and attire in the normal
wrestler folder, choose Keep the mod's own folder name, and use a new empty
output folder. Boot coverage still needs an in-game check. Beard and Billie
dark eyes are not claimed fixed.

0.8: accepts actual 2K24 format-40 inputs without rewriting source headers.
Original rig/output checks remain. Supplied Bryan base/attire model checks
passed; material, hide-mask, physics and game checks remain separate.

Already-ported 2K26 inputs now receive a missing-data audit. Missing material
tables/entries can be recovered from actual readable JMTLs in your input.
Referenced textures can be restored from exact available game-path hashes.
A readable matching HPL can restore a lost embedded mask after checking the
real paired native base. Other model/stream bytes remain unchanged.
Inspect native_2k26_missing_data_check in the report. Missing/unverified
assets stay listed; the tool does not fabricate shaders, masks or physics.
Use the complete wrestler folder, Keep the mod's own folder name, and a new
empty output folder. Appearance, movement and belt coverage still need an
in-game check. Xia needs her matching readable 982_Attire.hpl.
