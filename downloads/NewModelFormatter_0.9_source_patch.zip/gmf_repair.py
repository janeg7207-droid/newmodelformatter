"""Conservative runtime patch for the recovered Gorilla Model Formatter build.

No physics or geometry conversion changes are made by this patch. A narrowly
scoped, opt-in diagnostic weight profile is available for the supplied Rey MCD.
Install into the complete original application source tree, then call install()
after its gmf imports and before starting the existing GUI.
"""
import copy
import functools
import hashlib
import inspect
import json
import os
from pathlib import Path
import types
import math
import threading

PATCH_VERSION = "bc1-alpha-and-native26-verified-recovery-9"
_gear_context = threading.local()
REY_MODEL_SHA256 = 'c181b2889e01a8ebb76f020457de7466a099ae327d87514e1cd44b36b3f6245c'
REY_GEAR_MESHES = {'M_Wings', 'M_Tops', 'M_ShoulderPad'}
REY_SURFACE_MESHES = REY_GEAR_MESHES | {'M_Tights', 'M_Outfit'}


def set_gear_policy(enabled=False, method='ancestor'):
    """Opt-in diagnostic profile; set on the same worker thread as conversion."""
    if method not in ('ancestor', 'surface'):
        raise ValueError('unknown gear policy: ' + str(method))
    _gear_context.requested = bool(enabled)
    _gear_context.method = method
    _gear_context.surface_cache = {}


def preserve_gear_weights(mesh, inherit, rig_names):
    """Preserve source influence budgets and remap only removed bones.

    This is a diagnostic skinning alternative, not a physics conversion. It
    uses the original converter's hierarchy-derived inheritance map and fails
    on unresolved targets. Geometry and all original arrays stay untouched.
    """
    allowed = set(rig_names)
    original = mesh.weights
    mapping = {}
    for name in original:
        target, seen = name, set()
        while target in inherit:
            if target in seen:
                raise ValueError('cycle in removed-bone inheritance: ' + name)
            seen.add(target)
            target = inherit[target]
        if target not in allowed:
            raise ValueError(f'gear weight has no surviving target: {name} -> {target}')
        mapping[name] = target
    nv = mesh.num_verts
    result = {}
    selected = set()
    before_budget = [0.0] * nv
    for name, vector in original.items():
        if len(vector) != nv:
            raise ValueError('gear weight vector length differs from vertex count')
        target = mapping[name]
        if target not in result:
            result[target] = vector.copy()
        else:
            for index, weight in enumerate(vector):
                result[target][index] += weight
        for index, weight in enumerate(vector):
            value = float(weight)
            if not math.isfinite(value) or value < 0:
                raise ValueError('non-finite or negative gear weight')
            before_budget[index] += value
            if target != name and value > 1e-6:
                selected.add(index)
    for index, budget in enumerate(before_budget):
        after = sum(float(vector[index]) for vector in result.values())
        if abs(after - budget) > 1e-6:
            raise ValueError('gear remap failed to preserve vertex influence budget')
    mesh.weights = result
    return {'mesh': mesh.name, 'old_groups': sum(n != t for n,t in mapping.items()),
            'verts_changed': len(selected), 'kept_own_part': 0,
            'policy': 'preserve_attachment_ancestor_remap',
            'bone_remaps': {n:t for n,t in mapping.items() if n != t},
            'in_game_validation': 'required'}


def patch_gear_converter(convert_module, skeleton_module):
    original_model = convert_module.convert_mcd
    original_weights = skeleton_module.convert_weights
    original_verify = convert_module.verify

    @functools.wraps(original_weights)
    def convert_weights(mesh, inherit, ref, *args, **kwargs):
        selected = REY_SURFACE_MESHES if getattr(_gear_context, 'method', 'ancestor') == 'surface' else REY_GEAR_MESHES
        if getattr(_gear_context, 'active', False) and mesh.name in selected:
            if getattr(_gear_context, 'method', 'ancestor') == 'surface':
                from gmf_mask_recovery import validated_paired_base
                from gmf_surface_transfer import transfer_weights
                base, digest = validated_paired_base(_gear_context.source)
                donors = [m for m in base.meshes if m.name == 'M_Body']
                if len(donors) != 1:
                    raise ValueError('paired base must have exactly one M_Body donor')
                report = transfer_weights(mesh, donors[0], ref.set26,
                    cache=_gear_context.surface_cache, donor_sha256=digest)
            else:
                report = preserve_gear_weights(mesh, inherit, ref.set26)
            _gear_context.records.append(report)
            return report
        return original_weights(mesh, inherit, ref, *args, **kwargs)

    @functools.wraps(original_model)
    def convert_mcd(*args, **kwargs):
        bound = inspect.signature(original_model).bind(*args, **kwargs)
        src = bound.arguments['src_path']
        requested = getattr(_gear_context, 'requested', False)
        previous = getattr(_gear_context, 'active', False)
        records_before = getattr(_gear_context, 'records', None)
        source_before = getattr(_gear_context, 'source', None)
        if requested:
            digest = hashlib.sha256()
            with open(src, 'rb') as stream:
                for chunk in iter(lambda: stream.read(1024*1024), b''):
                    digest.update(chunk)
            active = digest.hexdigest() == REY_MODEL_SHA256
        else:
            active = False
        _gear_context.active = active
        _gear_context.records = []
        _gear_context.source = src
        try:
            report = original_model(*args, **kwargs)
            if active:
                report['experimental_gear_profile'] = list(_gear_context.records)
                if getattr(_gear_context, 'method', 'ancestor') == 'surface':
                    report['notes'].append('EXPERIMENTAL Rey gear: nearest-surface weights from the '
                        'verified paired converted body, using supplied PWM triangle math and '
                        'reference cleanup rules. Blender Heat Seek equivalence is not claimed. '
                        'No cloth physics created; entrance/gameplay validation required.')
                else:
                    report['notes'].append('EXPERIMENTAL Rey gear profile: source attachment weights '
                        'retained; removed bones remapped to surviving ancestors. No simulated '
                        'cloth created. Entrance/gameplay validation is required.')
            return report
        finally:
            _gear_context.active = previous
            _gear_context.records = records_before
            _gear_context.source = source_before

    @functools.wraps(original_verify)
    def verify(*args, **kwargs):
        # Keep original geometry/rig/mask verification. A surface policy also
        # compares every written influence against its expected projection.
        # The source file and its real geometry/rig data remain untouched.
        bound = inspect.signature(original_verify).bind(*args, **kwargs)
        previous = getattr(_gear_context, 'active', False)
        records_before = getattr(_gear_context, 'records', None)
        source_before = getattr(_gear_context, 'source', None)
        active = False
        if getattr(_gear_context, 'requested', False):
            with open(bound.arguments['src_path'], 'rb') as stream:
                active = hashlib.sha256(stream.read()).hexdigest() == REY_MODEL_SHA256
        _gear_context.active = active
        _gear_context.records = []
        _gear_context.source = bound.arguments['src_path']
        try:
            if active and getattr(_gear_context, 'method', 'ancestor') == 'surface':
                from gmf_mask_recovery import validated_paired_base
                from gmf_surface_transfer import transfer_weights
                from gmf_surface_verification import check_written_weights
                vc = convert_module.vc
                expected = vc.read_model(bound.arguments['src_path'])
                written = vc.read_model(bound.arguments['dst_path'])
                base, digest = validated_paired_base(bound.arguments['src_path'])
                donors = [m for m in base.meshes if m.name == 'M_Body']
                if len(donors) != 1:
                    raise ValueError('paired base must have one M_Body donor')
                rig = {bone.name for bone in written.bones}
                checks = []
                for mesh in expected.meshes:
                    if mesh.name not in REY_SURFACE_MESHES:
                        continue
                    targets = [m for m in written.meshes if m.name == mesh.name]
                    if len(targets) != 1:
                        raise ValueError('surface target must be unique: ' + mesh.name)
                    transfer_weights(mesh, donors[0], rig, cache=_gear_context.surface_cache, donor_sha256=digest)
                    checks.append(check_written_weights(mesh, targets[0], rig))
                # Original "untouched weight" checks assume partial reweighting.
                # Feed only the deliberately projected meshes' expected weights
                # to a local source view. Other source fields and every other
                # mesh still come from the real native reader, unchanged.
                def read_expected(path, *read_args, **read_kwargs):
                    model = vc.read_model(path, *read_args, **read_kwargs)
                    if os.path.normcase(os.path.abspath(path)) == os.path.normcase(os.path.abspath(bound.arguments['src_path'])):
                        by_name = {m.name:m for m in expected.meshes if m.name in REY_SURFACE_MESHES}
                        for mesh in model.meshes:
                            if mesh.name in by_name:
                                mesh.weights = {n:w.copy() for n,w in by_name[mesh.name].weights.items()}
                    return model
                namespace = dict(original_verify.__globals__)
                namespace['vc'] = types.SimpleNamespace(**{**vars(vc), 'read_model':read_expected})
                isolated = types.FunctionType(original_verify.__code__,namespace,original_verify.__name__,original_verify.__defaults__,original_verify.__closure__)
                isolated.__kwdefaults__ = original_verify.__kwdefaults__
                result = isolated(*args, **kwargs)
                result[2]['surface_weight_verification'] = checks
                for check in checks:
                    result[2].setdefault(check['mesh'],{})['policy_reweighted_vertices'] = check['vertices_checked']
                return result
            return original_verify(*args, **kwargs)
        finally:
            _gear_context.active = previous
            _gear_context.records = records_before
            _gear_context.source = source_before

    skeleton_module.convert_weights = convert_weights
    convert_module.convert_mcd = convert_mcd
    convert_module.verify = verify


def reconcile_materials(mats, used_names, clean_name):
    """Resolve unique case aliases; never guess between colliding definitions.

    Return copied definitions and an audit trail. Source objects and parameter
    dictionaries are not modified. Names emitted match the mesh binding exactly.
    """
    if used_names is None:
        return list(mats), []
    # Preserve the original first-exact-name choice and duplicate skipping.
    exact, buckets = {}, {}
    for index, material in enumerate(mats):
        name = clean_name(material.name)
        if name not in exact:
            exact[name] = index
            buckets.setdefault(name.casefold(), []).append(name)
    requested = sorted(set(used_names))
    renames, aliases = {}, []
    for name in requested:
        if not name or any(c in name for c in '/\\\x00') or name in ('.', '..'):
            raise ValueError(f"unsafe mesh material binding: {name!r}")
        if name in exact:
            continue
        key = name.casefold()
        definitions = buckets.get(key, [])
        if not definitions:
            # Retain the original missing-material note and lambert1 exemption.
            continue
        if len(definitions) != 1:
            raise ValueError("ambiguous material definitions: " +
                             ", ".join(repr(n) for n in definitions))
        collisions = [n for n in requested if n != name and n.casefold() == key]
        if collisions:
            raise ValueError(f"mesh material bindings collide on Windows: {collisions[0]!r}, {name!r}")
        source = definitions[0]
        index = exact[source]
        renames[index] = name
        aliases.append({"source": source, "binding": name})
    result = list(mats)
    for index, target in renames.items():
        material = mats[index]
        source = clean_name(material.name)
        renamed = copy.copy(material)
        renamed.name = target + material.name[len(source):]
        result[index] = renamed
    return result, aliases


def patch_material_converter(module):
    original = module.convert_library

    @functools.wraps(original)
    def convert_library(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs)
        bound.apply_defaults()
        used = bound.arguments['used_names']
        if used is not None:
            used = tuple(used)
            bound.arguments['used_names'] = used
        aliases = []
        read_mtls = module.mtl25.read_mtls

        def read_reconciled(path):
            version, mats = read_mtls(path)
            if mats is not None:
                mats, changes = reconcile_materials(mats, used, module.clean_name)
                aliases.extend(changes)
            return version, mats

        # The original function loads writer globals lazily. Load first, then
        # clone its namespace; do not temporarily replace the shared reader.
        module._load_writers()
        namespace = dict(original.__globals__)
        namespace['mtl25'] = types.SimpleNamespace(
            **{**vars(module.mtl25), 'read_mtls': read_reconciled})
        isolated = types.FunctionType(original.__code__, namespace,
                                      original.__name__, original.__defaults__,
                                      original.__closure__)
        isolated.__kwdefaults__ = original.__kwdefaults__
        report = isolated(*bound.args, **bound.kwargs)
        from gmf_jmtl_audit import inspect_written_materials
        inspect_written_materials(report)
        report['material_binding_aliases'] = aliases
        for alias in aliases:
            report['notes'].append(
                f"material case reconciled: {alias['source']} -> {alias['binding']}; "
                "source textures and shader parameters retained")
        return report

    module.convert_library = convert_library


def patch_mask_checks(module):
    original_check = module._check_mask
    original_streams = module._sidecar_streams

    @functools.wraps(original_check)
    def check_mask(src_path, b, body_limits, problems, facts, base_file=False):
        original_check(src_path, b, body_limits, problems, facts, base_file)
        if facts.get('hide_mask') == 'unreadable':
            problems.append("source hide mask is unsupported or unreadable; "
                            "an empty output does not validate skin hiding")

    @functools.wraps(original_streams)
    def sidecar_streams(*args, **kwargs):
        bound = inspect.signature(original_streams).bind(*args, **kwargs)
        bound.apply_defaults()
        notes = bound.arguments['notes']
        start = len(notes)
        result = original_streams(*args, **kwargs)
        for i in range(start, len(notes)):
            notes[i] = notes[i].replace(
                'holds no readable hide mask (a blanked or damaged file)',
                'has a hide-mask layout this parser cannot read; damage is not established')
        return result

    module._check_mask = check_mask
    module._sidecar_streams = sidecar_streams


INPUT_SUFFIXES = {'.mdl', '.mcd', '.mtls', '.hpl', '.ctg', '.ycl', '.wdf',
                  '.hair_ywa', '.hair_corr_ywa', '.other_ywa', '.other_corr_ywa'}


def source_inventory(src):
    root = Path(src).resolve()
    result = []
    for directory, dirs, files in os.walk(root, onerror=lambda error: (_ for _ in ()).throw(error)):
        dirs.sort()
        for name in sorted(files):
            path = Path(directory) / name
            if path.suffix.lower() not in INPUT_SUFFIXES:
                continue
            digest = hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(block)
            result.append({'path': path.relative_to(root).as_posix(),
                           'bytes': path.stat().st_size, 'sha256': digest.hexdigest()})
    return result


def mark_readiness(report):
    """Report conversion completeness separately from structural model checks."""
    limitations = [w for w in report.get('warnings', [])
                   if 'hair/cloth physics not converted' in w]
    if any(m.get('experimental_gear_profile') for m in report.get('models', [])):
        limitations.append('experimental Rey gear skinning requires entrance/gameplay validation')
    if any(m.get('hide_mask_recovery') for m in report.get('models', [])):
        limitations.append('restored Rey hide mask requires entrance/gameplay validation')
    for limitation in limitations:
        if limitation not in report['problems']:
            report['problems'].append(limitation)
    report['conversion_completeness'] = (
        'incomplete' if report['problems'] else 'structural_checks_only')
    report['in_game_validation'] = 'not_performed'
    report['repair_patch'] = PATCH_VERSION


def patch_folder_converter(module):
    original = module.convert_folder

    @functools.wraps(original)
    def convert_folder(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs)
        bound.apply_defaults()
        src, dst = bound.arguments['src'], bound.arguments['dst']
        inventory = source_inventory(src)
        report = original(*args, **kwargs)
        report['source_inventory_before_conversion'] = inventory
        mark_readiness(report)
        from gmf_report import save_intermediate
        save_intermediate(report,dst)
        return report

    module.convert_folder = convert_folder


def install():
    """Preserve the original GUI, CakeView selection, writers, and engine."""
    from gmf import materials, convert, folder, skeleton
    if getattr(materials, '_repair_patch', None) == PATCH_VERSION:
        return
    patch_material_converter(materials)
    from gmf_dds_alpha import install as install_alpha_check
    install_alpha_check(materials)
    patch_mask_checks(convert)
    patch_gear_converter(convert, skeleton)
    from gmf_mask_recovery import install as install_mask_recovery
    install_mask_recovery(convert, folder)
    patch_folder_converter(folder)
    from gmf_2k26_repair import install as install_native_repair
    install_native_repair(folder)
    from gmf_reference_audit import install as install_reference_audit
    install_reference_audit(folder)
    from gmf_ycl_repair import install as install_ycl_repair
    install_ycl_repair(folder)
    from gmf_aj_mask import install as install_aj_mask
    install_aj_mask(folder)
    from gmf_2k26_audit import install as install_native_audit
    install_native_audit(folder)
    from gmf_2k24_route import install as install_legacy24
    install_legacy24(folder,convert)
    from gmf_report import install as install_report
    install_report(folder)
    materials._repair_patch = PATCH_VERSION
