# Installation

See [NEW_FORMATTER.md](NEW_FORMATTER.md) for the current experimental 0.4
Windows installer, supported behavior, and validation limits.

For a source integration, use Python 3.14 and run `apply_source_patch.py --help`.
It preflights the recovered Gorilla source and installs `gmf_repair.py`,
`gmf_mask_recovery.py`, and `gmf_2k26_repair.py` with a GUI startup hook.
Keep a backup; do not apply this to an unrelated formatter implementation.

Run checks with `python3.14 -m unittest discover -s tests`.
Build from the exact original supplied EXE with `build_patched_exe.py --help`.
The source builder preserves original native payloads and CakeView gates;
use the own-UI option to build NewModelFormatter.
