# Rebuild the current experimental tool

Install Python 3.14 on Windows or Linux. Keep the uploaded original Gorilla 1.0
EXE unchanged. From the extracted source-patch directory run:

```
python -m unittest discover -s tests
python build_patched_exe.py "C:\path\Gorilla Model Formatter.exe" NewModelFormatter.exe --own-ui
```

The builder requires the exact original SHA-256 and a new output filename.
It reads the EXE archive as data and adds repair code; it does not execute the
input EXE. The resulting Windows EXE retains the original native DLLs,
references, Gorilla model conversion and YCL code, CakeView gate, and credits.
It adds the own UI, material repair, guarded mask recovery, native 2K26
preservation/material audit, and copied reference weight checks.

`reference_source/` contains the supplied ModelFormatter, Vynx and WWE2K_MDL
sources with hashes. That missing source is now available. The Windows build
uses the existing native engine with the tested repair wrappers, including
independent original Gorilla YCL translation. Full Blender scene processing
is not active in this release. The surface-weight prototype remains outside
this source package because its native verification did not pass.

Tests include inspected recovered Gorilla bytecode fixtures, requiring Python
3.14. Native DLL/Wine checks and in-game tests are separate from those tests.
Original mod models, textures and the Gorilla EXE are excluded from this ZIP.
