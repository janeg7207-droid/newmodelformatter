# Installation

See [NEW_FORMATTER.md](NEW_FORMATTER.md) for current 0.6 installation, evidence
and remaining physics limitations. See [SOURCE_REBUILD.md](SOURCE_REBUILD.md)
for rebuilding the EXE from the original supplied Gorilla EXE.

For integration into a COPY of a complete recovered Gorilla source project,
run `apply_source_patch.py --help`. It installs the six repair helper modules
and retains a backup of the original GUI. Preserve the original source.
