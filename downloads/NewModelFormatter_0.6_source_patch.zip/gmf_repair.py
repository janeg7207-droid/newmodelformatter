"""Conservative runtime patch for the recovered Gorilla Model Formatter build.

No physics or geometry conversion changes are made by this patch. A narrowly
scoped, opt-in diagnostic weight profile is available for the supplied Rey MCD.
Install into the complete original application source tree, then call install()
after its gmf imports and before starting the existing GUI.
"""
import copy
import functools
import hashlib
import inspect
import json
import os
from pathlib import Path
import types
import math
import threading

PATCH_VERSION = "material-mask-native26-reference-ycl-6"
_gear_context = threading.local()
REY_MODEL_SHA256 = 'c181b2889e01a8ebb76f020457de7466a099ae327d87514e1cd44b36b3f6245c'
REY_GEAR_MESHES = {'M_Wings', 'M_Tops', 'M_ShoulderPad'}


def set_gear_policy(enabled=False):
    """Opt-in diagnostic profile; set on the same worker thread as conversion."""
    _gear_context.requested = bool(enabled)


def preserve_gear_weights(mesh, inherit, rig_names):
    """Preserve source influence budgets and remap only removed bones.

    This is a diagnostic skinning alternative, not a physics conversion. It
    uses the original converter's hierarchy-derived inheritance map and fails
    on unresolved targets. Geometry and all original arrays stay untouched.
    """
    allowed = set(rig_names)
    original = mesh.weights
    mapping = {}
    for name in original:
        target, seen = name, set()
        while target in inherit:
            if target in seen:
                raise ValueError('cycle in removed-bone inheritance: ' + name)
            seen.add(target)
            target = inherit[target]
        if target not in allowed:
            raise ValueError(f'gear weight has no surviving target: {name} -> {target}')
        mapping[name] = target
    nv = mesh.num_verts
    result = {}
    selected = set()
    before_budget = [0.0] * nv
    for name, vector in original.items():
        if len(vector) != nv:
            raise ValueError('gear weight vector length differs from vertex count')
        target = mapping[name]
        if target not in result:
            result[target] = vector.copy()
        else:
            for index, weight in enumerate(vector):
                result[target][index] += weight
        for index, weight in enumerate(vector):
            value = float(weight)
            if not math.isfinite(value) or value < 0:
                raise ValueError('non-finite or negative gear weight')
            before_budget[index] += value
            if target != name and value > 1e-6:
                selected.add(index)
    for index, budget in enumerate(before_budget):
        after = sum(float(vector[index]) for vector in result.values())
        if abs(after - budget) > 1e-6:
            raise ValueError('gear remap failed to preserve vertex influence budget')
    mesh.weights = result
    return {'mesh': mesh.name, 'old_groups': sum(n != t for n,t in mapping.items()),
            'verts_changed': len(selected), 'kept_own_part': 0,
            'policy': 'preserve_attachment_ancestor_remap',
            'bone_remaps': {n:t for n,t in mapping.items() if n != t},
            'in_game_validation': 'required'}


def patch_gear_converter(convert_module, skeleton_module):
    original_model = convert_module.convert_mcd
    original_weights = skeleton_module.convert_weights
    original_verify = convert_module.verify

    @functools.wraps(original_weights)
    def convert_weights(mesh, inherit, ref, *args, **kwargs):
        if getattr(_gear_context, 'active', False) and mesh.name in REY_GEAR_MESHES:
            report = preserve_gear_weights(mesh, inherit, ref.set26)
            _gear_context.records.append(report)
            return report
        return original_weights(mesh, inherit, ref, *args, **kwargs)

    @functools.wraps(original_model)
    def convert_mcd(*args, **kwargs):
        bound = inspect.signature(original_model).bind(*args, **kwargs)
        src = bound.arguments['src_path']
        requested = getattr(_gear_context, 'requested', False)
        previous = getattr(_gear_context, 'active', False)
        records_before = getattr(_gear_context, 'records', None)
        if requested:
            digest = hashlib.sha256()
            with open(src, 'rb') as stream:
                for chunk in iter(lambda: stream.read(1024*1024), b''):
                    digest.update(chunk)
            active = digest.hexdigest() == REY_MODEL_SHA256
        else:
            active = False
        _gear_context.active = active
        _gear_context.records = []
        try:
            report = original_model(*args, **kwargs)
            if active:
                report['experimental_gear_profile'] = list(_gear_context.records)
                report['notes'].append('EXPERIMENTAL Rey gear profile: source attachment weights '
                    'retained; removed bones remapped to surviving ancestors. No simulated '
                    'cloth created. Entrance/gameplay validation is required.')
            return report
        finally:
            _gear_context.active = previous
            _gear_context.records = records_before

    @functools.wraps(original_verify)
    def verify(*args, **kwargs):
        # The original verifier recomputes expected skin weights. Apply the
        # same explicit policy for this recomputation, rather than checking
        # an intentional ancestor remap against the stock-sampling policy.
        bound = inspect.signature(original_verify).bind(*args, **kwargs)
        previous = getattr(_gear_context, 'active', False)
        records_before = getattr(_gear_context, 'records', None)
        active = False
        if getattr(_gear_context, 'requested', False):
            with open(bound.arguments['src_path'], 'rb') as stream:
                active = hashlib.sha256(stream.read()).hexdigest() == REY_MODEL_SHA256
        _gear_context.active = active
        _gear_context.records = []
        try:
            return original_verify(*args, **kwargs)
        finally:
            _gear_context.active = previous
            _gear_context.records = records_before

    skeleton_module.convert_weights = convert_weights
    convert_module.convert_mcd = convert_mcd
    convert_module.verify = verify


def reconcile_materials(mats, used_names, clean_name):
    """Resolve unique case aliases; never guess between colliding definitions.

    Return copied definitions and an audit trail. Source objects and parameter
    dictionaries are not modified. Names emitted match the mesh binding exactly.
    """
    if used_names is None:
        return list(mats), []
    # Preserve the original first-exact-name choice and duplicate skipping.
    exact, buckets = {}, {}
    for index, material in enumerate(mats):
        name = clean_name(material.name)
        if name not in exact:
            exact[name] = index
            buckets.setdefault(name.casefold(), []).append(name)
    requested = sorted(set(used_names))
    renames, aliases = {}, []
    for name in requested:
        if not name or any(c in name for c in '/\\\x00') or name in ('.', '..'):
            raise ValueError(f"unsafe mesh material binding: {name!r}")
        if name in exact:
            continue
        key = name.casefold()
        definitions = buckets.get(key, [])
        if not definitions:
            # Retain the original missing-material note and lambert1 exemption.
            continue
        if len(definitions) != 1:
            raise ValueError("ambiguous material definitions: " +
                             ", ".join(repr(n) for n in definitions))
        collisions = [n for n in requested if n != name and n.casefold() == key]
        if collisions:
            raise ValueError(f"mesh material bindings collide on Windows: {collisions[0]!r}, {name!r}")
        source = definitions[0]
        index = exact[source]
        renames[index] = name
        aliases.append({"source": source, "binding": name})
    result = list(mats)
    for index, target in renames.items():
        material = mats[index]
        source = clean_name(material.name)
        renamed = copy.copy(material)
        renamed.name = target + material.name[len(source):]
        result[index] = renamed
    return result, aliases


def patch_material_converter(module):
    original = module.convert_library

    @functools.wraps(original)
    def convert_library(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs)
        bound.apply_defaults()
        used = bound.arguments['used_names']
        if used is not None:
            used = tuple(used)
            bound.arguments['used_names'] = used
        aliases = []
        read_mtls = module.mtl25.read_mtls

        def read_reconciled(path):
            version, mats = read_mtls(path)
            if mats is not None:
                mats, changes = reconcile_materials(mats, used, module.clean_name)
                aliases.extend(changes)
            return version, mats

        # The original function loads writer globals lazily. Load first, then
        # clone its namespace; do not temporarily replace the shared reader.
        module._load_writers()
        namespace = dict(original.__globals__)
        namespace['mtl25'] = types.SimpleNamespace(
            **{**vars(module.mtl25), 'read_mtls': read_reconciled})
        isolated = types.FunctionType(original.__code__, namespace,
                                      original.__name__, original.__defaults__,
                                      original.__closure__)
        isolated.__kwdefaults__ = original.__kwdefaults__
        report = isolated(*bound.args, **bound.kwargs)
        report['material_binding_aliases'] = aliases
        for alias in aliases:
            report['notes'].append(
                f"material case reconciled: {alias['source']} -> {alias['binding']}; "
                "source textures and shader parameters retained")
        return report

    module.convert_library = convert_library


def patch_mask_checks(module):
    original_check = module._check_mask
    original_streams = module._sidecar_streams

    @functools.wraps(original_check)
    def check_mask(src_path, b, body_limits, problems, facts, base_file=False):
        original_check(src_path, b, body_limits, problems, facts, base_file)
        if facts.get('hide_mask') == 'unreadable':
            problems.append("source hide mask is unsupported or unreadable; "
                            "an empty output does not validate skin hiding")

    @functools.wraps(original_streams)
    def sidecar_streams(*args, **kwargs):
        bound = inspect.signature(original_streams).bind(*args, **kwargs)
        bound.apply_defaults()
        notes = bound.arguments['notes']
        start = len(notes)
        result = original_streams(*args, **kwargs)
        for i in range(start, len(notes)):
            notes[i] = notes[i].replace(
                'holds no readable hide mask (a blanked or damaged file)',
                'has a hide-mask layout this parser cannot read; damage is not established')
        return result

    module._check_mask = check_mask
    module._sidecar_streams = sidecar_streams


INPUT_SUFFIXES = {'.mdl', '.mcd', '.mtls', '.hpl', '.ctg', '.ycl', '.wdf',
                  '.hair_ywa', '.hair_corr_ywa', '.other_ywa', '.other_corr_ywa'}


def source_inventory(src):
    root = Path(src).resolve()
    result = []
    for directory, dirs, files in os.walk(root, onerror=lambda error: (_ for _ in ()).throw(error)):
        dirs.sort()
        for name in sorted(files):
            path = Path(directory) / name
            if path.suffix.lower() not in INPUT_SUFFIXES:
                continue
            digest = hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(block)
            result.append({'path': path.relative_to(root).as_posix(),
                           'bytes': path.stat().st_size, 'sha256': digest.hexdigest()})
    return result


def mark_readiness(report):
    """Report conversion completeness separately from structural model checks."""
    limitations = [w for w in report.get('warnings', [])
                   if 'hair/cloth physics not converted' in w]
    if any(m.get('experimental_gear_profile') for m in report.get('models', [])):
        limitations.append('experimental Rey gear skinning requires entrance/gameplay validation')
    if any(m.get('hide_mask_recovery') for m in report.get('models', [])):
        limitations.append('restored Rey hide mask requires entrance/gameplay validation')
    for limitation in limitations:
        if limitation not in report['problems']:
            report['problems'].append(limitation)
    report['conversion_completeness'] = (
        'incomplete' if report['problems'] else 'structural_checks_only')
    report['in_game_validation'] = 'not_performed'
    report['repair_patch'] = PATCH_VERSION


def patch_folder_converter(module):
    original = module.convert_folder

    @functools.wraps(original)
    def convert_folder(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs)
        bound.apply_defaults()
        src, dst = bound.arguments['src'], bound.arguments['dst']
        inventory = source_inventory(src)
        report = original(*args, **kwargs)
        report['source_inventory_before_conversion'] = inventory
        mark_readiness(report)
        # Same report location as the recovered folder.convert_folder, line 436.
        path = Path(dst).absolute() / (os.path.basename(report['source']) + ' - conversion report.json')
        with path.open('w') as stream:
            json.dump(report, stream, indent=2, default=str)
        return report

    module.convert_folder = convert_folder


def install():
    """Preserve the original GUI, CakeView selection, writers, and engine."""
    from gmf import materials, convert, folder, skeleton
    if getattr(materials, '_repair_patch', None) == PATCH_VERSION:
        return
    patch_material_converter(materials)
    patch_mask_checks(convert)
    patch_gear_converter(convert, skeleton)
    from gmf_mask_recovery import install as install_mask_recovery
    install_mask_recovery(convert, folder)
    patch_folder_converter(folder)
    from gmf_2k26_repair import install as install_native_repair
    install_native_repair(folder)
    from gmf_reference_audit import install as install_reference_audit
    install_reference_audit(folder)
    from gmf_ycl_repair import install as install_ycl_repair
    install_ycl_repair(folder)
    materials._repair_patch = PATCH_VERSION
