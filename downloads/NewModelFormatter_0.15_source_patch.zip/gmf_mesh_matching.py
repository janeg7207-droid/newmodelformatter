"""Pair attire meshes by identity inside Gorilla's unchanged verifier.

Integration has two phases, because the gear verifier clones raw globals:
``prepare(convert)`` AFTER patch_mask_checks and BEFORE gear/partial wrappers,
then ``install(convert)``
AFTER gear/partial and BEFORE mask wrappers. The original verifier code and
its geometry generator are unchanged. Only that generator's ``next`` call
uses the selector; ordinary next calls retain Python's normal semantics.

Scope is explicit *Attire* filenames. Base rename/overlay rules are untouched.
Weights never participate in selection. Missing, ambiguous or reused targets
fail; the original rig, material, geometry, flag, weight and mask checks run.
"""
import builtins
import functools
import hashlib
import inspect
import json
import os
import threading
import types

import numpy as np

PATCH_VERSION = 'identity-paired-attire-original-verifier-1'
# Canonical fingerprint includes all bytecode, constants, nested code,
# exception tables and source-loop metadata, not only the matching expression.
RAW_VERIFY_DIGEST = 'b4f3478bea18a4e6e1d5cacfa9cd6f168f7ac9ad756506ebec7a0e61f45b2efd'
BASE_CLASSIFIER_DIGEST = '15373e7dcee965b2d3b4d369b382dcbfd3a081efee0aa24ace8fec8fd435888c'
_context = threading.local()


def _code_digest(code):
    def value(item):
        if isinstance(item, types.CodeType):
            return ['code', item.co_name, item.co_filename, item.co_firstlineno,
                item.co_argcount, item.co_posonlyargcount, item.co_kwonlyargcount,
                item.co_flags, item.co_code.hex(), item.co_exceptiontable.hex(),
                item.co_linetable.hex(), item.co_names, item.co_varnames,
                item.co_freevars, item.co_cellvars, [value(v) for v in item.co_consts]]
        if isinstance(item, tuple):return ['tuple', [value(v) for v in item]]
        if isinstance(item, bytes):return ['bytes', item.hex()]
        if isinstance(item, slice):return ['slice', value(item.start), value(item.stop), value(item.step)]
        if item is None or isinstance(item, (str, int, float, bool)):
            return [type(item).__name__, item]
        raise ValueError('unrecognized original code constant')
    return hashlib.sha256(json.dumps(value(code), separators=(',', ':'),
        ensure_ascii=True).encode('ascii')).hexdigest()


def _equal_array(left, right, tolerance=0.):
    a=np.asarray(left);b=np.asarray(right)
    if a.shape!=b.shape:return False
    if not np.isfinite(a).all() or not np.isfinite(b).all():return False
    return bool(np.array_equal(a,b) if not tolerance else np.allclose(a,b,atol=tolerance,rtol=0))


def _remap(mesh):
    return np.arange(mesh.num_verts) if mesh.vertex_remap is None else mesh.vertex_remap


def _stable_identity(source, target):
    """Disambiguate same-name records without reading either weight table."""
    if (source.scene_flag,source.motion_flag)!=(target.scene_flag,target.motion_flag):return False
    if [tuple(g) for g in source.face_groups]!=[tuple(g) for g in target.face_groups]:return False
    if not _equal_array(_remap(source),_remap(target)):return False
    a=np.asarray(source.triangles);b=np.asarray(target.triangles)
    if a.shape!=b.shape:return False
    if not _equal_array(a[np.lexsort(a.T[::-1])],b[np.lexsort(b.T[::-1])]):return False
    if len(source.uvs)!=len(target.uvs):return False
    # Same tolerance as the original UV verifier, solely as a tie breaker.
    if any(not _equal_array(a,b,.0001) for a,b in zip(source.uvs,target.uvs)):return False
    # Shape names/order/size identify records without choosing on moved deltas.
    if [(s[0],len(s[1])) for s in source.shapes]!=[(s[0],len(s[1])) for s in target.shapes]:return False
    return True


class Selection:
    """One call's ordered source records and one-to-one target consumption."""
    def __init__(self, meshes):
        self.meshes=list(meshes);self.ordinal=0;self.consumed=set()
        self.problems=[];self.records=[]
        if not self.meshes:raise ValueError('empty attire source mesh list')
        for mesh in self.meshes:
            if not isinstance(mesh.name,str) or not mesh.name or mesh.num_verts<=0:
                raise ValueError('invalid attire source mesh identity')
            if np.asarray(mesh.positions).shape!=(mesh.num_verts,3):
                raise ValueError('invalid attire source position metadata: '+mesh.name)
            if not np.isfinite(mesh.positions).all():
                raise ValueError('non-finite attire source positions: '+mesh.name)
            if not _stable_identity(mesh,mesh):
                raise ValueError('inconsistent or non-finite attire source identity metadata: '+mesh.name)

    def choose(self, candidates):
        if self.ordinal>=len(self.meshes):
            self.problems.append('attire matcher has more calls than source records')
            return None
        index=self.ordinal;source=self.meshes[index];self.ordinal+=1
        # These are ONLY candidates emitted by the unchanged native geometry
        # generator. Cross-check the snapshot before using its ordinal identity.
        for target in candidates:
            if target.num_verts!=source.num_verts or len(target.triangles)!=len(source.triangles) or \
                    not _equal_array(source.positions,target.positions,.05):
                self.problems.append('attire source-loop identity differs: '+source.name)
                return None
        available=[m for m in candidates if id(m) not in self.consumed]
        exact=[m for m in available if m.name==source.name]
        choice=None;rule=None
        if len(exact)==1:choice=exact[0];rule='unique_expected_name'
        elif len(exact)>1:
            identified=[m for m in exact if _stable_identity(source,m)]
            if len(identified)==1:choice=identified[0];rule='same_name_stable_identity'
            else:self.problems.append('ambiguous same-name attire mesh: '+source.name)
        elif len(available)==1:
            # Preserve the original concrete name-error diagnosis. An unrelated
            # alias is never accepted: the unchanged verifier checks the name.
            choice=available[0];rule='unique_geometry_name_mismatch'
        elif available:self.problems.append('ambiguous attire mesh without expected name: '+source.name)
        elif candidates:self.problems.append('attire output mesh would be reused: '+source.name)
        if choice is not None:self.consumed.add(id(choice))
        self.records.append({'source_index':index,'source_name':source.name,
            'geometry_candidates':len(candidates),'selected_name':None if choice is None else choice.name,
            'selection_rule':rule})
        return choice

    def audit(self):
        if self.ordinal!=len(self.meshes):
            self.problems.append('attire matcher source-loop call count differs: %d/%d' %
                (self.ordinal,len(self.meshes)))
        return {'patch':PATCH_VERSION,'scope':'explicit attire filename; original geometry candidates',
            'source_records':len(self.meshes),'matching_calls':self.ordinal,
            'consumed_output_records':len(self.consumed),'weights_used_for_selection':False,
            'records':self.records,'problems':list(self.problems)}


def prepare(convert):
    """Clone raw verify after mask-check updates, before gear captures globals."""
    if getattr(convert,'_mesh_matching_prepared',None)==PATCH_VERSION:return
    original=convert.verify
    if not isinstance(original,types.FunctionType) or _code_digest(original.__code__)!=RAW_VERIFY_DIGEST:
        raise ValueError('attire matcher requires the exact reviewed original raw verifier')
    classifier=original.__globals__.get('is_base_file')
    if not isinstance(classifier,types.FunctionType) or _code_digest(classifier.__code__)!=BASE_CLASSIFIER_DIGEST:
        raise ValueError('attire matcher requires the exact reviewed base classifier')
    generators=[c for c in original.__code__.co_consts if isinstance(c,types.CodeType)
        and c.co_name=='<genexpr>' and c.co_firstlineno==514 and c.co_freevars==('m',)]
    if len(generators)!=1:raise ValueError('original attire matcher generator is not unique')
    matcher=generators[0];token=object()
    def matching_next(iterator,*default):
        if len(default)>1:return builtins.next(iterator,*default)
        stack=getattr(_context,'stack',())
        current=stack[-1] if stack else None
        if getattr(iterator,'gi_code',None) is not matcher or current is None or current[0] is not token:
            return builtins.next(iterator,*default)
        try:selected=current[1].choose(list(iterator))
        except (ValueError,TypeError,AttributeError,IndexError) as error:
            current[1].problems.append('attire matcher cannot resolve record identity: '+str(error))
            selected=None
        if selected is None:
            if default:return default[0]
            raise StopIteration
        return selected
    namespace=dict(original.__globals__);namespace['next']=matching_next
    cloned=types.FunctionType(original.__code__,namespace,original.__name__,
        original.__defaults__,original.__closure__)
    functools.update_wrapper(cloned,original)
    cloned.__kwdefaults__=original.__kwdefaults__
    convert.verify=cloned
    convert._mesh_matching_token=token
    convert._mesh_matching_prepared=PATCH_VERSION


def install(convert):
    """Add outer call context after gear/partial, before all mask wrappers."""
    if getattr(convert,'_mesh_matching_installed',None)==PATCH_VERSION:return
    if getattr(convert,'_mesh_matching_prepared',None)!=PATCH_VERSION:
        raise ValueError('prepare raw attire matcher before installing verifier wrappers')
    original=convert.verify;token=convert._mesh_matching_token;vc=convert.vc
    @functools.wraps(original)
    def verify(*args,**kwargs):
        bound=inspect.signature(original).bind(*args,**kwargs)
        src=bound.arguments['src_path']
        name=os.path.basename(os.fspath(src)).lower()
        # For this filename the exact original is_base_file is false for BOTH
        # source and output names. Thus there are no skipped overlay records,
        # no misnamed-body remaps and one matching call per source mesh.
        eligible='attire' in name and 'basemodel' not in name
        state=None;failure=None
        if eligible:
            try:state=Selection(vc.read_model(src).meshes)
            except (ValueError,TypeError,AttributeError,IndexError) as error:
                failure='attire matcher cannot establish source identity: '+str(error)
        stack=getattr(_context,'stack',None)
        if stack is None:stack=[];_context.stack=stack
        # A failed/disabled nested call must not inherit an outer source list.
        stack.append((token,state) if state is not None else (None,None))
        try:result=original(*args,**kwargs)
        finally:stack.pop()
        if not eligible:return result
        audit=state.audit() if state is not None else {'patch':PATCH_VERSION,'problems':[failure]}
        problems=list(result[1])+audit['problems'];facts=dict(result[2])
        facts['attire_mesh_matching']=audit
        return bool(result[0] and not audit['problems']),problems,facts
    convert.verify=verify
    convert._mesh_matching_installed=PATCH_VERSION
