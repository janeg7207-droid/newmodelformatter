"""Authored eye values survive without adding template or texture defaults."""
import concurrent.futures
import copy
import hashlib
from pathlib import Path
import struct
import sys
import types
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
# Existing recovered-function test helpers import sibling modules by name.
# Include their directory for both unittest discovery and package-style runs.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from gmf_eye_parameters import preserve_source_eye_parameters, EYE_FLOAT_SLOTS
from gmf_jmtl_audit import Table
from test_local_textures import original_shader_converter, reference_writer


# Values read from the supplied formatted-2K25 Bryan baseModel.mtls, SHA256
# 09fed438ce4917503b60cc59072e22dcc7b89cfb9e3289b467cc309026204e1a.
BRYAN_VALUES = {
    'caustic': 1.0, 'g_eyeRoughness': 1.0, 'g_fFresnel': .8500000238418579,
    'g_refraction': 1.0, 'g_specIntensity': 2.0, 'g_eyeWetness': 0.0,
    'eyeLidShadowDarkness': .10000000149011612,
    'eyeLidShadowFallOff': .15000000596046448,
    'eyeShadowConeSharpness': .10000000149011612,
    'eyeShadowConeBgLevel': .10000000149011612,
    'eyeShadowHorizontalFit': 1.7999999523162842,
    'eyeShadowLidZBias': .5, 'eyeShadowVerticalBias': .12999999523162842,
    'eyeShadowVerticalFit': .4000000059604645,
    'g_pupil_lns': .800000011920929, 'g_pupil_par': .07000000029802322,
    'EyeInsideTex@ref': 15203613993080756645,
    'EyeMaskTex@ref': 258609142176166946,
    'g_fSpecLev': 1.2000000476837158, 'g_fSpecPow': 23.0,
}


def material(values=None, **overrides):
    params = {'colorMap@ref': 12857464407004638857, **(values or {})}
    item = types.SimpleNamespace(shader='yCh_eye', technique='Normal', params=params,
                                 types={key: 2 for key in params})
    item.types['colorMap@ref'] = 7
    for key in ('EyeInsideTex@ref', 'EyeMaskTex@ref'):
        if key in params:
            item.types[key] = 7
    for key, value in overrides.items():
        setattr(item, key, value)
    return item


def payload(data):
    return Table(data, struct.unpack_from('<I', data, 0)[0]).child(2)


class EyeParameterTests(unittest.TestCase):
    def setUp(self):
        self.core = reference_writer()
        self.writer = self.core.write_jmtl
        self.convert = original_shader_converter(0x12)

    def test_actual_bryan_values_survive_recovered_converter_and_writer(self):
        source = material(BRYAN_VALUES)
        before = copy.deepcopy(source.__dict__)
        original = self.convert(source, None)
        self.assertEqual(set(original[1]), {'colorMap@ref'})
        fixed = preserve_source_eye_parameters(source, original)
        raw = self.writer(fixed[0], fixed[1]); table = payload(raw)
        self.assertEqual(len(raw), 152)
        self.assertEqual(hashlib.sha256(raw).hexdigest(),
                         '952afb8ac8360ef89876cba23cee85a05333f2ba0becf38d26869af1b5327f40')
        self.assertEqual(table.number(11, '<f'), 0.0)
        self.assertEqual(table.number(9, '<B'), 1)
        self.assertEqual(table.number(12, '<f'), BRYAN_VALUES['eyeLidShadowDarkness'])
        for key, slot in EYE_FLOAT_SLOTS.items():
            if key in BRYAN_VALUES:
                self.assertEqual(table.number(slot, '<f'), BRYAN_VALUES[key])
        self.assertEqual(table.number(0, '<Q'), before['params']['colorMap@ref'])
        self.assertEqual(table.number(3, '<Q'), 0xefbc052176b84e95)
        for slot in (1, 2, 7, 8):
            self.assertIsNone(table.field(slot, 1))
        self.assertEqual(source.__dict__, before)
        self.assertEqual(set(original[1]), {'colorMap@ref'})
        self.assertIs(fixed[2], original[2])
        self.assertIn('unverified', fixed[3])
        self.assertIs(preserve_source_eye_parameters(source, fixed), fixed)

    def test_explicit_zero_and_false_are_physically_present(self):
        source = material({'g_eyeWetness': 0.0, 'g_refraction': 0.0})
        result = preserve_source_eye_parameters(source, self.convert(source, None))
        table = payload(self.writer(result[0], result[1]))
        self.assertIsNotNone(table.field(11, 4)); self.assertEqual(table.number(11, '<f'), 0.0)
        self.assertIsNotNone(table.field(9, 1)); self.assertEqual(table.number(9, '<B'), 0)
        for slot in (1, 2, 4, 5, 6, 7, 8, 10, 12, 19):
            self.assertIsNone(table.field(slot, 1))

    def test_missing_invalid_untyped_and_unrepresentable_fields_are_unchanged(self):
        for value in (None, '', '0', True, float('nan'), float('inf'), -float('inf'),
                      1e39, 10**1000, [], {}):
            source = material({'g_eyeWetness': value})
            original = self.convert(source, None)
            self.assertIs(preserve_source_eye_parameters(source, original), original)
        for kind in (None, False, True, 0, 1, 6, 7):
            source = material({'g_eyeWetness': 0.0})
            source.types['g_eyeWetness'] = kind
            original = self.convert(source, None)
            self.assertIs(preserve_source_eye_parameters(source, original), original)
        for value in (None, [], 'unreadable'):
            source = material({'g_eyeWetness': 0.0}, types=value)
            original = self.convert(source, None)
            self.assertIs(preserve_source_eye_parameters(source, original), original)

    def test_refraction_matches_editor_finite_nonzero_numeric_rule(self):
        for value, expected in ((0.0, False), (-1.0, True), (.01, True), (True, True), (False, False)):
            source = material({'g_refraction': value})
            fixed = preserve_source_eye_parameters(source, self.convert(source, None))
            self.assertIs(fixed[1]['g_refraction'], expected)
        for value in ('0', None, float('nan'), float('inf')):
            source = material({'g_refraction': value})
            original = self.convert(source, None)
            self.assertIs(preserve_source_eye_parameters(source, original), original)

    def test_other_shaders_techniques_and_future_keys_are_unchanged(self):
        for field, value in (('shader', 'yCh_gear'), ('technique', 'ContactLens'), ('technique', 'Eyelash')):
            source = material({'g_eyeWetness': 0.0}, **{field: value})
            original = self.convert(source, None)
            self.assertIs(preserve_source_eye_parameters(source, original), original)
        source = material({'futureEyeValue': 0., 'g_pupil_lns': .8, 'g_fSpecPow': 23.})
        original = self.convert(source, None)
        self.assertIs(preserve_source_eye_parameters(source, original), original)
        wrong_shader = (0x19, {}, [], None)
        self.assertIs(preserve_source_eye_parameters(material(BRYAN_VALUES), wrong_shader), wrong_shader)

    def test_output_bytes_are_identical_without_authoring_and_for_other_shaders(self):
        for shader in (0x12, 0x1a, 0x19):
            source = material({'futureEyeValue': 0.})
            original = (shader, {'colorMap@ref': 13, 'nrMap@ref': 17}, [], None)
            fixed = preserve_source_eye_parameters(source, original)
            self.assertIs(fixed, original)
            self.assertEqual(self.writer(fixed[0], fixed[1]), self.core.write_jmtl(original[0], original[1]))

    def test_parallel_parameter_preservation_and_writes_do_not_mutate_shared_data(self):
        builder = self.core.flatbuffers.Builder
        globals_before = dict(self.core.write_jmtl.__globals__)
        eye_params = {'colorMap@ref': 11, 'g_eyeWetness': 0., 'g_refraction': False}
        other_params = {'colorMap@ref': 13, 'nrMap@ref': 17}
        expected = {0x12: self.core.write_jmtl(0x12, eye_params),
                    0x19: self.core.write_jmtl(0x19, other_params)}
        cases = [(0x12, eye_params), (0x19, other_params)] * 30
        source = material({'g_eyeWetness': 0., 'g_refraction': 0.})
        before = copy.deepcopy(source.__dict__)
        def convert_and_write(args):
            result = preserve_source_eye_parameters(source, (*args, [], None))
            return self.writer(result[0], result[1])
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
            actual = list(executor.map(convert_and_write, cases))
        self.assertEqual(actual, [expected[shader] for shader, _ in cases])
        self.assertIs(self.core.flatbuffers.Builder, builder)
        self.assertEqual(self.core.write_jmtl.__globals__, globals_before)
        self.assertEqual(source.__dict__, before)


if __name__ == '__main__':
    unittest.main()
