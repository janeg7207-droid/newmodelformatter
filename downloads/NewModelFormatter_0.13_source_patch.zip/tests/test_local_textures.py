"""Bind real named DDS dependencies without replacing external references."""
import copy
import hashlib
import importlib.util
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gmf_local_textures as local
from gmf_2k26_repair import path_hash
from gmf_jmtl_audit import inspect_material, Table
import gmf_repair
from test_material_formats import inline_block, library
from test_material_format_guard import conversion_folder
from test_repair import make_material_module, recovered_function


def dds(width=4, height=4, mips=1, *, dxgi=None, flags=0x81007, caps=0x1000):
    """Independently construct DDS envelopes with complete BC1/BC7 payloads."""
    data = bytearray(148 if dxgi is not None else 128)
    block_bytes = 8 if dxgi in (None, 71) else 16
    struct.pack_into('<4sIIIIIII', data, 0, b'DDS ', 124, flags, height, width,
                     ((width + 3) // 4) * ((height + 3) // 4) * block_bytes, 0, mips)
    struct.pack_into('<II4s', data, 76, 32, 4, b'DX10' if dxgi is not None else b'DXT1')
    struct.pack_into('<I', data, 108, caps)
    if dxgi is not None:
        struct.pack_into('<5I', data, 128, dxgi, 3, 0, 1, 0)
    for level in range(mips):
        w, h = max(1, width >> level), max(1, height >> level)
        data.extend(bytes(((w + 3) // 4) * ((h + 3) // 4) * block_bytes))
    return bytes(data)


def mat(name='eye_l', texture='eye_color', reference=123):
    return types.SimpleNamespace(name=name, shader='yCh_eye', technique='Normal',
        params={'colorMap': texture, 'colorMap@ref': reference,
                'g_nrmMap': 'eye_nrm', 'g_nrmMap@ref': 456},
        types={'colorMap': 6, 'colorMap@ref': 7, 'g_nrmMap': 6, 'g_nrmMap@ref': 7})


def paths(root):
    source = root / 'input' / '159_Bryan_Danielson' / 'BaseModel' / 'baseModel.mtls'
    target = root / 'output' / 'Characters' / '159_Bryan_Danielson' / 'BaseModel' / 'baseModel.mtls'
    source.parent.mkdir(parents=True); (source.parent / 'Textures').mkdir()
    return source, target


def bind(materials, source, target, *, keys=lambda item: ['colorMap@ref'], used=None):
    return local.bind_named_local_textures(materials, source, target,
        game_folder=lambda folder: 'Characters/159_Bryan_Danielson/BaseModel',
        dependency_keys=keys, used_names=used)


class LocalBindingTests(unittest.TestCase):
    def test_named_existing_eye_dds_sets_destination_hash_and_copies_exact_bytes(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); texture = source.parent / 'Textures' / 'eye_color.dds'
            raw = dds(); texture.write_bytes(raw); item = mat(); before = copy.deepcopy(item.params)
            converted, evidence, problems = bind([item], source, target)
            virtual = 'Characters/159_Bryan_Danielson/BaseModel/Textures/eye_color.tex'
            self.assertEqual(converted[0].params['colorMap@ref'], path_hash(virtual))
            self.assertEqual(item.params, before); self.assertIsNot(converted[0].params, item.params)
            self.assertIsNot(converted[0].types, item.types); self.assertEqual(problems, [])
            self.assertEqual((target.parent / 'Textures' / 'eye_color.dds').read_bytes(), raw)
            self.assertEqual(texture.read_bytes(), raw)
            self.assertEqual(evidence[0]['source_sha256'], hashlib.sha256(raw).hexdigest())
            self.assertEqual(evidence[0]['destination_virtual_path'], virtual)
            self.assertEqual(evidence[0]['policy'], local.POLICY)
            self.assertEqual(converted[0].params['g_nrmMap@ref'], 456)

    def test_missing_files_and_null_bindings_preserve_existing_external_refs(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); (source.parent / 'Textures' / 'eye_color.dds').write_bytes(dds())
            for item in [mat(reference=0), mat(reference=0xffffffffffffffff), mat(texture='global_eye')]:
                before = copy.deepcopy(item.params); result, evidence, problems = bind([item], source, target)
                self.assertEqual(result[0].params, before); self.assertEqual(evidence, []); self.assertEqual(problems, [])
            self.assertFalse(target.parent.exists())

    def test_only_the_active_shader_dependencies_and_used_materials_can_change(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp))
            for name in ['eye_color', 'eye_nrm']:
                (source.parent / 'Textures' / (name + '.dds')).write_bytes(dds())
            result, evidence, _ = bind([mat(), mat('unused')], source, target, used={'eye_l'})
            self.assertEqual(result[0].params['g_nrmMap@ref'], 456)
            self.assertEqual(result[1].params['colorMap@ref'], 123)
            self.assertEqual([e['field'] for e in evidence], ['colorMap@ref'])

    def test_windows_case_collision_never_picks_an_arbitrary_texture(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp))
            for name in ['eye_color.dds', 'EYE_COLOR.DDS']:
                (source.parent / 'Textures' / name).write_bytes(dds())
            result, evidence, problems = bind([mat()], source, target)
            self.assertEqual(result[0].params['colorMap@ref'], 123); self.assertEqual(evidence, [])
            self.assertIn('ambiguous', problems[0]); self.assertFalse(target.parent.exists())

    def test_unique_case_insensitive_texture_keeps_actual_filename_and_hash_algorithm(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); texture = source.parent / 'Textures' / 'EYE_COLOR.DDS'
            texture.write_bytes(dds()); result, evidence, problems = bind([mat()], source, target)
            self.assertEqual(problems, []); self.assertTrue((target.parent / 'Textures' / texture.name).exists())
            self.assertEqual(evidence[0]['destination_virtual_path'], 'Characters/159_Bryan_Danielson/BaseModel/Textures/EYE_COLOR.tex')
            self.assertEqual(result[0].params['colorMap@ref'], path_hash(evidence[0]['destination_virtual_path'].lower()))

    def test_traversal_and_source_or_output_symlink_escape_preserve_reference(self):
        for case in ['traversal', 'source', 'output']:
            with self.subTest(case=case), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp); source, target = paths(root); outside = root / 'outside'; outside.mkdir()
                asset = outside / 'eye_color.dds'; asset.write_bytes(dds())
                item = mat(texture='../eye_color') if case == 'traversal' else mat()
                if case == 'source':
                    (source.parent / 'Textures' / 'eye_color.dds').symlink_to(asset)
                else:
                    (source.parent / 'Textures' / 'eye_color.dds').write_bytes(dds())
                if case == 'output':
                    target.parent.mkdir(parents=True); (target.parent / 'Textures').symlink_to(outside, target_is_directory=True)
                result, evidence, problems = bind([item], source, target)
                self.assertEqual(result[0].params['colorMap@ref'], 123); self.assertEqual(evidence, [])
                self.assertTrue(problems); self.assertEqual(asset.read_bytes(), dds())

    def test_overlapping_output_and_source_is_rejected_before_copy(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); texture = source.parent / 'Textures' / 'eye_color.dds'; texture.write_bytes(dds())
            result, evidence, problems = bind([mat()], source, source.parent / 'new.mtls')
            self.assertEqual(result[0].params['colorMap@ref'], 123); self.assertEqual(evidence, [])
            self.assertIn('separate output', problems[0]); self.assertEqual(texture.read_bytes(), dds())

    def test_already_bound_hash_remains_stable_and_required_dependency_still_copies(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); (source.parent / 'Textures' / 'eye_color.dds').write_bytes(dds())
            expected = path_hash('Characters/159_Bryan_Danielson/BaseModel/Textures/eye_color.tex')
            result, evidence, problems = bind([mat(reference=expected)], source, target)
            self.assertEqual(result[0].params['colorMap@ref'], expected); self.assertFalse(evidence[0]['changed'])
            self.assertEqual(problems, []); self.assertTrue((target.parent / 'Textures' / 'eye_color.dds').exists())

    def test_invalid_named_dds_does_not_emit_a_replacement_reference(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); (source.parent / 'Textures' / 'eye_color.dds').write_bytes(dds()[:-1])
            result, evidence, problems = bind([mat()], source, target)
            self.assertEqual(result[0].params['colorMap@ref'], 123); self.assertEqual(evidence, [])
            self.assertIn('mip extents', problems[0]); self.assertFalse(target.parent.exists())
            self.assertIn('eye_color.dds', problems[0]); self.assertTrue(problems[0].endswith('; reference preserved'))

    def test_sparse_caps_binding_uses_exact_supported_texture_and_preserves_all_bytes(self):
        for dxgi in (None, 98):
            with self.subTest(dxgi=dxgi), tempfile.TemporaryDirectory() as tmp:
                source, target = paths(Path(tmp)); texture = source.parent / 'Textures' / 'eye_color.dds'
                raw = dds(7, 5, 3, dxgi=dxgi, caps=0); texture.write_bytes(raw)
                item = mat(); before = copy.deepcopy(item.params)
                result, evidence, problems = bind([item], source, target)
                virtual = 'Characters/159_Bryan_Danielson/BaseModel/Textures/eye_color.tex'
                self.assertEqual(problems, []); self.assertEqual(len(evidence), 1)
                self.assertEqual(result[0].params['colorMap@ref'], path_hash(virtual))
                self.assertEqual(result[0].params['g_nrmMap@ref'], before['g_nrmMap@ref'])
                self.assertEqual(item.params, before); self.assertEqual(texture.read_bytes(), raw)
                copied = (target.parent / 'Textures' / texture.name).read_bytes()
                self.assertEqual(copied, raw); self.assertEqual(struct.unpack_from('<I', copied, 108)[0], 0)
                self.assertEqual(evidence[0]['source_sha256'], hashlib.sha256(raw).hexdigest())
                self.assertEqual(evidence[0]['output_sha256'], evidence[0]['source_sha256'])
                self.assertFalse(evidence[0]['dds']['capsTextureBitPresent'])
                self.assertTrue(evidence[0]['dds']['header_advisories'])


class DdsExtentTests(unittest.TestCase):
    def test_sparse_texture_caps_are_advisory_only_for_complete_supported_payloads(self):
        for dxgi in (None, 71, 98):
            with self.subTest(dxgi=dxgi):
                complete = local.inspect_dds(dds(7, 5, 3, dxgi=dxgi))
                sparse = local.inspect_dds(dds(7, 5, 3, dxgi=dxgi, caps=0))
                for key in ('width', 'height', 'mip_count', 'format', 'payload_bytes', 'header_and_extents_validated'):
                    self.assertEqual(sparse[key], complete[key])
                self.assertTrue(complete['capsTextureBitPresent']); self.assertEqual(complete['header_advisories'], [])
                self.assertFalse(sparse['capsTextureBitPresent']); self.assertIn('original bytes preserved', sparse['header_advisories'][0])

    def test_sparse_caps_do_not_bypass_actual_dimensions_or_required_dimension_flags(self):
        cases = [(12, 0, 'dimensions'), (16, 0, 'dimensions'), (8, 0, 'dimension flags')]
        for offset, value, expected in cases:
            with self.subTest(offset=offset):
                raw = bytearray(dds(caps=0)); struct.pack_into('<I', raw, offset, value)
                with self.assertRaises(ValueError) as caught: local.inspect_dds(bytes(raw))
                message = str(caught.exception)
                self.assertIn(expected, message)
                for detail in ('width=', 'height=', 'flags=0x', 'caps=0x0'): self.assertIn(detail, message)

    def test_sparse_caps_do_not_bypass_header_sizes_or_complete_mip_extents(self):
        base = dds(caps=0); bad_header = bytearray(base); struct.pack_into('<I', bad_header, 4, 123)
        bad_pixel_format = bytearray(base); struct.pack_into('<I', bad_pixel_format, 76, 31)
        for raw in (bytes(bad_header), bytes(bad_pixel_format), base[:-1], base + b'extra',
                    dds(4, 4, 4, caps=0), dds(dxgi=98, caps=0)[:140]):
            with self.subTest(length=len(raw)), self.assertRaises(ValueError): local.inspect_dds(raw)

    def test_sparse_caps_do_not_bypass_cube_volume_array_or_resource_dimension_guards(self):
        base = dds(dxgi=98, caps=0)
        cases = [(112, 0x200), (24, 2), (136, 4), (140, 2), (132, 4)]
        for offset, value in cases:
            with self.subTest(offset=offset):
                raw = bytearray(base); struct.pack_into('<I', raw, offset, value)
                with self.assertRaises(ValueError): local.inspect_dds(bytes(raw))

    def test_all_bc1_mips_and_nonaligned_dimensions_are_bounded(self):
        self.assertEqual(local.inspect_dds(dds(7, 5, 3))['mip_count'], 3)
        for raw in [dds()[:-1], dds() + b'extra', dds(4, 4, 4)]:
            with self.assertRaises(ValueError): local.inspect_dds(raw)

    def test_complete_bc7_with_observed_advisory_flag_omissions_remains_supported(self):
        result = local.inspect_dds(dds(8, 8, 4, dxgi=98, flags=0x20006))
        self.assertEqual(result['format'], 'DXGI_98'); self.assertTrue(result['header_and_extents_validated'])

    def test_cube_array_unknown_format_and_truncated_dx10_are_rejected(self):
        base = dds(dxgi=98)
        cube = bytearray(base); struct.pack_into('<I', cube, 136, 4)
        array = bytearray(base); struct.pack_into('<I', array, 140, 2)
        for raw in [bytes(cube), bytes(array), base[:140], dds(dxgi=28)]:
            with self.assertRaises(ValueError): local.inspect_dds(raw)


def reference_writer():
    root = Path(__file__).resolve().parents[1] / 'reference_source' / 'WWE2K_MDL'
    vendor = root / 'Blender' / '_vendor' / 'flatbuffers'
    spec = importlib.util.spec_from_file_location('local_texture_test_fb', vendor / '__init__.py', submodule_search_locations=[str(vendor)])
    module = importlib.util.module_from_spec(spec); sys.modules[spec.name] = module; spec.loader.exec_module(module)
    prior = sys.modules.get('flatbuffers'); sys.modules['flatbuffers'] = module
    try:
        spec = importlib.util.spec_from_file_location('local_texture_reference_writer', root / 'Serialize' / 'jmtl_writer.py')
        writer = importlib.util.module_from_spec(spec); spec.loader.exec_module(writer)
    finally:
        if prior is None: sys.modules.pop('flatbuffers', None)
        else: sys.modules['flatbuffers'] = prior
    return writer


def original_shader_converter(shader):
    namespace = dict(SKIN=25, HEAD=23, CARUNCLE=19, EYE=18, EYELASH=20, GEAR=21, HAIR=22, TEETH=26,
        GEAR_SOLID=0, GEAR_CUTOUT=1, GEAR_SEE_THROUGH=2, GEAR_IRRADIANCE=(0, .75, .75),
        TEETH_IRRADIANCE=(0, .7490196, .7490196), shader_for=lambda item: (shader, None),
        _ref=lambda item, key: item.params.get(key),
        _num=lambda item, key, default=None: item.params.get(key, default), clean_name=lambda value: value.split(':', 1)[0])
    return recovered_function('gmf.materials', 'to_2k26', namespace)


class OriginalConverterBindingTests(unittest.TestCase):
    def setUp(self):
        self.writer = reference_writer()

    def converter(self, items, shader):
        module = make_material_module(items)
        converter = original_shader_converter(shader)
        module.to_2k26 = converter; module.convert_library.__globals__['to_2k26'] = converter
        module.write_jmtl = self.writer.write_jmtl; module.convert_library.__globals__['write_jmtl'] = module.write_jmtl
        module.game_folder = lambda folder: 'Characters/159_Bryan_Danielson/BaseModel'
        module.convert_library.__globals__['game_folder'] = module.game_folder
        gmf_repair.patch_material_converter(module)
        return module

    def test_recovered_eye_converter_and_reference_writer_emit_bound_color_and_global_normal(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); source.write_bytes(library([inline_block()], ['eye_l']))
            (source.parent / 'Textures' / 'eye_color.dds').write_bytes(dds())
            item = mat(); before = copy.deepcopy(item.params); module = self.converter([item], 0x12)
            report = module.convert_library(str(source), str(target), {'eye_l'})
            actual = inspect_material((target.parent / 'Materials' / 'eye_l.jmtl').read_bytes())
            self.assertEqual(actual['face_texture_check']['color_ref'], path_hash('Characters/159_Bryan_Danielson/BaseModel/Textures/eye_color.tex'))
            self.assertTrue(actual['face_texture_check']['reference_normal_match'])
            self.assertEqual(item.params, before); self.assertEqual(len(report['local_texture_bindings']), 1)
            self.assertTrue((target.parent / 'Textures' / 'eye_color.dds').exists())

    def test_custom_body_atlas_teeth_refs_and_explicit_source_irradiance_are_emitted(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, target = paths(Path(tmp)); source.write_bytes(library([inline_block()], ['teeth']))
            item = mat('teeth', 'body_color'); item.shader = 'yCh_Teeth'
            item.params.update(g_nrmMap='body_nrm', irradianceR=1., irradianceG=.75, irradianceB=.75)
            for name in ['body_color', 'body_nrm']:
                (source.parent / 'Textures' / (name + '.dds')).write_bytes(dds())
            before = copy.deepcopy(item.params); module = self.converter([item], 0x1a)
            report = module.convert_library(str(source), str(target), {'teeth'})
            raw = (target.parent / 'Materials' / 'teeth.jmtl').read_bytes(); actual = inspect_material(raw)
            check = actual['face_texture_check']
            self.assertEqual(check['color_ref'], path_hash('Characters/159_Bryan_Danielson/BaseModel/Textures/body_color.tex'))
            self.assertEqual(check['normal_ref'], path_hash('Characters/159_Bryan_Danielson/BaseModel/Textures/body_nrm.tex'))
            payload = Table(raw, struct.unpack_from('<I', raw, 0)[0]).child(2)
            illumination = payload.child(6)
            self.assertEqual([illumination.number(i, '<B', 0) for i in range(3)], [255, 191, 191])
            self.assertEqual(item.params, before); self.assertEqual(len(report['local_texture_bindings']), 2)
            self.assertIn('source teeth irradiance', report['notes'][0])

    def test_recovered_folder_generic_copy_off_still_keeps_required_bound_texture(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source, target = paths(root)
            source.write_bytes(library([inline_block()], ['eye_l']))
            source.with_suffix('.mdl').write_bytes(b'original model fixture')
            texture = source.parent / 'Textures' / 'eye_color.dds'; texture.write_bytes(dds())
            module = self.converter([mat()], 0x12); folder = conversion_folder(module)
            original_namespace = folder.convert_folder.__wrapped__.__globals__
            original_namespace['_used_materials'] = lambda path: ({'eye_l'}, {'M_EYE': 3})
            report = folder.convert_folder(str(source.parent.parent), str(root / 'output'),
                                           log=lambda text: None, copy_other=False)
            table = Path(report['materials'][0]['output'])
            self.assertTrue(table.exists()); self.assertEqual(report['copied'], 0)
            self.assertEqual((table.parent / 'Textures' / 'eye_color.dds').read_bytes(), dds())
            self.assertEqual(texture.read_bytes(), dds()); self.assertEqual(report['problems'], [])
            self.assertEqual(len(report['materials'][0]['local_texture_bindings']), 1)


if __name__ == '__main__':
    unittest.main()
