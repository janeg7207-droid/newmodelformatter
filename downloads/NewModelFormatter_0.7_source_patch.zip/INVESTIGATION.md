# Update: 0.7 reports and paired-body Rey gear

Current supported behavior and evidence are in NEW_FORMATTER.md. 89 tests
passed. Actual Rey base/attire conversions under Wine passed with the optional
paired-body surface policy on five meshes, plus independent written-weight
checks and deliberate wrong-bone corruption rejection. All 14 attire geometry
comparisons passed. The original verifier's untouched-weight assumption was
replaced only for deliberately projected mesh weights; other checks remain.
The donor is now usable only after the original paired-base verification passes.
This is an experimental policy requiring in-game movement/coverage checks.

Final/error reports now have one atomic commit point, a mirror in the opened
mod folder, a Temp fallback, retained intermediate records, and a UI button.
Actual Rey/Billie returned reports matched both saved copies. Native 2K26
model/JMTL byte preservation and UI startup passed. No AJ beard or Billie eye
fix is claimed. Latest AJ files are native 2K26 with empty embedded HPLs.

The following sections retain historical investigation notes; statements about
unshipped prototypes or missing reference source refer to those earlier stages.

# Update: 0.6 independent YCL translation and dark-eye investigation

User prioritized FIX YCL after supplying the missing PWM source. The folder
wrapper now uses the unchanged Gorilla YCL translator even when unrelated
WDF/YWA companions are unsupported. Actual Billie isolated-folder conversion
produced the expected 1,254,192-byte YCL, hash b3560ad5..., with names retained
and source untouched. A fresh supplied YclEditor read/write under Wine produced
byte-identical bytes. 59 regression tests passed; UI smoke passed. Companion
omissions remain explicit; this is not an in-game motion validation.

The dark Billie eye screenshot is new visual evidence. The eye material and
geometry are in her BaseModel, which has not been uploaded individually. The
previously uploaded baseModel files belong to Rey. Her original BaseModel MCD,
inline MTLS and the produced eye_l JMTL are required to compare eye shaders,
texture bindings and shading anchors. No eye-brightness change is guessed.

The new supplied WWE2K_MDL source is complete enough to inspect the previously
external routines; its native DLL matches Gorilla exactly. Source/configuration
snapshots are preserved. The nearest-surface prototype failed the original
untouched-weight check and is preserved outside the release. It is not shipped
or called a verified fix. See NEW_FORMATTER.md for current evidence and limits.

# Update: paired bases and reference-source integration (0.5)

The requested Rey source base is now uploaded and matches the original report
hash. Native 0.4 and 0.5 folder conversions recovered the mask with source files
unchanged: base/attire verify pass, Body/Head remap and topology equal, all mask
indices valid, 490,532-byte embedded HPL preserving both flags at five LODs.
Tests used isolated model/HPL copies without material libraries; no full mod
or in-game appearance claim follows. See NEW_FORMATTER.md and the published
Rey_Paired_Base_Mask_Validation.json for current evidence.

All latest reference archive parts and Vynx match earlier uploaded hashes.
Six provided source files were copied with provenance. The original reference
weight checks are integrated into reports; 52 tests and Wine UI/native smokes
passed. The full reference conversion engine remains blocked by its separate,
missing WWE2K_MDL Blender dependency. Gorilla's YCL stays unchanged.

# Current status (0.4)

See NEW_FORMATTER.md for current implementation, evidence and missing-file scope.
The entries below are historical investigation notes; earlier packaging counts
and unrun-check statements describe their respective earlier builds. Current
0.4 has 43 passing tests and Wine UI/native-2K26 smoke evidence.

# Investigation results and evidence limits

## New evidence: supplied Billie companion files and Windows Rey report

All five requested Billie companions have now been supplied and inspected
read-only. The measured SIZ/MOD table framing consumes the complete tables;
the SIZ scalar equals the number of MOD sections, not a demonstrated game
version. The empty 200-byte `other_corr_ywa` has two empty metadata tables.
Do not change its section count to a purported 2K26 version number.

`hair_ywa` and `other_ywa` each name 353 hair-chain records. Only 108 names
exist in the actual source rig; the other 245 are also absent from the
converted rig. `hair_corr_ywa` names an M_Hair mapping domain of 10,014 and
an S_Hair domain of 1,059, whereas the actual model has 6,719 and 363 vertices.
Its body/head table may refer to a separate base model; its absence from an
attire model alone is not an error. The supplied WDF has one measured MESH
record named M_Pierce with 270 entries of 48 bytes; M_Pierce is absent from
Billie's actual attire model. These facts prevent certifying the supplied
mappings as compatible; they do not prove how 2K25 handles unused mappings.

The reference archive contains no WDF/YWA writer implementation. The native
DLL exports raw-substream transfer functions but no exposed WDF/YWA physics
generator was found. Full link-payload semantics and a verified 2K26 writer
remain unresolved. No companion was copied into output or modified. Evidence
is `Billie_Companion_Validation.json` with the reproducible read-only inspector
under `billie-companion-review/inspect_companions.py` in the investigation workspace.

The newly supplied Rey report contains patch identifier
`material-binding-and-gear-profile-3` and records the optional ancestor policy
on wings, tops, and shoulder pads. It is evidence of a user-run patched
conversion on Windows, rather than an independent Windows GUI/game test.
Its model SHA matches the tested Rey source. Its HPL input is different:
81,408 bytes / SHA-256
`57abd17dd82782bcd4c1509c311d3f70227af707e7975a2e1b3fcbf1eae2c3dd`.
This is not the readable 196,220-byte HPL uploaded earlier and tested with
the same model. The report correctly marks the unreadable mask as incomplete.
Use a copy of the input folder with that earlier readable mask to validate the
mask path; preserve the original folder and convert to a separate output.

The report's source is explicitly inside `_formatted_2K25`, with MCD inputs
in its inventory. This establishes use of an intermediate formatted directory
for this run, explaining the MDL-archive/MCD-report discrepancy without
establishing which earlier program generated those intermediates.

## New evidence: actual Billie model and YCL

The actual `873_Attire.mcd` has SHA-256
`f304899095dbc9a7b9c5a6fae0ad7cce2c84b48f92e445c2a75fc9425756f6b0`.
The original native reader under Wine found version 0x29, 334 bones, 14 meshes,
and exactly one simulation mesh: `S_Hair`, with 363 vertices and 428 triangles.
The actual `M_Hair` binding is `hair_alpha:skinned`, confirming the earlier
report's mismatch with the uploaded library's `hair_ALPHA:skinned` definition.
The patched original writers emit all 13 actual nonsimulation bindings, retain
the simulation `lambert1` exemption, and retain the hair shader/texture hashes.

Baseline patched-native conversion passed the original verifier. All 14 meshes
retain positions, triangles, normals, UVs, remaps, shape positions, and material
bindings. Tangents differ because the original writer regenerates them. The
original skinning still reweights 249 `S_Hair` vertices. Uploaded originals'
hashes are unchanged. This is model/material validation under Wine, without
texture images, complete physics, CakeView baking, or an in-game appearance test.
The HPL bounds still use historical base-model counts; actual base bytes are absent.

The actual `873_Attire.ycl` has SHA-256
`4c24d15c8204c06662b6c85f3ea71d0881789325f92afbcd5e2713fe2c5d5a93`.
Its 345-node tree parses. Gorilla's built-in translator and the supplied
reference YclEditor produce byte-identical 2K26 outputs on preserved copies;
the editor's reread/rewrite check is stable. There is no demonstrated YCL
format-translator defect for this file.

The source YCL contains populated `S_Outfit` and `S_Outfit_withBelt` simulations
(234 vertices / 238 triangles each), plus populated `M_Outfit` and
`M_Outfit_withBelt` render targets absent from the actual model. These are not
disabled reference-tool placeholders. Its `S_Hair` counts and permutation
indices fit the model, and all 141 non-null joint links survive the original
skeleton conversion. Count/name checks do not establish skin-link or geometric
compatibility. Its internal `969_Attire` name differs from the supplied filename;
the reason is unresolved and no automatic renaming/deletion is justified.

Gorilla's folder guard classifies any substantial skipped companion as cloth,
including `.hair_ywa` and `.hair_corr_ywa`, and consequently blocks YCL conversion.
Do not remove that guard until the accompanying mappings are inspected. Still
needed: `873_Attire.hair_ywa`, `873_Attire.hair_corr_ywa`, `873_Attire.other_ywa`,
`873_Attire.other_corr_ywa`, and `873_Attire.wdf` from the original attire folder.

Evidence: `Billie_Native_Model_Validation.json` and `Billie_Physics_Validation.json`.
No unchanged 2K25 physics, invented simulations, deleted outfit nodes, or claims
of working in-game movement are part of the patch.

## Blood and belt comparison

The supplied reference's Belt CS Fix option forwards `belt_cs_fix` to an
external WWE2K_MDL exporter, defaults off, and lacks that exporter's source.
Blood shader parameters are present, but no dedicated blood repair is proven.
Both the reference and Gorilla request CTG generation for base models. No
supplied converted samples or in-game checks establish working blood or belts;
no blood/belt changes are included in this repair.

## Version 0.3 compatibility scope and user clarification

The user reports no currently reproducible black-teeth issue and requests the
existing input/output methods be retained. Teeth changes are deferred; teeth
files are not currently requested and do not block the remaining hair/cloth
repair.

Version 0.3 retains Gorilla's original startup entrypoint with the new UI
subclass. Positional source-folder prefill, `--auto`, `--dst`, `--slot`, `--shot`,
exit status, and Windows DPI setup follow the original implementation. Folder
selection, slot mapping, file formats, model/material readers and writers, and
CakeView checks/baking remain the existing workflow. The additional audit
fields are written to the original normalized conversion-report destination.

Material alias repair now prefers an exact binding match. It attempts a unique
case alias only when the exact name is absent. Duplicate cleaned definitions
retain Gorilla's first-used behavior; unused definitions, missing-material notes,
and the `lambert1` exemption keep their original handling. Ambiguous aliases
still fail before material writes. The patch identifier is
`material-binding-and-gear-profile-3`.

## New evidence: actual Rey MCD, native checks, and optional gear profile

The supplied `123_Attire.mcd` is 10,506,864 bytes, SHA-256
`c181b2889e01a8ebb76f020457de7466a099ae327d87514e1cd44b36b3f6245c`.
The original native reader opened it under Wine: version 0x29, 209 bones,
14 meshes. Their vertex counts match the historical report. It has no S_*
simulation mesh or named wing/cloth bone branch; the three investigated gear
meshes are weighted to chest, clavicle, shoulder, and related helpers.
This supports a bone-driven attachment investigation, not invented cloth.
The file contains an empty internal HPL marker but no captured raw substream;
the separately supplied HPL is readable. Its identity relative to the earlier
MDL-only archive still requires the original MDL or an export/rename history.

The original converter ran on COPIES of the MCD and readable HPL using its
bundled native DLL and reference caches. It reproduces the report's 7,967
selected reweight vertices and 924 own-part trust cases. In this run the HPL
is successfully carried, including 10,977 body and 1,273 head indices for
ring/entrance. Structural verification passes. Positions, triangles, UVs,
and material bindings are exactly unchanged across all 14 meshes. Base mask
limits are taken from the report pending the actual base-model upload.

The baseline wing conversion changes summed clavicle influence from about
2,834 to 1,886 and introduces head and stock muscle influence absent from the
source wing weights. The effect on visual deformation remains untested.

An explicit experimental alternative for this exact source hash preserves
source weight budgets and remaps only removed helper bones through the
original inheritance map. It is limited to M_Wings, M_Tops, M_ShoulderPad,
off by default, and applied consistently when the original verifier recomputes
expected weights. This alternate conversion also passes native structural
verification and preserves all geometry/UV/material bindings. Serialization
still performs the original packed-weight normalization/quantization.
The report flags entrance/gameplay validation as outstanding; this is not
proof of a visual fix. See `/workspace/artifacts/Rey_Native_Model_Validation.json`.

## ModelFormatter reference archive

All seven volumes joined to a 192,214,479-byte 7z with valid start/next-header
CRCs and successful extraction. It contains a 21,576-line Blender add-on,
MaterialGenerator.cs, MaterialGeneratorWorking.cs, bridges/material editor
assemblies, and YclEditor.exe. It relies on Blender/WWE2K_MDL operators rather
than providing a complete standalone Python model engine.

Its attire path calls Heat Seek Attire plus animation-compatibility mapping;
it is not evidence that a copied sidecar is compatible with a converted rig.
`convert_ycl_file` exports with YclEditor `--export-one ... 4`. The missing-YCL
fallback can write a donor file after disabling all donor simulation names
when there is no compatible target S_* topology. That explains a possible
"file exported but no simulation" outcome, not the confirmed cause of Billie's
movement issue. This fallback is not used by NewModelFormatter.

The main C# generator branches teeth between yCh_Teeth and yCh_skin based on
WWE-base classification, whereas the working variant uses a different teeth
skin correction. Neither path establishes a black-teeth cause. The user reports
no currently reproducible issue, so no tooth shader override was implemented
and no teeth assets are currently requested.

## New evidence: directly supplied Billie MTLS

The supplied `873_Attire.mtls` is 16,784 bytes, SHA-256
`fba5f0a65653a8327f53482ce01e9241db8d477ec90985cfb5c3cca0580ed8ab`.
Its 13 definitions include `hair_ALPHA:skinned`, `hair2_ALPHA:skinned`, and
`hair3_ALPHA:skinned`, using `yCh_hair / NewHair_ColorChanging`. There is no
lowercase `hair_alpha` definition.

An additional material-only validation used the real recovered MTLS reader,
shader conversion, original MTLS/JMTL writers, and the EXE's embedded
FlatBuffers dependency. Using the binding names from the historical report,
the unchanged converter drops hair_ALPHA; the patched converter writes
hair_alpha and resolves all 13 reported bindings. An independent FlatBuffer
field read confirms shader 0x16 and retention of the source flowMap/comboMap
hashes. The absent pixel-mask reference remains 0xFFFFFFFFFFFFFFFF rather than
becoming another wrestler's fixed mask. The source file hash is unchanged.

This validates the material case repair against the actual supplied MTLS,
but the mesh bindings are still taken from the report. The actual model,
texture files, physics, Windows runtime, and game have not been checked.
Material-only diagnostic outputs must not be baked as a complete conversion.
See `/workspace/artifacts/Billie_Material_Validation.json`.

## New evidence: directly supplied Rey HPL

The individually uploaded `123_Attire.hpl` is 196,220 bytes with SHA-256
`b00ba528b83157ff028cd85f542734b3e46780ebfcde68c708f6c56934d1bbf7`.
The unchanged original `_parse_hpl` accepts its complete contents. LODs 0 and
1 each contain ring/entrance masks for M_Body (10,977 indices, max 12,754) and
M_Head (1,273 indices, max 3,993). No indices are dropped against the base-model
vertex counts in the historical report. Actual base-model bytes are still
needed to validate those bounds independently.

The original filter/build functions produce a readable 2K26-style mask whose
LODs retain all these indices. This is a mask serialization check, not a model
conversion or in-game skin-hiding check. The individual upload contradicts the
historical report's claim that its input mask was unreadable. The identity of
the file actually used for that report remains unresolved; the report contains
no source hash. Do not replace a model or claim visual repair from this result.

See `/workspace/artifacts/Rey_Hide_Mask_Inspection.json` for the recorded checks.

## Available evidence

Read `START_HERE.md`, both JSON reports, archive_inventory.json, and the
headerless Python 3.14 marshal modules. Disassembled the recovered modules
without importing/executing their top-level code. Printable-string inventories
were treated as supporting context, not reconstructed source. The original
handoff and its recovered code remain unchanged outside this patch project.

The single-file EXE upload initially exceeded the transfer limit. The two-part
formatter archive subsequently transferred successfully (31,457,280 and
3,930,417 bytes). The joined archive's start/next-header CRCs validate; extraction
completed successfully. Its EXE hash is
`ece4729f2ac3fc707c69550d4a79df7866c11a61463d8eb529ae927e04f377f2`, matching
the handoff. All recovered gmf modules supplied in the handoff and gmf_gui match
the EXE byte-for-byte. The EXE's README explicitly says separate cloth data is
not converted yet.

Billie's RAR and `123_Rey_Mysterio_2019.7z` still cannot transfer because each
exceeds 32 MiB. Their bytes and hashes remain unverified. The new Rey archive
has a different filename from the earlier inventory's
`Grix - Rey Mysterio All In (1).7z`; equality is not assumed.

## Rey: hide mask

Recovered `gmf.mcd._parse_hpl` (lines 63-98) expects an `HPL!` header, followed
by `LOD!`, `DATA`, and `MESH` records. It imposes a mesh-name length ceiling,
checks index-buffer lengths, and accepts empty/zero padding or an `END!` tail.
Recovered `gmf.convert.expected_mask` (lines 258-274) returns `unreadable`
when `hpl_is_whole` rejects the bytes.

`_sidecar_streams` (lines 277-307) then writes an empty HPL. `_check_mask`
(lines 388-406) considers that empty output valid when the unreadable source
produces an empty expected mask. This explains the supplied report's combination
of `hide_mask: unreadable`, `verify: pass`, and no problems/warnings.

The patch reports this as incomplete verification and removes the unsupported
damage diagnosis. It does not reconstruct a mask or guess hidden vertices.
The actual `123_Attire.hpl` must be read before deciding whether its layout is
unsupported, wrapped, intentionally empty, or damaged.

## Rey: wings, tops, shoulder pads

Recovered `gmf.skeleton.convert_weights` (lines 173-261) selects vertices with
weight on removed/inherited bones, samples nearby stock body weights, compares
source and stock body-part distributions, and blends inherited weights toward
stock weights. Its blend uses removed-bone weight mass and body-part agreement;
the recorded nearest-skin distance is diagnostic and does not itself gate the
blend. Thus a loose wing and nearby torso can agree on body part while having
different intended deformation. This is a plausible limitation, not a proven
cause of Rey's visual fault.

The report records M_Tops: 1,681 selected vertices, max distance 10.56;
M_ShoulderPad: 1,726, max distance 6.06; M_Wings: 4,560, max distance 11.81,
with 924 partially/fully retaining own-part weighting. `verts_changed` counts
vertices selected by removed-bone mass, not an exact before/after weight diff;
`kept_own_part` counts trust values below 1, including partial blending.

No mesh-specific name exception or unvalidated global distance threshold was
implemented. Need actual source positions, parent hierarchy, per-vertex
weights, output weights, and intended movement to choose a supported repair.
Rey's earlier inventory has no separate physics files. None are invented or
borrowed. Bone animation and simulated cloth remain separate questions.

## Rey: MDL versus MCD inputs

Recovered `gmf.folder.convert_folder` scans both `.mdl` and `.mcd` (line 286).
When both share a stem, it selects the `.mcd` and excludes the `.mdl` twin
(lines 288-292). The wording "older copy" is an assumption: that branch checks
names, not timestamps or semantic equivalence.

`gmf.convert.convert_mcd` calls `read_model(src_path)` and reports that same
`src_path` as `source` (lines 313-314). It does not relabel an MDL source as MCD
in the report. Consequently the supplied report points to MCD paths passed to
conversion, whereas the earlier archive inventory lists MDL files. A rename,
re-export, intermediate, another input folder, or different tool version could
explain it. The evidence does not identify which. Future patched reports record
input hashes; a historical report cannot recover missing input bytes.

## Billie: material mismatch

`gmf.materials.clean_name` strips the suffix beginning at `:` but preserves case
(lines 46-47). `folder._used_materials` supplies cleaned mesh material bindings.
`materials.convert_library` filters definitions with exact membership in
`used_names` (lines 305-315). The report shows `hair_ALPHA` excluded and
`hair_alpha` unresolved, while hair2_ALPHA and hair3_ALPHA convert.

The patch prefers exact binding matches. If an exact match is absent, it
resolves only a unique case alias, copies the definition to the exact mesh
binding name, and retains parameters and suffix. Duplicate cleaned definitions
retain the original first-used behavior. Unused definitions and missing-binding
notes keep Gorilla's handling, including the `lambert1` exemption. Ambiguous
aliases fail before writes. Material encoding/texture lookup is delegated to
the original pipeline.

Regression tests reproduce the original loss using the recovered function,
then produce both intended MTLS entries and matching path hashes. Actual hair
shader encoding, texture links in the real assets, and visual transparency
remain untested. Billie S_Hair's 249 selected reweighting vertices and 13.75
distance are a separate attachment investigation; no weights were changed.

## Billie: physics

`folder.convert_folder` explicitly detects nonempty `LEFT_OUT_SIDECARS`
(lines 397-399) and refuses the YCL conversion when they are present. The report
lists hair_corr_ywa, hair_ywa, other_corr_ywa, other_ywa, wdf, and ycl as omitted.
This is an unsupported mixed hair/cloth path, not a case mismatch or accidental
missing copy.

The recovered `ycl_own` documents measured YCL node-layout transformations;
those embedded documentation claims are not independently verified tests in
this session. They do not establish conversion of WDF/YWA companions, their
references, or compatibility with the converted skeleton. No blocker branch
was removed, old sidecar copied, or untested physics generated. The patch
exposes the existing limitation as an incomplete conversion in the GUI's
problems/report flow.

## What is still needed

First, make the already supplied MOD archives transferable: split each into
30 MiB volumes with 7-Zip and upload every volume. The formatter is now complete;
it does not need to be uploaded again. This requests alternate packaging of
existing files, not different mods.

To establish the historical Rey input discrepancy, supply the exact
`BaseModel/baseModel.mcd` and `123_Default_Attire/123_Attire.mcd` used for that
report if the new archive does not contain them. For real before/after
validation, the current converted Rey and Billie folders and an indication of
the defective meshes/movement will be needed. Comparable native 2K26
hair/cloth files are needed only if the EXE's bundled references prove
insufficient. Do not assume a missing separate Rey physics file exists.

After asset inspection and a supported conversion, Windows/CakeView validation
must confirm selection/unlock and native engine operation. In-game entrance
and gameplay must check Rey's wings/tops/pads and skin hiding; Billie's hair
materials/transparency, attachments, and hair/cloth simulation; and both
attires' mesh/texture preservation. Structural reports alone do not establish
these results.

## Experimental EXE packaging validation

`build_patched_exe.py` adds the tested repair module and a bootstrap script,
then reparses the resulting CArchive. It verifies the PE prefix, all 1,067
existing non-PYZ payloads (including GUI and native DLLs), and all 423 existing
PYZ module payloads are unchanged. An independent PyInstaller 6.22.3 reader
also extracted and compared every retained non-PYZ payload successfully.
Standard-library dependencies used by the hook are present in PYZ or the
original base_library.zip. The CakeView check module remains byte-identical.

The EXE contains body/skeleton/slot references and blank-physics templates;
no separate native hair/cloth reference models or WDF/YWA sidecar sets appear
in its archive inventory. Those caches cannot establish mixed-physics
compatibility. Windows startup/GUI/native engine and game tests remain unrun.
