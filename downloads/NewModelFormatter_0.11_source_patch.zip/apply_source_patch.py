"""Apply the runtime hook to a COPY of the complete original source project."""
import argparse
import ast
from pathlib import Path
import shutil


def apply(project):
    project = Path(project).resolve()
    gui = project / 'gmf_gui.py'
    required = [gui, *(project / 'gmf' / f'{name}.py'
                      for name in ('materials', 'folder', 'convert', 'engine'))]
    absent = [str(p) for p in required if not p.is_file()]
    if absent:
        raise ValueError('Complete original source project required; missing: ' + ', '.join(absent))
    text = gui.read_text(encoding='utf-8')
    marker = '# GMF_REPAIR_HOOK_V1'
    if marker in text:
        raise ValueError('Hook already installed; no files changed')
    tree = ast.parse(text)
    app = next((node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'App'), None)
    if app is None:
        raise ValueError('Expected original App class not found; no files changed')
    hook = marker + '\nfrom gmf_repair import install as _install_gmf_repair\n_install_gmf_repair()\n\n'
    lines = text.splitlines(keepends=True)
    index = min([app.lineno] + [d.lineno for d in app.decorator_list]) - 1
    updated = ''.join(lines[:index]) + hook + ''.join(lines[index:])
    ast.parse(updated)
    helpers = [project / (name + '.py') for name in
               ('gmf_repair', 'gmf_mask_recovery', 'gmf_embedded_masks', 'gmf_supplied_masks', 'gmf_material_formats', 'gmf_local_textures', 'gmf_teeth_parameters', 'gmf_2k26_repair', 'gmf_reference_checks', 'gmf_reference_audit', 'gmf_ycl_repair', 'gmf_surface_math', 'gmf_surface_transfer', 'gmf_surface_verification', 'gmf_aj_mask', 'gmf_jmtl_fields', 'gmf_jmtl_audit', 'gmf_native_assets', 'gmf_native_masks', 'gmf_2k26_audit', 'gmf_2k24_route', 'gmf_dds_alpha', 'gmf_report')]
    backup = project / 'gmf_gui.py.pre-repair'
    if any(helper.exists() for helper in helpers) or backup.exists():
        raise ValueError('Existing helper/backup would be overwritten; no files changed')
    shutil.copy2(gui, backup)
    for helper in helpers:
        shutil.copy2(Path(__file__).with_name(helper.name), helper)
    gui.write_text(updated, encoding='utf-8')
    return gui


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('project', help='COPY of complete original source project, not an EXE')
    args = parser.parse_args()
    try:
        print('Patched:', apply(args.project))
    except (ValueError, OSError, SyntaxError) as error:
        parser.exit(1, str(error) + '\n')
