"""Read-only exposed physics declarations; no conversion or motion validation.

Names and bounded indices can expose mismatched supplied assets. They do not
establish which opaque solver fields are active or that a game consumes a
particular declaration. Original Gorilla YCL and every physics byte are kept.
"""
import functools
import hashlib
import inspect
import os
from pathlib import Path
import struct


PATCH_VERSION = 'read-only-exposed-physics-bindings-1'
SUFFIXES = ('.ycl', '.hair_ywa', '.hair_corr_ywa', '.other_ywa', '.other_corr_ywa', '.wdf')
LIMITATION = 'Exposed names and index domains only; opaque physics, active solver semantics and in-game motion compatibility are not validated.'
MAX_YCL_BYTES = 32 * 1024 * 1024
MAX_YCL_NODES = 100000


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _u32(data, position, end):
    if position < 0 or position + 4 > end:
        raise ValueError('physics field is truncated')
    return struct.unpack_from('<I', data, position)[0]


def _nodes(data, start, end, depth=0, budget=None):
    """Original Gorilla node framing; leaf payloads remain opaque."""
    if depth > 64:
        return None
    if budget is None:
        budget = [MAX_YCL_NODES]
    nodes = []
    while start < end:
        if start + 12 > end:
            return None
        kind, head, span = struct.unpack_from('<III', data, start)
        if head < 12 or span < head or head % 4 or span % 4 or start + span > end:
            return None
        budget[0] -= 1
        if budget[0] < 0:
            raise ValueError('YCL node budget exceeds the read-only audit limit')
        children = _nodes(data, start + head, start + span, depth + 1, budget) if span > head else []
        nodes.append((start, kind, head, span, children))
        start += span
    return nodes


def inspect_ycl(data):
    """Inspect measured tree/name layouts without interpreting solver payloads."""
    facts = {'state': 'not_audited', 'scope': 'bounded header/tree and exposed names',
             'sha256': _sha(data), 'bytes': len(data), 'compatibility': 'not established'}
    try:
        if len(data) > MAX_YCL_BYTES:
            raise ValueError('YCL file exceeds the read-only audit byte limit')
        if len(data) < 32 or struct.unpack_from('<II', data) != (0, 32):
            raise ValueError('YCL root header layout is unsupported')
        words = struct.unpack_from('<HH', data, 16)
        facts['version_words'] = list(words)
        if words not in ((0, 1), (1, 25), (1, 26)):
            raise ValueError('YCL version is outside the measured name-table layouts')
        if _u32(data, 8, len(data)) != len(data):
            raise ValueError('YCL declared size differs from the file extent')
        nodes = _nodes(data, 32, len(data))
        if nodes is None or len(nodes) != _u32(data, 12, len(data)):
            raise ValueError('YCL root node framing/count is invalid')
        tables = {}
        for offset, kind, head, span, children in nodes:
            if kind not in (23, 25):
                continue
            if kind in tables or head < 20 or span < head or children is None:
                raise ValueError('YCL exposed name table is ambiguous or unsupported')
            names = []
            for position, child_kind, child_head, child_span, _ in children:
                if child_kind != 24 or child_span < child_head:
                    raise ValueError('YCL name-table child layout is unsupported')
                raw = data[position + child_head:position + child_span]
                if b'\0' not in raw:
                    raise ValueError('YCL name is not NUL terminated')
                name, padding = raw.split(b'\0', 1)
                if any(padding) or not name:
                    raise ValueError('YCL name padding or empty name is unsupported')
                names.append(name.decode('ascii'))
            if len(names) != _u32(data, offset + 12, offset + head):
                raise ValueError('YCL name-table declared count differs from its children')
            tables[kind] = names
        if set(tables) != {23, 25}:
            raise ValueError('YCL object or joint name table is unavailable')
        objects = []
        for offset, kind, head, span, _ in nodes:
            if kind != 5:
                continue
            if head < 24 or span < head:
                raise ValueError('YCL object header layout is unsupported')
            model_index, name_index, count = struct.unpack_from('<III', data, offset + 12)
            if model_index >= len(tables[23]) or name_index >= len(tables[23]):
                raise ValueError('YCL exposed object name index is out of range')
            objects.append({'name': tables[23][name_index], 'model_name': tables[23][model_index],
                            'declared_count_word': count, 'count_semantics': 'not inferred',
                            'node_kind': kind, 'node_head': head})
        facts.update(state='exposed_names_inspected', root_node_count=len(nodes), objects=objects,
                     joint_names=tables[25], payload_semantics='not decoded',
                     output_2k26_version_observed=words == (1, 26),
                     legacy_year='unidentified measured 0/1 layout' if words == (0, 1) else words[1])
    except (ValueError, UnicodeDecodeError, struct.error) as error:
        facts['reason'] = str(error)
    return facts


def _mesh_table(data, offset, expected_id, end):
    if offset + 80 > end or data[offset:offset + 4] != b'MOD!' or _u32(data, offset + 4, end) != expected_id:
        raise ValueError('YWA leading MOD table layout is unsupported')
    if any(data[offset + 8:offset + 76]):
        raise ValueError('YWA leading table header is outside the measured layout')
    count = _u32(data, offset + 76, end)
    position = offset + 80
    if not 0 < count <= 500 or position + count * 32 + 4 > end:
        raise ValueError('YWA leading mesh-name table is truncated or unsupported')
    names = []
    for index in range(count):
        raw = data[position + index * 32:position + (index + 1) * 32]
        if b'\0' not in raw:
            raise ValueError('YWA mesh name is not NUL terminated')
        name, padding = raw.split(b'\0', 1)
        if not name or any(padding):
            raise ValueError('YWA mesh-name padding is unsupported')
        names.append(name.decode('ascii'))
    if len(names) != len(set(names)):
        raise ValueError('YWA leading mesh-name table is ambiguous')
    position += count * 32
    records = _u32(data, position, end)
    position += 4
    if records != count or position + records * 12 + 8 > end:
        raise ValueError('YWA leading declaration count/extent is unsupported')
    declarations = []
    seen = set()
    for index in range(records):
        name_index, start, count = struct.unpack_from('<III', data, position + index * 12)
        if name_index >= len(names) or name_index in seen or start != 0 or count == 0:
            raise ValueError('YWA leading declaration indices are unsupported or ambiguous')
        seen.add(name_index)
        declarations.append({'name': names[name_index], 'vertex_count': count, 'offset': start})
    next_offset = position + records * 12 + 8
    if any(data[next_offset - 8:next_offset]):
        raise ValueError('YWA leading table padding is outside the measured layout')
    return declarations, next_offset


def inspect_ywa(data, suffix):
    """Read contiguous measured leading tables; never scan opaque MOD bytes."""
    facts = {'state': 'not_audited', 'sha256': _sha(data), 'bytes': len(data),
             'scope': 'measured leading SIZ!/MOD mesh declarations and exposed index list only',
             'compatibility': 'not established'}
    try:
        corrective = suffix in ('.hair_corr_ywa', '.other_corr_ywa')
        if suffix not in SUFFIXES[1:5] or len(data) < 16 or data[:4] != b'SIZ!' or data[-8:] != b'END!\0\0\0\0':
            raise ValueError('YWA does not have the measured raw SIZ!/END! envelope')
        if _u32(data, 4, len(data)) != (4 if corrective else 3):
            raise ValueError('YWA declared MOD count is outside the measured layout')
        first, next_offset = _mesh_table(data, 8, 1, len(data) - 8)
        second, position = _mesh_table(data, next_offset, 2, len(data) - 8)
        if position + 96 > len(data) - 8 or data[position:position + 4] != b'MOD!':
            raise ValueError('YWA payload following the leading tables is truncated')
        payload_id = _u32(data, position + 4, len(data) - 8)
        if payload_id != (6 if corrective else 4):
            raise ValueError('YWA payload following the tables is outside the measured layout')
        render, collider = (first, second) if corrective else (second, first)
        if len(render) != 1:
            raise ValueError('YWA exposed render-index ownership is ambiguous')
        primary = []
        if corrective:
            count = _u32(data, position + 88, len(data) - 8)
            if not 0 < count <= 65536:
                raise ValueError('YWA sequential u16 record count is outside its supported domain')
            if count != _u32(data, position + 92, len(data) - 8) or count != render[0]['vertex_count']:
                raise ValueError('YWA corrective record counts disagree')
            start = position + 96
            if start + count * 13 > len(data) - 8:
                raise ValueError('YWA corrective exposed record list is truncated')
            primary = [struct.unpack_from('<H', data, start + i * 12)[0] for i in range(count)]
            # Slot and collider references are retained as observed indices;
            # no claim of palette/global skeleton index semantics is made.
            collider_indices = {}
            for i in range(count):
                record = start + i * 12
                slot = data[record + 2]
                if slot >= len(collider):
                    raise ValueError('YWA corrective collider slot exceeds its declared table')
                values = struct.unpack_from('<HHH', data, record + 6)
                if 0xffff in values or sum(data[record + 3:record + 6]) not in (254, 255):
                    raise ValueError('YWA corrective sentinel or inactive-weight semantics are outside the measured layout')
                collider_indices.setdefault(slot, set()).update(values)
            facts['collider_index_ranges'] = [{'name': collider[slot]['name'], 'slot': slot,
                'minimum': min(values), 'maximum': max(values)} for slot, values in sorted(collider_indices.items())]
        else:
            header = struct.unpack_from('<6I', data, position + 72)
            count = header[5]
            if not 0 < count <= 65536:
                raise ValueError('YWA sequential u16 map count is outside its supported domain')
            if header[:2] != (0, 1) or header[3:5] != (0, 0) or count != render[0]['vertex_count']:
                raise ValueError('YWA exposed MOD4 prefix is outside the measured layout')
            if count != _u32(data, position + 132, len(data) - 8):
                raise ValueError('YWA exposed MOD4 vertex-count echo disagrees')
            start = position + 136
            if start + count * 2 > len(data) - 8:
                raise ValueError('YWA exposed MOD4 map is truncated')
            primary = list(struct.unpack_from('<' + 'H' * count, data, start))
        if primary != list(range(len(primary))):
            raise ValueError('YWA exposed index map is outside the measured sequential layout')
        facts.update(state='exposed_declarations_inspected', render_declarations=render,
                     collider_declarations=collider, primary_indices={'name': render[0]['name'],
                        'count': len(primary), 'minimum': min(primary), 'maximum': max(primary),
                        'exact_sequential': primary == list(range(len(primary)))},
                     full_MOD_count_and_opaque_payloads_validated=False,
                     remaining_MOD4_MOD6_MOD7_auxiliary_semantics='not decoded')
        facts['schema_provenance'] = 'supplied reference_source/WWE2K_MDL/Serialize/physics_patcher.py _read_mod1 and _pack_primary_record; measured Moxley offsets independently reviewed; no solver activity inferred'
    except (ValueError, UnicodeDecodeError, struct.error) as error:
        facts['reason'] = str(error)
    return facts


def _key(path):
    return os.path.normcase(str(Path(path).resolve()))


def _safe_path(path, root):
    path, root = Path(path), Path(root)
    if not path.resolve().is_relative_to(root.resolve()) or path.is_symlink():
        raise ValueError('physics audit path leaves its folder or is a symlink')
    current = path.parent
    while current != root:
        if current.is_symlink() or current == current.parent:
            raise ValueError('physics audit path contains an unsupported directory alias')
        current = current.parent
    return path


def _read(path, root, snapshots):
    path = _safe_path(path, root)
    data = path.read_bytes()
    snapshots.setdefault(_key(path), (path, data))
    if snapshots[_key(path)][1] != data:
        raise ValueError('physics audit input changed during inspection')
    return data


def _domain(mesh):
    count = int(mesh.num_verts)
    if count <= 0:
        raise ValueError('model mesh vertex domain is invalid')
    remap = getattr(mesh, 'vertex_remap', None)
    if remap is None:
        minimum, maximum, unique, dense = 0, count - 1, count, True
    else:
        if len(remap) != count or any(int(v) != v or int(v) < 0 for v in remap):
            raise ValueError('model mesh vertex-remap domain is invalid')
        values = {int(v) for v in remap}
        minimum, maximum, unique = min(values), max(values), len(values)
        dense = minimum == 0 and unique == maximum + 1
    return {'render_count': count, 'render_minimum': 0, 'render_maximum': count - 1,
            'remap_count': unique, 'remap_minimum': minimum, 'remap_maximum': maximum,
            'remap_explicit': remap is not None, 'domain_dense': dense}


def _embedded_wdf(report, source, expected_model, source_data, root, snapshots):
    """Verify precise recorded delivery independently from the solver schema."""
    rows = [row for row in report.get('physics_converted', []) if isinstance(row, dict)
            and row.get('source') and _key(row['source']) == _key(source)
            and row.get('embedded_tag') == 'WDF!' and row.get('kind') == 'wrap_deformation_layout'
            and row.get('state') == 'authored_wdf_clone_lod_layout_restored']
    if not rows:
        return None
    if len(rows) != 1:
        raise ValueError('embedded WDF delivery report is ambiguous')
    row = rows[0]
    if not row.get('output') or _key(row['output']) != _key(expected_model):
        raise ValueError('embedded WDF delivery does not match its mapped model')
    if row.get('source_wdf_sha256') != _sha(source_data):
        raise ValueError('embedded WDF delivery source fingerprint does not match')
    data = _read(Path(row['output']), root, snapshots)
    if row.get('output_model_sha256') != _sha(data):
        raise ValueError('embedded WDF delivery model fingerprint is stale or missing')
    from gmf_native_masks import envelopes
    payloads = [frame['payload'] for frame in envelopes(data) if frame['tag'] == b'WDF!']
    if len(payloads) != 1 or row.get('output_wdf_sha256') != _sha(payloads[0]):
        raise ValueError('embedded WDF delivery payload is absent, ambiguous or has a different fingerprint')
    return payloads[0], {'state': 'embedded_payload_delivery_verified', 'embedded_tag': 'WDF!',
        'storage': 'embedded_MCD_substream',
        'model': str(row['output']), 'output_model_sha256': _sha(data), 'output_model_bytes': len(data),
        'output_wdf_sha256': _sha(payloads[0]), 'output_wdf_bytes': len(payloads[0]),
        'solver_and_motion_compatibility': 'not established'}


def _binding(info, models):
    result = {'state': 'not_audited', 'scope': LIMITATION, 'observations': [], 'problems': [], 'warnings': []}
    if info['state'] == 'not_audited':
        result['reason'] = info.get('reason', 'format not inspected')
        return result
    if not models.get('attire'):
        result['reason'] = 'paired attire model is unavailable'
        return result
    def matches(name, role=None):
        selected = [models[role]] if role and models.get(role) else ([] if role else list(models.values()))
        return [m for model in selected for m in model.meshes if m.name == name]
    if 'objects' in info:
        available = [m for m in models.values() if m is not None]
        bones = {b.name for model in available for b in model.bones}
        missing_joints = sorted(set(info['joint_names']) - {'null'} - bones)
        result['declared_joint_names_missing_from_available_rigs'] = missing_joints
        if missing_joints:
            result['warnings'].append('declared YCL joint names are absent from the available paired rigs: ' + ', '.join(missing_joints))
        for obj in info['objects']:
            found = matches(obj['name'])
            state = 'present' if len(found) == 1 else 'ambiguous' if found else 'missing_model_reference'
            observation = {**obj, 'model_reference_state': state, 'paired_model_scope_complete': bool(models.get('base')),
                           'active_or_embedded_solver_semantics': 'not established'}
            if not found:
                result['warnings'].append('YCL object ' + obj['name'] + ' is absent from the available paired named meshes; embedded or unused solver-name semantics are unverified')
            elif len(found) > 1:
                result['warnings'].append('YCL object ' + obj['name'] + ' has multiple available paired named meshes')
            result['observations'].append(observation)
    else:
        for role, declarations in (('attire', info['render_declarations']), ('base', info['collider_declarations'])):
            for declaration in declarations:
                found = matches(declaration['name'], role)
                observation = {**declaration, 'model_role': role}
                if not models.get(role):
                    observation.update(state='not_audited', reason='paired ' + role + ' model is unavailable')
                elif len(found) != 1:
                    observation.update(state='not_audited', reason='named mesh is missing or ambiguous in the paired ' + role + ' model')
                    result['warnings'].append(declaration['name'] + ': named ' + role + ' mesh is missing or ambiguous')
                else:
                    domain = _domain(found[0]); observation['model_domain'] = domain
                    declared_maximum = declaration['offset'] + declaration['vertex_count'] - 1
                    index_range = info['primary_indices'] if role == 'attire' else next(
                        (r for r in info.get('collider_index_ranges', []) if r['name'] == declaration['name']), None)
                    maximum = index_range['maximum'] if index_range is not None else None
                    beyond_both = maximum is not None and maximum > max(domain['render_maximum'], domain['remap_maximum'])
                    observation['exposed_index_range'] = index_range
                    observation['declared_vertex_range_maximum'] = declared_maximum
                    observation['declared_range_exceeds_both_exposed_domains'] = beyond_both if index_range is not None else None
                    observation['state'] = ('declarations_only_bounds_unverified' if index_range is None else
                                            'outside_exposed_domains' if beyond_both else 'within_exposed_bounds_only')
                    if beyond_both:
                        result['problems'].append(declaration['name'] + ': exposed vertex index range through ' + str(maximum)
                            + ' exceeds both paired render and remap domains (maxima ' + str(domain['render_maximum']) + '/' + str(domain['remap_maximum']) + '); authored binding is inconsistent with the exposed mesh domains')
                    elif declaration['vertex_count'] != domain['render_count']:
                        result['warnings'].append(declaration['name'] + ': declared vertex count ' + str(declaration['vertex_count'])
                            + ' differs from paired render count ' + str(domain['render_count']) + '; count alone does not prove an invalid remap or LOD binding')
                result['observations'].append(observation)
    result['state'] = 'requires_attention' if result['problems'] or result['warnings'] else 'exposed_names_and_domains_checked_only'
    return result


def process(report, selected_source, selected_output, vcmodel, mapped=lambda relative, plan: relative, plan=None, log=lambda text: None):
    """Audit mapped files after conversion, using real report-paired model reads."""
    from gmf_2k26_repair import require_separate_output
    if Path(selected_source).is_symlink() or Path(selected_output).is_symlink():
        raise ValueError('physics audit refuses selected folder aliases')
    source, destination = require_separate_output(selected_source, selected_output)
    output = Path(report['output']).resolve()
    if not output.is_relative_to(destination) or output.is_relative_to(source):
        raise ValueError('physics audit recorded output leaves the separate destination')
    summary = {'version': PATCH_VERSION, 'scope': LIMITATION, 'rows': [], 'model_reads': 0,
               'physics_files_modified': False, 'in_game_validation': 'not_performed'}
    snapshots, cache = {}, {}
    files = sorted(p for p in source.rglob('*') if p.is_file() and p.suffix.lower() in SUFFIXES)
    mapped_paths = {}
    for path in files:
        relative = os.path.relpath(path, source)
        value = mapped(relative, plan or {})
        if value is not None:
            mapped_paths.setdefault(str(value).replace('\\', '/').casefold(), []).append(path)
    def model(path, role, root):
        key = _key(path)
        if key not in cache:
            evidence = {'role': role, 'path': str(path)}
            try:
                data = _read(path, root, snapshots)
                evidence.update(sha256=_sha(data), bytes=len(data))
                summary['model_reads'] += 1
                parsed = vcmodel.read_model(str(path), with_shapes=False)
                if path.read_bytes() != data:
                    raise ValueError('paired model changed during physics audit')
                cache[key] = (parsed, evidence)
            except Exception as error:
                evidence.update(state='not_audited', reason=str(error))
                cache[key] = (None, evidence)
        return cache[key]
    def context(path):
        candidates = [r for r in report.get('models', []) if isinstance(r, dict) and r.get('source') and r.get('output')
            and Path(r['source']).parent.resolve() == path.parent.resolve() and Path(r['source']).stem.casefold() == path.stem.casefold()]
        if len(candidates) != 1:
            return {}, {}, [], ['paired attire model report is missing or ambiguous']
        attire = candidates[0]
        bases = [r for r in report.get('models', []) if isinstance(r, dict) and r.get('source') and r.get('output')
                 and Path(r['source']).parent.name.casefold() == 'basemodel'
                 and path.resolve().is_relative_to(Path(r['source']).parent.parent.resolve())]
        bases.sort(key=lambda r: len(Path(r['source']).parts), reverse=True)
        base = bases[0] if bases and (len(bases) == 1 or len(Path(bases[0]['source']).parts) > len(Path(bases[1]['source']).parts)) else None
        src, dst, facts, errors = {}, {}, [], []
        for role, row in (('attire', attire), ('base', base)):
            if row is None:
                errors.append('paired ' + role + ' model report is unavailable');continue
            for side, root_path, holder in (('source', source, src), ('output', output, dst)):
                try:
                    parsed, evidence = model(Path(row[side]), role, root_path)
                    facts.append({**evidence, 'side': side})
                    if parsed is None:
                        errors.append(side + ' ' + role + ' model unavailable: ' + evidence['reason'])
                    else:
                        holder[role] = parsed
                except (OSError, ValueError, RuntimeError) as error:
                    errors.append(side + ' ' + role + ' model unavailable: ' + str(error))
        return src, dst, facts, errors
    for path in files:
        relative = os.path.relpath(path, source)
        value = mapped(relative, plan or {})
        if value is None:
            continue
        row = {'file': relative, 'mapped_file': str(value), 'source': str(path), 'output': str(output / value),
               'in_game_validation': 'not_performed', 'file_changes': 'none'}
        try:
            if len(mapped_paths[str(value).replace('\\', '/').casefold()]) != 1:
                raise ValueError('mapped physics file path has multiple source aliases')
            source_data = _read(path, source, snapshots)
            target = _safe_path(output / value, output)
            parse = inspect_ycl if path.suffix.lower() == '.ycl' else (
                lambda data: inspect_ywa(data, path.suffix.lower())) if path.suffix.lower() != '.wdf' else (
                lambda data: {'state': 'not_audited', 'sha256': _sha(data), 'bytes': len(data), 'reason': 'WDF solver schema is not audited'})
            row['source_format'] = parse(source_data)
            row['source_sha256'] = _sha(source_data)
            if target.is_file():
                target_data = _read(target, output, snapshots)
                row['output_format'] = parse(target_data);row['output_sha256'] = _sha(target_data)
                row['physics_payload_byte_identical'] = target_data == source_data
            else:
                embedded = _embedded_wdf(report,path,target.with_suffix('.mcd'),source_data,output,snapshots) if path.suffix.lower() == '.wdf' else None
                if embedded is not None:
                    payload, delivery = embedded
                    row['delivery'] = delivery;row['output'] = delivery['model']
                    row['output_sha256'] = _sha(payload)
                    row['output_format'] = {'state': 'not_audited', 'reason': 'WDF solver schema is not audited; embedded payload delivery was independently verified',
                        'sha256': _sha(payload), 'bytes': len(payload), 'embedded_tag': 'WDF!'}
                    row['physics_payload_byte_identical'] = payload == source_data
                else:
                    row['output_format'] = {'state': 'not_audited', 'reason': 'mapped output physics file is missing'}
            if row['source_format']['state'] == row['output_format']['state'] == 'not_audited':
                src_models, dst_models, evidence, errors = {}, {}, [], ['format does not expose supported bindings; paired model reads skipped']
            else:
                src_models, dst_models, evidence, errors = context(path)
            row['paired_models'] = evidence;row['paired_model_gaps'] = errors
            row['source_bindings'] = _binding(row['source_format'], src_models)
            row['output_bindings'] = _binding(row['output_format'], dst_models)
            row['unchanged_source_declarations_against_output_models'] = _binding(row['source_format'], dst_models)
            row['format_translation_scope'] = 'output version 1/26 observed; binding and motion validity are separate' if row['output_format'].get('output_2k26_version_observed') else 'format translation not established by this audit'
            for side in ('source', 'output'):
                binding = row[side + '_bindings']
                for message in binding['problems']:
                    full = relative + ': ' + side + ' physics binding: ' + message
                    if full not in report.setdefault('problems', []):report['problems'].append(full)
                for message in binding['warnings']:
                    full = relative + ': ' + side + ' physics binding needs review: ' + message
                    if full not in report.setdefault('warnings', []):report['warnings'].append(full)
            unavailable = [side for side in ('source', 'output') if row[side + '_bindings']['state'] == 'not_audited']
            row['state'] = 'not_audited' if len(unavailable) == 2 else 'partially_audited' if unavailable else 'exposed_declarations_audited_only'
            if unavailable:
                row['unavailable_binding_sides'] = unavailable
        except (OSError, ValueError, RuntimeError, struct.error) as error:
            row.update(state='not_audited', reason=str(error))
        summary['rows'].append(row)
        try:log('  ' + relative + ': physics audit ' + row['state'] + '; movement compatibility unverified')
        except Exception:pass
    try:
        unchanged = all(path.read_bytes() == data for path, data in snapshots.values())
    except OSError:
        unchanged = False
    summary['all_inspected_files_unchanged'] = unchanged
    if not unchanged:
        summary['state'] = 'invalidated_by_concurrent_file_change'
        report.setdefault('problems', []).append('Physics audit evidence invalidated: an inspected file changed during the read-only audit')
    else:
        summary['state'] = 'exposed_declarations_only; motion compatibility not validated'
    report['physics_binding_audit'] = summary
    if report.get('problems'):
        report['conversion_completeness'] = 'incomplete'
    return summary


def install(folder_module=None, vcmodel=None):
    """Install outside existing YCL/model writers; checkpoints only metadata."""
    if folder_module is None:
        from gmf import folder as folder_module
    if vcmodel is None:
        from gmf import vcmodel
    if getattr(folder_module, '_physics_binding_audit', None) == PATCH_VERSION:
        return
    original = folder_module.convert_folder
    @functools.wraps(original)
    def convert_folder(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs);bound.apply_defaults()
        if Path(bound.arguments['src']).is_symlink() or Path(bound.arguments['dst']).is_symlink():
            raise ValueError('physics audit refuses selected folder aliases')
        from gmf_2k26_repair import require_separate_output
        source, destination = require_separate_output(bound.arguments['src'], bound.arguments['dst'])
        slot = bound.arguments.get('slot')
        plan = folder_module._slot_plan(str(source), slot)[1] if slot else {}
        report = original(*args, **kwargs)
        try:
            process(report, source, destination, vcmodel, folder_module._mapped, plan, bound.arguments.get('log', lambda text: None))
        except Exception as error:
            report['physics_binding_audit'] = {'version': PATCH_VERSION, 'state': 'not_audited',
                'reason': str(error), 'physics_files_modified': False, 'in_game_validation': 'not_performed'}
            report.setdefault('problems', []).append('Read-only physics binding audit was not completed: ' + str(error))
            report['conversion_completeness'] = 'incomplete'
        from gmf_report import save_intermediate
        save_intermediate(report, destination)
        return report
    folder_module.convert_folder = convert_folder
    folder_module._physics_binding_audit = PATCH_VERSION
