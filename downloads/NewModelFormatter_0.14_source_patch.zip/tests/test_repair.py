"""Regression checks using isolated, reviewed original functions (Python 3.14)."""
import hashlib
import importlib.util
import marshal
import os
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gmf_repair as repair
from apply_source_patch import apply

FIXTURES = Path(__file__).parent / 'fixtures'


def recovered_function(module, name, namespace):
    # Deserialize for inspection; do not execute any recovered module imports.
    code = marshal.loads((FIXTURES / (module + '.marshal')).read_bytes())
    function = next(c for c in code.co_consts
                    if isinstance(c, types.CodeType) and c.co_name == name)
    return types.FunctionType(function, namespace)


def material(name):
    return types.SimpleNamespace(name=name, shader='yCh_hair',
                                 technique='NewHair_ColorChanging',
                                 params={'flowMap@ref': 123, 'g_comboMap@ref': 456})


def make_material_module(mats):
    spec = importlib.util.spec_from_file_location('test_writer', FIXTURES / 'mtls_writer.py')
    writer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(writer)
    namespace = {
        'os': os, '_load_writers': lambda: None,
        'mtl25': types.SimpleNamespace(read_mtls=lambda path: (5, mats)),
        'clean_name': lambda n: n.split(':', 1)[0],
        'game_folder': lambda path: 'Characters/Test/Attire',
        'rehome_refs': lambda *args: {},
        'to_2k26': lambda m, callback: (0x16, dict(m.params), list(m.params), None),
        'write_jmtl': lambda shader, params: repr((shader, params)).encode(),
        'mtls_writer': writer,
    }
    function = recovered_function('gmf.materials', 'convert_library', namespace)
    function.__defaults__ = (None, None, None)
    return types.SimpleNamespace(convert_library=function, **namespace)


class MaterialTests(unittest.TestCase):
    def test_reproduces_original_drop_and_repairs_exact_binding(self):
        mats = [material('hair_ALPHA'), material('hair2_ALPHA')]
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / 'source.mtls'
            original_dir = Path(tmp) / 'original'; original_dir.mkdir()
            fixed_dir = Path(tmp) / 'fixed'; fixed_dir.mkdir()
            module = make_material_module(mats)
            original = module.convert_library(str(source), str(original_dir / 'attire.mtls'),
                                              {'hair_alpha', 'hair2_ALPHA'})
            self.assertEqual([m['name'] for m in original['materials']], ['hair2_ALPHA'])
            self.assertTrue(any('library has none' in n for n in original['notes']))
            repair.patch_material_converter(module)
            fixed = module.convert_library(str(source), str(fixed_dir / 'attire.mtls'),
                                           {'hair_alpha', 'hair2_ALPHA'})
            self.assertEqual([m['name'] for m in fixed['materials']], ['hair2_ALPHA', 'hair_alpha'])
            self.assertFalse(any('library has none' in n for n in fixed['notes']))
            self.assertEqual(mats[0].name, 'hair_ALPHA')
            self.assertEqual((fixed_dir / 'Materials/hair_alpha.jmtl').read_bytes(),
                             repr((0x16, mats[0].params)).encode())
            blob = (fixed_dir / 'attire.mtls').read_bytes()
            size = struct.unpack_from('<I', blob, 8)[0]
            self.assertEqual(blob[12:12+size].split(b'\0')[:-1], [b'hair2_ALPHA', b'hair_alpha'])
            offset = (12 + size + 3) & ~3
            self.assertEqual(struct.unpack_from('<I', blob, offset)[0], 2)
            actual_hashes = struct.unpack_from('<2Q', blob, offset + 4)
            expected = [module.mtls_writer._fnv1a_64_lower(
                'Characters/Test/Attire/Materials/' + name + '.jmtl')
                for name in ('hair2_ALPHA', 'hair_alpha')]
            self.assertEqual(list(actual_hashes), expected)

    def test_exact_case_output_unchanged(self):
        mats = [material('hair_ALPHA')]
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            mod = make_material_module(mats)
            original = mod.convert_library(str(folder/'in.mtls'), str(folder/'out.mtls'), {'hair_ALPHA'})
            before = (folder/'out.mtls').read_bytes()
            repair.patch_material_converter(mod)
            fixed = mod.convert_library(str(folder/'in.mtls'), str(folder/'out.mtls'), {'hair_ALPHA'})
            self.assertEqual(before, (folder/'out.mtls').read_bytes())
            self.assertEqual(original['materials'], fixed['materials'])

    def test_colliding_library_fails_before_writes(self):
        with tempfile.TemporaryDirectory() as tmp:
            mod = make_material_module([material('hair_ALPHA'), material('hair_alpha')])
            repair.patch_material_converter(mod)
            with self.assertRaisesRegex(ValueError, 'ambiguous'):
                mod.convert_library(str(Path(tmp)/'in.mtls'), str(Path(tmp)/'out.mtls'), {'HAIR_ALPHA'})
            self.assertEqual(list(Path(tmp).iterdir()), [])

    def test_missing_material_and_lambert1_keep_original_notes(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            mod = make_material_module([material('hair_ALPHA')])
            original = mod.convert_library(str(folder/'in.mtls'), str(folder/'out.mtls'),
                                            {'hair_ALPHA', 'unknown', 'lambert1'})
            before = (folder/'out.mtls').read_bytes()
            repair.patch_material_converter(mod)
            fixed = mod.convert_library(str(folder/'in.mtls'), str(folder/'out.mtls'),
                                         {'hair_ALPHA', 'unknown', 'lambert1'})
            self.assertEqual(original['notes'], fixed['notes'])
            self.assertTrue(any('unknown' in n for n in fixed['notes']))
            self.assertFalse(any('lambert1' in n for n in fixed['notes']))
            self.assertEqual(before, (folder/'out.mtls').read_bytes())

    def test_binding_collision_fails(self):
        with self.assertRaisesRegex(ValueError, 'collide on Windows'):
            repair.reconcile_materials([material('hair_ALPHA')], ['hair_ALPHA', 'hair_alpha'], lambda n: n)

    def test_exact_match_and_unused_duplicates_keep_original_output(self):
        mats = [material('hair_ALPHA'), material('hair_alpha'), material('hair_alpha:skinned'),
                material('unused'), material('unused:skinned')]
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            mod = make_material_module(mats)
            original = mod.convert_library(str(folder/'in.mtls'), str(folder/'out.mtls'), {'hair_alpha'})
            before = (folder/'out.mtls').read_bytes()
            repair.patch_material_converter(mod)
            fixed = mod.convert_library(str(folder/'in.mtls'), str(folder/'out.mtls'), {'hair_alpha'})
            self.assertEqual(before, (folder/'out.mtls').read_bytes())
            self.assertEqual(original['materials'], fixed['materials'])
            self.assertEqual(original['notes'], fixed['notes'])
            self.assertEqual(fixed['material_binding_aliases'], [])

    def test_duplicate_cleaned_name_alias_uses_original_first_definition(self):
        first, second = material('hair_ALPHA:skinned'), material('hair_ALPHA')
        result, aliases = repair.reconcile_materials([first, second], ['hair_alpha'],
                                                     lambda n: n.split(':', 1)[0])
        self.assertEqual(result[0].name, 'hair_alpha:skinned')
        self.assertIs(result[0].params, first.params)
        self.assertIs(result[1], second)
        self.assertEqual(len(aliases), 1)

    def test_suffix_and_texture_objects_preserved(self):
        source = material('hair_ALPHA:Skinned')
        resolved, aliases = repair.reconcile_materials([source], ['hair_alpha'], lambda n: n.split(':')[0])
        self.assertEqual(resolved[0].name, 'hair_alpha:Skinned')
        self.assertIs(resolved[0].params, source.params)
        self.assertEqual(source.name, 'hair_ALPHA:Skinned')
        self.assertEqual(aliases, [{'source':'hair_ALPHA', 'binding':'hair_alpha'}])

    def test_unsafe_name_rejected(self):
        with self.assertRaisesRegex(ValueError, 'unsafe'):
            repair.reconcile_materials([material('../hair')], ['../hair'], lambda n: n)


class ReportTests(unittest.TestCase):
    def test_rey_unreadable_mask_no_longer_passes(self):
        empty = b'HPL!empty'
        namespace = {'os': os, 'mcd': types.SimpleNamespace(
            EMPTY_HPL=empty, hpl_is_whole=lambda b: False, parse_hpl=lambda b: {}),
            'expected_mask': lambda *args: ({}, 'unreadable', []),
            'mask_limits': lambda model: {}}
        original = recovered_function('gmf.convert', '_check_mask', namespace)
        model = types.SimpleNamespace(substreams=[(b'HPL!', empty)])
        problems, facts = [], {}
        original('123_Attire.mcd', model, {}, problems, facts, False)
        self.assertEqual(problems, [])  # Demonstrates old false pass.
        mod = types.SimpleNamespace(_check_mask=original, _sidecar_streams=lambda: [])
        repair.patch_mask_checks(mod)
        problems, facts = [], {}
        mod._check_mask('123_Attire.mcd', model, {}, problems, facts, False)
        self.assertEqual(facts['hide_mask'], 'unreadable')
        self.assertEqual(len(problems), 1)

    def test_billie_report_is_incomplete(self):
        report = {'warnings': ['873_Attire.ycl: hair/cloth physics not converted (cloth)'], 'problems': []}
        repair.mark_readiness(report)
        self.assertEqual(report['conversion_completeness'], 'incomplete')
        self.assertEqual(report['in_game_validation'], 'not_performed')
        self.assertEqual(len(report['problems']), 1)

    def test_no_game_claim_for_structural_pass(self):
        report = {'warnings': [], 'problems': []}
        repair.mark_readiness(report)
        self.assertEqual(report['conversion_completeness'], 'structural_checks_only')

    def test_folder_preserves_physics_and_persists_provenance(self):
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp)/'Rey'; src.mkdir(); dst = Path(tmp)/'out'; dst.mkdir()
            (src/'123_Attire.mdl').write_bytes(b'original mdl')
            (src/'123_Attire.mcd').write_bytes(b'different intermediate mcd')
            (src/'123_Attire.ycl').write_bytes(b'physics must not be copied')
            def original(src, dst, log=print, copy_other=False, slot=None):
                return {'source':os.path.abspath(src),
                        'warnings':['hair/cloth physics not converted'], 'problems':[]}
            mod = types.SimpleNamespace(convert_folder=original)
            repair.patch_folder_converter(mod)
            report = mod.convert_folder(str(src), str(dst))
            self.assertEqual(report['conversion_completeness'], 'incomplete')
            inventory = report['source_inventory_before_conversion']
            self.assertEqual(len(inventory), 3)
            for record in inventory:
                self.assertEqual(record['sha256'], hashlib.sha256((src/record['path']).read_bytes()).hexdigest())
            self.assertFalse((dst/'123_Attire.ycl').exists())
            self.assertTrue((dst/'Rey - conversion report.json').is_file())

    def test_report_name_preserves_original_for_trailing_separator_and_dot(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root/'Rey'; src.mkdir()
            dst = root/'out'; dst.mkdir()
            def original(src, dst, log=print, copy_other=False, slot=None):
                normalized = os.path.abspath(src)
                report = {'source': normalized, 'warnings': [], 'problems': []}
                import json
                path = Path(dst)/(os.path.basename(normalized)+' - conversion report.json')
                path.write_text(json.dumps(report))
                return report
            mod = types.SimpleNamespace(convert_folder=original)
            repair.patch_folder_converter(mod)
            mod.convert_folder(str(src)+os.sep, str(dst))
            self.assertEqual([p.name for p in dst.iterdir()], ['Rey - conversion report.json'])
            previous = os.getcwd()
            try:
                os.chdir(src)
                mod.convert_folder('.', str(dst))
            finally:
                os.chdir(previous)
            self.assertEqual([p.name for p in dst.iterdir()], ['Rey - conversion report.json'])

    def test_source_hook_preserves_existing_gui(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root/'gmf').mkdir()
            for name in ('materials','folder','convert','engine'):
                (root/'gmf'/f'{name}.py').write_text('')
            original = 'from gmf import folder\n\nclass App:\n    pass\n'
            (root/'gmf_gui.py').write_text(original)
            apply(root)
            self.assertEqual((root/'gmf_gui.py.pre-repair').read_text(), original)
            self.assertIn('class App:\n    pass', (root/'gmf_gui.py').read_text())
            with self.assertRaisesRegex(ValueError, 'already installed'):
                apply(root)


class GearWeightTests(unittest.TestCase):
    def test_nonmatching_model_keeps_original_policy(self):
        mesh=types.SimpleNamespace(name='M_Wings')
        ref=types.SimpleNamespace(set26={'J_Chest'})
        skeleton=types.SimpleNamespace(convert_weights=lambda *a,**k: {'policy':'original'})
        def convert_mcd(src_path,dst_path,ref):
            result=skeleton.convert_weights(mesh,{},ref)
            return {'notes':[], 'weight_policy':result['policy']}
        def verify(src_path,dst_path,ref):
            return skeleton.convert_weights(mesh,{},ref)['policy']
        module=types.SimpleNamespace(convert_mcd=convert_mcd,verify=verify)
        repair.patch_gear_converter(module,skeleton)
        with tempfile.TemporaryDirectory() as tmp:
            source=Path(tmp)/'unrelated.mcd';source.write_bytes(b'unrelated model')
            repair.set_gear_policy(True)
            try:
                report=module.convert_mcd(str(source),'output.mcd',ref)
                self.assertEqual(report['weight_policy'],'original')
                self.assertNotIn('experimental_gear_profile',report)
                self.assertEqual(module.verify(str(source),'output.mcd',ref),'original')
            finally:
                repair.set_gear_policy(False)

    def test_remap_preserves_budgets_and_original_arrays(self):
        original={'J_Clavicle_L':[0.7,0.5], 'H_Delt_Top_L':[0.2,0.4], 'J_Chest':[0.1,0.1]}
        mesh=types.SimpleNamespace(name='M_Wings', num_verts=2, weights=original)
        report=repair.preserve_gear_weights(mesh, {'H_Delt_Top_L':'J_Clavicle_L'}, {'J_Clavicle_L','J_Chest'})
        self.assertEqual(original['J_Clavicle_L'],[0.7,0.5])
        self.assertEqual(original['H_Delt_Top_L'],[0.2,0.4])
        self.assertAlmostEqual(mesh.weights['J_Clavicle_L'][0],0.9)
        self.assertAlmostEqual(mesh.weights['J_Clavicle_L'][1],0.9)
        self.assertEqual(report['verts_changed'],2)
        self.assertEqual(set(mesh.weights),{'J_Clavicle_L','J_Chest'})

    def test_unresolved_target_preserves_original(self):
        original={'old':[1.0]}
        mesh=types.SimpleNamespace(name='M_Wings',num_verts=1,weights=original)
        with self.assertRaisesRegex(ValueError,'no surviving target'):
            repair.preserve_gear_weights(mesh,{'old':'missing'},{'J_Chest'})
        self.assertIs(mesh.weights,original)

    def test_cycles_and_invalid_values_rejected(self):
        mesh=types.SimpleNamespace(name='M_Wings',num_verts=1,weights={'old':[1.0]})
        with self.assertRaisesRegex(ValueError,'cycle'):
            repair.preserve_gear_weights(mesh,{'old':'second','second':'old'},{'J_Chest'})
        mesh.weights={'J_Chest':[float('nan')]}
        with self.assertRaisesRegex(ValueError,'non-finite'):
            repair.preserve_gear_weights(mesh,{}, {'J_Chest'})

    def test_experimental_profile_is_not_reported_ready(self):
        report={'models':[{'experimental_gear_profile':[{'mesh':'M_Wings'}]}], 'warnings':[],'problems':[]}
        repair.mark_readiness(report)
        self.assertEqual(report['conversion_completeness'],'incomplete')

    def test_partial_rig_notices_identify_verified_base_and_rejected_attire(self):
        root = '/input/kenny'
        report = {'source': root, 'models': [
            {'source': root + '/BaseModel/baseModel.mcd', 'partial_legacy_rig': {
                'status': 'target_rig_and_weights_verified'}},
            {'source': root + '/152_Default_Attire/152_Attire.mcd', 'partial_legacy_rig': {
                'status': 'unsupported_source_core', 'reason': 'unnormalized source weights: M_Tights'}}
        ], 'warnings': [], 'problems': ['unreadable hide mask']}
        repair.mark_readiness(report)
        self.assertIn('BaseModel/baseModel.mcd: verified partial legacy rig requires entrance/gameplay validation', report['problems'])
        self.assertIn('152_Default_Attire/152_Attire.mcd: partial legacy rig validation: unnormalized source weights: M_Tights', report['problems'])
        self.assertEqual(report['problems'][0], 'unreadable hide mask')
        self.assertNotIn('verified partial legacy rig requires entrance/gameplay validation', report['problems'])
        self.assertEqual(report['conversion_completeness'], 'incomplete')


if __name__ == '__main__':
    if sys.version_info[:2] != (3, 14):
        raise SystemExit('These recovered-bytecode tests require Python 3.14')
    unittest.main()
