# NewModelFormatter 0.3 — experimental build

This is your draft standalone formatter using Gorilla's window layout and
conversion engine. It retains the original CakeView selection/check and
credits. It is not the final hair/cloth repair: Billie physics inputs and
in-game checks are still outstanding. No black-teeth issue is currently
reproducible; teeth changes are deferred and no teeth files are requested.

The existing input/output workflow is retained: the same folder selection,
slot selection, output layout, formats, original readers/writers, and CakeView
baking workflow. Version 0.3 also preserves Gorilla's original startup entrypoint,
including positional source-folder prefill, automation arguments, and Windows
DPI setup. The conversion report stays at the original normalized destination.

## Use on Windows

If the full ZIP cannot download, use the small `NewModelFormatter_0.3_patch_installer.zip`.
Extract it, double-click `Install.cmd`, and select your original Gorilla EXE.
It creates a separate `NewModelFormatter.exe` without Python. The binary patch
reconstructs this build exactly and checks both hashes; the Windows PowerShell
installer itself has not been run here. Keep its extracted files together.

1. Extract the ZIP. Keep your original formatter and mods. Put **NewModelFormatter.exe**
   in a separate folder; do not replace the original EXE.
2. Open it and select your existing **CakeView.exe** if prompted. The original
   saved CakeView choice is reused when it remains valid.
3. Select the original 2K25 character folder and a NEW empty output folder.
4. Leave **Rey gear: preserve attachments (experimental)** unchecked for the
   original stock-weight conversion. Check it only to test the alternative
   on the supplied Rey MCD. It changes wings, tops, and shoulder pads by
   remapping removed bones to the surviving ancestor chosen by Gorilla's rig
   conversion; it does not borrow nearest stock-body skin weights for those
   meshes. All other models/meshes keep the original weight conversion.
5. Inspect the JSON report before baking. The patch identifier is
   `material-binding-and-gear-profile-3`. Any unsupported physics or unreadable
   mask is a problem. The experimental gear mode is also flagged as needing
   entrance/gameplay validation. An incomplete report is not a fixed mod.

The Rey option is guarded by the SHA-256 of the actual supplied model
(`c181b2889e01a8ebb76f020457de7466a099ae327d87514e1cd44b36b3f6245c`),
so it will not silently apply to another mod with similar mesh names. A changed
or re-exported source model requires a new inspection/profile.

## What is verified

* 21 regression tests passed under Python 3.14.8, including material alias
  collisions, mask reporting, gear influence budgets, and failure protection.
* Actual Billie MCD and MTLS: the native reader confirms `M_Hair` binds
  `hair_alpha:skinned` while the library defines `hair_ALPHA:skinned`.
  Patched conversion emits all 13 actual nonsimulation material bindings.
  The original `lambert1` simulation exemption remains. Independent FlatBuffer
  reads confirm the hair shader, flow/combo texture hashes, and unbound
  pixel-mask reference. Texture image files and in-game appearance are untested.
* Billie model conversion passed the original native verifier under Wine:
  all 14 meshes retain positions, triangles, UVs, normals, remaps, shape
  positions, and material bindings. The original writer regenerates tangents;
  their values differ. Original skinning still reweights 249 `S_Hair` vertices.
  This is a model/material diagnostic, not a complete conversion with physics.
* Actual Rey MCD + supplied HPL: original and ancestor-remap conversions ran
  using the bundled native DLL under Wine. Both passed structural verification;
  all 14 meshes preserved positions, triangle lists, UVs, and material bindings
  exactly. Both carried the readable hide mask. Its base-model index bounds
  are currently checked against historical report counts, not an uploaded base.
* The new UI opened in a Wine/Xvfb smoke test with its controls visible, the
  gear option off by default, and CakeView still required/unselected. This is
  not a native Windows/CakeView selection or in-game test.
* Repackaging preserved the original bootloader/PE prefix and all 423 original
  PYZ module payloads. Original GUI logic is retained as `gmf_gui_base` with a
  small subclass for branding/options. CakeView's check module, native engine,
  reference caches, and retained CArchive payloads are unchanged.

Material reconciliation prefers an exact binding match and only resolves a case
alias when no exact match exists and the alias is unique. Duplicate definitions
retain Gorilla's first-used behavior. Unused definitions and missing-material
notes, including the `lambert1` exemption, retain their original handling.

## Remaining work

Rey's gear appearance/motion and skin hiding require entrance/gameplay tests.
No cloth physics was invented for Rey, whose earlier archive inventory lacks
separate physics. Billie's actual MCD/YCL are now inspected. Her YCL converts
byte-identically with Gorilla's translator and the supplied reference editor,
but contains populated `S_Outfit`, `S_Outfit_withBelt`, `M_Outfit`, and
`M_Outfit_withBelt` objects absent from her model. Matching `S_Hair` counts and
surviving joint links do not establish compatible movement. The existing
folder guard also treats substantial hair companions as unsupported cloth.
Physics support remains unresolved pending these original companion files:
`873_Attire.hair_ywa`, `873_Attire.hair_corr_ywa`, `873_Attire.other_ywa`,
`873_Attire.other_corr_ywa`, and `873_Attire.wdf`.
Teeth are not a current repair
blocker; investigation resumes only if an affected output can be reproduced.

The supplied Blender ModelFormatter is a reference, not a verified replacement
backend. Its donor-YCL fallback can disable every simulated mesh while still
exporting a file; this behavior is not imported into the new tool. Its main and
working C# material generators differ in teeth shader handling. That observation
does not justify a teeth change without a reproducible issue.

## Reproduce the build

From this source-patch directory with Python 3.14:

```powershell
py -3.14 -m unittest discover -s tests -v
py -3.14 build_patched_exe.py "C:\path\Gorilla Model Formatter.exe" "C:\path\NewModelFormatter.exe" --own-ui
```

The builder accepts only the exact inspected original EXE SHA-256
`ece4729f2ac3fc707c69550d4a79df7866c11a61463d8eb529ae927e04f377f2`
and refuses an existing output. It does not execute the original EXE or modify
the original files. It repackages the existing unsigned bootloader and payloads,
and compiles only the new Python modules/scripts. Both original and new EXEs
are unsigned. The validation JSON records the resulting hash and scope.
