Big Boom AJ material-link correction

This is a material table repair, not the NewModelFormatter application.
It targets only Characters/BigBoomAJ_2K24/BaseModel and the exact uploaded
388-byte table. Teeth and mouthbag payloads already match the requested
skin shader and current body textures. The uploaded table links elsewhere.

1. Extract this ZIP.
2. Back up the current baseModel.mtls in:
   C:\Users\mykea\Documents\Characters\BigBoomAJ_2K24\BaseModel
3. Put the included baseModel.mtls in that same BaseModel folder.
4. Keep the current Materials and Textures folders together with it.
5. Rebake the complete wrestler output with CakeView and check teeth in-game.

Use this table only with the folder name BigBoomAJ_2K24. Moving or renaming
the wrestler changes the material namespace. For a different folder name,
run the formatter on the complete model to rebuild its links.
The correction changes only seven material path-hash fields. No model,
texture or shader bytes are included or changed. The other five referenced
material payloads were not uploaded here and must remain in your full output.
The incorrect links are proved; an in-game visual fix is not yet confirmed.

Expected uploaded original MTLS SHA256:
d9b431d0537886defa39bd1befdad06ddbbd110ee138579e0dcba0f214c375c7
Corrected MTLS SHA256:
b298fc62b8c51a8745556ab6f27cde1f3ee4d45700d4795e115c0b2ace62df22
