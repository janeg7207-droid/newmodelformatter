# Rebuild the current experimental tool

Install Python 3.14 on Windows or Linux. Keep the uploaded original Gorilla 1.0
EXE unchanged. From the extracted source-patch directory run:

```
python -m unittest discover -s tests
python build_patched_exe.py "C:\path\Gorilla Model Formatter.exe" NewModelFormatter.exe --own-ui
```

The builder requires the exact original SHA-256 and a new output filename.
It reads the EXE archive as data and adds repair code; it does not execute the
input EXE. The resulting Windows EXE retains the original native DLLs,
references, Gorilla model conversion and YCL code, CakeView gate, and credits.
It adds the own UI, material repair, guarded mask recovery, native 2K26
preservation/material audit, and copied reference weight checks.

`reference_source/` contains all supplied source snapshots with hashes. It is
not a runnable replacement backend without the separate WWE2K_MDL Blender
add-on. Its import/export operators, Heat Seek and hair/HPL helpers are external
calls, not implemented in the supplied snapshot. See NEW_FORMATTER.md for the
exact missing add-on paths. Do not call this a complete reference-engine rebuild.

Tests include inspected recovered Gorilla bytecode fixtures, requiring Python
3.14. Native DLL/Wine checks and in-game tests are separate from those tests.
Original mod models, textures and the Gorilla EXE are excluded from this ZIP.
