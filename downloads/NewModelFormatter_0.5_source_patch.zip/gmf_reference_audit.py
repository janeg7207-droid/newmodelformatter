"""Adapt copied reference weight checks to Gorilla native-model objects.

Read-only diagnostics: no geometry, weights, material or physics writers run.
The Blender reference's classification is reported separately from the original
Gorilla verifier. A numerically sound influence can still be anatomically wrong.
"""
import functools
import inspect
import json
import math
import operator
import os
from pathlib import Path
from types import SimpleNamespace

from gmf_reference_checks import _attachment_weight_problem_indices

AUDIT_VERSION = 'supplied-reference-weight-audit-1'


def audit_model(model):
    """Use the actual copied reference function with small Blender-shaped views."""
    # Native records do not expose Blender use_deform. Treat existing bones as
    # potential deformers; apply only the reference's explicit driver markers.
    bones = [SimpleNamespace(name=bone.name, use_deform=True) for bone in model.bones]
    armature = SimpleNamespace(data=SimpleNamespace(bones=bones))
    result = {'version': AUDIT_VERSION,
              'scope': 'read_only_weight_data_checks; anatomical correctness unverified',
              'bone_deform_flags': 'not_in_native_records; reference driver-name rules only',
              'meshes': [], 'suspicious_vertices': 0}
    for mesh in model.meshes:
        count = operator.index(mesh.num_verts)
        if count < 0:
            raise ValueError('negative mesh vertex count')
        names = list(mesh.weights)
        vertices = [SimpleNamespace(index=index, groups=[]) for index in range(count)]
        for group_index, name in enumerate(names):
            vector = mesh.weights[name]
            if len(vector) != count:
                raise ValueError(mesh.name + ': weight vector length differs from vertex count')
            for index, item in enumerate(vector):
                weight = float(item)
                # Keep invalid and negative memberships visible to the original
                # checker; omit zero memberships as Blender does on export.
                if weight != 0.0:
                    vertices[index].groups.append(SimpleNamespace(group=group_index, weight=weight))
        obj = SimpleNamespace(vertex_groups=[SimpleNamespace(index=i, name=n) for i, n in enumerate(names)],
                              data=SimpleNamespace(vertices=vertices))
        indices, counts = _attachment_weight_problem_indices(obj, armature)
        # The reference flags missing J_/X_ targets. Also expose other positive
        # groups that are absent from the actual rig, without guessing a target.
        rig = {bone.name for bone in model.bones}
        absent = sorted(name for name in names if name not in rig and
                        any(math.isfinite(float(w)) and float(w) > 1e-7 for w in mesh.weights[name]))
        result['meshes'].append({'mesh':mesh.name, 'vertices':count,
                                'suspicious_vertices':len(indices), 'counts':counts,
                                'sample_vertex_indices':indices[:32],
                                'positive_weight_groups_absent_from_rig':absent})
        result['suspicious_vertices'] += len(indices)
    return result


def install(folder_module=None):
    """Run after both conversion paths, keep every original folder argument."""
    if folder_module is None:
        from gmf import folder as folder_module
    if getattr(folder_module, '_reference_weight_audit', None) == AUDIT_VERSION:
        return
    original = folder_module.convert_folder

    @functools.wraps(original)
    def convert_folder(*args, **kwargs):
        bound = inspect.signature(original).bind(*args, **kwargs)
        bound.apply_defaults()
        report = original(*args, **kwargs)
        warnings = report.setdefault('warnings', [])
        for record in report.get('models', []):
            output = record.get('output')
            if not output or not Path(output).is_file():
                continue
            try:
                model = folder_module.vc.read_model(output)
                audit = audit_model(model)
                record['reference_weight_audit'] = audit
                if audit['suspicious_vertices']:
                    warnings.append(os.path.basename(output) + ': reference weight audit flagged '
                                    + str(audit['suspicious_vertices'])
                                    + ' vertices; inspect mesh counts in report before judging movement')
                # Do not classify driver-name heuristics or valid nonunit sums
                # as a definitive movement failure. Invalid numbers/missing rig
                # targets are concrete output defects and block readiness.
                invalid = any(mesh['counts']['invalid'] or mesh['positive_weight_groups_absent_from_rig']
                              for mesh in audit['meshes'])
                if invalid:
                    message = os.path.basename(output) + ': invalid influence values or positive weights on absent rig bones'
                    if message not in report.setdefault('problems', []):
                        report['problems'].append(message)
            except Exception as exc:
                record['reference_weight_audit'] = {'version': AUDIT_VERSION, 'status':'not_audited', 'error':str(exc)}
                warnings.append(os.path.basename(output) + ': reference weight audit could not complete: ' + str(exc))
        report['conversion_completeness'] = ('incomplete' if report.get('problems') else 'structural_checks_only')
        report['reference_source_integration'] = {
            'weight_checks':AUDIT_VERSION,
            'geometry_backend':'Gorilla native engine; reference Blender backend unavailable',
            'ycl_backend':'original Gorilla converter',
            'full_reference_engine_rebuilt':False,
        }
        path = Path(bound.arguments['dst']).absolute() / (os.path.basename(report['source']) + ' - conversion report.json')
        with path.open('w', encoding='utf-8') as stream:
            json.dump(report, stream, indent=2, default=str)
        return report

    folder_module.convert_folder = convert_folder
    folder_module._reference_weight_audit = AUDIT_VERSION
