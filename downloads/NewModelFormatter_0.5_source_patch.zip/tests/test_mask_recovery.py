"""Exercise mask recovery through reviewed original parsing/filter/check functions."""
import copy
import hashlib
import inspect
import marshal
import os
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import gmf_mask_recovery as repair
FIXTURES = Path(__file__).parent/'fixtures'


def original_function(name, namespace):
    code = marshal.loads((FIXTURES/'gmf.convert.marshal').read_bytes())
    fn = next(c for c in code.co_consts if isinstance(c, types.CodeType) and c.co_name == name)
    result = types.FunctionType(fn, namespace)
    if name == 'expected_mask': result.__defaults__ = (None, None)
    if name == '_sidecar_streams': result.__defaults__ = (None,)
    if name == '_check_mask': result.__defaults__ = (False,)
    return result


def pure_mcd():
    module = types.ModuleType('reviewed_test_mcd')
    # This module body was reviewed: it imports struct and defines pure helpers.
    exec(marshal.loads((FIXTURES/'gmf.mcd.marshal').read_bytes()), module.__dict__)
    return module


def base_model():
    meshes = []
    for name, count in [('M_Body', 12755), ('M_Head', 4483)]:
        meshes.append(types.SimpleNamespace(name=name, num_verts=count,
            vertex_remap=list(range(count)), positions=[[0.,0.,0.]], triangles=[[0,1,2]]))
    return types.SimpleNamespace(version=41, meshes=meshes)


class RecoveryFixture:
    def __init__(self, root):
        self.root = root
        self.source = root/'input'/'123_Rey'
        self.src_base = self.source/'BaseModel'/'baseModel.mcd'
        self.src_model = self.source/'123_Default_Attire'/'123_Attire.mcd'
        self.src_hpl = self.src_model.with_suffix('.hpl')
        self.dst_base = root/'out'/'BaseModel'/'baseModel.mcd'
        self.dst_model = root/'out'/'123_Default_Attire'/'123_Attire.mcd'
        self.source_base = base_model()
        self.output_base = copy.deepcopy(self.source_base)
        self.output_base.version = 47
        # Documented original seam nudge must not invalidate remap association.
        self.output_base.meshes[1].positions = [[0.002,0.,0.]]
        self.mcd = pure_mcd()
        self.streams = []
        self.job_callback = None
        self.body_limits = {'M_Body':12755, 'M_Head':4483, 'M_EYE':626}
        for p, data in [(self.src_base,b'base original'), (self.src_model,b'model original'),
                        (self.src_hpl,b'HPL!unreadable fixture')]:
            p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(data)
        self.before = {p:p.read_bytes() for p in [self.src_base,self.src_model,self.src_hpl]}
        namespace = {'os':os,'mcd':self.mcd,'EMBED_PHYSICS':False,'PHYSICS_SIDECARS':(),
                     'mask_limits':self.limits,'MASK_INDEX_CEILING':65536}
        for name in ['expected_mask','_sidecar_streams','_check_mask']:
            namespace[name] = original_function(name, namespace)
        self.module = types.SimpleNamespace(**namespace)
        self.module.vc = types.SimpleNamespace(read_model=self.read_model,VERSION_2K26=47)
        # Trusted test-only functions use their own defining globals, so install
        # can update both consumer lookups without mutating this test module.
        namespace.update({'fixture':self,'module':self.module,'Path':Path})
        exec('''
def convert_mcd(src_path, dst_path, ref=None, base=False, body_limits=None):
    Path(dst_path).parent.mkdir(parents=True, exist_ok=True)
    Path(dst_path).write_bytes(b'converted base' if base else b'converted attire')
    if base:
        return {'kind':'base model','mask_limits':fixture.body_limits,'notes':[]}
    notes=[]
    fixture.streams=_sidecar_streams(src_path,False,body_limits,notes,{})
    return {'kind':'attire','notes':notes}
def verify(src_path, dst_path, ref=None, body_limits=None):
    problems,facts=[],{}
    model=type('Model',(),{'meshes':[], 'substreams':fixture.streams})()
    _check_mask(src_path,model,body_limits,problems,facts)
    return not problems,problems,facts
def convert_folder(src,dst,log=print,copy_other=True,slot=None):
    if fixture.job_callback is not None: fixture.job_callback()
    models=[]
    models.append(module.convert_mcd(str(fixture.src_base),str(fixture.dst_base),base=True))
    if fixture.after_base is not None: fixture.after_base()
    models.append(module.convert_mcd(str(fixture.src_model),str(fixture.dst_model),body_limits=fixture.body_limits))
    return {'models':models, 'verification':module.verify(str(fixture.src_model),str(fixture.dst_model),body_limits=fixture.body_limits)}
''',namespace)
        self.module.convert_mcd = namespace['convert_mcd']
        self.module.verify = namespace['verify']
        self.folder = types.SimpleNamespace(convert_folder=namespace['convert_folder'])
        self.after_base = None
        self.real_fp = repair._fingerprint
        self.fingerprint_override = {}

    def limits(self, model):
        return {m.name:max(m.vertex_remap,default=-1)+1 if m.vertex_remap is not None else m.num_verts for m in model.meshes}

    def read_model(self, path):
        return self.source_base if Path(path)==self.src_base else self.output_base

    def fingerprint(self,path):
        path=Path(path)
        if path in self.fingerprint_override: return self.fingerprint_override[path]
        fixtures={self.src_base:(repair.SOURCE_BASE_SHA256,repair.SOURCE_BASE_BYTES),
                  self.src_model:(repair.REY_MODEL_SHA256,repair.REY_MODEL_BYTES),
                  self.src_hpl:(repair.SOURCE_HPL_SHA256,repair.SOURCE_HPL_BYTES)}
        if path in fixtures and path.read_bytes()==self.before[path]: return fixtures[path]
        return self.real_fp(path)

    def run(self):
        # Digests are simulated only for synthetic geometry fixtures. Production
        # guards hash real files; no native-base claim follows from these tests.
        with mock.patch.object(repair,'_fingerprint',self.fingerprint):
            repair.install(self.module,self.folder)
            return self.folder.convert_folder(str(self.source),str(self.root/'out'))


class MaskRecoveryTests(unittest.TestCase):
    def test_payload_is_exact_supplied_complete_mask(self):
        data=repair.replacement_hpl()
        self.assertEqual(len(data),196220)
        self.assertEqual(hashlib.sha256(data).hexdigest(),repair.REPLACEMENT_HPL_SHA256)
        mcd=pure_mcd();self.assertTrue(mcd.hpl_is_whole(data))
        parsed=mcd.parse_hpl(data)
        self.assertEqual(parsed[0],parsed[1])
        self.assertEqual(set(parsed[0]),{0,1})
        for groups in parsed[0].values():
            self.assertEqual([(n,len(v)) for n,v in groups],[('M_Body',10977),('M_Head',1273)])

    def test_original_failure_then_exact_scoped_recovery_and_verification(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=RecoveryFixture(Path(tmp))
            original=f.module.expected_mask(str(f.src_hpl),{},f.body_limits)
            self.assertEqual(original[1],'unreadable')
            result=f.run();record=result['models'][1]['hide_mask_recovery']
            self.assertEqual(record['replacement_sha256'],repair.REPLACEMENT_HPL_SHA256)
            self.assertTrue(record['original_source_unchanged'])
            self.assertEqual(result['verification'][2]['hide_mask'],'mask')
            self.assertTrue(result['verification'][0])
            self.assertEqual({p:p.read_bytes() for p in f.before},f.before)
            flags=f.mcd.parse_hpl(f.streams[0][1])[0]
            self.assertEqual(flags,f.mcd.parse_hpl(repair.replacement_hpl())[0])
            # A mask request outside the folder/source context stays original.
            self.assertEqual(f.module.expected_mask(str(f.src_hpl),{},f.body_limits)[1],'unreadable')

    def test_unrelated_source_model_mask_and_base_cannot_trigger_profile(self):
        for which in ['src_model','src_hpl','src_base']:
            with self.subTest(which=which),tempfile.TemporaryDirectory() as tmp:
                f=RecoveryFixture(Path(tmp));path=getattr(f,which)
                f.fingerprint_override[path]=('0'*64,len(path.read_bytes()))
                result=f.run()
                self.assertNotIn('hide_mask_recovery',result['models'][1])
                self.assertEqual(result['verification'][2]['hide_mask'],'unreadable')

    def test_remap_reorder_and_triangle_reorder_are_rejected(self):
        for mode in ['remap','triangles']:
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp:
                f=RecoveryFixture(Path(tmp));mesh=f.output_base.meshes[0]
                if mode=='remap':mesh.vertex_remap[0],mesh.vertex_remap[1]=mesh.vertex_remap[1],mesh.vertex_remap[0]
                else:mesh.triangles=[[0,2,1]]
                self.assertNotIn('hide_mask_recovery',f.run()['models'][1])

    def test_missing_index_domain_and_wrong_caller_bounds_are_rejected(self):
        for mode in ['domain','bounds']:
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp:
                f=RecoveryFixture(Path(tmp))
                if mode=='domain':
                    f.source_base.meshes[0].vertex_remap[2]=1
                    f.output_base.meshes[0].vertex_remap[2]=1
                else:
                    f.after_base=lambda:f.body_limits.update(M_Body=12754)
                self.assertNotIn('hide_mask_recovery',f.run()['models'][1])

    def test_stale_converted_base_fingerprint_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=RecoveryFixture(Path(tmp));f.after_base=lambda:f.dst_base.write_bytes(b'changed after registration')
            self.assertNotIn('hide_mask_recovery',f.run()['models'][1])

    def test_previous_job_context_is_restored_on_failure(self):
        sentinel={'bases':{}}
        old=getattr(repair._context,'job',None)
        repair._context.job=sentinel
        try:
            with tempfile.TemporaryDirectory() as tmp:
                f=RecoveryFixture(Path(tmp))
                f.job_callback=lambda:(_ for _ in ()).throw(ValueError('job failed'))
                with self.assertRaisesRegex(ValueError,'job failed'): f.run()
                self.assertIs(repair._context.job,sentinel)
        finally:repair._context.job=old

    def test_base_empty_hpl_path_remains_unchanged(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=RecoveryFixture(Path(tmp));f.run()
            result=f.module._sidecar_streams(str(f.src_base),True,None,[],{})
            self.assertEqual(result,[(b'HPL!',f.mcd.EMPTY_HPL)])


if __name__=='__main__':unittest.main()
