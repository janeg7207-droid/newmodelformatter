# Supplied source snapshot

These six source files are copied unchanged from the uploaded ModelFormatter
archive and Vynx script. `manifest.json` records their hashes and archive hash.
No bundled EXE, DLL, original mod model, or texture is redistributed here.

Only the inspected reference weight-check functions are active in this build,
through `gmf_reference_checks.py` and `gmf_reference_audit.py`. The Blender add-on
source is archived for the rebuild, not automatically imported/executed.

The reference's model import/export, Heat Seek, skeleton alignment, and HPL
application require a separate `WWE2K_MDL` Blender add-on not in this archive.
Vynx also wraps those external routines. `MaterialGenerator.cs` additionally
uses the supplied MaterialEditor managed runtime through reflection; it has
not replaced Gorilla's material writer or enabled new teeth/blood/belt fixes.
YCL conversion deliberately retains the original Gorilla implementation.
