"""Repackage the exact supplied unsigned PyInstaller EXE; never execute it.

Run under Python 3.14. Adds repair helpers and an optional own-UI entrypoint.
Other compressed payloads and the PE prefix are kept.
"""
import argparse
import hashlib
import importlib.util
import json
import marshal
from pathlib import Path
import struct
import sys
import types
import zlib

EXPECTED_SHA256 = 'ece4729f2ac3fc707c69550d4a79df7866c11a61463d8eb529ae927e04f377f2'
MAGIC = b'MEI\014\013\012\013\016'
COOKIE = '!8sIIII64s'
ENTRY = '!IIIIBc'
COOKIE_SIZE = struct.calcsize(COOKIE)
ENTRY_SIZE = struct.calcsize(ENTRY)


def read_archive(data):
    cookie_at = data.rfind(MAGIC)
    if cookie_at < 0 or cookie_at + COOKIE_SIZE != len(data):
        raise ValueError('Expected an unsigned archive ending at EOF')
    magic, length, toc_offset, toc_size, version, library = struct.unpack_from(COOKIE, data, cookie_at)
    start = cookie_at + COOKIE_SIZE - length
    if start < 0 or toc_offset + toc_size != length - COOKIE_SIZE:
        raise ValueError('Invalid CArchive extent')
    entries = []
    at, end = start + toc_offset, start + toc_offset + toc_size
    while at < end:
        size, offset, compressed_size, plain_size, compressed, kind = struct.unpack_from(ENTRY, data, at)
        if size < ENTRY_SIZE + 1 or at + size > end or offset + compressed_size > toc_offset:
            raise ValueError('Invalid CArchive entry')
        name = data[at+ENTRY_SIZE:at+size].rstrip(b'\0').decode('utf-8')
        stored = data[start+offset:start+offset+compressed_size]
        plain = zlib.decompress(stored) if compressed else stored
        if len(plain) != plain_size:
            raise ValueError('CArchive payload size mismatch: ' + name)
        entries.append({'name': name, 'kind': kind, 'compressed': compressed,
                        'stored': stored, 'plain': plain})
        at += size
    return data[:start], entries, version, library


def pyz_contents(data):
    if data[:4] != b'PYZ\0':
        raise ValueError('Invalid PYZ signature')
    offset = struct.unpack_from('!i', data, 8)[0]
    return offset, dict(marshal.loads(data[offset:]))


def add_module(pyz, name, source):
    if pyz[4:8] != importlib.util.MAGIC_NUMBER:
        raise ValueError('Compiler bytecode magic does not match the EXE')
    offset, toc = pyz_contents(pyz)
    if name in toc:
        raise ValueError('Module already exists: ' + name)
    code = source if isinstance(source, types.CodeType) else compile(source, name+'.py', 'exec', dont_inherit=True)
    payload = zlib.compress(marshal.dumps(code), 9)
    toc[name] = (0, offset, len(payload))
    data = bytearray(pyz[:offset] + payload + marshal.dumps(list(toc.items())))
    struct.pack_into('!i', data, 8, offset + len(payload))
    return bytes(data)


def serialize(prefix, entries, version, library):
    body, table = bytearray(), bytearray()
    for entry in entries:
        offset = len(body); body.extend(entry['stored'])
        name = entry['name'].encode('utf-8') + b'\0'
        size = (ENTRY_SIZE + len(name) + 15) & ~15
        table.extend(struct.pack(ENTRY, size, offset, len(entry['stored']),
                                 len(entry['plain']), entry['compressed'], entry['kind']))
        table.extend(name + bytes(size - ENTRY_SIZE - len(name)))
    cookie = struct.pack(COOKIE, MAGIC, len(body)+len(table)+COOKIE_SIZE,
                         len(body), len(table), version, library)
    return prefix + body + table + cookie


def new_script(name, source):
    plain = marshal.dumps(compile(source, name+'.py', 'exec', dont_inherit=True))
    return {'name': name, 'kind': b's', 'compressed': 1,
            'stored': zlib.compress(plain, 9), 'plain': plain}


def build(original_path, output_path, own_ui=False):
    if sys.version_info[:2] != (3, 14):
        raise ValueError('Python 3.14 is required')
    original_path, output_path = Path(original_path), Path(output_path)
    if output_path.exists() or original_path.resolve() == output_path.resolve():
        raise ValueError('Choose a new output filename; originals are never overwritten')
    original = original_path.read_bytes()
    if hashlib.sha256(original).hexdigest() != EXPECTED_SHA256:
        raise ValueError('EXE does not match the inspected handoff build')
    prefix, entries, version, library = read_archive(original)
    if version != 314:
        raise ValueError('Expected Python 3.14 EXE')
    pyz = next(e for e in entries if e['name'] == 'PYZ.pyz')
    repair_source = Path(__file__).with_name('gmf_repair.py').read_text(encoding='utf-8')
    new_pyz = add_module(pyz['plain'], 'gmf_repair', repair_source)
    for name in ('gmf_mask_recovery', 'gmf_2k26_repair', 'gmf_reference_checks', 'gmf_reference_audit'):
        new_pyz = add_module(new_pyz, name,
            Path(__file__).with_name(name + '.py').read_text(encoding='utf-8'))
    if own_ui:
        original_gui = next(e for e in entries if e['name'] == 'gmf_gui')['plain']
        new_pyz = add_module(new_pyz, 'gmf_gui_base', marshal.loads(original_gui))
        new_pyz = add_module(new_pyz, 'newmodelformatter_gui',
            Path(__file__).with_name('newmodelformatter_gui.py').read_text(encoding='utf-8'))
    changed = {**pyz, 'plain': new_pyz,
               'stored': zlib.compress(new_pyz, 9) if pyz['compressed'] else new_pyz}
    final = []
    for entry in entries:
        if entry['name'] == 'gmf_gui':
            if own_ui:
                final.append(new_script('gmf_gui', 'import sys\nfrom newmodelformatter_gui import main\nsys.exit(main())\n'))
                continue
            else:
                final.append(new_script('gmf_repair_bootstrap',
                                        'from gmf_repair import install\ninstall()\n'))
        final.append(changed if entry['name'] == 'PYZ.pyz' else entry)
    output = serialize(prefix, final, version, library)
    # Independently reparse and verify every retained payload before saving.
    check_prefix, check, check_version, check_library = read_archive(output)
    check_by_name = {e['name']: e for e in check}
    assert check_prefix == prefix and (check_version, check_library) == (version, library)
    unchanged = 0
    for entry in entries:
        if entry['name'] != 'PYZ.pyz' and not (own_ui and entry['name'] == 'gmf_gui'):
            assert check_by_name[entry['name']]['stored'] == entry['stored']
            unchanged += 1
    old_offset, old_toc = pyz_contents(pyz['plain'])
    new_offset, new_toc = pyz_contents(check_by_name['PYZ.pyz']['plain'])
    for name, location in old_toc.items():
        assert new_toc[name] == location
        kind, pos, size = location
        assert new_pyz[pos:pos+size] == pyz['plain'][pos:pos+size]
    module_kind, pos, size = new_toc['gmf_repair']
    assert isinstance(marshal.loads(zlib.decompress(new_pyz[pos:pos+size])), types.CodeType)
    scripts = [e['name'] for e in check if e['kind'] == b's']
    if not own_ui:
        assert scripts.index('gmf_repair_bootstrap') + 1 == scripts.index('gmf_gui')
    else:
        kind,pos,size = new_toc['gmf_gui_base']
        # Marshal reference encoding can differ after deserialization; compare
        # canonical code serialization, including all original class methods.
        copied = marshal.loads(zlib.decompress(new_pyz[pos:pos+size]))
        assert marshal.dumps(copied) == marshal.dumps(marshal.loads(original_gui))
    validation = {
        'original_sha256': EXPECTED_SHA256,
        'patched_sha256': hashlib.sha256(output).hexdigest(),
        'patched_bytes': len(output),
        'unchanged_carchive_payloads': unchanged,
        'unchanged_pyz_modules': len(old_toc),
        'pe_prefix_unchanged': True,
        'original_gui_logic_retained': True,
        'cakeview_check_unchanged': True,
        'windows_execution_tested': False,
        'in_game_tested': False,
        'changes': ['material binding repairs', 'guarded supplied-Rey mask recovery',
                    'native 2K26 preservation and material audit',
                    'copied reference weight checks; Gorilla YCL unchanged'] +
                   (['own UI module; original GUI retained as gmf_gui_base',
                     'NewModelFormatter branding and optional Rey gear profile'] if own_ui else
                    ['repair bootstrap before original GUI']),
    }
    with output_path.open('xb') as stream:
        stream.write(output)
    output_path.with_suffix('.validation.json').write_text(json.dumps(validation, indent=2), encoding='utf-8')
    return validation


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original_exe')
    parser.add_argument('new_exe')
    parser.add_argument('--own-ui', action='store_true', help='Build the experimental NewModelFormatter window')
    args = parser.parse_args()
    print(json.dumps(build(args.original_exe, args.new_exe, args.own_ui), indent=2))
